export const BODY_LIMIT = 10_000_000;
export const SENSITIVE_KEY = /(token|sign|cookie|authorization|password|secret|session|csrf|dynamicToken|webOpSessionId|uniqueItemCampaign)/i;

export function canonicalPath(pathname) {
  return String(pathname || "")
    .replace(/^\/api_2\//, "/api/")
    .replace(/\.json$/, "")
    .replace(/\/+$/, "");
}

export function safeUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    for (const key of [...url.searchParams.keys()]) {
      if (SENSITIVE_KEY.test(key)) url.searchParams.set(key, "[REDACTED]");
    }
    return url.toString();
  } catch {
    return String(rawUrl || "");
  }
}

export function bodyFormat(text, mimeType = "") {
  const value = String(text || "").trim();
  if (!value) return "empty";
  try {
    JSON.parse(value);
    return "json";
  } catch {}
  const jsonp = value.match(/^[\w$.[\]]+\s*\(([\s\S]*)\)\s*;?$/);
  if (jsonp) {
    try {
      JSON.parse(jsonp[1]);
      return "jsonp";
    } catch {}
  }
  const mime = String(mimeType || "").toLowerCase();
  if (mime.includes("x-www-form-urlencoded") || /^[^=&\s]+=[\s\S]*(?:&[^=&\s]+=|$)/.test(value)) return "form";
  if (mime.includes("json")) return "json-text";
  if (mime.includes("xml") || /^<\?xml\s|^<[\w:-]+[\s>]/.test(value)) return "xml";
  if (mime.includes("html") || /^<!doctype\s+html|^<html[\s>]/i.test(value)) return "html";
  return "text";
}

export function redactJsonValue(value) {
  if (Array.isArray(value)) return value.map(redactJsonValue);
  if (!value || typeof value !== "object") return value;
  return Object.fromEntries(Object.entries(value).map(([key, child]) => [
    key,
    SENSITIVE_KEY.test(key) ? "[REDACTED]" : redactJsonValue(child),
  ]));
}

function sanitizePlainText(text) {
  return String(text || "")
    .replace(/((?:token|sign|cookie|authorization|password|secret|session|csrf|dynamicToken|webOpSessionId)\s*[=:]\s*)[^&\s,;"'}]+/gi, "$1[REDACTED]")
    .slice(0, BODY_LIMIT);
}

export function sanitizePayload(text, format = bodyFormat(text)) {
  const source = String(text || "");
  try {
    if (format === "json" || format === "json-text") return JSON.stringify(redactJsonValue(JSON.parse(source)));
    if (format === "jsonp") {
      const match = source.trim().match(/^([\w$.[\]]+\s*\()([\s\S]*)(\)\s*;?\s*)$/);
      if (match) return `${match[1]}${JSON.stringify(redactJsonValue(JSON.parse(match[2])))}${match[3]}`;
    }
    if (format === "form") {
      const params = new URLSearchParams(source);
      for (const key of [...params.keys()]) if (SENSITIVE_KEY.test(key)) params.set(key, "[REDACTED]");
      return params.toString().slice(0, BODY_LIMIT);
    }
  } catch {}
  return sanitizePlainText(source);
}

export function payloadKeySummary(text, format = bodyFormat(text)) {
  try {
    let source = String(text || "").trim();
    if (format === "jsonp") {
      const match = source.match(/^[\w$.[\]]+\s*\(([\s\S]*)\)\s*;?$/);
      if (!match) return [];
      source = match[1];
    }
    if (format === "form") return [...new Set([...new URLSearchParams(source).keys()])].slice(0, 100);
    const parsed = JSON.parse(source);
    if (Array.isArray(parsed)) return parsed[0] && typeof parsed[0] === "object" ? Object.keys(parsed[0]).slice(0, 100) : [];
    return parsed && typeof parsed === "object" ? Object.keys(parsed).slice(0, 100) : [];
  } catch {
    return [];
  }
}

export function requestPayload(postData, mimeType = "") {
  if (typeof postData !== "string") {
    return { requestBodyLength: 0, requestBodyTruncated: false, requestFormat: "empty", requestKeys: [], requestBody: "" };
  }
  const format = bodyFormat(postData, mimeType);
  const safeBody = sanitizePayload(postData, format);
  return {
    requestBodyLength: postData.length,
    requestBodyTruncated: safeBody.length > BODY_LIMIT,
    requestFormat: format,
    requestKeys: payloadKeySummary(safeBody, format),
    requestBody: safeBody.slice(0, BODY_LIMIT),
  };
}

export function isInterfaceResponse(meta) {
  const resourceType = String(meta?.type || "").toLowerCase();
  const mimeType = String(meta?.mimeType || "").toLowerCase();
  const path = String(meta?.pathname || "");
  return resourceType === "xhr"
    || resourceType === "fetch"
    || resourceType === "eventsource"
    || /json|xml/.test(mimeType)
    || /(?:^|\/)(?:api|api_2|graphql)(?:\/|$)/i.test(path)
    || /\.json$/i.test(path);
}

export function responsePayload(body, mimeType = "") {
  const format = bodyFormat(body, mimeType);
  const safeBody = sanitizePayload(body, format);
  return {
    bodyLength: String(body || "").length,
    truncated: safeBody.length > BODY_LIMIT,
    format,
    responseKeys: payloadKeySummary(safeBody, format),
    body: safeBody.slice(0, BODY_LIMIT),
  };
}
