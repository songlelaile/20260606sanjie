(function initCompetitionReportEngine(root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.DmpCompetitionReportEngine = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function createCompetitionReportEngine() {
  "use strict";

  const REQUIRED_TABLES = Object.freeze(["报告总览", "对标总表", "流量投放结构", "渠道指标", "人群画像"]);
  const REQUIRED_ENDPOINTS = Object.freeze([
    "/api/competition/analysis/base/indicator",
    "/api/competition/analysis/base/shop/indicator",
    "/api/competition/analysis/flow/paid_free/structural",
    "/api/competition/analysis/flow/investor/structural",
    "/api/competition/analysis/flow/indicator",
    "/api/dmp/insight/targets",
    "/api/dmp/v2/analysis/coverage",
    "/api/dmp/insight/tag/chart",
  ]);

  const ATTRIBUTION_SCALES = Object.freeze({ 1: "全域归因", 2: "广告域归因" });
  const STRUCTURE_ENDPOINTS = new Set([
    "/api/competition/analysis/flow/paid_free/structural",
    "/api/competition/analysis/flow/investor/structural",
  ]);
  const METRIC_LABELS = Object.freeze({
    alipayCnt: "成交笔数",
    alipayCnt1d: "广告归因成交笔数",
    alipayConversion: "支付转化率",
    alipayConversion1d: "广告归因支付转化率",
    averageOrderValue: "笔单价",
    buyCrowdGmvRate: "新客成交占比",
    cartRate: "加购率",
    cartRate1d: "广告归因加购率",
    click: "点击量",
    clickCost: "平均点击成本",
    clickRate: "点击率/流量占比",
    costRate: "投放成本占比",
    gmv1d: "广告归因成交金额",
    roi1d: "直接投产比",
  });

  const BASE_SPECS = Object.freeze([
    { id: "alipayCnt", label: "成交笔数", metric: "alipayCnt", endpoint: "/api/competition/analysis/base/shop/indicator", format: "integer" },
    { id: "shopClick", label: "全域点击量", metric: "click", endpoint: "/api/competition/analysis/base/shop/indicator", format: "integer" },
    { id: "cartRate", label: "加购率", metric: "cartRate", endpoint: "/api/competition/analysis/base/shop/indicator", format: "percent" },
    { id: "alipayConversion", label: "支付转化率", metric: "alipayConversion", endpoint: "/api/competition/analysis/base/shop/indicator", format: "percent" },
    { id: "buyCrowdGmvRate", label: "新客成交占比", metric: "buyCrowdGmvRate", endpoint: "/api/competition/analysis/base/shop/indicator", format: "percent" },
    { id: "averageOrderValue", label: "笔单价", metric: "averageOrderValue", endpoint: "/api/competition/analysis/base/shop/indicator", format: "number" },
    { id: "totalGmv", label: "成交金额（全店）", metric: null, endpoint: null, format: "number" },
    { id: "adClick", label: "广告点击量", metric: "click", endpoint: "/api/competition/analysis/base/indicator", format: "integer" },
    { id: "alipayCnt1d", label: "广告归因成交笔数", metric: "alipayCnt1d", endpoint: "/api/competition/analysis/base/indicator", format: "integer" },
    { id: "gmv1d", label: "广告归因成交金额", metric: "gmv1d", endpoint: "/api/competition/analysis/base/indicator", format: "number" },
    { id: "clickCost", label: "平均点击成本", metric: "clickCost", endpoint: "/api/competition/analysis/base/indicator", format: "number" },
    { id: "roi1d", label: "直接投产比", metric: "roi1d", endpoint: "/api/competition/analysis/base/indicator", format: "number" },
    { id: "adSpend", label: "广告消耗", metric: null, endpoint: null, format: "number" },
  ]);

  const SELECTED_METRICS = Object.freeze([
    ["alipayCnt", "成交笔数"],
    ["click", "点击量"],
    ["clickRate", "点击率/流量占比"],
    ["alipayCnt1d", "广告归因成交笔数"],
    ["cartRate1d", "广告归因加购率"],
    ["alipayConversion1d", "广告归因支付转化率"],
    ["cartRate", "加购率"],
    ["alipayConversion", "支付转化率"],
    ["roi1d", "直接投产比"],
  ]);

  const FIRST_ORDER = Object.freeze([
    "关键词推广", "流量宝", "内容营销", "品销宝", "全站推广", "人群推广",
    "淘宝客", "淘宝其他", "淘宝私域", "淘宝搜索", "淘宝推荐", "淘宝直播",
  ]);
  const SECOND_ORDER = Object.freeze([
    "88VIP频道", "芭芭农场", "百亿补贴频道", "榜单会场", "超级短视频", "超级直播", "电视淘宝", "店铺超链",
    "短视频全屏页上下滑", "短直联动", "飞猪会员中心", "飞猪其他", "购物车", "逛逛", "红包省钱卡", "货品全站推广",
    "巨浪", "品牌专区", "其他入口榜单", "日常营销活动", "商品详情页入口榜单", "手机浏览器访问淘宝", "手淘充值",
    "手淘发表评价", "手淘拍立淘", "手淘确认订单", "手淘扫一扫", "手淘旺信", "手淘问大家", "手淘我的评价",
    "手淘消息中心", "搜索入口榜单", "淘宝关注", "淘宝秒杀频道", "淘工厂直营", "淘金币及相关场域", "淘口令分享",
    "淘内待分类", "淘特其他渠道", "淘特自主访问", "淘外网站", "天猫APP", "天猫U先试用", "天猫超市", "我的淘宝",
    "闲鱼", "小黑盒频道", "一淘", "直接访问", "主会场",
  ]);
  const PORTRAIT_TAGS = Object.freeze(["用户性别", "用户年龄", "月均消费频次", "消费能力等级", "城市等级", "大快消策略人群（老）"]);
  const STRUCTURE_ORDER = Object.freeze(["付费", "免费搜索", "免费推荐", "免费其他", "关键词推广", "人群推广", "内容营销", "全站推广"]);

  function canonicalPath(value) {
    let pathname = String(value || "");
    try { pathname = new URL(pathname).pathname; } catch { pathname = pathname.split("?")[0]; }
    return pathname.replace(/^\/api_2\//, "/api/").replace(/\.json$/, "").replace(/\/+$/, "");
  }

  function parseJsonLike(value, depth = 0) {
    if (value == null || depth > 4) return value == null ? null : value;
    if (typeof value === "object") return value;
    if (typeof value !== "string") return null;
    const text = value.trim().replace(/^```(?:json|javascript|js)?\s*/i, "").replace(/\s*```$/, "");
    if (!text) return null;
    try {
      const parsed = JSON.parse(text);
      return typeof parsed === "string" ? parseJsonLike(parsed, depth + 1) : parsed;
    } catch {}
    const jsonp = text.match(/^[\w$.[\]]+\s*\(([\s\S]*)\)\s*;?$/);
    if (jsonp) {
      try { return JSON.parse(jsonp[1]); } catch {}
    }
    return null;
  }

  function parseRequestBody(value) {
    const parsed = parseJsonLike(value);
    if (parsed != null) return parsed;
    const text = String(value || "").trim();
    if (!text.includes("=")) return null;
    try {
      const output = {};
      for (const [key, rawValue] of new URLSearchParams(text)) {
        const child = parseJsonLike(rawValue);
        const normalized = child == null ? rawValue : child;
        if (!(key in output)) output[key] = normalized;
        else if (Array.isArray(output[key])) output[key].push(normalized);
        else output[key] = [output[key], normalized];
      }
      return Object.keys(output).length ? output : null;
    } catch { return null; }
  }

  function normalizeRecord(raw, index = 0) {
    const requestSource = raw?.requestBody ?? raw?.request ?? raw?.postData ?? raw?.request?.postData ?? null;
    const responseSource = raw?.body ?? raw?.responseBody ?? raw?.response?.body ?? raw?.response ?? null;
    const url = raw?.url || raw?.requestUrl || raw?.request?.url || "";
    const endpoint = canonicalPath(raw?.endpoint || raw?.path || raw?.canonicalPath || raw?.pathname || url);
    const body = parseJsonLike(responseSource);
    return {
      captureIndex: index,
      capturedAt: raw?.capturedAt || raw?.startedDateTime || null,
      method: String(raw?.method || raw?.request?.method || "GET").toUpperCase(),
      path: endpoint,
      status: raw?.status ?? raw?.response?.status ?? null,
      truncated: Boolean(raw?.truncated || raw?.bodyTruncated),
      bodyAvailable: raw?.bodyAvailable !== false && responseSource != null && responseSource !== "",
      requestBody: parseRequestBody(requestSource),
      body,
    };
  }

  function requestOf(record) {
    const request = record?.requestBody;
    if (!request || typeof request !== "object") return request;
    if (request.data && typeof request.data === "object" && (request.data.competitorIds || request.data.beginDate || Object.keys(request).length === 1)) return request.data;
    return request;
  }

  function dataOf(body) {
    return body && typeof body === "object" ? (body.data ?? body) : null;
  }

  function unique(values) { return [...new Set(values.filter((value) => value != null && value !== ""))]; }

  function singleShopId(value) {
    const shopId = String(value ?? "").trim();
    return /^\d+$/.test(shopId) ? shopId : "";
  }
  function roleOrder(role) { return role === "主体" ? 0 : 1; }
  function normalizeValue(value) { return value === null || value === undefined || value === "" ? "—" : value; }
  function isNumber(value) { return typeof value === "number" && Number.isFinite(value); }
  function ratio(numerator, denominator) { return isNumber(numerator) && isNumber(denominator) && denominator !== 0 ? numerator / denominator : "—"; }
  function growth(current, compare) { return isNumber(current) && isNumber(compare) && compare !== 0 ? current / compare - 1 : "—"; }
  function daysInclusive(start, end) {
    if (!start || !end) return null;
    const first = Date.parse(`${start}T00:00:00Z`);
    const last = Date.parse(`${end}T00:00:00Z`);
    return Number.isFinite(first) && Number.isFinite(last) && last >= first ? Math.round((last - first) / 86400000) + 1 : null;
  }
  function periodContext(request = {}) {
    const beginDate = request.beginDate || request.startDate || request.start;
    const endDate = request.endDate || request.end;
    const peerBeginDate = request.peerBeginDate || request.compareBeginDate || request.peerStartDate;
    const peerEndDate = request.peerEndDate || request.compareEndDate;
    const analysisDays = daysInclusive(beginDate, endDate);
    const compareDays = daysInclusive(peerBeginDate, peerEndDate);
    return {
      analysisDays,
      analysisPeriod: beginDate && endDate ? `${beginDate}~${endDate}${analysisDays ? `（${analysisDays}天）` : ""}` : "",
      compareDays,
      comparePeriod: peerBeginDate && peerEndDate ? `${peerBeginDate}~${peerEndDate}${compareDays ? `（${compareDays}天）` : ""}` : "",
    };
  }

  function collectTokenValues(value) {
    const output = [];
    function visit(node) {
      if (Array.isArray(node)) return node.forEach(visit);
      if (!node || typeof node !== "object") return;
      for (const [key, child] of Object.entries(node)) {
        if ((key === "competitorId" || key === "competitor_id") && typeof child === "string") output.push(child);
        else if (key === "competitorIds" && Array.isArray(child)) child.filter((item) => typeof item === "string").forEach((item) => output.push(item));
        else visit(child);
      }
    }
    visit(value);
    return output;
  }

  function collectSelectedCompetitorTokens(value) {
    const output = [];
    function visit(node) {
      if (Array.isArray(node)) return node.forEach(visit);
      if (!node || typeof node !== "object") return;
      for (const [key, child] of Object.entries(node)) {
        if (key === "competitorIds" && Array.isArray(child)) {
          child.filter((item) => typeof item === "string" && item && !/^\[(?:REDACTED|TRUNCATED)\]$/i.test(item)).forEach((item) => output.push(item));
        } else visit(child);
      }
    }
    visit(value);
    return output;
  }

  function selectionRows(value) {
    const output = [];
    function visit(node) {
      if (Array.isArray(node)) return node.forEach(visit);
      if (!node || typeof node !== "object") return;
      if (Array.isArray(node.selects)) output.push(...node.selects);
      Object.values(node).forEach(visit);
    }
    visit(value);
    return output;
  }

  function audienceContext(request = {}) {
    const selections = selectionRows(request.selectTagOptionSetDTO ?? request);
    const byGroup = new Map(selections.map((entry) => [Number(entry.optionGroupId), entry]));
    return {
      shopId: singleShopId(byGroup.get(328146)?.values),
      behavior: byGroup.get(328147)?.names ?? byGroup.get(328147)?.values ?? "",
      recentDays: byGroup.get(328260)?.values ?? "",
      dateRange: byGroup.get(328261)?.values ?? "",
    };
  }

  function targetShops(body) {
    const result = dataOf(body)?.result;
    const pick = (targets) => unique((targets || []).flatMap((target) => selectionRows(target))
      .filter((entry) => Number(entry.optionGroupId) === 328146)
      .map((entry) => singleShopId(entry.values))
      .filter(Boolean));
    return { subjects: pick(result?.targets), competitors: pick(result?.compareTargets) };
  }

  function createRegistry(records, metadata = {}) {
    const explicitCompetitorTokens = [];
    const tokenEvidence = new Map();
    const session = metadata?.session || {};
    const subjectShopIds = [singleShopId(session.portraitSubjectShopId)].filter(Boolean);
    const competitorShopIds = unique((Array.isArray(session.portraitCompetitorShopIds) ? session.portraitCompetitorShopIds : [])
      .map(singleShopId)
      .filter(Boolean));
    const portraitNameById = new Map((Array.isArray(session.portraitShopMappings) ? session.portraitShopMappings : [])
      .map((row) => [singleShopId(row?.shopId), String(row?.competitorName || "").trim()])
      .filter(([shopId, name]) => shopId && name));

    function addEvidence(token, base) {
      if (typeof token !== "string" || !token) return;
      const evidence = tokenEvidence.get(token) || { numeric: 0, string: 0, other: 0 };
      if (typeof base === "number" && Number.isFinite(base)) evidence.numeric += 1;
      else if (typeof base === "string") evidence.string += 1;
      else evidence.other += 1;
      tokenEvidence.set(token, evidence);
    }

    for (const record of records) {
      if (record.path.startsWith("/api/competition/analysis/")) {
        // Structural endpoints are queried once per object, so their competitorIds
        // may contain either the subject or competitor token. Comparative endpoints
        // carry the actual selected competitor list and are authoritative here.
        if (!STRUCTURE_ENDPOINTS.has(record.path)) {
          explicitCompetitorTokens.push(...collectSelectedCompetitorTokens(requestOf(record)));
        }
        function inspectEntity(node) {
          if (Array.isArray(node)) return node.forEach(inspectEntity);
          if (!node || typeof node !== "object") return;
          if (Array.isArray(node.competitorList)) {
            for (const entity of node.competitorList) {
              addEvidence(entity?.competitorId ?? entity?.competitor_id, entity?.base);
            }
          }
          Object.values(node).forEach(inspectEntity);
        }
        inspectEntity(record.body);
      }
      if (record.path === "/api/dmp/insight/targets") {
        const shops = targetShops(record.body);
        subjectShopIds.push(...shops.subjects);
        competitorShopIds.push(...shops.competitors);
      }
    }
    const competitorSet = new Set(unique(explicitCompetitorTokens));
    const subjectSet = new Set();
    for (const [token, evidence] of tokenEvidence) {
      if (competitorSet.has(token)) continue;
      if (evidence.numeric > 0) subjectSet.add(token);
      else if (evidence.string > 0) competitorSet.add(token);
    }
    const subjectShopSet = new Set(unique(subjectShopIds));
    const competitorShopSet = new Set(unique(competitorShopIds));
    const requestedNames = unique(Array.isArray(metadata?.session?.competitorNames)
      ? metadata.session.competitorNames.map((name) => String(name).trim())
      : String(metadata?.session?.competitorName || "").split(/[,，、;；\n]+/).map((name) => name.trim()));
    const competitorTokenList = [...competitorSet];
    const subjectTokenList = [...subjectSet];
    const competitorShopList = [...competitorShopSet];
    const subjectShopList = [...subjectShopSet];
    const competitorCount = Math.max(competitorTokenList.length, competitorShopList.length);
    const competitorLabel = (index) => requestedNames[index] || (competitorCount === 1 ? "竞店" : `竞店${index + 1}`);
    const competitorShopLabel = (shopId, index) => portraitNameById.get(String(shopId)) || competitorLabel(index);
    const roleForToken = (token) => {
      const value = String(token ?? "");
      if (/^主体/.test(value)) return "主体";
      if (/^竞品/.test(value)) return "竞品";
      if (competitorSet.has(value)) return "竞品";
      if (subjectSet.has(value)) return "主体";
      return "未映射";
    };
    const roleForShop = (shopId) => subjectShopSet.has(String(shopId)) ? "主体" : competitorShopSet.has(String(shopId)) ? "竞品" : "未映射";
    const identityForToken = (token, fallbackRole = "未映射") => {
      const value = String(token ?? "");
      const role = roleForToken(value) === "未映射" ? fallbackRole : roleForToken(value);
      if (role === "主体") return { role, key: value || "subject", label: "本店" };
      if (role === "竞品") {
        const index = competitorTokenList.indexOf(value);
        return { role, key: value || `competitor-${Math.max(0, index) + 1}`, label: competitorLabel(index < 0 ? 0 : index) };
      }
      return { role, key: value || "unmapped", label: "未映射" };
    };
    const identityForShop = (shopId) => {
      const value = String(shopId ?? "");
      const role = roleForShop(value);
      if (role === "主体") return { role, key: value || "subject-shop", label: "本店" };
      if (role === "竞品") {
        const index = competitorShopList.indexOf(value);
        return { role, key: value || `competitor-shop-${Math.max(0, index) + 1}`, label: competitorShopLabel(value, index < 0 ? 0 : index) };
      }
      return { role, key: value || "unmapped-shop", label: "未映射" };
    };
    return {
      roleForToken,
      roleForShop,
      identityForToken,
      identityForShop,
      subjectShopIds: subjectShopList,
      competitorShopIds: competitorShopList,
      mappings: [
        ...subjectTokenList.map((identifier) => ({ idSystem: "竞争接口对象", role: "主体", alias: "本店", identifier })),
        ...competitorTokenList.map((identifier, index) => ({ idSystem: "竞争接口对象", role: "竞品", alias: competitorLabel(index), identifier })),
        ...subjectShopList.map((identifier) => ({ idSystem: "画像接口店铺ID", role: "主体", alias: "本店", identifier })),
        ...competitorShopList.map((identifier, index) => ({ idSystem: "画像接口店铺ID", role: "竞品", alias: competitorShopLabel(identifier, index), identifier })),
      ],
    };
  }

  function dedupeRows(rows) {
    const map = new Map();
    for (const row of rows) {
      const key = JSON.stringify(row);
      if (!map.has(key)) map.set(key, row);
    }
    return [...map.values()];
  }

  function metricRowsFromNode(node, context, registry, output) {
    if (!node || typeof node !== "object") return;
    for (const [metric, value] of Object.entries(node)) {
      if (!value || typeof value !== "object" || !Array.isArray(value.competitorList)) continue;
      for (const entity of value.competitorList) {
        const token = entity.competitorId ?? entity.competitor_id;
        const fallbackRole = typeof entity.base === "number" ? "主体" : "竞品";
        const identity = registry.identityForToken(token, fallbackRole);
        output.push({
          ...context,
          metric,
          metricName: METRIC_LABELS[metric] || metric,
          entityRole: identity.role,
          entityKey: identity.key,
          entityLabel: identity.label,
          currentValue: entity.base ?? null,
          compareValue: entity.basePeriod ?? null,
          growthRate: entity.growthRate ?? null,
        });
      }
    }
  }

  function inventoryFromRecords(rawRecords = [], metadata = {}) {
    const records = rawRecords.map(normalizeRecord);
    const registry = createRegistry(records, metadata);
    const metricRows = [];
    const structureRows = [];
    const portraitRows = [];
    const metricEndpoints = new Set([
      "/api/competition/analysis/base/indicator",
      "/api/competition/analysis/base/shop/indicator",
      "/api/competition/analysis/flow/indicator",
    ]);

    for (const record of records) {
      if (record.method !== "POST" || !record.body) continue;
      const request = requestOf(record) || {};
      const period = periodContext(request);
      if (metricEndpoints.has(record.path)) {
        const context = {
          endpoint: record.path,
          ...period,
          attributionScale: request.attributionScale ?? "",
          attributionScaleLabel: ATTRIBUTION_SCALES[request.attributionScale] || "",
          channelLevel: "整体",
          firstChannelName: "",
          secondChannelName: "",
        };
        const data = dataOf(record.body);
        if (record.path === "/api/competition/analysis/flow/indicator") {
          for (const channel of data?.list || []) {
            const first = { ...context, channelLevel: "一级渠道", firstChannelName: channel.channelName || "" };
            metricRowsFromNode(channel, first, registry, metricRows);
            for (const child of channel.subChannels || []) {
              metricRowsFromNode(child, { ...first, channelLevel: "二级渠道", secondChannelName: child.channelName || "" }, registry, metricRows);
            }
          }
        } else metricRowsFromNode(data, context, registry, metricRows);
      }

      if (STRUCTURE_ENDPOINTS.has(record.path)) {
        const token = collectTokenValues(request)[0];
        const identity = registry.identityForToken(token);
        for (const row of dataOf(record.body)?.list || []) {
          const metric = record.path.includes("paid_free") ? "clickRate" : "costRate";
          structureRows.push({
            endpoint: record.path,
            objectRole: identity.role,
            objectKey: identity.key,
            objectLabel: identity.label,
            ...period,
            channelName: row.channelName || "",
            metric,
            value: row[metric] ?? null,
          });
        }
      }
    }

    const coverage = new Map();
    for (const record of records) {
      if (record.method !== "POST" || record.path !== "/api/dmp/v2/analysis/coverage") continue;
      const audience = audienceContext(requestOf(record) || {});
      const result = dataOf(record.body)?.result;
      if (audience.shopId) coverage.set(audience.shopId, result?.coverage ?? result?.hintDataSecurityInfo ?? "");
    }
    for (const record of records) {
      if (record.method !== "POST" || record.path !== "/api/dmp/insight/tag/chart" || !record.body) continue;
      const request = requestOf(record) || {};
      const audience = audienceContext(request);
      if (!audience.shopId) continue;
      const identity = registry.identityForShop(audience.shopId);
      for (const row of dataOf(record.body)?.result?.chartDataFull || []) {
        portraitRows.push({
          objectRole: identity.role,
          objectKey: identity.key,
          objectLabel: identity.label,
          shopId: audience.shopId,
          behavior: audience.behavior,
          audiencePeriod: audience.recentDays ? `最近${audience.recentDays}天` : audience.dateRange,
          coverage: coverage.get(audience.shopId) || "",
          tagName: row.tagName || "",
          optionName: row.optionName || "",
          optionNum: Number(row.optionNum ?? 0),
          rate: Number(row.rate ?? 0),
        });
      }
    }

    const timestamps = records.map((record) => record.capturedAt).filter(Boolean).sort();
    const endpointOverview = unique(records.map((record) => record.path)).map((endpoint) => ({ endpoint }));
    return {
      schemaVersion: 1,
      captureMetadata: metadata,
      objectMappings: registry.mappings,
      endpointOverview,
      parsedRecords: records,
      metricRows: dedupeRows(metricRows),
      structureRows: dedupeRows(structureRows),
      portraitRows: dedupeRows(portraitRows),
      summary: {
        capturedRecords: records.length,
        truncatedRecords: records.filter((record) => record.truncated).length,
        non200Records: records.filter((record) => record.status != null && Number(record.status) !== 200).length,
        captureRange: { first: timestamps[0] || null, last: timestamps.at(-1) || null },
        analysisPeriods: unique(metricRows.map((row) => row.analysisPeriod)).sort(),
        comparePeriods: unique(metricRows.map((row) => row.comparePeriod)).sort(),
      },
    };
  }

  function rowIdentity(row = {}) {
    const role = row.entityRole || row.objectRole || "未映射";
    const key = String(row.entityKey ?? row.objectKey ?? row.shopId ?? role);
    const label = row.entityLabel || row.objectLabel || (role === "主体" ? "本店" : role === "竞品" ? "竞店" : "未映射");
    return { role, key, label };
  }

  function metricEntities(inventory) {
    const output = [];
    const seen = new Set();
    const add = (entity) => {
      if (!entity?.key || seen.has(entity.key) || !["主体", "竞品"].includes(entity.role)) return;
      seen.add(entity.key);
      output.push(entity);
    };
    for (const mapping of inventory.objectMappings || []) {
      if (mapping.idSystem !== "竞争接口对象") continue;
      add({ role: mapping.role, key: String(mapping.identifier), label: mapping.alias || (mapping.role === "主体" ? "本店" : "竞店") });
    }
    for (const row of inventory.metricRows || []) add(rowIdentity(row));
    return output.sort((left, right) => roleOrder(left.role) - roleOrder(right.role));
  }

  function portraitEntities(inventory) {
    const output = [];
    const seen = new Set();
    const add = (entity) => {
      if (!entity?.key || seen.has(entity.key) || !["主体", "竞品"].includes(entity.role)) return;
      seen.add(entity.key);
      output.push(entity);
    };
    for (const mapping of inventory.objectMappings || []) {
      if (mapping.idSystem !== "画像接口店铺ID") continue;
      add({ role: mapping.role, key: String(mapping.identifier), label: mapping.alias || (mapping.role === "主体" ? "本店" : "竞店") });
    }
    for (const row of inventory.portraitRows || []) add(rowIdentity(row));
    return output.sort((left, right) => roleOrder(left.role) - roleOrder(right.role));
  }

  function rowForEntity(rows, entity, entities) {
    const explicit = rows.find((row) => (row.entityKey != null || row.objectKey != null || row.shopId != null) && rowIdentity(row).key === entity.key);
    if (explicit) return explicit;
    const sameRole = entities.filter((candidate) => candidate.role === entity.role);
    return sameRole.length === 1 ? rows.find((row) => rowIdentity(row).role === entity.role) : null;
  }

  function entityForRow(row, entities) {
    const identity = rowIdentity(row);
    const explicit = entities.find((entity) => entity.key === identity.key);
    if (explicit) return explicit;
    const sameRole = entities.filter((entity) => entity.role === identity.role);
    return sameRole.length === 1 ? sameRole[0] : identity;
  }

  function overallRows(inventory, entities = metricEntities(inventory)) {
    const output = [];
    for (const days of [7, 30]) {
      for (const spec of BASE_SPECS) {
        const rowsFor = (metric, endpoint) => inventory.metricRows.filter((row) => row.analysisDays === days && row.channelLevel === "整体" && row.metric === metric && row.endpoint === endpoint);
        let matching = spec.metric ? rowsFor(spec.metric, spec.endpoint) : [];
        const contextRows = spec.id === "adSpend" ? rowsFor("gmv1d", "/api/competition/analysis/base/indicator") : matching;
        const valuesByEntity = {};
        for (const entity of entities) {
          const candidate = rowForEntity(matching, entity, entities);
          valuesByEntity[entity.key] = {
            current: normalizeValue(candidate?.currentValue),
            compare: normalizeValue(candidate?.compareValue),
            growth: normalizeValue(candidate?.growthRate),
          };
        }
        if (spec.id === "totalGmv") {
          const orderRows = rowsFor("alipayCnt", "/api/competition/analysis/base/shop/indicator");
          const aovRows = rowsFor("averageOrderValue", "/api/competition/analysis/base/shop/indicator");
          for (const entity of entities) {
            const orders = rowForEntity(orderRows, entity, entities);
            const aov = rowForEntity(aovRows, entity, entities);
            const current = isNumber(orders?.currentValue) && isNumber(aov?.currentValue) ? orders.currentValue * aov.currentValue : "—";
            const compare = isNumber(orders?.compareValue) && isNumber(aov?.compareValue) ? orders.compareValue * aov.compareValue : "—";
            valuesByEntity[entity.key] = { current, compare, growth: growth(current, compare) };
          }
        }
        const context = contextRows.find((row) => row.entityRole === "主体") || contextRows.find((row) => row.entityRole === "竞品") || {};
        if (spec.id === "adSpend") {
          const gmv = output.find((row) => row.days === days && row.id === "gmv1d");
          const roi = output.find((row) => row.days === days && row.id === "roi1d");
          for (const entity of entities) {
            const current = ratio(gmv?.valuesByEntity?.[entity.key]?.current, roi?.valuesByEntity?.[entity.key]?.current);
            const compare = ratio(gmv?.valuesByEntity?.[entity.key]?.compare, roi?.valuesByEntity?.[entity.key]?.compare);
            valuesByEntity[entity.key] = { current, compare, growth: growth(current, compare) };
          }
        }
        const subjectEntity = entities.find((entity) => entity.role === "主体");
        const competitorEntities = entities.filter((entity) => entity.role === "竞品");
        const subjectValues = valuesByEntity[subjectEntity?.key] || { current: "—", compare: "—", growth: "—" };
        const firstCompetitor = valuesByEntity[competitorEntities[0]?.key] || { current: "—", compare: "—", growth: "—" };
        output.push({
          key: `${days}|${spec.id}`,
          id: spec.id,
          days,
          label: spec.label,
          format: spec.format,
          analysisPeriod: context.analysisPeriod || inventory.summary?.analysisPeriods?.find((value) => value.includes(`（${days}天）`)) || `${days}天`,
          comparePeriod: context.comparePeriod || "—",
          valuesByEntity,
          subjectCurrent: subjectValues.current,
          subjectCompare: subjectValues.compare,
          subjectGrowth: subjectValues.growth,
          competitorCurrent: firstCompetitor.current,
          competitorCompare: firstCompetitor.compare,
          competitorGrowth: firstCompetitor.growth,
        });
      }
    }
    return output;
  }

  function excelColumn(index) {
    let value = Number(index) + 1;
    let output = "";
    while (value > 0) {
      output = String.fromCharCode(65 + ((value - 1) % 26)) + output;
      value = Math.floor((value - 1) / 26);
    }
    return output;
  }

  function buildStructureTable(inventory, entities = metricEntities(inventory)) {
    const map = new Map();
    for (const row of inventory.structureRows || []) {
      if (![7, 30].includes(row.analysisDays)) continue;
      const type = row.endpoint?.includes("paid_free") || row.module?.includes("付费免费") ? "点击结构" : "投放成本结构";
      const key = [row.analysisDays, row.analysisPeriod, type, row.channelName].join("|");
      if (!map.has(key)) map.set(key, { days: row.analysisDays, analysisPeriod: row.analysisPeriod, type, channel: row.channelName, sourceRows: [] });
      map.get(key).sourceRows.push(row);
    }
    const rows = [...map.values()].sort((a, b) => a.days - b.days || a.type.localeCompare(b.type, "zh-CN") || STRUCTURE_ORDER.indexOf(a.channel) - STRUCTURE_ORDER.indexOf(b.channel));
    const subject = entities.find((entity) => entity.role === "主体");
    const competitors = entities.filter((entity) => entity.role === "竞品");
    const matrix = rows.map((row) => {
      const values = new Map(entities.map((entity) => [entity.key, normalizeValue(rowForEntity(row.sourceRows, entity, entities)?.value)]));
      const subjectValue = values.get(subject?.key);
      return [
        row.analysisPeriod,
        row.days,
        row.type,
        row.channel,
        ...entities.map((entity) => values.get(entity.key)),
        ...competitors.map((entity) => isNumber(subjectValue) && isNumber(values.get(entity.key)) ? subjectValue - values.get(entity.key) : "—"),
      ];
    });
    const formulas = {};
    rows.forEach((row, rowIndex) => {
      const subjectIndex = entities.findIndex((entity) => entity.role === "主体");
      competitors.forEach((competitor, competitorIndex) => {
        const competitorEntityIndex = entities.findIndex((entity) => entity.key === competitor.key);
        const differenceColumn = 4 + entities.length + competitorIndex;
        if (isNumber(matrix[rowIndex][4 + subjectIndex]) && isNumber(matrix[rowIndex][4 + competitorEntityIndex])) {
          formulas[`${rowIndex},${differenceColumn}`] = `${excelColumn(4 + subjectIndex)}${rowIndex + 5}-${excelColumn(4 + competitorEntityIndex)}${rowIndex + 5}`;
        }
      });
    });
    return {
      name: "流量投放结构",
      subtitle: "点击结构与投放成本结构分开排列；占比均为接口精确值。",
      columns: ["分析周期", "天数", "结构类型", "渠道", ...entities.map((entity) => `${entity.label}占比`), ...competitors.map((entity) => `本店-${entity.label}`)],
      widths: [31, 8, 15, 16, ...entities.map(() => 14), ...competitors.map(() => 14)],
      freezeColumns: 4,
      rows: matrix,
      columnRoles: ["", "", "", "", ...entities.map((entity) => entity.role === "主体" ? "subject" : "competitor"), ...competitors.map(() => "difference")],
      formulas,
    };
  }

  function orderIndex(order, value) { const index = order.indexOf(value); return index < 0 ? order.length : index; }

  function channelRowsFor(inventory, level, entities = metricEntities(inventory)) {
    const selected = new Set(SELECTED_METRICS.map(([metric]) => metric));
    const source = (inventory.metricRows || []).filter((row) => row.endpoint === "/api/competition/analysis/flow/indicator" && row.channelLevel === level && selected.has(row.metric));
    const groups = new Map();
    for (const row of source) {
      const entity = entityForRow(row, entities);
      const key = [row.analysisDays, row.analysisPeriod, row.attributionScale, row.attributionScaleLabel, row.firstChannelName, row.secondChannelName, entity.key].join("|");
      if (!groups.has(key)) groups.set(key, {
        analysisPeriod: row.analysisPeriod,
        days: row.analysisDays,
        attributionScale: row.attributionScale,
        attribution: row.attributionScaleLabel || ATTRIBUTION_SCALES[row.attributionScale] || "",
        first: row.firstChannelName,
        second: row.secondChannelName,
        role: entity.role,
        entityKey: entity.key,
        entityLabel: entity.label,
        metrics: Object.fromEntries(SELECTED_METRICS.map(([metric]) => [metric, "—"])),
      });
      groups.get(key).metrics[row.metric] = normalizeValue(row.currentValue);
    }
    return [...groups.values()];
  }

  function buildChannelTable(inventory, entities = metricEntities(inventory)) {
    const groups = new Map();
    function getGroup(row) {
      const key = [row.days, row.analysisPeriod, row.attributionScale, row.attribution, row.first].join("|");
      if (!groups.has(key)) groups.set(key, { analysisPeriod: row.analysisPeriod, days: row.days, attributionScale: row.attributionScale, attribution: row.attribution, first: row.first, parents: new Map(), children: new Map() });
      return groups.get(key);
    }
    for (const row of channelRowsFor(inventory, "一级渠道", entities)) getGroup(row).parents.set(row.entityKey, row);
    for (const row of channelRowsFor(inventory, "二级渠道", entities)) {
      const group = getGroup(row);
      if (!group.children.has(row.second)) group.children.set(row.second, new Map());
      group.children.get(row.second).set(row.entityKey, row);
    }
    const sorted = [...groups.values()].sort((a, b) => a.days - b.days || Number(a.attributionScale) - Number(b.attributionScale) || orderIndex(FIRST_ORDER, a.first) - orderIndex(FIRST_ORDER, b.first) || a.first.localeCompare(b.first, "zh-CN"));
    const rows = [];
    const rowKinds = [];
    const rowRoles = [];
    for (const group of sorted) {
      for (const entity of entities) {
        const parent = group.parents.get(entity.key);
        if (parent) {
          rows.push([parent.analysisPeriod, parent.days, parent.attribution, `▾ ${parent.first}`, parent.entityLabel, ...SELECTED_METRICS.map(([metric]) => parent.metrics[metric])]);
          rowKinds.push("parent");
          rowRoles.push(parent.role);
        }
      }
      const children = [...group.children.keys()].sort((a, b) => orderIndex(SECOND_ORDER, a) - orderIndex(SECOND_ORDER, b) || a.localeCompare(b, "zh-CN"));
      for (const childName of children) {
        for (const entity of entities) {
          const child = group.children.get(childName).get(entity.key);
          if (!child) continue;
          rows.push([child.analysisPeriod, child.days, child.attribution, `　　↳ ${childName}`, child.entityLabel, ...SELECTED_METRICS.map(([metric]) => child.metrics[metric])]);
          rowKinds.push("child");
          rowRoles.push(child.role);
        }
      }
    }
    return {
      name: "渠道指标",
      subtitle: "一级渠道为父行，二级渠道在“流量来源”单元格内缩进；九项指标按对象展开。",
      columns: ["分析周期", "天数", "归因范围", "流量来源", "对象", ...SELECTED_METRICS.map(([, label]) => label)],
      widths: [31, 8, 12, 28, 9, 12, 13, 16, 18, 16, 19, 12, 14, 12],
      freezeColumns: 4,
      rows,
      rowKinds,
      rowRoles,
    };
  }

  function buildPortraitTable(inventory, entities = portraitEntities(inventory)) {
    const map = new Map();
    for (const row of inventory.portraitRows || []) {
      if (!PORTRAIT_TAGS.includes(row.tagName)) continue;
      const key = [row.audiencePeriod, row.behavior, row.tagName, row.optionName].join("|");
      if (!map.has(key)) map.set(key, { period: row.audiencePeriod, behavior: row.behavior, tag: row.tagName, option: row.optionName, sourceRows: [] });
      map.get(key).sourceRows.push(row);
    }
    const rows = [...map.values()].sort((a, b) => PORTRAIT_TAGS.indexOf(a.tag) - PORTRAIT_TAGS.indexOf(b.tag) || a.option.localeCompare(b.option, "zh-CN"));
    return {
      name: "人群画像",
      subtitle: "当前口径：店铺浏览人群、最近30天；保留覆盖规模、标签选项人数和占比。",
      columns: ["画像周期", "行为", "标签维度", "标签选项", ...entities.flatMap((entity) => [`${entity.label}人数`, `${entity.label}占比`, `${entity.label}覆盖规模`])],
      widths: [13, 10, 22, 24, ...entities.flatMap(() => [13, 12, 16])],
      freezeColumns: 4,
      rows: rows.map((row) => [
        row.period,
        row.behavior,
        row.tag,
        row.option,
        ...entities.flatMap((entity) => {
          const source = rowForEntity(row.sourceRows, entity, entities);
          return [normalizeValue(source?.optionNum), normalizeValue(source?.rate), normalizeValue(source?.coverage)];
        }),
      ]),
      columnRoles: ["", "", "", "", ...entities.flatMap((entity) => Array(3).fill(entity.role === "主体" ? "subject" : "competitor"))],
    };
  }

  function endpointSet(inventory) {
    const businessRecords = (inventory.parsedRecords || []).filter((row) => String(row.method || "").toUpperCase() !== "OPTIONS");
    const records = businessRecords.length ? businessRecords : (inventory.endpointOverview || []);
    return new Set(records.map((row) => canonicalPath(row.endpoint || row.path)).filter(Boolean));
  }

  function evaluateQuality(inventory, channelTable, portraitTable) {
    const endpoints = endpointSet(inventory);
    const missingEndpoints = REQUIRED_ENDPOINTS.filter((endpoint) => !endpoints.has(endpoint));
    const issues = missingEndpoints.map((endpoint) => `缺少接口 ${endpoint}`);
    const requestedCompetitorNames = unique(Array.isArray(inventory.captureMetadata?.session?.competitorNames)
      ? inventory.captureMetadata.session.competitorNames
      : String(inventory.captureMetadata?.session?.competitorName || "").split(/[,，、;；\n]+/).map((name) => name.trim()));
    const expectedCompetitorCount = requestedCompetitorNames.length;
    const recordedPortraitShopIds = unique((Array.isArray(inventory.captureMetadata?.session?.portraitCompetitorShopIds)
      ? inventory.captureMetadata.session.portraitCompetitorShopIds
      : []).map(singleShopId).filter(Boolean));
    const mappedPortraitShopIds = unique((inventory.objectMappings || [])
      .filter((row) => row.idSystem === "画像接口店铺ID" && row.role === "竞品")
      .map((row) => singleShopId(row.identifier))
      .filter(Boolean));
    const expectedPortraitShopIds = recordedPortraitShopIds.length ? recordedPortraitShopIds : mappedPortraitShopIds;
    if (expectedCompetitorCount && expectedPortraitShopIds.length < expectedCompetitorCount) {
      issues.push(`画像竞店ID仅记录 ${expectedPortraitShopIds.length}/${expectedCompetitorCount} 家，需逐店输入单一店铺ID`);
    }
    for (const days of [7, 30]) {
      if (!(inventory.metricRows || []).some((row) => row.analysisDays === days && row.channelLevel === "整体")) issues.push(`缺少近${days}天基础指标`);
      if (!(inventory.structureRows || []).some((row) => row.analysisDays === days)) issues.push(`缺少近${days}天流量/投放结构`);
    }
    const flowRows = (inventory.metricRows || []).filter((row) => row.endpoint === "/api/competition/analysis/flow/indicator");
    const combos = new Set(flowRows.map((row) => `${row.analysisDays}|${row.attributionScale}`));
    for (const [days, scale] of [[7, 2], [30, 1], [30, 2]]) {
      if (!combos.has(`${days}|${scale}`)) {
        issues.push(`缺少近${days}天${ATTRIBUTION_SCALES[scale]}渠道指标`);
        continue;
      }
      if (expectedCompetitorCount) {
        const competitorKeys = new Set(flowRows
          .filter((row) => row.analysisDays === days && Number(row.attributionScale) === scale && row.entityRole === "竞品")
          .map((row) => row.entityKey || row.entityLabel || row.entityRole));
        if (competitorKeys.size < expectedCompetitorCount) issues.push(`近${days}天${ATTRIBUTION_SCALES[scale]}仅返回 ${competitorKeys.size}/${expectedCompetitorCount} 家竞店渠道指标`);
      }
    }
    for (const tag of PORTRAIT_TAGS) {
      const roles = new Set((inventory.portraitRows || []).filter((row) => row.tagName === tag).map((row) => row.objectRole));
      if (!roles.has("主体") || !roles.has("竞品")) issues.push(`画像“${tag}”主体/竞品未配齐`);
      if (expectedCompetitorCount) {
        const competitorKeys = new Set((inventory.portraitRows || [])
          .filter((row) => row.tagName === tag && row.objectRole === "竞品")
          .map((row) => singleShopId(row.shopId || row.objectKey))
          .filter(Boolean));
        const returnedCount = expectedPortraitShopIds.length
          ? expectedPortraitShopIds.filter((shopId) => competitorKeys.has(shopId)).length
          : competitorKeys.size;
        if (returnedCount < expectedCompetitorCount) issues.push(`画像“${tag}”仅返回 ${returnedCount}/${expectedCompetitorCount} 家竞店`);
      }
    }
    if (!channelTable.rows.length) issues.push("渠道指标为空");
    const channelRoles = new Set(channelTable.rowRoles || []);
    if (!channelRoles.has("主体") || !channelRoles.has("竞品")) issues.push("渠道指标主体/竞品未配齐");
    if (!portraitTable.rows.length) issues.push("人群画像为空");
    const requiredRecords = (inventory.parsedRecords || []).filter((row) => String(row.method || "").toUpperCase() !== "OPTIONS" && REQUIRED_ENDPOINTS.includes(canonicalPath(row.endpoint || row.path)));
    const competitionRecords = requiredRecords.filter((row) => canonicalPath(row.endpoint || row.path).startsWith("/api/competition/analysis/"));
    const comparativeRecords = competitionRecords.filter((row) => !STRUCTURE_ENDPOINTS.has(canonicalPath(row.endpoint || row.path)));
    const selectedCompetitorTokens = unique(comparativeRecords.flatMap((row) => collectSelectedCompetitorTokens(requestOf(row))));
    if (!selectedCompetitorTokens.length) {
      issues.unshift("竞争店铺未选中：核心请求 competitorIds 为空");
    } else if (expectedCompetitorCount && selectedCompetitorTokens.length < expectedCompetitorCount) {
      issues.unshift(`竞争店铺未选全：接口仅带回 ${selectedCompetitorTokens.length}/${expectedCompetitorCount} 家`);
    }
    for (const days of [7, 30]) {
      const exactPeriod = competitionRecords.some((row) => {
        const request = requestOf(row) || {};
        const period = periodContext(request);
        return period.analysisDays === days
          && period.compareDays === days
          && daysInclusive(request.peerEndDate, request.beginDate) === 2;
      });
      if (!exactPeriod) issues.push(`近${days}天分析周期与对比周期未形成连续等长自定义区间`);
    }
    const failed = requiredRecords.filter((row) => row.truncated || row.bodyAvailable === false || (row.status != null && Number(row.status) !== 200));
    if (failed.length) issues.push(`核心接口存在 ${failed.length} 条失败、缺响应或截断记录`);
    const blockingIssues = unique(issues);
    return {
      complete: blockingIssues.length === 0,
      exportAllowed: blockingIssues.length === 0,
      blockingIssues,
      missingEndpoints,
      observedEndpoints: REQUIRED_ENDPOINTS.length - missingEndpoints.length,
      expectedEndpoints: REQUIRED_ENDPOINTS.length,
      channelRows: channelTable.rows.length,
      portraitRows: portraitTable.rows.length,
    };
  }

  function buildReportFromInventory(inventory, context = {}) {
    const entities = metricEntities(inventory);
    const metrics = overallRows(inventory, entities);
    const rowMap = new Map(metrics.map((row, index) => [row.key, index + 5]));
    const benchmarkFormulas = {};
    for (const days of [7, 30]) {
      const totalGmv = metrics.findIndex((row) => row.key === `${days}|totalGmv`);
      const orders = rowMap.get(`${days}|alipayCnt`);
      const aov = rowMap.get(`${days}|averageOrderValue`);
      if (totalGmv >= 0 && orders && aov) {
        const reportRow = totalGmv + 5;
        benchmarkFormulas[`${totalGmv},3`] = `IFERROR(D${orders}*D${aov},\"\")`;
        benchmarkFormulas[`${totalGmv},4`] = `IFERROR(E${orders}*E${aov},\"\")`;
        benchmarkFormulas[`${totalGmv},5`] = `IFERROR(D${reportRow}/E${reportRow}-1,\"\")`;
        benchmarkFormulas[`${totalGmv},6`] = `IFERROR(G${orders}*G${aov},\"\")`;
        benchmarkFormulas[`${totalGmv},7`] = `IFERROR(H${orders}*H${aov},\"\")`;
        benchmarkFormulas[`${totalGmv},8`] = `IFERROR(G${reportRow}/H${reportRow}-1,\"\")`;
      }
      const spend = metrics.findIndex((row) => row.key === `${days}|adSpend`);
      const gmv = rowMap.get(`${days}|gmv1d`);
      const roi = rowMap.get(`${days}|roi1d`);
      if (spend >= 0) {
        benchmarkFormulas[`${spend},3`] = `IFERROR(D${gmv}/D${roi},\"\")`;
        benchmarkFormulas[`${spend},4`] = `IFERROR(E${gmv}/E${roi},\"\")`;
        benchmarkFormulas[`${spend},5`] = `IFERROR(D${spend + 5}/E${spend + 5}-1,\"\")`;
        benchmarkFormulas[`${spend},6`] = `IFERROR(G${gmv}/G${roi},\"\")`;
        benchmarkFormulas[`${spend},7`] = `IFERROR(H${gmv}/H${roi},\"\")`;
        benchmarkFormulas[`${spend},8`] = `IFERROR(G${spend + 5}/H${spend + 5}-1,\"\")`;
      }
    }
    for (const days of [7, 30]) {
      const totalGmv = metrics.findIndex((row) => row.key === `${days}|totalGmv`);
      const spend = metrics.findIndex((row) => row.key === `${days}|adSpend`);
      const orders = rowMap.get(`${days}|alipayCnt`);
      const aov = rowMap.get(`${days}|averageOrderValue`);
      const gmv = rowMap.get(`${days}|gmv1d`);
      const roi = rowMap.get(`${days}|roi1d`);
      entities.forEach((entity, entityIndex) => {
        const currentColumn = 3 + entityIndex * 3;
        const compareColumn = currentColumn + 1;
        const growthColumn = currentColumn + 2;
        if (totalGmv >= 0 && orders && aov) {
          const reportRow = totalGmv + 5;
          benchmarkFormulas[`${totalGmv},${currentColumn}`] = `IFERROR(${excelColumn(currentColumn)}${orders}*${excelColumn(currentColumn)}${aov},\"\")`;
          benchmarkFormulas[`${totalGmv},${compareColumn}`] = `IFERROR(${excelColumn(compareColumn)}${orders}*${excelColumn(compareColumn)}${aov},\"\")`;
          benchmarkFormulas[`${totalGmv},${growthColumn}`] = `IFERROR(${excelColumn(currentColumn)}${reportRow}/${excelColumn(compareColumn)}${reportRow}-1,\"\")`;
        }
        if (spend >= 0 && gmv && roi) {
          benchmarkFormulas[`${spend},${currentColumn}`] = `IFERROR(${excelColumn(currentColumn)}${gmv}/${excelColumn(currentColumn)}${roi},\"\")`;
          benchmarkFormulas[`${spend},${compareColumn}`] = `IFERROR(${excelColumn(compareColumn)}${gmv}/${excelColumn(compareColumn)}${roi},\"\")`;
          benchmarkFormulas[`${spend},${growthColumn}`] = `IFERROR(${excelColumn(currentColumn)}${spend + 5}/${excelColumn(compareColumn)}${spend + 5}-1,\"\")`;
        }
      });
    }
    for (const key of Object.keys(benchmarkFormulas)) {
      const [rowIndex, columnIndex] = key.split(",").map(Number);
      const entity = entities[Math.floor((columnIndex - 3) / 3)];
      const field = ["current", "compare", "growth"][(columnIndex - 3) % 3];
      if (!isNumber(metrics[rowIndex]?.valuesByEntity?.[entity?.key]?.[field])) delete benchmarkFormulas[key];
    }
    const benchmark = {
      name: "对标总表",
      subtitle: "仅保留已圈选经营指标；本店保持精确值，各竞店保持接口脱敏区间，不对区间取中点。",
      columns: ["分析周期", "对比周期", "对标指标", ...entities.flatMap((entity) => [`${entity.label}当前值`, `${entity.label}对比期值`, `${entity.label}变化率`])],
      widths: [31, 31, 21, ...entities.flatMap(() => [16, 16, 13])],
      freezeColumns: 2,
      rows: metrics.map((row) => [row.analysisPeriod, row.comparePeriod, row.label, ...entities.flatMap((entity) => {
        const values = row.valuesByEntity?.[entity.key] || {};
        return [normalizeValue(values.current), normalizeValue(values.compare), normalizeValue(values.growth)];
      })]),
      rowKeys: metrics.map((row) => row.key),
      rowFormats: metrics.map((row) => row.format),
      columnRoles: ["", "", "", ...entities.flatMap((entity) => Array(3).fill(entity.role === "主体" ? "subject" : "competitor"))],
      growthColumns: entities.map((entity, index) => 3 + index * 3 + 2),
      formulas: benchmarkFormulas,
    };
    const subjectId = inventory.objectMappings?.find((row) => row.role === "主体" && /店铺ID/.test(row.idSystem))?.identifier || "本店";
    const competitorMappings = (inventory.objectMappings || []).filter((row) => row.role === "竞品" && /店铺ID/.test(row.idSystem));
    const competitorIds = competitorMappings.map((row) => row.identifier);
    const competitorId = competitorIds[0] || "竞店";
    const competitorLabels = entities.filter((entity) => entity.role === "竞品").map((entity) => entity.label);
    const primaryCompetitorLabel = competitorLabels[0] || "竞店";
    const overviewEntities = entities.map((entity, index) => ({
      key: entity.key,
      role: entity.role,
      label: entity.role === "主体" ? "本店" : entity.label || `竞店${index + 1}`,
    }));
    const overviewSubject = overviewEntities.find((entity) => entity.role === "主体");
    const captureRange = inventory.summary?.captureRange || {};
    const formatCapture = (value) => value ? String(value).replace("T", " ").replace(/\.\d{3}Z$/, "Z") : "";
    const overviewMetrics = ["alipayCnt", "shopClick", "alipayConversion", "roi1d"];
    const extraMetrics = ["alipayCnt1d", "gmv1d", "adSpend", "clickCost", "buyCrowdGmvRate"];
    const overviewPeriods = [7, 30].map((days) => ({
      days,
      title: `近${days}天｜${metrics.find((row) => row.days === days)?.analysisPeriod || ""}`,
      metrics: overviewMetrics.map((id) => {
        const row = metrics.find((candidate) => candidate.key === `${days}|${id}`);
        return { ...row, sourceRow: rowMap.get(`${days}|${id}`) };
      }),
    }));
    const overviewExtras = [7, 30].map((days) => ({
      days,
      metrics: extraMetrics.map((id) => {
        const row = metrics.find((candidate) => candidate.key === `${days}|${id}`);
        return { ...row, sourceRow: rowMap.get(`${days}|${id}`) };
      }),
    }));
    const overview = {
      name: "报告总览",
      subtitle: `对象：本店 ${subjectId} vs ${competitorMappings.map((row, index) => `${row.alias || competitorLabels[index] || `竞店${index + 1}`} ${row.identifier}`).join("、") || `竞店 ${competitorId}`}｜抓取时间：${formatCapture(captureRange.first)}–${formatCapture(captureRange.last)}｜竞店区间不做中点化；完整指标明细见“对标总表”`,
      columns: ["分析周期", "指标", ...overviewEntities.map((entity) => `${entity.label}当前`), "本店变化"],
      widths: [14, 24, ...overviewEntities.map((entity) => entity.role === "主体" ? 15 : 19), 13],
      rows: overviewPeriods.flatMap((period) => period.metrics.map((row) => [
        `近${period.days}天`,
        row.label,
        ...overviewEntities.map((entity) => normalizeValue(row.valuesByEntity?.[entity.key]?.current)),
        normalizeValue(row.valuesByEntity?.[overviewSubject?.key]?.growth),
      ])),
      layout: "overview",
      primaryCompetitorLabel,
      overviewEntities,
      overviewPeriods,
      overviewExtras,
    };
    const structure = buildStructureTable(inventory, entities);
    const channel = buildChannelTable(inventory, entities);
    const portrait = buildPortraitTable(inventory, portraitEntities(inventory));
    const quality = evaluateQuality(inventory, channel, portrait);
    return {
      version: 1,
      reportType: "competition-situation",
      generatedAt: new Date().toISOString(),
      subjectId,
      competitorId,
      competitorIds,
      source: context,
      quality,
      tables: [overview, benchmark, structure, channel, portrait],
    };
  }

  function buildReport(records, context = {}) {
    return buildReportFromInventory(inventoryFromRecords(records, context), context);
  }

  function canonicalCell(value, semantic = "", format = "") {
    if (value === null || value === undefined || value === "" || value === "—") return "";
    if (typeof value !== "number" || !Number.isFinite(value)) return String(value);
    const semanticText = String(semantic);
    const isDerivedRate = /变化|变动|相对|环比|同比|差异|提升|下降/.test(semanticText) && !/排名变化/.test(semanticText);
    const isMultiple = /投入产出比|投产比|ROI|ROAS/i.test(semanticText);
    if (isDerivedRate || format === "percent" || (!format && !isMultiple && /比|率|变化|转化|CTR|贡献/i.test(semanticText))) {
      return `${(value * 100).toFixed(2)}%`;
    }
    if (format === "integer" || /笔数|点击量|访客数|浏览量|人数/i.test(String(semantic))) return String(Math.round(value));
    return Number.isInteger(value) ? String(value) : value.toFixed(2);
  }

  function toCanonicalReport(report) {
    const competitorIds = [...new Set((report?.competitorIds || [report?.competitorId])
      .map((value) => String(value || "").trim())
      .filter((value) => /^\d{6,20}$/.test(value)))].slice(0, 3);
    return {
      schema_version: "3.0",
      report_type: "competition",
      title: "达摩盘竞争态势分析报告｜少壮AI自动化",
      item_id: String(report?.subjectId || ""),
      competitor_ids: competitorIds,
      period: (report?.tables?.find((table) => table.name === "报告总览")?.overviewPeriods || [])
        .map((period) => period.title)
        .filter(Boolean)
        .join(" + ") || "近7天 + 近30天",
      tables: (report?.tables || []).map((table) => ({
        name: String(table?.name || ""),
        columns: (table?.columns || []).map(String),
        rows: (table?.rows || []).map((row, rowIndex) => ({
          cells: (Array.isArray(row) ? row : Object.values(row || {})).map((value, columnIndex) => canonicalCell(
            value,
            `${table?.columns?.[columnIndex] || ""} ${row?.[1] || ""}`,
            table?.rowFormats?.[rowIndex] || ""
          ))
        }))
      }))
    };
  }

  function validateCanonicalReport(report) {
    if (!report || report.schema_version !== "3.0" || report.report_type !== "competition" || !/^\d{6,20}$/.test(String(report.item_id || ""))) {
      return { ok: false, error: "竞争态势在线报告结构不完整" };
    }
    const competitorIds = Array.isArray(report.competitor_ids) ? report.competitor_ids : [];
    if (competitorIds.length < 1 || competitorIds.length > 3 || competitorIds.some((value) => !/^\d{6,20}$/.test(String(value)))) {
      return { ok: false, error: "竞争态势在线报告缺少有效竞店 ID" };
    }
    const names = (report.tables || []).map((table) => table.name);
    if (JSON.stringify(names) !== JSON.stringify(REQUIRED_TABLES)) return { ok: false, error: `在线报告缺少业务表：${names.join("、")}` };
    for (const table of report.tables) {
      if (!Array.isArray(table.columns) || !Array.isArray(table.rows) || table.rows.some((row) => !Array.isArray(row.cells) || row.cells.length !== table.columns.length)) {
        return { ok: false, error: `${table.name} 行列不一致` };
      }
    }
    return { ok: true };
  }

  return {
    REQUIRED_ENDPOINTS,
    REQUIRED_TABLES,
    SELECTED_METRICS,
    PORTRAIT_TAGS,
    buildReport,
    buildReportFromInventory,
    inventoryFromRecords,
    normalizeRecord,
    toCanonicalReport,
    validateCanonicalReport,
  };
});
