(function initCompetitionAutomationCore(root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.DmpCompetitionAutomationCore = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function createCompetitionAutomationCore() {
  "use strict";

  const DAY_MS = 24 * 60 * 60 * 1000;
  const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;
  const PORTRAIT_TAGS = Object.freeze(["用户性别", "用户年龄", "月均消费频次", "消费能力等级", "城市等级", "大快消策略人群（老）"]);

  function parseJsonLike(value, depth = 0) {
    if (value == null || depth > 4) return value == null ? null : value;
    if (typeof value === "object") return value;
    if (typeof value !== "string") return null;
    const text = value.trim();
    if (!text) return null;
    try {
      const parsed = JSON.parse(text);
      return typeof parsed === "string" ? parseJsonLike(parsed, depth + 1) : parsed;
    } catch {}
    if (!text.includes("=")) return null;
    try {
      const output = {};
      for (const [key, rawValue] of new URLSearchParams(text)) {
        const child = parseJsonLike(rawValue, depth + 1);
        const normalized = child == null ? rawValue : child;
        if (!(key in output)) output[key] = normalized;
        else if (Array.isArray(output[key])) output[key].push(normalized);
        else output[key] = [output[key], normalized];
      }
      return Object.keys(output).length ? output : null;
    } catch { return null; }
  }

  function requestOfRecord(record) {
    const source = record?.requestBody ?? record?.request ?? record?.postData ?? record?.request?.postData ?? null;
    const parsed = parseJsonLike(source);
    if (!parsed || typeof parsed !== "object") return {};
    if (parsed.data && typeof parsed.data === "object" && !Array.isArray(parsed.data)) {
      const data = parsed.data;
      if (data.beginDate || data.endDate || data.peerBeginDate || data.peerEndDate || data.competitorIds) return data;
    }
    return parsed;
  }

  function canonicalPath(record) {
    const raw = record?.canonicalPath || record?.pathname || record?.path || record?.endpoint || record?.url || record?.requestUrl || "";
    let pathname = String(raw);
    try { pathname = new URL(pathname).pathname; } catch { pathname = pathname.split("?")[0]; }
    return pathname.replace(/^\/api_2\//, "/api/").replace(/\.json$/, "").replace(/\/+$/, "");
  }

  function isCompetitionAnalysisRecord(record) {
    return canonicalPath(record).startsWith("/api/competition/analysis/");
  }

  function parseIsoDate(value) {
    const text = String(value || "");
    if (!ISO_DATE.test(text)) return null;
    const [year, month, day] = text.split("-").map(Number);
    const date = new Date(year, month - 1, day, 12, 0, 0, 0);
    return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day ? date : null;
  }

  function formatIsoDate(value) {
    const date = value instanceof Date ? value : parseIsoDate(value);
    if (!date || Number.isNaN(date.getTime())) return "";
    const pad = (part) => String(part).padStart(2, "0");
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
  }

  function addDays(value, offset) {
    const date = value instanceof Date ? new Date(value) : parseIsoDate(value);
    if (!date || Number.isNaN(date.getTime())) return "";
    date.setDate(date.getDate() + Number(offset || 0));
    return formatIsoDate(date);
  }

  function daysInclusive(start, end) {
    const first = parseIsoDate(start);
    const last = parseIsoDate(end);
    if (!first || !last || last < first) return null;
    return Math.round((last - first) / DAY_MS) + 1;
  }

  function customPeriod(days, endDate) {
    const length = Number(days);
    const analysisEnd = formatIsoDate(endDate);
    if (!Number.isInteger(length) || length < 1 || !analysisEnd) return null;
    const analysisStart = addDays(analysisEnd, 1 - length);
    const compareEnd = addDays(analysisStart, -1);
    const compareStart = addDays(compareEnd, 1 - length);
    return {
      days: length,
      beginDate: analysisStart,
      endDate: analysisEnd,
      peerBeginDate: compareStart,
      peerEndDate: compareEnd,
    };
  }

  function yesterday(now = new Date()) {
    const date = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 12, 0, 0, 0);
    date.setDate(date.getDate() - 1);
    return formatIsoDate(date);
  }

  function parseCompetitorNames(value) {
    return [...new Set(String(value || "")
      .split(/[,，、;；\n]+/)
      .map((name) => name.trim())
      .filter(Boolean))];
  }

  function parseShopIds(value) {
    const output = [];
    const visit = (node) => {
      if (Array.isArray(node)) return node.forEach(visit);
      String(node ?? "").split(/[,，、;；\s]+/).forEach((part) => {
        const shopId = part.trim();
        if (/^\d+$/.test(shopId) && !output.includes(shopId)) output.push(shopId);
      });
    };
    visit(value);
    return output;
  }

  function selectionRows(value) {
    const output = [];
    function visit(node) {
      if (Array.isArray(node)) return node.forEach(visit);
      if (!node || typeof node !== "object") return;
      if (Array.isArray(node.selects)) output.push(...node.selects);
      Object.values(node).forEach(visit);
    }
    visit(value);
    return output;
  }

  function audienceShopIdFromRequest(request = {}) {
    const entry = selectionRows(request.selectTagOptionSetDTO ?? request)
      .find((row) => Number(row?.optionGroupId) === 328146);
    const shopId = String(entry?.values ?? "").trim();
    return /^\d+$/.test(shopId) ? shopId : "";
  }

  function responseOfRecord(record) {
    return parseJsonLike(record?.body ?? record?.responseBody ?? record?.response?.body ?? record?.response) || {};
  }

  function portraitTagNames(record) {
    const body = responseOfRecord(record);
    const rows = body?.data?.result?.chartDataFull ?? body?.result?.chartDataFull ?? [];
    return [...new Set((Array.isArray(rows) ? rows : []).map((row) => String(row?.tagName || "").trim()).filter(Boolean))];
  }

  function portraitCompareShopIds(records = []) {
    const output = [];
    for (const record of records) {
      if (canonicalPath(record) !== "/api/dmp/insight/targets") continue;
      const request = requestOfRecord(record);
      for (const shopId of parseShopIds(request?.contextParams?.compareShopId)) {
        if (!output.includes(shopId)) output.push(shopId);
      }
    }
    return output;
  }

  function portraitCaptureStatus(records = [], shopId, options = {}) {
    const wantedShopId = String(shopId || "").trim();
    const startIndex = Math.max(0, Number(options.startIndex || 0));
    const requiredTags = Array.isArray(options.requiredTags) && options.requiredTags.length ? options.requiredTags : PORTRAIT_TAGS;
    const recent = records.slice(startIndex).filter(isUsableBusinessRecord);
    const targetLoaded = recent.some((record) => {
      if (canonicalPath(record) !== "/api/dmp/insight/targets") return false;
      const raw = String(requestOfRecord(record)?.contextParams?.compareShopId ?? "").trim();
      return raw === wantedShopId;
    });
    const coverageLoaded = recent.some((record) => (
      canonicalPath(record) === "/api/dmp/v2/analysis/coverage"
      && audienceShopIdFromRequest(requestOfRecord(record)) === wantedShopId
    ));
    const chartRecords = recent.filter((record) => (
      canonicalPath(record) === "/api/dmp/insight/tag/chart"
      && audienceShopIdFromRequest(requestOfRecord(record)) === wantedShopId
    ));
    const tags = [...new Set(chartRecords.flatMap(portraitTagNames))];
    const missingTags = requiredTags.filter((tag) => !tags.includes(tag));
    return {
      shopId: wantedShopId,
      targetLoaded,
      coverageLoaded,
      chartRecords: chartRecords.length,
      tags,
      missingTags,
      complete: Boolean(wantedShopId && coverageLoaded && missingTags.length === 0),
    };
  }

  function latestBusinessEndDate(records = [], fallback = yesterday()) {
    const values = [];
    for (const record of records) {
      if (!isCompetitionAnalysisRecord(record)) continue;
      const request = requestOfRecord(record);
      for (const value of [request.endDate, request.peerEndDate]) if (parseIsoDate(value)) values.push(value);
    }
    const analysisEnds = records
      .filter(isCompetitionAnalysisRecord)
      .map((record) => requestOfRecord(record).endDate)
      .filter((value) => parseIsoDate(value));
    const latestDayValues = records
      .filter((record) => canonicalPath(record) === "/api/latestDay")
      .map((record) => parseJsonLike(record?.body ?? record?.responseBody ?? record?.response?.body ?? record?.response))
      .map((body) => body?.data ?? body?.latestDay ?? "")
      .filter((value) => parseIsoDate(value));
    return [...(analysisEnds.length ? analysisEnds : latestDayValues.length ? latestDayValues : values)].sort().at(-1)
      || formatIsoDate(fallback)
      || yesterday();
  }

  function competitorTokens(request) {
    const output = [];
    function visit(node, key = "") {
      if (Array.isArray(node)) {
        if (key === "competitorIds") node.forEach((item) => { if (String(item || "").trim()) output.push(String(item)); });
        else node.forEach((item) => visit(item, key));
        return;
      }
      if (!node || typeof node !== "object") {
        if ((key === "competitorId" || key === "competitor_id") && String(node || "").trim()) output.push(String(node));
        return;
      }
      for (const [childKey, child] of Object.entries(node)) visit(child, childKey);
    }
    visit(request);
    return [...new Set(output)];
  }

  function matchesPeriod(request, expected, requireCompetitor = true) {
    if (!request || !expected) return false;
    const sameDates = ["beginDate", "endDate", "peerBeginDate", "peerEndDate"]
      .every((key) => String(request[key] || "") === String(expected[key] || ""));
    return sameDates && (!requireCompetitor || competitorTokens(request).length > 0);
  }

  function matchingRecords(records = [], expected, options = {}) {
    const startIndex = Math.max(0, Number(options.startIndex || 0));
    const minimumCompetitors = Math.max(0, Number(options.minimumCompetitors || 0));
    return records.slice(startIndex).filter((record) => (
      isCompetitionAnalysisRecord(record)
      && matchesPeriod(requestOfRecord(record), expected, options.requireCompetitor !== false)
      && (!minimumCompetitors || competitorTokens(requestOfRecord(record)).length >= minimumCompetitors)
      && (options.requireUsable !== true || isUsableBusinessRecord(record))
    ));
  }

  function isUsableBusinessRecord(record) {
    const method = String(record?.method || record?.request?.method || "POST").toUpperCase();
    const status = record?.status ?? record?.response?.status ?? null;
    return method !== "OPTIONS"
      && record?.bodyAvailable !== false
      && !record?.truncated
      && !record?.bodyTruncated
      && (status == null || Number(status) === 200);
  }

  function matchingFlowIndicatorRecords(records = [], expected, attributionScale, options = {}) {
    const startIndex = Math.max(0, Number(options.startIndex || 0));
    const wantedScale = String(attributionScale ?? "");
    const minimumCompetitors = Math.max(0, Number(options.minimumCompetitors || 0));
    return records.slice(startIndex).filter((record) => {
      if (canonicalPath(record) !== "/api/competition/analysis/flow/indicator") return false;
      const request = requestOfRecord(record);
      return matchesPeriod(request, expected, options.requireCompetitor !== false)
        && (!minimumCompetitors || competitorTokens(request).length >= minimumCompetitors)
        && String(request.attributionScale ?? "") === wantedScale
        && (options.requireUsable === false || isUsableBusinessRecord(record));
    });
  }

  function isImmediatelyPrevious(request) {
    const analysisDays = daysInclusive(request?.beginDate, request?.endDate);
    const compareDays = daysInclusive(request?.peerBeginDate, request?.peerEndDate);
    return Boolean(
      analysisDays
      && analysisDays === compareDays
      && addDays(request.peerEndDate, 1) === request.beginDate
    );
  }

  return {
    addDays,
    canonicalPath,
    competitorTokens,
    customPeriod,
    daysInclusive,
    formatIsoDate,
    isCompetitionAnalysisRecord,
    isImmediatelyPrevious,
    isUsableBusinessRecord,
    latestBusinessEndDate,
    matchesPeriod,
    matchingFlowIndicatorRecords,
    matchingRecords,
    parseShopIds,
    parseCompetitorNames,
    parseIsoDate,
    portraitCaptureStatus,
    portraitCompareShopIds,
    portraitTagNames,
    PORTRAIT_TAGS,
    requestOfRecord,
    yesterday,
  };
});
