(function initCompetitionXlsxWriter(root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.DmpCompetitionXlsxWriter = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function createCompetitionXlsxWriter() {
  "use strict";

  const MIME_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
  const XMLNS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
  const RELNS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
  const REQUIRED_TABLES = ["报告总览", "对标总表", "流量投放结构", "渠道指标", "人群画像"];

  const STYLE = Object.freeze({
    DEFAULT: 0,
    TITLE: 1,
    SUBTITLE: 2,
    HEADER: 3,
    TEXT: 4,
    NUMBER: 5,
    PERCENT: 6,
    INTEGER: 7,
    SUBJECT_TEXT: 8,
    SUBJECT_NUMBER: 9,
    SUBJECT_PERCENT: 10,
    SUBJECT_INTEGER: 11,
    COMPETITOR_TEXT: 12,
    COMPETITOR_NUMBER: 13,
    COMPETITOR_PERCENT: 14,
    COMPETITOR_INTEGER: 15,
    PARENT_TEXT: 16,
    PARENT_NUMBER: 17,
    PARENT_PERCENT: 18,
    PARENT_INTEGER: 19,
    CHILD_SOURCE: 20,
    DIFFERENCE_NUMBER: 21,
    DIFFERENCE_PERCENT: 22,
    SECTION: 23,
    OVERVIEW_LABEL: 24,
    OVERVIEW_GROWTH: 25,
    OVERVIEW_NOTE: 26,
  });

  function xmlEscape(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&apos;");
  }

  function columnName(index) {
    let value = index + 1;
    let result = "";
    while (value > 0) {
      const remainder = (value - 1) % 26;
      result = String.fromCharCode(65 + remainder) + result;
      value = Math.floor((value - 1) / 26);
    }
    return result;
  }

  function cellRef(row, column) { return `${columnName(column)}${row}`; }
  function isFiniteNumber(value) { return typeof value === "number" && Number.isFinite(value); }
  function isMissing(value) { return value === null || value === undefined || value === "" || value === "—"; }

  function valueKind(column, rowFormat = "") {
    if (rowFormat === "percent") return "percent";
    if (rowFormat === "integer") return "integer";
    if (rowFormat === "number") return "number";
    const text = String(column || "");
    if (/变化率|占比|转化率|加购率|点击率|流量占比|本店-竞店/.test(text)) return "percent";
    if (/天数|笔数|点击量|人数$/.test(text)) return "integer";
    return "number";
  }

  function roleStyle(kind, role = "") {
    if (role === "subject") {
      if (kind === "percent") return STYLE.SUBJECT_PERCENT;
      if (kind === "integer") return STYLE.SUBJECT_INTEGER;
      return STYLE.SUBJECT_NUMBER;
    }
    if (role === "competitor") {
      if (kind === "percent") return STYLE.COMPETITOR_PERCENT;
      if (kind === "integer") return STYLE.COMPETITOR_INTEGER;
      return STYLE.COMPETITOR_NUMBER;
    }
    if (role === "parent") {
      if (kind === "percent") return STYLE.PARENT_PERCENT;
      if (kind === "integer") return STYLE.PARENT_INTEGER;
      return STYLE.PARENT_NUMBER;
    }
    if (role === "difference") return kind === "percent" ? STYLE.DIFFERENCE_PERCENT : STYLE.DIFFERENCE_NUMBER;
    if (kind === "percent") return STYLE.PERCENT;
    if (kind === "integer") return STYLE.INTEGER;
    return STYLE.NUMBER;
  }

  function inlineCell(ref, value, style = STYLE.TEXT) {
    const text = String(value ?? "");
    const preserve = /^\s|\s$|\n|　/.test(text) ? ' xml:space="preserve"' : "";
    return `<c r="${ref}" s="${style}" t="inlineStr"><is><t${preserve}>${xmlEscape(text)}</t></is></c>`;
  }

  function blankCell(ref, style = STYLE.TEXT) { return `<c r="${ref}" s="${style}"/>`; }

  function numericCell(ref, value, style, formula = "") {
    const calculation = formula ? `<f>${xmlEscape(formula)}</f>` : "";
    if (formula && !isMissing(value) && !isFiniteNumber(value)) {
      return `<c r="${ref}" s="${style}" t="str">${calculation}<v>${xmlEscape(value)}</v></c>`;
    }
    const cached = isFiniteNumber(value) ? `<v>${value}</v>` : "<v/>";
    return `<c r="${ref}" s="${style}">${calculation}${cached}</c>`;
  }

  function styledCell(ref, value, column, options = {}) {
    const kind = valueKind(column, options.rowFormat);
    let style = roleStyle(kind, options.role);
    if (options.style != null) style = options.style;
    if (options.formula) return numericCell(ref, value, style, options.formula);
    if (isMissing(value)) return inlineCell(ref, "—", options.textStyle ?? (options.role === "subject" ? STYLE.SUBJECT_TEXT : options.role === "competitor" ? STYLE.COMPETITOR_TEXT : options.role === "parent" ? STYLE.PARENT_TEXT : style));
    if (isFiniteNumber(value)) return numericCell(ref, value, style);
    const textStyle = options.textStyle ?? (options.role === "subject" ? STYLE.SUBJECT_TEXT : options.role === "competitor" ? STYLE.COMPETITOR_TEXT : options.role === "parent" ? STYLE.PARENT_TEXT : STYLE.TEXT);
    return inlineCell(ref, value, textStyle);
  }

  function rowXml(row, cells, height = 18) {
    return `<row r="${row}" ht="${height}" customHeight="1">${cells.join("")}</row>`;
  }

  function columnsXml(widths, count) {
    return `<cols>${Array.from({ length: count }, (_, index) => {
      const width = Number(widths?.[index]) || 14;
      return `<col min="${index + 1}" max="${index + 1}" width="${width}" customWidth="1"/>`;
    }).join("")}</cols>`;
  }

  function formulaAt(table, rowIndex, columnIndex) {
    return table.formulas?.[`${rowIndex},${columnIndex}`] || "";
  }

  function cellOptionsFor(table, rowIndex, columnIndex) {
    const rowKind = table.rowKinds?.[rowIndex] || "";
    const rowRole = table.rowRoles?.[rowIndex] || "";
    const options = { rowFormat: table.rowFormats?.[rowIndex] || "", formula: formulaAt(table, rowIndex, columnIndex) };
    if (table.columnRoles?.[columnIndex]) options.role = table.columnRoles[columnIndex];
    if (table.growthColumns?.includes(columnIndex)) options.rowFormat = "percent";
    if (rowKind === "parent") {
      options.role = "parent";
      options.textStyle = STYLE.PARENT_TEXT;
      return options;
    }
    if (table.name === "对标总表") {
      if (!table.columnRoles) {
        if (columnIndex === 5 || columnIndex === 8) options.rowFormat = "percent";
        if (columnIndex >= 3 && columnIndex <= 5) options.role = "subject";
        else if (columnIndex >= 6 && columnIndex <= 8) options.role = "competitor";
      }
    } else if (table.name === "流量投放结构") {
      if (!table.columnRoles) {
        if (columnIndex === 4) options.role = "subject";
        else if (columnIndex === 5) options.role = "competitor";
        else if (columnIndex === 6) options.role = "difference";
      }
    } else if (table.name === "渠道指标") {
      if (columnIndex === 3 && rowKind === "child") options.textStyle = STYLE.CHILD_SOURCE;
      if (columnIndex === 4) {
        if (rowRole === "主体") options.textStyle = STYLE.SUBJECT_TEXT;
        if (rowRole === "竞品") options.textStyle = STYLE.COMPETITOR_TEXT;
      }
    } else if (table.name === "人群画像") {
      if (!table.columnRoles) {
        if (columnIndex === 4 || columnIndex === 5 || columnIndex === 8) options.role = "subject";
        if (columnIndex === 6 || columnIndex === 7 || columnIndex === 9) options.role = "competitor";
      }
    }
    return options;
  }

  function sheetViewXml(freezeColumns = 0) {
    const xSplit = Math.max(0, Number(freezeColumns) || 0);
    const topLeft = `${columnName(xSplit)}5`;
    const activePane = xSplit ? "bottomRight" : "bottomLeft";
    return `<sheetViews><sheetView showGridLines="0" zoomScale="90" zoomScaleNormal="90" workbookViewId="0"><pane${xSplit ? ` xSplit="${xSplit}"` : ""} ySplit="4" topLeftCell="${topLeft}" activePane="${activePane}" state="frozen"/><selection pane="${activePane}" activeCell="${topLeft}" sqref="${topLeft}"/></sheetView></sheetViews>`;
  }

  function regularSheet(table, sheetIndex, tableIndex) {
    const columnCount = table.columns.length;
    const lastColumn = columnName(columnCount - 1);
    const rows = [
      rowXml(1, [inlineCell("A1", table.name, STYLE.TITLE)], 28),
      rowXml(2, [inlineCell("A2", table.subtitle || "", STYLE.SUBTITLE)], 22),
      rowXml(3, [], 8),
      rowXml(4, table.columns.map((column, index) => inlineCell(cellRef(4, index), column, STYLE.HEADER)), 34),
    ];
    table.rows.forEach((values, rowIndex) => {
      const rowNumber = rowIndex + 5;
      const cells = table.columns.map((column, columnIndex) => styledCell(
        cellRef(rowNumber, columnIndex),
        values[columnIndex],
        column,
        cellOptionsFor(table, rowIndex, columnIndex),
      ));
      rows.push(rowXml(rowNumber, cells, table.name === "渠道指标" && table.rowKinds?.[rowIndex] === "parent" ? 21 : 18));
    });
    const lastRow = Math.max(5, table.rows.length + 4);
    const tableRef = `A4:${lastColumn}${lastRow}`;
    const merges = [`A1:${lastColumn}1`, `A2:${lastColumn}2`];
    const xml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="${XMLNS}" xmlns:r="${RELNS}"><dimension ref="A1:${lastColumn}${lastRow}"/>${sheetViewXml(table.freezeColumns)}<sheetFormatPr defaultRowHeight="18"/>${columnsXml(table.widths, columnCount)}<sheetData>${rows.join("")}</sheetData><mergeCells count="${merges.length}">${merges.map((ref) => `<mergeCell ref="${ref}"/>`).join("")}</mergeCells><pageMargins left="0.4" right="0.4" top="0.5" bottom="0.5" header="0.2" footer="0.2"/><tableParts count="1"><tablePart r:id="rId1"/></tableParts></worksheet>`;
    return { xml, tableRef, sheetIndex, tableIndex };
  }

  function overviewEntitiesOf(table) {
    const entities = (table?.overviewEntities || []).filter((entity) => entity?.key && ["主体", "竞品"].includes(entity.role));
    if (entities.length) return entities;
    return [
      { key: "__subject__", role: "主体", label: "本店" },
      { key: "__competitor__", role: "竞品", label: table?.primaryCompetitorLabel || "竞店" },
    ];
  }

  function overviewEntityValueCell(ref, metric, entity, entityIndex) {
    const sourceRow = metric?.sourceRow;
    const sourceColumn = columnName(3 + entityIndex * 3);
    const formula = sourceRow ? `'对标总表'!${sourceColumn}${sourceRow}` : "";
    const values = metric?.valuesByEntity?.[entity.key];
    const legacyValue = entity.role === "主体" ? metric?.subjectCurrent : metric?.competitorCurrent;
    return styledCell(ref, values?.current ?? legacyValue, metric?.label || "", {
      role: entity.role === "主体" ? "subject" : "competitor",
      rowFormat: metric?.format,
      formula,
    });
  }

  function overviewGrowthCell(ref, metric, subjectEntity, subjectIndex) {
    const sourceRow = metric?.sourceRow;
    const sourceColumn = columnName(3 + subjectIndex * 3 + 2);
    const formula = sourceRow ? `'对标总表'!${sourceColumn}${sourceRow}` : "";
    const value = metric?.valuesByEntity?.[subjectEntity?.key]?.growth ?? metric?.subjectGrowth;
    return styledCell(ref, value, metric?.label || "", { rowFormat: "percent", formula, style: STYLE.OVERVIEW_GROWTH });
  }

  function addOverviewCells(rowMap, rowNumber, cells, height = 21) {
    if (!rowMap.has(rowNumber)) rowMap.set(rowNumber, { cells: [], height });
    const row = rowMap.get(rowNumber);
    row.cells.push(...cells);
    row.height = Math.max(row.height, height);
  }

  function overviewMetricBlock(rowMap, startRow, startColumn, period, entities) {
    const subjectIndex = Math.max(0, entities.findIndex((entity) => entity.role === "主体"));
    const subjectEntity = entities[subjectIndex];
    const endColumn = startColumn + entities.length + 1;
    addOverviewCells(rowMap, startRow, [inlineCell(cellRef(startRow, startColumn), period?.title || `近${period?.days || ""}天`, STYLE.HEADER)], 24);
    const headers = ["指标", ...entities.map((entity) => `${entity.label || (entity.role === "主体" ? "本店" : "竞店")}当前`), "本店变化"];
    addOverviewCells(rowMap, startRow + 1, headers.map((value, index) => inlineCell(cellRef(startRow + 1, startColumn + index), value, STYLE.OVERVIEW_LABEL)), 34);
    (period?.metrics || []).forEach((metric, index) => {
      const rowNumber = startRow + 2 + index;
      addOverviewCells(rowMap, rowNumber, [
        inlineCell(cellRef(rowNumber, startColumn), metric.label, STYLE.OVERVIEW_LABEL),
        ...entities.map((entity, entityIndex) => overviewEntityValueCell(cellRef(rowNumber, startColumn + 1 + entityIndex), metric, entity, entityIndex)),
        overviewGrowthCell(cellRef(rowNumber, endColumn), metric, subjectEntity, subjectIndex),
      ], 21);
    });
    return `${cellRef(startRow, startColumn)}:${cellRef(startRow, endColumn)}`;
  }

  function overviewSegmentRow(rowMap, rowNumber, totalColumns, labels, style, height) {
    const merges = [];
    let startColumn = 0;
    labels.forEach((label, index) => {
      const remainingColumns = totalColumns - startColumn;
      const remainingLabels = labels.length - index;
      const width = Math.ceil(remainingColumns / remainingLabels);
      const endColumn = startColumn + width - 1;
      addOverviewCells(rowMap, rowNumber, [inlineCell(cellRef(rowNumber, startColumn), label, style)], height);
      if (endColumn > startColumn) merges.push(`${cellRef(rowNumber, startColumn)}:${cellRef(rowNumber, endColumn)}`);
      startColumn = endColumn + 1;
    });
    return merges;
  }

  function overviewSheet(table, report) {
    const rowMap = new Map();
    const entities = overviewEntitiesOf(table);
    const blockWidth = entities.length + 2;
    const blockStride = blockWidth + 1;
    const totalColumns = blockStride * 2;
    const lastColumn = columnName(totalColumns - 1);
    addOverviewCells(rowMap, 1, [inlineCell("A1", "达摩盘竞争态势分析自动取数报告｜少壮AI自动化", STYLE.TITLE)], 30);
    addOverviewCells(rowMap, 2, [inlineCell("A2", table.subtitle || "", STYLE.SUBTITLE)], 24);
    addOverviewCells(rowMap, 3, [], 8);
    addOverviewCells(rowMap, 4, [inlineCell("A4", "经营观察路径", STYLE.SECTION)], 24);
    addOverviewCells(rowMap, 6, [], 8);
    const merges = [`A1:${lastColumn}1`, `A2:${lastColumn}2`, `A4:${lastColumn}4`];
    merges.push(...overviewSegmentRow(rowMap, 5, totalColumns, ["全店结果", "广告承接", "投放效率", "渠道结构", "人群画像"], STYLE.OVERVIEW_NOTE, 28));
    const periods = table.overviewPeriods || [];
    merges.push(overviewMetricBlock(rowMap, 7, 0, periods[0] || { days: 7, metrics: [] }, entities));
    merges.push(overviewMetricBlock(rowMap, 7, blockStride, periods[1] || { days: 30, metrics: [] }, entities));

    addOverviewCells(rowMap, 13, [], 8);
    addOverviewCells(rowMap, 14, [inlineCell("A14", "补充经营指标", STYLE.SECTION)], 24);
    merges.push(`A14:${lastColumn}14`);
    const extras = table.overviewExtras || [];
    const periodByDays = new Map(periods.map((period) => [period.days, period]));
    const subjectIndex = Math.max(0, entities.findIndex((entity) => entity.role === "主体"));
    const subjectEntity = entities[subjectIndex];
    for (const [blockIndex, startColumn] of [[0, 0], [1, blockStride]]) {
      const extra = extras[blockIndex] || { days: blockIndex ? 30 : 7, metrics: [] };
      const title = periodByDays.get(extra.days)?.title || `近${extra.days}天`;
      addOverviewCells(rowMap, 15, [inlineCell(cellRef(15, startColumn), title, STYLE.HEADER)], 24);
      const headers = ["指标", ...entities.map((entity) => `${entity.label || (entity.role === "主体" ? "本店" : "竞店")}当前`), "本店变化"];
      addOverviewCells(rowMap, 16, headers.map((value, index) => inlineCell(cellRef(16, startColumn + index), value, STYLE.OVERVIEW_LABEL)), 34);
      merges.push(`${cellRef(15, startColumn)}:${cellRef(15, startColumn + blockWidth - 1)}`);
      extra.metrics.forEach((metric, index) => {
        const rowNumber = 17 + index;
        addOverviewCells(rowMap, rowNumber, [
          inlineCell(cellRef(rowNumber, startColumn), metric.label, STYLE.OVERVIEW_LABEL),
          ...entities.map((entity, entityIndex) => overviewEntityValueCell(cellRef(rowNumber, startColumn + 1 + entityIndex), metric, entity, entityIndex)),
          overviewGrowthCell(cellRef(rowNumber, startColumn + blockWidth - 1), metric, subjectEntity, subjectIndex),
        ], 21);
      });
    }
    addOverviewCells(rowMap, 23, [], 8);
    addOverviewCells(rowMap, 24, [inlineCell("A24", "报告页签", STYLE.SECTION)], 24);
    merges.push(`A24:${lastColumn}24`);
    merges.push(...overviewSegmentRow(rowMap, 25, totalColumns, [
      "对标总表｜核心经营指标",
      "流量投放结构｜付费/免费与成本结构",
      "渠道指标｜一级父行 + 二级缩进行",
      "人群画像｜六项圈选标签",
      report.quality?.complete ? "完整性校验｜通过" : "完整性校验｜未通过",
    ], STYLE.OVERVIEW_NOTE, 32));

    const sortedRows = [...rowMap.entries()].sort((a, b) => a[0] - b[0]).map(([rowNumber, row]) => rowXml(rowNumber, row.cells, row.height));
    const blockWidths = [23, ...entities.map((entity) => entity.role === "主体" ? 14 : 19), 14, 4];
    const widths = [...blockWidths, ...blockWidths];
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="${XMLNS}" xmlns:r="${RELNS}"><dimension ref="A1:${lastColumn}25"/><sheetViews><sheetView showGridLines="0" zoomScale="85" zoomScaleNormal="85" workbookViewId="0"><pane ySplit="2" topLeftCell="A3" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="18"/>${columnsXml(widths, totalColumns)}<sheetData>${sortedRows.join("")}</sheetData><mergeCells count="${merges.length}">${merges.map((ref) => `<mergeCell ref="${ref}"/>`).join("")}</mergeCells><pageMargins left="0.4" right="0.4" top="0.5" bottom="0.5" header="0.2" footer="0.2"/></worksheet>`;
  }

  function tableXml(table, tableIndex, ref) {
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><table xmlns="${XMLNS}" id="${tableIndex}" name="CompetitionTable${tableIndex}" displayName="CompetitionTable${tableIndex}" ref="${ref}" totalsRowShown="0"><autoFilter ref="${ref}"/><tableColumns count="${table.columns.length}">${table.columns.map((column, index) => `<tableColumn id="${index + 1}" name="${xmlEscape(column)}"/>`).join("")}</tableColumns><tableStyleInfo name="TableStyleMedium2" showFirstColumn="0" showLastColumn="0" showRowStripes="0" showColumnStripes="0"/></table>`;
  }

  function sheetRelationships(tableIndex) {
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/table" Target="../tables/table${tableIndex}.xml"/></Relationships>`;
  }

  function stylesXml() {
    const fonts = [
      '<font><sz val="10"/><color rgb="FF243746"/><name val="PingFang SC"/></font>',
      '<font><b/><sz val="18"/><color rgb="FFFFFFFF"/><name val="PingFang SC"/></font>',
      '<font><sz val="9"/><color rgb="FF425C66"/><name val="PingFang SC"/></font>',
      '<font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="PingFang SC"/></font>',
      '<font><b/><sz val="10"/><color rgb="FF174E48"/><name val="PingFang SC"/></font>',
      '<font><sz val="10"/><color rgb="FF5A6872"/><name val="PingFang SC"/></font>',
    ];
    const fills = [
      '<fill><patternFill patternType="none"/></fill>',
      '<fill><patternFill patternType="gray125"/></fill>',
      '<fill><patternFill patternType="solid"><fgColor rgb="FF0F5263"/></patternFill></fill>',
      '<fill><patternFill patternType="solid"><fgColor rgb="FFDDEFEA"/></patternFill></fill>',
      '<fill><patternFill patternType="solid"><fgColor rgb="FF008C7F"/></patternFill></fill>',
      '<fill><patternFill patternType="solid"><fgColor rgb="FFEAF2FC"/></patternFill></fill>',
      '<fill><patternFill patternType="solid"><fgColor rgb="FFFFF2E3"/></patternFill></fill>',
      '<fill><patternFill patternType="solid"><fgColor rgb="FFDDF3E6"/></patternFill></fill>',
      '<fill><patternFill patternType="solid"><fgColor rgb="FFF5F7F8"/></patternFill></fill>',
      '<fill><patternFill patternType="solid"><fgColor rgb="FFFFF7D9"/></patternFill></fill>',
      '<fill><patternFill patternType="solid"><fgColor rgb="FFE8F4F3"/></patternFill></fill>',
    ];
    const xf = (numFmtId, fontId, fillId, borderId = 1, alignment = "") => `<xf numFmtId="${numFmtId}" fontId="${fontId}" fillId="${fillId}" borderId="${borderId}" xfId="0" applyNumberFormat="${numFmtId ? 1 : 0}" applyFont="1" applyFill="${fillId ? 1 : 0}" applyBorder="${borderId ? 1 : 0}" applyAlignment="1"><alignment vertical="center"${alignment}/></xf>`;
    const cellXfs = [
      '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>',
      xf(0, 1, 2, 0, ' horizontal="left"'),
      xf(0, 2, 3, 0, ' horizontal="left" wrapText="1"'),
      xf(0, 3, 4, 1, ' horizontal="center" wrapText="1"'),
      xf(0, 0, 0, 1, ' horizontal="left" wrapText="1"'),
      xf(164, 0, 0, 1, ' horizontal="right"'),
      xf(165, 0, 0, 1, ' horizontal="right"'),
      xf(3, 0, 0, 1, ' horizontal="right"'),
      xf(0, 0, 5, 1, ' horizontal="left" wrapText="1"'),
      xf(164, 0, 5, 1, ' horizontal="right"'),
      xf(165, 0, 5, 1, ' horizontal="right"'),
      xf(3, 0, 5, 1, ' horizontal="right"'),
      xf(0, 0, 6, 1, ' horizontal="left" wrapText="1"'),
      xf(164, 0, 6, 1, ' horizontal="right"'),
      xf(165, 0, 6, 1, ' horizontal="right"'),
      xf(3, 0, 6, 1, ' horizontal="right"'),
      xf(0, 4, 7, 1, ' horizontal="left" wrapText="1"'),
      xf(164, 4, 7, 1, ' horizontal="right"'),
      xf(165, 4, 7, 1, ' horizontal="right"'),
      xf(3, 4, 7, 1, ' horizontal="right"'),
      xf(0, 5, 8, 1, ' horizontal="left" wrapText="1"'),
      xf(164, 0, 9, 1, ' horizontal="right"'),
      xf(165, 0, 9, 1, ' horizontal="right"'),
      xf(0, 3, 2, 0, ' horizontal="left"'),
      xf(0, 4, 10, 1, ' horizontal="left" wrapText="1"'),
      xf(165, 4, 10, 1, ' horizontal="right"'),
      xf(0, 5, 8, 1, ' horizontal="center" wrapText="1"'),
    ];
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="${XMLNS}"><numFmts count="2"><numFmt numFmtId="164" formatCode="#,##0.00"/><numFmt numFmtId="165" formatCode="0.00%"/></numFmts><fonts count="${fonts.length}">${fonts.join("")}</fonts><fills count="${fills.length}">${fills.join("")}</fills><borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FFD9E4E7"/></left><right style="thin"><color rgb="FFD9E4E7"/></right><top style="thin"><color rgb="FFD9E4E7"/></top><bottom style="thin"><color rgb="FFD9E4E7"/></bottom><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="${cellXfs.length}">${cellXfs.join("")}</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles><tableStyles count="0" defaultTableStyle="TableStyleMedium2" defaultPivotStyle="PivotStyleLight16"/></styleSheet>`;
  }

  function contentTypes(sheetCount, tableCount) {
    const overrides = [
      '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
      '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>',
      '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>',
      '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>',
    ];
    for (let index = 1; index <= sheetCount; index += 1) overrides.push(`<Override PartName="/xl/worksheets/sheet${index}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`);
    for (let index = 1; index <= tableCount; index += 1) overrides.push(`<Override PartName="/xl/tables/table${index}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.table+xml"/>`);
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>${overrides.join("")}</Types>`;
  }

  function workbookXml(tables) {
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="${XMLNS}" xmlns:r="${RELNS}"><fileVersion appName="xl"/><workbookPr/><bookViews><workbookView xWindow="0" yWindow="0" windowWidth="28800" windowHeight="15000"/></bookViews><sheets>${tables.map((table, index) => `<sheet name="${xmlEscape(table.name)}" sheetId="${index + 1}" r:id="rId${index + 1}"/>`).join("")}</sheets><calcPr calcId="191029" fullCalcOnLoad="1" forceFullCalc="1"/></workbook>`;
  }

  function workbookRelationships(sheetCount) {
    const relationships = [];
    for (let index = 1; index <= sheetCount; index += 1) relationships.push(`<Relationship Id="rId${index}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${index}.xml"/>`);
    relationships.push(`<Relationship Id="rId${sheetCount + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>`);
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${relationships.join("")}</Relationships>`;
  }

  function rootRelationships() {
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>`;
  }

  function coreProperties() {
    const now = new Date().toISOString();
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:creator>少壮AI自动化</dc:creator><cp:lastModifiedBy>少壮AI自动化</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">${now}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">${now}</dcterms:modified><dc:title>达摩盘竞争态势分析自动取数报告｜少壮AI自动化</dc:title></cp:coreProperties>`;
  }

  function appProperties(tables) {
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>少壮AI自动化</Application><DocSecurity>0</DocSecurity><ScaleCrop>false</ScaleCrop><HeadingPairs><vt:vector size="2" baseType="variant"><vt:variant><vt:lpstr>Worksheets</vt:lpstr></vt:variant><vt:variant><vt:i4>${tables.length}</vt:i4></vt:variant></vt:vector></HeadingPairs><TitlesOfParts><vt:vector size="${tables.length}" baseType="lpstr">${tables.map((table) => `<vt:lpstr>${xmlEscape(table.name)}</vt:lpstr>`).join("")}</vt:vector></TitlesOfParts><Company></Company><LinksUpToDate>false</LinksUpToDate><SharedDoc>false</SharedDoc><HyperlinksChanged>false</HyperlinksChanged><AppVersion>16.0300</AppVersion></Properties>`;
  }

  function validateReport(report) {
    if (!report || !Array.isArray(report.tables)) throw new Error("报告数据为空");
    const names = report.tables.map((table) => table.name);
    if (names.length !== REQUIRED_TABLES.length || REQUIRED_TABLES.some((name, index) => names[index] !== name)) {
      throw new Error(`报告必须按顺序包含 ${REQUIRED_TABLES.join("、")}`);
    }
    for (const table of report.tables) {
      if (!Array.isArray(table.columns) || !Array.isArray(table.rows)) throw new Error(`${table.name} 缺少列或数据行`);
      if (table.name !== "报告总览" && table.rows.some((row) => row.length !== table.columns.length)) throw new Error(`${table.name} 存在列数不一致的数据行`);
    }
  }

  function buildXlsxParts(report) {
    validateReport(report);
    const parts = new Map();
    let tableIndex = 0;
    report.tables.forEach((table, index) => {
      const sheetIndex = index + 1;
      if (table.name === "报告总览") {
        parts.set(`xl/worksheets/sheet${sheetIndex}.xml`, overviewSheet(table, report));
        return;
      }
      tableIndex += 1;
      const built = regularSheet(table, sheetIndex, tableIndex);
      parts.set(`xl/worksheets/sheet${sheetIndex}.xml`, built.xml);
      parts.set(`xl/tables/table${tableIndex}.xml`, tableXml(table, tableIndex, built.tableRef));
      parts.set(`xl/worksheets/_rels/sheet${sheetIndex}.xml.rels`, sheetRelationships(tableIndex));
    });
    parts.set("[Content_Types].xml", contentTypes(report.tables.length, tableIndex));
    parts.set("_rels/.rels", rootRelationships());
    parts.set("docProps/core.xml", coreProperties());
    parts.set("docProps/app.xml", appProperties(report.tables));
    parts.set("xl/workbook.xml", workbookXml(report.tables));
    parts.set("xl/_rels/workbook.xml.rels", workbookRelationships(report.tables.length));
    parts.set("xl/styles.xml", stylesXml());
    return parts;
  }

  const CRC_TABLE = (() => {
    const table = new Uint32Array(256);
    for (let index = 0; index < 256; index += 1) {
      let value = index;
      for (let bit = 0; bit < 8; bit += 1) value = (value & 1) ? 0xEDB88320 ^ (value >>> 1) : value >>> 1;
      table[index] = value >>> 0;
    }
    return table;
  })();

  function crc32(bytes) {
    let crc = 0xFFFFFFFF;
    for (const byte of bytes) crc = CRC_TABLE[(crc ^ byte) & 0xFF] ^ (crc >>> 8);
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }

  function dosDateTime(date = new Date()) {
    const year = Math.max(1980, date.getFullYear());
    return {
      date: ((year - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate(),
      time: (date.getHours() << 11) | (date.getMinutes() << 5) | Math.floor(date.getSeconds() / 2),
    };
  }

  function u16(value) { return new Uint8Array([value & 0xFF, (value >>> 8) & 0xFF]); }
  function u32(value) { return new Uint8Array([value & 0xFF, (value >>> 8) & 0xFF, (value >>> 16) & 0xFF, (value >>> 24) & 0xFF]); }

  function concatBytes(chunks) {
    const size = chunks.reduce((sum, chunk) => sum + chunk.length, 0);
    const output = new Uint8Array(size);
    let offset = 0;
    for (const chunk of chunks) { output.set(chunk, offset); offset += chunk.length; }
    return output;
  }

  function zipStore(parts) {
    const encoder = new TextEncoder();
    const localChunks = [];
    const centralChunks = [];
    const stamp = dosDateTime();
    let offset = 0;
    for (const [name, content] of parts) {
      const filename = encoder.encode(name);
      const data = typeof content === "string" ? encoder.encode(content) : content;
      const crc = crc32(data);
      const local = concatBytes([u32(0x04034B50), u16(20), u16(0x0800), u16(0), u16(stamp.time), u16(stamp.date), u32(crc), u32(data.length), u32(data.length), u16(filename.length), u16(0), filename, data]);
      localChunks.push(local);
      centralChunks.push(concatBytes([u32(0x02014B50), u16(20), u16(20), u16(0x0800), u16(0), u16(stamp.time), u16(stamp.date), u32(crc), u32(data.length), u32(data.length), u16(filename.length), u16(0), u16(0), u16(0), u16(0), u32(0), u32(offset), filename]));
      offset += local.length;
    }
    const central = concatBytes(centralChunks);
    const end = concatBytes([u32(0x06054B50), u16(0), u16(0), u16(parts.size), u16(parts.size), u32(central.length), u32(offset), u16(0)]);
    return concatBytes([...localChunks, central, end]);
  }

  function buildXlsx(report) { return zipStore(buildXlsxParts(report)); }

  return { MIME_TYPE, REQUIRED_TABLES, buildXlsx, buildXlsxParts, zipStore };
});
