(function initCompetitionCompetitorDom(root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.DmpCompetitionCompetitorDom = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function createCompetitionCompetitorDom() {
  "use strict";

  function normalizeText(value) {
    return String(value ?? "").replace(/[\s\u00a0]+/g, " ").trim();
  }

  function uniqueElements(elements) {
    return [...new Set((elements || []).filter(Boolean))];
  }

  function deepestElements(elements) {
    const unique = uniqueElements(elements);
    return unique.filter((candidate) => !unique.some((other) => other !== candidate && candidate.contains?.(other)));
  }

  function exactVisibleTextElements(root, text, options = {}) {
    if (!root) return [];
    const wanted = normalizeText(text);
    if (!wanted) return [];
    const isVisible = typeof options.isVisible === "function" ? options.isVisible : () => true;
    const exclude = options.exclude || null;
    const output = [];
    const seen = new Set();
    const add = (element) => {
      if (!element || seen.has(element) || exclude?.contains?.(element) || !isVisible(element)) return;
      seen.add(element);
      output.push(element);
    };

    const doc = root.ownerDocument || globalThis.document;
    const filterApi = doc?.defaultView?.NodeFilter || globalThis.NodeFilter || {
      SHOW_TEXT: 4,
      FILTER_ACCEPT: 1,
      FILTER_REJECT: 2,
    };
    if (doc?.createTreeWalker) {
      const walker = doc.createTreeWalker(root, filterApi.SHOW_TEXT, {
        acceptNode(node) {
          const parent = node.parentElement;
          return parent && normalizeText(node.nodeValue) === wanted && !exclude?.contains?.(parent) && isVisible(parent)
            ? filterApi.FILTER_ACCEPT
            : filterApi.FILTER_REJECT;
        },
      });
      while (walker.nextNode()) add(walker.currentNode.parentElement);
    }

    const selector = "button,a,[role='button'],[role='option'],[role='row'],li,span,div,strong,p";
    const candidates = [
      ...(root.matches?.(selector) ? [root] : []),
      ...(root.querySelectorAll?.(selector) || []),
    ];
    for (const element of candidates) {
      if (normalizeText(element.textContent) === wanted) add(element);
    }
    return output;
  }

  function nearestUniqueAction(nameElements, actionElements, root, options = {}) {
    const exclude = options.exclude || null;
    const clickTarget = typeof options.clickTarget === "function" ? options.clickTarget : (element) => element;
    for (const nameElement of nameElements || []) {
      if (!nameElement || exclude?.contains?.(nameElement)) continue;
      let row = nameElement;
      while (row && row !== root) {
        const logicalActions = deepestElements((actionElements || [])
          .filter((element) => row.contains?.(element) && !exclude?.contains?.(element)));
        const actions = uniqueElements(logicalActions.map(clickTarget));
        if (actions.length === 1) return { button: actions[0], row, nameElement };
        row = row.parentElement;
      }
    }
    return null;
  }

  function findExactRowAction(root, wantedText, actionText, options = {}) {
    const names = exactVisibleTextElements(root, wantedText, options);
    const actions = exactVisibleTextElements(root, actionText, options);
    return nearestUniqueAction(names, actions, root, options)?.button || null;
  }

  return {
    normalizeText,
    deepestElements,
    exactVisibleTextElements,
    nearestUniqueAction,
    findExactRowAction,
  };
});
