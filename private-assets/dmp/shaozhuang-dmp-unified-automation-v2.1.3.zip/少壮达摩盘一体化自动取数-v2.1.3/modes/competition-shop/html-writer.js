(function initCompetitionHtmlWriter(root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.DmpCompetitionHtmlWriter = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function createCompetitionHtmlWriter() {
  "use strict";

  const MIME_TYPE = "text/html;charset=utf-8";
  const REQUIRED_TABLES = Object.freeze(["报告总览", "对标总表", "流量投放结构", "渠道指标", "人群画像"]);
  const SECTION_IDS = Object.freeze({
    报告总览: "overview",
    对标总表: "benchmark",
    流量投放结构: "structure",
    渠道指标: "channel",
    人群画像: "portrait",
  });

  function escapeHtml(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function isMissing(value) {
    return value === null || value === undefined || value === "" || value === "—";
  }

  function valueKind(table, rowIndex, columnIndex, metricFormat = "") {
    if (metricFormat) return metricFormat;
    if (table.growthColumns?.includes(columnIndex)) return "percent";
    const rowFormat = table.rowFormats?.[rowIndex];
    if (["percent", "integer", "number"].includes(rowFormat)) {
      if (table.name === "对标总表" && columnIndex >= 3 && !table.growthColumns?.includes(columnIndex)) return rowFormat;
      if (columnIndex >= 3) return rowFormat;
    }
    const column = String(table.columns?.[columnIndex] || "");
    if (/变化率|变化$|占比|转化率|加购率|点击率|流量占比|本店-/.test(column)) return "percent";
    if (/天数|笔数|点击量|人数$/.test(column)) return "integer";
    return "number";
  }

  function formatValue(value, kind = "number") {
    if (isMissing(value)) return "—";
    if (typeof value !== "number" || !Number.isFinite(value)) {
      if (typeof value === "object") {
        try { return JSON.stringify(value); } catch { return String(value); }
      }
      return String(value);
    }
    if (kind === "percent") {
      return new Intl.NumberFormat("zh-CN", {
        style: "percent",
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      }).format(value);
    }
    if (kind === "integer") return new Intl.NumberFormat("zh-CN", { maximumFractionDigits: 0 }).format(value);
    return new Intl.NumberFormat("zh-CN", { minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(value);
  }

  function trendClass(value, kind) {
    if (kind !== "percent" || typeof value !== "number" || !Number.isFinite(value) || value === 0) return "";
    return value > 0 ? " trend-up" : " trend-down";
  }

  function roleClass(role) {
    if (role === "subject" || role === "主体") return " role-subject";
    if (role === "competitor" || role === "竞品") return " role-competitor";
    if (role === "difference") return " role-difference";
    return "";
  }

  function formatGeneratedAt(value) {
    const date = new Date(value || Date.now());
    if (Number.isNaN(date.getTime())) return String(value || "");
    return new Intl.DateTimeFormat("zh-CN", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
    }).format(date).replace(/\//g, "-");
  }

  function columnWidth(table, columnIndex) {
    return Math.max(88, Math.min(250, Math.round((Number(table.widths?.[columnIndex]) || 14) * 7.2)));
  }

  function stickyOffsets(table) {
    const count = Math.max(0, Number(table.freezeColumns) || 0);
    const offsets = [];
    let left = 0;
    for (let index = 0; index < count; index += 1) {
      offsets[index] = left;
      left += columnWidth(table, index);
    }
    return offsets;
  }

  function cellRole(table, rowIndex, columnIndex) {
    if (table.columnRoles?.[columnIndex]) return table.columnRoles[columnIndex];
    if (table.name === "渠道指标" && columnIndex >= 4) return table.rowRoles?.[rowIndex] || "";
    return "";
  }

  function isTrendCell(table, columnIndex) {
    const column = String(table.columns?.[columnIndex] || "");
    return table.growthColumns?.includes(columnIndex)
      || table.columnRoles?.[columnIndex] === "difference"
      || /变化率|变化$|本店-/.test(column);
  }

  function renderTable(table) {
    const offsets = stickyOffsets(table);
    const head = table.columns.map((column, columnIndex) => {
      const width = columnWidth(table, columnIndex);
      const sticky = offsets[columnIndex] == null ? "" : ` sticky-col\" style=\"--sticky-left:${offsets[columnIndex]}px;min-width:${width}px;width:${width}px`;
      const role = roleClass(table.columnRoles?.[columnIndex]);
      return `<th class="${role.trim()}${sticky}">${escapeHtml(column)}</th>`;
    }).join("");
    const body = table.rows.map((row, rowIndex) => {
      const rowKind = table.rowKinds?.[rowIndex] || "";
      const rowRole = table.rowRoles?.[rowIndex] || "";
      const cells = table.columns.map((column, columnIndex) => {
        const width = columnWidth(table, columnIndex);
        const sticky = offsets[columnIndex] == null ? "" : ` sticky-col\" style=\"--sticky-left:${offsets[columnIndex]}px;min-width:${width}px;width:${width}px`;
        const kind = valueKind(table, rowIndex, columnIndex);
        const value = row?.[columnIndex];
        const sourceClass = table.name === "渠道指标" && columnIndex === 3 ? " source-cell" : "";
        const numericClass = typeof value === "number" ? " numeric" : "";
        const trend = isTrendCell(table, columnIndex) ? trendClass(value, kind) : "";
        const classes = `${roleClass(cellRole(table, rowIndex, columnIndex))}${sourceClass}${numericClass}${trend}`.trim();
        return `<td class="${classes}${sticky}">${escapeHtml(formatValue(value, kind))}</td>`;
      }).join("");
      return `<tr class="${rowKind ? `row-${escapeHtml(rowKind)}` : ""}${roleClass(rowRole)}">${cells}</tr>`;
    }).join("");
    const sectionId = SECTION_IDS[table.name] || `table-${Math.random().toString(36).slice(2)}`;
    return `<section class="report-section" id="${sectionId}">
      <div class="section-heading">
        <div><p class="section-index">${String(REQUIRED_TABLES.indexOf(table.name) + 1).padStart(2, "0")}</p><h2>${escapeHtml(table.name)}</h2></div>
        <span class="row-total">${table.rows.length} 行</span>
      </div>
      ${table.subtitle ? `<p class="section-note">${escapeHtml(table.subtitle)}</p>` : ""}
      <div class="table-tools"><label>筛选本表<input type="search" data-table-filter aria-label="筛选${escapeHtml(table.name)}" placeholder="输入关键词"></label><span data-filter-count>${table.rows.length} / ${table.rows.length}</span></div>
      <div class="table-shell"><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>
    </section>`;
  }

  function overviewEntitiesOf(table) {
    const entities = (table?.overviewEntities || []).filter((entity) => entity?.key && ["主体", "竞品"].includes(entity.role));
    if (entities.length) return entities;
    return [
      { key: "__subject__", role: "主体", label: "本店" },
      { key: "__competitor__", role: "竞品", label: table?.primaryCompetitorLabel || "竞店" },
    ];
  }

  function overviewEntityValue(metric, entity, field = "current") {
    const value = metric?.valuesByEntity?.[entity?.key]?.[field];
    if (value !== undefined && value !== null) return value;
    if (entity?.role === "主体") return field === "growth" ? metric?.subjectGrowth : metric?.subjectCurrent;
    return field === "growth" ? metric?.competitorGrowth : metric?.competitorCurrent;
  }

  function renderMetric(metric, entities) {
    const format = metric?.format || "number";
    const subject = entities.find((entity) => entity.role === "主体") || entities[0];
    const competitors = entities.filter((entity) => entity.role === "竞品");
    const growth = overviewEntityValue(metric, subject, "growth");
    const comparisons = competitors.map((entity) => `<div><dt>${escapeHtml(entity.label || "竞店")}当前</dt><dd>${escapeHtml(formatValue(overviewEntityValue(metric, entity), format))}</dd></div>`).join("");
    return `<article class="metric-card">
      <p>${escapeHtml(metric?.label || "—")}</p>
      <strong>${escapeHtml(formatValue(overviewEntityValue(metric, subject), format))}</strong>
      <dl>${comparisons}<div><dt>本店变化</dt><dd class="${trendClass(growth, "percent").trim()}">${escapeHtml(formatValue(growth, "percent"))}</dd></div></dl>
    </article>`;
  }

  function renderExtraTable(extra, entities) {
    const subject = entities.find((entity) => entity.role === "主体") || entities[0];
    const competitors = entities.filter((entity) => entity.role === "竞品");
    const rows = (extra?.metrics || []).map((metric) => `<tr>
      <td>${escapeHtml(metric?.label || "—")}</td>
      <td class="role-subject numeric">${escapeHtml(formatValue(overviewEntityValue(metric, subject), metric?.format || "number"))}</td>
      ${competitors.map((entity) => `<td class="role-competitor">${escapeHtml(formatValue(overviewEntityValue(metric, entity), metric?.format || "number"))}</td>`).join("")}
      <td class="numeric${trendClass(overviewEntityValue(metric, subject, "growth"), "percent")}">${escapeHtml(formatValue(overviewEntityValue(metric, subject, "growth"), "percent"))}</td>
    </tr>`).join("");
    const competitorHeads = competitors.map((entity) => `<th class="role-competitor">${escapeHtml(entity.label || "竞店")}当前</th>`).join("");
    return `<div class="extra-table"><table><thead><tr><th>指标</th><th class="role-subject">本店当前</th>${competitorHeads}<th>本店变化</th></tr></thead><tbody>${rows}</tbody></table></div>`;
  }

  function renderOverview(table) {
    const entities = overviewEntitiesOf(table);
    const competitorLabels = entities.filter((entity) => entity.role === "竞品").map((entity) => entity.label || "竞店");
    const comparisonLabel = competitorLabels.join("、") || "竞店";
    const periods = table.overviewPeriods || [];
    const extras = table.overviewExtras || [];
    const periodCards = periods.map((period) => `<article class="period-block">
      <div class="period-title"><span>${escapeHtml(period.title || `近${period.days || ""}天`)}</span><small>本店 vs ${escapeHtml(comparisonLabel)}</small></div>
      <div class="metric-grid">${(period.metrics || []).map((metric) => renderMetric(metric, entities)).join("")}</div>
    </article>`).join("");
    const extraBlocks = extras.map((extra) => `<article class="period-block compact">
      <div class="period-title"><span>近${escapeHtml(extra.days || "")}天补充指标</span><small>本店 vs ${escapeHtml(comparisonLabel)}</small></div>
      ${renderExtraTable(extra, entities)}
    </article>`).join("");
    return `<section class="report-section overview-section" id="overview">
      <div class="section-heading"><div><p class="section-index">01</p><h2>报告总览</h2></div><span class="row-total">双周期 · ${competitorLabels.length}家竞店</span></div>
      ${table.subtitle ? `<p class="section-note">${escapeHtml(table.subtitle)}</p>` : ""}
      <div class="period-layout">${periodCards}</div>
      <h3 class="subheading">补充经营指标</h3>
      <div class="period-layout">${extraBlocks}</div>
    </section>`;
  }

  function assertReport(report) {
    if (!report || typeof report !== "object") throw new TypeError("缺少竞争态势报告数据");
    if (!report.quality?.exportAllowed) throw new Error("业务数据未完整，不能生成 HTML 报告");
    const tables = Array.isArray(report.tables) ? report.tables : [];
    for (const name of REQUIRED_TABLES) {
      const table = tables.find((candidate) => candidate?.name === name);
      if (!table || !Array.isArray(table.columns) || !Array.isArray(table.rows)) throw new Error(`HTML 报告缺少“${name}”数据表`);
    }
  }

  function buildHtml(report, options = {}) {
    assertReport(report);
    const tableByName = new Map(report.tables.map((table) => [table.name, table]));
    const generatedAt = options.generatedAt || report.generatedAt || new Date().toISOString();
    const requestedTitle = options.title || "达摩盘竞争态势分析报告";
    const title = /少壮AI自动化$/.test(requestedTitle) ? requestedTitle : `${requestedTitle}｜少壮AI自动化`;
    const watermark = Array.from({ length: 36 }, () => "<span>少壮AI自动化</span>").join("");
    const nav = REQUIRED_TABLES.map((name) => `<a href="#${SECTION_IDS[name]}">${escapeHtml(name)}</a>`).join("");
    const sections = REQUIRED_TABLES.map((name) => name === "报告总览" ? renderOverview(tableByName.get(name)) : renderTable(tableByName.get(name))).join("");
    return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="color-scheme" content="light">
  <title>${escapeHtml(title)}</title>
  <style>
    :root{--ink:#17313a;--muted:#667c83;--line:#dbe7e5;--paper:#fff;--canvas:#f2f7f6;--deep:#074d4c;--teal:#0f766e;--mint:#dff5ef;--subject:#eaf3ff;--subject-ink:#185a91;--competitor:#fff1df;--competitor-ink:#a85b12;--difference:#f3ecff;--up:#d33c32;--down:#087f5b;--shadow:0 14px 38px rgba(23,49,58,.09)}
    *{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;color:var(--ink);background:radial-gradient(circle at 85% 0,#dff4ef 0,transparent 28rem),var(--canvas);font:14px/1.55 -apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei","Segoe UI",sans-serif;font-variant-numeric:tabular-nums}.hero{padding:42px max(24px,calc((100vw - 1680px)/2));color:#fff;background:linear-gradient(120deg,#063f43,#086660 58%,#109070)}.eyebrow{margin:0 0 8px;color:#aee9dd;font-weight:700;letter-spacing:.14em}.hero h1{margin:0;font-size:clamp(28px,4vw,46px);line-height:1.15}.hero-meta{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:18px}.hero-meta span{padding:6px 11px;border:1px solid rgba(255,255,255,.22);border-radius:999px;background:rgba(255,255,255,.08)}.actions{margin-left:auto}.actions button{padding:8px 13px;color:#084c49;background:#fff;border:0;border-radius:8px;cursor:pointer;font:inherit;font-weight:700}.nav-wrap{position:sticky;top:0;z-index:30;padding:0 max(18px,calc((100vw - 1680px)/2));background:rgba(255,255,255,.94);border-bottom:1px solid var(--line);backdrop-filter:blur(12px)}nav{display:flex;gap:4px;overflow:auto}nav a{flex:0 0 auto;padding:14px 16px;color:#426069;text-decoration:none;border-bottom:3px solid transparent}nav a:hover,nav a:focus{color:var(--teal);border-color:var(--teal)}main{display:grid;gap:22px;max-width:1680px;margin:26px auto;padding:0 18px 42px}.report-section{scroll-margin-top:72px;padding:24px;background:var(--paper);border:1px solid var(--line);border-radius:16px;box-shadow:var(--shadow)}.section-heading{display:flex;align-items:center;justify-content:space-between;gap:14px}.section-heading>div{display:flex;align-items:center;gap:10px}.section-index{margin:0;padding:4px 8px;color:#fff;background:var(--teal);border-radius:7px;font-size:11px;font-weight:800}.section-heading h2{margin:0;font-size:22px}.row-total{padding:4px 9px;color:var(--teal);background:var(--mint);border-radius:999px;font-size:12px}.section-note{margin:12px 0 18px;padding:10px 12px;color:#49666d;background:#f1f8f6;border-left:3px solid #52aa96;border-radius:6px}.period-layout{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.period-block{overflow:hidden;border:1px solid var(--line);border-radius:13px;background:#fbfdfd}.period-title{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 14px;color:#fff;background:linear-gradient(90deg,#0f766e,#399b86)}.period-title span{font-weight:800}.period-title small{color:#d9f5ee}.metric-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;padding:12px}.metric-card{padding:13px;border:1px solid #e1ecea;border-radius:10px;background:#fff}.metric-card p{margin:0;color:var(--muted);font-size:12px}.metric-card>strong{display:block;margin:6px 0 10px;color:#103d46;font-size:22px}.metric-card dl{display:grid;gap:4px;margin:0}.metric-card dl div{display:flex;justify-content:space-between;gap:8px}.metric-card dt{color:#789097}.metric-card dd{margin:0;font-weight:700}.subheading{margin:22px 0 12px;font-size:16px}.extra-table{overflow:auto}.extra-table table{min-width:100%}.table-tools{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:0 0 10px;color:var(--muted);font-size:12px}.table-tools label{display:flex;align-items:center;gap:8px}.table-tools input{width:min(280px,48vw);padding:7px 9px;border:1px solid #bed3cf;border-radius:8px;outline:none;font:inherit}.table-tools input:focus{border-color:var(--teal);box-shadow:0 0 0 3px rgba(15,118,110,.11)}.table-shell{max-height:72vh;overflow:auto;border:1px solid var(--line);border-radius:10px}.table-shell table,.extra-table table{width:100%;border-collapse:separate;border-spacing:0;font-size:12px}th,td{padding:9px 10px;border-right:1px solid #e4eceb;border-bottom:1px solid #e4eceb;text-align:left;white-space:nowrap}th{position:sticky;top:0;z-index:8;color:#fff;background:#0d716b;font-weight:700}tbody tr:nth-child(even)>td{background-color:#f9fbfb}tbody tr:hover>td{background-color:#eef8f5}.numeric{text-align:right}.role-subject{color:var(--subject-ink);background-color:var(--subject)!important}.role-competitor{color:var(--competitor-ink);background-color:var(--competitor)!important}.role-difference{background-color:var(--difference)!important}.trend-up{color:var(--up)!important}.trend-down{color:var(--down)!important}.sticky-col{position:sticky;left:var(--sticky-left);z-index:5;background:#fff}.row-parent>td{font-weight:700;border-top:2px solid #9fcfc4}.row-parent>.sticky-col{background:#edf8f5}.row-child .source-cell{white-space:pre;color:#5d747a}.row-subject>td:first-child,.row-subject .source-cell{box-shadow:inset 3px 0 #5b9bd5}.row-competitor>td:first-child,.row-competitor .source-cell{box-shadow:inset 3px 0 #f0a74f}thead .sticky-col{z-index:12;background:#0b615d}.extra-table th{position:static}.extra-table td:nth-child(n+2){text-align:right}.compact .extra-table{padding:12px}.footer{max-width:1680px;margin:0 auto 30px;padding:0 20px;color:#73898e;text-align:center;font-size:12px}[hidden]{display:none!important}
    @media(max-width:900px){.hero{padding:30px 20px}.actions{width:100%;margin-left:0}.period-layout{grid-template-columns:1fr}.report-section{padding:16px}.metric-grid{grid-template-columns:1fr}.nav-wrap{padding:0 8px}}
    .brand-watermark{position:fixed;inset:-8%;z-index:999;display:grid;grid-template-columns:repeat(4,1fr);align-content:space-around;gap:76px 32px;pointer-events:none;transform:rotate(-17deg);overflow:hidden}.brand-watermark span{color:rgba(13,113,107,.06);font-size:17px;font-weight:800;letter-spacing:.12em;text-align:center;white-space:nowrap}.print-disabled{display:none}
    @media print{body>*:not(.print-disabled){display:none!important}.print-disabled{display:flex!important;align-items:center;justify-content:center;min-height:90vh;padding:40px;color:#173d31;font-size:18px;font-weight:800;text-align:center}}
  </style>
</head>
<body>
  <div class="brand-watermark" aria-hidden="true">${watermark}</div>
  <div class="print-disabled">当前版本仅支持官网在线查看，暂不支持打印或导出。</div>
  <header class="hero">
    <p class="eyebrow">DAMOPAN · COMPETITION SITUATION</p>
    <h1>${escapeHtml(title)}</h1>
    <div class="hero-meta"><span>本店 ID：${escapeHtml(report.subjectId || "—")}</span><span>竞店：${escapeHtml((report.competitorIds || []).join("、") || report.competitorId || "—")}</span><span>生成时间：${escapeHtml(formatGeneratedAt(generatedAt))}</span></div>
  </header>
  <div class="nav-wrap"><nav aria-label="报告目录">${nav}</nav></div>
  <main>${sections}</main>
  <footer class="footer">达摩盘竞争态势分析自动取数报告｜少壮AI自动化</footer>
  <script>
    (() => {
      document.querySelectorAll('[data-table-filter]').forEach((input) => {
        const section = input.closest('.report-section');
        const rows = [...section.querySelectorAll('tbody tr')];
        const count = section.querySelector('[data-filter-count]');
        input.addEventListener('input', () => {
          const keyword = input.value.trim().toLocaleLowerCase('zh-CN');
          let visible = 0;
          rows.forEach((row) => {
            const matched = !keyword || row.textContent.toLocaleLowerCase('zh-CN').includes(keyword);
            row.hidden = !matched;
            if (matched) visible += 1;
          });
          if (count) count.textContent = visible + ' / ' + rows.length;
        });
      });
    })();
  </script>
</body>
</html>`;
  }

  return { MIME_TYPE, REQUIRED_TABLES, buildHtml, escapeHtml, formatValue };
});
