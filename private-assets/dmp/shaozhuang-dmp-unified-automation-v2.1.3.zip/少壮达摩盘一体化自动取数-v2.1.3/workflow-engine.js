(function initDmpWorkflowEngine(root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.DmpWorkflowEngine = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function createDmpWorkflowEngine() {
  "use strict";

  const COMPARISON_TABS = ["关键指标对比", "推广策略对比", "人群对比"];
  const MAX_AUTO_RECAPTURE_ATTEMPTS = 3;
  const SCENE_CHANNELS = ["关键词推广", "人群推广", "线索推广", "货品全站推", "店铺运营", "货品运营", "内容营销"];
  const SCENE_PARENT_CHANNELS = {
    "371": "关键词推广",
    "372": "人群推广",
    "376": "货品运营",
    "377": "店铺运营",
    "379": "内容营销",
    "395": "线索推广",
    "435": "货品全站推",
    "436": "货品全站推"
  };
  const SUCCESS_ENTRY_LABELS = ["取得成功品", "获取成功品", "定制成功品", "选择成功品", "设置成功品", "添加成功品", "切换成功品", "修改成功品"];
  const SUCCESS_CLEAR_LABELS = ["全部删除", "清空全部", "全部移除", "全部清除"];

  // 这些值对应“定制成功品”弹窗中用户截图展示的筛选状态。
  const SUCCESS_FILTERS = [
    { key: "priceBand", label: "价格带", selected: ["全部价格带"], options: ["全选"] },
    { key: "growthCycle", label: "打爆周期", selected: ["新品打爆期", "爆品期"], options: ["新品打爆期", "爆品期"] },
    { key: "onlineCycle", label: "上架周期", selected: ["全部上架周期"], options: ["全选"] },
    { key: "rankLevel", label: "TOP水位", selected: ["TOP0.5%以内"], options: ["TOP0.5%以内"] },
    { key: "salesLevel", label: "销售额水位", selected: ["1000w以上", "500万~1000万"], options: ["1000w以上", "500万~1000万"] }
  ];

  function normalizeText(value) {
    return String(value || "").replace(/\s+/g, "").replace(/[～—–]/g, "~").trim();
  }

  function pad2(value) {
    return String(value).padStart(2, "0");
  }

  function localDate(value) {
    return `${value.getFullYear()}-${pad2(value.getMonth() + 1)}-${pad2(value.getDate())}`;
  }

  function periodEndingAtLatestDay(days = 30, latestDay = "") {
    const count = Number.isInteger(days) && days > 0 ? days : 30;
    const match = String(latestDay || "").trim().match(/^(\d{4})-?(\d{2})-?(\d{2})$/);
    if (!match) return null;
    const endTime = Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
    const end = new Date(endTime);
    if (end.getUTCFullYear() !== Number(match[1]) || end.getUTCMonth() !== Number(match[2]) - 1 || end.getUTCDate() !== Number(match[3])) return null;
    const start = new Date(endTime - (count - 1) * 86400000);
    const utcDate = value => `${value.getUTCFullYear()}-${pad2(value.getUTCMonth() + 1)}-${pad2(value.getUTCDate())}`;
    return { startDate: utcDate(start), endDate: utcDate(end), days: count };
  }

  function pastCompletedDays(days = 30, now = new Date()) {
    const count = Number.isInteger(days) && days > 0 ? days : 30;
    const end = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
    return periodEndingAtLatestDay(count, localDate(end));
  }

  function buildGrowupRouteHash(itemId, nonce = Date.now()) {
    const value = String(itemId || "").trim();
    if (!/^\d{6,20}$/.test(value)) throw new Error("商品 ID 必须是 6–20 位数字");
    return `#!/items/growup-path?spm=&itemId=${encodeURIComponent(value)}&dmpReportTask=${encodeURIComponent(String(nonce))}`;
  }

  function selectedSuccessCount(value) {
    const match = normalizeText(value).match(/已选成功品[（(]?(\d+)\/(\d+)项?[）)]?/);
    return match ? Number(match[1]) : null;
  }

  function buildRecapturePlan(report, job = {}) {
    const quality = report?.quality || {};
    const issues = [...(quality.blockingIssues || []), ...(quality.warnings || [])].map(String);
    const issueText = issues.join("\n");
    const missingModules = new Set((quality.endpointStatus || []).filter(status => !status.usable).map(status => status.module));
    const failedPaths = (quality.endpointCoverage || []).filter(entry => entry.failed > 0).map(entry => String(entry.path || "")).filter(Boolean);
    const missingValues = (quality.deterministicMissing || []).map(String);
    const tabFailures = (job.tabFailures || []).join("\n");
    const tabs = new Set();
    const reasons = new Set(issues);
    const requests = new Map();
    const addRequest = (path, label, details = {}) => {
      const sceneLevel1Id = String(details.sceneLevel1Id || "");
      const key = `${path}|${sceneLevel1Id}`;
      if (!requests.has(key)) requests.set(key, { path, label, ...(sceneLevel1Id ? { sceneLevel1Id } : {}) });
    };

    const routePatterns = /商品概况|主体商品|成长趋势|成长阶段|日趋势|五渠道消耗|GMV 序列|精确周期GMV|\/api\/goods\/item\/info|\/api\/goods\/grow\/define\/line\/data/;
    const successPatterns = /目标成功品[^\n]*(?:未能|缺少|未匹配)|成功品接口|\/api\/goods\/grow\/define\/success/;
    const corePatterns = /核心指标|成交笔数|笔单价|总GMV|访客数|完全一致的核心指标卡|\/dataplatform\/dataset\/report\/query/;
    const scenePatterns = /投放场景|场景明细|一级场景|二级明细|场景金额|推广消耗|费比|ROAS|\/api\/goods\/grow\/comparison\/scene(?:\s|:|$)/;
    const keywordPatterns = /关键词响应|关键词样本|\/api\/goods\/grow\/comparison\/scene\/keyword/;
    const periodPatterns = /目标业务周期起止日期|目标周期自然日|日期未|日期控件|30\s*天/;

    const reloadRoute = missingModules.has("商品概况") || missingModules.has("成长阶段与趋势") ||
      routePatterns.test(issueText) || failedPaths.some(path => /item\/info|goods\/grow\/line$|define\/line\/data/.test(path)) ||
      missingValues.some(label => /^对手(?:推广消耗|费比|全域ROAS)$/.test(label));
    const reselectSuccess = missingModules.has("成功品") || successPatterns.test(issueText) ||
      failedPaths.some(path => /define\/success/.test(path));
    const needsCore = missingModules.has("核心指标") || corePatterns.test(issueText) ||
      failedPaths.some(path => /dataplatform\/dataset\/report\/query/.test(path)) ||
      missingValues.some(label => /成交笔数|笔单价|总GMV|访客数/.test(label));
    const needsScenes = missingModules.has("投放场景") || scenePatterns.test(issueText) ||
      failedPaths.some(path => /comparison\/scene$/.test(path)) ||
      missingValues.some(label => /^主体(?:推广消耗|费比|全域ROAS)$/.test(label));
    const needsKeywords = missingModules.has("关键词样本") || keywordPatterns.test(issueText) ||
      failedPaths.some(path => /comparison\/scene\/keyword/.test(path));
    const needsPeriod = periodPatterns.test(issueText);

    if (missingModules.has("商品概况") || failedPaths.some(path => /\/api\/goods\/item\/info/.test(path)) || /主体商品/.test(issueText)) {
      addRequest("/api/goods/item/info", "商品概况");
    }
    if (missingModules.has("成长阶段与趋势") || failedPaths.some(path => /define\/line\/data/.test(path)) || routePatterns.test(issueText)
      || missingValues.some(label => /^对手(?:推广消耗|费比|全域ROAS)$/.test(label))) {
      addRequest("/api/goods/grow/define/line/data", "日趋势");
    }
    if (missingModules.has("成功品") || failedPaths.some(path => /define\/success/.test(path)) || successPatterns.test(issueText)) {
      addRequest("/api/goods/grow/define/success/load", "成功品");
    }
    if (needsCore) addRequest("/dataplatform/dataset/report/query", "核心指标");
    const hasSpecificSceneParent = /二级明细响应：[\d、,，\s]+/.test(issueText);
    if (needsScenes && !hasSpecificSceneParent) addRequest("/api/goods/grow/comparison/scene", "一级场景");
    if (needsKeywords) addRequest("/api/goods/grow/comparison/scene/keyword", "关键词");
    if (needsPeriod) {
      addRequest("/api/goods/grow/define/line/data", "日趋势");
      addRequest("/dataplatform/dataset/report/query", "核心指标");
      addRequest("/api/goods/grow/comparison/scene", "一级场景");
      addRequest("/api/goods/grow/comparison/scene/keyword", "关键词");
    }

    if (needsCore || reloadRoute) tabs.add("关键指标对比");
    if (needsScenes || needsKeywords) tabs.add("推广策略对比");
    if (needsPeriod) COMPARISON_TABS.forEach(label => tabs.add(label));
    COMPARISON_TABS.forEach(label => {
      if (tabFailures.includes(label)) tabs.add(label);
    });
    if (job.periodPrecision === "failed" && !needsPeriod) {
      const results = new Map((job.tabResults || []).map(result => [result.label, result]));
      COMPARISON_TABS.forEach(label => {
        const result = results.get(label);
        if (!result || !result.periodConfirmed || result.periodPrecision === "failed") tabs.add(label);
      });
    }

    const missingSceneChannels = new Set((job.sceneMissed || []).filter(channel => SCENE_CHANNELS.includes(channel)));
    const parentMatch = issueText.match(/二级明细响应：([\d、,，\s]+)/);
    if (parentMatch) {
      parentMatch[1].split(/[、,，\s]+/).filter(Boolean).forEach(parentId => {
        const channel = SCENE_PARENT_CHANNELS[parentId];
        if (channel) {
          missingSceneChannels.add(channel);
          addRequest("/api/goods/grow/comparison/scene", `${channel}二级场景`, { sceneLevel1Id: parentId });
        }
      });
    }
    if (needsScenes && !missingSceneChannels.size) SCENE_CHANNELS.forEach(channel => missingSceneChannels.add(channel));
    if (needsKeywords && !needsScenes) missingSceneChannels.add("关键词推广");
    if (failedPaths.some(path => /comparison\/scene$/.test(path))) {
      missingSceneChannels.clear();
      SCENE_CHANNELS.forEach(channel => missingSceneChannels.add(channel));
    }
    if (needsScenes) {
      for (const channel of missingSceneChannels) {
        const parentId = Object.entries(SCENE_PARENT_CHANNELS).find(([, name]) => name === channel)?.[0];
        if (parentId) addRequest("/api/goods/grow/comparison/scene", `${channel}二级场景`, { sceneLevel1Id: parentId });
      }
    }

    const replaceablePath = /^(?:\/api\/goods\/item\/info|\/api\/goods\/grow\/line|\/api\/goods\/grow\/define\/success(?:\/load|\/item\/list)?|\/api\/goods\/grow\/define\/line\/data|\/api\/goods\/grow\/comparison\/scene(?:\/keyword)?|\/dataplatform\/dataset\/report\/query)$/;
    const clearPaths = new Set(failedPaths.filter(path => replaceablePath.test(path)));

    if (!requests.size && !reselectSuccess) reasons.add("暂时无法自动定位缺失项，请重新运行当前任务");

    const summary = [...requests.values()].map(request => request.label);
    if (reselectSuccess) summary.push("目标成功品选择");

    return {
      reloadRoute,
      reselectSuccess,
      tabs: [...tabs],
      sceneChannels: [...missingSceneChannels],
      clearPaths: [...clearPaths],
      requests: [...requests.values()],
      reasons: [...reasons],
      summary: summary.length ? summary.join("、") : "暂无可自动补充的数据"
    };
  }

  function qualityGapSnapshot(report) {
    const quality = report?.quality || {};
    const missingModules = (quality.endpointStatus || [])
      .filter(status => !status.usable)
      .map(status => `模块:${status.module}`);
    const failedEndpoints = (quality.endpointCoverage || [])
      .filter(entry => Number(entry.failed) > 0)
      .map(entry => `接口:${entry.path}:${entry.failed}`);
    const blockingIssues = (quality.blockingIssues || []).map(issue => `阻断:${issue}`);
    const deterministicMissing = (quality.deterministicMissing || []).map(label => `关键值:${label}`);
    const gaps = [...new Set([...missingModules, ...failedEndpoints, ...blockingIssues, ...deterministicMissing].map(String))].sort();
    const requiredValues = Number(quality.requiredValues) || (quality.deterministicMissing ? quality.deterministicMissing.length : 0);
    const resolvedValues = Number.isFinite(Number(quality.resolvedValues))
      ? Number(quality.resolvedValues)
      : Math.max(0, requiredValues - (quality.deterministicMissing || []).length);
    return {
      gaps,
      gapCount: gaps.length,
      signature: gaps.join("\n"),
      requiredValues,
      resolvedValues,
      observedModules: Number(quality.observed) || 0,
      expectedModules: Number(quality.expected) || 0,
      parsedRecords: Number(quality.parsedRecords) || 0,
      failedRecords: Number(quality.failedRecords) || 0
    };
  }

  // 感知层不再把“接口出现过”当作“数据完整”。它同时比较关键值、阻断项、
  // 失败响应和上一轮缺口指纹；有进展就继续定向补抓，连续两轮完全无增量时
  // 停止自动循环并保留人工重试入口，避免页面异常造成无限点击。
  function assessRecaptureNeed(report, job = {}) {
    const snapshot = qualityGapSnapshot(report);
    if (report?.quality?.complete === true) {
      return {
        state: "complete", needsRecapture: false, autoRecapture: false, actionable: false,
        attemptCount: (job.recaptureAttempts || []).length, maxAutoAttempts: MAX_AUTO_RECAPTURE_ATTEMPTS,
        stagnantRounds: 0, snapshot, plan: null, reason: "关键数据已完整"
      };
    }

    const plan = buildRecapturePlan(report, job);
    const attempts = Array.isArray(job.recaptureAttempts) ? job.recaptureAttempts : [];
    const lastAttempt = attempts.at(-1) || null;
    const previousAttempt = attempts.at(-2) || null;
    const unchanged = Boolean(lastAttempt?.beforeSignature && lastAttempt.beforeSignature === snapshot.signature);
    const stagnantRounds = unchanged ? Number(previousAttempt?.stagnantRounds || 0) + 1 : 0;
    const actionable = Boolean(plan.requests.length || plan.reselectSuccess || plan.tabs.length || plan.reloadRoute);
    const exhausted = attempts.length >= MAX_AUTO_RECAPTURE_ATTEMPTS;
    const stalled = stagnantRounds >= 2;
    const autoRecapture = actionable && !exhausted && !stalled && attempts.length > 0;
    const state = !actionable ? "unactionable" : exhausted ? "exhausted" : stalled ? "stalled" : "retry-needed";
    const reason = !actionable
      ? "仍有缺失项，但暂时无法自动补充"
      : exhausted
        ? `仍有缺失项，已完成 ${MAX_AUTO_RECAPTURE_ATTEMPTS} 次自动补充`
        : stalled
          ? "连续两轮补充后仍无新增数据，已停止自动处理"
          : unchanged
            ? "本轮仍无新增数据，切换页面后再补充一次"
            : "关键数据尚未完整，继续自动补充";
    return {
      state,
      needsRecapture: true,
      autoRecapture,
      actionable,
      attemptCount: attempts.length,
      maxAutoAttempts: MAX_AUTO_RECAPTURE_ATTEMPTS,
      stagnantRounds,
      snapshot,
      plan,
      reason
    };
  }

  return {
    COMPARISON_TABS, MAX_AUTO_RECAPTURE_ATTEMPTS, SCENE_CHANNELS, SUCCESS_ENTRY_LABELS, SUCCESS_CLEAR_LABELS, SUCCESS_FILTERS,
    normalizeText, periodEndingAtLatestDay, pastCompletedDays, buildGrowupRouteHash, selectedSuccessCount,
    buildRecapturePlan, qualityGapSnapshot, assessRecaptureNeed
  };
});
