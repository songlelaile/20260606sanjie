(function initDmpHtmlWriter(root, factory) {
  const reportEngine = root.DmpReportEngine || (typeof module === "object" && module.exports ? require("./report-engine.js") : null);
  const api = factory(reportEngine);
  if (typeof module === "object" && module.exports) module.exports = api;
  root.DmpHtmlWriter = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function createDmpHtmlWriter(reportEngine) {
  "use strict";

  const MIME_TYPE = "text/html;charset=utf-8";
  const REQUIRED_TABLES = Object.freeze([
    "报告总览", "对标总表", "商品与成功品", "周期汇总", "日GMV与费比", "渠道花费",
    "一级场景", "二级场景", "成长阶段数据", "基础指标对比", "关键词样本"
  ]);
  const SECTION_IDS = Object.freeze({
    报告总览: "overview",
    对标总表: "benchmark",
    商品与成功品: "products",
    周期汇总: "period",
    日GMV与费比: "daily",
    渠道花费: "channel",
    一级场景: "scene-primary",
    二级场景: "scene-secondary",
    成长阶段数据: "stages",
    基础指标对比: "metrics",
    关键词样本: "keywords",
  });
  const FREEZE_COLUMNS = Object.freeze({
    对标总表: 2,
    商品与成功品: 3,
    周期汇总: 2,
    日GMV与费比: 1,
    渠道花费: 2,
    一级场景: 3,
    二级场景: 4,
    成长阶段数据: 4,
    基础指标对比: 1,
    关键词样本: 3,
  });

  function escapeHtml(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function isMissing(value) {
    return value === null || value === undefined || value === "" || value === "—";
  }

  function isPercentSemantic(value) {
    const text = String(value || "");
    if (/排名变化/.test(text)) return false;
    if (/变化|变动|相对|环比|同比|差异|提升|下降/.test(text)) return true;
    return !/投入产出比|投产比|ROI|ROAS/i.test(text) && /比|率|变化|相对|CTR|贡献|百分位/i.test(text);
  }

  function isIntegerSemantic(value) {
    return /天数|层级|成交笔数|展现|点击|访客|数量/i.test(String(value || ""));
  }

  function semanticFor(table, row, columnIndex) {
    const column = String(table.columns?.[columnIndex] || "");
    if (table.name === "对标总表") return `${column} ${row?.[1] || ""}`;
    if (table.name === "基础指标对比") return `${column} ${row?.[0] || ""}`;
    return column;
  }

  function formatValue(value, semantic = "") {
    if (isMissing(value)) return "—";
    if (typeof reportEngine?.formatMetricValue === "function") {
      const formatted = reportEngine.formatMetricValue(semantic, value);
      if (formatted !== "" && formatted !== null && formatted !== undefined) return String(formatted);
    }
    if (typeof value !== "number" || !Number.isFinite(value)) {
      if (typeof value === "object") {
        try { return JSON.stringify(value); } catch { return String(value); }
      }
      return String(value);
    }
    if (isPercentSemantic(semantic)) return new Intl.NumberFormat("zh-CN", { style: "percent", minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value);
    if (isIntegerSemantic(semantic)) return new Intl.NumberFormat("zh-CN", { maximumFractionDigits: 0 }).format(value);
    return new Intl.NumberFormat("zh-CN", { minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(value);
  }

  function formatGeneratedAt(value) {
    const date = new Date(value || Date.now());
    if (Number.isNaN(date.getTime())) return String(value || "");
    return new Intl.DateTimeFormat("zh-CN", {
      year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false,
    }).format(date).replace(/\//g, "-");
  }

  function columnWidth(table, columnIndex) {
    return Math.max(88, Math.min(460, Math.round((Number(table.widths?.[columnIndex]) || 15) * 6.6)));
  }

  function stickyOffsets(table) {
    const count = Math.max(0, Number(FREEZE_COLUMNS[table.name]) || 0);
    const offsets = [];
    let left = 0;
    for (let index = 0; index < count; index += 1) {
      offsets[index] = left;
      left += columnWidth(table, index);
    }
    return offsets;
  }

  function columnRole(table, columnIndex) {
    const column = String(table.columns?.[columnIndex] || "");
    if (table.name === "对标总表") return columnIndex === 2 ? "subject" : columnIndex === 3 ? "competitor" : columnIndex === 4 ? "difference" : "";
    if (table.name === "基础指标对比") return columnIndex === 1 ? "subject" : columnIndex === 2 ? "competitor" : columnIndex === 3 ? "difference" : "";
    if (/^主体/.test(column)) return "subject";
    if (/^(对手|目标对手)/.test(column)) return "competitor";
    if (/相对对手/.test(column)) return "difference";
    return "";
  }

  function rowRole(row) {
    const first = String(row?.[0] || "");
    const second = String(row?.[1] || "");
    if (/^主体/.test(first) || /^主体/.test(second)) return "subject";
    if (/目标对手|^对手|^竞品/.test(first) || /目标对手|^对手/.test(second)) return "competitor";
    return "";
  }

  function roleClass(role) {
    if (role === "subject") return " role-subject";
    if (role === "competitor") return " role-competitor";
    if (role === "difference") return " role-difference";
    return "";
  }

  function trendClass(value, role) {
    if (role !== "difference" || typeof value !== "number" || !Number.isFinite(value) || value === 0) return "";
    return value > 0 ? " trend-up" : " trend-down";
  }

  function wrapColumn(column) {
    return /标题|描述|打法|细节|动作|标签|图片|详情/.test(String(column || ""));
  }

  function renderTable(table) {
    const offsets = stickyOffsets(table);
    const head = table.columns.map((column, columnIndex) => {
      const width = columnWidth(table, columnIndex);
      const offset = offsets[columnIndex];
      const sticky = offset == null ? "" : " sticky-col";
      const style = `${offset == null ? "" : `--sticky-left:${offset}px;`}min-width:${width}px;width:${width}px`;
      return `<th class="${roleClass(columnRole(table, columnIndex)).trim()}${sticky}" style="${style}">${escapeHtml(column)}</th>`;
    }).join("");
    const body = table.rows.map((row, rowIndex) => {
      const rowClass = roleClass(rowRole(row));
      const cells = table.columns.map((column, columnIndex) => {
        const width = columnWidth(table, columnIndex);
        const offset = offsets[columnIndex];
        const sticky = offset == null ? "" : " sticky-col";
        const style = `${offset == null ? "" : `--sticky-left:${offset}px;`}min-width:${width}px;width:${width}px`;
        const value = row?.[columnIndex];
        const role = columnRole(table, columnIndex);
        const numeric = typeof value === "number" && Number.isFinite(value) ? " numeric" : "";
        const wrap = wrapColumn(column) ? " wrap" : "";
        const classes = `${roleClass(role)}${trendClass(value, role)}${numeric}${wrap}${sticky}`.trim();
        return `<td class="${classes}" style="${style}">${escapeHtml(formatValue(value, semanticFor(table, row, columnIndex)))}</td>`;
      }).join("");
      return `<tr class="${rowClass.trim()}">${cells}</tr>`;
    }).join("");
    const sectionId = SECTION_IDS[table.name];
    const sectionNumber = String(REQUIRED_TABLES.indexOf(table.name) + 1).padStart(2, "0");
    return `<section class="report-section" id="${sectionId}">
      <div class="section-heading"><div><p class="section-index">${sectionNumber}</p><h2>${escapeHtml(table.name)}</h2></div><span class="row-total">${table.rows.length} 行</span></div>
      ${table.subtitle ? `<p class="section-note">${escapeHtml(table.subtitle)}</p>` : ""}
      <div class="table-tools"><label>筛选本表<input type="search" data-table-filter aria-label="筛选${escapeHtml(table.name)}" placeholder="输入关键词"></label><span data-filter-count>${table.rows.length} / ${table.rows.length}</span></div>
      <div class="table-shell"><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>
    </section>`;
  }

  function renderDailyChart(table) {
    const rows = (table?.rows || []).filter((row) => typeof row?.[1] === "number" && Number.isFinite(row[1]));
    if (rows.length < 2) return "";
    const width = 760;
    const height = 230;
    const padX = 30;
    const padY = 24;
    const values = rows.map((row) => row[1]);
    const maximum = Math.max(...values, 1);
    const points = values.map((value, index) => {
      const x = padX + index * (width - padX * 2) / (values.length - 1);
      const y = height - padY - value / maximum * (height - padY * 2);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(" ");
    const area = `${padX},${height - padY} ${points} ${width - padX},${height - padY}`;
    return `<article class="visual-card"><div class="visual-title"><div><strong>每日 GMV</strong><small>${escapeHtml(rows[0][0])} 至 ${escapeHtml(rows.at(-1)[0])}</small></div><span>峰值 ${escapeHtml(formatValue(maximum, "GMV"))}</span></div><svg viewBox="0 0 ${width} ${height}" role="img" aria-label="每日GMV趋势"><defs><linearGradient id="dailyArea" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#20a486" stop-opacity=".38"/><stop offset="1" stop-color="#20a486" stop-opacity=".03"/></linearGradient></defs><line x1="${padX}" y1="${height - padY}" x2="${width - padX}" y2="${height - padY}" stroke="#cbded9"/><polygon points="${area}" fill="url(#dailyArea)"/><polyline points="${points}" fill="none" stroke="#0f766e" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg></article>`;
  }

  function renderChannelChart(table) {
    if (!table) return "";
    const subjectIndex = table.columns.findIndex((column) => /^主体\d+日消耗$/.test(String(column || "")));
    const competitorIndex = table.columns.findIndex((column) => /^对手\d+日消耗$/.test(String(column || "")));
    if (subjectIndex < 0 || competitorIndex < 0) return "";
    const rows = table.rows.filter((row) => row?.[0] !== "合计").slice(0, 5);
    const values = rows.flatMap((row) => [row[subjectIndex], row[competitorIndex]]).filter((value) => typeof value === "number" && Number.isFinite(value));
    if (!values.length) return "";
    const maximum = Math.max(...values, 1);
    const bars = rows.map((row) => {
      const subject = typeof row[subjectIndex] === "number" && Number.isFinite(row[subjectIndex]) ? row[subjectIndex] : 0;
      const competitor = typeof row[competitorIndex] === "number" && Number.isFinite(row[competitorIndex]) ? row[competitorIndex] : 0;
      const subjectWidth = Math.max(0, Math.min(100, subject / maximum * 100));
      const competitorWidth = Math.max(0, Math.min(100, competitor / maximum * 100));
      return `<div class="bar-row"><strong>${escapeHtml(row[0])}</strong><div class="bar-pair"><div><span>主体</span><i class="bar-track"><b class="bar-subject" style="width:${subjectWidth.toFixed(2)}%"></b></i><em>${escapeHtml(formatValue(row[subjectIndex], table.columns[subjectIndex]))}</em></div><div><span>对手</span><i class="bar-track"><b class="bar-competitor" style="width:${competitorWidth.toFixed(2)}%"></b></i><em>${escapeHtml(formatValue(row[competitorIndex], table.columns[competitorIndex]))}</em></div></div></div>`;
    }).join("");
    return `<article class="visual-card"><div class="visual-title"><div><strong>渠道花费对比</strong><small>主体与目标对手</small></div><span>5 个渠道</span></div><div class="channel-bars">${bars}</div></article>`;
  }

  function renderOverview(table, report, tableByName) {
    const cards = (table.kpis || []).map((card, index) => {
      const role = index % 2 === 0 ? "subject" : "competitor";
      return `<article class="metric-card${roleClass(role)}"><p>${escapeHtml(card.label || "指标")}</p><strong>${escapeHtml(formatValue(card.value, card.label || ""))}</strong></article>`;
    }).join("");
    const objectRows = (table.rows || []).filter((row) => ["商品ID", "商品标题"].includes(String(row?.[0] || "")));
    const objectTable = objectRows.map((row) => `<tr><th>${escapeHtml(row[0])}</th><td class="role-subject">${escapeHtml(row[1] || "—")}</td><td class="role-competitor">${escapeHtml(row[2] || "—")}</td></tr>`).join("");
    const visuals = [renderDailyChart(tableByName.get("日GMV与费比")), renderChannelChart(tableByName.get("渠道花费"))].filter(Boolean).join("");
    return `<section class="report-section overview-section" id="overview">
      <div class="section-heading"><div><p class="section-index">01</p><h2>报告总览</h2></div><span class="row-total">${escapeHtml(report.periodLabel || "业务周期")}</span></div>
      ${table.subtitle ? `<p class="section-note">${escapeHtml(table.subtitle)}</p>` : ""}
      <div class="metric-grid">${cards}</div>
      <div class="object-panel"><div><span>分析周期</span><strong>${escapeHtml(report.period?.startDate || "—")} 至 ${escapeHtml(report.period?.endDate || "—")}</strong></div><div class="object-table"><table><thead><tr><th>对象</th><th class="role-subject">主体</th><th class="role-competitor">目标对手</th></tr></thead><tbody>${objectTable}</tbody></table></div></div>
      ${visuals ? `<h3 class="subheading">数据趋势与结构</h3><div class="visual-grid">${visuals}</div>` : ""}
    </section>`;
  }

  function assertReport(report) {
    if (!report || typeof report !== "object") throw new TypeError("缺少商品成长报告数据");
    if (report.quality?.complete !== true || report.quality?.exportAllowed !== true) throw new Error("业务数据未完整，不能生成 HTML 报告");
    const tables = Array.isArray(report.tables) ? report.tables : [];
    for (const name of REQUIRED_TABLES) {
      const current = tables.find((candidate) => candidate?.name === name);
      if (!current || !Array.isArray(current.columns) || !Array.isArray(current.rows)) throw new Error(`HTML 报告缺少“${name}”数据表`);
    }
  }

  function buildHtml(report, options = {}) {
    assertReport(report);
    const tableByName = new Map(report.tables.map((table) => [table.name, table]));
    const generatedAt = options.generatedAt || report.finishedAt || new Date().toISOString();
    const requestedTitle = options.title || "达摩盘商品成长竞品对标报告";
    const title = /少壮AI自动化$/.test(requestedTitle) ? requestedTitle : `${requestedTitle}｜少壮AI自动化`;
    const watermark = Array.from({ length: 36 }, () => "<span>少壮AI自动化</span>").join("");
    const nav = REQUIRED_TABLES.map((name) => `<a href="#${SECTION_IDS[name]}">${escapeHtml(name)}</a>`).join("");
    const sections = REQUIRED_TABLES.map((name) => name === "报告总览" ? renderOverview(tableByName.get(name), report, tableByName) : renderTable(tableByName.get(name))).join("");
    return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="color-scheme" content="light">
  <title>${escapeHtml(title)}</title>
  <style>
    :root{--ink:#17313a;--muted:#667c83;--line:#dbe7e5;--paper:#fff;--canvas:#f2f7f6;--deep:#074d4c;--teal:#0f766e;--mint:#dff5ef;--subject:#eaf3ff;--subject-ink:#185a91;--competitor:#fff1df;--competitor-ink:#a85b12;--difference:#f3ecff;--up:#d33c32;--down:#087f5b;--shadow:0 14px 38px rgba(23,49,58,.09)}
    *{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;color:var(--ink);background:radial-gradient(circle at 85% 0,#dff4ef 0,transparent 28rem),var(--canvas);font:14px/1.55 -apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei","Segoe UI",sans-serif;font-variant-numeric:tabular-nums}.hero{padding:42px max(24px,calc((100vw - 1720px)/2));color:#fff;background:linear-gradient(120deg,#063f43,#086660 58%,#109070)}.eyebrow{margin:0 0 8px;color:#aee9dd;font-weight:700;letter-spacing:.14em}.hero h1{margin:0;font-size:clamp(28px,4vw,46px);line-height:1.15}.hero-meta{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:18px}.hero-meta span{padding:6px 11px;border:1px solid rgba(255,255,255,.22);border-radius:999px;background:rgba(255,255,255,.08)}.actions{margin-left:auto}.actions button{padding:8px 13px;color:#084c49;background:#fff;border:0;border-radius:8px;cursor:pointer;font:inherit;font-weight:700}.nav-wrap{position:sticky;top:0;z-index:30;padding:0 max(18px,calc((100vw - 1720px)/2));background:rgba(255,255,255,.94);border-bottom:1px solid var(--line);backdrop-filter:blur(12px)}nav{display:flex;gap:4px;overflow:auto}nav a{flex:0 0 auto;padding:14px 15px;color:#426069;text-decoration:none;border-bottom:3px solid transparent}nav a:hover,nav a:focus{color:var(--teal);border-color:var(--teal)}main{display:grid;gap:22px;max-width:1720px;min-width:0;margin:26px auto;padding:0 18px 42px}.report-section{min-width:0;scroll-margin-top:72px;padding:24px;background:var(--paper);border:1px solid var(--line);border-radius:16px;box-shadow:var(--shadow)}.section-heading{display:flex;align-items:center;justify-content:space-between;gap:14px}.section-heading>div{display:flex;align-items:center;gap:10px}.section-index{margin:0;padding:4px 8px;color:#fff;background:var(--teal);border-radius:7px;font-size:11px;font-weight:800}.section-heading h2{margin:0;font-size:22px}.row-total{padding:4px 9px;color:var(--teal);background:var(--mint);border-radius:999px;font-size:12px}.section-note{margin:12px 0 18px;padding:10px 12px;color:#49666d;background:#f1f8f6;border-left:3px solid #52aa96;border-radius:6px}.metric-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;min-width:0}.metric-card{min-width:0;padding:16px;border:1px solid var(--line);border-radius:12px;background:#fff}.metric-card p{margin:0;color:var(--muted);font-size:12px}.metric-card strong{display:block;margin-top:8px;color:#103d46;font-size:25px}.object-panel{display:grid;grid-template-columns:minmax(260px,.55fr) minmax(0,1.45fr);gap:14px;min-width:0;margin-top:16px}.object-panel>div:first-child{display:flex;flex-direction:column;justify-content:center;padding:16px;color:#fff;background:linear-gradient(135deg,#0b5e5c,#158875);border-radius:12px}.object-panel span{color:#c8eee6;font-size:12px}.object-panel strong{margin-top:5px;font-size:17px}.object-table{min-width:0;overflow:auto;border:1px solid var(--line);border-radius:12px}.object-table table{width:100%;border-collapse:collapse}.object-table th,.object-table td{position:static}.subheading{margin:22px 0 12px;font-size:16px}.visual-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;min-width:0}.visual-card{min-width:0;overflow:hidden;padding:15px;border:1px solid var(--line);border-radius:12px;background:#fbfdfd}.visual-title{display:flex;align-items:flex-start;justify-content:space-between;gap:12px}.visual-title strong{display:block;font-size:16px}.visual-title small{display:block;margin-top:2px;color:var(--muted)}.visual-title>span{color:var(--teal);font-size:12px}.visual-card svg{display:block;width:100%;height:auto;margin-top:8px}.channel-bars{display:grid;gap:10px;margin-top:13px}.bar-row{display:grid;grid-template-columns:92px minmax(0,1fr);gap:9px;align-items:start}.bar-row>strong{font-size:12px}.bar-pair{display:grid;gap:5px}.bar-pair>div{display:grid;grid-template-columns:30px minmax(70px,1fr) 78px;gap:6px;align-items:center}.bar-pair span{color:var(--muted);font-size:11px}.bar-track{display:block;height:7px;overflow:hidden;background:#e7efed;border-radius:999px}.bar-track b{display:block;height:100%;border-radius:999px}.bar-subject{background:#5b9bd5}.bar-competitor{background:#ed9a46}.bar-pair em{font-style:normal;text-align:right;font-size:11px}.table-tools{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:12px 0 10px;color:var(--muted);font-size:12px}.table-tools label{display:flex;align-items:center;gap:8px}.table-tools input{width:min(280px,48vw);padding:7px 9px;border:1px solid #bed3cf;border-radius:8px;outline:none;font:inherit}.table-tools input:focus{border-color:var(--teal);box-shadow:0 0 0 3px rgba(15,118,110,.11)}.table-shell{width:100%;max-width:100%;min-width:0;max-height:72vh;overflow:auto;border:1px solid var(--line);border-radius:10px}.table-shell table{width:100%;border-collapse:separate;border-spacing:0;font-size:12px}th,td{padding:9px 10px;border-right:1px solid #e4eceb;border-bottom:1px solid #e4eceb;text-align:left;white-space:nowrap}th{position:sticky;top:0;z-index:8;color:#fff;background:#0d716b;font-weight:700}tbody tr:nth-child(even)>td{background-color:#f9fbfb}tbody tr:hover>td{background-color:#eef8f5}.numeric{text-align:right}.wrap{white-space:normal;line-height:1.55}.role-subject{color:var(--subject-ink);background-color:var(--subject)!important}.role-competitor{color:var(--competitor-ink);background-color:var(--competitor)!important}.role-difference{background-color:var(--difference)!important}.trend-up{color:var(--up)!important}.trend-down{color:var(--down)!important}.sticky-col{position:sticky;left:var(--sticky-left);z-index:5;background:#fff}.role-subject>.sticky-col,.row-subject>.sticky-col{background:var(--subject)!important}.role-competitor>.sticky-col,.row-competitor>.sticky-col{background:var(--competitor)!important}thead .sticky-col{z-index:12;background:#0b615d}.footer{max-width:1720px;margin:0 auto 30px;padding:0 20px;color:#73898e;text-align:center;font-size:12px}[hidden]{display:none!important}
    @media(max-width:980px){.hero{padding:30px 20px}.actions{width:100%;margin-left:0}.report-section{padding:16px}.metric-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.visual-grid,.object-panel{grid-template-columns:1fr}.nav-wrap{padding:0 8px}}
    @media(max-width:560px){.metric-grid{grid-template-columns:1fr}.bar-row{grid-template-columns:1fr}}
    .brand-watermark{position:fixed;inset:-8%;z-index:999;display:grid;grid-template-columns:repeat(4,1fr);align-content:space-around;gap:76px 32px;pointer-events:none;transform:rotate(-17deg);overflow:hidden}.brand-watermark span{color:rgba(13,113,107,.06);font-size:17px;font-weight:800;letter-spacing:.12em;text-align:center;white-space:nowrap}.print-disabled{display:none}
    @media print{body>*:not(.print-disabled){display:none!important}.print-disabled{display:flex!important;align-items:center;justify-content:center;min-height:90vh;padding:40px;color:#173d31;font-size:18px;font-weight:800;text-align:center}}
  </style>
</head>
<body>
  <div class="brand-watermark" aria-hidden="true">${watermark}</div>
  <div class="print-disabled">当前版本仅支持官网在线查看，暂不支持打印或导出。</div>
  <header class="hero">
    <p class="eyebrow">DAMOPAN · GROWTH BENCHMARK</p>
    <h1>${escapeHtml(title)}</h1>
    <div class="hero-meta"><span>主体：${escapeHtml(report.item?.title || "—")}（${escapeHtml(report.item?.id || "—")}）</span><span>目标对手：${escapeHtml(report.item?.competitorTitle || "—")}（${escapeHtml(report.item?.competitorId || "—")}）</span><span>生成时间：${escapeHtml(formatGeneratedAt(generatedAt))}</span></div>
  </header>
  <div class="nav-wrap"><nav aria-label="报告目录">${nav}</nav></div>
  <main>${sections}</main>
  <footer class="footer">达摩盘商品成长竞品对标报告｜少壮AI自动化</footer>
  <script>
    (() => {
      document.querySelectorAll('[data-table-filter]').forEach((input) => {
        const section = input.closest('.report-section');
        const rows = [...section.querySelectorAll('tbody tr')];
        const count = section.querySelector('[data-filter-count]');
        input.addEventListener('input', () => {
          const keyword = input.value.trim().toLocaleLowerCase('zh-CN');
          let visible = 0;
          rows.forEach((row) => {
            const matched = !keyword || row.textContent.toLocaleLowerCase('zh-CN').includes(keyword);
            row.hidden = !matched;
            if (matched) visible += 1;
          });
          if (count) count.textContent = visible + ' / ' + rows.length;
        });
      });
    })();
  </script>
</body>
</html>`;
  }

  return { MIME_TYPE, REQUIRED_TABLES, buildHtml, escapeHtml, formatValue };
});
