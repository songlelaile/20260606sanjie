const SHARE_PATH = /^\/shared\/dmp-reports\/[A-Fa-f0-9]{64}\/?$/;

export function normalizeOfficialShareUrl(value, officialSite) {
  try {
    const officialOrigin = new URL(officialSite).origin;
    const candidate = new URL(String(value || ""), `${officialOrigin}/`);
    if (!SHARE_PATH.test(candidate.pathname)) return "";
    return new URL(`${candidate.pathname}${candidate.search}${candidate.hash}`, officialOrigin).toString();
  } catch {
    return "";
  }
}
