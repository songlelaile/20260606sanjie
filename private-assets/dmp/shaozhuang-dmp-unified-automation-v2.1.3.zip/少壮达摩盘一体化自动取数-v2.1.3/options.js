(() => {
  "use strict";

  const badge = document.getElementById("cloudBadge");
  const status = document.getElementById("status");
  const test = document.getElementById("test");
  const login = document.getElementById("login");

  function message(type) {
    return chrome.runtime.sendMessage({ type });
  }

  function businessFacingText(value) {
    return String(value || "")
      .replace(/ChatGPT\s*API|\bAPI\b|\bJSON\b|\bCDP\b/gi, "云端服务")
      .replace(/\bHTTP\s*\d*/gi, "")
      .replace(/接口|响应体|请求|解析|模型/g, "数据")
      .replace(/\s{2,}/g, " ")
      .trim();
  }

  function show(text, ok = true) {
    status.textContent = businessFacingText(text);
    status.style.color = ok ? "#b7d84a" : "#ff8f7c";
    badge.textContent = ok ? "云端已连接" : "等待连接";
  }

  async function verify() {
    test.disabled = true;
    try {
      show("正在验证官网登录与云端服务…", true);
      const authorization = await message("DMP_CDP_AUTH_CHECK");
      if (!authorization?.ok) throw new Error(authorization?.error || "官网登录或工具授权无效");
      const health = await message("DMP_CDP_AI_HEALTH");
      if (!health?.ok) throw new Error(health?.error || "云端服务暂不可用");
      show("安装即用 · 数据与报告由少壮AI云端托管", true);
    } catch (error) {
      show(error?.message || String(error), false);
    } finally {
      test.disabled = false;
    }
  }

  test.addEventListener("click", () => void verify());
  login.addEventListener("click", () => void message("DMP_CDP_OPEN_LOGIN"));
  void verify();
})();
