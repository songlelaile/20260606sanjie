(() => {
  "use strict";

  if ((window.top && window.top !== window) || (globalThis.DmpUnifiedMode && globalThis.DmpUnifiedMode.current !== "growth")) return;

  const engine = globalThis.DmpReportEngine;
  const workflow = globalThis.DmpWorkflowEngine;
  const completeness = globalThis.DmpCompletenessEngine;
  const xlsxWriter = globalThis.DmpXlsxWriter;
  const htmlWriter = globalThis.DmpHtmlWriter;
  if (!engine || !workflow || !completeness || !xlsxWriter || !htmlWriter) return;
  const unifiedMode = globalThis.DmpUnifiedMode || { current: "growth", switchTo: async () => false };

  const EXTENSION_VERSION = chrome.runtime.getManifest().version;
  const INTERNAL_EXPORT_VISIBLE_MS = 600_000;
  const records = [];
  let currentJob = null;
  let lastRecordAt = 0;
  let collapsed = false;
  let siteAuthorized = false;
  let siteStatusTimer = 0;
  let contextInvalidated = false;
  let internalExportButton = null;
  let internalExportTimer = 0;
  let internalExportCheckPending = false;
  let internalExportDownloadPending = false;

  const root = document.createElement("section");
  root.id = "dmp-cdp-monitor";
  root.style.cssText = "position:fixed;right:14px;bottom:14px;z-index:2147483647";
  const shadow = root.attachShadow({ mode: "closed" });
  shadow.innerHTML = `
    <style>
      :host { all: initial; }
      * { box-sizing: border-box; }
      .panel { width:min(680px,calc(100vw - 28px)); max-height:78vh; overflow:hidden; color:#eaf7eb; background:#07130a; border:1px solid #4f8b58; border-radius:12px; box-shadow:0 16px 44px rgba(0,0,0,.42); font:12px/1.45 -apple-system,BlinkMacSystemFont,"PingFang SC","Segoe UI",sans-serif; }
      header { display:grid; grid-template-columns:minmax(0,1fr) auto auto auto; align-items:center; gap:8px; padding:10px 12px; background:#102516; border-bottom:1px solid #315a38; }
      header strong { font-size:14px; white-space:nowrap; }
      .header-main { display:flex; align-items:center; gap:8px; min-width:0; overflow:hidden; }
      .status { color:#ffd66b; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; user-select:none; }
      .mode-switch { min-width:118px; padding:4px 7px; color:#eaf7eb; background:#17351f; border:1px solid #4f8b58; border-radius:6px; font:inherit; }
      button { border:0; border-radius:6px; cursor:pointer; font:inherit; }
      button:disabled { opacity:.45; cursor:not-allowed; }
      .collapse { min-width:26px; padding:3px 7px; background:#24472b; color:#fff; }
      .settings { min-width:26px; padding:3px 7px; background:#24472b; color:#fff; }
      .body { max-height:calc(78vh - 44px); overflow:auto; }
      .task { padding:12px; border-bottom:1px solid #315a38; background:#0b1c0f; }
      .task-row { display:grid; grid-template-columns:minmax(0,1fr) auto; gap:8px; }
      .task-inputs { display:grid; gap:6px; }
      .input-line { display:grid; grid-template-columns:116px minmax(0,1fr); align-items:center; gap:7px; }
      .input-line > span { color:#a8cdae; white-space:nowrap; }
      input { width:100%; min-width:0; padding:8px 10px; color:#f4fff5; background:#07130a; border:1px solid #4f8b58; border-radius:6px; outline:none; font:13px/1.3 ui-monospace,SFMono-Regular,Menlo,monospace; }
      input:focus { border-color:#8fc99a; box-shadow:0 0 0 2px rgba(143,201,154,.15); }
      .run { padding:8px 15px; background:#208548; color:#fff; font-weight:700; white-space:nowrap; }
      .task-meta { display:flex; gap:7px; align-items:center; flex-wrap:wrap; margin-top:8px; color:#afd5b5; }
      .pill { padding:2px 7px; border-radius:999px; background:#193e25; color:#bce8c4; }
      .pill.warn { background:#5a4315; color:#ffe294; }
      .pill.bad { background:#5e2828; color:#ffb3b3; }
      .progress { height:5px; margin-top:9px; overflow:hidden; background:#18311d; border-radius:999px; }
      .progress > i { display:block; width:0; height:100%; background:linear-gradient(90deg,#2ea35b,#8ed09d); transition:width .25s ease; }
      .downloads { display:flex; gap:7px; margin-top:10px; }
      .downloads button { flex:1; padding:6px 8px; color:#fff; background:#24472b; }
      .downloads .primary { background:#1c6b35; }
      .recapture { display:flex; align-items:center; gap:8px; margin-top:8px; padding:8px; border:1px solid #795f22; border-radius:7px; background:#30250e; color:#ffe294; }
      .recapture[hidden] { display:none; }
      .recapture button { flex:0 0 auto; padding:7px 11px; background:#b77717; color:#fff; font-weight:700; }
      .recapture span { min-width:0; word-break:break-word; }
      .preview { padding:10px 12px 12px; }
      .preview-head { display:flex; align-items:center; justify-content:space-between; gap:8px; margin-bottom:7px; }
      .preview-head strong { font-size:13px; }
      .preview-head select { min-width:150px; max-width:230px; padding:4px 7px; color:#eaf7eb; background:#132c19; border:1px solid #4f8b58; border-radius:5px; font:inherit; }
      .quality { color:#9ed7a6; }
      .table-wrap { max-height:280px; overflow:auto; border:1px solid #315a38; border-radius:7px; background:#0a190d; }
      table { width:100%; border-collapse:separate; border-spacing:0; color:#dcefe0; font-size:11px; }
      th { position:sticky; top:0; z-index:1; padding:7px 8px; text-align:left; white-space:nowrap; color:#fff; background:#1f6b49; }
      td { max-width:220px; padding:6px 8px; vertical-align:top; border-bottom:1px solid #183d23; word-break:break-word; }
      tbody tr:nth-child(even) td { background:#0d2112; }
      .empty { padding:24px 12px; color:#8fb095; text-align:center; }
      .hint { margin-top:7px; color:#7fa787; }
    </style>
    <div class="panel">
      <header>
        <div class="header-main"><strong title="达摩盘一体化自动取数｜少壮AI自动化">一体化自动取数｜少壮AI自动化 v${EXTENSION_VERSION}</strong><span class="status" data-role="status">等待运行</span></div>
        <select class="mode-switch" data-role="mode-switch" title="切换取数模式"><option value="growth">打爆路径</option><option value="competition-shop">竞争态势·店铺</option></select>
        <button class="settings" data-role="settings" title="系统设置">⚙</button>
        <button class="collapse" data-role="collapse" title="收起/展开">—</button>
      </header>
      <div class="body" data-role="body">
        <section class="task">
          <div class="task-row">
            <div class="task-inputs">
              <label class="input-line"><span>本店主体商品 ID</span><input data-role="subject-item-id" inputmode="numeric" autocomplete="off" placeholder="有权限且近30天有销量" /></label>
              <label class="input-line"><span>成功品/竞品 ID</span><input data-role="success-item-id" inputmode="numeric" autocomplete="off" placeholder="要添加并对比的商品" /></label>
            </div>
            <button class="run" data-role="run">一键运行</button>
          </div>
          <div class="task-meta">
            <span class="pill">默认近30天</span>
            <span class="pill warn" data-role="site-state">官网检测中</span>
            <span class="pill" data-role="ai-state">云端检测中</span>
            <span class="pill" data-role="job-state">等待主体/竞品 ID</span>
            <span data-role="step">自动取得成功品并整理三个对比页签</span>
          </div>
          <div class="progress"><i data-role="progress"></i></div>
          <div class="downloads" data-role="downloads">
            <button class="primary" data-role="open-online-report" disabled>打开官网 HTML 报告</button>
            <button class="primary" data-role="share-report" disabled>官网分享</button>
            <button data-role="open-report-center">管理历史报告</button>
          </div>
          <div class="recapture" data-role="recapture-wrap" hidden>
            <button data-role="recapture" type="button">补齐缺失数据</button>
            <span data-role="recapture-summary"></span>
          </div>
        </section>
        <section class="preview">
          <div class="preview-head"><strong>业务表格预览</strong><select data-role="preview-table" disabled><option>尚未生成</option></select><span class="quality" data-role="quality">尚未生成</span></div>
          <div class="table-wrap" data-role="preview-wrap"><div class="empty">输入商品 ID 后点击“一键运行”</div></div>
        </section>
      </div>
    </div>
  `;

  function mount() {
    if (document.documentElement && !document.getElementById(root.id)) document.documentElement.appendChild(root);
  }
  mount();
  if (!root.isConnected) document.addEventListener("DOMContentLoaded", mount, { once: true });

  const $ = role => shadow.querySelector(`[data-role="${role}"]`);
  const ui = {
    body: $("body"), status: $("status"), collapse: $("collapse"), settings: $("settings"), modeSwitch: $("mode-switch"),
    subjectItemId: $("subject-item-id"), successItemId: $("success-item-id"), run: $("run"),
    jobState: $("job-state"), step: $("step"), progress: $("progress"), downloads: $("downloads"), onlineReport: $("open-online-report"),
    shareReport: $("share-report"), openReportCenter: $("open-report-center"), quality: $("quality"), previewTable: $("preview-table"), aiState: $("ai-state"), siteState: $("site-state"), previewWrap: $("preview-wrap"),
    recaptureWrap: $("recapture-wrap"), recapture: $("recapture"), recaptureSummary: $("recapture-summary")
  };

  function retireInvalidatedInstance() {
    if (contextInvalidated) return;
    contextInvalidated = true;
    hideInternalExport();
    if (siteStatusTimer) window.clearInterval(siteStatusTimer);
    if (root.isConnected) root.remove();
  }

  async function runtimeMessage(type, payload = {}) {
    if (contextInvalidated || typeof chrome === "undefined" || !chrome.runtime?.id) {
      retireInvalidatedInstance();
      return { ok: false, contextInvalidated: true };
    }
    try {
      return await chrome.runtime.sendMessage({ type, ...payload });
    } catch {
      if (!chrome.runtime?.id) {
        retireInvalidatedInstance();
        return { ok: false, contextInvalidated: true };
      }
      return { ok: false, error: "服务暂不可用" };
    }
  }

  function businessFacingText(value) {
    return String(value ?? "")
      .replace(/ChatGPT\s*API/gi, "云端服务")
      .replace(/\bJSON\b/gi, "数据")
      .replace(/\bAPI\b/gi, "云端服务")
      .replace(/\bCDP\b/gi, "页面")
      .replace(/\bHTTP\s*\d*/gi, "")
      .replace(/\bendpoint\b/gi, "数据项")
      .replace(/\/(?:api|api_2|dataplatform)\/[^\s；，、）)]*/gi, "相关数据")
      .replace(/接口/g, "数据项")
      .replace(/响应体/g, "页面数据")
      .replace(/回读/g, "确认")
      .replace(/请求/g, "加载")
      .replace(/解析/g, "处理")
      .replace(/模型/g, "云端")
      .replace(/精准补抓|定向补抓|自动补抓|补抓/g, "补充")
      .replace(/完整性门禁/g, "完整度检查")
      .replace(/感知层/g, "系统")
      .replace(/采集批次/g, "本次数据")
      .replace(/闭合/g, "完整")
      .replace(/直连/g, "自动加载")
      .replace(/重放/g, "重新加载")
      .replace(/\s+[）)]/g, "）")
      .replace(/[（(]\s*[）)]/g, "")
      .replace(/\s{2,}/g, " ")
      .trim();
  }

  function setStatus(message, color = "#ffd66b") {
    ui.status.textContent = businessFacingText(message);
    ui.status.style.color = color;
  }

  function publicErrorMessage(error, fallback = "操作未完成，请稍后重试") {
    const text = String(error?.message || error || "").trim();
    if (isSuccessProductBlockingCode(error?.code) || /无法搜索到商品.*叶子类目|已搜索到商品.*未成功加入已选成功品/.test(text)) return text;
    const messages = [
      [/登录|会话失效/, "请先登录官网并刷新页面"],
      [/授权|权限|付费|账号停用|到期/, "当前账号未获得有效使用权限，请联系管理员开通或续费"],
      [/主体商品|单品洞察|本店商品|近30天有销量/, "主体商品不可用，请确认是本店商品且近30天有销量"],
      [/业务数据|刷新达摩盘|页面切换/, "暂未取得业务数据，请刷新达摩盘页面后重试"],
      [/超时/, "操作超时，请稍后重试"],
      [/报告中心/, "报告中心暂时不可用，请稍后重试"],
      [/设置页/, "设置页打开失败，请重试"],
      [/XLSX|工作簿|报告结构|校验/, "报告生成失败，请重新运行"]
    ];
    return messages.find(([pattern]) => pattern.test(text))?.[1] || fallback;
  }

  function setStep(message, progress, state = "运行中", stateClass = "") {
    const displayMessage = businessFacingText(message);
    ui.step.textContent = displayMessage;
    ui.progress.style.width = `${Math.max(0, Math.min(100, progress || 0))}%`;
    ui.jobState.textContent = businessFacingText(state);
    ui.jobState.className = `pill ${stateClass}`.trim();
    if (currentJob) {
      currentJob.step = displayMessage;
      currentJob.progress = progress;
      currentJob.statusLabel = state;
    }
  }

  async function refreshSiteStatus() {
    const result = await runtimeMessage("DMP_CDP_AUTH_CHECK").catch(() => null);
    if (result?.contextInvalidated) return false;
    siteAuthorized = Boolean(result?.ok);
    if (siteAuthorized) {
      const name = result.user?.name || result.user?.username || "已登录";
      const remainingDays = Number(result.user?.dmpEntitlement?.remainingDays);
      const countdown = Number.isFinite(remainingDays) && remainingDays > 0
        ? ` · 剩余 ${Math.ceil(remainingDays)} 天`
        : "";
      ui.siteState.textContent = `官网在线 · ${name}${countdown}`;
      ui.siteState.className = "pill";
    } else {
      ui.siteState.textContent = result?.reason === "nologin" || result?.reason === "invalid"
        ? "官网未登录"
        : result?.reason === "expired"
          ? "30 天授权已到期"
        : result?.reason === "denied"
          ? "账号未授权"
          : "官网离线";
      ui.siteState.className = "pill bad";
      if (!currentJob || currentJob.status !== "running") setStatus(publicErrorMessage(result?.error, "官网连接失败，请确认已登录并重试"), "#ff9d9d");
    }
    if (!currentJob || currentJob.status !== "running") ui.run.disabled = !siteAuthorized;
    ui.recapture.disabled = !siteAuthorized || currentJob?.status !== "blocked";
    return siteAuthorized;
  }

  async function refreshAiStatus() {
    const configResult = await runtimeMessage("DMP_CDP_GET_AI_CONFIG");
    if (configResult?.contextInvalidated) return;
    if (!configResult?.ok || configResult.config.enabled === false) {
      ui.aiState.textContent = configResult?.ok ? "云端校验未启用" : "云端服务暂不可用";
      ui.aiState.className = "pill warn";
      return;
    }
    const healthResult = await runtimeMessage("DMP_CDP_AI_HEALTH");
    ui.aiState.textContent = healthResult?.ok ? "云端就绪" : "云端暂不可用";
    ui.aiState.className = `pill ${healthResult?.ok ? "" : "warn"}`.trim();
  }

  // 内部错误码保持不变，面向用户只显示业务化提示。
  const ANALYSIS_ERROR_LABEL = {
    NO_JSON: "未取得有效数据",
    PARSE_FAILED: "数据整理未完成",
    CALC_FAILED: "数据计算未完成",
    API_FAILED: "云端处理未完成"
  };

  function analysisErrorLabel(code) {
    return ANALYSIS_ERROR_LABEL[code] || "云端处理未完成";
  }

  async function persistJob() {
    if (!currentJob) return;
    const result = await runtimeMessage("DMP_CDP_SAVE_JOB", { job: currentJob });
    if (!result?.ok) throw new Error(result?.error || "任务保存失败");
  }

  async function archiveReportToOfficialCenter({ openReport = false } = {}) {
    if (!currentJob?.report || currentJob.report.quality?.exportAllowed !== true) return false;
    try {
      const canonical = engine.toCanonicalReport(currentJob.report);
      const validation = engine.validateCanonicalReport(canonical);
      if (!validation.ok) return false;
      const result = await runtimeMessage("DMP_CDP_SYNC_REPORT", {
        report: canonical,
        subjectItemId: currentJob.subjectItemId || currentJob.itemId,
        competitorItemId: currentJob.successItemId,
        quality: currentJob.report.quality?.complete ? "complete" : "partial",
        openReport
      });
      currentJob.reportCenter = {
        ok: Boolean(result?.ok),
        reportId: result?.reportId || "",
        sourceVersion: EXTENSION_VERSION,
        reportUrl: result?.reportUrl || "",
        opened: Boolean(result?.opened),
        openError: result?.openError || "",
        savedAt: result?.savedAt || "",
        error: result?.ok ? "" : (result?.error || "报告中心暂时不可用"),
        attemptedAt: new Date().toISOString()
      };
      ui.onlineReport.disabled = !result?.ok || !result?.reportId;
      return Boolean(result?.ok);
    } catch (error) {
      currentJob.reportCenter = { ok: false, error: String(error?.message || error), attemptedAt: new Date().toISOString() };
      return false;
    }
  }

  async function copyShareLink(value) {
    try {
      await navigator.clipboard.writeText(value);
    } catch {
      const input = document.createElement("textarea");
      input.value = value;
      input.style.cssText = "position:fixed;left:-9999px;opacity:0";
      document.documentElement.appendChild(input);
      input.select();
      document.execCommand("copy");
      input.remove();
    }
  }

  async function createOnlineShare() {
    if (!currentJob?.report || currentJob.report.quality?.exportAllowed !== true) {
      throw new Error("业务数据未完整，暂不能生成官网分享报告");
    }
    if (currentJob.reportCenter?.ok !== true || !currentJob.reportCenter.reportId) {
      const archived = await archiveReportToOfficialCenter();
      if (!archived || !currentJob.reportCenter?.reportId) {
        throw new Error(currentJob.reportCenter?.error || "官网报告保存失败");
      }
      await persistJob().catch(() => {});
    }
    const result = await runtimeMessage("DMP_CDP_CREATE_SHARE", { reportId: currentJob.reportCenter.reportId });
    if (!result?.ok || !result.shareUrl) throw new Error(result?.error || "官网分享链接生成失败");
    await copyShareLink(result.shareUrl);
    return result.shareUrl;
  }

  function reportIsExportable() {
    return Boolean(currentJob?.report?.quality?.complete === true && currentJob?.report?.quality?.exportAllowed === true);
  }

  function hideInternalExport() {
    if (internalExportTimer) clearTimeout(internalExportTimer);
    internalExportTimer = 0;
    internalExportButton?.remove();
    internalExportButton = null;
  }

  function showInternalExport() {
    hideInternalExport();
    const button = document.createElement("button");
    button.type = "button";
    button.className = "primary";
    button.dataset.role = "internal-export";
    button.textContent = "内部导出";
    button.title = "仅限平台管理员，点击时将再次向官网校验";
    button.disabled = internalExportDownloadPending || !reportIsExportable();
    button.addEventListener("click", () => void exportInternalWorkbook());
    ui.downloads.appendChild(button);
    internalExportButton = button;
    internalExportTimer = setTimeout(hideInternalExport, INTERNAL_EXPORT_VISIBLE_MS);
  }

  // 隐藏手势只负责发现入口，不是安全边界；显示前与真正导出前都必须经官网鉴权。
  async function revealInternalExport() {
    if (internalExportCheckPending || internalExportDownloadPending) return;
    internalExportCheckPending = true;
    hideInternalExport();
    setStatus("正在校验内部导出权限…", "#ffd66b");
    try {
      const result = await runtimeMessage("DMP_CDP_VERIFY_REPORT_EXPORT");
      if (!result?.ok) throw new Error(result?.error || "官网未授权内部导出");
      showInternalExport();
      setStatus("内部导出已临时开启 10 分钟", "#76e287");
    } catch (error) {
      setStatus(publicErrorMessage(error, "当前账号无内部导出权限"), "#ff9d9d");
    } finally {
      internalExportCheckPending = false;
    }
  }

  async function exportInternalWorkbook() {
    if (internalExportDownloadPending) return;
    const button = internalExportButton;
    if (!button || !reportIsExportable()) {
      hideInternalExport();
      setStatus("请先生成数据完整的报告", "#ff9d9d");
      return;
    }
    if (internalExportTimer) clearTimeout(internalExportTimer);
    internalExportTimer = 0;
    internalExportDownloadPending = true;
    button.disabled = true;
    ui.run.disabled = true;
    ui.recapture.disabled = true;
    ui.modeSwitch.disabled = true;
    const exportJob = currentJob;
    const report = exportJob.report;
    setStatus("正在复核并登记本次内部导出…", "#ffd66b");
    try {
      const reportCenterCurrent = currentJob.reportCenter?.ok === true
        && currentJob.reportCenter.reportId
        && currentJob.reportCenter.sourceVersion === EXTENSION_VERSION;
      if (!reportCenterCurrent) {
        const archived = await archiveReportToOfficialCenter();
        if (!archived || !currentJob.reportCenter?.reportId) throw new Error(currentJob.reportCenter?.error || "报告尚未保存到官网");
        await persistJob().catch(() => {});
      }
      const reportId = exportJob.reportCenter.reportId;
      const result = await runtimeMessage("DMP_CDP_AUTHORIZE_REPORT_EXPORT", {
        reportId,
        reportType: "growth",
        format: "xlsx",
        clientVersion: EXTENSION_VERSION
      });
      if (!result?.ok || result.authorization?.authorized !== true) {
        throw new Error(result?.error || "官网未授权本次内部导出");
      }
      downloadBlob(xlsxWriter.buildXlsx(report), reportFilename(".xlsx", exportJob, report), xlsxWriter.MIME_TYPE);
      setStatus("内部 XLSX 已导出，本次入口已关闭", "#76e287");
    } catch (error) {
      setStatus(publicErrorMessage(error, "内部导出未完成，请重新触发后再试"), "#ff9d9d");
    } finally {
      internalExportDownloadPending = false;
      hideInternalExport();
      ui.run.disabled = !siteAuthorized || currentJob?.status === "running";
      ui.recapture.disabled = !siteAuthorized || currentJob?.status !== "blocked";
      ui.modeSwitch.disabled = currentJob?.status === "running";
    }
  }

  function recordIdentity(record) {
    return [record.requestId, record.capturedAt, record.kind, record.source, record.pathname || record.url].join("|");
  }

  function mergeRecords(incoming) {
    const known = new Set(records.map(recordIdentity));
    for (const record of incoming || []) {
      const key = recordIdentity(record);
      if (known.has(key)) continue;
      known.add(key);
      records.push(record);
    }
    records.sort((a, b) => String(a.capturedAt || "").localeCompare(String(b.capturedAt || "")));
  }

  function canonicalRecordPath(record) {
    let value = String(record?.pathname || "");
    if (!value) {
      try { value = new URL(record?.url || "").pathname; } catch { value = String(record?.url || "").split("?")[0]; }
    }
    return value.replace(/^\/api_2\//, "/api/").replace(/\.json$/, "").replace(/\/+$/, "");
  }

  async function clearRecordHistory(paths = null) {
    const partial = Array.isArray(paths);
    const result = await runtimeMessage(partial ? "DMP_CDP_CLEAR_RECORD_PATHS" : "DMP_CDP_CLEAR_RECORDS", partial ? { paths } : {});
    if (!result?.ok) throw new Error(result?.error || (partial ? "局部清理失败" : "清空失败"));
    if (partial) {
      const wanted = new Set(paths.map(path => canonicalRecordPath({ pathname: path })).filter(Boolean));
      for (let index = records.length - 1; index >= 0; index -= 1) {
        if (wanted.has(canonicalRecordPath(records[index]))) records.splice(index, 1);
      }
    } else {
      records.length = 0;
    }
    return result;
  }

  function normalizeText(value) {
    return workflow.normalizeText(value);
  }

  function accessibleDocuments() {
    const documents = [];
    const queue = [document];
    const visited = new Set();
    while (queue.length) {
      const current = queue.shift();
      if (!current || visited.has(current)) continue;
      visited.add(current);
      documents.push(current);
      let frames = [];
      try { frames = Array.from(current.querySelectorAll("iframe,frame")); } catch { frames = []; }
      for (const frame of frames) {
        try {
          if (frame.contentDocument?.documentElement) queue.push(frame.contentDocument);
        } catch { /* 跨源子页面不能由顶层内容脚本读取。 */ }
      }
    }
    return documents;
  }

  function queryElements(scope, selector) {
    const scopes = scope === document ? accessibleDocuments() : [scope];
    return scopes.flatMap(current => {
      try { return Array.from(current.querySelectorAll(selector)); }
      catch { return []; }
    });
  }

  function isVisible(element) {
    if (!element || element.nodeType !== 1 || element.closest?.("#dmp-cdp-monitor")) return false;
    const view = element.ownerDocument?.defaultView || window;
    const style = view.getComputedStyle(element);
    return style.visibility !== "hidden" && style.display !== "none" && element.getClientRects().length > 0;
  }

  function pageClickTarget(element) {
    return element.closest("button,[role='button'],[role='tab'],[role='option'],[role='radio'],[role='checkbox'],a,label,li,[tabindex],.next-select,.ant-select,.next-menu-item,.ant-select-item") || element;
  }

  function elementLabels(element) {
    return [element.textContent, element.getAttribute?.("aria-label"), element.getAttribute?.("title")]
      .map(normalizeText)
      .filter(Boolean);
  }

  function findVisibleText(patterns, scope = document, selector = "button,[role='button'],[role='tab'],[role='option'],[role='radio'],[role='checkbox'],a,label,li,span,div,[aria-label],[title]") {
    const candidates = queryElements(scope, selector).filter(isVisible);
    for (const pattern of patterns) {
      const found = candidates.find(element => {
        return elementLabels(element).some(text => {
          pattern.lastIndex = 0;
          return text.length <= 80 && pattern.test(text);
        });
      });
      if (found) return pageClickTarget(found);
    }
    return null;
  }

  async function waitForVisible(factory, timeoutMs = 7000) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      const found = factory();
      if (found) return found;
      await wait(200);
    }
    return null;
  }

  const SUCCESS_LOAD_PATH = "/api/goods/grow/define/success/load";
  const SUCCESS_LIST_PATH = "/api/goods/grow/define/success/item/list";
  const SUCCESS_PRODUCT_NOT_FOUND_CODE = "SUCCESS_PRODUCT_NOT_FOUND";
  const SUCCESS_PRODUCT_SELECTION_FAILED_CODE = "SUCCESS_PRODUCT_SELECTION_FAILED";

  function isSuccessProductBlockingCode(code) {
    return code === SUCCESS_PRODUCT_NOT_FOUND_CODE || code === SUCCESS_PRODUCT_SELECTION_FAILED_CODE;
  }

  function successProductNotFoundError(itemId) {
    const error = new Error(`无法搜索到商品 ${itemId}，请排查该商品是否与主体商品属于同一叶子类目`);
    error.code = SUCCESS_PRODUCT_NOT_FOUND_CODE;
    return error;
  }

  function successProductSelectionFailedError(itemId) {
    const error = new Error(`已搜索到商品 ${itemId}，但未成功加入已选成功品，请刷新页面后重试`);
    error.code = SUCCESS_PRODUCT_SELECTION_FAILED_CODE;
    return error;
  }

  function selectedSuccessIdsFromRecord(record) {
    const body = parseRecordJson(record);
    const containers = [body?.data, body?.result?.data, body?.result, body?.payload, body];
    let list = [];
    for (const container of containers) {
      if (Array.isArray(container)) {
        list = container;
        break;
      }
      const nested = [container?.list, container?.rows, container?.items].find(Array.isArray);
      if (nested) {
        list = nested;
        break;
      }
    }
    return [...new Set(list.map(item => String(item?.itemId ?? item?.id ?? item?.item?.itemId ?? "")).filter(id => /^\d{6,20}$/.test(id)))];
  }

  function hasOnlySuccessProductRecord(itemId, since) {
    return records.some(record => {
      if (since && record.capturedAt && record.capturedAt < since) return false;
      const path = record.pathname || record.url || "";
      if (!path.includes(SUCCESS_LOAD_PATH)) return false;
      const ids = selectedSuccessIdsFromRecord(record);
      return ids.length === 1 && ids[0] === String(itemId);
    });
  }

  function fillPageInput(input, value) {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
    if (setter) setter.call(input, value);
    else input.value = value;
    input.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: value }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function selectedState(element) {
    const checkbox = element.matches("input[type='checkbox'],input[type='radio']") ? element : element.querySelector("input[type='checkbox'],input[type='radio']");
    if (checkbox) return checkbox.checked;
    for (const name of ["aria-checked", "aria-selected"]) {
      const value = element.getAttribute(name);
      if (value === "true") return true;
      if (value === "false") return false;
    }
    const classes = `${element.className || ""} ${element.parentElement?.className || ""}`;
    if (/(^|\s)(selected|checked|active)(\s|$)|-selected|-checked|is-selected|is-checked/i.test(classes)) return true;
    return null;
  }

  function findSuccessDialog() {
    // 策略1：锚点法。遍历所有元素（主文档 + 可访问 iframe），找含“已选成功品”的最小元素，向上找面板容器。
    const anchors = [];
    for (const doc of accessibleDocuments()) {
      for (const el of doc.querySelectorAll("*")) {
        if (el.closest?.("#dmp-cdp-monitor")) continue;
        const text = el.textContent || "";
        if (text.length > 200) continue;
        if (text.includes("已选成功品")) anchors.push(el);
      }
    }
    anchors.sort((a, b) => (a.textContent || "").length - (b.textContent || "").length);
    for (const anchor of anchors) {
      let node = anchor;
      while (node && node.nodeType === 1 && node !== document.documentElement) {
        const text = normalizeText(node.textContent);
        if (/成功品列表|所有商品/.test(text) && /已选成功品/.test(text)) return node;
        node = node.parentElement;
      }
    }
    // 策略2：找对话框容器（含达摩盘 mx-dialog）。
    const dialogs = queryElements(document, "[role='dialog'],.mx-dialog,.next-dialog,.ant-modal,.ant-drawer,.ant-modal-wrap,.next-overlay-wrapper,body > div")
      .filter(element => !element.closest?.("#dmp-cdp-monitor"))
      .filter(element => /成功品/.test(normalizeText(element.textContent)))
      .sort((a, b) => normalizeText(a.textContent).length - normalizeText(b.textContent).length);
    return dialogs[0] || null;
  }

  function successEntryCandidates() {
    const labels = workflow.SUCCESS_ENTRY_LABELS || ["取得成功品", "获取成功品", "定制成功品", "选择成功品"];
    const exactOrder = new Map(labels.map((label, index) => [normalizeText(label), index]));
    const candidates = queryElements(document, "button,[role='button'],a,label,li,span,div,[aria-label],[title]")
      .filter(isVisible)
      .map(element => {
        const texts = elementLabels(element);
        const exactIndex = texts.reduce((best, text) => Math.min(best, exactOrder.get(text) ?? Number.MAX_SAFE_INTEGER), Number.MAX_SAFE_INTEGER);
        const related = texts.some(text => text.length <= 80 && /(取得|获取|定制|选择|设置|添加|切换|修改)成功品/.test(text));
        return { target: pageClickTarget(element), score: exactIndex !== Number.MAX_SAFE_INTEGER ? exactIndex : related ? labels.length + 1 : Number.MAX_SAFE_INTEGER };
      })
      .filter(candidate => candidate.score !== Number.MAX_SAFE_INTEGER)
      .sort((a, b) => a.score - b.score);
    const seen = new Set();
    return candidates.map(candidate => candidate.target).filter(target => {
      if (seen.has(target)) return false;
      seen.add(target);
      return true;
    });
  }

  function visibleSuccessTextSummary() {
    const values = queryElements(document, "button,[role='button'],a,label,li,span,div,[aria-label],[title]")
      .filter(isVisible)
      .flatMap(elementLabels)
      .filter(text => text.length <= 80 && text.includes("成功品"));
    return Array.from(new Set(values)).slice(0, 6);
  }

  function subjectAccessError(subjectItemId) {
    const messages = queryElements(document, "[role='alert'],.next-message,.ant-message,.next-notice,div,span")
      .filter(isVisible)
      .map(element => normalizeText(element.textContent))
      .filter(text => text.length <= 300 && (/无法查看单品洞察/.test(text) || (/无权访问|近30天无销量/.test(text) && text.includes(subjectItemId))))
      .sort((left, right) => left.length - right.length);
    return messages[0] || "";
  }

  async function openSuccessDialog(timeoutMs = 20_000) {
    const started = Date.now();
    const attempted = new Set();
    while (Date.now() - started < timeoutMs) {
      const existing = findSuccessDialog();
      if (existing) return existing;
      const candidate = successEntryCandidates().find(target => !attempted.has(target));
      if (candidate) {
        attempted.add(candidate);
        await trustedClick(candidate, "打开自定义成功品");
        const opened = await waitForVisible(findSuccessDialog, 1600);
        if (opened) return opened;
      } else {
        await wait(250);
      }
    }
    return null;
  }

  function selectedSuccessArea(dialog) {
    const headers = queryElements(dialog, "div,section,aside,header,h1,h2,h3,span")
      .filter(isVisible)
      .filter(element => workflow.selectedSuccessCount(element.textContent) !== null)
      .sort((left, right) => normalizeText(left.textContent).length - normalizeText(right.textContent).length);
    const header = headers[0];
    if (!header) return dialog;
    let selectedArea = header.parentElement || header;
    for (let current = selectedArea; current && current !== dialog; current = current.parentElement) {
      const text = normalizeText(current.textContent);
      if (/成功品列表/.test(text)) break;
      if (/已选成功品/.test(text)) selectedArea = current;
    }
    return selectedArea;
  }

  function selectedSuccessCount(dialog) {
    const counts = queryElements(dialog, "div,section,aside,header,h1,h2,h3,span")
      .filter(isVisible)
      .map(element => ({ count: workflow.selectedSuccessCount(element.textContent), length: normalizeText(element.textContent).length }))
      .filter(value => value.count !== null)
      .sort((left, right) => left.length - right.length);
    return counts[0]?.count ?? null;
  }

  function selectedRemoveButtons(dialog) {
    const area = selectedSuccessArea(dialog);
    const seen = new Set();
    return queryElements(area, "button,[role='button'],a,span,[aria-label],[title]")
      .filter(isVisible)
      .filter(element => elementLabels(element).some(text => /^(移除|删除)$/.test(text)))
      .map(pageClickTarget)
      .filter(target => {
        if (seen.has(target)) return false;
        seen.add(target);
        return true;
      });
  }

  async function confirmSuccessDeletion(dialog) {
    await wait(180);
    const prompts = queryElements(document, "[role='dialog'],.next-balloon,.next-popconfirm,.ant-popover,.ant-popconfirm,.next-dialog,.ant-modal")
      .filter(isVisible)
      .filter(element => element !== dialog && !element.contains(dialog))
      .filter(element => {
        const text = normalizeText(element.textContent);
        return text.length <= 600 && /(删除|移除|清空)/.test(text) && /(确定|确认|是否|成功品|商品)/.test(text);
      })
      .sort((left, right) => normalizeText(left.textContent).length - normalizeText(right.textContent).length);
    const prompt = prompts[0];
    if (!prompt) return false;
    const confirm = findVisibleText([/^确定$/, /^确认$/, /^删除$/], prompt, "button,[role='button'],a,span");
    if (!confirm) return false;
    await trustedClick(confirm, "确认删除成功品");
    await wait(280);
    return true;
  }

  async function waitForSelectedSuccessEmpty(dialog, timeoutMs = 4_000) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      const count = selectedSuccessCount(dialog);
      const removeCount = selectedRemoveButtons(dialog).length;
      if (count === 0 || (count === null && removeCount === 0)) return true;
      await wait(180);
    }
    return false;
  }

  async function clearSelectedSuccessProducts(dialog) {
    const initialCount = selectedSuccessCount(dialog) ?? selectedRemoveButtons(dialog).length;
    if (initialCount === 0) return { confirmed: true, removed: 0, method: "已选成功品原本为空" };

    const clearLabels = (workflow.SUCCESS_CLEAR_LABELS || ["全部删除", "清空全部", "全部移除", "全部清除"])
      .map(label => new RegExp(`^${label}$`));
    const clearAll = findVisibleText(clearLabels, selectedSuccessArea(dialog), "button,[role='button'],a,span,[aria-label],[title]");
    if (clearAll) {
      await trustedClick(clearAll, "全部删除已选成功品");
      await confirmSuccessDeletion(dialog);
      if (await waitForSelectedSuccessEmpty(dialog)) {
        return { confirmed: true, removed: initialCount, method: "已全部删除默认成功品" };
      }
    }

    for (let index = 0; index < 8; index += 1) {
      const count = selectedSuccessCount(dialog);
      if (count === 0) break;
      const remove = selectedRemoveButtons(dialog)[0];
      if (!remove) break;
      await trustedClick(remove, "移除已选成功品");
      await confirmSuccessDeletion(dialog);
      await wait(260);
    }

    const finalCount = selectedSuccessCount(dialog);
    const confirmed = finalCount === 0 || (finalCount === null && selectedRemoveButtons(dialog).length === 0);
    return {
      confirmed,
      removed: confirmed ? initialCount : Math.max(0, initialCount - (finalCount ?? initialCount)),
      method: confirmed ? "已逐个移除默认成功品" : `默认成功品未清空${finalCount === null ? "" : `（仍有 ${finalCount} 个）`}`
    };
  }

  function filterSatisfied(dialog, filter) {
    const text = normalizeText(dialog.textContent).toLowerCase();
    return filter.selected.every(value => text.includes(normalizeText(value).toLowerCase()));
  }

  function optionPattern(value) {
    if (value === "500万~1000万") return /^500万(?:~|至|-)?1000万$/i;
    const escaped = value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/~/g, "(?:~|至|-)");
    return new RegExp(`^${escaped}$`, "i");
  }

  function filterTrigger(dialog, filter) {
    const patterns = filter.selected.map(value => optionPattern(value));
    const exact = findVisibleText(patterns, dialog);
    if (exact) return exact;
    const labelPatterns = {
      priceBand: [/价格带/], growthCycle: [/打爆期/, /爆品期/], onlineCycle: [/上架周期/],
      rankLevel: [/TOP.*%以内/i], salesLevel: [/万以上/, /万.*1000万/]
    };
    return findVisibleText(labelPatterns[filter.key] || [], dialog);
  }

  function activePopup() {
    const candidates = queryElements(document, "[role='listbox'],.next-menu,.ant-select-dropdown,.next-overlay-wrapper,.ant-dropdown,.next-popup")
      .filter(isVisible);
    return candidates[candidates.length - 1] || document;
  }

  async function applySuccessFilter(dialog, filter) {
    if (filterSatisfied(dialog, filter)) return { label: filter.label, confirmed: true, method: "页面已选" };
    const trigger = filterTrigger(dialog, filter);
    if (!trigger) return { label: filter.label, confirmed: false, method: "未找到筛选控件" };
    await trustedClick(trigger, `成功品筛选:${filter.label}`);
    await wait(300);
    const popup = activePopup();
    const missing = [];
    for (const value of filter.options) {
      const option = findVisibleText([optionPattern(value)], popup);
      if (!option) {
        missing.push(value);
        continue;
      }
      if (selectedState(option) !== true) {
        await trustedClick(option, `成功品筛选选项:${value}`);
        await wait(180);
      }
    }
    const popupConfirm = findVisibleText([/^确定$/, /^确认$/], popup, "button,[role='button'],a,span");
    if (popupConfirm) {
      await trustedClick(popupConfirm, `确认成功品筛选:${filter.label}`);
      await wait(280);
    } else {
      await trustedClick(trigger, `收起成功品筛选:${filter.label}`);
      await wait(180);
    }
    return { label: filter.label, confirmed: missing.length === 0, method: missing.length ? `缺少选项：${missing.join("、")}` : "已按截图选择" };
  }

  function findSearchInput(dialog) {
    const inputs = Array.from(dialog.querySelectorAll("input")).filter(isVisible).filter(input => !/checkbox|radio|date/.test(input.type || ""));
    return inputs.find(input => /搜索|商品|item|id|宝贝/i.test(`${input.placeholder || ""} ${input.name || ""} ${input.getAttribute("aria-label") || ""}`)) || null;
  }

  function findItemAddButton(dialog, itemId) {
    const matches = Array.from(dialog.querySelectorAll("div,li,tr,section,article")).filter(isVisible).filter(element => normalizeText(element.textContent).includes(itemId));
    matches.sort((a, b) => normalizeText(a.textContent).length - normalizeText(b.textContent).length);
    for (const match of matches) {
      let container = match;
      while (container && container !== dialog) {
        const button = findVisibleText([/^添加$/], container, "button,[role='button'],a,span");
        if (button) return button;
        container = container.parentElement;
      }
    }
    return null;
  }

  function dialogShowsSelectedItem(dialog, itemId) {
    if ((selectedSuccessCount(dialog) || 0) < 1) return false;
    return normalizeText(selectedSuccessArea(dialog).textContent).includes(String(itemId));
  }

  async function waitForSelectedSuccessItem(dialog, itemId, timeoutMs = 5_000) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      if (dialogShowsSelectedItem(dialog, itemId)) return true;
      await wait(200);
    }
    return false;
  }

  const DMP_API_BASE = "https://dmp.advgateway.taobao.com";

  function readDmpCookies() {
    const map = {};
    document.cookie.split(";").forEach(item => {
      const idx = item.indexOf("=");
      if (idx < 0) return;
      const key = item.slice(0, idx).trim();
      const value = item.slice(idx + 1).trim();
      if (key) map[key] = value;
    });
    return map;
  }

  function getDmpAuth() {
    const cookies = readDmpCookies();
    const tbToken = cookies._tb_token_ || "";
    let csrf = cookies.csrfId || cookies._csrf || "";
    if (!csrf && cookies.cookie2) {
      try {
        const parsed = JSON.parse(decodeURIComponent(cookies.cookie2));
        csrf = parsed.ck || "";
      } catch {}
    }
    if (!csrf && cookies.csg) csrf = cookies.csg;
    return { tbToken, csrf };
  }

  function dmpAuthQuery(auth) {
    return `bizCode=dmp&_tb_token_=${encodeURIComponent(auth.tbToken)}&_csrf=${encodeURIComponent(auth.csrf)}&csrfId=${encodeURIComponent(auth.csrf)}`;
  }

  async function fetchDmpLatestDay() {
    const auth = getDmpAuth();
    if (!auth.tbToken || !auth.csrf) throw new Error("达摩盘授权已失效");
    const response = await fetch(`${DMP_API_BASE}/api/latestDay?${dmpAuthQuery(auth)}&sceneCode=goodsGrowPathSuccItemList`, {
      credentials: "include",
      cache: "no-store"
    });
    const result = await response.json().catch(() => ({}));
    const latestDay = String(result?.data || "").trim();
    const period = workflow.periodEndingAtLatestDay(30, latestDay);
    if (!response.ok || result?.info?.ok === false || !period) throw new Error("达摩盘最新业务日期暂不可用");
    return { latestDay: period.endDate, period };
  }

  async function resolveBusinessPeriod(days = 30) {
    try {
      const latest = await fetchDmpLatestDay();
      return { period: workflow.periodEndingAtLatestDay(days, latest.latestDay), latestDay: latest.latestDay, source: "platform" };
    } catch {
      const period = workflow.pastCompletedDays(days);
      return { period, latestDay: period.endDate, source: "local-fallback" };
    }
  }

  function capturedBusinessPeriod(days = 30) {
    for (let index = records.length - 1; index >= 0; index -= 1) {
      if (canonicalRecordPath(records[index]) !== "/api/latestDay") continue;
      const result = parseRecordJson(records[index]);
      const period = workflow.periodEndingAtLatestDay(days, result?.data);
      if (period) return { period, latestDay: period.endDate, source: "captured-platform" };
    }
    return null;
  }

  function recordNeedsReplacement(record) {
    try {
      return completeness.classifyGrowthRecord(record).status === "failed";
    } catch {
      // 这里只处理完整性门禁已点名的缺失路径；无法分类时保守地替换旧记录，
      // 避免异常记录永久占住 failedRecords。
      return true;
    }
  }

  function requestSpecMatchesRecord(record, request) {
    if (canonicalRecordPath(record) !== canonicalRecordPath({ pathname: request.path })) return false;
    if (canonicalRecordPath(record) === "/dataplatform/dataset/report/query") {
      const requestType = completeness.datasetRequestType(record);
      return requestType === "INDEX_CARD" || (!requestType && completeness.classifyGrowthRecord(record).parser === "index-card");
    }
    if (canonicalRecordPath(record) !== "/api/goods/grow/comparison/scene") return true;
    let parentId = "";
    try { parentId = new URL(record.url).searchParams.get("sceneLevel1Id") || ""; } catch {}
    return String(request.sceneLevel1Id || "") === String(parentId);
  }

  function latestRequestTemplate(request) {
    return records.filter(record => requestSpecMatchesRecord(record, request))
      .sort((left, right) => String(right.capturedAt || "").localeCompare(String(left.capturedAt || "")))[0] || null;
  }

  function expectedParserForRequest(request) {
    const path = canonicalRecordPath({ pathname: request?.path });
    if (path === "/api/goods/item/info") return "item-info";
    if (path === "/api/goods/grow/define/success/load") return "selected-success-items";
    if (path === "/api/goods/grow/define/line/data") return "growth-line";
    if (path === "/api/goods/grow/comparison/scene") return "growth-scenes";
    if (path === "/api/goods/grow/comparison/scene/keyword") return "growth-keywords";
    if (path === "/dataplatform/dataset/report/query") return "index-card";
    return "";
  }

  async function clearFailedRequestRecords(requests, clearPaths = []) {
    const requestedPaths = new Set((requests || []).map(request => canonicalRecordPath({ pathname: request.path })));
    // clearPaths 是门禁实际点名的失败路径。只把 requests 没覆盖的路径作为
    // 补充范围，避免把共用 dataset/scene pathname 下的其他语义记录粗暴删除。
    const additionalPaths = new Set((clearPaths || [])
      .map(path => canonicalRecordPath({ pathname: path }))
      .filter(path => path && !requestedPaths.has(path)));
    const failed = records.filter(record => {
      if (!recordNeedsReplacement(record)) return false;
      return (requests || []).some(request => requestSpecMatchesRecord(record, request))
        || additionalPaths.has(canonicalRecordPath(record));
    });
    const identities = failed.map(recordIdentity);
    if (!identities.length) return 0;
    const result = await runtimeMessage("DMP_CDP_CLEAR_RECORD_IDS", { identities });
    if (!result?.ok) throw new Error(result?.error || "缺失数据的旧记录清理失败");
    if (Number(result.deleted) !== identities.length) throw new Error("缺失数据的旧记录未能完整清理，请刷新页面后重试");
    const wanted = new Set(identities);
    for (let index = records.length - 1; index >= 0; index -= 1) {
      if (wanted.has(recordIdentity(records[index]))) records.splice(index, 1);
    }
    return identities.length;
  }

  function recaptureRequestUrl(request, template) {
    const auth = getDmpAuth();
    if (!auth.tbToken || !auth.csrf) throw new Error("达摩盘授权已失效，请刷新页面后重试");
    const endpoint = request.path === "/dataplatform/dataset/report/query" ? `${request.path}.json` : request.path;
    let url;
    try { url = new URL(template?.url || `${DMP_API_BASE}${endpoint}`); }
    catch { url = new URL(`${DMP_API_BASE}${endpoint}`); }
    for (const key of [...url.searchParams.keys()]) {
      const value = url.searchParams.get(key) || "";
      if (/\[REDACTED\]/i.test(value) && !/^_tb_token_$|^_csrf$|^csrfId$/i.test(key)) url.searchParams.delete(key);
    }
    url.searchParams.set("bizCode", "dmp");
    url.searchParams.set("_tb_token_", auth.tbToken);
    url.searchParams.set("_csrf", auth.csrf);
    url.searchParams.set("csrfId", auth.csrf);
    const subjectItemId = currentJob?.subjectItemId || currentJob?.itemId || "";
    const successItemId = currentJob?.successItemId || "";
    const period = currentJob?.period || {};
    if (/^\/api\/goods\/(?:item\/info|grow\/)/.test(request.path)) url.searchParams.set("itemId", subjectItemId);
    if (request.path === "/api/goods/item/info") url.searchParams.set("scene", "1");
    if (request.path === "/api/goods/grow/define/line/data") url.searchParams.set("successItemId", successItemId);
    if (request.path.startsWith("/api/goods/grow/comparison/")) url.searchParams.set("succItemIds", successItemId);
    if (request.path === "/api/goods/grow/comparison/scene") {
      if (request.sceneLevel1Id) url.searchParams.set("sceneLevel1Id", request.sceneLevel1Id);
      else url.searchParams.delete("sceneLevel1Id");
    }
    if (/define\/line\/data|comparison\/scene/.test(request.path)) {
      url.searchParams.set("startDate", period.startDate || "");
      url.searchParams.set("endDate", period.endDate || "");
    }
    return url;
  }

  function periodValueLike(value, date) {
    return String(value || "").includes("-") ? date : String(date || "").replaceAll("-", "");
  }

  function alignedDatasetRequestBody(template) {
    const raw = String(template?.requestBody || "");
    if (!raw) return "";
    let payload;
    try { payload = JSON.parse(raw); } catch { return raw; }
    const period = currentJob?.period || {};
    const align = (key, itemId) => {
      let filters = payload[key];
      const encoded = typeof filters === "string";
      if (encoded) {
        try { filters = JSON.parse(filters); } catch { return; }
      }
      if (!Array.isArray(filters)) return;
      filters = filters.map(filter => {
        const marker = `${filter?.expression || ""}|${filter?.description || ""}|${filter?.name || ""}`;
        if (/item_id|宝贝ID/i.test(marker)) return { ...filter, values: [String(itemId)] };
        if (/thedate|日期|时间/i.test(marker)) {
          const example = Array.isArray(filter.values) ? filter.values[0] : "";
          return { ...filter, values: [periodValueLike(example, period.startDate), periodValueLike(example, period.endDate)] };
        }
        return filter;
      });
      payload[key] = encoded ? JSON.stringify(filters) : filters;
    };
    align("filterCondition", currentJob?.subjectItemId || currentJob?.itemId || "");
    align("filterCompareCondition", currentJob?.successItemId || "");
    return JSON.stringify(payload);
  }

  function safeRecaptureUrl(url) {
    const safe = new URL(url.toString());
    for (const key of [...safe.searchParams.keys()]) {
      if (/token|sign|cookie|authorization|password|secret|session|csrf|dynamicToken|webOpSessionId|uniqueItemCampaign/i.test(key)) safe.searchParams.set(key, "[REDACTED]");
    }
    return safe.toString();
  }

  async function replayMissingJsonRequest(request) {
    const template = latestRequestTemplate(request);
    const url = recaptureRequestUrl(request, template);
    const method = String(template?.method || (request.path === "/dataplatform/dataset/report/query" ? "POST" : "GET")).toUpperCase();
    const body = method === "GET" ? undefined : alignedDatasetRequestBody(template);
    if (method !== "GET" && !body) throw new Error(`${request.label}缺少可复用请求模板`);
    const response = await fetch(url, {
      method,
      credentials: "include",
      cache: "no-store",
      headers: method === "GET" ? undefined : { "Content-Type": template?.requestMimeType || "application/json" },
      body
    });
    const responseText = await response.text();
    let parsed = null;
    try { parsed = JSON.parse(responseText); } catch {}
    if (!response.ok || parsed?.info?.ok === false || parsed?.result?.info?.ok === false) throw new Error(`${request.label}加载失败`);
    const capturedAt = new Date().toISOString();
    const safeUrl = safeRecaptureUrl(url);
    const record = {
      capturedAt, requestId: `recapture-${Date.now()}-${Math.random().toString(16).slice(2)}`,
      url: safeUrl, origin: url.origin, pathname: url.pathname, queryKeys: [...new Set([...url.searchParams.keys()])],
      method, type: "Fetch", initiatorType: "recapture", documentUrl: `${location.origin}${location.pathname}`,
      requestBodyLength: body?.length || 0, requestBodyTruncated: false, requestBodyAvailable: Boolean(body),
      requestMimeType: template?.requestMimeType || (body ? "application/json" : ""), requestFormat: body ? "json" : "empty",
      requestKeys: template?.requestKeys || [], requestBody: body || "", status: response.status, statusText: response.statusText,
      mimeType: response.headers.get("content-type") || "application/json", protocol: "fetch", fromDiskCache: false, fromServiceWorker: false,
      encodedDataLength: responseText.length, bodyAvailable: true, bodyEncoding: "", bodyLength: responseText.length,
      truncated: false, format: parsed ? "json" : "text", responseKeys: parsed && typeof parsed === "object" ? Object.keys(parsed) : [], body: responseText
    };
    // HTTP 200 只表示传输成功。补抓结果还必须通过与最终门禁完全相同的
    // 解析器，并且语义类型匹配本次目标；TABLE 不能冒充核心 INDEX_CARD。
    const classification = completeness.classifyGrowthRecord(record);
    const expectedParser = expectedParserForRequest(request);
    if (classification.status !== "parsed" || (expectedParser && classification.parser !== expectedParser)) {
      throw new Error(`${request.label}返回内容未形成可用业务数据`);
    }
    mergeRecords([record]);
    const stored = await runtimeMessage("DMP_CDP_STORE_RECORD", { record });
    if (!stored?.ok) throw new Error(`${request.label}保存失败`);
    return record;
  }

  async function replayMissingJsonRequests(requests) {
    const succeeded = [];
    const failed = [];
    for (let index = 0; index < requests.length; index += 1) {
      const request = requests[index];
      setStep(`正在补充：${request.label}`, 15 + Math.round(((index + 1) / requests.length) * 45), "补充中", "warn");
      try {
        await replayMissingJsonRequest(request);
        succeeded.push(request);
      } catch (error) {
        failed.push({ ...request, error: String(error?.message || error) });
      }
    }
    return { succeeded, failed };
  }

  function cateIdFromRecords() {
    // cateId 会出现在成功品相关请求的 query 里；item/info 的响应体里也常带类目字段。
    for (let index = records.length - 1; index >= 0; index -= 1) {
      const record = records[index];
      const path = record?.pathname || record?.url || "";
      if (!path.includes("/api/goods/grow/define/success") && !path.includes("/api/goods/item/info")) continue;
      try {
        const fromQuery = new URL(record.url).searchParams.get("cateId") || "";
        if (fromQuery) return fromQuery;
      } catch {}
    }
    for (let index = records.length - 1; index >= 0; index -= 1) {
      const record = records[index];
      const path = record?.pathname || record?.url || "";
      if (!path.includes("/api/goods/item/info")) continue;
      const data = parseRecordJson(record);
      const found = findCateIdInData(data);
      if (found) return found;
    }
    return "";
  }

  function findCateIdInData(value, depth = 0) {
    if (!value || depth > 12 || typeof value !== "object") return "";
    if (Array.isArray(value)) {
      for (const child of value) {
        const found = findCateIdInData(child, depth + 1);
        if (found) return found;
      }
      return "";
    }
    for (const key of ["cateId", "categoryId", "cateid", "leafCateId", "catId"]) {
      const candidate = value[key];
      if (candidate !== undefined && candidate !== null && /^\d{1,20}$/.test(String(candidate))) return String(candidate);
    }
    for (const child of Object.values(value)) {
      const found = findCateIdInData(child, depth + 1);
      if (found) return found;
    }
    return "";
  }

  // cateId 只有在成功品面板发过请求后才会出现在监听记录里。首次运行时记录必然为空，
  // 所以先打开一次面板触发 item/list 请求，再回读记录，避免"先有鸡还是先有蛋"。
  async function resolveCateId() {
    const cached = cateIdFromRecords();
    if (cached) return { cateId: cached, openedDialog: null };

    const dialog = await openSuccessDialog();
    if (dialog) {
      await waitForNetworkQuiet({ minimumMs: 900, maximumMs: 8000 });
      await refreshTaskRecords().catch(() => {});
    }
    return { cateId: cateIdFromRecords(), openedDialog: dialog };
  }

  async function addSuccessProductByApi(successItemId, cateId) {
    const subjectItemId = currentJob?.subjectItemId || "";
    if (!/^\d{6,20}$/.test(subjectItemId)) throw new Error("缺少主体商品 ID");
    if (!/^\d{6,20}$/.test(successItemId)) throw new Error("缺少成功品 ID");
    if (!cateId) throw new Error("未能确认成功品所属类目");

    const auth = getDmpAuth();
    if (!auth.tbToken || !auth.csrf) throw new Error("无法从页面 cookie 读取鉴权 token（_tb_token_/csrf），请刷新达摩盘页面后重试");
    const q = dmpAuthQuery(auth);

    // 1. 获取最新日期（可选）。
    let thedate = "";
    try {
      thedate = (await fetchDmpLatestDay()).latestDay;
    } catch {}

    // 2. 搜索目标成功品，拿详情。
    const searchUrl = `${DMP_API_BASE}${SUCCESS_LIST_PATH}?${q}&cateId=${encodeURIComponent(cateId)}&itemId=${subjectItemId}&growthStage=2%2C4%2C1%2C3%2C5%2C6&sellerLevel=1%2C2%2C3%2C4%2C5%2C6%2C7%2C8%2C9&gmvRankRateLevel=1%2C2&pageSize=20&page=1&keyword=${encodeURIComponent(successItemId)}${thedate ? `&thedate=${thedate}` : ""}`;
    const searchResponse = await fetch(searchUrl, { credentials: "include" });
    const search = await searchResponse.json().catch(() => null);
    if (!searchResponse.ok || search?.info?.ok === false) {
      throw new Error(search?.info?.message || "成功品搜索失败，请刷新页面后重试");
    }
    if (!Array.isArray(search?.data?.list)) throw new Error("成功品搜索结果异常，请刷新达摩盘页面后重试");
    const list = search.data.list;
    const found = list.find(item => String(item.itemId) === String(successItemId));
    if (!found) throw successProductNotFoundError(successItemId);

    // 3. 添加成功品。
    const response = await fetch(`${DMP_API_BASE}/api/goods/grow/define/success?${q}`, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        itemId: Number(subjectItemId),
        successItemList: [{
          itemId: Number(successItemId),
          itemTitle: found.itemTitle || found.title || "",
          itemPictUrl: found.itemPictUrl || found.picUrl || "",
          desc: found.desc || "",
          labels: found.labels || []
        }]
      })
    });
    const data = await response.json().catch(() => ({}));
    const apiInfo = data?.info || data?.result?.info;
    if (!response.ok || apiInfo?.ok === false) throw new Error(apiInfo?.message || "成功品添加失败，请刷新页面后重试");
    return { confirmed: true, method: "已添加成功品", api: true };
  }

  // resolveCateId 可能为了触发 item/list 请求而打开了成功品弹窗。
  // 接口添加成功后必须关掉它，否则遮罩会挡住后续的对比页签点击。
  async function closeSuccessDialog(dialog) {
    if (!dialog || !isVisible(dialog)) return;
    const cancel = findVisibleText([/^取消$/, /^关闭$/, /^×$/, /^✕$/], dialog, "button,[role='button'],a,span,i");
    if (cancel) {
      await trustedClick(cancel, "关闭成功品弹窗");
      await wait(300);
    }
    if (isVisible(dialog)) {
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true }));
      await wait(300);
    }
  }

  async function reloadAndVerifySuccessProduct(itemId, label) {
    const subjectItemId = currentJob?.subjectItemId || currentJob?.itemId || "";
    if (!subjectItemId) return false;
    const since = new Date().toISOString();
    await routeToItem(subjectItemId);
    await settleAfterAction({ label, since, activityMs: 9000, minimumMs: 2200, quietMs: 1400, quietMaximumMs: 16000, readbackMs: 9000 });
    await refreshTaskRecords().catch(() => {});
    return hasOnlySuccessProductRecord(itemId, since);
  }

  async function ensureSuccessProductAdded(itemId) {
    // 优先通过接口直接添加成功品，绕开脆弱的 DOM 自动化。
    // resolveCateId 可能顺带打开了成功品弹窗，复用它，避免重复打开。
    let dialog = null;
    try {
      const resolved = await resolveCateId();
      dialog = resolved.openedDialog;
      const apiResult = await addSuccessProductByApi(itemId, resolved.cateId);
      if (apiResult.confirmed) {
        await closeSuccessDialog(dialog);
        const verified = await reloadAndVerifySuccessProduct(itemId, "添加成功品后确认");
        if (verified) return { ...apiResult, verified: true };
        currentJob.successApiError = "添加后未能在已选成功品中确认目标 ID";
        dialog = null;
      }
    } catch (error) {
      currentJob.successApiError = error?.message || String(error);
      if (error?.code === SUCCESS_PRODUCT_NOT_FOUND_CODE) {
        return { confirmed: false, blocking: true, code: error.code, method: error.message };
      }
    }

    if (!dialog) dialog = await openSuccessDialog();
    if (!dialog) {
      const detected = visibleSuccessTextSummary();
      return {
        confirmed: false,
        method: detected.length
          ? `发现成功品区域但弹窗未打开（检测到：${detected.join("、")}）`
          : "页面未发现成功品入口；请确认达摩盘“货品 → 打爆路径”内容已加载",
        filters: []
      };
    }

    const allProducts = findVisibleText([/^所有商品$/], dialog);
    if (allProducts) {
      await trustedClick(allProducts, "切换到所有成功品");
      await wait(250);
    }

    const cleared = await clearSelectedSuccessProducts(dialog);
    if (!cleared.confirmed) return { confirmed: false, method: cleared.method, filters: [], cleared };

    const filters = [];
    for (const filter of workflow.SUCCESS_FILTERS) filters.push(await applySuccessFilter(dialog, filter));
    const failedFilters = filters.filter(result => !result.confirmed);
    if (failedFilters.length) return { confirmed: false, method: `筛选未完成：${failedFilters.map(result => result.label).join("、")}`, filters, cleared };

    const input = findSearchInput(dialog);
    if (!input) return { confirmed: false, method: "未找到成功品搜索框", filters, cleared };
    fillPageInput(input, itemId);
    input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true }));
    input.dispatchEvent(new KeyboardEvent("keyup", { key: "Enter", code: "Enter", bubbles: true }));
    await waitForNetworkQuiet({ minimumMs: 800, maximumMs: 7000 });

    let selectedInDialog = dialogShowsSelectedItem(dialog, itemId);
    if (!selectedInDialog) {
      const addButton = await waitForVisible(() => findItemAddButton(dialog, itemId), 5000);
      if (!addButton) {
        const error = successProductNotFoundError(itemId);
        return { confirmed: false, blocking: true, code: error.code, method: error.message, filters, cleared };
      }
      await trustedClick(addButton, `添加成功品:${itemId}`);
      selectedInDialog = await waitForSelectedSuccessItem(dialog, itemId, 5000);
    }

    if (!selectedInDialog) {
      const error = successProductSelectionFailedError(itemId);
      return { confirmed: false, blocking: true, code: error.code, method: error.message, filters, cleared };
    }

    const confirmButtons = Array.from(dialog.querySelectorAll("button,[role='button'],a,span"))
      .filter(isVisible)
      .filter(element => /^(确认|确定|完成)$/.test(normalizeText(element.textContent)))
      .map(pageClickTarget);
    const confirmButton = confirmButtons[confirmButtons.length - 1];
    if (!confirmButton) return { confirmed: false, method: "成功品已添加，但未找到弹窗确认按钮", filters, cleared };
    await trustedClick(confirmButton, `确认成功品:${itemId}`);
    await waitForNetworkQuiet({ minimumMs: 1200, maximumMs: 9000 });
    await refreshTaskRecords();
    const dialogClosed = !isVisible(dialog);
    if (!dialogClosed) {
      const error = successProductSelectionFailedError(itemId);
      return { confirmed: false, blocking: true, code: error.code, method: error.message, filters, cleared };
    }
    const verified = await reloadAndVerifySuccessProduct(itemId, "页面确认成功品选择").catch(() => false);
    if (!verified) {
      const error = successProductSelectionFailedError(itemId);
      return { confirmed: false, blocking: true, code: error.code, method: error.message, filters, cleared };
    }
    return {
      confirmed: true,
      verified: true,
      method: "已添加成功品并确认目标 ID",
      filters,
      cleared
    };
  }

  function networkHasRange(range, since) {
    const variants = date => [date, date.replace(/-/g, "")];
    return records.some(record => {
      if (since && record.capturedAt && record.capturedAt < since) return false;
      const payload = `${record.url || ""}\n${record.requestBody || ""}`;
      return variants(range.startDate).some(value => payload.includes(value)) && variants(range.endDate).some(value => payload.includes(value));
    });
  }

  // 达摩盘的日期控件（实测 DOM）：
  //   触发器：<div class="mx-trigger"> 文案形如 "⚁ 过去 30 天⌃"（带图标字符和空格）
  //   展开后：快捷按钮 <button class="asiYsrRaf"> 文案 "过去 30 天"
  //   不同页面构建的提交方式不一致：有的会在点快捷项后自动取数并关闭浮层，
  //   有的仍保留浮层，必须再点「确定」。两条路径都要识别。
  // 注意页面提示"默认选择该路径第一个成长阶段时间"——默认区间不是 30 天，
  // 所以这一步不能省，否则拿到的是 10 天左右的阶段数据。
  const THIRTY_DAY_TEXT = /^(近|过去|最近)30(天|日)$/;
  const DATE_TRIGGER_SELECTOR = ".mx-trigger,.mxgc-calendar-rangepicker,[class*='rangepicker'],[class*='trigger']";

  // 日期面板里的两个日期输入框（开始/结束）。必须排除插件面板自己的商品 ID 输入框，
  // 也要排除"定制成功品"弹窗里的搜索框。
  function datePanelInputs(scope = document) {
    return queryElements(scope, "input").filter(isVisible).filter(input => {
      if (input.closest("#dmp-cdp-monitor")) return false;
      if (input.closest("[role='dialog'],.next-dialog,.ant-modal")) return false;
      const signature = `${input.type || ""} ${input.placeholder || ""} ${input.name || ""} ${input.getAttribute("aria-label") || ""} ${input.className || ""}`;
      if (/日期|开始|结束|start|end|date|yyyy|mm|dd|calendar|picker/i.test(signature)) return true;
      // 达摩盘的类名是混淆的，占位符也可能为空——已经填了 ISO 日期的输入框同样认。
      return /^20\d{2}-\d{2}-\d{2}$/.test(String(input.value || "").trim());
    });
  }

  // 判断日期面板/下拉是不是真的展开了。展开的标志是能同时看到
  // 「过去 30 天」这类快捷预设，或者两个日期输入框。
  function datePanelIsOpen(trigger = dateTriggerElement()) {
    if (trigger && datePresetCandidates(trigger).length) return true;
    return datePanelInputs().length >= 2;
  }

  // 日期面板的「确定」在当前达摩盘构建里不是 button，而可能只是带点击监听的 DIV，
  // 也可能是 value="确定" 的 input。旧选择器只查 button/a/span，导致截图里按钮明明
  // 可见，插件却连续记录“未找到「确定」按钮”。先找日期面板的最小公共容器，再兼容
  // 这些真实节点形态；找不到面板容器时才退回全页精确文案搜索。
  function datePanelScope(anchor = null, trigger = null) {
    const inputs = datePanelInputs();
    const starts = [anchor, ...inputs].filter(Boolean);
    for (const start of starts) {
      let node = start;
      for (let depth = 0; node && depth < 10; node = node.parentElement, depth += 1) {
        if (node.nodeType !== 1 || node.closest?.("#dmp-cdp-monitor")) continue;
        const visibleInputs = queryElements(node, "input").filter(isVisible);
        const text = normalizeText(node.textContent);
        // 正确日期浮层同时包含快捷项和「确定」；不再强依赖 input 的类名/占位符。
        const hasPreset = /(近|过去|最近)30(天|日)/.test(text);
        if ((hasPreset && /确定/.test(text) && text.length <= 2000) || (visibleInputs.length >= 2 && /确定|取消/.test(text))) {
          // 若传入了目标触发器，浮层必须在其附近；避免拿到页面上方另一个日期面板。
          if (trigger?.getBoundingClientRect) {
            const triggerRect = trigger.getBoundingClientRect();
            const panelRect = node.getBoundingClientRect();
            const distance = Math.abs(panelRect.top - triggerRect.bottom);
            if (panelRect.bottom < triggerRect.top - 20 || distance > Math.max(900, window.innerHeight)) continue;
          }
          return node;
        }
      }
    }
    return null;
  }

  function dateConfirmCandidates(anchor = null, trigger = dateTriggerElement()) {
    const panel = datePanelScope(anchor, trigger);
    const scopes = panel ? [panel, document] : [document];
    const seen = new Set();
    const candidates = [];
    for (const scope of scopes) {
      for (const element of queryElements(scope, "button,[role='button'],a,label,span,div,input[type='button'],input[type='submit'],[aria-label],[title]")) {
        if (!isVisible(element) || element.closest?.("#dmp-cdp-monitor")) continue;
        const labels = [element.textContent, element.getAttribute?.("aria-label"), element.getAttribute?.("title"), element.value]
          .map(normalizeText)
          .filter(Boolean);
        if (!labels.some(label => label === "确定")) continue;
        const target = pageClickTarget(element);
        if (!target || seen.has(target) || !isVisible(target)) continue;
        const rect = target.getBoundingClientRect();
        const triggerRect = trigger?.getBoundingClientRect?.();
        const nearTrigger = !triggerRect || (
          rect.top >= triggerRect.top - 30
          && Math.abs(rect.top - triggerRect.bottom) <= Math.max(850, window.innerHeight * 0.9)
        );
        if (!panel && !nearTrigger) continue;
        seen.add(target);
        candidates.push({
          target,
          inPanel: Boolean(panel && panel.contains(target)),
          semantic: target.matches?.("button,[role='button'],input[type='button'],input[type='submit']") ? 1 : 0,
          distance: triggerRect ? Math.abs(rect.top - triggerRect.bottom) + Math.abs(rect.left - triggerRect.left) * 0.15 : 0,
          area: rect.width * rect.height
        });
      }
      if (candidates.some(candidate => candidate.inPanel)) break;
    }
    return candidates
      .sort((left, right) => Number(right.inPanel) - Number(left.inPanel) || right.semantic - left.semantic || left.distance - right.distance || left.area - right.area)
      .map(candidate => candidate.target);
  }

  async function waitForDateConfirm(anchor = null, trigger = dateTriggerElement(), timeoutMs = 2400) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      const confirm = dateConfirmCandidates(anchor, trigger)[0];
      if (confirm) return confirm;
      await wait(160);
    }
    return null;
  }

  // 选择快捷项后的页面有两种真实行为：
  //   1. 新构建立即把触发器改成「过去 30 天」、发请求并关闭浮层；
  //   2. 旧构建保留浮层，等用户再点「确定」。
  // 先找与目标触发器关联的「确定」；只有连续两轮都看到预设已选中且浮层已关闭，
  // 才认定为自动提交，避免把浮层重绘的短暂空档误判成成功。
  async function waitForDatePresetOutcome(anchor, trigger, timeoutMs = 2400) {
    const started = Date.now();
    let closedSelectedRounds = 0;
    while (Date.now() - started < timeoutMs) {
      const confirm = dateConfirmCandidates(anchor, trigger)[0];
      if (confirm) return { mode: "confirm", confirm };
      const shown = currentDatePresetText();
      if (THIRTY_DAY_TEXT.test(shown) && !datePanelIsOpen(trigger)) {
        closedSelectedRounds += 1;
        if (closedSelectedRounds >= 2) return { mode: "auto", shown };
      } else {
        closedSelectedRounds = 0;
      }
      await wait(160);
    }
    const shown = currentDatePresetText();
    if (THIRTY_DAY_TEXT.test(shown) && !datePanelIsOpen(trigger)) return { mode: "auto", shown };
    return { mode: "missing", shown };
  }

  // 展开前先把触发器顶到视口上部，给下方的浮层留出空间。
  // 这一步是必须的：日期浮层是 position:absolute、锚在触发器下方的，
  // 触发器本身在视口下半部分时，浮层里的「过去 30 天」和「确定」会落到视口以下
  // （实测触发器在 y≈880 时，确定按钮在 y≈1084，而视口只有 985 高）。
  // 而对浮层调用 scrollIntoView 是没用的——滚动会带着锚点一起移动，浮层永远追不进视口。
  // CDP 按坐标点击点不到视口外的点，于是就出现"面板打开了、但预设点不到"的现象。
  async function scrollTriggerToTop(trigger) {
    if (!trigger?.getBoundingClientRect) return;
    // 目标：把触发器放到视口顶部往下约 1/5 的位置，下面至少留 400px 给浮层。
    const wanted = Math.round(window.innerHeight * 0.2);
    for (let attempt = 0; attempt < 3; attempt += 1) {
      const rect = trigger.getBoundingClientRect();
      const delta = rect.top - wanted;
      if (Math.abs(delta) < 40) return;
      window.scrollBy({ top: delta, behavior: "instant" });
      await wait(240);
    }
  }

  // 严格按页面交互顺序：展开日期下拉 → 选「过去 30 天」→ 若浮层仍在则点「确定」。
  // 快捷项自动提交的页面不能继续找按钮或重复点击；页面预设就是用户指定口径，
  // 不再提交后重开面板改写成另一组明确日期。
  async function applyThirtyDayPreset() {
    // 页面有两个日期区域。必须先锚定「关键指标对比」页签所在模块下方的日期触发器，
    // 再从这个触发器展开的邻近浮层中找快捷项；禁止全页直接搜“过去30天”。
    const trigger = dateTriggerElement();
    if (!trigger) {
      tabDiag("日期：未找到关键指标对比下方的日期控件触发器");
      return false;
    }
    const triggerRect = trigger.getBoundingClientRect();
    const tabAnchor = comparisonDateAnchor();
    const tabRect = tabAnchor?.getBoundingClientRect?.();
    tabDiag("日期：定位关键指标对比下方时间控件", {
      text: normalizeText(trigger.textContent).slice(0, 30),
      x: Math.round(triggerRect.left + triggerRect.width / 2),
      y: Math.round(triggerRect.top + triggerRect.height / 2),
      关键指标页签Y: tabRect ? Math.round(tabRect.top + tabRect.height / 2) : null
    });

    let preset = datePresetCandidates(trigger)[0] || null;
    for (let attempt = 0; attempt < 3 && !preset; attempt += 1) {
      // 每轮都重新把正确触发器顶上去：点击后页面可能又滚回去了。
      await scrollTriggerToTop(trigger);
      await trustedClick(trigger, `日期触发器#${attempt + 1}`);
      for (let poll = 0; poll < 6 && !preset; poll += 1) {
        await wait(240);
        preset = datePresetCandidates(trigger)[0] || null;
      }
    }
    if (!preset) {
      tabDiag("日期：目标时间弹窗展开后仍未找到「过去 30 天」快捷按钮", { 面板已展开: datePanelIsOpen(trigger) });
      return false;
    }
    // 选预设同样要真实点击，否则点了也不会生效。
    await trustedClick(preset, "日期预设:过去30天");
    await wait(320);

    // 3. 兼容两种提交模式：自动生效并收起，或保留面板等待「确定」。
    const outcome = await waitForDatePresetOutcome(preset, trigger);
    if (outcome.mode === "auto") {
      tabDiag("日期：快捷项已自动生效，无需点击「确定」", { shown: outcome.shown });
      return true;
    }
    if (outcome.mode !== "confirm") {
      tabDiag("日期：目标时间弹窗未找到「确定」按钮", { 面板已展开: datePanelIsOpen(trigger), 可见日期输入框: datePanelInputs().length });
      return false;
    }
    await trustedClick(outcome.confirm, "日期确定");
    await wait(420);
    tabDiag("日期：已提交「过去 30 天」预设");
    return true;
  }

  // 读日期控件上的预设标签（形如 "⚁ 过去 30 天⌃"）。
  // 「推广策略对比」「人群对比」默认显示预设标签，「关键指标对比」显示具体日期。
  function currentDatePresetText() {
    const trigger = dateTriggerElement();
    if (!trigger) return "";
    const text = normalizeText(trigger.textContent);
    if (/20\d{2}-\d{2}-\d{2}/.test(text)) return "";
    // 去掉两端的图标字符，只留 "过去30天" 这样的核心文案。
    return text.replace(/^[^一-龥]+/, "").replace(/[^一-龥\d]+$/, "");
  }

  // 读当前日期控件上显示的区间，用来确认"过去 30 天"是否真的生效了。
  // 页面默认是"该路径第一个成长阶段"（实测 07-14~07-23，约 10 天），必须改掉。
  // 只从日期控件本身读：页面「成长阶段」区域也有 "20260714-20260723" 这类文本，
  // 用宽泛的 div/span 选择器会把它误当成日期控件。
  function comparisonDateAnchor() {
    return comparisonTabCandidates("关键指标对比")
      .filter(isVisible)
      .sort((left, right) => {
        const leftRect = left.getBoundingClientRect();
        const rightRect = right.getBoundingClientRect();
        return leftRect.width * leftRect.height - rightRect.width * rightRect.height;
      })[0] || null;
  }

  function isDateTriggerCandidate(element) {
    if (!isVisible(element) || element.closest?.("#dmp-cdp-monitor")) return false;
    const text = normalizeText(element.textContent);
    if (text.length > 40) return false;
    const hasPreset = /(过去|近|最近)\d+(天|日)/.test(text);
    const hasDateRange = (text.match(/20\d{2}-\d{2}-\d{2}/g) || []).length >= 2;
    return hasPreset || hasDateRange;
  }

  // 只取「关键指标对比」页签所在模块内、且位于页签附近/下方的日期控件。
  // 从页签逐层向上找第一个同时包含日期触发器的容器，可天然排除页面上方另一个时间区域。
  function dateTriggerElement() {
    const anchor = comparisonDateAnchor();
    if (!anchor) return null;
    let scopedCandidates = [];
    let scope = anchor.parentElement;
    for (let depth = 0; scope && depth < 10; scope = scope.parentElement, depth += 1) {
      scopedCandidates = queryElements(scope, DATE_TRIGGER_SELECTOR).filter(isDateTriggerCandidate);
      if (scopedCandidates.length) break;
    }
    if (!scopedCandidates.length) return null;
    const anchorRect = anchor.getBoundingClientRect();
    return scopedCandidates
      .map(element => {
        const rect = element.getBoundingClientRect();
        const deltaY = rect.top - anchorRect.bottom;
        return {
          element,
          belowPenalty: deltaY >= -40 ? 0 : 100000,
          distance: Math.abs(deltaY) + Math.abs(rect.left - anchorRect.left) * 0.15,
          area: rect.width * rect.height
        };
      })
      .sort((left, right) => left.belowPenalty - right.belowPenalty || left.distance - right.distance || left.area - right.area)[0]?.element || null;
  }

  // 只接受目标日期触发器附近、位于其下方的“过去30天”候选。
  // 这样页面上方另一个时间区域即使同时显示同名快捷项，也不会被误点。
  function datePresetCandidates(trigger) {
    if (!trigger?.getBoundingClientRect) return [];
    const triggerRect = trigger.getBoundingClientRect();
    const seen = new Set();
    return queryElements(document, "button,[role='button'],a,li,span,div,[aria-label],[title]")
      .filter(isVisible)
      .filter(element => {
        if (element.closest?.("#dmp-cdp-monitor")) return false;
        const text = normalizeText(element.textContent);
        return text.length <= 40 && THIRTY_DAY_TEXT.test(text);
      })
      .map(element => pageClickTarget(element))
      .filter(target => {
        if (!target || seen.has(target) || !isVisible(target)) return false;
        if (target === trigger || target.contains?.(trigger) || trigger.contains?.(target)) return false;
        seen.add(target);
        const rect = target.getBoundingClientRect();
        const verticalDistance = Math.abs(rect.top - triggerRect.bottom);
        return rect.top >= triggerRect.top - 30 && verticalDistance <= Math.max(850, window.innerHeight * 0.9);
      })
      .map(target => {
        const rect = target.getBoundingClientRect();
        return {
          target,
          semantic: target.matches?.("button,[role='button'],li") ? 1 : 0,
          floating: isFloatingLayer(target) ? 1 : 0,
          distance: Math.abs(rect.top - triggerRect.bottom) + Math.abs(rect.left - triggerRect.left) * 0.15,
          area: rect.width * rect.height
        };
      })
      .sort((left, right) => right.floating - left.floating || right.semantic - left.semantic || left.distance - right.distance || left.area - right.area)
      .map(candidate => candidate.target);
  }

  function currentDateRangeText() {
    const trigger = dateTriggerElement();
    if (!trigger) return "";
    const text = normalizeText(trigger.textContent);
    return /20\d{2}-\d{2}-\d{2}/.test(text) ? text : "";
  }

  function rangeSpansAtLeast(text, minDays) {
    const dates = (text.match(/20\d{2}-\d{2}-\d{2}/g) || []).map(value => Date.parse(`${value}T00:00:00Z`));
    if (dates.length < 2 || dates.some(Number.isNaN)) return false;
    const days = Math.round((Math.max(...dates) - Math.min(...dates)) / 86400000) + 1;
    return days >= minDays;
  }

  // 从控件文案里取出起止日期，用来和我们要的窗口逐日核对。
  function parseTriggerRange(text) {
    const dates = (text.match(/20\d{2}-\d{2}-\d{2}/g) || []).sort();
    if (dates.length < 2) return null;
    return { startDate: dates[0], endDate: dates[dates.length - 1] };
  }

  // 控件区间是否正好等于我们要的窗口。相等才算"日期已落实"，
  // 只是跨度够 30 天不算——那可能是含今日的口径，和报告的"截至昨天"差一天。
  function rangeMatchesExactly(text, range) {
    const shown = parseTriggerRange(text);
    return Boolean(shown && range && shown.startDate === range.startDate && shown.endDate === range.endDate);
  }

  // 日期落实分三档，写进报告让下游知道拿到的到底是什么口径：
  //   exact  —— 控件区间与"截至昨天的 30 个完整自然日"逐日相等，或接口请求里带着这两个日期；
  //   preset —— 页面已明确显示并提交「过去 30 天」，或控件区间达到 30 天量级；
  //   failed —— 仍是默认的成长阶段区间（实测约 10 天），这种数据不能当 30 天用。
  async function confirmThirtyDays(range, since) {
    await refreshTaskRecords().catch(() => {});
    // 接口请求里直接带着目标起止日期，是最硬的证据。
    if (networkHasRange(range, since)) {
      tabDiag("日期：接口请求已携带目标起止日期", { 期望: `${range.startDate}~${range.endDate}` });
      return { confirmed: true, precision: "exact", shown: `${range.startDate} 至 ${range.endDate}` };
    }

    const before = currentDateRangeText();
    const presetBefore = currentDatePresetText();
    // 日期是全局生效的：在任一页签改成目标区间后，切到其它页签会沿用这个区间。
    // 所以先看当前区间是不是已经正好是目标窗口（首个页签改完，后续页签直接继承）。
    if (rangeMatchesExactly(before, range)) {
      tabDiag("日期：控件区间已等于目标窗口，沿用", { shown: before });
      return { confirmed: true, precision: "exact", shown: before };
    }
    // 页面会把已提交的快捷项显示为「过去 30 天」，而不是显示具体起止日。
    // 这是权威的页面选中状态，后续页签直接沿用，不能再把它误判成日期失败。
    if (THIRTY_DAY_TEXT.test(presetBefore)) {
      tabDiag("日期：页面已选中「过去 30 天」，沿用", { shown: presetBefore });
      return { confirmed: true, precision: "preset", shown: presetBefore };
    }

    // 未选中时严格执行用户指定的三步；页面偶发动画/防抖，最多完整重试两轮。
    for (let attempt = 0; attempt < 2; attempt += 1) {
      if (!await applyThirtyDayPreset()) continue;
      // 改完日期页面会重新取数，这一批数据必须等它真的落地。
      await settleAfterAction({ label: "日期确认", since, minimumMs: 1000, quietMs: 1200, quietMaximumMs: 12000, readbackMs: 8000 });
      const after = currentDateRangeText();
      const presetAfter = currentDatePresetText();
      if (networkHasRange(range, since) || rangeMatchesExactly(after, range)) {
        tabDiag("日期：已确认为目标窗口", { before, after });
        return { confirmed: true, precision: "exact", shown: after || `${range.startDate} 至 ${range.endDate}` };
      }
      if (THIRTY_DAY_TEXT.test(presetAfter)) {
        tabDiag("日期：已确认页面预设「过去 30 天」", { shown: presetAfter, 第几轮: attempt + 1 });
        return { confirmed: true, precision: "preset", shown: presetAfter };
      }
      if (rangeSpansAtLeast(after, 28)) {
        tabDiag("日期：已是 30 天量级，按页面口径采集", { before, after, 第几轮: attempt + 1 });
        return { confirmed: true, precision: "preset", shown: after };
      }
      tabDiag("日期：提交「过去 30 天」后页面状态未匹配，准备重试", { before, after, presetAfter, 第几轮: attempt + 1 });
    }
    await refreshTaskRecords().catch(() => {});
    const final = currentDateRangeText();
    const finalPreset = currentDatePresetText();
    if (networkHasRange(range, since) || rangeMatchesExactly(final, range)) {
      return { confirmed: true, precision: "exact", shown: final || `${range.startDate} 至 ${range.endDate}` };
    }
    if (THIRTY_DAY_TEXT.test(finalPreset)) return { confirmed: true, precision: "preset", shown: finalPreset };
    if (rangeSpansAtLeast(final, 28)) return { confirmed: true, precision: "preset", shown: final };
    return { confirmed: false, precision: "failed", shown: final || finalPreset };
  }

  // 达摩盘业务接口所在的域（业务请求可能发到 dmp.taobao.com 或 dmp.advgateway.taobao.com），
  // 用来把埋点流量（gm.mmstat.com / alimama_bp / aes 等）排除在"有没有真正取数"的判断之外。
  // 定义在此处而非文件靠后：clickTabAndAwaitData 会用到，const 不像函数声明那样提升。
  const BUSINESS_HOST = /(^|\.)dmp(\.advgateway)?\.taobao\.com$/i;
  const BUSINESS_PATH = /\/(api|api_2|dataplatform)\//i;

  function isBusinessRecord(record) {
    if (!record || record.kind) return false;
    if (completeness.isTransportOnlyRecord(record)) return false;
    const raw = record.url || "";
    let host = "";
    try { host = new URL(raw).hostname; } catch { return false; }
    if (!BUSINESS_HOST.test(host)) return false;
    const path = record.pathname || (() => { try { return new URL(raw).pathname; } catch { return ""; } })();
    return BUSINESS_PATH.test(path);
  }

  function countBusinessRecords(since) {
    return records.filter(record => {
      if (since && record.capturedAt && record.capturedAt < since) return false;
      return isBusinessRecord(record);
    }).length;
  }

  // 达摩盘前端是 Magix/Brix，页签监听的是 mousedown/pointerdown 而不是 click。
  // 只派发一个裸 click 事件框架收不到（手动点有效、插件点无效就是这么来的），
  // 所以要补全整个指针事件序列。javascript: href 的默认导航会被页面 CSP 拦截，
  // 用一次性捕获监听器掐掉，避免控制台刷 security 违规。
  function dispatchRealisticClick(element) {
    const view = element.ownerDocument?.defaultView || window;
    const doc = element.ownerDocument || document;
    const rect = element.getBoundingClientRect();
    const clientX = Math.round(rect.left + rect.width / 2);
    const clientY = Math.round(rect.top + rect.height / 2);
    const base = { bubbles: true, cancelable: true, view, clientX, clientY, button: 0, buttons: 1 };

    // 达摩盘页签的 href 是 "javascript:;"（空操作），真正的切换逻辑绑在事件监听器上。
    // 这个空导航仍会被页面 CSP 拦截并刷 security 违规，所以要掐掉。
    // guard 必须挂在 document 捕获阶段：我们点击的目标可能是内层 DIV/SPAN，
    // 自身没有 href，但事件冒泡到父级 <a> 时照样触发导航——挂在元素自己身上拦不住。
    const guard = event => {
      const anchor = event.target?.closest?.("a[href]");
      const href = (anchor?.getAttribute("href") || "").trim().toLowerCase();
      if (href.startsWith("javascript:")) event.preventDefault();
    };
    doc.addEventListener("click", guard, { capture: true });

    try {
      const PointerEventCtor = view.PointerEvent || null;
      const pointer = type => PointerEventCtor
        ? new PointerEventCtor(type, { ...base, pointerId: 1, pointerType: "mouse", isPrimary: true })
        : new MouseEvent(type === "pointerdown" ? "mousedown" : "mouseup", base);

      element.dispatchEvent(new MouseEvent("mouseover", { ...base, buttons: 0 }));
      element.dispatchEvent(new MouseEvent("mousemove", { ...base, buttons: 0 }));
      element.dispatchEvent(pointer("pointerdown"));
      element.dispatchEvent(new MouseEvent("mousedown", base));
      element.dispatchEvent(pointer("pointerup"));
      element.dispatchEvent(new MouseEvent("mouseup", { ...base, buttons: 0 }));
      element.dispatchEvent(new MouseEvent("click", { ...base, buttons: 0 }));
    } finally {
      doc.removeEventListener("click", guard, { capture: true });
    }
  }


  // 通过 CDP Input 域派发浏览器级真实点击。
  // 内容脚本合成的事件 isTrusted 恒为 false，达摩盘页签逻辑不响应
  // （实测埋点 SDK 收到了 mousedown 并上报 _g_et=mousedown，但页面既不切换也不取数）。
  function tabDiag() {}

  // 把元素滚进视口，并确认真的滚进来了。
  // "nearest" 对已在滚动容器内的元素常常原地不动（实测页签 y=1256 而视口高 985，
  // nearest 完全没滚），所以这里用 center 并循环校验，必要时直接操作 window.scrollBy。
  //
  // 例外：浮层（日期面板、下拉菜单）是 position:absolute/fixed 锚在触发器上的，
  // 滚动会带着锚点一起动，浮层永远追不进视口，硬滚只会把页面滚乱。
  // 这类元素直接判定"能不能点"，滚动交给展开前的 scrollTriggerToTop 负责。
  function isFloatingLayer(element) {
    for (let node = element, depth = 0; node && depth < 6; node = node.parentElement, depth += 1) {
      const view = node.ownerDocument?.defaultView || window;
      const position = view.getComputedStyle(node).position;
      if (position === "absolute" || position === "fixed") return true;
    }
    return false;
  }

  async function ensureInViewport(element) {
    const fitsNow = () => {
      const rect = element.getBoundingClientRect();
      const centerY = rect.top + rect.height / 2;
      const centerX = rect.left + rect.width / 2;
      return centerY >= 0 && centerY <= window.innerHeight && centerX >= 0 && centerX <= window.innerWidth;
    };
    if (fitsNow()) return true;
    // 浮层不滚：滚了也追不进来，还会把页面位置搞乱。
    if (isFloatingLayer(element)) return false;
    for (let attempt = 0; attempt < 3; attempt += 1) {
      const rect = element.getBoundingClientRect();
      const centerY = rect.top + rect.height / 2;
      const centerX = rect.left + rect.width / 2;
      const fits = centerY >= 0 && centerY <= window.innerHeight
        && centerX >= 0 && centerX <= window.innerWidth;
      if (fits) return true;
      if (attempt === 0) {
        element.scrollIntoView?.({ block: "center", inline: "center" });
      } else {
        // scrollIntoView 不奏效时（元素在自定义滚动容器里），手动补偿差值。
        window.scrollBy({ top: centerY - window.innerHeight / 2, behavior: "instant" });
      }
      await wait(260);
    }
    const rect = element.getBoundingClientRect();
    const centerY = rect.top + rect.height / 2;
    return centerY >= 0 && centerY <= window.innerHeight;
  }

  async function realClickViaCdp(element, label) {
    if (!element?.getBoundingClientRect) return false;
    if (!await ensureInViewport(element)) {
      const rect = element.getBoundingClientRect();
      tabDiag("跳过：无法把目标滚进视口", {
        label, tag: element.tagName,
        y: Math.round(rect.top + rect.height / 2), vh: window.innerHeight
      });
      return false;
    }
    const rect = element.getBoundingClientRect();
    if (!rect.width || !rect.height) {
      tabDiag("跳过：元素尺寸为 0", { label, tag: element.tagName });
      return false;
    }
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    // CDP 坐标以视口左上角为原点，视口外的点点不到。
    if (x < 0 || y < 0 || x > window.innerWidth || y > window.innerHeight) {
      tabDiag("跳过：中心点在视口外", { label, tag: element.tagName, x: Math.round(x), y: Math.round(y), vw: window.innerWidth, vh: window.innerHeight });
      return false;
    }
    // CDP 按坐标点击命中的是该点最顶层的元素。插件面板固定在右下角，
    // 可能正好盖住目标——那样点下去只会点到面板自己，必须跳过。
    // 其它情况（命中的是目标的子节点/父容器/兄弟文字节点）都属于正常命中：
    // 页面控件本来就是多层嵌套，点中哪一层都会冒泡到真正的监听器上。
    const topMost = document.elementFromPoint(x, y);
    if (!topMost) {
      tabDiag("跳过：该坐标没有元素", { label, x: Math.round(x), y: Math.round(y) });
      return false;
    }
    if (topMost.closest?.("#dmp-cdp-monitor") || root.contains(topMost)) {
      tabDiag("跳过：被插件面板遮挡", { label, x: Math.round(x), y: Math.round(y) });
      return false;
    }
    try {
      const result = await runtimeMessage("DMP_CDP_REAL_CLICK", { x: Math.round(x), y: Math.round(y) });
      if (!result?.ok) {
        tabDiag("CDP 真实点击失败", { label, error: result?.error || "无响应" });
        return false;
      }
      tabDiag("CDP 真实点击已派发", { label, tag: element.tagName, x: Math.round(x), y: Math.round(y), hit: topMost.tagName });
      return true;
    } catch (error) {
      tabDiag("CDP 真实点击异常", { label, error: String(error?.message || error) });
      return false;
    }
  }

  // 插件面板固定在右下角，可能正好压住页面控件，导致 CDP 按坐标点击命中面板自己。
  // 面板是 position:fixed 的浮层，隐藏它不会让页面重排，所以可以临时藏起来再点。
  async function withPanelHidden(run) {
    const previous = root.style.visibility;
    root.style.visibility = "hidden";
    // 给一帧时间让 elementFromPoint 反映隐藏后的命中结果。
    await wait(60);
    try { return await run(); }
    finally { root.style.visibility = previous; }
  }

  // 达摩盘所有交互控件（页签、日期下拉、场景渠道下拉）走的都是 Magix 的
  // mousedown/pointerdown 监听，只认 isTrusted 的真实事件。
  // 内容脚本合成的事件 isTrusted 恒为 false：埋点 SDK 会收到并上报，
  // 但页面既不切换也不取数——实测就是日期停在默认阶段区间、
  // 场景下拉展开后选项点不动（下拉一直挂着）的原因。
  // 所以统一先走 CDP 真实点击；被面板挡住或落在视口外时各有一次补救；
  // 合成事件只作为最后的兜底（基本不管用，但比什么都不做好）。
  async function trustedClick(element, label) {
    if (!element) return false;
    if (await realClickViaCdp(element, label)) return true;
    // 可能是被插件面板挡住了，藏起面板再试一次。
    if (await withPanelHidden(() => realClickViaCdp(element, `${label}(面板已隐藏)`))) return true;
    // 可能是浮层里的元素落在了视口以下（日期面板的「确定」、下拉末尾的渠道）。
    // 浮层锚在触发器上不能单独滚，但可以整页滚动，把浮层带进视口。
    if (await scrollPageUntilClickable(element)) {
      if (await realClickViaCdp(element, `${label}(已整页滚动)`)) return true;
      if (await withPanelHidden(() => realClickViaCdp(element, `${label}(已滚动+面板已隐藏)`))) return true;
    }
    tabDiag("CDP 点击不可用，退回合成事件（达摩盘可能不响应）", { label });
    dispatchRealisticClick(element);
    return false;
  }

  // 整页滚动，直到目标元素的中心点进入视口。
  // 用于浮层内落在视口外的元素：浮层自身不能 scrollIntoView（会带着锚点一起动），
  // 但整页滚动会同时移动锚点和浮层，能把浮层下半部分带进视口。
  async function scrollPageUntilClickable(element) {
    for (let attempt = 0; attempt < 4; attempt += 1) {
      const rect = element.getBoundingClientRect();
      const centerY = rect.top + rect.height / 2;
      const centerX = rect.left + rect.width / 2;
      if (centerY >= 0 && centerY <= window.innerHeight && centerX >= 0 && centerX <= window.innerWidth) {
        return true;
      }
      const before = window.scrollY;
      // 目标在视口下方就往下滚，在上方就往上滚，每次滚到让它落在视口中部。
      window.scrollBy({ top: Math.round(centerY - window.innerHeight / 2), behavior: "instant" });
      await wait(240);
      // 滚不动了（已经到底/到顶）就别再试。
      if (window.scrollY === before) break;
    }
    const rect = element.getBoundingClientRect();
    const centerY = rect.top + rect.height / 2;
    const ok = centerY >= 0 && centerY <= window.innerHeight;
    if (!ok) tabDiag("整页滚动后目标仍在视口外", { y: Math.round(centerY), vh: window.innerHeight });
    return ok;
  }

  // 达摩盘页签同一份文案会同时出现在 A / DIV / SPAN 三层元素上（已由页面实测确认），
  // 监听器可能挂在其中任意一层，只点一个未必生效。这里把所有同名候选按"由内到外"
  // 依次尝试，每次点完都核对是否真的触发了业务请求。
  function comparisonTabCandidates(label) {
    const wanted = normalizeText(label);
    const matched = queryElements(document, "[role='tab'],button,a,li,span,div")
      .filter(isVisible)
      .filter(element => normalizeText(element.textContent) === wanted);
    // 文本越短越接近真实叶子节点，优先点内层，再退到外层容器。
    const ordered = matched.sort((left, right) => (left.textContent || "").length - (right.textContent || "").length);
    const seen = new Set();
    return ordered.filter(element => {
      if (seen.has(element)) return false;
      seen.add(element);
      return true;
    }).slice(0, 6);
  }

  // 判断页签是否已经是选中态。
  // 达摩盘用下划线+主题色表示选中，class 名是混淆的（asiYsrRaf 这类），
  // 所以 active/selected 这类关键字基本匹配不到——只靠 class 判断会把
  // 默认选中的「关键指标对比」也判成未选中，而它本来就选中、点了也不会重新取数，
  // 于是"已激活:false + 业务请求数:0"，整个页签被误判成失败。
  // 因此使用 aria 状态、class 关键字和目标本身的底部高亮边框。不能再用“文字是蓝色”
  // 作为选中依据：当前页面三个页签都继承了蓝色主题文字，0.9.10 因而把推广策略和
  // 人群对比都误判为已选中，实际一次页签点击都没有发生。
  function isTabActive(element) {
    const clickTarget = pageClickTarget(element);
    const nodes = [element, clickTarget, clickTarget?.parentElement].filter(Boolean);
    for (const node of nodes) {
      if (node.getAttribute?.("aria-selected") === "true") return true;
      const cls = String(node.className || "");
      if (/(^|[\s_-])(active|selected|current|checked)([\s_-]|$)|is-active|is-selected|-active|-selected/i.test(cls)) return true;
      if (hasSelectedStyling(node)) return true;
    }
    return false;
  }

  // 选中态的视觉特征只认目标自身的底部高亮边框（下划线）。主题色文字不是可靠信号。
  function hasSelectedStyling(node) {
    if (!node?.getBoundingClientRect) return false;
    const view = node.ownerDocument?.defaultView || window;
    let style;
    try { style = view.getComputedStyle(node); } catch { return false; }
    if (!style) return false;
    // 下划线：底边框有宽度且颜色不透明。
    const bottomWidth = parseFloat(style.borderBottomWidth) || 0;
    if (bottomWidth >= 2 && !/rgba\([^)]*,\s*0\)/.test(style.borderBottomColor || "")) return true;
    return false;
  }

  function tabIsCurrentlyActive(label) {
    return comparisonTabCandidates(label).some(isTabActive);
  }

  // 只有三个页签中恰好一个具备选中信号时，才允许靠样式判定当前页签。
  // 如果三个都被主题样式误命中，就返回空，强制实际点击并用内容/请求核对。
  function uniquelyActiveComparisonTab() {
    const activeLabels = workflow.COMPARISON_TABS.filter(label => tabIsCurrentlyActive(label));
    return activeLabels.length === 1 ? activeLabels[0] : "";
  }

  // 每个对比页签独有的内容特征。用来在 class 名混淆、又没有新请求（命中缓存）时
  // 判断"当前显示的到底是哪个页签的内容"——这是最贴近用户所见的信号。
  const TAB_CONTENT_MARKERS = {
    "关键指标对比": [/营销推广点击量/, /自然点击量/, /支付转化率/],
    "推广策略对比": [/场景投放策略明细/, /一级场景名称/, /消耗占比/],
    "人群对比": [/人群结构/, /人群数/, /宝贝新客/]
  };

  // 页面上是否正在显示该页签的内容。
  function tabContentVisible(label) {
    const markers = TAB_CONTENT_MARKERS[label] || [];
    if (!markers.length) return false;
    const text = normalizeText(document.body?.textContent || "");
    // 至少命中两个特征才算，避免单个词在别处偶然出现造成误判。
    const hits = markers.filter(pattern => pattern.test(text)).length;
    return hits >= 2;
  }

  // 点击页签后确认它确实切过去了。
  // 三种信号取其一，任何一个成立都算成功：
  //   ① 页签变成激活态（aria/class/选中样式）；
  //   ② 页面上出现了该页签独有的内容特征；
  //   ③ 产生了新的业务请求。
  // 只用 ①+③ 会漏判：达摩盘 class 名混淆、默认页签本来就选中且命中缓存不重新取数，
  // 「关键指标对文」这种默认页签就会被误判成"点击失败"（实测 已激活:false + 业务请求数:0）。
  async function clickTabAndAwaitData(label) {
    const candidates = comparisonTabCandidates(label);
    if (!candidates.length) {
      tabDiag("未找到页签元素", { label });
      return { opened: false, method: "", since: "", reason: "页面未找到该页签元素" };
    }

    // 已经是当前页签就不用点了，直接去确认日期。
    const activeBefore = uniquelyActiveComparisonTab();
    if (activeBefore === label || tabContentVisible(label)) {
      tabDiag("页签已处于选中态，跳过点击", { label, 内容特征: tabContentVisible(label), 唯一选中页签: activeBefore || "无" });
      return { opened: true, method: "已选中", since: new Date().toISOString() };
    }

    tabDiag("开始点击页签", { label, candidates: candidates.map(el => el.tagName).join(",") });

    const strategies = [
      { name: "CDP真实点击", run: element => realClickViaCdp(element, label) },
      // 被插件面板挡住时，藏起面板再按坐标点一次。
      { name: "CDP真实点击(面板已隐藏)", run: element => withPanelHidden(() => realClickViaCdp(element, `${label}(面板已隐藏)`)) },
      { name: "合成事件序列", run: element => { dispatchRealisticClick(element); return true; } }
    ];

    for (const strategy of strategies) {
      for (let index = 0; index < candidates.length; index += 1) {
        const element = candidates[index];
        const since = new Date().toISOString();
        const dispatched = await strategy.run(element);
        if (currentJob) {
          currentJob.tabClicks = currentJob.tabClicks || [];
          currentJob.tabClicks.push({
            label, strategy: strategy.name, attempt: index + 1, tag: element.tagName,
            dispatched: Boolean(dispatched), text: normalizeText(element.textContent).slice(0, 20)
          });
        }
        if (!dispatched) continue;
        // 点完要给页面时间发请求、给 CDP 时间取回响应体、给插件时间读回记录。
        await settleAfterAction({ label: `页签点击:${label}`, since, minimumMs: 900, quietMaximumMs: 10000, readbackMs: 7000 });
        const hits = countBusinessRecords(since);
        const active = uniquelyActiveComparisonTab() === label;
        const content = tabContentVisible(label);
        tabDiag("点击结果", { label, strategy: strategy.name, tag: element.tagName, 业务请求数: hits, 已激活: active, 内容特征: content });
        // 三种信号任一成立就算切过去了：有没有立刻取数取决于页面缓存，
        // 日期确认那一步还会再触发一次。
        if (active || content || hits > 0) {
          return { opened: true, method: `${strategy.name}/${element.tagName}#${index + 1}`, since };
        }
      }
    }
    return { opened: false, method: "", since: "", reason: `${candidates.length} 个候选 × ${strategies.length} 种点击方式都没能切换页签` };
  }

  // 「推广策略对比」页签下有个「场景投放策略明细」下拉（当前页面组件配置的 7 个渠道：
  // 关键词推广/人群推广/线索推广/货品全站推/店铺运营/货品运营/内容营销）。
  // 每切一个渠道才会请求一次 scene 明细，不遍历就只能拿到默认的「关键词推广」。
  const SCENE_CHANNELS = ["关键词推广", "人群推广", "线索推广", "货品全站推", "店铺运营", "货品运营", "内容营销"];

  // 找「场景投放策略明细」的下拉触发器。
  // 难点：下拉展开后，选项列表里每个 <li> 的文案也等于渠道名，
  // 直接按文案找会把选项当成触发器，导致第二轮开始全部错位。
  // 达摩盘的类名是混淆的（asiYsrRqV 这类），既不能靠 select/trigger 关键字来认，
  // 也不能靠它来排除——实测触发器自身的混淆类名可能含 "select"，
  // 旧逻辑把它当弹出层排除掉，于是报"未找到渠道下拉触发器"、7 个渠道一个都没切。
  //
  // 可靠的锚点是区块标题「场景投放策略明细」：触发器就在这个标题附近的容器里，
  // 而弹出层通常挂在 body 末尾、不在这个容器内。
  const SCENE_SECTION_TITLE = /场景投放策略明细/;

  // 找标题所在的区块容器，用来把搜索范围限定在这一块里。
  function sceneSectionHeading() {
    return queryElements(document, "div,span,h1,h2,h3,h4,p,label")
      .filter(isVisible)
      .filter(element => {
        if (element.closest?.("#dmp-cdp-monitor")) return false;
        const text = normalizeText(element.textContent);
        return text.length <= 20 && SCENE_SECTION_TITLE.test(text);
      })
      .sort((left, right) => normalizeText(left.textContent).length - normalizeText(right.textContent).length)[0];
  }

  function sceneSectionScope() {
    const heading = sceneSectionHeading();
    if (!heading) return null;
    // 往上找几层，直到容器里能同时看到标题和某个渠道名（即下拉触发器）。
    let node = heading.parentElement;
    for (let depth = 0; node && depth < 10; node = node.parentElement, depth += 1) {
      const text = normalizeText(node.textContent);
      if (SCENE_CHANNELS.some(channel => text.includes(normalizeText(channel)))) return node;
    }
    return heading.parentElement || null;
  }

  function sceneChannelTrigger() {
    const scope = sceneSectionScope();
    const heading = sceneSectionHeading();
    // 优先在区块容器内找；找不到容器再退回全页扫描（保持旧行为兜底）。
    const pools = scope ? [scope, document] : [document];
    for (const pool of pools) {
      const matched = queryElements(pool, "div,span,button,[role='combobox'],[aria-haspopup='listbox'],[aria-expanded],[class*='select'],[class*='trigger']")
        .filter(isVisible)
        .filter(element => {
          if (element.closest?.("#dmp-cdp-monitor")) return false;
          // 只排除明确是弹出层的容器（role/aria 是可靠信号，混淆类名不是）。
          if (element.closest?.("[role='listbox'],[role='menu'],[aria-hidden='true']")) return false;
          // 在区块容器内搜索时，容器外的元素（弹出层挂在 body 末尾）自然被排除。
          if (pool !== document && !pool.contains(element)) return false;
          const text = normalizeText(element.textContent);
          return text.length <= 20 && SCENE_CHANNELS.some(name => text === normalizeText(name));
        });
      const found = matched
        .map(element => {
          const rect = element.getBoundingClientRect();
          const headingRect = heading?.getBoundingClientRect?.();
          const semantic = element.matches?.("[role='combobox'],[aria-haspopup='listbox'],[aria-expanded]") ? 1 : 0;
          const inScope = Boolean(scope && scope.contains(element));
          const distance = headingRect
            ? Math.abs(rect.top - headingRect.bottom) + Math.abs(rect.left - headingRect.left) * 0.25
            : 0;
          return { element, semantic, inScope, distance, area: rect.width * rect.height };
        })
        // 区块内、带下拉语义、离标题最近的候选优先；这样全页兜底也不会误拿表格中的渠道名。
        .sort((left, right) => Number(right.inScope) - Number(left.inScope) || right.semantic - left.semantic || left.distance - right.distance || left.area - right.area)[0]?.element;
      if (found) return found;
    }
    return null;
  }

  // 在已展开的下拉里找指定渠道的选项。必须排除触发器自己
  // （它的文案就是当前选中的渠道，会和选项重名）。
  function sceneChannelOption(channel, trigger) {
    const wanted = normalizeText(channel);
    const matched = queryElements(document, "li,[role='option'],div,span")
      .filter(isVisible)
      .filter(element => {
        if (element.closest?.("#dmp-cdp-monitor")) return false;
        if (trigger && (element === trigger || trigger.contains(element) || element.contains(trigger))) return false;
        return normalizeText(element.textContent) === wanted;
      });
    // 优先取明确是选项的（role/li 是可靠信号），其次取最内层的文本节点。
    // 不用混淆类名判断"在不在弹出层里"——达摩盘的类名靠不住。
    const asOption = matched.filter(element =>
      element.matches?.("li,[role='option']") || element.closest?.("li,[role='option'],[role='listbox'],[role='menu'],ul"));
    const pool = asOption.length ? asOption : matched;
    return pool.sort((left, right) => (left.textContent || "").length - (right.textContent || "").length)[0] || null;
  }

  // 下拉是不是展开着（选项已渲染）。用来判断该点触发器还是该收下拉。
  function sceneDropdownIsOpen(trigger) {
    return SCENE_CHANNELS.some(channel => sceneChannelOption(channel, trigger));
  }

  async function closeSceneDropdown(trigger) {
    if (!sceneDropdownIsOpen(trigger)) return;
    document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true }));
    await wait(260);
    // Esc 收不掉就再点一次触发器（真实点击），否则展开的下拉会盖住下一轮的触发器。
    if (sceneDropdownIsOpen(trigger) && trigger) {
      await trustedClick(trigger, "场景下拉收起");
      await wait(260);
    }
  }

  // 逐个渠道：展开下拉 → 选中 → 确认选中生效 → 等数据加载 → 确认拿到数据。
  // 每一步都要核对，不能"点了就算"：
  //   合成事件 isTrusted=false，Magix 的选项监听不响应——实测表现就是
  //   下拉展开后一直挂着、选项点不动、7 个渠道只拿到默认的「关键词推广」。
  async function switchSceneChannel(trigger, channel, label) {
    if (!trigger) return false;
    if (!sceneDropdownIsOpen(trigger)) {
      await scrollTriggerToTop(trigger);
      await trustedClick(trigger, `${label}:展开`);
    }
    let option = null;
    for (let poll = 0; poll < 5 && !option; poll += 1) {
      await wait(240);
      option = sceneChannelOption(channel, trigger);
    }
    if (!option) {
      await closeSceneDropdown(trigger);
      return false;
    }
    await trustedClick(option, `${label}:${channel}`);
    await wait(420);
    const current = sceneChannelTrigger() || trigger;
    const selected = normalizeText(current.textContent) === normalizeText(channel);
    if (!selected) await closeSceneDropdown(current);
    return selected;
  }

  async function sweepSceneChannels(channels = SCENE_CHANNELS, { force = false } = {}) {
    const requestedChannels = [...new Set((channels || []).filter(channel => SCENE_CHANNELS.includes(channel)))];
    const swept = [];
    const missed = [];
    for (let channelIndex = 0; channelIndex < requestedChannels.length; channelIndex += 1) {
      const channel = requestedChannels[channelIndex];
      let trigger = sceneChannelTrigger();
      if (!trigger) {
        tabDiag("场景明细：未找到渠道下拉触发器", { 停在: channel });
        // 触发器都不存在时，当前项及后续项都没有采集，不能再像 0.9.10 一样显示“未采集：无”。
        missed.push(...requestedChannels.slice(channelIndex).filter(name => !missed.includes(name)));
        break;
      }
      // 已经是当前选中项：默认渠道（通常是「关键词推广」）的数据随页签一起加载过了。
      if (normalizeText(trigger.textContent) === normalizeText(channel)) {
        if (!force) {
          tabDiag("场景明细：已是当前渠道，沿用已加载数据", { channel });
          swept.push(channel);
          continue;
        }
        // 精准补抓不能沿用上一次缓存：先切到别的渠道，再切回目标渠道，强制页面重新发请求。
        const fallback = SCENE_CHANNELS.find(name => name !== channel);
        const moved = fallback ? await switchSceneChannel(trigger, fallback, `场景补抓预切换:${channel}`) : false;
        trigger = sceneChannelTrigger() || trigger;
        await closeSceneDropdown(trigger);
        if (!moved) {
          tabDiag("场景明细：无法离开当前渠道，不能强制补抓", { channel });
          missed.push(channel);
          continue;
        }
      }

      let selected = false;
      // 整个"展开→选中→核对"最多重试 3 轮：达摩盘下拉偶发一次点不开。
      for (let attempt = 0; attempt < 3 && !selected; attempt += 1) {
        // 1. 展开下拉，等选项渲染出来。
        //    展开前先把触发器顶到视口上部：下拉浮层锚在触发器下方，7 个渠道
        //    展开后有几百像素高，触发器靠下时后面几个选项会落到视口以下，
        //    CDP 按坐标点不到（实测「内容营销」这类末尾选项永远点不中）。
        if (!sceneDropdownIsOpen(trigger)) {
          await scrollTriggerToTop(trigger);
          await trustedClick(trigger, `场景下拉触发器:${channel}#${attempt + 1}`);
        }
        let option = null;
        for (let poll = 0; poll < 5 && !option; poll += 1) {
          await wait(240);
          option = sceneChannelOption(channel, trigger);
        }
        if (!option) {
          tabDiag("场景明细：下拉未展开或找不到该渠道选项", { channel, 第几轮: attempt + 1, 下拉已展开: sceneDropdownIsOpen(trigger) });
          await closeSceneDropdown(trigger);
          continue;
        }

        // 2. 选中渠道。必须真实点击，合成事件点不动。
        const since = new Date().toISOString();
        await trustedClick(option, `场景渠道选项:${channel}`);
        await wait(420);

        // 3. 核对选中是否真的生效——触发器文案应该已经变成这个渠道。
        trigger = sceneChannelTrigger() || trigger;
        selected = normalizeText(trigger.textContent) === normalizeText(channel);
        if (!selected) {
          tabDiag("场景明细：点了选项但触发器没变成该渠道", { channel, 第几轮: attempt + 1, 当前触发器: normalizeText(trigger.textContent).slice(0, 20) });
          await closeSceneDropdown(trigger);
          continue;
        }
        // 4. 选中生效后才等数据：等请求发出、等响应体取回、等记录读回。
        const settled = await settleAfterAction({ label: `场景渠道:${channel}`, since, minimumMs: 800, quietMaximumMs: 9000, readbackMs: 6000 });
        // 5. 确认这一轮真的拿到了数据。
        if (settled.usable > 0 || countBusinessRecords(since) > 0) {
          tabDiag("场景明细：渠道数据已到", { channel, 业务请求数: countBusinessRecords(since), 可用响应数: settled.usable });
          swept.push(channel);
        } else {
          // 选中生效但没取数：可能命中了页面缓存，不算失败，但要记下来。
          tabDiag("场景明细：渠道已选中但未观察到新请求（可能命中页面缓存）", { channel });
          swept.push(channel);
        }
      }
      if (!selected) missed.push(channel);
      await closeSceneDropdown(sceneChannelTrigger() || trigger);
    }
    tabDiag("场景明细渠道遍历完成", { 已采集: swept.join("、") || "无", 未采集: missed.join("、") || "无" });
    if (currentJob) currentJob.sceneMissed = missed;
    return swept;
  }

  async function runComparisonTabs(range, labels = workflow.COMPARISON_TABS, options = {}) {
    const results = [];
    const failures = [];
    const requestedTabs = [...new Set((labels || []).filter(label => workflow.COMPARISON_TABS.includes(label)))];
    for (let index = 0; index < requestedTabs.length; index += 1) {
      const label = requestedTabs[index];
      setStep(`采集近30天：${label}`, 48 + Math.round(((index + 1) / requestedTabs.length) * 28));
      // 单个页签失败不能中断整轮采集：之前「关键指标对比」一失败，
      // 后面的「推广策略对比」「人群对比」就完全没机会跑，投放场景必然缺失。
      try {
        const clicked = await clickTabAndAwaitData(label);
        if (!clicked.opened) throw new Error(clicked.reason || "页签未切换");
        // 日期控件是全局的；confirmThirtyDays 会识别已选中的「过去 30 天」，后续页签直接沿用。
        const periodResult = await confirmThirtyDays(range, clicked.since);
        // 「推广策略对比」还要把场景明细的各个渠道都翻一遍，否则 scene 数据不全。
        let sceneChannels = [];
        if (label === "推广策略对比") {
          setStep(`采集近30天：${label} · 场景明细`, 48 + Math.round(((index + 1) / requestedTabs.length) * 28));
          const targetChannels = options.sceneChannels?.length ? options.sceneChannels : SCENE_CHANNELS;
          sceneChannels = await sweepSceneChannels(targetChannels, { force: Boolean(options.forceScene) });
        }
        if (!periodResult.confirmed) {
          // 日期没落实是硬问题：页面很可能还停在默认的成长阶段区间（实测 5 天），
          // 那份数据不是 30 天。要在面板上说出来，不能只写进诊断日志。
          tabDiag("页签周期未确认：页面区间可能不是 30 天", { label, 页面区间: periodResult.shown });
          setStep(`${label}：日期未能落实为 30 天（页面显示 ${periodResult.shown || "未知区间"}）`, 48 + Math.round(((index + 1) / requestedTabs.length) * 28), "运行中", "warn");
        }
        // 页签数据在离开之前必须已经落地——下一次点击会覆盖页面状态。
        const settled = await settleAfterAction({ label: `页签收尾:${label}`, since: clicked.since, activityMs: 2000, minimumMs: 600, readbackMs: 6000 });
        results.push({
          label, opened: true, method: clicked.method,
          periodConfirmed: periodResult.confirmed, periodPrecision: periodResult.precision, periodShown: periodResult.shown,
          sceneChannels, usableResponses: settled.usable, startDate: range.startDate, endDate: range.endDate
        });
      } catch (error) {
        const reason = String(error?.message || error);
        tabDiag("页签采集失败，继续下一个", { label, reason });
        failures.push(`${label}（${reason}）`);
      }
    }
    if (!results.length) {
      currentJob.tabFailures = failures;
      throw new Error(`目标对比页签都没能采集：${failures.join("；")}`);
    }
    if (failures.length) currentJob.tabFailures = failures;
    return results;
  }

  function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  async function waitForNetworkQuiet({ minimumMs = 1300, quietMs = 1200, maximumMs = 9000 } = {}) {
    const started = Date.now();
    while (Date.now() - started < maximumMs) {
      await wait(350);
      const elapsed = Date.now() - started;
      if (elapsed >= minimumMs && Date.now() - lastRecordAt >= quietMs) return;
    }
  }

  // 一条业务记录要"可用"必须同时满足：是达摩盘业务接口、响应体已被 CDP 取回、没被截断。
  // 只数请求条数不够——responseReceived 先到，响应体是 loadingFinished 之后才 getResponseBody
  // 取回来的，中间有真实的时间差。差这一步就会拿着空 body 去解析。
  function usableBusinessRecords(since) {
    return records.filter(record => {
      if (since && record.capturedAt && record.capturedAt < since) return false;
      if (!isBusinessRecord(record)) return false;
      return record.bodyAvailable !== false && typeof record.body === "string" && record.body.trim().length > 0;
    }).length;
  }

  // 每次点击之后要等三段时间，缺一段就会取到空数据：
  //   ① 页面自己发请求——达摩盘前端有 debounce/动画，点完不是立刻发；
  //   ② 请求跑完 + 响应体被 CDP 取回并写进 IndexedDB；
  //   ③ 插件把记录读回内存（refreshTaskRecords），read-back 也要时间。
  // 三段都用"实际观测"收敛，而不是固定 sleep：先等到有请求发出，再等网络安静，
  // 最后反复读回直到可用记录数连续两轮不再增长。
  async function settleAfterAction({
    label = "操作",
    since,
    activityMs = 6000,
    minimumMs = 900,
    quietMs = 1100,
    quietMaximumMs = 9000,
    readbackMs = 6000,
    stableRounds = 2
  } = {}) {
    const started = Date.now();

    // ① 等页面真的发出业务请求。没等到不算失败：页面可能命中前端缓存。
    let requested = countBusinessRecords(since);
    while (requested === 0 && Date.now() - started < activityMs) {
      await wait(400);
      await refreshTaskRecords().catch(() => {});
      requested = countBusinessRecords(since);
    }
    const waitedForRequest = Date.now() - started;

    // ② 等网络安静，让这一批请求跑完。
    await waitForNetworkQuiet({ minimumMs, quietMs, maximumMs: quietMaximumMs });

    // ③ 反复读回，直到"响应体已可用"的记录数稳定下来。
    const readbackStarted = Date.now();
    let usable = -1;
    let stable = 0;
    while (Date.now() - readbackStarted < readbackMs) {
      await refreshTaskRecords().catch(() => {});
      const current = usableBusinessRecords(since);
      if (current === usable) {
        stable += 1;
        if (stable >= stableRounds) break;
      } else {
        stable = 0;
        usable = current;
      }
      await wait(450);
    }
    if (usable < 0) usable = usableBusinessRecords(since);

    const settled = {
      label,
      请求数: countBusinessRecords(since),
      可用响应数: usable,
      等请求ms: waitedForRequest,
      总耗时ms: Date.now() - started
    };
    tabDiag("等待数据落地完成", settled);
    if (currentJob) {
      currentJob.settleLog = currentJob.settleLog || [];
      currentJob.settleLog.push(settled);
    }
    return { requested: settled.请求数, usable, elapsedMs: settled.总耗时ms };
  }

  async function refreshTaskRecords() {
    if (!currentJob?.startedAt) return;
    const result = await runtimeMessage("DMP_CDP_GET_RECORDS", { since: currentJob.startedAt });
    if (!result?.ok) throw new Error(result?.error || "读取任务数据失败");
    mergeRecords(result.records || []);
  }

  function routeItemId() {
    const query = String(location.hash || "").split("?")[1] || "";
    const value = new URLSearchParams(query).get("itemId") || "";
    return /^\d{6,20}$/.test(value) ? value : "";
  }

  function parseRecordJson(record) {
    if (typeof record?.body !== "string" || !record.body.trim()) return null;
    try { return JSON.parse(record.body); } catch { return null; }
  }

  function eligibleSubjectIdFromData(data, excludedId) {
    let found = "";
    const walk = (value, depth = 0) => {
      if (found || !value || depth > 12) return;
      if (Array.isArray(value)) return value.forEach(child => walk(child, depth + 1));
      if (typeof value !== "object") return;
      const id = String(value.id ?? value.itemId ?? "");
      const looksLikeItem = id && ["name", "itemTitle", "gmv30d", "reservePrice", "onlineDays", "lifeCycleDesc"].some(key => value[key] !== undefined);
      if (/^\d{6,20}$/.test(id) && id !== excludedId && looksLikeItem) {
        found = id;
        return;
      }
      Object.values(value).forEach(child => walk(child, depth + 1));
    };
    walk(data);
    return found;
  }

  function detectSubjectItemId(excludedId = "") {
    const routed = routeItemId();
    if (routed && routed !== excludedId) return routed;
    for (let index = records.length - 1; index >= 0; index -= 1) {
      const record = records[index];
      const path = record?.pathname || record?.url || "";
      if (!path.includes("/api/goods/item/info")) continue;
      const detected = eligibleSubjectIdFromData(parseRecordJson(record), excludedId);
      if (detected) return detected;
    }
    return "";
  }

  // 达摩盘前端路由只认 hash 里的路径部分（#!/items/growup-path）和 itemId。
  // 页面本来就停在同一个商品的打爆路径时，即便我们给 hash 加上唯一的 dmpReportTask
  // nonce，路由也会判定"无需重新加载"，一条业务请求都不发（表现为五个模块全缺）。
  // 所以先切到一个中性路由，等路由真正卸载，再切回目标路由强制重新挂载。
  const NEUTRAL_ROUTE_HASH = "#!/items/shop-insight";

  async function routeToItem(itemId) {
    const nextHash = workflow.buildGrowupRouteHash(itemId, Date.now());
    const currentPath = String(location.hash || "").split("?")[0];
    const nextPath = nextHash.split("?")[0];
    const sameItem = routeItemId() === String(itemId);

    if (currentPath === nextPath && sameItem) {
      location.hash = NEUTRAL_ROUTE_HASH;
      // 等达摩盘把当前路由卸载掉，否则紧接着切回去仍会被当成"没变化"。
      await wait(900);
    }
    location.hash = nextHash;
  }

  function mergeTabResults(nextResults, replace = false) {
    const merged = new Map((replace ? [] : (currentJob.tabResults || [])).map(result => [result.label, result]));
    for (const result of nextResults || []) merged.set(result.label, result);
    currentJob.tabResults = workflow.COMPARISON_TABS.map(label => merged.get(label)).filter(Boolean);
    currentJob.visitedPaths = currentJob.tabResults.map(result => result.label);
    const successfulLabels = new Set((nextResults || []).map(result => result.label));
    currentJob.tabFailures = (currentJob.tabFailures || []).filter(failure => ![...successfulLabels].some(label => String(failure).startsWith(label)));
    currentJob.periodConfirmed = currentJob.tabResults.length === workflow.COMPARISON_TABS.length && currentJob.tabResults.every(result => result.periodConfirmed);
    currentJob.periodPrecision = !currentJob.periodConfirmed || currentJob.tabResults.some(result => result.periodPrecision === "failed")
      ? "failed"
      : currentJob.tabResults.every(result => result.periodPrecision === "exact") ? "exact" : "preset";
    currentJob.periodShown = currentJob.tabResults.map(result => result.periodShown).find(Boolean) || currentJob.periodShown || "";
  }

  function reportRequiresRecapture(report) {
    return Boolean(report && report.quality?.complete !== true);
  }

  function buildCurrentReport() {
    const subjectItemId = currentJob.subjectItemId || currentJob.itemId;
    currentJob.report = engine.buildReport(records, subjectItemId, currentJob);
    currentJob.reportBuildVersion = EXTENSION_VERSION;
    return currentJob.report;
  }

  async function finalizeCurrentReport() {
    const subjectItemId = currentJob.subjectItemId || currentJob.itemId;
    const successItemId = currentJob.successItemId;
    setStep("汇总经营数据并生成业务表格", 78);
    await settleAfterAction({ label: "生成前最终确认", since: currentJob.startedAt, activityMs: 1500, minimumMs: 600, readbackMs: 8000, stableRounds: 3 });
    currentJob.finishedAt = new Date().toISOString();
    setStep("匹配周期总GMV并计算日GMV", 82);
    buildCurrentReport();

    if (reportRequiresRecapture(currentJob.report)) {
      const gateReasons = [
        ...(currentJob.report.quality.blockingIssues || []),
        ...(currentJob.report.quality.deterministicMissing || []).map(label => `${label}未填`),
        ...(currentJob.report.quality.warnings || [])
      ];
      currentJob.analysis = { attempted: false, skipped: true, error: "v2.0 完整性门禁未通过" };
      currentJob.ai = { ok: false, skipped: true, error: "数据尚未完整，未进行云端校验", checkedAt: new Date().toISOString() };
      currentJob.status = "blocked";
      currentJob.recaptureDecision = workflow.assessRecaptureNeed(currentJob.report, currentJob);
      currentJob.recapturePlan = currentJob.recaptureDecision.plan || workflow.buildRecapturePlan(currentJob.report, currentJob);
      const coverage = currentJob.recaptureDecision.snapshot;
      const perceptionText = currentJob.recaptureDecision.autoRecapture
        ? `系统判定仍需补齐：${currentJob.recaptureDecision.reason}`
        : `数据尚未完整：${currentJob.recaptureDecision.reason}`;
      setStep(`${perceptionText}（关键指标 ${coverage.resolvedValues}/${coverage.requiredValues}）`, 100, "待补充", "bad");
      renderReport(currentJob.report);
      await persistJob();
      setStatus(currentJob.recaptureDecision.autoRecapture
        ? `数据尚未完整，将自动继续补齐：${currentJob.recapturePlan.summary}`
        : `数据尚未完整，可再次点击“补齐缺失数据”：${currentJob.recapturePlan.summary || gateReasons.slice(0, 2).join("；")}`, "#ff9d9d");
      return false;
    }

    currentJob.recapturePlan = null;
    currentJob.recaptureDecision = workflow.assessRecaptureNeed(currentJob.report, currentJob);
    ui.recaptureWrap.hidden = true;

    const analysisPayload = engine.buildAnalysisPayload(records, subjectItemId, currentJob);
    currentJob.analysis = { attempted: true, modules: analysisPayload.modules.length };
    try {
      setStep("向云端提交待补全数据", 86);
      const analyzeResult = await runtimeMessage("DMP_CDP_AI_ANALYZE", {
        payload: analysisPayload,
        report: engine.toCanonicalReport(currentJob.report)
      });
      if (analyzeResult?.ok && !analyzeResult.skipped) {
        const merged = engine.applyAnalysis(currentJob.report, analyzeResult.analysis);
        currentJob.report = merged.report;
        currentJob.analysis = {
          attempted: true, ok: true, modules: analysisPayload.modules.length,
          blanksAsked: analyzeResult.blanks_asked || 0,
          applied: merged.applied, rejected: merged.rejected,
          unresolved: analyzeResult.analysis?.unresolved || [],
          droppedOutOfScope: analyzeResult.dropped_out_of_scope || 0,
          model: analyzeResult.model || ""
        };
        setStep(`智能补全已填写 ${merged.applied.length} 项（${merged.rejected.length} 项未采用）`, 89);
      } else if (analyzeResult?.skipped) {
        currentJob.analysis = { attempted: true, ok: true, skipped: true, modules: analysisPayload.modules.length, applied: [], rejected: [], valuesReceived: analyzeResult.values_received || 0, error: analyzeResult.reason || "云端校验完成" };
        setStep("云端已完成数据校验", 89);
      } else {
        currentJob.analysis = {
          attempted: true, ok: false, modules: analysisPayload.modules.length,
          code: analyzeResult?.code || "API_FAILED",
          error: analyzeResult?.error || "深度解析不可用",
          detail: analyzeResult?.detail || {}
        };
        setStep(`${analysisErrorLabel(currentJob.analysis.code)}，将保留已完成的数据`, 89, "运行中", "warn");
      }
    } catch (error) {
      currentJob.analysis = { attempted: true, ok: false, code: "API_FAILED", modules: analysisPayload.modules.length, error: String(error?.message || error) };
      setStep("云端处理未完成，将保留已完成的数据", 89, "运行中", "warn");
    }

    const canonical = engine.toCanonicalReport(currentJob.report);
    const localValidation = engine.validateCanonicalReport(canonical);
    if (!localValidation.ok) throw new Error(localValidation.error || "本地报告结构校验失败");

    setStep("通过少壮AI云端校验报告", 93);
    const aiResult = await runtimeMessage("DMP_CDP_AI_GENERATE", { report: canonical });
    currentJob.ai = {
      ok: Boolean(aiResult?.ok),
      skipped: Boolean(aiResult?.skipped),
      model: aiResult?.model || "",
      responseId: aiResult?.response_id || "",
      error: aiResult?.ok ? "" : (aiResult?.error || "云端校验暂不可用"),
      checkedAt: new Date().toISOString()
    };
    ui.aiState.textContent = currentJob.ai.ok ? `云端已校验 · ${currentJob.ai.model}` : "云端校验暂不可用";
    ui.aiState.className = `pill ${currentJob.ai.ok ? "" : "warn"}`.trim();
    currentJob.status = "completed";
    setStep("报告生成完成", 100, "已完成");
    renderReport(currentJob.report);
    const archived = await archiveReportToOfficialCenter({ openReport: true });
    await persistJob();
    setStatus(archived
      ? currentJob.reportCenter?.opened
        ? `主体 ${subjectItemId} vs 成功品 ${successItemId} 已完成，官网 HTML 报告已在新窗口打开`
        : `报告已保存到官网；自动打开失败，可点击“打开官网 HTML 报告”重试`
      : `主体 ${subjectItemId} vs 成功品 ${successItemId} 已完成，但官网报告保存失败，请稍后重试`, archived ? "#76e287" : "#ff9d9d");
    return true;
  }

  async function runPreciseRecapture(automatic = false) {
    if (internalExportDownloadPending) return;
    if (!currentJob?.report || currentJob.status !== "blocked") return;
    if (!await refreshSiteStatus()) return;
    const plan = workflow.buildRecapturePlan(currentJob.report, currentJob);
    const beforeSnapshot = workflow.qualityGapSnapshot(currentJob.report);
    const attempt = {
      startedAt: new Date().toISOString(),
      plan,
      automatic,
      beforeMissing: [...(currentJob.report.quality?.missing || [])],
      beforeSignature: beforeSnapshot.signature,
      beforeGapCount: beforeSnapshot.gapCount,
      beforeResolvedValues: beforeSnapshot.resolvedValues,
      beforeRecordCount: records.length
    };
    currentJob.recaptureAttempts = currentJob.recaptureAttempts || [];
    currentJob.recaptureAttempts.push(attempt);
    currentJob.recapturePlan = plan;
    currentJob.status = "running";
    ui.run.disabled = true;
    ui.recapture.disabled = true;
    hideInternalExport();
    ui.onlineReport.disabled = true;
    ui.shareReport.disabled = true;

    try {
      setStatus(`正在补齐：${plan.summary}`, "#ffd66b");
      setStep(`准备补齐：${plan.summary}`, 5, "补充中", "warn");
      const connected = await runtimeMessage("DMP_CDP_ENSURE_ATTACHED");
      if (!connected?.ok) throw new Error(connected?.error || "数据通道连接失败");
      await wait(500);

      if (!plan.requests?.length && !plan.reselectSuccess) throw new Error("暂无可自动补充的数据");
      if (plan.requests?.length) {
        setStep(`正在整理 ${plan.requests.length} 类缺失数据`, 10, "补充中", "warn");
        attempt.clearedFailedRecords = await clearFailedRequestRecords(plan.requests, plan.clearPaths);
        attempt.jsonReplay = await replayMissingJsonRequests(plan.requests);
      }

      const failedRequests = attempt.jsonReplay?.failed || [];
      const broadenFallback = Number(currentJob.recaptureDecision?.stagnantRounds || 0) > 0;
      if (failedRequests.some(request => request.path === "/api/goods/item/info" || request.path === "/api/goods/grow/define/line/data")
        || (broadenFallback && plan.reloadRoute)) {
        setStep("主体概况与趋势尚未完整，正在打开页面补充", 62, "补充中", "warn");
        const since = new Date().toISOString();
        await routeToItem(currentJob.subjectItemId || currentJob.itemId);
        const settled = await settleAfterAction({ label: "精准补抓:主体概况与趋势", since, activityMs: 9000, minimumMs: 2200, quietMs: 1400, quietMaximumMs: 16000, readbackMs: 9000 });
        if (!settled.requested) throw new Error("主体概况与趋势未能更新，请刷新页面后重试");
      }

      if (plan.reselectSuccess || failedRequests.some(request => request.path === "/api/goods/grow/define/success/load")) {
        setStep("需要重新确认目标成功品", 68, "补充中", "warn");
        const successProduct = await ensureSuccessProductAdded(currentJob.successItemId);
        currentJob.successProduct = successProduct;
        if (!successProduct?.confirmed) {
          const failure = new Error(successProduct?.method || "目标成功品补抓未确认");
          failure.code = successProduct?.code || "SUCCESS_PRODUCT_NOT_CONFIRMED";
          throw failure;
        }
      }

      const fallbackTabs = [...new Set([...failedRequests.map(request => request.path === "/dataplatform/dataset/report/query"
        ? "关键指标对比"
        : request.path.startsWith("/api/goods/grow/comparison/scene") ? "推广策略对比" : "").filter(Boolean),
      ...(broadenFallback ? plan.tabs : [])])];
      if (fallbackTabs.length) {
        setStep("正在打开对应数据页继续补充", 72, "补充中", "warn");
        const nextResults = await runComparisonTabs(currentJob.period, fallbackTabs, {
          sceneChannels: plan.sceneChannels,
          forceScene: true
        });
        mergeTabResults(nextResults);
      }

      // 跨页兜底和成功品重选会继续产生网络记录。最终计算前再回读一次，
      // 并清掉本轮已被替代的失败尝试，防止旧状态在下一轮重新占住门禁。
      await refreshTaskRecords().catch(() => {});
      attempt.clearedAfterActions = await clearFailedRequestRecords(plan.requests || [], plan.clearPaths || []);
      attempt.actionsFinishedAt = new Date().toISOString();
      const reportReady = await finalizeCurrentReport();
      attempt.finishedAt = new Date().toISOString();
      attempt.reportReady = reportReady;
      attempt.complete = currentJob.report?.quality?.complete === true;
      attempt.afterMissing = [...(currentJob.report?.quality?.missing || [])];
      const afterSnapshot = workflow.qualityGapSnapshot(currentJob.report);
      attempt.afterSignature = afterSnapshot.signature;
      attempt.afterGapCount = afterSnapshot.gapCount;
      attempt.afterResolvedValues = afterSnapshot.resolvedValues;
      attempt.afterRecordCount = records.length;
      attempt.stagnantRounds = Number(currentJob.recaptureDecision?.stagnantRounds || 0);
      await persistJob();
      if (!reportReady && currentJob.recaptureDecision?.autoRecapture) {
        currentJob.status = "blocked";
        setStep(`系统确认仍有可补充项，开始第 ${currentJob.recaptureAttempts.length + 1} 次补充`, 100, "继续补充", "warn");
        setStatus(`${currentJob.recaptureDecision.reason}：${currentJob.recapturePlan?.summary || "继续补齐数据"}`, "#ffd66b");
        await wait(700);
        return await runPreciseRecapture(true);
      }
    } catch (error) {
      attempt.finishedAt = new Date().toISOString();
      attempt.error = String(error?.message || error);
      await refreshTaskRecords().catch(() => {});
      currentJob.finishedAt = new Date().toISOString();
      buildCurrentReport();
      const afterSnapshot = workflow.qualityGapSnapshot(currentJob.report);
      attempt.afterSignature = afterSnapshot.signature;
      attempt.afterGapCount = afterSnapshot.gapCount;
      attempt.afterResolvedValues = afterSnapshot.resolvedValues;
      attempt.afterRecordCount = records.length;
      currentJob.status = "blocked";
      currentJob.recaptureDecision = workflow.assessRecaptureNeed(currentJob.report, currentJob);
      attempt.stagnantRounds = Number(currentJob.recaptureDecision.stagnantRounds || 0);
      currentJob.recapturePlan = currentJob.recaptureDecision.plan || workflow.buildRecapturePlan(currentJob.report, currentJob);
      const successBlocked = isSuccessProductBlockingCode(error?.code);
      const publicMessage = publicErrorMessage(error, "数据补充未完成，暂不能生成在线报告");
      setStep(publicMessage, 100, successBlocked ? "已阻断" : "待补充", "bad");
      renderReport(currentJob.report);
      setStatus(successBlocked ? publicMessage : `数据补充未完成，暂不能生成在线报告：${currentJob.recaptureDecision.reason}`, "#ff9d9d");
      await persistJob().catch(() => {});
    } finally {
      ui.run.disabled = !siteAuthorized;
      ui.recapture.disabled = !siteAuthorized || currentJob?.status !== "blocked";
    }
  }

  async function runReport() {
    if (internalExportDownloadPending) return;
    if (!await refreshSiteStatus()) return;
    const successItemId = ui.successItemId.value.trim();
    if (!/^\d{6,20}$/.test(successItemId)) {
      setStatus("请输入 6–20 位成功品/竞品商品 ID", "#ff9d9d");
      ui.successItemId.focus();
      return;
    }
    const subjectItemId = ui.subjectItemId.value.trim() || detectSubjectItemId(successItemId);
    if (!/^\d{6,20}$/.test(subjectItemId)) {
      setStatus("请填写本店有权访问且近30天有销量的主体商品 ID", "#ff9d9d");
      ui.subjectItemId.focus();
      return;
    }
    if (subjectItemId === successItemId) {
      setStatus("主体商品与成功品/竞品不能是同一个商品", "#ff9d9d");
      ui.successItemId.focus();
      return;
    }
    ui.subjectItemId.value = subjectItemId;
    if (!location.hostname.endsWith("dmp.taobao.com")) {
      setStatus("请在达摩盘页面运行", "#ff9d9d");
      return;
    }

    ui.run.disabled = true;
    hideInternalExport();
    ui.onlineReport.disabled = true;
    ui.shareReport.disabled = true;
    ui.recaptureWrap.hidden = true;
    ui.recapture.disabled = true;
    try {
      setStatus("正在准备本次任务…", "#ffd66b");
      await clearRecordHistory();
      lastRecordAt = 0;
    } catch (error) {
      setStatus(publicErrorMessage(error, "任务准备失败，请刷新页面后重试"), "#ff9d9d");
      ui.run.disabled = !siteAuthorized;
      return;
    }
    setStatus("正在确认达摩盘最新可用数据日期…", "#ffd66b");
    const periodResolution = await resolveBusinessPeriod(30);
    const period = periodResolution.period;
    currentJob = {
      id: `${Date.now()}-${subjectItemId}-${successItemId}`,
      itemId: subjectItemId,
      subjectItemId,
      successItemId,
      startedAt: new Date().toISOString(),
      status: "running",
      progress: 3,
      periodConfirmed: false,
      period,
      platformLatestDay: periodResolution.latestDay,
      periodSource: periodResolution.source,
      visitedPaths: [],
      report: null
    };

    try {
      setStatus(`正在分析主体 ${subjectItemId} vs 成功品 ${successItemId}`, "#76e287");
      setStep("连接数据通道", 5);
      await persistJob();
      // 不能用 RECONNECT：它会先 detach，摧毁已生效的 Network.enable，
      // 而紧接着的 routeToItem 立刻就会发出 item/info 等业务请求，
      // 空窗期内这些请求会全部丢失（表现为五个模块全缺）。
      const connected = await runtimeMessage("DMP_CDP_ENSURE_ATTACHED");
      if (!connected?.ok) throw new Error(connected?.error || "数据通道连接失败");
      // 给 Network.enable 一点时间在 Chrome 侧真正生效，再触发路由。
      await wait(600);

      setStep("进入达摩盘“货品 → 打爆路径”页面", 15);
      const routeSince = new Date().toISOString();
      await routeToItem(subjectItemId);
      // 首屏要加载的接口最多，给足时间：等请求发出、等响应体取回、等记录读回。
      await settleAfterAction({ label: "路由首屏", since: routeSince, activityMs: 9000, minimumMs: 2200, quietMs: 1400, quietMaximumMs: 16000, readbackMs: 9000 });
      // 只统计达摩盘业务请求：页面的曝光/点击埋点一直在发，
      // 用记录总数判断会被埋点骗过（曾导致路由没真正重载却继续跑完并输出空报告）。
      if (countBusinessRecords(routeSince) === 0) {
        throw new Error("页面切换后没有取得业务数据，请刷新达摩盘页面后重试");
      }
      const accessError = subjectAccessError(subjectItemId);
      if (accessError) throw new Error(`主体商品 ${subjectItemId} 不可用于单品洞察：请确认是本店商品且近30天有销量`);

      setStep("清空默认成功品、应用筛选并添加目标", 27);
      try {
        currentJob.successProduct = await ensureSuccessProductAdded(successItemId);
      } catch (error) {
        currentJob.successProduct = { confirmed: false, method: String(error?.message || error), code: error?.code || "" };
      }
      if (!currentJob.successProduct.confirmed) {
        const failure = new Error(currentJob.successProduct.method || "目标成功品未能添加，请重新选择后再试");
        failure.code = currentJob.successProduct.code || "SUCCESS_PRODUCT_NOT_CONFIRMED";
        throw failure;
      }

      setStep("准备三个对比页签的近30天周期", 43);
      try {
        mergeTabResults(await runComparisonTabs(period), true);
      } catch (error) {
        currentJob.tabResults = [];
        currentJob.visitedPaths = [];
        currentJob.periodConfirmed = false;
        currentJob.periodPrecision = "failed";
        currentJob.tabError = String(error?.message || error);
        setStep("部分对比页签未完全确认，正在使用已采集数据生成", 60, "运行中", "warn");
      }

      await finalizeCurrentReport();
    } catch (error) {
      currentJob.status = "failed";
      currentJob.error = String(error?.message || error);
      const publicMessage = publicErrorMessage(error, "运行未完成，请刷新页面后重试");
      setStep(publicMessage, currentJob.progress || 0, isSuccessProductBlockingCode(error?.code) ? "已阻断" : "运行失败", "bad");
      setStatus(publicMessage, "#ff9d9d");
      await persistJob().catch(() => {});
    } finally {
      ui.run.disabled = !siteAuthorized;
    }
  }

  function renderSelectedTable(report, tableName) {
    ui.previewWrap.replaceChildren();
    const current = report.tables.find(candidate => candidate.name === tableName) || report.tables[0];
    if (!current || !current.rows.length) {
      const empty = document.createElement("div");
      empty.className = "empty";
      empty.textContent = `${current?.name || "该业务表"}暂无可披露数据`;
      ui.previewWrap.appendChild(empty);
      return;
    }
    const table = document.createElement("table");
    const thead = document.createElement("thead");
    const headRow = document.createElement("tr");
    current.columns.forEach(label => {
      const th = document.createElement("th");
      th.textContent = label;
      headRow.appendChild(th);
    });
    thead.appendChild(headRow);
    const tbody = document.createElement("tbody");
    current.rows.slice(0, 200).forEach(row => {
      const tr = document.createElement("tr");
      row.forEach((value, index) => {
        const td = document.createElement("td");
        const semantic = current.name === "对标总表" ? `${current.columns[index]} ${row[1]}` : current.name === "基础指标对比" ? `${current.columns[index]} ${row[0]}` : current.columns[index];
        td.textContent = engine.formatMetricValue(semantic, value);
        tr.appendChild(td);
      });
      tbody.appendChild(tr);
    });
    table.append(thead, tbody);
    ui.previewWrap.appendChild(table);
  }

  function renderReport(report) {
    if (report?.version !== 3 || !Array.isArray(report.tables)) {
      ui.recaptureWrap.hidden = true;
      ui.previewWrap.innerHTML = '<div class="empty">旧版报告结构已失效，请重新点击“一键运行”</div>';
      return;
    }
    const exportable = report.quality?.complete === true;
    ui.onlineReport.disabled = !exportable || currentJob?.reportCenter?.ok !== true;
    ui.shareReport.disabled = !exportable;
    if (internalExportButton) internalExportButton.disabled = internalExportDownloadPending || !reportIsExportable();
    const recaptureDecision = reportRequiresRecapture(report)
      ? (currentJob?.recaptureDecision || workflow.assessRecaptureNeed(report, currentJob || {}))
      : null;
    const recapturePlan = recaptureDecision?.plan || (reportRequiresRecapture(report) ? workflow.buildRecapturePlan(report, currentJob || {}) : null);
    ui.recaptureWrap.hidden = exportable;
    ui.recapture.disabled = exportable || !siteAuthorized || currentJob?.status === "running";
    ui.recaptureSummary.textContent = recapturePlan ? businessFacingText(`${recaptureDecision?.reason || "仍需补齐"}；需要补充：${recapturePlan.summary}`) : "";
    const rowCount = report.tables.reduce((sum, current) => sum + current.rows.length, 0);
    // 用业务化文案展示补全数量，内部错误细节不暴露到面板。
    const analysis = currentJob?.analysis;
    const analysisText = !analysis?.attempted ? ""
      : analysis.ok ? ` · 智能补全 ${analysis.applied?.length || 0} 项${analysis.rejected?.length ? `，${analysis.rejected.length} 项未采用` : ""}`
      : analysis.skipped ? " · 云端校验已跳过"
      : ` · ${analysisErrorLabel(analysis.code)}`;
    // 日期口径和场景渠道覆盖都要能一眼看到：这两处出问题时数据是"看着对但不对"。
    const precision = currentJob?.periodPrecision;
    const periodText = precision === "exact" ? "" : precision === "preset" ? " · 日期为页面预设口径" : precision ? " · 日期未落实30天" : "";
    const sceneMissed = currentJob?.sceneMissed?.length ? ` · 场景缺${currentJob.sceneMissed.length}渠道` : "";
    const resolvedValues = Number(report.quality?.resolvedValues || 0);
    const requiredValues = Number(report.quality?.requiredValues || 0);
    const gateText = exportable ? "" : ` · 完整度：${recaptureDecision?.reason || "关键数据尚未完整"}`;
    ui.quality.textContent = businessFacingText(`数据覆盖 ${report.quality.observed}/${report.quality.expected} · 关键指标 ${resolvedValues}/${requiredValues} · ${report.tables.length} 张表 · ${rowCount} 行${analysisText}${periodText}${sceneMissed}${gateText}`);
    const selected = ui.previewTable.value;
    ui.previewTable.replaceChildren();
    report.tables.forEach(current => {
      const option = document.createElement("option");
      option.value = current.name;
      option.textContent = `${current.name}（${current.rows.length}）`;
      ui.previewTable.appendChild(option);
    });
    ui.previewTable.disabled = false;
    ui.previewTable.value = report.tables.some(current => current.name === selected) ? selected : (report.tables.find(current => current.name === "对标总表")?.name || report.tables[0]?.name || "");
    renderSelectedTable(report, ui.previewTable.value);
  }

  function downloadBlob(content, filename, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.style.display = "none";
    document.documentElement.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }

  function reportFilename(extension, job = currentJob, report = job?.report) {
    const subject = job?.subjectItemId || job?.itemId || "未识别主体";
    const opponent = job?.successItemId || report?.item?.competitorId || "未识别对手";
    return engine.safeFilename(`达摩盘_商品成长竞品对标报告_${subject}_vs_${opponent}`) + extension;
  }

  ui.run.addEventListener("click", () => void runReport());
  document.addEventListener("keydown", event => {
    const internalShortcut = event.altKey && event.shiftKey && !event.ctrlKey && !event.metaKey && event.code === "KeyD";
    if (!internalShortcut || event.repeat) return;
    event.preventDefault();
    event.stopPropagation();
    void revealInternalExport();
  }, true);
  ui.status.addEventListener("click", event => {
    if (event.detail === 3) void revealInternalExport();
  });
  ui.modeSwitch.value = unifiedMode.current;
  ui.modeSwitch.addEventListener("change", async () => {
    const requested = ui.modeSwitch.value;
    if (currentJob?.status === "running") {
      ui.modeSwitch.value = unifiedMode.current;
      setStatus("当前取数正在运行，请完成或停止后再切换模式", "#ffb3b3");
      return;
    }
    ui.modeSwitch.disabled = true;
    setStatus("正在切换取数模式…", "#ffd66b");
    await unifiedMode.switchTo(requested);
  });
  ui.recapture.addEventListener("click", () => void runPreciseRecapture());
  ui.subjectItemId.addEventListener("keydown", event => { if (event.key === "Enter") ui.successItemId.focus(); });
  ui.successItemId.addEventListener("keydown", event => { if (event.key === "Enter") void runReport(); });
  ui.previewTable.addEventListener("change", () => {
    if (currentJob?.report) renderSelectedTable(currentJob.report, ui.previewTable.value);
  });
  ui.settings.addEventListener("click", async () => {
    ui.settings.disabled = true;
    try {
      const result = await runtimeMessage("DMP_CDP_OPEN_OPTIONS");
      if (!result?.ok) throw new Error(result?.error || "设置页打开失败");
      setStatus("设置页已打开", "#76e287");
    } catch (error) {
      setStatus(publicErrorMessage(error, "设置页打开失败，请重试"), "#ff9d9d");
    } finally {
      ui.settings.disabled = false;
    }
  });
  ui.onlineReport.addEventListener("click", async () => {
    const reportId = currentJob?.reportCenter?.reportId;
    if (!reportId) return;
    ui.onlineReport.disabled = true;
    const result = await runtimeMessage("DMP_CDP_OPEN_REPORT", { reportId });
    setStatus(result?.ok ? "官网 HTML 报告已在新窗口打开" : publicErrorMessage(result?.error, "官网报告打开失败，请重试"), result?.ok ? "#76e287" : "#ff9d9d");
    ui.onlineReport.disabled = false;
  });
  ui.shareReport.addEventListener("click", async () => {
    ui.shareReport.disabled = true;
    setStatus("正在生成官网公开只读链接…", "#ffd66b");
    try {
      await createOnlineShare();
      setStatus("官网公开只读链接已复制；任何拿到链接的人均可直接打开", "#76e287");
    } catch (error) {
      setStatus(publicErrorMessage(error, "官网分享链接生成失败，请稍后重试"), "#ff9d9d");
    } finally {
      ui.shareReport.disabled = currentJob?.report?.quality?.complete !== true;
    }
  });
  ui.openReportCenter.addEventListener("click", async () => {
    const result = await runtimeMessage("DMP_CDP_OPEN_REPORT_CENTER");
    setStatus(result?.ok ? "已打开官网报告中心" : publicErrorMessage(result?.error, "报告中心打开失败，请重试"), result?.ok ? "#76e287" : "#ff9d9d");
  });
  ui.collapse.addEventListener("click", () => {
    collapsed = !collapsed;
    ui.body.style.display = collapsed ? "none" : "block";
    ui.collapse.textContent = collapsed ? "+" : "—";
  });

  chrome.runtime.onMessage.addListener(message => {
    if (message.type === "DMP_CDP_STATUS") {
      if (!currentJob || currentJob.status !== "running") setStatus(message.active ? "数据通道已就绪" : publicErrorMessage(message.message, "数据通道暂不可用，请稍后重试"), message.active ? "#76e287" : "#ff9d9d");
      return;
    }
    if (message.type !== "DMP_CDP_RECORD" || !message.record) return;
    records.push(message.record);
    lastRecordAt = Date.now();
  });

  async function restore() {
    try {
      const [recordResult, jobResult] = await Promise.all([
        runtimeMessage("DMP_CDP_GET_RECORDS"),
        runtimeMessage("DMP_CDP_GET_JOB")
      ]);
      if (recordResult?.ok) mergeRecords(recordResult.records || []);
      if (jobResult?.ok && jobResult.job) {
        currentJob = jobResult.job;
        const legacyTarget = currentJob.successItemId || (currentJob.subjectItemId ? "" : currentJob.itemId) || "";
        ui.successItemId.value = legacyTarget;
        ui.subjectItemId.value = currentJob.subjectItemId || detectSubjectItemId(legacyTarget);
        if (currentJob.report && currentJob.reportBuildVersion !== EXTENSION_VERSION) {
          setStatus("正在用现有数据重新计算日GMV…", "#ffd66b");
          const periodResolution = capturedBusinessPeriod(30) || await resolveBusinessPeriod(30);
          currentJob.period = periodResolution.period;
          currentJob.platformLatestDay = periodResolution.latestDay;
          currentJob.periodSource = periodResolution.source;
          currentJob.recaptureAttempts = [];
          currentJob.recapturePlan = null;
          currentJob.finishedAt = new Date().toISOString();
          buildCurrentReport();
          currentJob.status = currentJob.report.quality?.complete ? "completed" : "blocked";
          currentJob.step = currentJob.report.quality?.complete ? "已用现有数据重新计算日GMV" : "现有数据仍有真实缺口";
          currentJob.progress = 100;
          if (reportRequiresRecapture(currentJob.report)) {
            currentJob.recaptureDecision = workflow.assessRecaptureNeed(currentJob.report, currentJob);
            currentJob.recapturePlan = currentJob.recaptureDecision.plan;
          }
          await persistJob();
        }
        if (currentJob.report) {
          if (reportRequiresRecapture(currentJob.report)) {
            currentJob.status = "blocked";
            currentJob.recaptureDecision = workflow.assessRecaptureNeed(currentJob.report, currentJob);
            currentJob.recapturePlan = currentJob.recaptureDecision.plan;
          }
          renderReport(currentJob.report);
          let restoredArchive = false;
          if (!reportRequiresRecapture(currentJob.report) && currentJob.reportCenter?.ok !== true) {
            restoredArchive = await archiveReportToOfficialCenter();
            await persistJob();
          }
          if (currentJob.ai) {
            ui.aiState.textContent = currentJob.ai.ok ? "云端已校验" : currentJob.ai.skipped ? "云端校验已跳过" : "已按本地规则生成";
            ui.aiState.className = `pill ${currentJob.ai.ok ? "" : "warn"}`.trim();
          }
          const blocked = currentJob.status === "blocked";
          setStep(currentJob.step || "已恢复上次报告", currentJob.progress || 100, blocked ? "待补充" : currentJob.status === "completed" ? "已完成" : "部分完成", blocked ? "bad" : currentJob.status === "completed" ? "" : "warn");
          setStatus(blocked
            ? `已恢复待补充任务：${currentJob.recapturePlan.summary}`
            : restoredArchive
              ? `已恢复主体 ${currentJob.subjectItemId || currentJob.itemId} 的报告并保存到官网报告中心`
              : `已恢复主体 ${currentJob.subjectItemId || currentJob.itemId} 的报告`, blocked ? "#ff9d9d" : "#76e287");
        } else if (currentJob.status === "running") {
          currentJob.status = "interrupted";
          setStep("上次任务因页面刷新中断，请重新点击一键运行", currentJob.progress || 0, "待重跑", "warn");
          await persistJob();
        }
      } else {
        ui.subjectItemId.value = detectSubjectItemId();
        setStatus("等待运行", "#ffd66b");
      }
    } catch (error) {
      setStatus(publicErrorMessage(error, "任务恢复失败，请重新运行"), "#ff9d9d");
    }
  }

  void refreshSiteStatus().catch(() => {});
  siteStatusTimer = window.setInterval(() => void refreshSiteStatus().catch(() => {}), 30_000);
  void refreshAiStatus().catch(() => {});
  void restore();
})();
