(function initDmpXlsxWriter(root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.DmpXlsxWriter = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function createDmpXlsxWriter() {
  "use strict";

  const MIME_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
  const XMLNS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
  const RELNS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
  const TABLE_SHEETS = new Set(["对标总表", "商品与成功品", "周期汇总", "日GMV与费比", "渠道花费", "一级场景", "二级场景", "成长阶段数据", "基础指标对比", "关键词样本"]);

  function xmlEscape(value) {
    return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
  }

  function columnName(index) {
    let value = index + 1;
    let name = "";
    while (value > 0) {
      const remainder = (value - 1) % 26;
      name = String.fromCharCode(65 + remainder) + name;
      value = Math.floor((value - 1) / 26);
    }
    return name;
  }

  function cellRef(row, column) { return `${columnName(column)}${row}`; }

  function excelDate(value) {
    const match = String(value || "").match(/^(20\d{2})-(\d{2})-(\d{2})$/);
    if (!match) return NaN;
    return Math.floor((Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])) - Date.UTC(1899, 11, 30)) / 86400000);
  }

  function isPercentColumn(column) {
    const text = String(column || "");
    return !/排名变化/.test(text) && /比|率|变化|相对|CTR|贡献|百分位/i.test(text);
  }
  function fixedTwo(value) {
    const number = Number(value);
    const absolute = Math.abs(number);
    const rounded = Math.round((absolute + Number.EPSILON * Math.max(1, absolute)) * 100) / 100;
    return (number < 0 ? -rounded : rounded).toFixed(2);
  }
  function isIntegerColumn(column) { return /天数|层级|成交笔数|展现|点击|访客|数量/i.test(String(column || "")); }
  function isDateColumn(column) { return /^日期$|^开始$|^结束$|周期开始|周期结束|峰值日/.test(String(column || "")); }
  function isIdColumn(column) { return /商品ID|场景编号|sceneId/i.test(String(column || "")); }

  function styleFor(column, value, total = false) {
    if (total) return isPercentColumn(column) ? 12 : typeof value === "number" ? 11 : 10;
    if (isIdColumn(column)) return 8;
    if (isDateColumn(column) && Number.isFinite(excelDate(value))) return 7;
    if (typeof value === "number" && Number.isFinite(value)) {
      if (isPercentColumn(column)) return 6;
      if (isIntegerColumn(column)) return 9;
      return 5;
    }
    return 4;
  }

  function inlineCell(ref, value, style = 4) {
    const text = String(value ?? "");
    const preserve = /^\s|\s$|\n/.test(text) ? ' xml:space="preserve"' : "";
    return `<c r="${ref}" s="${style}" t="inlineStr"><is><t${preserve}>${xmlEscape(text)}</t></is></c>`;
  }

  function numericCell(ref, value, style = 5, formula = "") {
    const number = Number.isFinite(Number(value)) && value !== "" ? Number(value) : "";
    const calculation = formula ? `<f>${xmlEscape(formula)}</f>` : "";
    return `<c r="${ref}" s="${style}">${calculation}<v>${number}</v></c>`;
  }

  function blankCell(ref, style = 4) { return `<c r="${ref}" s="${style}"/>`; }

  function dataCell(ref, value, column, total = false, formula = "") {
    const style = styleFor(column, value, total);
    if (formula) return numericCell(ref, value, style, formula);
    const date = isDateColumn(column) ? excelDate(value) : NaN;
    if (Number.isFinite(date)) return numericCell(ref, date, 7);
    if (typeof value === "number" && Number.isFinite(value)) return numericCell(ref, value, style);
    if (value === "" || value === null || value === undefined) return blankCell(ref, style);
    if (isIdColumn(column) && /^\d{6,20}$/.test(String(value))) return inlineCell(ref, `${value}\u2060`, style);
    const text = String(value);
    if (isPercentColumn(column) && !text.includes("%") && /^[<>]?\s*[+-]?\d+(?:\.\d+)?(?:\s*[~～]\s*[<>]?\s*[+-]?\d+(?:\.\d+)?)?$/.test(text)) {
      return inlineCell(ref, text.replace(/[+-]?\d+(?:\.\d+)?/g, token => `${fixedTwo(Number(token) * 100)}%`), style);
    }
    return inlineCell(ref, value, style);
  }

  function rowXml(row, cells, height = 15) {
    return `<row r="${row}" ht="${height}" customHeight="1">${cells.join("")}</row>`;
  }

  function formulaFor(table, dataRowIndex, columnIndex) {
    const row = dataRowIndex + 5;
    const name = table.name;
    if (name === "对标总表" && columnIndex === 4) {
      const difference = isPercentColumn(table.rows[dataRowIndex]?.[1]);
      return difference ? `IF(OR(C${row}="",D${row}=""),"",C${row}-D${row})` : `IF(OR(C${row}="",D${row}="",D${row}=0),"",C${row}/D${row}-1)`;
    }
    if (name === "周期汇总") {
      if (columnIndex === 7) return Number.isFinite(Number(table.rows[dataRowIndex]?.[5])) && Number.isFinite(Number(table.rows[dataRowIndex]?.[6])) ? `F${row}*G${row}` : "";
      if (columnIndex === 10) return `IF(OR(J${row}="",H${row}="",H${row}=0),"",J${row}/H${row})`;
      if (columnIndex === 11) return `IF(OR(H${row}="",J${row}="",J${row}=0),"",H${row}/J${row})`;
      if (columnIndex === 12) return typeof table.rows[dataRowIndex]?.[8] === "number" ? `IF(OR(I${row}="",H${row}="",H${row}=0),"",I${row}/H${row})` : "";
      if (columnIndex === 14) return `IF(OR(H${row}="",E${row}="",E${row}=0),"",H${row}/E${row})`;
      if (columnIndex === 15) return `IF(OR(J${row}="",E${row}="",E${row}=0),"",J${row}/E${row})`;
    }
    if (name === "日GMV与费比") {
      if (columnIndex === 1 && dataRowIndex === table.rows.length - 1 && table.rows.every(values => typeof values[1] === "number" && Number.isFinite(values[1]))) {
        return `'周期汇总'!H6-SUM(B5:B${row - 1})`;
      }
      if (columnIndex === 7) return table.rows[dataRowIndex]?.slice(2, 7).every(value => typeof value === "number" && Number.isFinite(value)) ? `SUM(C${row}:G${row})` : "";
      if (columnIndex === 8) return `IF(B${row}>0,H${row}/B${row},"")`;
    }
    if (name === "成长阶段数据") {
      if (columnIndex === 11) return `IF(OR(K${row}="",J${row}="",J${row}=0),"",K${row}/J${row}-1)`;
      if (columnIndex === 14) return `IF(OR(N${row}="",I${row}="",I${row}=0),"",N${row}/I${row})`;
    }
    if (name === "基础指标对比" && columnIndex === 3) {
      const difference = isPercentColumn(table.rows[dataRowIndex]?.[0]);
      return difference ? `IF(OR(B${row}="",C${row}=""),"",B${row}-C${row})` : `IF(OR(B${row}="",C${row}="",C${row}=0),"",B${row}/C${row}-1)`;
    }
    return "";
  }

  function columnsXml(widths, count) {
    const values = Array.from({ length: count }, (_, index) => Number(widths?.[index]) || 16);
    return `<cols>${values.map((width, index) => `<col min="${index + 1}" max="${index + 1}" width="${width}" customWidth="1"/>`).join("")}</cols>`;
  }

  function titleRows(table, columnCount) {
    const last = columnName(columnCount - 1);
    return {
      rows: [
        rowXml(1, [inlineCell("A1", table.name, 1)], 21.6),
        rowXml(2, [inlineCell("A2", table.subtitle || "", 2)], 15),
        rowXml(3, [], 15)
      ],
      merges: [`A1:${last}1`, `A2:${last}2`]
    };
  }

  function dailyTotalRow(table, rowNumber) {
    const dataStart = 5;
    const dataEnd = rowNumber - 1;
    const completeColumn = columnIndex => table.rows.length > 0 && table.rows.every(values => typeof values[columnIndex] === "number" && Number.isFinite(values[columnIndex]));
    const totalValue = columnIndex => completeColumn(columnIndex)
      ? Math.round((table.rows.reduce((sum, values) => sum + values[columnIndex], 0) + Number.EPSILON) * 100) / 100
      : "";
    const totals = Array.from({ length: table.columns.length }, () => "");
    totals[0] = "周期合计";
    for (let columnIndex = 1; columnIndex <= 7; columnIndex += 1) totals[columnIndex] = totalValue(columnIndex);
    totals[8] = typeof totals[7] === "number" && typeof totals[1] === "number" && totals[1] !== 0
      ? Math.round((totals[7] / totals[1] + Number.EPSILON) * 1e6) / 1e6
      : "";
    return rowXml(rowNumber, totals.map((value, columnIndex) => {
      const ref = cellRef(rowNumber, columnIndex);
      if (columnIndex >= 1 && columnIndex <= 7 && completeColumn(columnIndex)) {
        return dataCell(ref, value, table.columns[columnIndex], true, `SUM(${columnName(columnIndex)}${dataStart}:${columnName(columnIndex)}${dataEnd})`);
      }
      if (columnIndex === 8 && totals[8] !== "") return dataCell(ref, value, table.columns[columnIndex], true, `IFERROR(H${rowNumber}/B${rowNumber},"")`);
      return dataCell(ref, value, table.columns[columnIndex], true);
    }), 18);
  }

  function regularSheet(table, sheetIndex, tableIndex, drawingIndex) {
    const mainColumns = table.columns.length;
    const hasChannelChart = table.name === "渠道花费";
    const hasStageChart = table.name === "成长阶段数据";
    const helperStart = hasChannelChart ? 9 : hasStageChart ? mainColumns + 1 : -1;
    const totalColumns = helperStart >= 0 ? helperStart + 3 : mainColumns;
    const titles = titleRows(table, mainColumns);
    const rows = [...titles.rows];
    rows.push(rowXml(4, table.columns.map((column, index) => inlineCell(cellRef(4, index), column, 3)), 30));
    table.rows.forEach((values, dataIndex) => {
      const rowNumber = dataIndex + 5;
      const isTotal = table.name === "渠道花费" && values[0] === "合计";
      const cells = values.map((value, columnIndex) => {
        const semanticColumn = table.name === "对标总表" ? `${table.columns[columnIndex]} ${values[1]}` : table.name === "基础指标对比" ? `${table.columns[columnIndex]} ${values[0]}` : table.columns[columnIndex];
        return dataCell(cellRef(rowNumber, columnIndex), value, semanticColumn, isTotal, formulaFor(table, dataIndex, columnIndex));
      });
      rows.push(rowXml(rowNumber, cells, table.name === "商品与成功品" && dataIndex > 0 ? 24 : 15));
    });
    const hasDailyTotal = table.name === "日GMV与费比";
    if (hasDailyTotal) rows.push(dailyTotalRow(table, table.rows.length + 5));

    if (hasChannelChart) {
      const subjectSpendIndex = table.columns.findIndex(column => /^主体\d+日消耗$/.test(String(column || "")));
      const competitorSpendIndex = table.columns.findIndex(column => /^对手\d+日消耗$/.test(String(column || "")));
      if (subjectSpendIndex < 0 || competitorSpendIndex < 0) throw new Error("渠道花费缺少主体/对手周期消耗列");
      const subjectSpendColumn = columnName(subjectSpendIndex);
      const competitorSpendColumn = columnName(competitorSpendIndex);
      const periodLabel = table.columns[subjectSpendIndex]?.match(/\d+日/)?.[0] || "30日";
      const helpers = ["渠道", `主体${periodLabel}`, `对手${periodLabel}`];
      rows[3] = rows[3].replace("</row>", `${helpers.map((value, index) => inlineCell(cellRef(4, helperStart + index), value, 3)).join("")}</row>`);
      for (let index = 0; index < Math.min(5, table.rows.length); index += 1) {
        const rowNumber = index + 5;
        const helperCells = [
          inlineCell(cellRef(rowNumber, helperStart), table.rows[index][0], 4),
          numericCell(cellRef(rowNumber, helperStart + 1), table.rows[index][subjectSpendIndex], 5, `${subjectSpendColumn}${rowNumber}`),
          numericCell(cellRef(rowNumber, helperStart + 2), table.rows[index][competitorSpendIndex], 5, `${competitorSpendColumn}${rowNumber}`)
        ].join("");
        rows[4 + index] = rows[4 + index].replace("</row>", `${helperCells}</row>`);
      }
    }

    if (hasStageChart) {
      const helpers = ["阶段", "平均日GMV", "日均消耗"];
      rows[3] = rows[3].replace("</row>", `${helpers.map((value, index) => inlineCell(cellRef(4, helperStart + index), value, 3)).join("")}</row>`);
      table.rows.forEach((values, index) => {
        const rowNumber = index + 5;
        const helperCells = [
          inlineCell(cellRef(rowNumber, helperStart), values[3] || values[0], 4),
          numericCell(cellRef(rowNumber, helperStart + 1), values[12], 5, `M${rowNumber}`),
          numericCell(cellRef(rowNumber, helperStart + 2), values[14], 5, `O${rowNumber}`)
        ].join("");
        rows[4 + index] = rows[4 + index].replace("</row>", `${helperCells}</row>`);
      });
    }

    const lastRow = Math.max(4, table.rows.length + 4 + (hasDailyTotal ? 1 : 0));
    const lastColumn = columnName(totalColumns - 1);
    const mergeXml = `<mergeCells count="${titles.merges.length}">${titles.merges.map(ref => `<mergeCell ref="${ref}"/>`).join("")}</mergeCells>`;
    const tablePart = TABLE_SHEETS.has(table.name) ? `<tableParts count="1"><tablePart r:id="rId1"/></tableParts>` : "";
    const drawing = drawingIndex ? `<drawing r:id="rId2"/>` : "";
    const xml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="${XMLNS}" xmlns:r="${RELNS}"><dimension ref="A1:${lastColumn}${Math.max(lastRow, hasChannelChart ? 29 : hasStageChart ? 26 : lastRow)}"/><sheetViews><sheetView showGridLines="0" workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="15"/>${columnsXml(table.widths, totalColumns)}<sheetData>${rows.join("")}</sheetData>${mergeXml}<pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/>${drawing}${tablePart}</worksheet>`;
    return { xml, tableRef: `A4:${columnName(mainColumns - 1)}${lastRow}`, drawingIndex, tableIndex, sheetIndex };
  }

  function overviewSheet(table) {
    const rows = [];
    rows.push(rowXml(1, [inlineCell("A1", "达摩盘商品成长竞品对标报告｜少壮AI自动化", 1)], 21.6));
    rows.push(rowXml(2, [inlineCell("A2", table.subtitle || "", 2)], 15));
    rows.push(rowXml(3, [], 15));
    const cards = table.kpis || [];
    const labels = [[0, 0, 14], [3, 1, 16], [6, 2, 18], [9, 3, 20]];
    rows.push(rowXml(5, labels.flatMap(([column, index, style]) => [inlineCell(cellRef(5, column), cards[index]?.label || "", style), blankCell(cellRef(5, column + 1), style), blankCell(cellRef(5, column + 2), style)]), 15));
    const valueCells = [];
    labels.forEach(([column, index, style]) => {
      const valueStyle = style + 1;
      const source = index === 0 ? "'周期汇总'!H5" : index === 1 ? "'周期汇总'!H6" : index === 2 ? "'周期汇总'!K5" : "'周期汇总'!K6";
      valueCells.push(numericCell(cellRef(6, column), cards[index]?.value, valueStyle, `IF(${source}="","",${source})`), blankCell(cellRef(6, column + 1), valueStyle), blankCell(cellRef(6, column + 2), valueStyle));
    });
    rows.push(rowXml(6, valueCells, 18));
    rows.push(rowXml(7, labels.flatMap(([column, , style]) => [blankCell(cellRef(7, column), style + 1), blankCell(cellRef(7, column + 1), style + 1), blankCell(cellRef(7, column + 2), style + 1)]), 18));
    rows.push(rowXml(8, [], 15));
    rows.push(rowXml(9, [inlineCell("A9", "对象与周期", 13)], 15));
    rows.push(rowXml(10, table.columns.map((column, index) => inlineCell(cellRef(10, index), column, 3)), 30));
    table.rows.forEach((values, index) => rows.push(rowXml(index + 11, values.map((value, column) => values[0] === "商品ID" && (column === 1 || column === 2)
      ? inlineCell(cellRef(index + 11, column), value ? `${value}\u2060` : "", 8)
      : dataCell(cellRef(index + 11, column), value, table.columns[column])), 15)));
    const merges = ["A1:L1", "A2:L2", "A5:C5", "A6:C7", "D5:F5", "D6:F7", "G5:I5", "G6:I7", "J5:L5", "J6:L7", "A9:L9"];
    const lastRow = Math.max(14, table.rows.length + 10);
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="${XMLNS}" xmlns:r="${RELNS}"><dimension ref="A1:L${lastRow}"/><sheetViews><sheetView showGridLines="0" workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="15"/>${columnsXml(table.widths, 12)}<sheetData>${rows.join("")}</sheetData><mergeCells count="${merges.length}">${merges.map(ref => `<mergeCell ref="${ref}"/>`).join("")}</mergeCells><pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/></worksheet>`;
  }

  function tableXml(table, tableIndex, ref) {
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><table xmlns="${XMLNS}" id="${tableIndex}" name="Table${tableIndex}" displayName="Table${tableIndex}" ref="${ref}" totalsRowShown="0"><autoFilter ref="${ref}"/><tableColumns count="${table.columns.length}">${table.columns.map((column, index) => `<tableColumn id="${index + 1}" name="${xmlEscape(column)}"/>`).join("")}</tableColumns><tableStyleInfo name="TableStyleMedium2" showFirstColumn="0" showLastColumn="0" showRowStripes="1" showColumnStripes="0"/></table>`;
  }

  function sheetRelationships(tableIndex, drawingIndex) {
    const relationships = [];
    if (tableIndex) relationships.push(`<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/table" Target="../tables/table${tableIndex}.xml"/>`);
    if (drawingIndex) relationships.push(`<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing${drawingIndex}.xml"/>`);
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${relationships.join("")}</Relationships>`;
  }

  function drawingXml(drawingIndex, chartType) {
    const channel = chartType === "channel";
    const from = channel ? { col: 9, row: 10 } : { col: 18, row: 9 };
    const to = channel ? { col: 19, row: 29 } : { col: 28, row: 26 };
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><xdr:twoCellAnchor><xdr:from><xdr:col>${from.col}</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>${from.row}</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from><xdr:to><xdr:col>${to.col}</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>${to.row}</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to><xdr:graphicFrame macro=""><xdr:nvGraphicFramePr><xdr:cNvPr id="${drawingIndex + 1}" name="图表 ${drawingIndex}"/><xdr:cNvGraphicFramePr/></xdr:nvGraphicFramePr><xdr:xfrm/><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/chart"><c:chart xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:r="${RELNS}" r:id="rId1"/></a:graphicData></a:graphic></xdr:graphicFrame><xdr:clientData/></xdr:twoCellAnchor></xdr:wsDr>`;
  }

  function drawingRelationships(drawingIndex) {
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart" Target="../charts/chart${drawingIndex}.xml"/></Relationships>`;
  }

  function seriesXml(index, nameRef, nameText, categoryRef, categories, valueRef, values, color) {
    const stringCache = list => `<c:strCache><c:ptCount val="${list.length}"/>${list.map((value, itemIndex) => `<c:pt idx="${itemIndex}"><c:v>${xmlEscape(value)}</c:v></c:pt>`).join("")}</c:strCache>`;
    const numberCache = list => `<c:numCache><c:formatCode>#,##0.00</c:formatCode><c:ptCount val="${list.length}"/>${list.map((value, itemIndex) => Number.isFinite(Number(value)) && value !== "" ? `<c:pt idx="${itemIndex}"><c:v>${Number(value)}</c:v></c:pt>` : "").join("")}</c:numCache>`;
    return `<c:ser><c:idx val="${index}"/><c:order val="${index}"/><c:tx><c:strRef><c:f>${xmlEscape(nameRef)}</c:f>${stringCache([nameText])}</c:strRef></c:tx><c:spPr><a:solidFill><a:srgbClr val="${color}"/></a:solidFill><a:ln><a:solidFill><a:srgbClr val="${color}"/></a:solidFill></a:ln></c:spPr><c:cat><c:strRef><c:f>${xmlEscape(categoryRef)}</c:f>${stringCache(categories)}</c:strRef></c:cat><c:val><c:numRef><c:f>${xmlEscape(valueRef)}</c:f>${numberCache(values)}</c:numRef></c:val></c:ser>`;
  }

  function chartXml(table, chartType) {
    const sheet = `'${table.name.replace(/'/g, "''")}'`;
    const channel = chartType === "channel";
    const lastRow = Math.max(5, table.rows.length + 4);
    const title = table.chartTitle || (channel ? "30日渠道消耗对比" : "阶段平均日GMV");
    const channelCategories = table.rows.slice(0, 5).map(row => row[0]);
    const stageCategories = table.rows.map(row => row[3] || row[0]);
    const stageHelperStart = table.columns.length + 1;
    const stageCategoryColumn = columnName(stageHelperStart);
    const stageValueColumn = columnName(stageHelperStart + 1);
    const subjectSpendIndex = channel ? table.columns.findIndex(column => /^主体\d+日消耗$/.test(String(column || ""))) : -1;
    const competitorSpendIndex = channel ? table.columns.findIndex(column => /^对手\d+日消耗$/.test(String(column || ""))) : -1;
    if (channel && (subjectSpendIndex < 0 || competitorSpendIndex < 0)) throw new Error("渠道图表缺少主体/对手周期消耗列");
    const series = channel
      ? seriesXml(0, `${sheet}!$K$4`, (table.columns[subjectSpendIndex] || "主体").replace("消耗", ""), `${sheet}!$J$5:$J$9`, channelCategories, `${sheet}!$K$5:$K$9`, table.rows.slice(0, 5).map(row => row[subjectSpendIndex]), "176B87")
        + seriesXml(1, `${sheet}!$L$4`, (table.columns[competitorSpendIndex] || "对手").replace("消耗", ""), `${sheet}!$J$5:$J$9`, channelCategories, `${sheet}!$L$5:$L$9`, table.rows.slice(0, 5).map(row => row[competitorSpendIndex]), "ED7D31")
      : seriesXml(0, `${sheet}!$${stageValueColumn}$4`, "平均日GMV", `${sheet}!$${stageCategoryColumn}$5:$${stageCategoryColumn}$${lastRow}`, stageCategories, `${sheet}!$${stageValueColumn}$5:$${stageValueColumn}$${lastRow}`, table.rows.map(row => row[12]), "176B87");
    const plot = channel
      ? `<c:barChart><c:barDir val="col"/><c:grouping val="clustered"/><c:varyColors val="0"/>${series}<c:axId val="48650112"/><c:axId val="48672768"/></c:barChart>`
      : `<c:lineChart><c:grouping val="standard"/><c:varyColors val="0"/>${series}<c:smooth val="0"/><c:axId val="48650112"/><c:axId val="48672768"/></c:lineChart>`;
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><c:chartSpace xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="${RELNS}"><c:date1904 val="0"/><c:lang val="zh-CN"/><c:roundedCorners val="0"/><c:chart><c:title><c:tx><c:rich><a:bodyPr/><a:lstStyle/><a:p><a:r><a:rPr lang="zh-CN" sz="1200" b="1"/><a:t>${xmlEscape(title)}</a:t></a:r></a:p></c:rich></c:tx><c:layout/><c:overlay val="0"/></c:title><c:autoTitleDeleted val="0"/><c:plotArea><c:layout/>${plot}<c:catAx><c:axId val="48650112"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="0"/><c:axPos val="b"/><c:tickLblPos val="nextTo"/><c:crossAx val="48672768"/><c:crosses val="autoZero"/><c:auto val="1"/><c:lblAlgn val="ctr"/><c:lblOffset val="100"/></c:catAx><c:valAx><c:axId val="48672768"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="0"/><c:axPos val="l"/><c:majorGridlines/><c:numFmt formatCode="#,##0.00" sourceLinked="0"/><c:tickLblPos val="nextTo"/><c:crossAx val="48650112"/><c:crosses val="autoZero"/><c:crossBetween val="between"/></c:valAx></c:plotArea><c:legend><c:legendPos val="b"/><c:layout/><c:overlay val="0"/></c:legend><c:plotVisOnly val="1"/><c:dispBlanksAs val="gap"/><c:showDLblsOverMax val="0"/></c:chart><c:printSettings><c:headerFooter/><c:pageMargins b="0.75" l="0.7" r="0.7" t="0.75" header="0.3" footer="0.3"/><c:pageSetup/></c:printSettings></c:chartSpace>`;
  }

  function stylesXml() {
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="${XMLNS}"><numFmts count="4"><numFmt numFmtId="164" formatCode="#,##0.00"/><numFmt numFmtId="165" formatCode="0.00%"/><numFmt numFmtId="166" formatCode="yyyy-mm-dd"/><numFmt numFmtId="167" formatCode="@"/></numFmts><fonts count="9"><font><sz val="11"/><name val="Carlito"/></font><font><b/><sz val="18"/><color rgb="FFFFFFFF"/><name val="PingFang SC"/></font><font><sz val="9"/><color rgb="FF667581"/><name val="PingFang SC"/></font><font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="PingFang SC"/></font><font><sz val="10"/><color rgb="FF1F2933"/><name val="PingFang SC"/></font><font><b/><sz val="10"/><color rgb="FF123047"/><name val="PingFang SC"/></font><font><b/><sz val="10"/><color rgb="FF123047"/><name val="Carlito"/></font><font><b/><sz val="18"/><color rgb="FF123047"/><name val="Carlito"/></font><font><b/><sz val="11"/><color rgb="FF123047"/><name val="PingFang SC"/></font></fonts><fills count="10"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF123047"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFEAF0F3"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FF007F7A"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFF4DA"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE8F4F3"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE9F4ED"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFCEAE8"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFFFFF"/></patternFill></fill></fills><borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FFD8E0E5"/></left><right style="thin"><color rgb="FFD8E0E5"/></right><top style="thin"><color rgb="FFD8E0E5"/></top><bottom style="thin"><color rgb="FFD8E0E5"/></bottom><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="22"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf><xf numFmtId="0" fontId="2" fillId="3" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf><xf numFmtId="0" fontId="3" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="4" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf><xf numFmtId="164" fontId="4" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1"><alignment horizontal="right" vertical="center"/></xf><xf numFmtId="165" fontId="4" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1"><alignment horizontal="right" vertical="center"/></xf><xf numFmtId="166" fontId="4" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="167" fontId="4" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1"><alignment vertical="center"/></xf><xf numFmtId="3" fontId="4" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1"><alignment horizontal="right" vertical="center"/></xf><xf numFmtId="0" fontId="5" fillId="5" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/><xf numFmtId="164" fontId="5" fillId="5" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="right"/></xf><xf numFmtId="165" fontId="5" fillId="5" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="right"/></xf><xf numFmtId="0" fontId="8" fillId="6" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/><xf numFmtId="0" fontId="6" fillId="6" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center"/></xf><xf numFmtId="164" fontId="7" fillId="6" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="6" fillId="5" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center"/></xf><xf numFmtId="164" fontId="7" fillId="5" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="6" fillId="7" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center"/></xf><xf numFmtId="165" fontId="7" fillId="7" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="6" fillId="8" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center"/></xf><xf numFmtId="165" fontId="7" fillId="8" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center" vertical="center"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles><tableStyles count="0" defaultTableStyle="TableStyleMedium2" defaultPivotStyle="PivotStyleLight16"/></styleSheet>`;
  }

  function contentTypes(sheetCount, tableCount, chartCount) {
    const overrides = [
      '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
      '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>',
      '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>',
      '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
    ];
    for (let index = 1; index <= sheetCount; index += 1) overrides.push(`<Override PartName="/xl/worksheets/sheet${index}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`);
    for (let index = 1; index <= tableCount; index += 1) overrides.push(`<Override PartName="/xl/tables/table${index}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.table+xml"/>`);
    for (let index = 1; index <= chartCount; index += 1) {
      overrides.push(`<Override PartName="/xl/drawings/drawing${index}.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/>`);
      overrides.push(`<Override PartName="/xl/charts/chart${index}.xml" ContentType="application/vnd.openxmlformats-officedocument.drawingml.chart+xml"/>`);
    }
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>${overrides.join("")}</Types>`;
  }

  function workbookXml(tables) {
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="${XMLNS}" xmlns:r="${RELNS}"><fileVersion appName="xl"/><workbookPr/><bookViews><workbookView xWindow="0" yWindow="0" windowWidth="28800" windowHeight="15000"/></bookViews><sheets>${tables.map((table, index) => `<sheet name="${xmlEscape(table.name)}" sheetId="${index + 1}" r:id="rId${index + 1}"/>`).join("")}</sheets><calcPr calcId="191029" fullCalcOnLoad="1" forceFullCalc="1"/></workbook>`;
  }

  function workbookRelationships(sheetCount) {
    const relationships = [];
    for (let index = 1; index <= sheetCount; index += 1) relationships.push(`<Relationship Id="rId${index}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${index}.xml"/>`);
    relationships.push(`<Relationship Id="rId${sheetCount + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>`);
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${relationships.join("")}</Relationships>`;
  }

  function rootRelationships() {
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>`;
  }

  function coreProperties() {
    const now = new Date().toISOString();
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:creator>少壮AI自动化</dc:creator><cp:lastModifiedBy>少壮AI自动化</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">${now}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">${now}</dcterms:modified><dc:title>达摩盘商品成长竞品对标报告｜少壮AI自动化</dc:title></cp:coreProperties>`;
  }

  function appProperties(tables) {
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>少壮AI自动化</Application><DocSecurity>0</DocSecurity><ScaleCrop>false</ScaleCrop><HeadingPairs><vt:vector size="2" baseType="variant"><vt:variant><vt:lpstr>Worksheets</vt:lpstr></vt:variant><vt:variant><vt:i4>${tables.length}</vt:i4></vt:variant></vt:vector></HeadingPairs><TitlesOfParts><vt:vector size="${tables.length}" baseType="lpstr">${tables.map(table => `<vt:lpstr>${xmlEscape(table.name)}</vt:lpstr>`).join("")}</vt:vector></TitlesOfParts><Company></Company><LinksUpToDate>false</LinksUpToDate><SharedDoc>false</SharedDoc><HyperlinksChanged>false</HyperlinksChanged><AppVersion>16.0300</AppVersion></Properties>`;
  }

  function buildXlsxParts(report) {
    if (!report || !Array.isArray(report.tables) || report.tables.length !== 11) throw new Error("报告必须包含参考模板规定的 11 个页签");
    const parts = new Map();
    let tableIndex = 0;
    let drawingIndex = 0;
    report.tables.forEach((table, index) => {
      const sheetIndex = index + 1;
      if (table.name === "报告总览") {
        parts.set(`xl/worksheets/sheet${sheetIndex}.xml`, overviewSheet(table));
        return;
      }
      tableIndex += 1;
      const chartType = table.name === "渠道花费" ? "channel" : table.name === "成长阶段数据" ? "stage" : "";
      if (chartType) drawingIndex += 1;
      const built = regularSheet(table, sheetIndex, tableIndex, chartType ? drawingIndex : 0);
      parts.set(`xl/worksheets/sheet${sheetIndex}.xml`, built.xml);
      parts.set(`xl/tables/table${tableIndex}.xml`, tableXml(table, tableIndex, built.tableRef));
      parts.set(`xl/worksheets/_rels/sheet${sheetIndex}.xml.rels`, sheetRelationships(tableIndex, built.drawingIndex));
      if (chartType) {
        parts.set(`xl/drawings/drawing${drawingIndex}.xml`, drawingXml(drawingIndex, chartType));
        parts.set(`xl/drawings/_rels/drawing${drawingIndex}.xml.rels`, drawingRelationships(drawingIndex));
        parts.set(`xl/charts/chart${drawingIndex}.xml`, chartXml(table, chartType));
      }
    });
    parts.set("[Content_Types].xml", contentTypes(report.tables.length, tableIndex, drawingIndex));
    parts.set("_rels/.rels", rootRelationships());
    parts.set("docProps/core.xml", coreProperties());
    parts.set("docProps/app.xml", appProperties(report.tables));
    parts.set("xl/workbook.xml", workbookXml(report.tables));
    parts.set("xl/_rels/workbook.xml.rels", workbookRelationships(report.tables.length));
    parts.set("xl/styles.xml", stylesXml());
    return parts;
  }

  const CRC_TABLE = (() => {
    const table = new Uint32Array(256);
    for (let index = 0; index < 256; index += 1) {
      let value = index;
      for (let bit = 0; bit < 8; bit += 1) value = (value & 1) ? 0xEDB88320 ^ (value >>> 1) : value >>> 1;
      table[index] = value >>> 0;
    }
    return table;
  })();

  function crc32(bytes) {
    let crc = 0xFFFFFFFF;
    for (const byte of bytes) crc = CRC_TABLE[(crc ^ byte) & 0xFF] ^ (crc >>> 8);
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }

  function dosDateTime(date = new Date()) {
    const year = Math.max(1980, date.getFullYear());
    return {
      date: ((year - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate(),
      time: (date.getHours() << 11) | (date.getMinutes() << 5) | Math.floor(date.getSeconds() / 2)
    };
  }

  function u16(value) { return new Uint8Array([value & 0xFF, (value >>> 8) & 0xFF]); }
  function u32(value) { return new Uint8Array([value & 0xFF, (value >>> 8) & 0xFF, (value >>> 16) & 0xFF, (value >>> 24) & 0xFF]); }

  function concatBytes(chunks) {
    const size = chunks.reduce((sum, chunk) => sum + chunk.length, 0);
    const output = new Uint8Array(size);
    let offset = 0;
    chunks.forEach(chunk => { output.set(chunk, offset); offset += chunk.length; });
    return output;
  }

  function zipStore(parts) {
    const encoder = new TextEncoder();
    const localChunks = [];
    const centralChunks = [];
    const stamp = dosDateTime();
    let offset = 0;
    for (const [name, content] of parts) {
      const filename = encoder.encode(name);
      const data = typeof content === "string" ? encoder.encode(content) : content;
      const crc = crc32(data);
      const local = concatBytes([u32(0x04034B50), u16(20), u16(0x0800), u16(0), u16(stamp.time), u16(stamp.date), u32(crc), u32(data.length), u32(data.length), u16(filename.length), u16(0), filename, data]);
      localChunks.push(local);
      centralChunks.push(concatBytes([u32(0x02014B50), u16(20), u16(20), u16(0x0800), u16(0), u16(stamp.time), u16(stamp.date), u32(crc), u32(data.length), u32(data.length), u16(filename.length), u16(0), u16(0), u16(0), u16(0), u32(0), u32(offset), filename]));
      offset += local.length;
    }
    const central = concatBytes(centralChunks);
    const end = concatBytes([u32(0x06054B50), u16(0), u16(0), u16(parts.size), u16(parts.size), u32(central.length), u32(offset), u16(0)]);
    return concatBytes([...localChunks, central, end]);
  }

  function buildXlsx(report) { return zipStore(buildXlsxParts(report)); }

  return { MIME_TYPE, buildXlsx, buildXlsxParts, zipStore };
});
