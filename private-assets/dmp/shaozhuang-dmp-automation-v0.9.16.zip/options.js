(() => {
  "use strict";

  const ui = Object.fromEntries([
    "enabled", "endpoint", "provider", "apiKey", "visionModel", "textModel", "baseUrl",
    "profileBadge", "keyHint", "save", "test", "clearKey", "clearKeyInline", "status"
  ].map(id => [id, document.getElementById(id)]));

  const DEFAULT_PROFILE = {
    provider: "openai-compatible",
    providerName: "ChatGPT / OpenAI-compatible",
    visionModel: "gpt-5.6-sol",
    textModel: "gpt-5.6-sol",
    baseUrl: "https://api.openai.com/v1",
    hasApiKey: false,
    keySource: "none"
  };

  function message(type, payload = {}) {
    return chrome.runtime.sendMessage({ type, ...payload });
  }

  function show(text, ok = true) {
    ui.status.textContent = text;
    ui.status.style.color = ok ? "#b7d84a" : "#ff8f7c";
  }

  function setBusy(busy) {
    [ui.save, ui.test, ui.clearKey, ui.clearKeyInline].forEach(button => { button.disabled = busy; });
  }

  function formProfile(extra = {}) {
    return {
      provider: ui.provider.value,
      providerName: ui.provider.options[ui.provider.selectedIndex]?.text || DEFAULT_PROFILE.providerName,
      visionModel: ui.visionModel.value.trim(),
      textModel: ui.textModel.value.trim(),
      baseUrl: ui.baseUrl.value.trim(),
      apiKey: ui.apiKey.value.trim(),
      ...extra
    };
  }

  function applyProfile(value = {}) {
    const profile = { ...DEFAULT_PROFILE, ...value };
    ui.provider.value = profile.provider;
    ui.visionModel.value = profile.visionModel;
    ui.textModel.value = profile.textModel;
    ui.baseUrl.value = profile.baseUrl;
    ui.apiKey.value = "";
    if (profile.hasApiKey) {
      ui.apiKey.placeholder = "••••••••••••••••（已保存，留空不修改）";
      ui.profileBadge.textContent = profile.keySource === "environment" ? "环境变量 Key 已生效" : "本机 Key 已保存";
      ui.keyHint.textContent = profile.keySource === "environment"
        ? "当前优先使用 OPENAI_API_KEY 环境变量；设置页不会显示或覆盖读取该值。"
        : "API Key 已保存在本机报告服务的当前用户配置中；此页不会回显。";
    } else {
      ui.apiKey.placeholder = "输入 API Key；留空表示不修改";
      ui.profileBadge.textContent = "API Key 未配置";
      ui.keyHint.textContent = "只提交到本机报告服务，不写入扩展存储。";
    }
  }

  async function saveLocalConfig() {
    const result = await message("DMP_CDP_SAVE_AI_CONFIG", {
      config: { enabled: ui.enabled.checked, endpoint: ui.endpoint.value.trim() }
    });
    if (!result?.ok) throw new Error(result?.error || "本机报告端点设置无效");
    ui.endpoint.value = result.config.endpoint;
    return result.config;
  }

  async function saveAll({ probe = false } = {}) {
    setBusy(true);
    try {
      await saveLocalConfig();
      const saved = await message("DMP_CDP_SAVE_PROVIDER_CONFIG", { profile: formProfile() });
      if (!saved?.ok) throw new Error(saved?.error || "服务商配置保存失败");
      applyProfile(saved.profile);
      if (!probe) {
        show("配置已保存；API Key 未写入浏览器扩展。", true);
        return;
      }
      show("正在验证服务商鉴权和连接…", true);
      const tested = await message("DMP_CDP_AI_HEALTH", { probe: true });
      if (!tested?.ok) throw new Error(tested?.error || "服务商连接测试失败");
      const profile = tested.health.profile || saved.profile;
      applyProfile(profile);
      show(`连接正常 · ${profile.providerName || "OpenAI-compatible"} · ${tested.health.model} · API Key 已验证`, true);
    } catch (error) {
      show(error?.message || String(error), false);
    } finally {
      setBusy(false);
    }
  }

  async function clearApiKey() {
    if (!confirm("确定清除本机配置中保存的 API Key？环境变量 OPENAI_API_KEY 不受影响。")) return;
    setBusy(true);
    try {
      await saveLocalConfig();
      const result = await message("DMP_CDP_CLEAR_PROVIDER_API_KEY", { profile: formProfile({ apiKey: "", clearApiKey: true }) });
      if (!result?.ok) throw new Error(result?.error || "API Key 清除失败");
      applyProfile(result.profile);
      show(result.profile.keySource === "environment"
        ? "本机配置中的 Key 已清除；OPENAI_API_KEY 环境变量仍在生效。"
        : "本机配置中的 API Key 已清除。", true);
    } catch (error) {
      show(error?.message || String(error), false);
    } finally {
      setBusy(false);
    }
  }

  async function restore() {
    setBusy(true);
    try {
      const local = await message("DMP_CDP_GET_AI_CONFIG");
      if (!local?.ok) throw new Error(local?.error || "读取扩展设置失败");
      ui.enabled.checked = local.config.enabled !== false;
      ui.endpoint.value = local.config.endpoint || "http://127.0.0.1:8787/report";
      const provider = await message("DMP_CDP_GET_PROVIDER_CONFIG");
      if (!provider?.ok) {
        applyProfile(DEFAULT_PROFILE);
        ui.profileBadge.textContent = "本机服务未连接";
        show(`${provider?.error || "无法读取服务商配置"}。请先运行 node api-server/server.mjs。`, false);
        return;
      }
      applyProfile(provider.profile);
      show("配置读取完成。", true);
    } catch (error) {
      applyProfile(DEFAULT_PROFILE);
      ui.profileBadge.textContent = "配置读取失败";
      show(error?.message || String(error), false);
    } finally {
      setBusy(false);
    }
  }

  ui.save.addEventListener("click", () => void saveAll());
  ui.test.addEventListener("click", () => void saveAll({ probe: true }));
  ui.clearKey.addEventListener("click", () => void clearApiKey());
  ui.clearKeyInline.addEventListener("click", () => void clearApiKey());
  void restore();
})();
