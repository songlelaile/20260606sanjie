(function initDmpWorkflowEngine(root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.DmpWorkflowEngine = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function createDmpWorkflowEngine() {
  "use strict";

  const COMPARISON_TABS = ["关键指标对比", "推广策略对比", "人群对比"];
  const SUCCESS_ENTRY_LABELS = ["取得成功品", "获取成功品", "定制成功品", "选择成功品", "设置成功品", "添加成功品", "切换成功品", "修改成功品"];
  const SUCCESS_CLEAR_LABELS = ["全部删除", "清空全部", "全部移除", "全部清除"];

  // 这些值对应“定制成功品”弹窗中用户截图展示的筛选状态。
  const SUCCESS_FILTERS = [
    { key: "priceBand", label: "价格带", selected: ["全部价格带"], options: ["全选"] },
    { key: "growthCycle", label: "打爆周期", selected: ["新品打爆期", "爆品期"], options: ["新品打爆期", "爆品期"] },
    { key: "onlineCycle", label: "上架周期", selected: ["全部上架周期"], options: ["全选"] },
    { key: "rankLevel", label: "TOP水位", selected: ["TOP0.5%以内"], options: ["TOP0.5%以内"] },
    { key: "salesLevel", label: "销售额水位", selected: ["1000w以上", "500万~1000万"], options: ["1000w以上", "500万~1000万"] }
  ];

  function normalizeText(value) {
    return String(value || "").replace(/\s+/g, "").replace(/[～—–]/g, "~").trim();
  }

  function pad2(value) {
    return String(value).padStart(2, "0");
  }

  function localDate(value) {
    return `${value.getFullYear()}-${pad2(value.getMonth() + 1)}-${pad2(value.getDate())}`;
  }

  function pastCompletedDays(days = 30, now = new Date()) {
    const count = Number.isInteger(days) && days > 0 ? days : 30;
    const end = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
    const start = new Date(end.getFullYear(), end.getMonth(), end.getDate() - count + 1);
    return { startDate: localDate(start), endDate: localDate(end), days: count };
  }

  function buildGrowupRouteHash(itemId, nonce = Date.now()) {
    const value = String(itemId || "").trim();
    if (!/^\d{6,20}$/.test(value)) throw new Error("商品 ID 必须是 6–20 位数字");
    return `#!/items/growup-path?spm=&itemId=${encodeURIComponent(value)}&dmpReportTask=${encodeURIComponent(String(nonce))}`;
  }

  function selectedSuccessCount(value) {
    const match = normalizeText(value).match(/已选成功品[（(]?(\d+)\/(\d+)项?[）)]?/);
    return match ? Number(match[1]) : null;
  }

  return { COMPARISON_TABS, SUCCESS_ENTRY_LABELS, SUCCESS_CLEAR_LABELS, SUCCESS_FILTERS, normalizeText, pastCompletedDays, buildGrowupRouteHash, selectedSuccessCount };
});
