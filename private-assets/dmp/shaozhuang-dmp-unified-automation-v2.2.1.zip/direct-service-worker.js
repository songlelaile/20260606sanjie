import "./direct-core.js";
import "./completeness-engine.js";
import "./report-engine.js";
import "./rolling7-engine.js";
import "./rolling7-html-writer.js";
import { normalizeOfficialReportUrl } from "./official-share-url.mjs";

const core = globalThis.DmpDirectCore;
const completeness = globalThis.DmpCompletenessEngine;
const reportEngine = globalThis.DmpReportEngine;
const rolling7 = globalThis.DmpRolling7Engine;
const rolling7HtmlWriter = globalThis.DmpRolling7HtmlWriter;
if (!core || !completeness || !reportEngine || !rolling7) throw new Error("取数核心模块加载失败");

let runningPromise = null;
let storedArchivePromise = null;
const DRAFT_KEY = "dmpDirectDraftConfigV1";
let draftWriteTail = Promise.resolve();
const SANJIE_SESSION_COOKIE = "sanjie_session";
const SANJIE_IMPORT_TIMEOUT_MS = 20_000;
const OFFICIAL_AUTH_TIMEOUT_MS = 10_000;
const OFFICIAL_AUTH_CACHE_MS = 20_000;
const OFFICIAL_LAUNCH_TTL_MS = 60_000;
const OFFICIAL_COOKIE_URLS = ["https://www.shaozhuangai.com/", "https://shaozhuangai.com/"];
const RECOVERABLE_SANJIE_CODES = new Set([
  "SANJIE_LOGIN_REQUIRED", "SANJIE_TIMEOUT", "SANJIE_UNAVAILABLE", "SANJIE_IMPORT_UNCERTAIN",
  "SANJIE_REPORT_REJECTED", "SANJIE_IMPORT_FAILED", "REPORT_NOT_UPLOADABLE"
]);
const ARCHIVE_OUTBOX_LIMIT = 100;
const ROLLING7_STATE_KEY = "dmpMarketRolling7StateV1";
const ROLLING7_DATASET_KEY = "dmpMarketRolling7DatasetV1";
const ROLLING7_HTML_KEY = "dmpMarketRolling7HtmlV1";
const ROLLING7_ALARM_NAME = "dmpMarketRolling7ResumeV1";
const ROLLING7_ALARM_DELAY_MINUTES = 0.5;
const ROLLING7_MIN_INTERVAL_MS = 1200;
const ROLLING7_RETRY_BASE_MS = 1500;
const ROLLING7_MAX_RETRIES = 2;
const ROLLING7_TAIL_CONFIRMATION_ROUNDS = 3;
const ROLLING7_MAX_OBSERVED_LAG_DAYS = 2;
const ROLLING7_PAGE_API_CAPABILITY = "market-rolling7-v1";
const ROLLING7_BLOCKING_CODES = new Set([
  "NO_DMP_TAB", "TAB_UNAVAILABLE", "PAGE_API_UNAVAILABLE", "TEMPLATE_REQUIRED",
  "LOGIN_REQUIRED", "API_ERROR", "UNEXPECTED_ORIGIN", "REQUEST_NOT_ALLOWED", "INVALID_REQUEST",
  "INVALID_CATE_ID", "INVALID_DATE", "INVALID_DATE_RANGE"
]);
let rolling7State = null;
let rolling7MutationTail = Promise.resolve();
let rolling7Promise = null;
let rolling7ArchivePromise = null;
let rolling7InitializationPromise = null;
let rolling7LoadError = null;
let rolling7IgnorePersistedState = false;

function normalizeArchiveOutbox(value) {
  return Array.isArray(value) ? value.slice() : [];
}

function normalizeLocalState(value) {
  const state = value && typeof value === "object" ? value : {};
  const sourceShop = core.sanitizeSourceShop(state.sourceShop);
  return {
    lastConfig: { subjectItemId: "", successItemId: "" },
    datasetTemplate: "",
    job: null,
    report: null,
    sanjie: null,
    sourceShop: null,
    ...state,
    schemaVersion: 2,
    sourceShop,
    archiveOutbox: normalizeArchiveOutbox(state.archiveOutbox)
  };
}

async function readLocalState() {
  const stored = await chrome.storage.local.get(core.STATE_KEY);
  return normalizeLocalState(stored[core.STATE_KEY]);
}

async function writeLocalState(next) {
  const state = normalizeLocalState(next);
  await chrome.storage.local.set({ [core.STATE_KEY]: state });
  return state;
}

function rolling7SafeError(error, fallback = "滚动7天取数失败") {
  const rawCode = String(error?.code || error?.name || "REQUEST_FAILED");
  const code = /^[A-Za-z0-9_-]{1,64}$/.test(rawCode) ? rawCode : "REQUEST_FAILED";
  const candidate = {
    code,
    message: core.safeErrorText(error, fallback).slice(0, 240)
  };
  try {
    rolling7.assertSensitiveFree(candidate);
    return candidate;
  } catch {
    return { code: "REQUEST_FAILED", message: fallback };
  }
}

function emptyPublicRolling7State() {
  return {
    status: "idle",
    total: 0,
    completed: 0,
    missing: 0,
    conflicts: 0,
    boundaryMismatches: 0,
    failed: 0,
    currentDate: null,
    estimatedRemainingMs: 0,
    progress: 0,
    reportReady: false,
    error: rolling7LoadError?.message || "",
    errorCode: rolling7LoadError?.code || "",
    config: null
  };
}

function rolling7CurrentDate() {
  try {
    const parts = new Intl.DateTimeFormat("en-CA", {
      timeZone: "Asia/Shanghai",
      year: "numeric",
      month: "2-digit",
      day: "2-digit"
    }).formatToParts(new Date());
    const values = Object.fromEntries(parts.map(part => [part.type, part.value]));
    if (values.year && values.month && values.day) return `${values.year}-${values.month}-${values.day}`;
  } catch {}
  return new Date().toISOString().slice(0, 10);
}

function migrateUnavailableRolling7Tail(state, error = state?.lastError, taskId = null) {
  if (!state || !["running", "paused"].includes(state.queueStatus)) return state;
  const configuredRounds = Number(state.config?.tailConfirmationRounds || 0);
  const legacyCheckpoint = configuredRounds < 1;
  // New checkpoints already persist each real observation. Replaying the finalizer while the
  // service worker boots would fabricate another round without a new page response. Only old
  // checkpoints (created before the confirmation fields existed) receive the one-time migration.
  if (!legacyCheckpoint) return state;
  return rolling7.finalizeUnavailableTail(state, taskId, error, {
    currentDate: rolling7CurrentDate(),
    maxLagDays: Number(state.config?.maxObservedLagDays || ROLLING7_MAX_OBSERVED_LAG_DAYS),
    requiredRounds: legacyCheckpoint ? 1 : configuredRounds,
    allowLegacyApiError: legacyCheckpoint
  });
}

function publicRolling7State(state) {
  if (!state) return emptyPublicRolling7State();
  const stats = rolling7.getStats(state);
  const probe = state.unavailableTailProbe && typeof state.unavailableTailProbe === "object"
    ? state.unavailableTailProbe
    : null;
  const probing = state.queueStatus === "running"
    && probe
    && Number(probe.observedRounds || 0) < Number(probe.requiredRounds || 0);
  const reportReady = state.queueStatus === "completed"
    && stats.totalTaskCount > 0
    && stats.completedTaskCount === stats.totalTaskCount
    && stats.missingTaskCount === 0
    && stats.conflictTaskCount === 0
    && stats.boundaryMismatchTaskCount === 0
    && stats.failedTaskCount === 0;
  return {
    status: probing ? "retrying" : stats.queueStatus,
    queueStatus: stats.queueStatus,
    total: stats.totalTaskCount,
    completed: stats.completedTaskCount,
    missing: stats.missingTaskCount,
    conflicts: stats.conflictTaskCount,
    boundaryMismatches: stats.boundaryMismatchTaskCount,
    failed: stats.failedTaskCount,
    retrying: stats.retryingTaskCount,
    currentDate: stats.currentDate,
    estimatedRemainingMs: stats.estimatedRemainingMs,
    progress: stats.progressPercent,
    reportReady,
    availability: probe ? {
      targetDate: String(probe.targetDate || ""),
      lastAvailableWindowDate: String(probe.lastAvailableWindowDate || ""),
      observedLagDays: Number.isInteger(Number(probe.observedLagDays)) ? Number(probe.observedLagDays) : null,
      observedRounds: Number(probe.observedRounds || 0),
      requiredRounds: Number(probe.requiredRounds || 0),
      remainingRounds: Math.max(0, Number(probe.requiredRounds || 0) - Number(probe.observedRounds || 0))
    } : state.tailClosure ? {
      targetDate: "",
      lastAvailableWindowDate: String(state.tailClosure.lastAvailableWindowDate || ""),
      observedLagDays: Number.isInteger(Number(state.tailClosure.observedLagDays)) ? Number(state.tailClosure.observedLagDays) : null,
      observedRounds: Number(state.tailClosure.observedRounds || 0),
      requiredRounds: Number(state.tailClosure.requiredRounds || 0),
      remainingRounds: 0
    } : null,
    tailClosure: state.tailClosure && typeof state.tailClosure === "object" ? {
      requestedAnalysisEndDate: String(state.tailClosure.requestedAnalysisEndDate || ""),
      effectiveAnalysisEndDate: String(state.tailClosure.effectiveAnalysisEndDate || ""),
      lastAvailableWindowDate: String(state.tailClosure.lastAvailableWindowDate || ""),
      omittedTaskCount: Number(state.tailClosure.omittedTaskCount || 0),
      observedRounds: Number(state.tailClosure.observedRounds || 0),
      requiredRounds: Number(state.tailClosure.requiredRounds || 0),
      observedLagDays: Number.isInteger(Number(state.tailClosure.observedLagDays)) ? Number(state.tailClosure.observedLagDays) : null
    } : null,
    archive: state.archive && typeof state.archive === "object" ? {
      status: String(state.archive.status || ""),
      archived: state.archive.archived === true,
      reportId: String(state.archive.reportId || ""),
      reportUrl: String(state.archive.reportUrl || ""),
      error: String(state.archive.error || "")
    } : null,
    error: state.lastError?.message || "",
    errorCode: state.lastError?.code || "",
    config: {
      cateId: state.cateId,
      periodType: state.periodType,
      analysisStart: state.requestedAnalysisRange?.startDate || state.analysisRange?.startDate || "",
      analysisEnd: state.requestedAnalysisRange?.endDate || state.analysisRange?.endDate || "",
      effectiveAnalysisEnd: state.analysisRange?.endDate || "",
      queryStart: state.queryRange?.startDate || "",
      queryEnd: state.queryRange?.endDate || ""
    }
  };
}

async function broadcastRolling7(state) {
  try {
    await chrome.runtime.sendMessage({
      type: "DMP_ROLLING7_PROGRESS",
      state: publicRolling7State(state)
    });
  } catch {
    // Popup is normally closed while the queue runs; persisted state remains authoritative.
  }
}

async function syncRolling7Alarm(state) {
  if (!chrome.alarms) return;
  try {
    if (state?.queueStatus === "running") {
      await chrome.alarms.create(ROLLING7_ALARM_NAME, { delayInMinutes: ROLLING7_ALARM_DELAY_MINUTES });
    } else {
      await chrome.alarms.clear(ROLLING7_ALARM_NAME);
    }
  } catch {
    // The in-flight worker loop still proceeds; the alarm is only a MV3 wake-up checkpoint.
  }
}

async function readPersistedRolling7State() {
  if (rolling7IgnorePersistedState) return null;
  const stored = await chrome.storage.local.get(ROLLING7_STATE_KEY);
  const snapshot = stored[ROLLING7_STATE_KEY];
  if (!snapshot) return null;
  return rolling7.createCheckpoint(snapshot);
}

async function persistRolling7State(state) {
  const checkpoint = rolling7.createCheckpoint(state);
  const dataset = rolling7.buildDataset(checkpoint);
  rolling7.assertSensitiveFree(checkpoint);
  rolling7.assertSensitiveFree(dataset);
  await chrome.storage.local.set({
    [ROLLING7_STATE_KEY]: checkpoint,
    [ROLLING7_DATASET_KEY]: dataset
  });
  if (rolling7DatasetIsReady(dataset) && rolling7HtmlWriter?.buildHtml) {
    const html = rolling7HtmlWriter.buildHtml(dataset);
    rolling7.assertSensitiveFree(html);
    await chrome.storage.local.set({ [ROLLING7_HTML_KEY]: html });
  } else {
    await chrome.storage.local.set({ [ROLLING7_HTML_KEY]: null });
  }
  rolling7IgnorePersistedState = false;
  rolling7State = checkpoint;
  await syncRolling7Alarm(checkpoint);
  await broadcastRolling7(checkpoint);
  return checkpoint;
}

function mutateRolling7State(mutator) {
  const operation = rolling7MutationTail
    .catch(() => {})
    .then(async () => {
      if (!rolling7State) rolling7State = await readPersistedRolling7State();
      const next = await mutator(rolling7State);
      if (!next) return rolling7State;
      return persistRolling7State(next);
    });
  rolling7MutationTail = operation.then(() => undefined, () => undefined);
  return operation;
}

async function currentRolling7State() {
  await rolling7MutationTail.catch(() => {});
  if (!rolling7State) rolling7State = await readPersistedRolling7State();
  return rolling7State;
}

async function ensureRolling7Initialized() {
  if (rolling7InitializationPromise) return rolling7InitializationPromise;
  rolling7InitializationPromise = (async () => {
    try {
      const snapshot = await readPersistedRolling7State();
      rolling7LoadError = null;
      rolling7IgnorePersistedState = false;
      if (!snapshot) return null;
      const interrupted = Boolean(snapshot.currentTaskId)
        || snapshot.tasks.some(task => task.status === "running");
      const restored = interrupted
        ? rolling7.restoreQueueState(snapshot, { autoResume: snapshot.queueStatus === "running" })
        : snapshot;
      return persistRolling7State(migrateUnavailableRolling7Tail(restored));
    } catch (error) {
      rolling7LoadError = rolling7SafeError(error, "本地滚动7天断点无效，未自动继续");
      rolling7IgnorePersistedState = true;
      rolling7State = null;
      return null;
    }
  })();
  return rolling7InitializationPromise;
}

function normalizeDraftValue(value) {
  const text = String(value ?? "").trim();
  if (!/^\d{0,20}$/.test(text)) {
    const error = new Error("商品 ID 草稿只能包含数字且不超过 20 位");
    error.code = "INVALID_DRAFT";
    throw error;
  }
  return text;
}

function normalizeDraft(input) {
  return {
    subjectItemId: normalizeDraftValue(input?.subjectItemId),
    successItemId: normalizeDraftValue(input?.successItemId),
    savedAt: new Date().toISOString()
  };
}

function saveDraft(input) {
  const draft = normalizeDraft(input);
  draftWriteTail = draftWriteTail
    .catch(() => {})
    .then(async () => {
      await chrome.storage.local.set({ [DRAFT_KEY]: draft });
      return draft;
    });
  return draftWriteTail;
}

async function readDraftAfterPendingWrites() {
  await draftWriteTail.catch(() => {});
  const stored = await chrome.storage.local.get(DRAFT_KEY);
  return Object.prototype.hasOwnProperty.call(stored, DRAFT_KEY)
    ? normalizeDraft(stored[DRAFT_KEY])
    : null;
}

function publicJob(job) {
  if (!job) return null;
  return {
    id: job.id,
    subjectItemId: job.subjectItemId,
    successItemId: job.successItemId,
    status: job.status,
    statusLabel: job.statusLabel,
    step: job.step,
    progress: job.progress,
    startedAt: job.startedAt,
    finishedAt: job.finishedAt || "",
    period: job.period || null,
    latestDay: job.latestDay || "",
    recordCount: Number(job.recordCount || 0),
    sceneCount: Number(job.sceneCount || 0),
    sceneMissed: Array.isArray(job.sceneMissed) ? job.sceneMissed : [],
    warnings: Array.isArray(job.warnings) ? job.warnings : [],
    error: job.error || "",
    errorCode: job.errorCode || ""
  };
}

async function readSanjieSessions() {
  const queries = [
    ...OFFICIAL_COOKIE_URLS.map(url => ({ url, name: SANJIE_SESSION_COOKIE })),
    { domain: "shaozhuangai.com", name: SANJIE_SESSION_COOKIE }
  ];
  const settled = await Promise.allSettled(queries.map(query => chrome.cookies.getAll(query)));
  const nowSeconds = Date.now() / 1000;
  const values = [];
  const seen = new Set();
  for (const result of settled) {
    if (result.status !== "fulfilled") continue;
    for (const cookie of result.value || []) {
      const value = String(cookie?.value || "");
      if (!value || seen.has(value) || (cookie.expirationDate && Number(cookie.expirationDate) <= nowSeconds)) continue;
      seen.add(value);
      values.push(value);
    }
  }
  return values;
}

let activeSanjieSession = "";

async function readSanjieSession() {
  const sessions = await readSanjieSessions();
  return sessions.includes(activeSanjieSession) ? activeSanjieSession : sessions[0] || "";
}

let officialAuthCache = { expiresAt: 0, result: null };
const OFFICIAL_LAUNCH_KEY_PREFIX = "dmpOfficialReportLaunchV1:";
const OFFICIAL_FRAME_KEY_PREFIX = "dmpOfficialReportFrameV1:";
const ROLLING7_REPORT_FRAME_KEY_PREFIX = "dmpMarketRolling7ReportFrameV1:";

function officialLocalFallbackUrl(launchNonce) {
  return `${core.SANJIE_ORIGIN}/tools/dmp-report?source=dmp-extension#launch=${encodeURIComponent(launchNonce)}`;
}

function officialArchivedReportUrl(value) {
  return normalizeOfficialReportUrl(value, core.SANJIE_ORIGIN);
}

async function openOfficialArchivedReport(value) {
  const reportUrl = officialArchivedReportUrl(value);
  if (!reportUrl) {
    const error = new Error("官网报告链接无效");
    error.code = "SANJIE_REPORT_URL_INVALID";
    throw error;
  }
  const tab = await chrome.tabs.create({ url: reportUrl });
  return { reportUrl, tabId: tab?.id || null };
}

function createLaunchNonce() {
  const bytes = new Uint8Array(24);
  crypto.getRandomValues(bytes);
  return [...bytes].map(value => value.toString(16).padStart(2, "0")).join("");
}

function officialNonceKey(prefix, nonce) {
  return `${prefix}${nonce}`;
}

async function readOfficialNonce(prefix, nonce) {
  const key = officialNonceKey(prefix, nonce);
  const stored = await chrome.storage.session.get(key);
  return stored[key] || null;
}

async function writeOfficialNonce(prefix, nonce, value) {
  const key = officialNonceKey(prefix, nonce);
  await chrome.storage.session.set({ [key]: value });
}

async function deleteOfficialNonce(prefix, nonce) {
  await chrome.storage.session.remove(officialNonceKey(prefix, nonce));
}

async function cleanupOfficialLaunches(now = Date.now()) {
  const stored = await chrome.storage.session.get(null);
  const expired = Object.entries(stored)
    .filter(([key, value]) => (key.startsWith(OFFICIAL_LAUNCH_KEY_PREFIX)
      || key.startsWith(OFFICIAL_FRAME_KEY_PREFIX)
      || key.startsWith(ROLLING7_REPORT_FRAME_KEY_PREFIX))
      && (!value || Number(value.expiresAt || 0) <= now))
    .map(([key]) => key);
  if (expired.length) await chrome.storage.session.remove(expired);
}

function isOfficialSiteOrigin(value) {
  try {
    const parsed = new URL(String(value || ""));
    return parsed.protocol === "https:"
      && (parsed.hostname === "shaozhuangai.com" || parsed.hostname === "www.shaozhuangai.com");
  } catch {
    return false;
  }
}

function isOfficialLocalReportPage(value) {
  try {
    const parsed = new URL(String(value || ""));
    return isOfficialSiteOrigin(parsed.origin)
      && parsed.pathname === "/tools/dmp-report"
      && parsed.searchParams.get("source") === "dmp-extension";
  } catch {
    return false;
  }
}

async function prepareOfficialReportFrame(message, sender) {
  await cleanupOfficialLaunches();
  const nonce = String(message?.launchNonce || "");
  const launch = await readOfficialNonce(OFFICIAL_LAUNCH_KEY_PREFIX, nonce);
  const senderUrl = sender?.url || sender?.tab?.url || "";
  if (!/^[a-f0-9]{48}$/.test(nonce)
    || !launch
    || launch.used
    || launch.expiresAt <= Date.now()
    || sender?.id !== chrome.runtime.id
    || Number(sender?.frameId || 0) !== 0
    || !isOfficialSiteOrigin(sender?.origin)
    || !isOfficialLocalReportPage(senderUrl)
    || !isOfficialLocalReportPage(sender?.tab?.url)
    || (launch.tabId != null && Number(sender?.tab?.id) !== Number(launch.tabId))) {
    throw new Error("报告打开凭证已失效，请从扩展重新打开");
  }
  await writeOfficialNonce(OFFICIAL_LAUNCH_KEY_PREFIX, nonce, {
    ...launch,
    tabId: launch.tabId == null ? sender.tab.id : launch.tabId,
    used: true
  });
  requireOfficialSiteAccess(await checkOfficialSiteAccess(true));
  const state = await readLocalState();
  if (!isArchivableStoredReport(state.report)) {
    throw new Error("本机没有可归档的 HTML 报告");
  }
  const frameNonce = createLaunchNonce();
  await writeOfficialNonce(OFFICIAL_FRAME_KEY_PREFIX, frameNonce, {
    tabId: sender.tab.id,
    expiresAt: Date.now() + OFFICIAL_LAUNCH_TTL_MS
  });
  await deleteOfficialNonce(OFFICIAL_LAUNCH_KEY_PREFIX, nonce);
  return { ok: true, frameUrl: `${chrome.runtime.getURL("direct-report.html")}#frame=${frameNonce}` };
}

function isDirectReportFrame(value) {
  try {
    const parsed = new URL(String(value || ""));
    return parsed.protocol === "chrome-extension:" && parsed.pathname === "/direct-report.html";
  } catch {
    return false;
  }
}

function isRolling7ReportPage(value) {
  try {
    const parsed = new URL(String(value || ""));
    return parsed.protocol === "chrome-extension:"
      && parsed.hostname === chrome.runtime.id
      && parsed.pathname === "/rolling7-report.html";
  } catch {
    return false;
  }
}

function rolling7DatasetIsReady(dataset) {
  const quality = dataset?.completeness || {};
  const countFields = ["expectedTaskCount", "completedTaskCount", "missingTaskCount", "conflictTaskCount", "boundaryMismatchCount", "unexpectedWindowCount"];
  if (countFields.some(field => !Number.isInteger(quality[field]) || quality[field] < 0)) return false;
  const expected = quality.expectedTaskCount;
  return dataset?.schemaVersion === rolling7.DATASET_SCHEMA_VERSION
    && dataset?.kind === "dataset"
    && quality.status === "ready"
    && expected > 0
    && quality.completedTaskCount === expected
    && quality.missingTaskCount === 0
    && quality.conflictTaskCount === 0
    && quality.boundaryMismatchCount === 0
    && quality.unexpectedWindowCount === 0
    && Array.isArray(dataset.windows)
    && dataset.windows.length === expected;
}

async function readStoredRolling7Dataset() {
  const stored = await chrome.storage.local.get(ROLLING7_DATASET_KEY);
  const dataset = stored[ROLLING7_DATASET_KEY];
  rolling7.assertSensitiveFree(dataset);
  if (!rolling7DatasetIsReady(dataset)) {
    const error = new Error("滚动7天数据尚未完整闭合，不能生成完整 HTML 报告");
    error.code = "ROLLING7_REPORT_NOT_READY";
    throw error;
  }
  return dataset;
}

async function readStoredRolling7Html(dataset) {
  if (!rolling7HtmlWriter?.buildHtml) throw new Error("滚动7天 HTML 报告模块未就绪");
  const stored = await chrome.storage.local.get(ROLLING7_HTML_KEY);
  const current = stored[ROLLING7_HTML_KEY];
  const expected = rolling7HtmlWriter.buildHtml(dataset);
  rolling7.assertSensitiveFree(expected);
  if (current === expected) {
    rolling7.assertSensitiveFree(current);
    return current;
  }
  await chrome.storage.local.set({ [ROLLING7_HTML_KEY]: expected });
  return expected;
}

async function openRolling7StoredReport() {
  await cleanupOfficialLaunches();
  await readStoredRolling7Dataset();
  const frameNonce = createLaunchNonce();
  await writeOfficialNonce(ROLLING7_REPORT_FRAME_KEY_PREFIX, frameNonce, {
    tabId: null,
    expiresAt: Date.now() + OFFICIAL_LAUNCH_TTL_MS
  });
  try {
    const tab = await chrome.tabs.create({ url: `${chrome.runtime.getURL("rolling7-report.html")}#frame=${frameNonce}` });
    return { ok: true, tabId: tab?.id || null };
  } catch (error) {
    await deleteOfficialNonce(ROLLING7_REPORT_FRAME_KEY_PREFIX, frameNonce);
    throw error;
  }
}

async function readRolling7FrameReport(message, sender) {
  await cleanupOfficialLaunches();
  const nonce = String(message?.frameNonce || "");
  const frame = await readOfficialNonce(ROLLING7_REPORT_FRAME_KEY_PREFIX, nonce);
  if (!/^[a-f0-9]{48}$/.test(nonce)
    || !frame
    || frame.expiresAt <= Date.now()
    || sender?.id !== chrome.runtime.id
    || Number(sender?.frameId || 0) !== 0
    || !isRolling7ReportPage(sender?.url)
    || (frame.tabId != null && Number(sender?.tab?.id) !== Number(frame.tabId))) {
    throw new Error("滚动报告读取凭证已失效，请从扩展重新打开");
  }
  await deleteOfficialNonce(ROLLING7_REPORT_FRAME_KEY_PREFIX, nonce);
  const dataset = await readStoredRolling7Dataset();
  return { ok: true, dataset, html: await readStoredRolling7Html(dataset) };
}

async function readOfficialFrameReport(message, sender) {
  await cleanupOfficialLaunches();
  const nonce = String(message?.frameNonce || "");
  const frame = await readOfficialNonce(OFFICIAL_FRAME_KEY_PREFIX, nonce);
  if (!/^[a-f0-9]{48}$/.test(nonce)
    || !frame
    || frame.expiresAt <= Date.now()
    || sender?.id !== chrome.runtime.id
    || Number(sender?.frameId) <= 0
    || Number(sender?.tab?.id) !== Number(frame.tabId)
    || !isDirectReportFrame(sender?.url)
    || !isOfficialLocalReportPage(sender?.tab?.url)) {
    throw new Error("报告读取凭证已失效，请从扩展重新打开");
  }
  await deleteOfficialNonce(OFFICIAL_FRAME_KEY_PREFIX, nonce);
  requireOfficialSiteAccess(await checkOfficialSiteAccess(true));
  const state = await readLocalState();
  if (!isArchivableStoredReport(state.report)) {
    throw new Error("本机没有可归档的 HTML 报告");
  }
  return { ok: true, report: state.report };
}

async function checkOfficialSiteAccess(force = false) {
  const now = Date.now();
  if (!force && officialAuthCache.result?.ok && officialAuthCache.expiresAt > now) {
    return structuredClone(officialAuthCache.result);
  }
  const tokens = await readSanjieSessions();
  if (!tokens.length) {
    return { ok: false, reason: "nologin", error: "请先登录 shaozhuangai.com，再使用达摩盘自动化" };
  }
  for (const token of tokens) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), OFFICIAL_AUTH_TIMEOUT_MS);
    try {
      const response = await fetch(`${core.SANJIE_ORIGIN}/api/auth/me`, {
        method: "GET",
        headers: { "x-sanjie-session": token },
        cache: "no-store",
        credentials: "omit",
        redirect: "error",
        signal: controller.signal
      });
      const result = await response.json().catch(() => ({}));
      if (response.status === 401) continue;
      if (!response.ok || !result?.data) {
        return {
          ok: false,
          reason: "unavailable",
          error: `官网在线校验失败（HTTP ${response.status}）`
        };
      }
      activeSanjieSession = token;
      const entitlement = result.data.dmpEntitlement || null;
      if (result.data.service?.online !== true || result.data.capabilities?.dmpAutomation !== true) {
        const expired = entitlement?.status === "expired";
        return {
          ok: false,
          reason: expired ? "expired" : "denied",
          error: expired
            ? "达摩盘自动化的 30 天授权已到期，请联系管理员付费续费"
            : "当前官网账号未开通达摩盘自动化权限，请联系管理员付费开通"
        };
      }
      const verified = {
        ok: true,
        checkedAt: result.data.service?.checkedAt || new Date().toISOString(),
        entitlement: {
          status: String(entitlement?.status || "active"),
          expiresAt: String(entitlement?.expiresAt || ""),
          remainingDays: Number(entitlement?.remainingDays || 0)
        }
      };
      officialAuthCache = { result: verified, expiresAt: now + OFFICIAL_AUTH_CACHE_MS };
      return structuredClone(verified);
    } catch (error) {
      return {
        ok: false,
        reason: "offline",
        error: error?.name === "AbortError" ? "官网在线校验超时，插件已停止运行" : "官网暂时不可达，插件已停止运行"
      };
    } finally {
      clearTimeout(timeout);
    }
  }
  return { ok: false, reason: "invalid", error: "官网登录已失效，请重新登录 shaozhuangai.com" };
}

function requireOfficialSiteAccess(result) {
  if (result?.ok) return result;
  const error = new Error(result?.error || "shaozhuangai.com 授权核验未通过");
  error.code = `OFFICIAL_AUTH_${String(result?.reason || "FAILED").toUpperCase()}`;
  throw error;
}

function sanjieComparableReport(report) {
  const renderData = core.sanitizeRenderData(report?.render_data);
  if (renderData) delete renderData.generated_at;
  return JSON.stringify({
    schema_version: String(report?.schema_version || ""),
    item_id: String(report?.item_id || ""),
    period: String(report?.period || ""),
    render_data: renderData,
    tables: Array.isArray(report?.tables) ? report.tables.map(table => ({
      name: String(table?.name || ""),
      columns: Array.isArray(table?.columns) ? table.columns.map(String) : [],
      rows: Array.isArray(table?.rows) ? table.rows.map(row => ({ cells: Array.isArray(row?.cells) ? row.cells.map(String) : [] })) : []
    })) : []
  });
}

function archiveReportQuality(report) {
  return report?.quality?.complete === true
    && report?.quality?.exportAllowed === true
    && report?.quality?.status === "ready"
    && Number(report?.quality?.failedRecords || 0) === 0
    ? "complete"
    : "partial";
}

function archiveFingerprintHash(value) {
  let left = 0x811c9dc5;
  let right = 0x9e3779b9;
  const text = String(value || "");
  for (let index = 0; index < text.length; index += 1) {
    const code = text.charCodeAt(index);
    left ^= code;
    left = Math.imul(left, 0x01000193) >>> 0;
    right ^= code + index;
    right = Math.imul(right, 0x85ebca6b) >>> 0;
  }
  return `${left.toString(16).padStart(8, "0")}${right.toString(16).padStart(8, "0")}`;
}

function archiveOutboxFingerprint(report, context = {}) {
  const ids = storedReportArchiveIds({
    report,
    lastConfig: context.lastConfig,
    job: context.job
  });
  const canonical = reportEngine.toCanonicalReport(report);
  const period = report?.period || context.job?.period || null;
  const sourceShop = core.sanitizeSourceShop(context.sourceShop || context.job?.sourceShop);
  const fingerprint = archiveFingerprintHash(JSON.stringify({
    subjectItemId: ids.subjectItemId,
    successItemId: ids.successItemId,
    period,
    sourceShopIdentity: sourceShop?.sourceShopId || sourceShop?.shopName || "",
    report: sanjieComparableReport(canonical)
  }));
  return { ids, fingerprint, period, sourceShop };
}

function archiveOutboxEntry(state, report = state?.report, job = state?.job, sanjie = state?.sanjie) {
  const identity = archiveOutboxFingerprint(report, {
    lastConfig: state?.lastConfig,
    job,
    sourceShop: state?.sourceShop
  });
  const now = new Date().toISOString();
  const outbox = normalizeArchiveOutbox(state?.archiveOutbox);
  const existingIndex = outbox.findIndex(entry => entry?.fingerprint === identity.fingerprint);
  if (existingIndex < 0 && outbox.length >= ARCHIVE_OUTBOX_LIMIT) {
    const error = new Error(`本地待归档报告已达 ${ARCHIVE_OUTBOX_LIMIT} 份，请联网登录官网完成补传后再开始新任务`);
    error.code = "ARCHIVE_OUTBOX_FULL";
    throw error;
  }
  const existing = existingIndex >= 0 ? outbox[existingIndex] : null;
  const sequence = existing?.sequence || outbox.reduce((maximum, entry) => Math.max(maximum, Number(entry?.sequence || 0)), 0) + 1;
  const entry = {
    id: existing?.id || `growth-${identity.fingerprint}`,
    fingerprint: identity.fingerprint,
    sequence,
    queuedAt: existing?.queuedAt || now,
    updatedAt: now,
    lastConfig: identity.ids,
    period: identity.period,
    sourceShop: identity.sourceShop,
    report,
    job: publicJob(job),
    sanjie: sanjie && typeof sanjie === "object" ? { ...sanjie } : null,
    attempts: Number(existing?.attempts || 0)
  };
  if (existingIndex >= 0) outbox[existingIndex] = entry;
  else outbox.push(entry);
  state.archiveOutbox = outbox;
  return entry;
}

function archiveEntryIndex(state, fingerprint) {
  return normalizeArchiveOutbox(state?.archiveOutbox)
    .findIndex(entry => entry?.fingerprint === fingerprint);
}

function updateArchiveOutboxEntry(state, fingerprint, updates) {
  const outbox = normalizeArchiveOutbox(state?.archiveOutbox);
  const index = outbox.findIndex(entry => entry?.fingerprint === fingerprint);
  if (index < 0) return null;
  outbox[index] = {
    ...outbox[index],
    ...updates,
    updatedAt: new Date().toISOString()
  };
  state.archiveOutbox = outbox;
  return outbox[index];
}

function removeArchiveOutboxEntry(state, fingerprint) {
  const outbox = normalizeArchiveOutbox(state?.archiveOutbox);
  state.archiveOutbox = outbox.filter(entry => entry?.fingerprint !== fingerprint);
}

function sortedArchiveOutbox(state) {
  return normalizeArchiveOutbox(state?.archiveOutbox)
    .filter(entry => isArchivableStoredReport(entry?.report))
    .slice()
    .sort((left, right) => String(left?.queuedAt || "").localeCompare(String(right?.queuedAt || ""))
      || Number(left?.sequence || 0) - Number(right?.sequence || 0));
}

function currentArchiveFingerprint(state) {
  if (!isArchivableStoredReport(state?.report)) return "";
  try {
    return archiveOutboxFingerprint(state.report, state).fingerprint;
  } catch {
    return "";
  }
}

async function ensureCurrentReportQueued(state) {
  if (!isArchivableStoredReport(state?.report) || isArchivedSanjieState(state?.sanjie)) return null;
  const entry = archiveOutboxEntry(state, state.report, state.job, state.sanjie);
  await writeLocalState(state);
  return entry;
}

async function requestSanjie(token, method, body = "") {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), SANJIE_IMPORT_TIMEOUT_MS);
  try {
    const response = await fetch(`${core.SANJIE_ORIGIN}/api/dmp-reports`, {
      method,
      headers: {
        ...(body ? { "Content-Type": "application/json" } : {}),
        "x-sanjie-session": token
      },
      cache: "no-store",
      credentials: "omit",
      redirect: "error",
      body: body || undefined,
      signal: controller.signal
    });
    const result = await response.json().catch(() => ({}));
    return { response, result };
  } catch (error) {
    const wrapped = new Error(error?.name === "AbortError" ? "官网报告归档超时" : "官网报告中心暂时不可用");
    wrapped.code = error?.name === "AbortError" ? "SANJIE_TIMEOUT" : "SANJIE_UNAVAILABLE";
    wrapped.archivePhase = method === "POST" ? "post" : "lookup";
    throw wrapped;
  } finally {
    clearTimeout(timeout);
  }
}

function marketComparableReport(report) {
  return JSON.stringify({
    schema_version: String(report?.schema_version || ""),
    report_type: String(report?.report_type || ""),
    period: String(report?.period || ""),
    market_scope: report?.market_scope || null,
    tables: Array.isArray(report?.tables) ? report.tables.map(table => ({
      name: String(table?.name || ""),
      columns: Array.isArray(table?.columns) ? table.columns.map(String) : [],
      rows: Array.isArray(table?.rows) ? table.rows.map(row => ({ cells: Array.isArray(row?.cells) ? row.cells.map(String) : [] })) : []
    })) : []
  });
}

function archiveCandidateMatchesSourceShop(candidate, payload) {
  const expected = core.sanitizeSourceShop(payload?.sourceShop);
  if (!expected) return true;
  // GET /api/dmp-reports returns the website's internal shopId. The numeric
  // sourceShopId captured from DMP is an external seller/shop identity and must
  // never be compared with that internal relation id. Without a visible shop
  // name there is no safe reconciliation key, so retry by POST and let the
  // website resolve the tenant/store relationship.
  if (!expected.shopName) return false;
  const clean = value => String(value || "")
    .normalize("NFKC")
    .replace(/[\u0000-\u001f\u007f]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .toLocaleLowerCase();
  return clean(candidate?.shopName) === clean(expected.shopName);
}

async function importMarketReportToSanjie(report, options = {}) {
  const token = await readSanjieSession();
  if (!token) {
    const error = new Error("请先登录 shaozhuangai.com，完整大盘报告已保留在本机");
    error.code = "SANJIE_LOGIN_REQUIRED";
    error.archivePhase = "auth";
    throw error;
  }
  const payload = core.sanjieMarketImportPayload(
    report,
    chrome.runtime.getManifest().version,
    "complete",
    options.sourceShop
  );
  const body = JSON.stringify(payload);
  if (new TextEncoder().encode(body).byteLength > 2 * 1024 * 1024) {
    const error = new Error("大盘报告超过官网归档上限");
    error.code = "SANJIE_REPORT_TOO_LARGE";
    error.archivePhase = "validation";
    throw error;
  }
  if (options.reconcileFirst === true) {
    const listed = await requestSanjie(token, "GET");
    if (listed.response.ok && Array.isArray(listed.result?.data?.reports)) {
      const comparable = marketComparableReport(payload.report);
      const existing = listed.result.data.reports.find(candidate =>
        marketComparableReport(candidate?.report) === comparable
        && archiveCandidateMatchesSourceShop(candidate, payload));
      const existingUrl = officialArchivedReportUrl(core.sanjieReportUrl(existing?.id));
      if (existing?.id && existingUrl) return {
        ok: true,
        reportId: String(existing.id),
        reportUrl: existingUrl,
        savedAt: String(existing.createdAt || new Date().toISOString()),
        reused: true
      };
    }
  }
  const { response, result } = await requestSanjie(token, "POST", body);
  const saved = result?.data?.report;
  const reportUrl = officialArchivedReportUrl(core.sanjieReportUrl(saved?.id));
  if (!response.ok || !saved?.id || !reportUrl) {
    const error = new Error(response.status === 401
      ? "官网登录已失效，大盘报告已保留在本机"
      : result?.error || `官网大盘报告归档失败（HTTP ${response.status}）`);
    error.code = response.status === 401
      ? "SANJIE_LOGIN_REQUIRED"
      : response.status >= 500 || [408, 425, 429].includes(response.status)
        ? "SANJIE_UNAVAILABLE"
        : response.ok ? "SANJIE_IMPORT_UNCERTAIN" : "SANJIE_REPORT_REJECTED";
    error.archivePhase = response.status === 401
      ? "auth"
      : response.status >= 400 && response.status < 500 ? "validation" : "post";
    throw error;
  }
  return { ok: true, reportId: String(saved.id), reportUrl, savedAt: String(saved.createdAt || new Date().toISOString()) };
}

async function synchronizeStoredRolling7Report(trigger = "worker-wake") {
  const state = await currentRolling7State();
  const publicState = publicRolling7State(state);
  if (!state || !publicState.reportReady || !rolling7HtmlWriter?.buildArchiveReport) return { ok: false, skipped: "not-ready" };
  const dataset = rolling7.buildDataset(state);
  if (!/[\u3400-\u9fff]/u.test(String(dataset.categoryName || "").trim())
    || !Array.isArray(dataset.categoryPath)
    || !dataset.categoryPath.some(value => String(value || "").trim())) {
    return { ok: false, skipped: "category-metadata-missing" };
  }
  const report = rolling7HtmlWriter.buildArchiveReport(dataset);
  const sourceShop = core.sanitizeSourceShop(state.sourceShop);
  const fingerprint = archiveFingerprintHash(JSON.stringify({
    sourceShopIdentity: sourceShop?.sourceShopId || sourceShop?.shopName || "",
    report: marketComparableReport(report)
  }));
  if (state.archive?.status === "archived" && state.archive?.fingerprint === fingerprint && state.archive?.reportUrl) {
    return { ok: true, skipped: "already-archived", ...state.archive };
  }
  const reconcileFirst = state.archive?.errorPhase === "post" && state.archive?.fingerprint === fingerprint;
  await mutateRolling7State(current => current ? {
    ...current,
    archive: {
      status: "archiving",
      archived: false,
      fingerprint,
      trigger: String(trigger || ""),
      startedAt: new Date().toISOString(),
      error: "",
      errorCode: "",
      errorPhase: ""
    }
  } : null);
  try {
    const saved = await importMarketReportToSanjie(report, { reconcileFirst, sourceShop });
    const archived = {
      status: "archived",
      archived: true,
      fingerprint,
      reportId: saved.reportId,
      reportUrl: saved.reportUrl,
      savedAt: saved.savedAt,
      reused: saved.reused === true,
      error: "",
      errorCode: "",
      errorPhase: ""
    };
    await mutateRolling7State(current => current ? { ...current, archive: archived } : null);
    return { ok: true, ...archived };
  } catch (error) {
    const safe = rolling7SafeError(error, "官网大盘报告未归档，本机报告已保留");
    const failed = {
      status: "failed",
      archived: false,
      fingerprint,
      error: safe.message,
      errorCode: String(error?.code || safe.code || "SANJIE_IMPORT_FAILED"),
      errorPhase: String(error?.archivePhase || "unknown"),
      failedAt: new Date().toISOString()
    };
    await mutateRolling7State(current => current ? { ...current, archive: failed } : null);
    return { ok: false, ...failed };
  }
}

function scheduleStoredRolling7Archive(trigger = "worker-wake") {
  if (rolling7ArchivePromise) return rolling7ArchivePromise;
  rolling7ArchivePromise = synchronizeStoredRolling7Report(trigger)
    .finally(() => { rolling7ArchivePromise = null; });
  return rolling7ArchivePromise;
}

function findExistingSanjieReport(payload, reports) {
  const comparable = sanjieComparableReport(payload.report);
  return reports.find(candidate =>
    String(candidate?.subjectItemId || "") === payload.subjectItemId
    && String(candidate?.competitorItemId || "") === payload.competitorItemId
    && archiveCandidateMatchesSourceShop(candidate, payload)
    && sanjieComparableReport(candidate?.report) === comparable
    && core.sanjieReportUrl(candidate?.id)
  );
}

async function importCanonicalReportToSanjie(canonical, job, options = {}) {
  const token = await readSanjieSession();
  if (!token) {
    const error = new Error("请先登录 shaozhuangai.com，再重新点击开始取数");
    error.code = "SANJIE_LOGIN_REQUIRED";
    throw error;
  }
  const payload = core.sanjieImportPayload(
    canonical,
    job.subjectItemId,
    job.successItemId,
    chrome.runtime.getManifest().version,
    options.quality,
    options.sourceShop
  );
  const body = JSON.stringify(payload);
  if (new TextEncoder().encode(body).byteLength > 2 * 1024 * 1024) {
    const error = new Error("最终业务报告超过官网归档上限");
    error.code = "SANJIE_REPORT_TOO_LARGE";
    throw error;
  }

  if (options.reconcileFirst === true) {
    const listed = await requestSanjie(token, "GET");
    if (listed.response.status === 401) {
      const error = new Error("官网登录已失效，请重新登录后再运行");
      error.code = "SANJIE_LOGIN_REQUIRED";
      error.archivePhase = "lookup";
      throw error;
    }
    if (!listed.response.ok || !Array.isArray(listed.result?.data?.reports)) {
      const error = new Error(listed.result?.error || `官网报告查重失败（HTTP ${listed.response.status}）`);
      error.code = "SANJIE_UNAVAILABLE";
      error.archivePhase = "lookup";
      throw error;
    }
    const existing = findExistingSanjieReport(payload, listed.result.data.reports);
    if (existing) {
      const reportUrl = officialArchivedReportUrl(core.sanjieReportUrl(existing.id));
      if (!reportUrl) {
        const error = new Error("官网报告中心返回了无效编号");
        error.code = "SANJIE_IMPORT_UNCERTAIN";
        error.archivePhase = "lookup";
        throw error;
      }
      return {
        ok: true,
        reportId: String(existing.id),
        reportUrl,
        savedAt: String(existing.createdAt || new Date().toISOString()),
        reused: true
      };
    }
  }

  const { response, result } = await requestSanjie(token, "POST", body);
  const saved = result?.data?.report;
  const reportUrl = officialArchivedReportUrl(core.sanjieReportUrl(saved?.id));
  if (!response.ok || !saved?.id || !reportUrl) {
    const error = new Error(response.status === 401
      ? "官网登录已失效，请重新登录后再运行"
      : result?.error || `官网报告归档失败（HTTP ${response.status}）`);
    error.code = response.status === 401
      ? "SANJIE_LOGIN_REQUIRED"
      : response.status >= 500 || [408, 425, 429].includes(response.status)
        ? "SANJIE_UNAVAILABLE"
        : response.ok
          ? "SANJIE_IMPORT_UNCERTAIN"
          : "SANJIE_REPORT_REJECTED";
    error.archivePhase = response.status === 401
      ? "auth"
      : response.status >= 400 && response.status < 500
        ? "validation"
        : "post";
    throw error;
  }
  return { ok: true, reportId: String(saved.id), reportUrl, savedAt: String(saved.createdAt || new Date().toISOString()) };
}

async function broadcast(job) {
  const message = { type: "DMP_DIRECT_PROGRESS", job: publicJob(job) };
  try { await chrome.runtime.sendMessage(message); } catch {}
}

async function saveProgress(state, job, step, progress, statusLabel = "运行中") {
  job.step = step;
  job.progress = Math.max(0, Math.min(100, Number(progress || 0)));
  job.statusLabel = statusLabel;
  await writeLocalState({ ...state, job: publicJob(job) });
  await broadcast(job);
}

function isDmpTab(tab) {
  try { return new URL(tab?.url || "").hostname === "dmp.taobao.com"; } catch { return false; }
}

async function findDmpTabs() {
  const [active, all] = await Promise.all([
    chrome.tabs.query({ active: true, currentWindow: true }),
    chrome.tabs.query({ url: "https://dmp.taobao.com/*" })
  ]);
  const byId = new Map();
  for (const tab of [...active.filter(isDmpTab), ...all.filter(isDmpTab)]) if (tab?.id) byId.set(tab.id, tab);
  const tabs = [...byId.values()].sort((left, right) => {
    const activeDelta = Number(Boolean(right.active)) - Number(Boolean(left.active));
    return activeDelta || Number(right.lastAccessed || 0) - Number(left.lastAccessed || 0);
  });
  if (!tabs.length) {
    const error = new Error("请先登录并保持一个达摩盘页面打开");
    error.code = "NO_DMP_TAB";
    throw error;
  }
  if (tabs.every(tab => tab.discarded || tab.frozen)) {
    const error = new Error("达摩盘页面已被 Chrome 冻结，请手动打开一次后重试");
    error.code = "TAB_UNAVAILABLE";
    throw error;
  }
  return tabs.filter(tab => !tab.discarded && !tab.frozen);
}

async function executeInMain(tabId, func, args = []) {
  const results = await chrome.scripting.executeScript({
    target: { tabId, frameIds: [0] },
    world: "MAIN",
    func,
    args
  });
  return results?.[0]?.result;
}

async function readSourceShopFromDmpTab(tabId) {
  try {
    const candidate = await executeInMain(tabId, () => {
      if (location.hostname !== "dmp.taobao.com") return null;
      const clean = (value, maximum = 80) => String(value ?? "")
        .replace(/[\u0000-\u001f\u007f]/g, " ")
        .replace(/\s+/g, " ")
        .trim()
        .slice(0, maximum);
      const ignored = /^(?:店铺|店铺名称|切换店铺|主店|本店|账号|账户|达摩盘|阿里妈妈|淘宝|天猫)$/u;
      const visible = element => {
        if (!element) return false;
        try {
          const rect = element.getBoundingClientRect();
          const style = getComputedStyle(element);
          return rect.width > 0 && rect.height > 0
            && style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0";
        } catch {
          return false;
        }
      };
      const selectors = [
        "[data-shop-name]", "[data-seller-name]", "[data-nick]",
        '[class*="shop-name"]', '[class*="shopName"]', '[class*="seller-name"]',
        '[class*="sellerName"]', '[class*="merchant-name"]', '[class*="merchantName"]',
        '[class*="account-name"]', '[class*="accountName"]', '[class*="shop-switch"]',
        '[class*="shopSwitch"]'
      ];
      const namedNodes = [...document.querySelectorAll(selectors.join(","))]
        .filter(element => {
          if (!visible(element)) return false;
          const rect = element.getBoundingClientRect();
          return rect.top >= 0 && rect.top < 220
            || Boolean(element.closest('header,[role="banner"],[class*="header"],[class*="account"],[class*="shop-switch"],[class*="shopSwitch"]'));
        })
        .map(element => ({
          element,
          name: clean(element.getAttribute("data-shop-name")
            || element.getAttribute("data-seller-name")
            || element.getAttribute("data-nick")
            || element.textContent)
        }))
        .filter(entry => entry.name.length >= 2 && !ignored.test(entry.name));
      const bodyNames = String(document.body?.innerText || "")
        .slice(0, 6000)
        .split(/\r?\n/)
        .map(value => clean(value))
        .reduce((names, value, index, lines) => {
          const inline = value.match(/^当前店铺\s*[:：]\s*(.+)$/u)?.[1] || "";
          const adjacent = /^当前店铺\s*[:：]?$/u.test(value) ? lines[index + 1] || "" : "";
          const name = clean(inline || adjacent);
          if (name.length >= 2 && name.length <= 80 && !ignored.test(name)) names.push(name);
          return names;
        }, []);
      const named = namedNodes[0] || null;
      const shopName = named?.name || bodyNames[0] || "";
      let identityNode = named?.element || null;
      let sourceShopId = "";
      for (let depth = 0; identityNode && depth < 5 && !sourceShopId; depth += 1, identityNode = identityNode.parentElement) {
        sourceShopId = ["data-shop-id", "data-seller-id", "data-user-id", "data-member-id"]
          .map(attribute => clean(identityNode.getAttribute?.(attribute), 32).replace(/\s+/g, ""))
          .find(value => /^\d{5,32}$/.test(value)) || "";
      }
      if (!shopName && !sourceShopId) return null;
      return {
        ...(sourceShopId ? { sourceShopId } : {}),
        ...(shopName ? { shopName } : {})
      };
    });
    return core.sanitizeSourceShop(candidate);
  } catch {
    return null;
  }
}

async function ensurePageApi(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId, frameIds: [0] },
    world: "MAIN",
    files: ["direct-main.js"]
  });
  const readiness = await executeInMain(tabId, (key, capability) => {
    const api = globalThis[key];
    return api?.version === 1
      && Array.isArray(api.capabilities)
      && api.capabilities.includes(capability)
      && typeof api.readiness === "function"
      ? api.readiness()
      : { ok: false, error: "滚动7天页面监听器未就绪，请重新加载测试扩展后刷新页面" };
  }, [core.PAGE_API_KEY, ROLLING7_PAGE_API_CAPABILITY]);
  if (!readiness?.ok) {
    const error = new Error(readiness?.error || "达摩盘页面监听器未就绪，请刷新页面后重试");
    error.code = "PAGE_API_UNAVAILABLE";
    throw error;
  }
  return readiness;
}

async function selectReadyDmpTab(hasStoredDatasetTemplate) {
  const tabs = await findDmpTabs();
  const candidates = [];
  const failures = [];
  for (const tab of tabs) {
    try {
      const readiness = await ensurePageApi(tab.id);
      const readyForRun = Number(readiness.requestTemplateCount || 0) > 0
        && (Boolean(readiness.hasIndexCardTemplate) || Boolean(hasStoredDatasetTemplate));
      candidates.push({ tab, readiness, readyForRun });
    } catch (error) {
      failures.push(core.safeErrorText(error));
    }
  }
  candidates.sort((left, right) => {
    const readyDelta = Number(right.readyForRun) - Number(left.readyForRun);
    const indexDelta = Number(Boolean(right.readiness.hasIndexCardTemplate)) - Number(Boolean(left.readiness.hasIndexCardTemplate));
    const countDelta = Number(right.readiness.requestTemplateCount || 0) - Number(left.readiness.requestTemplateCount || 0);
    const activeDelta = Number(Boolean(right.tab.active)) - Number(Boolean(left.tab.active));
    return readyDelta || indexDelta || countDelta || activeDelta || Number(right.tab.lastAccessed || 0) - Number(left.tab.lastAccessed || 0);
  });
  if (candidates.length) return candidates[0];
  const error = new Error(failures[0] || "达摩盘页面监听器未就绪，请刷新页面后重试");
  error.code = "PAGE_API_UNAVAILABLE";
  throw error;
}

async function requestFromPage(tabId, spec) {
  const result = await executeInMain(tabId, async (key, capability, requestSpec) => {
    const api = globalThis[key];
    if (!api || api.version !== 1
      || !Array.isArray(api.capabilities)
      || !api.capabilities.includes(capability)
      || typeof api.request !== "function") {
      return { ok: false, error: { code: "PAGE_API_UNAVAILABLE", message: "页面监听器未就绪" } };
    }
    return api.request(requestSpec);
  }, [core.PAGE_API_KEY, ROLLING7_PAGE_API_CAPABILITY, spec]);
  if (result?.record) core.assertSafeRecord(result.record);
  if (!result?.ok || !result.record) {
    const error = new Error(result?.error?.message || "达摩盘接口取数失败");
    error.code = result?.error?.code || "REQUEST_FAILED";
    if (result?.record) error.record = result.record;
    throw error;
  }
  return result.record;
}

async function selectRolling7DmpTab() {
  const tabs = await findDmpTabs();
  const candidates = [];
  const failures = [];
  for (const tab of tabs) {
    try {
      const readiness = await ensurePageApi(tab.id);
      candidates.push({ tab, readiness });
    } catch (error) {
      failures.push(rolling7SafeError(error).message);
    }
  }
  const ready = candidates
    .filter(candidate => candidate.readiness?.marketRolling7Ready === true)
    .sort((left, right) => {
      const activeDelta = Number(Boolean(right.tab.active)) - Number(Boolean(left.tab.active));
      const countDelta = Number(right.readiness.requestTemplateCount || 0) - Number(left.readiness.requestTemplateCount || 0);
      return activeDelta || countDelta || Number(right.tab.lastAccessed || 0) - Number(left.tab.lastAccessed || 0);
    });
  if (ready.length) return ready[0];
  if (candidates.length) {
    const error = new Error("请先在当前已登录达摩盘页面正常打开一次叶子类目市场，让日期范围与市场概览两个接口完成请求");
    error.code = "TEMPLATE_REQUIRED";
    throw error;
  }
  const error = new Error(failures[0] || "达摩盘页面监听器未就绪，请刷新页面后重试");
  error.code = "PAGE_API_UNAVAILABLE";
  throw error;
}

function rolling7RequestSpec(task, path) {
  return {
    path,
    method: path === rolling7.RANGE_PATH ? "GET" : "POST",
    cateId: task.cateId,
    periodType: task.periodType,
    requestDate: task.requestDate
  };
}

function rolling7TaskIsCurrent(state, task) {
  if (!state || !task || !["running", "paused"].includes(state.queueStatus)) return false;
  if (state.currentTaskId !== task.taskId
    || state.cateId !== task.cateId
    || state.periodType !== task.periodType) return false;
  return state.tasks.some(item => item.taskId === task.taskId && item.status === "running");
}

function rolling7WaitMs(state) {
  const now = Date.now();
  const candidates = [state?.nextAllowedAt, ...(state?.tasks || [])
    .filter(task => task.status === "retry-wait")
    .map(task => task.nextRetryAt)]
    .filter(Boolean)
    .map(value => new Date(value).valueOf())
    .filter(value => Number.isFinite(value) && value > now);
  const delay = candidates.length ? Math.min(...candidates) - now : 250;
  return Math.max(100, Math.min(1000, delay));
}

function sleepRolling7(milliseconds) {
  return new Promise(resolve => setTimeout(resolve, Math.max(0, Number(milliseconds) || 0)));
}

async function pauseRolling7ForError(error, taskId = null) {
  const safe = rolling7SafeError(error);
  return mutateRolling7State(state => {
    if (!state || state.queueStatus === "stopped" || state.queueStatus === "completed") return state;
    let next = state;
    if (next.queueStatus === "running") next = rolling7.pauseQueue(next);
    next = rolling7.createCheckpoint(next);
    if (taskId) {
      const task = next.tasks.find(item => item.taskId === taskId);
      if (task?.status === "running") {
        task.status = "pending";
        task.attempts = Math.max(0, Number(task.attempts || 0) - 1);
        task.lastStartedAt = null;
        task.lastFinishedAt = null;
        task.nextRetryAt = null;
        task.durationMs = null;
        task.lastError = safe;
        if (next.currentTaskId === taskId) next.currentTaskId = null;
        next.nextAllowedAt = null;
      }
    }
    next = { ...next, lastError: safe, updatedAt: new Date().toISOString() };
    rolling7.assertSensitiveFree(next);
    return next;
  });
}

async function recordRolling7Failure(taskId, error) {
  const safe = rolling7SafeError(error);
  return mutateRolling7State(state => {
    if (!state || state.queueStatus === "stopped") return state;
    let next = rolling7.recordTaskFailure(state, taskId, safe);
    if (state.queueStatus === "paused" && next.queueStatus === "running") next = rolling7.pauseQueue(next);
    return next;
  });
}

function isLegacyMarketUnavailableError(error) {
  if (String(error?.code || "") !== "API_ERROR") return false;
  const pathname = String(error?.record?.pathname || "");
  if (pathname !== rolling7.RANGE_PATH && pathname !== rolling7.OVERVIEW_PATH) return false;
  return /暂未返回可用数据|暂无数据|数据未产出/.test(String(error?.message || ""));
}

function unavailableRolling7TailOptions(state, error) {
  return {
    currentDate: rolling7CurrentDate(),
    maxLagDays: Number(state?.config?.maxObservedLagDays || ROLLING7_MAX_OBSERVED_LAG_DAYS),
    requiredRounds: Number(state?.config?.tailConfirmationRounds || ROLLING7_TAIL_CONFIRMATION_ROUNDS),
    allowLegacyApiError: isLegacyMarketUnavailableError(error)
  };
}

async function processUnavailableRolling7Tail(taskId, error) {
  let decision = "not-eligible";
  const next = await mutateRolling7State(state => {
    if (!state || state.queueStatus === "stopped" || state.queueStatus === "completed") return null;
    const options = unavailableRolling7TailOptions(state, error);
    const assessment = rolling7.assessUnavailableTail(state, taskId, error, options);
    if (!assessment.eligible) return null;
    const candidate = rolling7.finalizeUnavailableTail(state, taskId, error, options);
    const closed = candidate?.queueStatus === "completed"
      && candidate?.tailClosure?.closedAt
      && candidate.tasks.length < state.tasks.length;
    if (closed) {
      decision = "closed";
      return candidate;
    }
    decision = "retrying";
    return rolling7.recordTaskFailure(candidate, taskId, rolling7SafeError(error));
  });
  return { decision, state: next };
}

async function runRolling7Queue() {
  await ensureRolling7Initialized();
  if (rolling7Promise) return rolling7Promise;
  rolling7Promise = (async () => {
    let tabId = null;
    while (true) {
      const snapshot = await currentRolling7State();
      if (!snapshot || snapshot.queueStatus !== "running") break;

      if (!tabId) {
        try {
          const selected = await selectRolling7DmpTab();
          tabId = selected.tab.id;
          const sourceShop = await readSourceShopFromDmpTab(tabId);
          if (sourceShop) {
            await mutateRolling7State(state => state && !core.sanitizeSourceShop(state.sourceShop)
              ? { ...state, sourceShop }
              : null);
          }
        } catch (error) {
          await pauseRolling7ForError(error);
          break;
        }
      }

      let task = null;
      await mutateRolling7State(state => {
        if (!state || state.queueStatus !== "running") return null;
        const claimed = rolling7.claimNextTask(state);
        task = claimed.task;
        return task ? claimed.state : null;
      });

      if (!task) {
        const waiting = await currentRolling7State();
        if (!waiting || waiting.queueStatus !== "running") break;
        await sleepRolling7(rolling7WaitMs(waiting));
        continue;
      }

      // Yield once after claiming so a user pause/stop command can win before a new request
      // is dispatched. The identity gate below still accepts responses that were already in flight.
      await sleepRolling7(0);
      const beforeRange = await currentRolling7State();
      if (!rolling7TaskIsCurrent(beforeRange, task) || beforeRange.queueStatus !== "running") {
        if (beforeRange?.queueStatus === "running") continue;
        break;
      }

      try {
        const rangeRecord = await requestFromPage(tabId, rolling7RequestSpec(task, rolling7.RANGE_PATH));
        const rangeCapture = rolling7.sanitizeCaptureRecord(rangeRecord, { cateId: task.cateId });
        if (!rangeCapture || rangeCapture.taskId !== task.taskId) {
          const error = new Error("日期范围响应与当前滚动任务不匹配");
          error.code = "CAPTURE_MISMATCH";
          throw error;
        }
        let rangeAccepted = false;
        await mutateRolling7State(state => {
          if (!rolling7TaskIsCurrent(state, task)) return null;
          rangeAccepted = true;
          return rolling7.ingestCapture(state, rangeCapture);
        });
        if (!rangeAccepted) continue;

        const afterRange = await currentRolling7State();
        if (!rolling7TaskIsCurrent(afterRange, task)) {
          if (afterRange?.queueStatus === "running") continue;
          break;
        }
        if (afterRange.queueStatus !== "running") break;

        const overviewRecord = await requestFromPage(tabId, rolling7RequestSpec(task, rolling7.OVERVIEW_PATH));
        const overviewCapture = rolling7.sanitizeCaptureRecord(overviewRecord, { cateId: task.cateId });
        if (!overviewCapture || overviewCapture.taskId !== task.taskId) {
          const error = new Error("市场概览响应与当前滚动任务不匹配");
          error.code = "CAPTURE_MISMATCH";
          throw error;
        }
        let overviewAccepted = false;
        const afterOverview = await mutateRolling7State(state => {
          if (!rolling7TaskIsCurrent(state, task)) return null;
          overviewAccepted = true;
          return rolling7.ingestCapture(state, overviewCapture);
        });
        if (!overviewAccepted) continue;
        const finishedTask = afterOverview?.tasks?.find(item => item.taskId === task.taskId);
        if (finishedTask?.status === "running") {
          const error = new Error("两类核心响应尚未形成完整滚动窗口");
          error.code = "PAIR_INCOMPLETE";
          throw error;
        }
      } catch (error) {
        const current = await currentRolling7State();
        if (!current || current.queueStatus === "stopped") break;
        if (!rolling7TaskIsCurrent(current, task)) continue;
        const unavailableTail = await processUnavailableRolling7Tail(task.taskId, error);
        if (unavailableTail.decision === "closed") break;
        if (unavailableTail.decision === "retrying") continue;
        if (ROLLING7_BLOCKING_CODES.has(String(error?.code || ""))) {
          await pauseRolling7ForError(error, task.taskId);
          break;
        }
        await recordRolling7Failure(task.taskId, error);
        tabId = null;
      }
    }
    const finished = await currentRolling7State();
    if (publicRolling7State(finished).reportReady) {
      await synchronizeStoredRolling7Report("queue-completed").catch(() => null);
    }
    return publicRolling7State(await currentRolling7State());
  })().finally(() => {
    rolling7Promise = null;
    void currentRolling7State()
      .then(state => {
        if (state?.queueStatus === "running") void runRolling7Queue();
      })
      .catch(() => {});
  });
  return rolling7Promise;
}

function sameRolling7Config(state, input) {
  const requested = state?.requestedAnalysisRange || state?.analysisRange;
  return Boolean(state)
    && state.cateId === String(input.cateId || "").trim()
    && state.periodType === "1"
    && requested?.startDate === String(input.analysisStart || "").trim()
    && requested?.endDate === String(input.analysisEnd || "").trim();
}

async function startRolling7(input) {
  await ensureRolling7Initialized();
  const next = await mutateRolling7State(state => {
    if (state?.queueStatus === "running") {
      const error = new Error("滚动7天任务已在运行");
      error.code = "QUEUE_ALREADY_RUNNING";
      throw error;
    }
    if (sameRolling7Config(state, input) && state.queueStatus === "paused") {
      return rolling7.resumeQueue(state);
    }
    if (sameRolling7Config(state, input) && state.queueStatus === "stopped") {
      return rolling7.startQueue(state, { restartStopped: true });
    }
    const manifest = rolling7.generateManifest({
      cateId: input.cateId,
      periodType: "1",
      analysisStart: input.analysisStart,
      analysisEnd: input.analysisEnd,
      paddingDays: 6
    });
    const created = rolling7.createQueueState(manifest, {
      maxRetries: ROLLING7_MAX_RETRIES,
      retryBaseMs: ROLLING7_RETRY_BASE_MS,
      minIntervalMs: ROLLING7_MIN_INTERVAL_MS,
      tailConfirmationRounds: ROLLING7_TAIL_CONFIRMATION_ROUNDS,
      maxObservedLagDays: ROLLING7_MAX_OBSERVED_LAG_DAYS
    });
    rolling7LoadError = null;
    return rolling7.startQueue(created);
  });
  void runRolling7Queue();
  return { ok: true, state: publicRolling7State(next) };
}

async function pauseRolling7() {
  await ensureRolling7Initialized();
  const next = await mutateRolling7State(state => state ? rolling7.pauseQueue(state) : null);
  return { ok: true, state: publicRolling7State(next) };
}

async function resumeRolling7() {
  await ensureRolling7Initialized();
  const next = await mutateRolling7State(state => {
    if (!state) {
      const error = new Error("没有可继续的滚动7天断点");
      error.code = "QUEUE_NOT_FOUND";
      throw error;
    }
    return rolling7.resumeQueue(state);
  });
  void runRolling7Queue();
  return { ok: true, state: publicRolling7State(next) };
}

async function stopRolling7() {
  await ensureRolling7Initialized();
  const next = await mutateRolling7State(state => state ? rolling7.stopQueue(state) : null);
  return { ok: true, state: publicRolling7State(next) };
}

async function getRolling7ClientState() {
  await ensureRolling7Initialized();
  return { ok: true, state: publicRolling7State(await currentRolling7State()) };
}

function parseLatestDay(record) {
  const body = core.parseRecordBody(record);
  const candidates = [body?.data, body?.result?.data, body?.latestDay, body?.data?.latestDay];
  for (const value of candidates) {
    const normalized = core.normalizeDate(value);
    if (normalized) return normalized;
  }
  return "";
}

function classifyBusinessRecord(record, expectedParser) {
  const classification = completeness.classifyGrowthRecord(record);
  if (!classification || classification.status === "failed" || classification.status === "ignored") {
    const error = new Error("接口已返回，但业务结构未通过完整性检查");
    error.code = "SHAPE_MISMATCH";
    error.record = record;
    throw error;
  }
  if (expectedParser && classification.parser !== expectedParser) {
    const error = new Error("接口返回的数据类型与目标模块不一致");
    error.code = "SHAPE_MISMATCH";
    throw error;
  }
  return classification;
}

async function fetchBusinessRecord(tabId, spec, expectedParser) {
  const record = await requestFromPage(tabId, spec);
  const classification = classifyBusinessRecord(record, expectedParser);
  return { record, classification };
}

function baseSpec(job, path, method = "GET", extra = {}) {
  return {
    path,
    method,
    subjectItemId: job.subjectItemId,
    successItemId: job.successItemId,
    latestDay: job.latestDay || "",
    period: job.period || null,
    ...extra
  };
}

async function fetchSubjectDailyCards(tabId, state, job, records) {
  const dates = completeness.enumerateDates(job.period?.startDate, job.period?.endDate);
  if (dates.length !== Number(job.period?.days || 0)) {
    const error = new Error("主体逐日核心指标日期范围不完整");
    error.code = "SUBJECT_DAILY_PERIOD_INVALID";
    throw error;
  }
  const batchSize = 2;
  for (let offset = 0; offset < dates.length; offset += batchSize) {
    const batch = dates.slice(offset, offset + batchSize);
    const completed = Math.min(dates.length, offset + batch.length);
    const progress = 36 + Math.round(completed / dates.length * 18);
    await saveProgress(state, job, `获取主体每日成交 ${completed}/${dates.length}`, progress);
    const settled = await Promise.allSettled(batch.map(date => fetchBusinessRecord(tabId, baseSpec(
      job,
      "/dataplatform/dataset/report/query",
      "POST",
      {
        period: { startDate: date, endDate: date, days: 1 },
        templateBody: state.datasetTemplate
      }
    ), "index-card")));
    let firstFailure = null;
    for (const result of settled) {
      if (result.status === "fulfilled") records.push(result.value.record);
      else {
        if (result.reason?.record && !records.includes(result.reason.record)) records.push(result.reason.record);
        firstFailure ||= result.reason;
      }
    }
    job.recordCount = records.length;
    if (firstFailure) throw firstFailure;
  }
}

function buildPartialReport(records, job, options = {}) {
  if (!job.period || !records.length) return null;
  try {
    const built = reportEngine.buildReport(records, job.subjectItemId, {
      ...job,
      periodConfirmed: true,
      periodPrecision: "exact",
      visitedPaths: ["商品概况", "成功品", "核心指标", "成长阶段与趋势", "投放场景", "关键词样本"]
    });
    for (const table of built.tables || []) {
      if (table.name !== "报告总览") continue;
      table.rows = (table.rows || []).filter(row => !["取数时段提示", "数据说明", "花费覆盖"].includes(String(row?.[0] || "")));
    }
    return built;
  } catch (error) {
    if (options.throwOnError) {
      const wrapped = new Error(`本地报告生成失败：${core.safeErrorText(error, "报告结构与当前数据不兼容")}`);
      wrapped.code = "REPORT_BUILD_FAILED";
      throw wrapped;
    }
    return null;
  }
}

async function finishWithSanjieImport(state, job, report, options = {}) {
  if (!report || typeof report !== "object") throw new Error("本机没有可归档的报告");
  const canonical = reportEngine.toCanonicalReport(report);
  const archiveQuality = archiveReportQuality(report);
  state.report = report;
  state.sanjie = {
    ok: false,
    status: "archiving",
    archived: false,
    reportId: "",
    reportUrl: "",
    savedAt: "",
    attemptedAt: new Date().toISOString(),
    errorCode: "SANJIE_IMPORT_UNCERTAIN",
    errorPhase: "post",
    error: "官网报告正在归档"
  };
  const queued = archiveOutboxEntry(state, report, job, state.sanjie);
  await writeLocalState(state);
  await saveProgress(state, job, "归档到官网报告中心", 96);
  try {
    const imported = await importCanonicalReportToSanjie(canonical, job, {
      reconcileFirst: job.reconcileArchiveFirst === true,
      quality: archiveQuality,
      sourceShop: core.sanitizeSourceShop(options.sourceShop || state.sourceShop)
    });
    state.sanjie = {
      ...imported,
      status: "archived",
      archived: true,
      attemptedAt: new Date().toISOString(),
      autoOpened: false,
      openError: "",
      errorCode: "",
      errorPhase: "",
      error: ""
    };
    removeArchiveOutboxEntry(state, queued.fingerprint);
    job.status = "completed";
    job.statusLabel = "已完成";
    job.step = archiveQuality === "complete" ? "官网历史报告已归档" : "官网历史报告已归档（部分数据）";
    delete job.errorCode;
    delete job.error;
  } catch (error) {
    const retainPostUncertainty = job.reconcileArchiveFirst === true
      && error?.archivePhase === "lookup";
    state.sanjie = {
      ok: false,
      status: "failed",
      archived: false,
      reportId: "",
      reportUrl: "",
      savedAt: "",
      attemptedAt: new Date().toISOString(),
      errorCode: error?.code || "SANJIE_IMPORT_FAILED",
      errorPhase: retainPostUncertainty ? "post" : error?.archivePhase || "unknown",
      error: core.safeErrorText(error, "官网报告未归档")
    };
    job.status = "blocked";
    job.statusLabel = "归档失败";
    job.errorCode = state.sanjie.errorCode;
    job.error = state.sanjie.error;
    job.step = `官网归档失败；本地报告已保留：${state.sanjie.error}`;
    updateArchiveOutboxEntry(state, queued.fingerprint, {
      job: publicJob(job),
      sanjie: state.sanjie,
      attempts: Number(queued.attempts || 0) + 1
    });
  }
  job.finishedAt = new Date().toISOString();
  job.progress = 100;
  state.job = publicJob(job);
  await writeLocalState(state);
  await broadcast(job);
  if (!state.sanjie.ok) {
    return {
      ok: false,
      archived: false,
      localFallback: true,
      error: state.sanjie.error,
      code: state.sanjie.errorCode,
      job: publicJob(job),
      reportReady: true
    };
  }

  if (options.autoOpen === false) {
    return {
      ok: true,
      archived: true,
      reportReady: true,
      reportUrl: state.sanjie.reportUrl,
      autoOpened: false,
      openError: "",
      job: publicJob(job)
    };
  }

  try {
    const opened = await openOfficialArchivedReport(state.sanjie.reportUrl);
    state.sanjie.autoOpened = true;
    state.sanjie.reportUrl = opened.reportUrl;
    state.sanjie.openedAt = new Date().toISOString();
    job.step = "官网历史报告已归档并打开";
  } catch (error) {
    state.sanjie.autoOpened = false;
    state.sanjie.openError = core.safeErrorText(error, "官网历史报告自动打开失败");
    job.step = "官网历史报告已归档；可点击“打开官网报告”查看";
  }
  state.job = publicJob(job);
  await writeLocalState(state);
  await broadcast(job);
  return {
    ok: true,
    archived: true,
    reportReady: true,
    reportUrl: state.sanjie.reportUrl,
    autoOpened: state.sanjie.autoOpened,
    openError: state.sanjie.openError || "",
    job: publicJob(job)
  };
}

async function runDirectJob(input) {
  const ids = core.validateJob(input);
  const previous = await readLocalState();
  await ensureCurrentReportQueued(previous);
  const hasReusableReport = isArchivableStoredReport(previous.report)
    && String(previous.lastConfig?.subjectItemId || "") === ids.subjectItemId
    && String(previous.lastConfig?.successItemId || "") === ids.successItemId;
  const canResumeFinalization = hasReusableReport
    && previous.sanjie?.ok !== true
    && RECOVERABLE_SANJIE_CODES.has(String(previous.sanjie?.errorCode || ""));
  if (!canResumeFinalization && normalizeArchiveOutbox(previous.archiveOutbox).length >= ARCHIVE_OUTBOX_LIMIT) {
    const error = new Error(`本地待归档报告已达 ${ARCHIVE_OUTBOX_LIMIT} 份，请联网登录官网完成补传后再开始新任务`);
    error.code = "ARCHIVE_OUTBOX_FULL";
    throw error;
  }
  const reconcileArchiveFirst = canResumeFinalization
    && previous.sanjie?.errorPhase === "post";
  const state = {
    schemaVersion: 2,
    lastConfig: ids,
    datasetTemplate: String(previous.datasetTemplate || ""),
    job: null,
    report: canResumeFinalization ? previous.report : null,
    sanjie: canResumeFinalization ? previous.sanjie : null,
    sourceShop: canResumeFinalization ? core.sanitizeSourceShop(previous.sourceShop) : null,
    archiveOutbox: normalizeArchiveOutbox(previous.archiveOutbox)
  };
  const records = [];
  const job = {
    id: `direct-${Date.now()}-${ids.subjectItemId}-${ids.successItemId}`,
    ...ids,
    status: "running",
    statusLabel: "准备中",
    step: "查找已登录的达摩盘页面",
    progress: 1,
    startedAt: new Date().toISOString(),
    recordCount: 0,
    sceneCount: 0,
    sceneMissed: [],
    warnings: [],
    requireSubjectDaily: true,
    reconcileArchiveFirst
  };
  state.job = publicJob(job);
  await writeLocalState(state);
  await broadcast(job);

  try {
    await saveProgress(state, job, "准备取数", 2);
    requireOfficialSiteAccess(await checkOfficialSiteAccess());
    if (canResumeFinalization) {
      job.period = previous.report.period || null;
      job.latestDay = previous.report.period?.endDate || "";
      return await finishWithSanjieImport(state, job, previous.report);
    }
    const selected = await selectReadyDmpTab(Boolean(state.datasetTemplate));
    const { tab, readiness } = selected;
    job.tabId = tab.id;
    state.sourceShop = await readSourceShopFromDmpTab(tab.id);
    await saveProgress(state, job, "确认页面本机请求模板", 5);
    job.templatePaths = readiness.capturedPaths || [];
    if (!readiness.requestTemplateCount) {
      const error = new Error("加载测试扩展后，请刷新一次达摩盘页面再运行；无需切换页面或日期");
      error.code = "TEMPLATE_REQUIRED";
      throw error;
    }
    if (!readiness.hasIndexCardTemplate && !state.datasetTemplate) {
      const error = new Error("请在达摩盘“货品-打爆路径”页面刷新一次，让插件学习核心指标请求模板");
      error.code = "TEMPLATE_REQUIRED";
      throw error;
    }

    await saveProgress(state, job, "读取达摩盘最新业务日期", 9);
    const latestRecord = await requestFromPage(tab.id, baseSpec(job, "/api/latestDay"));
    job.latestDay = parseLatestDay(latestRecord);
    job.period = core.periodEndingAtLatestDay(30, job.latestDay);
    if (!job.period) {
      const error = new Error("达摩盘没有返回可用的最新业务日期");
      error.code = "LATEST_DAY_UNAVAILABLE";
      throw error;
    }

    await saveProgress(state, job, "获取主体商品概况", 15);
    const itemResult = await fetchBusinessRecord(tab.id, baseSpec(job, "/api/goods/item/info"), "item-info");
    records.push(itemResult.record);
    job.recordCount = records.length;
    const cateId = core.findCateId(core.parseRecordBody(itemResult.record));

    await saveProgress(state, job, "只读确认目标成功品", 22);
    const searchResult = await fetchBusinessRecord(tab.id, baseSpec(job, "/api/goods/grow/define/success/item/list", "GET", { cateId }), "success-item-search");
    if (!core.successRecordHasTarget(searchResult.record, job.successItemId)) {
      const error = new Error("只读搜索未找到目标成功品，请确认与主体属于同一叶子类目");
      error.code = "SUCCESS_NOT_FOUND";
      error.record = searchResult.record;
      throw error;
    }
    records.push(searchResult.record);
    job.recordCount = records.length;

    await saveProgress(state, job, "获取主体与竞品核心指标", 34);
    const cardResult = await fetchBusinessRecord(tab.id, baseSpec(job, "/dataplatform/dataset/report/query", "POST", {
      templateBody: state.datasetTemplate
    }), "index-card");
    records.push(cardResult.record);
    state.datasetTemplate = cardResult.record.requestBody;
    job.recordCount = records.length;

    await fetchSubjectDailyCards(tab.id, state, job, records);

    await saveProgress(state, job, "获取成长趋势与五渠道消耗", 58);
    const lineResult = await fetchBusinessRecord(tab.id, baseSpec(job, "/api/goods/grow/define/line/data"), "growth-line");
    records.push(lineResult.record);
    job.recordCount = records.length;

    await saveProgress(state, job, "获取一级投放场景", 65);
    const level1Result = await fetchBusinessRecord(tab.id, baseSpec(job, "/api/goods/grow/comparison/scene"), "growth-scenes");
    records.push(level1Result.record);
    const sceneIds = core.sceneIdsFromRecord(level1Result.record);
    if (sceneIds.length > 20) {
      const error = new Error("一级场景数量异常，已停止本次后台取数");
      error.code = "SCENE_LIMIT_EXCEEDED";
      throw error;
    }
    job.sceneCount = sceneIds.length;
    job.recordCount = records.length;

    for (let index = 0; index < sceneIds.length; index += 1) {
      const sceneId = sceneIds[index];
      const progress = 67 + Math.round(((index + 1) / Math.max(1, sceneIds.length)) * 15);
      await saveProgress(state, job, `获取二级场景 ${index + 1}/${sceneIds.length}`, progress);
      const level2Result = await fetchBusinessRecord(tab.id, baseSpec(job, "/api/goods/grow/comparison/scene", "GET", { sceneLevel1Id: sceneId }), "growth-scenes");
      records.push(level2Result.record);
      job.recordCount = records.length;
    }

    await saveProgress(state, job, "获取关键词样本", 86);
    const keywordResult = await fetchBusinessRecord(tab.id, baseSpec(job, "/api/goods/grow/comparison/scene/keyword"), "growth-keywords");
    records.push(keywordResult.record);
    job.recordCount = records.length;

    await saveProgress(state, job, "本地生成 11 张业务表", 92);
    job.finishedAt = new Date().toISOString();
    const report = buildPartialReport(records, job, { throwOnError: true });
    const strictGapDays = Number(report.quality?.platformGap?.days || 0);
    const toleratedGapDays = Number(completeness.PLATFORM_DAY_GAP_TOLERANCE || 2);
    if (strictGapDays > toleratedGapDays) {
      const issue = `请求周期内缺少 ${strictGapDays} 天平台数据，超过允许的 ${toleratedGapDays} 天范围`;
      report.quality.complete = false;
      report.quality.exportAllowed = false;
      report.quality.status = "blocked";
      report.quality.missing = [...new Set([...(report.quality.missing || []), issue])];
      report.quality.blockingIssues = [...new Set([...(report.quality.blockingIssues || []), issue])];
    }
    return await finishWithSanjieImport(state, job, report);
  } catch (error) {
    if (error?.record && !records.includes(error.record)) records.push(error.record);
    job.finishedAt = new Date().toISOString();
    job.status = "failed";
    job.statusLabel = "运行未完成";
    job.progress = 100;
    job.errorCode = error?.code || "DIRECT_RUN_FAILED";
    job.error = core.safeErrorText(error, "取数未完成");
    job.step = job.error;
    const partial = buildPartialReport(records, job);
    if (partial?.quality) {
      partial.quality.complete = false;
      partial.quality.exportAllowed = false;
      partial.quality.status = "blocked";
      partial.quality.missing = [...new Set([...(partial.quality.missing || []), `任务失败：${job.error}`])];
    }
    if (partial) {
      job.warnings = [...new Set([...(job.warnings || []), `已归档当前可用数据：${job.error}`])];
      return await finishWithSanjieImport(state, job, partial);
    }
    state.report = partial;
    state.job = publicJob(job);
    await writeLocalState(state);
    await broadcast(job);
    return { ok: false, error: job.error, code: job.errorCode, job: publicJob(job), reportReady: false };
  } finally {
    records.length = 0;
  }
}

async function getClientState() {
  const draft = await readDraftAfterPendingWrites();
  const state = await readLocalState();
  if (state.job?.status === "running" && !runningPromise) {
    state.job = {
      ...state.job,
      status: "interrupted",
      statusLabel: "需要重试",
      step: "上次任务因扩展后台中断，请重新运行",
      error: "上次任务未完成",
      errorCode: "WORKER_INTERRUPTED"
    };
    await writeLocalState(state);
  }
  return { ok: true, state: { ...state, job: publicJob(state.job) }, draft };
}

function storedReportArchiveIds(state) {
  const report = state?.report || {};
  const overview = (report.tables || []).find(table => table?.name === "报告总览");
  const itemRow = (overview?.rows || []).find(row => String(row?.[0] || "") === "商品ID") || [];
  return core.validateJob({
    subjectItemId: state?.lastConfig?.subjectItemId
      || state?.job?.subjectItemId
      || report.item?.id
      || itemRow[1],
    successItemId: state?.lastConfig?.successItemId
      || state?.job?.successItemId
      || report.item?.competitorId
      || itemRow[2]
  });
}

function storedReportArchiveJob(state) {
  const ids = storedReportArchiveIds(state);
  const previous = state?.job || {};
  return {
    id: `archive-existing-${Date.now()}-${ids.subjectItemId}-${ids.successItemId}`,
    ...ids,
    status: "running",
    statusLabel: "同步中",
    step: "同步现有报告到官网",
    progress: 96,
    startedAt: previous.startedAt || new Date().toISOString(),
    period: state.report?.period || previous.period || null,
    latestDay: state.report?.period?.endDate || previous.latestDay || "",
    recordCount: Number(state.report?.recordCount || previous.recordCount || 0),
    sceneCount: Number(previous.sceneCount || 0),
    sceneMissed: Array.isArray(previous.sceneMissed) ? previous.sceneMissed : [],
    warnings: Array.isArray(previous.warnings) ? previous.warnings : [],
    reconcileArchiveFirst: state.sanjie?.errorPhase === "post"
      || state.sanjie?.status === "archiving"
  };
}

async function openOfficialLocalFallback(archiveFailure = null) {
  const launchNonce = createLaunchNonce();
  const reportUrl = officialLocalFallbackUrl(launchNonce);
  await cleanupOfficialLaunches();
  await writeOfficialNonce(OFFICIAL_LAUNCH_KEY_PREFIX, launchNonce, {
    tabId: null,
    expiresAt: Date.now() + OFFICIAL_LAUNCH_TTL_MS,
    used: false
  });
  let tab;
  try {
    tab = await chrome.tabs.create({ url: reportUrl });
  } catch (error) {
    await deleteOfficialNonce(OFFICIAL_LAUNCH_KEY_PREFIX, launchNonce);
    throw error;
  }
  const pending = await readOfficialNonce(OFFICIAL_LAUNCH_KEY_PREFIX, launchNonce);
  if (pending && !pending.used && pending.tabId == null) {
    await writeOfficialNonce(OFFICIAL_LAUNCH_KEY_PREFIX, launchNonce, { ...pending, tabId: tab?.id || null });
  }
  return {
    ok: true,
    archived: false,
    fallback: true,
    reportUrl,
    archiveError: archiveFailure?.error || "",
    archiveCode: archiveFailure?.code || ""
  };
}

function isArchivableStoredReport(report) {
  return Boolean(report && typeof report === "object"
    && (Array.isArray(report.tables) || report.item?.id));
}

function isArchivedSanjieState(sanjie) {
  return sanjie?.ok === true
    && sanjie?.archived !== false
    && Boolean(sanjie?.reportId)
    && Boolean(officialArchivedReportUrl(sanjie?.reportUrl));
}

function stateForArchiveOutboxEntry(entry) {
  return normalizeLocalState({
    lastConfig: entry?.lastConfig,
    job: entry?.job,
    report: entry?.report,
    sanjie: entry?.sanjie,
    sourceShop: entry?.sourceShop,
    archiveOutbox: []
  });
}

async function synchronizeArchiveOutboxEntry(state, entry) {
  const entryState = stateForArchiveOutboxEntry(entry);
  let job;
  try {
    job = storedReportArchiveJob(entryState);
  } catch (error) {
    const failure = {
      ok: false,
      status: "failed",
      archived: false,
      reportId: "",
      reportUrl: "",
      savedAt: "",
      attemptedAt: new Date().toISOString(),
      errorCode: error?.code || "ARCHIVE_IDENTITY_INVALID",
      errorPhase: "identity",
      error: core.safeErrorText(error, "报告商品身份无效")
    };
    updateArchiveOutboxEntry(state, entry.fingerprint, {
      sanjie: failure,
      attempts: Number(entry.attempts || 0) + 1
    });
    await writeLocalState(state);
    return { ok: false, archived: false, code: failure.errorCode, error: failure.error, nonRetryable: true };
  }

  const isCurrent = entry.fingerprint === currentArchiveFingerprint(state);
  const attemptedAt = new Date().toISOString();
  const archiving = {
    ok: false,
    status: "archiving",
    archived: false,
    reportId: "",
    reportUrl: "",
    savedAt: "",
    attemptedAt,
    errorCode: "SANJIE_IMPORT_UNCERTAIN",
    errorPhase: "post",
    error: "官网报告正在归档"
  };
  updateArchiveOutboxEntry(state, entry.fingerprint, {
    job: publicJob(job),
    sanjie: archiving,
    attempts: Number(entry.attempts || 0) + 1
  });
  if (isCurrent) state.sanjie = archiving;
  await writeLocalState(state);

  try {
    const canonical = reportEngine.toCanonicalReport(entry.report);
    const imported = await importCanonicalReportToSanjie(canonical, job, {
      reconcileFirst: job.reconcileArchiveFirst === true,
      quality: archiveReportQuality(entry.report),
      sourceShop: core.sanitizeSourceShop(entry.sourceShop || entryState.sourceShop)
    });
    const archived = {
      ...imported,
      status: "archived",
      archived: true,
      attemptedAt,
      autoOpened: false,
      openError: "",
      errorCode: "",
      errorPhase: "",
      error: ""
    };
    removeArchiveOutboxEntry(state, entry.fingerprint);
    if (isCurrent) {
      state.sanjie = archived;
      job.status = "completed";
      job.statusLabel = "已完成";
      job.step = archiveReportQuality(entry.report) === "complete"
        ? "官网历史报告已归档"
        : "官网历史报告已归档（部分数据）";
      job.progress = 100;
      job.finishedAt = new Date().toISOString();
      delete job.errorCode;
      delete job.error;
      state.job = publicJob(job);
    }
    await writeLocalState(state);
    if (isCurrent) await broadcast(job);
    return {
      ok: true,
      archived: true,
      reportReady: true,
      reportUrl: archived.reportUrl,
      autoOpened: false,
      job: publicJob(job)
    };
  } catch (error) {
    const retainPostUncertainty = job.reconcileArchiveFirst === true
      && error?.archivePhase === "lookup";
    const failure = {
      ok: false,
      status: "failed",
      archived: false,
      reportId: "",
      reportUrl: "",
      savedAt: "",
      attemptedAt,
      errorCode: error?.code || "SANJIE_IMPORT_FAILED",
      errorPhase: retainPostUncertainty ? "post" : error?.archivePhase || "unknown",
      error: core.safeErrorText(error, "官网报告未归档")
    };
    job.status = "blocked";
    job.statusLabel = "归档失败";
    job.progress = 100;
    job.finishedAt = new Date().toISOString();
    job.errorCode = failure.errorCode;
    job.error = failure.error;
    job.step = `官网归档失败；本地报告已保留：${failure.error}`;
    updateArchiveOutboxEntry(state, entry.fingerprint, {
      job: publicJob(job),
      sanjie: failure
    });
    if (isCurrent) {
      state.sanjie = failure;
      state.job = publicJob(job);
    }
    await writeLocalState(state);
    if (isCurrent) await broadcast(job);
    return { ok: false, archived: false, error: failure.error, code: failure.errorCode };
  }
}

function synchronizeStoredReport(options = {}) {
  if (storedArchivePromise) return storedArchivePromise;
  storedArchivePromise = (async () => {
    if (runningPromise) return { ok: false, skipped: "running" };
    let state = await readLocalState();
    try {
      await ensureCurrentReportQueued(state);
    } catch (error) {
      return { ok: false, skipped: "outbox-full", code: error?.code || "ARCHIVE_OUTBOX_FULL", error: core.safeErrorText(error) };
    }
    state = await readLocalState();
    const currentFingerprint = currentArchiveFingerprint(state);
    if (isArchivedSanjieState(state.sanjie) && currentFingerprint && archiveEntryIndex(state, currentFingerprint) >= 0) {
      removeArchiveOutboxEntry(state, currentFingerprint);
      await writeLocalState(state);
    }
    const queue = sortedArchiveOutbox(state);
    if (!queue.length) {
      if (isArchivedSanjieState(state.sanjie)) {
        return { ok: true, archived: true, reused: true, reportUrl: officialArchivedReportUrl(state.sanjie.reportUrl) };
      }
      return { ok: false, skipped: "no-report" };
    }
    if (options.authorized !== true) {
      const access = await checkOfficialSiteAccess(Boolean(options.forceAuth));
      if (!access?.ok) {
        return { ok: false, skipped: "auth", reason: access?.reason || "unavailable" };
      }
    }

    let archivedCount = 0;
    let skippedCount = 0;
    let latest = null;
    for (const queued of queue) {
      const failureCode = String(queued?.sanjie?.errorCode || "");
      if (queued?.sanjie?.status === "failed"
        && failureCode
        && !RECOVERABLE_SANJIE_CODES.has(failureCode)) {
        skippedCount += 1;
        continue;
      }
      latest = await synchronizeArchiveOutboxEntry(state, queued);
      state = await readLocalState();
      if (!latest.ok) {
        if (latest.nonRetryable) {
          skippedCount += 1;
          continue;
        }
        return { ...latest, archivedCount, pendingCount: sortedArchiveOutbox(state).length };
      }
      archivedCount += 1;
    }
    if (latest?.ok) return { ...latest, archivedCount, pendingCount: sortedArchiveOutbox(state).length };
    return { ok: false, skipped: "non-retryable", skippedCount, pendingCount: sortedArchiveOutbox(state).length };
  })().finally(() => {
    storedArchivePromise = null;
  });
  return storedArchivePromise;
}

function scheduleStoredReportArchive(trigger = "worker-wake") {
  return synchronizeStoredReport({ trigger }).catch(() => ({ ok: false, skipped: "error" }));
}

async function openArchivedStoredReport(state) {
  const reportUrl = officialArchivedReportUrl(state?.sanjie?.reportUrl);
  if (!reportUrl) throw new Error("官网归档记录的报告链接无效；本地报告仍已保留");
  const opened = await openOfficialArchivedReport(reportUrl);
  state.sanjie.autoOpened = true;
  state.sanjie.openedAt = new Date().toISOString();
  if (state.job) state.job.step = "官网历史报告已归档并打开";
  await writeLocalState(state);
  return { ok: true, archived: true, fallback: false, reportUrl: opened.reportUrl };
}

async function openStoredReport() {
  requireOfficialSiteAccess(await checkOfficialSiteAccess(true));
  let state = await readLocalState();
  if (!isArchivableStoredReport(state.report)) {
    return { ok: false, error: "本机没有可归档的 HTML 报告" };
  }
  if (isArchivedSanjieState(state.sanjie)) return openArchivedStoredReport(state);
  if (runningPromise) return { ok: false, error: "取数任务仍在运行，请完成后再打开报告" };

  let synced = await synchronizeStoredReport({ authorized: true, trigger: "manual-open" });
  state = await readLocalState();
  if (isArchivedSanjieState(state.sanjie)) return openArchivedStoredReport(state);
  if (synced?.skipped === "auth") {
    synced = await synchronizeStoredReport({ authorized: true, trigger: "manual-open-retry" });
    state = await readLocalState();
    if (isArchivedSanjieState(state.sanjie)) return openArchivedStoredReport(state);
  }
  if (synced?.skipped && !["error"].includes(synced.skipped)) {
    return { ok: false, error: "报告同步任务暂未完成，请稍后重试" };
  }
  return openOfficialLocalFallback(synced);
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "DMP_ROLLING7_OPEN_REPORT") {
    void scheduleStoredRolling7Archive("manual-open");
    openRolling7StoredReport()
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: rolling7SafeError(error, "滚动报告打开失败").message, code: error?.code || "REPORT_OPEN_FAILED" }));
    return true;
  }
  if (message?.type === "DMP_ROLLING7_GET_REPORT_FOR_FRAME") {
    readRolling7FrameReport(message, _sender)
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: rolling7SafeError(error, "滚动报告读取失败").message, code: error?.code || "REPORT_READ_FAILED" }));
    return true;
  }
  if (message?.type === "DMP_ROLLING7_GET_STATE") {
    getRolling7ClientState()
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: rolling7SafeError(error).message, code: error?.code || "STATE_READ_FAILED" }));
    return true;
  }
  if (message?.type === "DMP_ROLLING7_START") {
    startRolling7(message)
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: rolling7SafeError(error).message, code: error?.code || "QUEUE_START_FAILED" }));
    return true;
  }
  if (message?.type === "DMP_ROLLING7_PAUSE") {
    pauseRolling7()
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: rolling7SafeError(error).message, code: error?.code || "QUEUE_PAUSE_FAILED" }));
    return true;
  }
  if (message?.type === "DMP_ROLLING7_RESUME") {
    resumeRolling7()
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: rolling7SafeError(error).message, code: error?.code || "QUEUE_RESUME_FAILED" }));
    return true;
  }
  if (message?.type === "DMP_ROLLING7_STOP") {
    stopRolling7()
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: rolling7SafeError(error).message, code: error?.code || "QUEUE_STOP_FAILED" }));
    return true;
  }
  if (message?.type === "DMP_DIRECT_AUTH_CHECK") {
    checkOfficialSiteAccess(Boolean(message.force))
      .then(result => {
        sendResponse(result);
        if (result?.ok) {
          void scheduleStoredReportArchive("auth-success");
          void scheduleStoredRolling7Archive("auth-success");
        }
      })
      .catch(error => sendResponse({ ok: false, reason: "offline", error: core.safeErrorText(error) }));
    return true;
  }
  if (message?.type === "DMP_DIRECT_OPEN_LOGIN") {
    chrome.tabs.create({ url: `${core.SANJIE_ORIGIN}/login` })
      .then(tab => sendResponse({ ok: true, tabId: tab?.id || null }))
      .catch(error => sendResponse({ ok: false, error: core.safeErrorText(error) }));
    return true;
  }
  if (message?.type === "DMP_DIRECT_SAVE_DRAFT") {
    saveDraft(message.draft)
      .then(draft => sendResponse({ ok: true, draft }))
      .catch(error => sendResponse({ ok: false, error: core.safeErrorText(error), code: error?.code || "DRAFT_SAVE_FAILED" }));
    return true;
  }
  if (message?.type === "DMP_DIRECT_GET_STATE") {
    getClientState().then(sendResponse).catch(error => sendResponse({ ok: false, error: core.safeErrorText(error) }));
    return true;
  }
  if (message?.type === "DMP_DIRECT_PREPARE_OFFICIAL_FRAME") {
    prepareOfficialReportFrame(message, _sender)
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: core.safeErrorText(error) }));
    return true;
  }
  if (message?.type === "DMP_DIRECT_GET_REPORT_FOR_FRAME") {
    readOfficialFrameReport(message, _sender)
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: core.safeErrorText(error) }));
    return true;
  }
  if (message?.type === "DMP_DIRECT_OPEN_HTML") {
    openStoredReport()
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: core.safeErrorText(error) }));
    return true;
  }
  if (message?.type === "DMP_DIRECT_START") {
    if (runningPromise) {
      sendResponse({ ok: false, error: "已有取数任务正在运行" });
      return false;
    }
    try {
      core.validateJob(message);
    } catch (error) {
      sendResponse({ ok: false, error: core.safeErrorText(error) });
      return false;
    }
    const pendingArchive = storedArchivePromise;
    runningPromise = (pendingArchive ? pendingArchive.catch(() => null) : Promise.resolve())
      .then(() => runDirectJob(message));
    runningPromise
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: core.safeErrorText(error) }))
      .finally(() => {
        runningPromise = null;
        void scheduleStoredReportArchive("job-finished");
      });
    return true;
  }
  return false;
});

if (chrome.runtime.onInstalled?.addListener) {
  chrome.runtime.onInstalled.addListener(() => {
    void scheduleStoredReportArchive("installed-or-updated");
    void scheduleStoredRolling7Archive("installed-or-updated");
  });
}
if (chrome.runtime.onStartup?.addListener) {
  chrome.runtime.onStartup.addListener(() => {
    void scheduleStoredReportArchive("browser-startup");
    void scheduleStoredRolling7Archive("browser-startup");
  });
  void scheduleStoredReportArchive("worker-wake");
  void scheduleStoredRolling7Archive("worker-wake");
}
if (chrome.alarms?.onAlarm?.addListener) {
  chrome.alarms.onAlarm.addListener(alarm => {
    if (alarm?.name !== ROLLING7_ALARM_NAME) return;
    void ensureRolling7Initialized().then(() => currentRolling7State()).then(state => {
      if (state?.queueStatus === "running") void runRolling7Queue();
    });
  });
}
if (chrome.cookies.onChanged?.addListener) {
  chrome.cookies.onChanged.addListener(changeInfo => {
    if (!changeInfo?.removed && changeInfo?.cookie?.name === SANJIE_SESSION_COOKIE) {
      officialAuthCache = { expiresAt: 0, result: null };
      void scheduleStoredReportArchive("login-cookie-changed");
      void scheduleStoredRolling7Archive("login-cookie-changed");
    }
  });
}

void ensureRolling7Initialized().then(state => {
  if (state?.queueStatus === "running") void runRolling7Queue();
  else if (publicRolling7State(state).reportReady) void scheduleStoredRolling7Archive("rolling-state-ready");
});
