(() => {
  "use strict";

  const root = globalThis;
  const PAGE_API_KEY = "__SZ_DMP_DIRECT_ROLLING7_V1__";
  const PAGE_API_CAPABILITY = "market-rolling7-v1";
  if (root[PAGE_API_KEY]?.version === 1) return;

  const PAGE_ORIGIN = "https://dmp.taobao.com";
  const GATEWAY_ORIGIN = "https://dmp.advgateway.taobao.com";
  const ALLOWED_ORIGINS = new Set([PAGE_ORIGIN, GATEWAY_ORIGIN]);
  const MAX_TEMPLATE_BYTES = 512 * 1024;
  const MAX_RESPONSE_BYTES = 5 * 1024 * 1024;
  const REQUEST_TIMEOUT_MS = 20_000;
  const ALLOWED = Object.freeze({
    "/api/latestDay": "GET",
    "/api/goods/item/info": "GET",
    "/api/goods/grow/define/success/load": "GET",
    "/api/goods/grow/define/success/item/list": "GET",
    "/dataplatform/dataset/report/query": "POST",
    "/api/goods/grow/define/line/data": "GET",
    "/api/goods/grow/comparison/scene": "GET",
    "/api/goods/grow/comparison/scene/keyword": "GET",
    "/api/subdivide/market/date/range": "GET",
    "/api/subdivide/market/overview": "POST"
  });
  const SAFE_QUERY_KEYS = new Set([
    "itemId", "successItemId", "succItemIds", "startDate", "endDate", "sceneLevel1Id",
    "scene", "keyword", "cateId", "thedate", "sceneCode", "page", "pageSize", "periodType", "date"
  ]);
  const BUSINESS_QUERY_KEYS = new Set([
    ...SAFE_QUERY_KEYS, "growthStage", "sellerLevel", "gmvRankRateLevel"
  ]);
  const SENSITIVE_KEY = /(?:token|csrf|cookie|authorization|password|secret|(?:^|[_-])sign(?:ature|data)?$|session|webOpSessionId|uniqueItemCampaign)/i;
  const templates = new Map();
  const originalFetch = typeof root.fetch === "function" ? root.fetch : null;
  const NativeXHR = typeof root.XMLHttpRequest === "function" ? root.XMLHttpRequest : null;

  function canonicalPath(value) {
    let pathname = "";
    try {
      const url = new URL(String(value || ""), root.location?.href || "https://dmp.taobao.com/");
      if (!ALLOWED_ORIGINS.has(url.origin)) return "";
      pathname = url.pathname;
    } catch { return ""; }
    return pathname.replace(/^\/api_2\//, "/api/").replace(/\.json$/, "").replace(/\/+$/, "");
  }

  function bodyString(value) {
    if (value == null) return "";
    if (typeof value === "string") return value.length <= MAX_TEMPLATE_BYTES ? value : "";
    if (typeof URLSearchParams !== "undefined" && value instanceof URLSearchParams) {
      const text = value.toString();
      return text.length <= MAX_TEMPLATE_BYTES ? text : "";
    }
    return "";
  }

  function contentType(headers) {
    try { return new Headers(headers || {}).get("content-type") || ""; } catch { return ""; }
  }

  function rememberTemplate(entry) {
    const path = canonicalPath(entry?.url);
    if (!path || !ALLOWED[path]) return;
    const method = String(entry.method || "GET").toUpperCase();
    if (method !== ALLOWED[path]) return;
    const body = bodyString(entry.body);
    const current = templates.get(path) || [];
    const template = {
      path,
      url: String(entry.url),
      method,
      body,
      contentType: String(entry.contentType || ""),
      capturedAt: Date.now()
    };
    const duplicate = current.findIndex(candidate => candidate.url === template.url && candidate.method === method && candidate.body === body);
    if (duplicate >= 0) current.splice(duplicate, 1);
    current.push(template);
    while (current.length > 8) current.shift();
    templates.set(path, current);
  }

  function describeFetchTemplate(input, init) {
    let url = "";
    let method = "GET";
    let body = "";
    let mime = "";
    try {
      if (typeof Request !== "undefined" && input instanceof Request) {
        url = input.url;
        method = String(init?.method || input.method || "GET").toUpperCase();
        mime = contentType(init?.headers || input.headers);
        if (init && Object.prototype.hasOwnProperty.call(init, "body")) {
          body = bodyString(init.body);
        } else if (method !== "GET" && method !== "HEAD") {
          return input.clone().text()
            .then(text => ({ url, method, body: bodyString(text), contentType: mime }))
            .catch(() => null);
        }
      } else {
        url = new URL(String(input || ""), root.location?.href || "https://dmp.taobao.com/").href;
        method = String(init?.method || "GET").toUpperCase();
        body = bodyString(init?.body);
        mime = contentType(init?.headers);
      }
      return { url, method, body, contentType: mime };
    } catch { return null; }
  }

  if (originalFetch) {
    const wrappedFetch = function fetch(input, init) {
      const descriptor = describeFetchTemplate(input, init);
      const result = Reflect.apply(originalFetch, this, arguments);
      Promise.resolve(result).then(response => {
        if (!response?.ok) return;
        if (descriptor && typeof descriptor.then === "function") descriptor.then(entry => { if (entry) rememberTemplate(entry); }).catch(() => {});
        else if (descriptor) rememberTemplate(descriptor);
      }).catch(() => {});
      return result;
    };
    try { Object.defineProperty(wrappedFetch, "toString", { value: originalFetch.toString.bind(originalFetch) }); } catch {}
    root.fetch = wrappedFetch;
  }

  if (NativeXHR?.prototype) {
    const xhrMeta = new WeakMap();
    const originalOpen = NativeXHR.prototype.open;
    const originalSetRequestHeader = NativeXHR.prototype.setRequestHeader;
    const originalSend = NativeXHR.prototype.send;
    NativeXHR.prototype.open = function open(method, url) {
      xhrMeta.set(this, {
        method: String(method || "GET").toUpperCase(),
        url: new URL(String(url || ""), root.location?.href || "https://dmp.taobao.com/").href,
        contentType: ""
      });
      return Reflect.apply(originalOpen, this, arguments);
    };
    NativeXHR.prototype.setRequestHeader = function setRequestHeader(name, value) {
      const meta = xhrMeta.get(this);
      if (meta && String(name).toLowerCase() === "content-type") meta.contentType = String(value || "");
      return Reflect.apply(originalSetRequestHeader, this, arguments);
    };
    NativeXHR.prototype.send = function send(body) {
      const meta = xhrMeta.get(this);
      if (meta && typeof this.addEventListener === "function") {
        meta.body = body;
        this.addEventListener("loadend", () => {
          if (Number(this.status) >= 200 && Number(this.status) < 300) rememberTemplate(meta);
        }, { once: true });
      }
      return Reflect.apply(originalSend, this, arguments);
    };
  }

  function parseJson(text) {
    try { return JSON.parse(String(text || "")); } catch { return null; }
  }

  function datasetType(template) {
    const payload = parseJson(template?.body);
    return String(payload?.type ?? payload?.data?.type ?? payload?.params?.type ?? "").trim().toUpperCase();
  }

  function latestTemplates(path) {
    return [...(templates.get(path) || [])].sort((left, right) => right.capturedAt - left.capturedAt);
  }

  function selectTemplate(path) {
    const candidates = latestTemplates(path);
    if (path === "/dataplatform/dataset/report/query") {
      return candidates.find(candidate => datasetType(candidate) === "INDEX_CARD") || null;
    }
    return candidates[0] || null;
  }

  function selectAuthTemplate() {
    return [...templates.values()].flat().sort((left, right) => right.capturedAt - left.capturedAt)[0] || null;
  }

  function dateLike(example, value) {
    const date = String(value || "");
    return /^\d{8}$/.test(String(example || "")) ? date.replaceAll("-", "") : date;
  }

  function setDate(url, key, value) {
    const existing = url.searchParams.get(key) || "";
    url.searchParams.set(key, dateLike(existing, value));
  }

  function createRequestUrl(path, template, authTemplate, spec) {
    const endpoint = path === "/dataplatform/dataset/report/query" ? `${path}.json` : path;
    let url;
    if (template) {
      url = new URL(template.url);
    } else {
      url = new URL(endpoint, path === "/dataplatform/dataset/report/query" ? GATEWAY_ORIGIN : authTemplate.url);
      const source = new URL(authTemplate.url);
      for (const [key, value] of source.searchParams) {
        if (!BUSINESS_QUERY_KEYS.has(key)) url.searchParams.append(key, value);
      }
    }
    if (!ALLOWED_ORIGINS.has(url.origin) || canonicalPath(url.href) !== path) throw new Error("页面请求模板不属于允许的数据接口");
    url.hash = "";

    if (path === "/api/latestDay") url.searchParams.set("sceneCode", "goodsGrowPathSuccItemList");
    if (path === "/api/goods/item/info") {
      url.searchParams.set("itemId", spec.subjectItemId);
      url.searchParams.set("scene", "1");
    }
    if (path === "/api/goods/grow/define/success/load") {
      url.searchParams.set("itemId", spec.subjectItemId);
      url.searchParams.delete("thedate");
    }
    if (path === "/api/goods/grow/define/success/item/list") {
      const cateId = String(spec.cateId || url.searchParams.get("cateId") || "");
      if (!/^\d{1,20}$/.test(cateId)) {
        const error = new Error("未取得主体商品叶子类目；目标不是已选成功品时暂时无法只读搜索");
        error.code = "CATE_REQUIRED";
        throw error;
      }
      url.searchParams.set("cateId", cateId);
      url.searchParams.set("itemId", spec.subjectItemId);
      url.searchParams.set("growthStage", "2,4,1,3,5,6");
      url.searchParams.set("sellerLevel", "1,2,3,4,5,6,7,8,9");
      url.searchParams.set("gmvRankRateLevel", "1,2");
      url.searchParams.set("pageSize", "20");
      url.searchParams.set("page", "1");
      url.searchParams.set("keyword", spec.successItemId);
      if (spec.latestDay) url.searchParams.set("thedate", spec.latestDay);
    }
    if (path === "/api/goods/grow/define/line/data") {
      url.searchParams.set("itemId", spec.subjectItemId);
      url.searchParams.set("successItemId", spec.successItemId);
      setDate(url, "startDate", spec.period.startDate);
      setDate(url, "endDate", spec.period.endDate);
    }
    if (path === "/api/goods/grow/comparison/scene" || path === "/api/goods/grow/comparison/scene/keyword") {
      url.searchParams.set("itemId", spec.subjectItemId);
      url.searchParams.set("succItemIds", spec.successItemId);
      setDate(url, "startDate", spec.period.startDate);
      setDate(url, "endDate", spec.period.endDate);
      if (path === "/api/goods/grow/comparison/scene") {
        if (spec.sceneLevel1Id) url.searchParams.set("sceneLevel1Id", String(spec.sceneLevel1Id));
        else url.searchParams.delete("sceneLevel1Id");
      }
    }
    if (path === "/api/subdivide/market/date/range") {
      url.searchParams.set("periodType", String(spec.periodType || "1"));
      url.searchParams.set("date", String(spec.requestDate || ""));
    }
    return url;
  }

  function alignMarketOverviewBody(raw, spec) {
    const payload = parseJson(raw);
    if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
      const error = new Error("叶子类目市场概览模板尚未捕获；请先正常打开一次叶子类目市场页面");
      error.code = "TEMPLATE_REQUIRED";
      throw error;
    }
    const cateId = String(spec?.cateId || "");
    const periodType = String(spec?.periodType || "1");
    const date = String(spec?.requestDate || "");
    if (!/^\d{1,20}$/.test(cateId) || periodType !== "1" || !/^20\d{2}-\d{2}-\d{2}$/.test(date)) {
      const error = new Error("滚动7天公开业务参数无效");
      error.code = "INVALID_REQUEST";
      throw error;
    }
    return JSON.stringify({ cateId, periodType, date });
  }

  function alignDatasetBody(raw, spec) {
    const payload = parseJson(raw);
    if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
      const error = new Error("核心指标请求模板尚未捕获；请刷新一次达摩盘打爆路径页面");
      error.code = "TEMPLATE_REQUIRED";
      throw error;
    }
    const type = String(payload.type ?? payload?.data?.type ?? payload?.params?.type ?? "").toUpperCase();
    if (type !== "INDEX_CARD") {
      const error = new Error("尚未捕获核心指标模板；请刷新一次达摩盘打爆路径页面");
      error.code = "TEMPLATE_REQUIRED";
      throw error;
    }
    const align = (key, itemId) => {
      let filters = payload[key];
      const encoded = typeof filters === "string";
      if (encoded) filters = parseJson(filters);
      if (!Array.isArray(filters)) return false;
      filters = filters.map(filter => {
        const marker = `${filter?.expression || ""}|${filter?.description || ""}|${filter?.name || ""}`;
        if (/item_id|宝贝ID/i.test(marker)) return { ...filter, values: [String(itemId)] };
        if (/thedate|日期|时间/i.test(marker)) {
          const example = Array.isArray(filter?.values) ? filter.values[0] : "";
          return { ...filter, values: [dateLike(example, spec.period.startDate), dateLike(example, spec.period.endDate)] };
        }
        return filter;
      });
      payload[key] = encoded ? JSON.stringify(filters) : filters;
      return true;
    };
    if (!align("filterCondition", spec.subjectItemId) || !align("filterCompareCondition", spec.successItemId)) {
      const error = new Error("核心指标模板缺少商品或日期筛选条件");
      error.code = "TEMPLATE_REQUIRED";
      throw error;
    }
    return JSON.stringify(payload);
  }

  function sanitizeUrlString(value) {
    const text = String(value || "");
    if (!/^https?:\/\//i.test(text)) return text;
    try {
      const url = new URL(text);
      for (const key of [...url.searchParams.keys()]) if (SENSITIVE_KEY.test(key)) url.searchParams.delete(key);
      return url.toString();
    } catch { return text; }
  }

  function sanitizeValue(value, depth = 0) {
    if (depth > 24) return null;
    if (Array.isArray(value)) return value.map(child => sanitizeValue(child, depth + 1));
    if (value && typeof value === "object") {
      const output = {};
      for (const [key, child] of Object.entries(value)) {
        if (SENSITIVE_KEY.test(key)) continue;
        output[key] = sanitizeValue(child, depth + 1);
      }
      return output;
    }
    if (typeof value === "string") {
      const text = value.trim();
      if ((text.startsWith("{") && text.endsWith("}")) || (text.startsWith("[") && text.endsWith("]"))) {
        const nested = parseJson(text);
        if (nested && typeof nested === "object") return JSON.stringify(sanitizeValue(nested, depth + 1));
      }
      return sanitizeUrlString(value);
    }
    return value;
  }

  function safeRecordUrl(url) {
    const safe = new URL(url.origin + url.pathname);
    for (const [key, value] of url.searchParams) if (SAFE_QUERY_KEYS.has(key)) safe.searchParams.append(key, value);
    return safe.toString();
  }

  async function readTextCapped(response) {
    const length = Number(response.headers?.get?.("content-length") || 0);
    if (Number.isFinite(length) && length > MAX_RESPONSE_BYTES) throw new Error("接口响应超过本地处理上限");
    if (!response.body?.getReader || typeof TextDecoder === "undefined") {
      const text = await response.text();
      if (text.length > MAX_RESPONSE_BYTES) throw new Error("接口响应超过本地处理上限");
      return text;
    }
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let bytes = 0;
    let text = "";
    while (true) {
      const chunk = await reader.read();
      if (chunk.done) break;
      bytes += chunk.value?.byteLength || 0;
      if (bytes > MAX_RESPONSE_BYTES) {
        try { await reader.cancel(); } catch {}
        throw new Error("接口响应超过本地处理上限");
      }
      text += decoder.decode(chunk.value, { stream: true });
    }
    return text + decoder.decode();
  }

  function failure(code, message, record = null) {
    const output = { ok: false, error: { code: String(code || "REQUEST_FAILED"), message: String(message || "取数失败").slice(0, 240) } };
    if (record) output.record = record;
    return output;
  }

  function marketBusinessFailure(apiInfo, record) {
    const businessText = [
      apiInfo?.message,
      apiInfo?.msg,
      apiInfo?.errorMessage,
      apiInfo?.subMessage
    ].filter(value => value != null).map(String).join(" ").slice(0, 600);
    if (/(?:未登录|登录.*(?:失效|过期)|请.*登录|login|session.*(?:expired|invalid))/i.test(businessText)) {
      return failure("LOGIN_REQUIRED", "达摩盘登录已失效，请重新登录后继续", record);
    }
    if (/(?:无权限|没有权限|权限不足|未授权|禁止访问|forbidden|permission|access\s*denied)/i.test(businessText)) {
      return failure("REQUEST_NOT_ALLOWED", "当前账号无权读取该类目或周期", record);
    }
    if (/(?:参数.*(?:错误|无效)|日期.*(?:格式|无效)|类目.*(?:错误|无效)|invalid\s*(?:param|date|cate))/i.test(businessText)) {
      return failure("INVALID_REQUEST", "达摩盘拒绝了当前类目或日期参数", record);
    }
    // A parsed HTTP-2xx market response that is neither an auth, permission nor parameter
    // failure is only a no-data candidate. The worker still requires a continuous completed
    // prefix and three identical tail observations before it may close the unavailable suffix.
    return failure("MARKET_DATA_UNAVAILABLE", "达摩盘暂未返回可用数据", record);
  }

  async function request(spec) {
    try {
      if (root.location?.hostname !== "dmp.taobao.com" || root.location?.protocol !== "https:") return failure("UNEXPECTED_ORIGIN", "请保持一个已登录的达摩盘页面打开");
      if (!originalFetch) return failure("FETCH_UNAVAILABLE", "当前页面不支持接口请求");
      if (!spec || typeof spec !== "object") return failure("INVALID_REQUEST", "请求参数无效");
      const path = canonicalPath(`${GATEWAY_ORIGIN}${String(spec.path || "")}`);
      const method = String(spec.method || ALLOWED[path] || "").toUpperCase();
      if (!path || ALLOWED[path] !== method) return failure("REQUEST_NOT_ALLOWED", "请求不在达摩盘只读白名单内");
      const marketRequest = path === "/api/subdivide/market/date/range" || path === "/api/subdivide/market/overview";
      if (!marketRequest && !/^\d{6,20}$/.test(String(spec.subjectItemId || "")) && path !== "/api/latestDay") return failure("INVALID_ITEM", "主体商品 ID 无效");
      if (spec.successItemId && !/^\d{6,20}$/.test(String(spec.successItemId))) return failure("INVALID_ITEM", "成功品/竞品 ID 无效");

      const template = selectTemplate(path);
      if (marketRequest && !template) return failure("TEMPLATE_REQUIRED", "请先在已登录达摩盘中正常打开一次叶子类目市场页面，让两个核心接口各自完成一次请求");
      const authTemplate = template || selectAuthTemplate();
      if (!authTemplate) return failure("TEMPLATE_REQUIRED", "尚未捕获达摩盘本机请求模板；加载扩展后请刷新一次达摩盘页面");
      const url = createRequestUrl(path, template, authTemplate, spec);
      let requestBody = "";
      let requestMimeType = "";
      if (method === "POST") {
        requestBody = path === "/api/subdivide/market/overview"
          ? alignMarketOverviewBody(template?.body || "", spec)
          : alignDatasetBody(template?.body || spec.templateBody || "", spec);
        requestMimeType = template?.contentType || "application/json";
      }

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
      let response;
      let rawText;
      try {
        response = await Reflect.apply(originalFetch, root, [url.href, {
          method,
          credentials: "include",
          cache: "no-store",
          headers: method === "POST" ? { "Content-Type": requestMimeType } : undefined,
          body: method === "POST" ? requestBody : undefined,
          signal: controller.signal
        }]);
        rawText = await readTextCapped(response);
      } finally {
        clearTimeout(timeout);
      }
      const parsed = parseJson(rawText);
      const sanitizedBody = JSON.stringify(sanitizeValue(parsed));
      const sanitizedRequestBody = method === "POST" ? JSON.stringify(sanitizeValue(parseJson(requestBody))) : "";
      const safeUrl = safeRecordUrl(url);
      const capturedAt = new Date().toISOString();
      const record = {
        kind: "Network",
        source: "direct-main",
        capturedAt,
        requestId: `direct-${Date.now()}-${Math.random().toString(16).slice(2)}`,
        url: safeUrl,
        origin: url.origin,
        pathname: url.pathname,
        queryKeys: [...new URL(safeUrl).searchParams.keys()],
        method,
        type: "Fetch",
        initiatorType: "direct-main",
        documentUrl: `${root.location.origin}${root.location.pathname}`,
        requestBodyLength: sanitizedRequestBody.length,
        requestBodyTruncated: false,
        requestBodyAvailable: Boolean(sanitizedRequestBody),
        requestMimeType,
        requestFormat: sanitizedRequestBody ? "json" : "empty",
        requestKeys: Object.keys(parseJson(sanitizedRequestBody) || {}),
        requestBody: sanitizedRequestBody,
        status: response.status,
        statusText: response.statusText || "",
        mimeType: response.headers?.get?.("content-type") || "application/json",
        protocol: "fetch",
        fromDiskCache: false,
        fromServiceWorker: false,
        encodedDataLength: sanitizedBody.length,
        bodyAvailable: true,
        bodyEncoding: "",
        bodyLength: sanitizedBody.length,
        truncated: false,
        format: "json",
        responseKeys: Object.keys(sanitizeValue(parsed) || {}),
        body: sanitizedBody,
        templateSource: template ? "page-memory" : "page-auth+local-body"
      };
      if (!response.ok) {
        const loginExpired = response.status === 401 || response.status === 403;
        return failure(
          loginExpired ? "LOGIN_REQUIRED" : "HTTP_ERROR",
          loginExpired ? "达摩盘登录已失效，请重新登录后继续" : `数据接口返回 ${response.status}`,
          record
        );
      }
      if (!parsed) return failure("LOGIN_REQUIRED", "接口未返回业务数据，请确认达摩盘仍处于登录状态", record);
      const apiInfo = parsed?.info || parsed?.result?.info;
      if (apiInfo?.ok === false || (apiInfo?.code != null && Number(apiInfo.code) !== 0)) {
        return marketRequest
          ? marketBusinessFailure(apiInfo, record)
          : failure("API_ERROR", "达摩盘暂未返回可用数据", record);
      }
      return { ok: true, record };
    } catch (error) {
      const code = error?.code || (error?.name === "AbortError" ? "TIMEOUT" : "REQUEST_FAILED");
      return failure(code, error?.name === "AbortError" ? "接口请求超时" : error?.message);
    }
  }

  function readiness() {
    const paths = [...templates.entries()].filter(([, values]) => values.length).map(([path]) => path).sort();
    return {
      ok: true,
      version: 1,
      requestTemplateCount: [...templates.values()].reduce((sum, values) => sum + values.length, 0),
      capturedPaths: paths,
      hasIndexCardTemplate: latestTemplates("/dataplatform/dataset/report/query").some(candidate => datasetType(candidate) === "INDEX_CARD"),
      hasMarketDateRangeTemplate: latestTemplates("/api/subdivide/market/date/range").length > 0,
      hasMarketOverviewTemplate: latestTemplates("/api/subdivide/market/overview").length > 0,
      marketRolling7Ready: latestTemplates("/api/subdivide/market/date/range").length > 0
        && latestTemplates("/api/subdivide/market/overview").length > 0
    };
  }

  Object.defineProperty(root, PAGE_API_KEY, {
    value: Object.freeze({
      version: 1,
      capabilities: Object.freeze([PAGE_API_CAPABILITY]),
      readiness,
      request
    }),
    configurable: false,
    enumerable: false,
    writable: false
  });
})();
