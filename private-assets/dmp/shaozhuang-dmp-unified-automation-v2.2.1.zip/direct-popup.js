(() => {
  "use strict";

  let running = false;
  let hydrated = false;
  let inputsDirty = false;
  let rolling7ActionPending = false;
  let rolling7Hydrated = false;
  let rolling7LastState = {};

  const element = role => document.querySelector(`[data-role="${role}"]`);
  const ui = {
    subject: element("subject"),
    success: element("success"),
    run: element("run"),
    status: element("status"),
    percent: element("percent"),
    progress: element("progress"),
    step: element("step"),
    resultWrap: element("result-wrap"),
    result: element("result"),
    missing: element("missing"),
    openHtml: element("open-html")
  };
  const rolling7Ui = {
    section: element("rolling7-section"),
    cateId: element("rolling7-cate-id"),
    analysisStart: element("rolling7-analysis-start"),
    analysisEnd: element("rolling7-analysis-end"),
    start: element("rolling7-start"),
    pause: element("rolling7-pause"),
    resume: element("rolling7-resume"),
    stop: element("rolling7-stop"),
    status: element("rolling7-status"),
    percent: element("rolling7-percent"),
    progress: element("rolling7-progress"),
    count: element("rolling7-count"),
    error: element("rolling7-error"),
    openReport: element("rolling7-open-report")
  };
  const hasRolling7Ui = Boolean(rolling7Ui.section && rolling7Ui.cateId && rolling7Ui.analysisStart
    && rolling7Ui.analysisEnd && rolling7Ui.start && rolling7Ui.pause && rolling7Ui.resume
    && rolling7Ui.stop && rolling7Ui.status && rolling7Ui.percent && rolling7Ui.progress
    && rolling7Ui.count && rolling7Ui.error && rolling7Ui.openReport);
  ui.subject.disabled = true;
  ui.success.disabled = true;
  ui.run.disabled = true;

  function runtimeMessage(type, payload = {}) {
    return chrome.runtime.sendMessage({ type, ...payload });
  }

  async function ensureOfficialAccess() {
    const authorization = await runtimeMessage("DMP_DIRECT_AUTH_CHECK");
    if (authorization?.ok) return authorization;
    if (["nologin", "invalid"].includes(String(authorization?.reason || ""))) {
      await runtimeMessage("DMP_DIRECT_OPEN_LOGIN").catch(() => {});
    }
    throw new Error(authorization?.error || "shaozhuangai.com 授权核验未通过");
  }

  function currentDraft() {
    return {
      subjectItemId: ui.subject.value.trim(),
      successItemId: ui.success.value.trim(),
      savedAt: new Date().toISOString()
    };
  }

  function persistDraft() {
    return runtimeMessage("DMP_DIRECT_SAVE_DRAFT", { draft: currentDraft() }).then(result => {
      if (!result?.ok) throw new Error(result?.error || "商品 ID 保存失败");
      return result.draft;
    });
  }

  function setProgress(job) {
    const value = Math.max(0, Math.min(100, Number(job?.progress || 0)));
    ui.progress.style.width = `${value}%`;
    ui.percent.textContent = `${value}%`;
    ui.status.textContent = job?.statusLabel || (value ? "运行中" : "等待运行");
    ui.step.textContent = job?.step || "";
    const failed = ["failed", "blocked", "interrupted"].includes(job?.status);
    ui.status.style.color = failed ? "#ef7c67" : job?.status === "completed" ? "#8fcf7b" : "#f6c65f";
  }

  function hydrateInputs(state, savedDraft) {
    if (hydrated) return;
    if (!inputsDirty) {
      const config = savedDraft !== null && savedDraft !== undefined ? savedDraft : state?.lastConfig;
      ui.subject.value = String(config?.subjectItemId || "");
      ui.success.value = String(config?.successItemId || "");
    }
    hydrated = true;
    ui.subject.disabled = false;
    ui.success.disabled = false;
    ui.run.disabled = running;
  }

  function render(state) {
    setProgress(state?.job);
    const report = state?.report;
    const localReady = Boolean(report && typeof report === "object"
      && (Array.isArray(report.tables) || report.item?.id));
    const archived = state?.sanjie?.ok === true
      && state?.sanjie?.archived !== false
      && Boolean(state.sanjie.reportId)
      && Boolean(state.sanjie.reportUrl);
    const archiveFailed = localReady && state?.sanjie?.status === "failed";
    const taskRunning = state?.job?.status === "running";
    ui.run.disabled = running || taskRunning;
    ui.openHtml.disabled = !localReady || running || taskRunning;
    ui.openHtml.textContent = archived ? "打开官网报告" : "同步并打开官网报告";
    ui.resultWrap.hidden = !report && !state?.job?.error && !state?.sanjie?.error;
    ui.missing.replaceChildren();
    if (report) {
      ui.result.textContent = archived
        ? (state.sanjie.autoOpened ? "官网历史报告已归档并打开。" : "官网历史报告已归档。")
        : localReady
          ? (archiveFailed
            ? `官网同步未完成；本地报告已保留，可直接重试同步。${state.sanjie.error || ""}`
            : "本地报告待同步官网。")
          : `已取得部分数据：覆盖 ${report.quality?.observed || 0}/${report.quality?.expected || 6} 个模块。`;
      ui.result.className = `result ${archived || (localReady && !archiveFailed) ? "" : "bad"}`.trim();
      const missing = [...new Set(report.quality?.missing || [])].slice(0, 6);
      missing.forEach(value => {
        const item = document.createElement("li");
        item.textContent = String(value);
        ui.missing.appendChild(item);
      });
    } else if (state?.job?.error) {
      ui.result.textContent = state.job.error;
      ui.result.className = "result bad";
    }
  }

  async function refresh() {
    try {
      const result = await runtimeMessage("DMP_DIRECT_GET_STATE");
      if (!result?.ok) throw new Error(result?.error || "本地状态读取失败");
      hydrateInputs(result.state, result.draft);
      render(result.state);
    } catch (error) {
      hydrateInputs(null, null);
      ui.status.textContent = "扩展后台未就绪";
      ui.status.style.color = "#ef7c67";
      ui.step.textContent = String(error?.message || error);
    }
  }

  function validateInputs() {
    const subjectItemId = ui.subject.value.trim();
    const successItemId = ui.success.value.trim();
    if (!/^\d{6,20}$/.test(subjectItemId)) throw new Error("请输入 6–20 位主体商品 ID");
    if (!/^\d{6,20}$/.test(successItemId)) throw new Error("请输入 6–20 位成功品/竞品 ID");
    if (subjectItemId === successItemId) throw new Error("主体与成功品/竞品不能相同");
    return { subjectItemId, successItemId };
  }

  function rolling7Number(value) {
    const number = Number(value);
    return Number.isFinite(number) && number >= 0 ? Math.floor(number) : 0;
  }

  function rolling7PublicState(value) {
    if (!value || typeof value !== "object") return {};
    const state = value.state && typeof value.state === "object"
      ? value.state
      : value.job && typeof value.job === "object"
        ? value.job
        : {};
    const stats = value.stats && typeof value.stats === "object" ? value.stats : {};
    return { ...state, ...stats, ...value };
  }

  function rolling7StatusLabel(state) {
    if (state?.statusLabel) return String(state.statusLabel);
    return ({
      idle: "等待开始",
      starting: "正在启动",
      queued: "等待执行",
      running: "运行中",
      retrying: "正在重试",
      waiting: "等待下一项",
      pausing: "正在暂停",
      paused: "已暂停",
      resuming: "正在继续",
      stopping: "正在停止",
      stopped: "已停止",
      completed: "已完成",
      failed: "运行失败",
      blocked: "暂时无法继续"
    })[String(state?.status || state?.queueStatus || "idle")] || "等待开始";
  }

  function hydrateRolling7Inputs(state) {
    if (!hasRolling7Ui || rolling7Hydrated) return;
    const config = state?.config || state?.lastConfig || state?.input || {};
    rolling7Ui.cateId.value = String(config.cateId || state?.cateId || "");
    rolling7Ui.analysisStart.value = String(config.analysisStart || state?.analysisStart || "");
    rolling7Ui.analysisEnd.value = String(config.analysisEnd || state?.analysisEnd || "");
    rolling7Hydrated = true;
  }

  function renderRolling7(rawState) {
    if (!hasRolling7Ui) return;
    const state = { ...rolling7LastState, ...rolling7PublicState(rawState) };
    rolling7LastState = state;
    hydrateRolling7Inputs(state);
    const counts = state.counts && typeof state.counts === "object" ? state.counts : {};
    const total = rolling7Number(state.total ?? state.totalTaskCount ?? state.totalTasks ?? counts.total);
    const completed = rolling7Number(state.completed ?? state.completedTaskCount ?? state.completedTasks ?? counts.completed);
    const explicitProgress = state.progressPercent ?? state.progress;
    const progress = Number.isFinite(Number(explicitProgress))
      ? Math.max(0, Math.min(100, Number(explicitProgress)))
      : total > 0 ? Math.max(0, Math.min(100, completed / total * 100)) : 0;
    const status = String(state.status || state.queueStatus || "idle");
    const active = ["starting", "queued", "running", "retrying", "waiting", "pausing", "resuming", "stopping"].includes(status);
    const paused = status === "paused";
    const canStop = active || paused;
    const failed = ["failed", "blocked"].includes(status);

    rolling7Ui.count.textContent = `${completed} / ${total}`;
    rolling7Ui.percent.textContent = `${Math.round(progress)}%`;
    rolling7Ui.progress.style.width = `${progress}%`;
    const archive = state.archive && typeof state.archive === "object" ? state.archive : null;
    const tailClosure = state.tailClosure && typeof state.tailClosure === "object" ? state.tailClosure : null;
    const completedLabel = status === "completed"
      ? archive?.archived === true ? "已完成并归档"
        : archive?.status === "archiving" ? "正在归档"
          : archive?.status === "failed" ? "已完成，待同步"
            : tailClosure?.effectiveAnalysisEndDate ? `已按可用数据完成至 ${tailClosure.effectiveAnalysisEndDate}`
              : "已完成"
      : "";
    rolling7Ui.status.textContent = completedLabel || rolling7StatusLabel(state);
    rolling7Ui.status.style.color = failed ? "#ef7c67" : status === "completed" ? "#8fcf7b" : "#f6c65f";
    rolling7Ui.error.textContent = String(state.error || archive?.error || "");
    rolling7Ui.start.disabled = rolling7ActionPending || active || paused;
    rolling7Ui.pause.disabled = rolling7ActionPending || !["running", "retrying", "waiting"].includes(status);
    rolling7Ui.resume.disabled = rolling7ActionPending || !paused;
    rolling7Ui.stop.disabled = rolling7ActionPending || !canStop;
    rolling7Ui.openReport.disabled = rolling7ActionPending || state.reportReady !== true;
    rolling7Ui.cateId.disabled = active || paused;
    rolling7Ui.analysisStart.disabled = active || paused;
    rolling7Ui.analysisEnd.disabled = active || paused;
  }

  async function refreshRolling7() {
    if (!hasRolling7Ui) return;
    try {
      const result = await runtimeMessage("DMP_ROLLING7_GET_STATE");
      if (!result?.ok) throw new Error(result?.error || "滚动任务状态读取失败");
      renderRolling7(result);
    } catch (error) {
      rolling7Ui.status.textContent = "任务后台未就绪";
      rolling7Ui.status.style.color = "#ef7c67";
      rolling7Ui.error.textContent = String(error?.message || error);
    }
  }

  function validateRolling7Inputs() {
    const cateId = rolling7Ui.cateId.value.trim();
    const analysisStart = rolling7Ui.analysisStart.value.trim();
    const analysisEnd = rolling7Ui.analysisEnd.value.trim();
    if (!/^\d{1,20}$/.test(cateId)) throw new Error("请输入有效的叶子类目 ID");
    if (!/^\d{4}-\d{2}-\d{2}$/.test(analysisStart)) throw new Error("请选择分析开始日");
    if (!/^\d{4}-\d{2}-\d{2}$/.test(analysisEnd)) throw new Error("请选择分析结束日");
    if (analysisStart > analysisEnd) throw new Error("分析开始日不能晚于结束日");
    return { cateId, analysisStart, analysisEnd };
  }

  async function rolling7Action(type, payload = {}) {
    if (!hasRolling7Ui || rolling7ActionPending) return;
    rolling7ActionPending = true;
    const pendingStatus = ({
      DMP_ROLLING7_START: "starting",
      DMP_ROLLING7_PAUSE: "pausing",
      DMP_ROLLING7_RESUME: "resuming",
      DMP_ROLLING7_STOP: "stopping"
    })[type];
    renderRolling7({ status: pendingStatus, error: "" });
    try {
      const result = await runtimeMessage(type, payload);
      if (!result?.ok) throw new Error(result?.error || "滚动任务操作失败");
      renderRolling7(result);
    } catch (error) {
      renderRolling7({ status: "failed", error: String(error?.message || error) });
    } finally {
      rolling7ActionPending = false;
      renderRolling7(rolling7LastState);
      await refreshRolling7();
    }
  }

  function startRolling7() {
    let input;
    try {
      input = validateRolling7Inputs();
    } catch (error) {
      rolling7Ui.status.textContent = "输入有误";
      rolling7Ui.status.style.color = "#ef7c67";
      rolling7Ui.error.textContent = String(error?.message || error);
      return;
    }
    void rolling7Action("DMP_ROLLING7_START", input);
  }

  async function run() {
    if (running) return;
    let input;
    try { input = validateInputs(); }
    catch (error) {
      ui.status.textContent = "输入有误";
      ui.status.style.color = "#ef7c67";
      ui.step.textContent = error.message;
      return;
    }
    running = true;
    ui.run.disabled = true;
    ui.openHtml.disabled = true;
    ui.status.textContent = "正在启动";
    ui.status.style.color = "#f6c65f";
    ui.step.textContent = "正在取数…";
    try {
      await ensureOfficialAccess();
      await persistDraft();
      const result = await runtimeMessage("DMP_DIRECT_START", input);
      if (!result?.ok && result?.error) {
        ui.status.textContent = "运行未完成";
        ui.status.style.color = "#ef7c67";
        ui.step.textContent = result.error;
      }
    } catch (error) {
      ui.status.textContent = "运行未完成";
      ui.status.style.color = "#ef7c67";
      ui.step.textContent = String(error?.message || error);
    } finally {
      running = false;
      ui.run.disabled = false;
      await refresh();
    }
  }

  function saveChangedDraft() {
    inputsDirty = true;
    void persistDraft().catch(() => {});
  }

  ui.run.addEventListener("click", () => void run());
  ui.subject.addEventListener("input", saveChangedDraft);
  ui.success.addEventListener("input", saveChangedDraft);
  ui.subject.addEventListener("change", saveChangedDraft);
  ui.success.addEventListener("change", saveChangedDraft);
  ui.subject.addEventListener("keydown", event => { if (event.key === "Enter") ui.success.focus(); });
  ui.success.addEventListener("keydown", event => { if (event.key === "Enter") void run(); });
  ui.openHtml.addEventListener("click", async () => {
    if (running) return;
    running = true;
    ui.run.disabled = true;
    ui.openHtml.disabled = true;
    ui.status.textContent = "正在同步";
    ui.status.style.color = "#f6c65f";
    ui.step.textContent = "正在使用现有报告同步官网，无需重新取数";
    try {
      await ensureOfficialAccess();
      const result = await runtimeMessage("DMP_DIRECT_OPEN_HTML");
      if (result?.ok) {
        ui.status.textContent = result.archived ? "已打开官网报告" : "已打开本地报告";
        ui.step.textContent = result.archived
          ? "官网历史报告已归档并打开"
          : `官网同步未完成；已打开本地报告${result.archiveError ? `：${result.archiveError}` : ""}`;
        return;
      }
      throw new Error(result?.error || "报告暂时无法打开");
    } catch (error) {
      ui.status.textContent = "打开失败";
      ui.status.style.color = "#ef7c67";
      ui.step.textContent = String(error?.message || error || "报告暂时无法打开");
    } finally {
      running = false;
      ui.run.disabled = false;
      await refresh();
    }
  });

  if (hasRolling7Ui) {
    rolling7Ui.start.addEventListener("click", startRolling7);
    rolling7Ui.pause.addEventListener("click", () => void rolling7Action("DMP_ROLLING7_PAUSE"));
    rolling7Ui.resume.addEventListener("click", () => void rolling7Action("DMP_ROLLING7_RESUME"));
    rolling7Ui.stop.addEventListener("click", () => void rolling7Action("DMP_ROLLING7_STOP"));
    rolling7Ui.openReport.addEventListener("click", async () => {
      if (rolling7ActionPending) return;
      rolling7ActionPending = true;
      rolling7Ui.openReport.disabled = true;
      rolling7Ui.error.textContent = "";
      try {
        const result = await runtimeMessage("DMP_ROLLING7_OPEN_REPORT");
        if (!result?.ok) throw new Error(result?.error || "滚动报告打开失败");
      } catch (error) {
        rolling7Ui.error.textContent = String(error?.message || error || "滚动报告打开失败");
      } finally {
        rolling7ActionPending = false;
        await refreshRolling7();
      }
    });
    rolling7Ui.cateId.addEventListener("keydown", event => {
      if (event.key === "Enter") rolling7Ui.analysisStart.focus();
    });
  }

  chrome.runtime.onMessage.addListener(message => {
    if (message?.type === "DMP_DIRECT_PROGRESS") setProgress(message.job);
    if (message?.type === "DMP_ROLLING7_PROGRESS") renderRolling7(message);
  });

  void refresh();
  void refreshRolling7();
})();
