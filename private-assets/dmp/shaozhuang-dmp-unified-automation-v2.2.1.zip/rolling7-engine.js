(function initDmpRolling7Engine(root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.DmpRolling7Engine = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function createDmpRolling7Engine() {
  "use strict";

  // This module is deliberately transport-agnostic. It accepts responses observed in an
  // already authenticated DMP page, but it never creates requests and never persists URLs,
  // headers, cookies, tokens, CSRF values, or signatures.
  const MANIFEST_SCHEMA_VERSION = "dmp-market-rolling7-manifest/1.0";
  const DATASET_SCHEMA_VERSION = "dmp-market-rolling7/1.0";
  const CAPTURE_SCHEMA_VERSION = "dmp-market-rolling7-capture/1.0";
  const RANGE_PATH = "/api/subdivide/market/date/range";
  const OVERVIEW_PATH = "/api/subdivide/market/overview";
  const ENDPOINTS = Object.freeze([RANGE_PATH, OVERVIEW_PATH]);

  // Keep this list in sync with the dmp-market-rolling7/1.0 offline pipeline. A missing
  // property is represented by null. An API-provided numeric zero remains numeric zero.
  const MARKET_FIELDS = Object.freeze([
    "alipayInshopAmt", "alipayInshopAmtPop",
    "nup", "nupPop",
    "qup", "qupPop",
    "newCnt", "newCntPop",
    "hotCnt", "hotCntPop",
    "clk", "clkPop",
    "alipayUv", "alipayUvPop",
    "newCustCnt", "newCustCntPop",
    "saleCnt", "saleCntPop",
    "apf", "apfPop",
    "cvr", "cvrPop",
    "roi", "roiPop"
  ]);

  const QUEUE_STATUSES = Object.freeze(["idle", "running", "paused", "stopped", "completed"]);
  const TASK_STATUSES = Object.freeze([
    "pending", "running", "retry-wait", "completed", "conflict",
    "boundary-mismatch", "failed", "stopped"
  ]);
  const TERMINAL_TASK_STATUSES = new Set(["completed", "conflict", "boundary-mismatch", "failed", "stopped"]);

  const SENSITIVE_KEY_PATTERN = /(?:token|csrf|cookie|authorization|password|passwd|secret|(?:^|[_-])auth(?:$|[_-])|(?:^|[_-])sign(?:ature|data)?$|session|webOpSessionId|uniqueItemCampaign)/i;
  const SENSITIVE_TEXT_PATTERNS = Object.freeze([
    /(?:_tb_token_|[A-Za-z0-9_-]*(?:token|csrf|cookie|authorization|password|passwd|secret|signature|signData|session|webOpSessionId|uniqueItemCampaign)[A-Za-z0-9_-]*)\s*[=:]/i,
    /(?:^|[?&])(?:auth|sign)\s*=/i,
    /(?:cookie|set-cookie|authorization)\s*:/i,
    /\b(?:bearer|basic)\s+[A-Za-z0-9._~+/=-]{8,}/i
  ]);

  function clone(value) {
    return value == null ? value : JSON.parse(JSON.stringify(value));
  }

  function errorWithCode(code, message) {
    const error = new Error(message);
    error.name = "DmpRolling7Error";
    error.code = code;
    return error;
  }

  function parseDate(value) {
    const text = String(value == null ? "" : value).trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) throw errorWithCode("INVALID_DATE", `日期格式错误: ${text}`);
    const date = new Date(`${text}T00:00:00.000Z`);
    if (Number.isNaN(date.valueOf()) || date.toISOString().slice(0, 10) !== text) {
      throw errorWithCode("INVALID_DATE", `无效日期: ${text}`);
    }
    return date;
  }

  function formatDate(value) {
    const date = value instanceof Date ? value : new Date(value);
    if (Number.isNaN(date.valueOf())) throw errorWithCode("INVALID_DATE", "无法格式化无效日期");
    return date.toISOString().slice(0, 10);
  }

  function addDays(value, days) {
    if (!Number.isInteger(days)) throw errorWithCode("INVALID_DAY_OFFSET", "日期偏移必须是整数");
    const date = parseDate(value);
    date.setUTCDate(date.getUTCDate() + days);
    return formatDate(date);
  }

  function dateSequence(startDate, endDate) {
    const start = parseDate(startDate);
    const end = parseDate(endDate);
    if (start > end) throw errorWithCode("INVALID_DATE_RANGE", `${startDate} 晚于 ${endDate}`);
    const values = [];
    for (const cursor = new Date(start); cursor <= end; cursor.setUTCDate(cursor.getUTCDate() + 1)) {
      values.push(formatDate(cursor));
    }
    return values;
  }

  function isoNow(value) {
    const source = typeof value === "function" ? value() : value;
    const date = source == null ? new Date() : source instanceof Date ? source : new Date(source);
    if (Number.isNaN(date.valueOf())) throw errorWithCode("INVALID_NOW", "now 必须是有效时间");
    return date.toISOString();
  }

  function timestamp(value) {
    const parsed = new Date(value == null ? 0 : value).valueOf();
    return Number.isFinite(parsed) ? parsed : 0;
  }

  function positiveInteger(value, fallback, maximum) {
    const parsed = Number(value);
    if (!Number.isInteger(parsed) || parsed < 0 || parsed > maximum) return fallback;
    return parsed;
  }

  function makeTaskId(cateId, periodType, requestDate) {
    const category = String(cateId == null ? "" : cateId).trim();
    const period = String(periodType == null ? "" : periodType).trim();
    if (!/^\d+$/.test(category)) throw errorWithCode("INVALID_CATE_ID", "cateId 必须是纯数字文本");
    if (period !== "1") throw errorWithCode("INVALID_PERIOD_TYPE", "滚动7天 periodType 必须为 1");
    parseDate(requestDate);
    return `${category}|${period}|${requestDate}`;
  }

  function generateManifest(options) {
    const input = options || {};
    const cateId = String(input.cateId == null ? "" : input.cateId).trim();
    const periodType = String(input.periodType == null ? "1" : input.periodType).trim();
    const analysisStart = String(input.analysisStart == null ? "" : input.analysisStart).trim();
    const analysisEnd = String(input.analysisEnd == null ? "" : input.analysisEnd).trim();
    const paddingDays = positiveInteger(input.paddingDays, 6, 31);
    makeTaskId(cateId, periodType, analysisStart);
    parseDate(analysisEnd);
    if (parseDate(analysisStart) > parseDate(analysisEnd)) {
      throw errorWithCode("INVALID_DATE_RANGE", "分析开始日期晚于结束日期");
    }
    const queryStart = addDays(analysisStart, -paddingDays);
    const queryEnd = addDays(analysisEnd, paddingDays);
    const tasks = dateSequence(queryStart, queryEnd).map((requestDate, index) => ({
      sequence: index + 1,
      taskId: makeTaskId(cateId, periodType, requestDate),
      cateId,
      periodType,
      requestDate,
      expectedStartDate: addDays(requestDate, -6),
      expectedEndDate: requestDate,
      status: "pending"
    }));
    return {
      schemaVersion: MANIFEST_SCHEMA_VERSION,
      generatedAt: isoNow(input.now),
      cateId,
      periodType,
      analysisRange: { startDate: analysisStart, endDate: analysisEnd },
      queryRange: { startDate: queryStart, endDate: queryEnd, paddingDays },
      captureKeywords: ENDPOINTS.slice(),
      taskCount: tasks.length,
      tasks
    };
  }

  function canonicalEndpoint(value) {
    let source = String(value == null ? "" : value).trim();
    if (!source) return "";
    try {
      if (typeof URL === "function") source = new URL(source, "https://dmp.taobao.com").pathname;
      else throw new Error("URL unavailable");
    } catch {
      source = source.replace(/^[A-Za-z][A-Za-z0-9+.-]*:\/\/[^/]+/, "").split(/[?#]/)[0];
    }
    return source
      .replace(/^\/api_2\//, "/api/")
      .replace(/\.json$/i, "")
      .replace(/\/+$/, "");
  }

  function endpointOf(record) {
    return canonicalEndpoint(record?.endpoint || record?.pathname || record?.url || record?.request?.url || "");
  }

  function stripFence(value) {
    return String(value == null ? "" : value)
      .replace(/^\s*```(?:json|javascript|js)?\s*/i, "")
      .replace(/\s*```\s*$/, "")
      .trim();
  }

  function parseJsonLike(value, depth) {
    const level = Number(depth || 0);
    if (value == null || level > 4) return value == null ? null : value;
    if (typeof value === "object") return value;
    if (typeof value !== "string") return null;
    const text = stripFence(value);
    if (!text) return null;
    try {
      const parsed = JSON.parse(text);
      return typeof parsed === "string" ? parseJsonLike(parsed, level + 1) : parsed;
    } catch {}
    const jsonp = text.match(/^[\w$.[\]]+\s*\(([\s\S]*)\)\s*;?$/);
    if (!jsonp) return null;
    try { return JSON.parse(jsonp[1]); } catch { return null; }
  }

  function requestPayload(record) {
    const candidates = [
      record?.requestPostData,
      record?.postData,
      record?.requestBody,
      record?.request?.postData?.text,
      record?.request?.postData
    ];
    for (const candidate of candidates) {
      if (candidate == null) continue;
      const parsed = parseJsonLike(candidate);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
        if (typeof parsed.text === "string") {
          const nested = parseJsonLike(parsed.text);
          if (nested && typeof nested === "object") return nested;
        }
        return parsed;
      }
      try {
        const result = parsePublicQuery(String(candidate));
        if (Object.keys(result).length) return result;
      } catch {}
    }
    return {};
  }

  function parsePublicQuery(value) {
    const text = String(value == null ? "" : value);
    const query = text.includes("?") ? text.slice(text.indexOf("?") + 1) : text;
    const result = {};
    for (const pair of query.split("&")) {
      if (!pair) continue;
      const separator = pair.indexOf("=");
      const rawKey = separator < 0 ? pair : pair.slice(0, separator);
      const rawValue = separator < 0 ? "" : pair.slice(separator + 1);
      let key;
      let decoded;
      try {
        key = decodeURIComponent(rawKey.replace(/\+/g, " "));
        decoded = decodeURIComponent(rawValue.replace(/\+/g, " "));
      } catch {
        continue;
      }
      if (key) result[key] = decoded;
    }
    return result;
  }

  function responsePayload(record) {
    if (record?.schemaVersion === CAPTURE_SCHEMA_VERSION) return record.response || null;
    const candidates = [
      record?.body,
      record?.responseBody,
      record?.response?.body,
      record?.response?.content?.text
    ];
    for (const candidate of candidates) {
      const parsed = parseJsonLike(candidate);
      if (parsed && typeof parsed === "object") return parsed;
    }
    return null;
  }

  function publicRangeRequest(record) {
    const directPeriod = record?.request?.periodType ?? record?.periodType;
    const directDate = record?.request?.date ?? record?.request?.requestDate ?? record?.requestDate;
    if (directPeriod != null && directDate != null) {
      return { periodType: String(directPeriod), requestDate: String(directDate) };
    }
    const source = record?.url || record?.request?.url || "";
    try {
      const query = parsePublicQuery(source);
      return {
        periodType: query.periodType ?? null,
        requestDate: query.date ?? null
      };
    } catch {
      return { periodType: null, requestDate: null };
    }
  }

  function stableStringify(value) {
    if (value === undefined) return "null";
    if (value === null || typeof value !== "object") return JSON.stringify(value);
    if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
    return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(",")}}`;
  }

  function contentFingerprint(value) {
    const text = stableStringify(value);
    let first = 0x811c9dc5;
    let second = 0x9e3779b9;
    for (let index = 0; index < text.length; index += 1) {
      const code = text.charCodeAt(index);
      first ^= code;
      first = Math.imul(first, 0x01000193) >>> 0;
      second ^= code + index;
      second = Math.imul(second, 0x85ebca6b) >>> 0;
    }
    return `${first.toString(16).padStart(8, "0")}${second.toString(16).padStart(8, "0")}`;
  }

  function scanSensitive(value) {
    const findings = [];
    const seen = typeof WeakSet === "function" ? new WeakSet() : null;
    function visit(current, path) {
      if (current == null) return;
      if (typeof current === "string") {
        if (SENSITIVE_TEXT_PATTERNS.some(pattern => pattern.test(current))) {
          findings.push({ path, reason: "sensitive-text" });
        }
        return;
      }
      if (typeof current !== "object") return;
      if (seen) {
        if (seen.has(current)) return;
        seen.add(current);
      }
      for (const key of Object.keys(current)) {
        const childPath = path ? `${path}.${key}` : key;
        if (SENSITIVE_KEY_PATTERN.test(key)) findings.push({ path: childPath, reason: "sensitive-key" });
        visit(current[key], childPath);
      }
    }
    visit(value, "$");
    return findings;
  }

  function assertSensitiveFree(value) {
    const findings = scanSensitive(value);
    if (findings.length) {
      const paths = findings.slice(0, 5).map(item => item.path).join(", ");
      throw errorWithCode("SENSITIVE_DATA", `禁止持久化认证或签名字段: ${paths}`);
    }
    return true;
  }

  function recordIsSuccessful(record) {
    const state = String(record?.captureState || "").toLowerCase();
    const status = Number(record?.status ?? record?.response?.status ?? 200);
    return state !== "failed"
      && state !== "truncated"
      && record?.truncated !== true
      && Number.isFinite(status)
      && status >= 200
      && status < 300;
  }

  function apiResponseIsSuccessful(body) {
    if (!body || typeof body !== "object") return false;
    if (!body.info || typeof body.info !== "object") return true;
    const code = Number(body.info.code ?? 0);
    return body.info.ok !== false && code === 0;
  }

  function normalizeRange(value) {
    const source = value || {};
    const startDate = source.startDate == null ? null : String(source.startDate);
    const endDate = source.endDate == null ? null : String(source.endDate);
    if (!startDate || !endDate) throw errorWithCode("INVALID_RANGE_RESPONSE", "date/range 缺少 startDate 或 endDate");
    parseDate(startDate);
    parseDate(endDate);
    const compareStartDate = source.compareStartDate == null ? null : String(source.compareStartDate);
    const compareEndDate = source.compareEndDate == null ? null : String(source.compareEndDate);
    if (compareStartDate != null) parseDate(compareStartDate);
    if (compareEndDate != null) parseDate(compareEndDate);
    return { startDate, endDate, compareStartDate, compareEndDate };
  }

  function normalizeMarket(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      throw errorWithCode("INVALID_OVERVIEW_RESPONSE", "market/overview 缺少 data.product.market");
    }
    const output = {};
    let knownFieldCount = 0;
    for (const field of MARKET_FIELDS) {
      const present = Object.prototype.hasOwnProperty.call(value, field) && value[field] !== undefined;
      if (present) knownFieldCount += 1;
      output[field] = present ? clone(value[field]) : null;
    }
    if (knownFieldCount === 0) {
      throw errorWithCode("INVALID_OVERVIEW_RESPONSE", "market/overview 未返回任何已知市场字段");
    }
    return output;
  }

  function normalizeCategoryMetadata(value) {
    const source = value && typeof value === "object" ? value : {};
    const explicitPath = Array.isArray(source.categoryPath)
      ? source.categoryPath
        .map(part => String(part || "").replace(/[\u0000-\u001f\u007f「」『』]/g, " ").replace(/\s+/g, " ").trim().slice(0, 80))
        .filter(Boolean)
        .slice(0, 8)
      : [];
    if (explicitPath.length) return {
      categoryPath: explicitPath,
      categoryName: String(source.categoryName || explicitPath.at(-1)).trim().slice(0, 80),
      categoryDisplayName: explicitPath.join(" / ")
    };
    const title = String(source?.dataInsight?.title || source?.title || "")
      .replace(/[\u0000-\u001f\u007f]/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 300);
    const matched = title.match(/[「『]([^」』]+)[」』]\s*类目/) || title.match(/^(.+?)\s*类目(?:市场|增长|分析)/);
    const rawPath = String(matched?.[1] || "").trim();
    if (!rawPath) return null;
    const categoryPath = rawPath
      .split(/\s*(?:\/|>|＞|→)\s*/)
      .map(part => part.replace(/[「」『』]/g, "").trim().slice(0, 80))
      .filter(Boolean)
      .slice(0, 8);
    if (!categoryPath.length) return null;
    return {
      categoryPath,
      categoryName: categoryPath.at(-1),
      categoryDisplayName: categoryPath.join(" / ")
    };
  }

  function captureContent(capture) {
    return capture.endpoint === RANGE_PATH ? capture.response.range : capture.response.market;
  }

  function sanitizeCaptureRecord(record, options) {
    const input = record || {};
    const config = options || {};
    if (input.schemaVersion === CAPTURE_SCHEMA_VERSION) {
      const endpoint = canonicalEndpoint(input.endpoint);
      if (!ENDPOINTS.includes(endpoint)) return null;
      const request = input.request || {};
      const cateId = String(request.cateId ?? config.cateId ?? "");
      const periodType = String(request.periodType ?? "");
      const requestDate = String(request.requestDate ?? request.date ?? "");
      const taskId = makeTaskId(cateId, periodType, requestDate);
      const response = endpoint === RANGE_PATH
        ? { range: normalizeRange(input.response?.range) }
        : { market: normalizeMarket(input.response?.market) };
      const category = endpoint === OVERVIEW_PATH
        ? normalizeCategoryMetadata(input.category || input.response?.category)
        : null;
      const capturedAt = isoNow(input.capturedAt ?? config.now);
      const safe = {
        schemaVersion: CAPTURE_SCHEMA_VERSION,
        endpoint,
        capturedAt,
        taskId,
        request: { cateId, periodType, requestDate },
        response,
        ...(category ? { category } : {}),
        contentFingerprint: contentFingerprint(response),
        occurrences: Math.max(1, Number(input.occurrences) || 1),
        firstCapturedAt: isoNow(input.firstCapturedAt ?? capturedAt),
        lastCapturedAt: isoNow(input.lastCapturedAt ?? capturedAt)
      };
      assertSensitiveFree(safe);
      return safe;
    }

    const endpoint = endpointOf(input);
    if (!ENDPOINTS.includes(endpoint)) return null;
    if (!recordIsSuccessful(input)) throw errorWithCode("CAPTURE_INCOMPLETE", `${endpoint} 响应失败或被截断`);
    const body = responsePayload(input);
    if (!apiResponseIsSuccessful(body)) throw errorWithCode("API_RESPONSE_FAILED", `${endpoint} 业务响应失败`);

    let cateId;
    let periodType;
    let requestDate;
    let response;
    if (endpoint === RANGE_PATH) {
      const request = publicRangeRequest(input);
      cateId = String(config.cateId ?? input.cateId ?? "");
      periodType = String(request.periodType ?? "");
      requestDate = String(request.requestDate ?? "");
      response = { range: normalizeRange(body?.data) };
    } else {
      const request = requestPayload(input);
      cateId = String(request.cateId ?? config.cateId ?? "");
      periodType = String(request.periodType ?? "");
      requestDate = String(request.date ?? request.requestDate ?? "");
      response = { market: normalizeMarket(body?.data?.product?.market) };
    }
    const taskId = makeTaskId(cateId, periodType, requestDate);
    const capturedAt = isoNow(input.capturedAt ?? config.now);
    const safe = {
      schemaVersion: CAPTURE_SCHEMA_VERSION,
      endpoint,
      capturedAt,
      taskId,
      request: { cateId, periodType, requestDate },
      response,
      ...(endpoint === OVERVIEW_PATH && normalizeCategoryMetadata(body?.data)
        ? { category: normalizeCategoryMetadata(body.data) }
        : {}),
      contentFingerprint: contentFingerprint(response),
      occurrences: 1,
      firstCapturedAt: capturedAt,
      lastCapturedAt: capturedAt
    };
    assertSensitiveFree(safe);
    return safe;
  }

  function validateManifest(manifest) {
    if (!manifest || manifest.schemaVersion !== MANIFEST_SCHEMA_VERSION) {
      throw errorWithCode("INVALID_MANIFEST", `manifest.schemaVersion 必须是 ${MANIFEST_SCHEMA_VERSION}`);
    }
    const cateId = String(manifest.cateId || "");
    const periodType = String(manifest.periodType || "");
    if (!Array.isArray(manifest.tasks) || manifest.tasks.length !== Number(manifest.taskCount)) {
      throw errorWithCode("INVALID_MANIFEST", "manifest 任务数量不一致");
    }
    const seen = new Set();
    for (const task of manifest.tasks) {
      const taskId = makeTaskId(cateId, periodType, task.requestDate);
      if (task.taskId !== taskId || seen.has(taskId)) throw errorWithCode("INVALID_MANIFEST", `无效或重复任务: ${task.taskId}`);
      if (task.expectedStartDate !== addDays(task.requestDate, -6) || task.expectedEndDate !== task.requestDate) {
        throw errorWithCode("INVALID_MANIFEST", `任务边界不符合滚动7天: ${task.taskId}`);
      }
      seen.add(taskId);
    }
    return true;
  }

  function createQueueState(manifest, options) {
    validateManifest(manifest);
    const input = options || {};
    const now = isoNow(input.now);
    const state = {
      schemaVersion: DATASET_SCHEMA_VERSION,
      kind: "queue-state",
      stateVersion: 1,
      createdAt: now,
      updatedAt: now,
      startedAt: null,
      pausedAt: null,
      stoppedAt: null,
      completedAt: null,
      queueStatus: "idle",
      currentTaskId: null,
      nextAllowedAt: null,
      cateId: String(manifest.cateId),
      periodType: String(manifest.periodType),
      analysisRange: clone(manifest.analysisRange),
      requestedAnalysisRange: clone(manifest.analysisRange),
      queryRange: clone(manifest.queryRange),
      requestedQueryRange: clone(manifest.queryRange),
      config: {
        concurrency: 1,
        maxRetries: positiveInteger(input.maxRetries, 2, 10),
        retryBaseMs: positiveInteger(input.retryBaseMs, 1500, 600000),
        minIntervalMs: positiveInteger(input.minIntervalMs, 1200, 600000),
        estimatedTaskMs: positiveInteger(input.estimatedTaskMs, 2500, 3600000),
        tailConfirmationRounds: Math.max(1, positiveInteger(input.tailConfirmationRounds, 3, 3)),
        maxObservedLagDays: Math.max(1, positiveInteger(input.maxObservedLagDays, 2, 2))
      },
      tasks: manifest.tasks.map(task => ({
        sequence: Number(task.sequence),
        taskId: task.taskId,
        cateId: String(task.cateId),
        periodType: String(task.periodType),
        requestDate: task.requestDate,
        expectedStartDate: task.expectedStartDate,
        expectedEndDate: task.expectedEndDate,
        status: "pending",
        attempts: 0,
        lastStartedAt: null,
        lastFinishedAt: null,
        nextRetryAt: null,
        durationMs: null,
        lastError: null
      })),
      captures: [],
      ingestion: {
        acceptedCount: 0,
        duplicateCount: 0,
        irrelevantCount: 0,
        rejectedCount: 0
      },
      lastError: null
    };
    assertSensitiveFree(state);
    return state;
  }

  function validateQueueState(state) {
    if (!state || state.schemaVersion !== DATASET_SCHEMA_VERSION || state.kind !== "queue-state") {
      throw errorWithCode("INVALID_STATE", "不是有效的 dmp-market-rolling7/1.0 队列状态");
    }
    if (!QUEUE_STATUSES.includes(state.queueStatus)) throw errorWithCode("INVALID_STATE", "queueStatus 无效");
    if (!Array.isArray(state.tasks) || !Array.isArray(state.captures)) throw errorWithCode("INVALID_STATE", "tasks/captures 缺失");
    for (const task of state.tasks) {
      if (!TASK_STATUSES.includes(task.status)) throw errorWithCode("INVALID_STATE", `任务状态无效: ${task.status}`);
      if (task.taskId !== makeTaskId(state.cateId, state.periodType, task.requestDate)) {
        throw errorWithCode("INVALID_STATE", `任务主键不匹配: ${task.taskId}`);
      }
    }
    assertSensitiveFree(state);
    return true;
  }

  function touch(state, now) {
    state.updatedAt = isoNow(now);
    return state;
  }

  function startQueue(state, options) {
    validateQueueState(state);
    const next = clone(state);
    if (next.queueStatus === "completed") return next;
    if (next.queueStatus === "stopped" && !options?.restartStopped) {
      throw errorWithCode("QUEUE_STOPPED", "已停止的队列需显式 restartStopped 才能重新开始");
    }
    if (next.queueStatus === "stopped") {
      for (const task of next.tasks) if (task.status === "stopped") task.status = "pending";
      next.stoppedAt = null;
    }
    const now = isoNow(options?.now);
    next.queueStatus = "running";
    next.startedAt = next.startedAt || now;
    next.pausedAt = null;
    next.lastError = null;
    maybeCompleteQueue(next, now);
    return touch(next, now);
  }

  function pauseQueue(state, options) {
    validateQueueState(state);
    const next = clone(state);
    if (next.queueStatus !== "running") return next;
    const now = isoNow(options?.now);
    next.queueStatus = "paused";
    next.pausedAt = now;
    return touch(next, now);
  }

  function resumeQueue(state, options) {
    validateQueueState(state);
    if (state.queueStatus === "stopped") return startQueue(state, { ...options, restartStopped: options?.restartStopped === true });
    const next = clone(state);
    if (next.queueStatus === "completed") return next;
    const now = isoNow(options?.now);
    next.queueStatus = "running";
    next.startedAt = next.startedAt || now;
    next.pausedAt = null;
    maybeCompleteQueue(next, now);
    return touch(next, now);
  }

  function stopQueue(state, options) {
    validateQueueState(state);
    const next = clone(state);
    if (next.queueStatus === "completed" || next.queueStatus === "stopped") return next;
    const now = isoNow(options?.now);
    const active = next.tasks.find(task => task.taskId === next.currentTaskId && task.status === "running");
    if (active) {
      active.status = "stopped";
      active.lastFinishedAt = now;
      active.durationMs = Math.max(0, timestamp(now) - timestamp(active.lastStartedAt));
    }
    next.currentTaskId = null;
    next.queueStatus = "stopped";
    next.stoppedAt = now;
    return touch(next, now);
  }

  function queueDelaySatisfied(state, now) {
    return !state.nextAllowedAt || timestamp(state.nextAllowedAt) <= timestamp(now);
  }

  function nextTask(state, options) {
    validateQueueState(state);
    if (state.queueStatus !== "running") return null;
    const now = isoNow(options?.now);
    const current = state.tasks.find(task => task.taskId === state.currentTaskId && task.status === "running");
    if (current) return clone(current);
    if (!queueDelaySatisfied(state, now)) return null;
    const eligible = state.tasks
      .filter(task => task.status === "pending" || (task.status === "retry-wait" && (!task.nextRetryAt || timestamp(task.nextRetryAt) <= timestamp(now))))
      .sort((left, right) => left.sequence - right.sequence);
    return eligible.length ? clone(eligible[0]) : null;
  }

  function beginTask(state, taskId, options) {
    validateQueueState(state);
    if (state.queueStatus !== "running") throw errorWithCode("QUEUE_NOT_RUNNING", "队列未运行");
    const now = isoNow(options?.now);
    if (!queueDelaySatisfied(state, now)) throw errorWithCode("QUEUE_THROTTLED", "低频间隔尚未结束");
    const next = clone(state);
    const other = next.tasks.find(task => task.status === "running" && task.taskId !== taskId);
    if (other) throw errorWithCode("SINGLE_CONCURRENCY", "滚动7天队列仅允许单任务运行");
    const task = next.tasks.find(item => item.taskId === taskId);
    if (!task) throw errorWithCode("TASK_NOT_FOUND", `任务不存在: ${taskId}`);
    const retryReady = task.status === "retry-wait" && (!task.nextRetryAt || timestamp(task.nextRetryAt) <= timestamp(now));
    if (task.status !== "pending" && task.status !== "running" && !retryReady) {
      throw errorWithCode("INVALID_TASK_TRANSITION", `${task.status} 不能进入 running`);
    }
    if (task.status !== "running") task.attempts = Number(task.attempts || 0) + 1;
    task.status = "running";
    task.lastStartedAt = task.lastStartedAt && state.currentTaskId === taskId ? task.lastStartedAt : now;
    task.lastFinishedAt = null;
    task.nextRetryAt = null;
    task.lastError = null;
    next.currentTaskId = taskId;
    next.lastError = null;
    return touch(next, now);
  }

  function beginNextTask(state, options) {
    const task = nextTask(state, options);
    return task ? beginTask(state, task.taskId, options) : clone(state);
  }

  function claimNextTask(state, options) {
    const task = nextTask(state, options);
    if (!task) return { state: clone(state), task: null };
    const claimed = beginTask(state, task.taskId, options);
    return { state: claimed, task: clone(claimed.tasks.find(item => item.taskId === task.taskId)) };
  }

  function redactErrorMessage(value) {
    let text = String(value == null ? "请求失败" : value).slice(0, 600);
    text = text.replace(/https?:\/\/\S+/gi, "[请求地址已移除]");
    text = text.replace(/(?:cookie|set-cookie|authorization)\s*:[^,;\n]*/gi, "[认证信息已移除]");
    text = text.replace(/(?:_tb_token_|_csrf|csrfId|dynamicToken|webOpSessionId|token|signature|sign|secret|password|sessionid)\s*[=:]\s*[^&\s,;]*/gi, "[认证参数已移除]");
    return SENSITIVE_TEXT_PATTERNS.some(pattern => pattern.test(text)) ? "请求失败（认证信息已移除）" : text.slice(0, 300);
  }

  function safeError(error) {
    const codeText = typeof error === "object" && error ? String(error.code || error.name || "REQUEST_FAILED") : "REQUEST_FAILED";
    const code = /^[A-Za-z0-9_-]{1,64}$/.test(codeText) ? codeText : "REQUEST_FAILED";
    const message = redactErrorMessage(typeof error === "object" && error ? error.message : error);
    return { code, message };
  }

  function recordTaskFailure(state, taskId, error, options) {
    validateQueueState(state);
    const now = isoNow(options?.now);
    const next = clone(state);
    const task = next.tasks.find(item => item.taskId === taskId);
    if (!task) throw errorWithCode("TASK_NOT_FOUND", `任务不存在: ${taskId}`);
    if (task.status !== "running") task.attempts = Number(task.attempts || 0) + 1;
    const persistedError = safeError(error);
    const maxRetries = Number(next.config.maxRetries || 0);
    const canRetry = Number(task.attempts || 0) <= maxRetries;
    const exponential = Number(next.config.retryBaseMs || 0) * Math.pow(2, Math.max(0, Number(task.attempts || 1) - 1));
    const retryAfterMs = positiveInteger(options?.retryAfterMs, exponential, 3600000);
    task.status = canRetry ? "retry-wait" : "failed";
    task.lastFinishedAt = now;
    task.durationMs = task.lastStartedAt ? Math.max(0, timestamp(now) - timestamp(task.lastStartedAt)) : null;
    task.nextRetryAt = canRetry ? new Date(timestamp(now) + retryAfterMs).toISOString() : null;
    task.lastError = persistedError;
    next.currentTaskId = next.currentTaskId === taskId ? null : next.currentTaskId;
    next.lastError = persistedError;
    const delay = Math.max(Number(next.config.minIntervalMs || 0), canRetry ? retryAfterMs : 0);
    next.nextAllowedAt = new Date(timestamp(now) + delay).toISOString();
    maybeCompleteQueue(next, now);
    assertSensitiveFree(next);
    return touch(next, now);
  }

  function unavailableTailRequiredRounds(options) {
    const value = Number(options?.requiredRounds);
    return Number.isInteger(value) && value >= 1 ? Math.min(3, value) : 1;
  }

  function calendarDayDistance(earlierDate, laterDate) {
    return Math.round((parseDate(laterDate).valueOf() - parseDate(earlierDate).valueOf()) / 86400000);
  }

  function unavailableTailAssessment(reason, values) {
    const requiredRounds = unavailableTailRequiredRounds(values?.options);
    const observedRounds = Math.max(0, Math.min(3, Number(values?.observedRounds) || 0));
    return {
      eligible: values?.eligible === true,
      reason: String(reason || "not-eligible"),
      requiredRounds,
      observedRounds,
      remainingRounds: Math.max(0, requiredRounds - observedRounds),
      targetDate: values?.targetDate || null,
      lastAvailableWindowDate: values?.lastAvailableWindowDate || null,
      observedLagDays: Number.isInteger(values?.observedLagDays) ? values.observedLagDays : null,
      tailSignature: values?.tailSignature || ""
    };
  }

  function assessUnavailableTail(state, taskId, error, options) {
    validateQueueState(state);
    const input = options || {};
    const persistedError = safeError(error || state.lastError);
    const ordered = [...state.tasks].sort((left, right) => left.sequence - right.sequence);
    const target = taskId
      ? ordered.find(task => task.taskId === taskId)
      : ordered.find(task => task.status !== "completed");
    const base = {
      options: input,
      targetDate: target?.requestDate || null
    };
    if (!target) return unavailableTailAssessment("target-not-found", base);
    const supportedError = persistedError.code === "MARKET_DATA_UNAVAILABLE"
      || (persistedError.code === "API_ERROR" && input.allowLegacyApiError === true);
    if (!supportedError) return unavailableTailAssessment("unsupported-error", base);

    const targetIndex = ordered.findIndex(task => task.taskId === target.taskId);
    if (targetIndex <= 0) return unavailableTailAssessment("no-completed-prefix", base);
    if (!["pending", "running", "retry-wait"].includes(target.status)) {
      return unavailableTailAssessment("target-terminal", base);
    }

    const prior = ordered.slice(0, targetIndex);
    const later = ordered.slice(targetIndex + 1);
    const lastCompleted = prior.at(-1);
    base.lastAvailableWindowDate = lastCompleted?.requestDate || null;
    if (prior.some(task => task.status !== "completed")) {
      return unavailableTailAssessment("prefix-not-continuous", base);
    }
    if (later.some(task => task.status !== "pending")) {
      return unavailableTailAssessment("suffix-not-pristine", base);
    }
    const laterIds = new Set(later.map(task => task.taskId));
    if (state.captures.some(capture => laterIds.has(capture.taskId))) {
      return unavailableTailAssessment("suffix-has-captures", base);
    }

    const requestedRange = clone(state.requestedAnalysisRange || state.analysisRange);
    const requestedEnd = String(requestedRange?.endDate || "");
    if (!requestedEnd) return unavailableTailAssessment("requested-end-missing", base);
    parseDate(requestedEnd);
    const currentDate = String(input.currentDate || isoNow(input.now).slice(0, 10));
    parseDate(currentDate);
    const observedLagDays = calendarDayDistance(lastCompleted.requestDate, currentDate);
    base.observedLagDays = observedLagDays;

    const analysisAlreadyComplete = target.requestDate > requestedEnd;
    if (!analysisAlreadyComplete) {
      const maxAnalysisTailDays = Math.max(1, Math.min(2, positiveInteger(input.maxAnalysisTailDays, 2, 2)));
      const missingAnalysisDays = calendarDayDistance(target.requestDate, requestedEnd) + 1;
      if (missingAnalysisDays < 1 || missingAnalysisDays > maxAnalysisTailDays) {
        return unavailableTailAssessment("analysis-tail-too-wide", base);
      }
      const maxLagDays = Math.max(1, Math.min(2, positiveInteger(input.maxLagDays, 2, 2)));
      if (observedLagDays < 0 || observedLagDays > maxLagDays) {
        return unavailableTailAssessment("outside-current-lag", base);
      }
    }

    const effectiveEnd = lastCompleted.requestDate < requestedEnd ? lastCompleted.requestDate : requestedEnd;
    if (effectiveEnd < String(state.analysisRange?.startDate || "")) {
      return unavailableTailAssessment("effective-range-empty", base);
    }

    const requiredRounds = unavailableTailRequiredRounds(input);
    const tailSignature = [
      state.cateId,
      state.periodType,
      target.requestDate,
      lastCompleted.requestDate,
      requestedEnd,
      persistedError.code,
      requiredRounds
    ].join("|");
    const probe = state.unavailableTailProbe;
    const observedRounds = probe?.tailSignature === tailSignature
      ? Math.max(0, Math.min(3, Number(probe.observedRounds) || 0))
      : 0;
    return unavailableTailAssessment(
      analysisAlreadyComplete ? "right-padding-tail" : "recent-analysis-tail",
      {
        ...base,
        eligible: true,
        observedRounds,
        tailSignature
      }
    );
  }

  function recordUnavailableTailProbe(state, taskId, error, options) {
    validateQueueState(state);
    const assessment = assessUnavailableTail(state, taskId, error, options);
    const next = clone(state);
    if (!assessment.eligible) {
      delete next.unavailableTailProbe;
      return next;
    }
    const now = isoNow(options?.now);
    const existing = next.unavailableTailProbe;
    const sameTail = existing?.tailSignature === assessment.tailSignature;
    const observedRounds = Math.min(
      assessment.requiredRounds,
      sameTail ? Math.max(0, Number(existing.observedRounds) || 0) + 1 : 1
    );
    next.unavailableTailProbe = {
      tailSignature: assessment.tailSignature,
      targetTaskId: taskId || next.tasks.find(task => task.requestDate === assessment.targetDate)?.taskId || null,
      targetDate: assessment.targetDate,
      lastAvailableWindowDate: assessment.lastAvailableWindowDate,
      observedLagDays: assessment.observedLagDays,
      requiredRounds: assessment.requiredRounds,
      observedRounds,
      errorCode: safeError(error || next.lastError).code,
      firstObservedAt: sameTail && existing?.firstObservedAt ? existing.firstObservedAt : now,
      lastObservedAt: now
    };
    assertSensitiveFree(next);
    return touch(next, now);
  }

  function finalizeUnavailableTail(state, taskId, error, options) {
    validateQueueState(state);
    const probed = recordUnavailableTailProbe(state, taskId, error, options);
    const assessment = assessUnavailableTail(probed, taskId, error, options);
    if (!assessment.eligible || assessment.remainingRounds > 0) return probed;

    const next = clone(probed);
    const persistedError = safeError(error || next.lastError);
    const ordered = [...next.tasks].sort((left, right) => left.sequence - right.sequence);
    const target = ordered.find(task => task.requestDate === assessment.targetDate);
    const targetIndex = ordered.findIndex(task => task.taskId === target?.taskId);
    const prior = ordered.slice(0, targetIndex);
    const lastCompleted = prior.at(-1);
    const requestedRange = clone(next.requestedAnalysisRange || next.analysisRange);
    const requestedEnd = String(requestedRange?.endDate || "");
    const effectiveEnd = lastCompleted.requestDate < requestedEnd ? lastCompleted.requestDate : requestedEnd;

    const now = isoNow(options?.now);
    const retainedIds = new Set(prior.map(task => task.taskId));
    const omittedTaskCount = ordered.length - prior.length;
    next.tasks = prior;
    next.captures = next.captures.filter(capture => retainedIds.has(capture.taskId));
    next.requestedAnalysisRange = requestedRange;
    next.requestedQueryRange = clone(next.requestedQueryRange || next.queryRange);
    next.analysisRange = { ...next.analysisRange, endDate: effectiveEnd };
    next.queryRange = { ...next.queryRange, endDate: lastCompleted.requestDate };
    next.currentTaskId = null;
    next.nextAllowedAt = null;
    next.queueStatus = "completed";
    next.completedAt = now;
    next.pausedAt = null;
    next.stoppedAt = null;
    next.lastError = null;
    next.tailClosure = {
      reason: "trailing-data-unavailable",
      requestedAnalysisEndDate: requestedEnd,
      effectiveAnalysisEndDate: effectiveEnd,
      lastAvailableWindowDate: lastCompleted.requestDate,
      omittedTaskCount,
      errorCode: persistedError.code,
      requiredRounds: assessment.requiredRounds,
      observedRounds: assessment.observedRounds,
      observedLagDays: assessment.observedLagDays,
      tailSignature: assessment.tailSignature,
      closedAt: now
    };
    delete next.unavailableTailProbe;
    assertSensitiveFree(next);
    return touch(next, now);
  }

  function groupCaptures(captures) {
    const groups = new Map();
    for (const capture of captures || []) {
      if (!groups.has(capture.taskId)) groups.set(capture.taskId, { range: [], overview: [] });
      const group = groups.get(capture.taskId);
      if (capture.endpoint === RANGE_PATH) group.range.push(capture);
      if (capture.endpoint === OVERVIEW_PATH) group.overview.push(capture);
    }
    for (const group of groups.values()) {
      group.range.sort((a, b) => String(a.contentFingerprint).localeCompare(String(b.contentFingerprint)));
      group.overview.sort((a, b) => String(a.contentFingerprint).localeCompare(String(b.contentFingerprint)));
    }
    return groups;
  }

  function boundaryMatches(task, range) {
    return Boolean(task && range
      && task.expectedStartDate === range.startDate
      && task.expectedEndDate === range.endDate);
  }

  function terminalStatusFor(task, group) {
    if (!group) return null;
    if (group.range.length > 1 || group.overview.length > 1) return "conflict";
    if (group.range.length === 1 && group.overview.length === 1) {
      return boundaryMatches(task, group.range[0].response.range) ? "completed" : "boundary-mismatch";
    }
    return null;
  }

  function refreshTaskFromCaptures(state, taskId, now) {
    const task = state.tasks.find(item => item.taskId === taskId);
    if (!task) return;
    const group = groupCaptures(state.captures).get(taskId);
    const terminal = terminalStatusFor(task, group);
    if (!terminal) return;
    task.status = terminal;
    task.lastFinishedAt = now;
    task.nextRetryAt = null;
    task.lastError = null;
    if (task.lastStartedAt) task.durationMs = Math.max(0, timestamp(now) - timestamp(task.lastStartedAt));
    if (state.currentTaskId === taskId) state.currentTaskId = null;
    state.nextAllowedAt = new Date(timestamp(now) + Number(state.config.minIntervalMs || 0)).toISOString();
    if (state.unavailableTailProbe?.targetTaskId === taskId) delete state.unavailableTailProbe;
  }

  function maybeCompleteQueue(state, now) {
    const allCompleted = state.tasks.length > 0 && state.tasks.every(task => task.status === "completed");
    const blocking = state.tasks.find(task => task.status === "conflict")
      || state.tasks.find(task => task.status === "boundary-mismatch")
      || state.tasks.find(task => task.status === "failed");
    if (state.queueStatus === "running" && allCompleted) {
      state.queueStatus = "completed";
      state.completedAt = now;
      state.currentTaskId = null;
      state.pausedAt = null;
    } else if ((state.queueStatus === "running" || state.queueStatus === "completed") && blocking && !allCompleted) {
      state.queueStatus = "paused";
      state.pausedAt = now;
      state.completedAt = null;
      state.currentTaskId = null;
      if (!state.lastError && blocking) {
        const fallback = blocking.status === "conflict"
          ? { code: "RESPONSE_CONFLICT", message: "核心响应存在冲突，队列已暂停" }
          : blocking.status === "boundary-mismatch"
            ? { code: "BOUNDARY_MISMATCH", message: "滚动窗口边界不一致，队列已暂停" }
            : { code: "TASK_FAILED", message: "滚动窗口重试后仍失败，队列已暂停" };
        state.lastError = blocking.lastError || fallback;
      }
    }
    return state;
  }

  function ingestCapture(state, record, options) {
    validateQueueState(state);
    const next = clone(state);
    const now = isoNow(options?.now);
    let capture;
    try {
      capture = sanitizeCaptureRecord(record, { cateId: next.cateId, now });
    } catch (error) {
      // Other period tabs may emit the same endpoints while the rolling-7 queue is active.
      // They are out of scope, not collection failures.
      if (error?.code === "INVALID_PERIOD_TYPE") {
        next.ingestion.irrelevantCount = Number(next.ingestion.irrelevantCount || 0) + 1;
        return touch(next, now);
      }
      next.ingestion.rejectedCount = Number(next.ingestion.rejectedCount || 0) + 1;
      next.lastError = safeError(error);
      assertSensitiveFree(next);
      return touch(next, now);
    }
    if (!capture) {
      next.ingestion.irrelevantCount = Number(next.ingestion.irrelevantCount || 0) + 1;
      return touch(next, now);
    }
    if (capture.request.cateId !== next.cateId || capture.request.periodType !== next.periodType) {
      next.ingestion.irrelevantCount = Number(next.ingestion.irrelevantCount || 0) + 1;
      return touch(next, now);
    }
    const existing = next.captures.find(item => item.taskId === capture.taskId
      && item.endpoint === capture.endpoint
      && stableStringify(captureContent(item)) === stableStringify(captureContent(capture)));
    if (existing) {
      existing.occurrences = Number(existing.occurrences || 1) + Number(capture.occurrences || 1);
      existing.firstCapturedAt = [existing.firstCapturedAt, capture.firstCapturedAt].filter(Boolean).sort()[0] || now;
      existing.lastCapturedAt = [existing.lastCapturedAt, capture.lastCapturedAt].filter(Boolean).sort().at(-1) || now;
      next.ingestion.duplicateCount = Number(next.ingestion.duplicateCount || 0) + 1;
    } else {
      next.captures.push(capture);
      next.captures.sort((left, right) => left.taskId.localeCompare(right.taskId)
        || left.endpoint.localeCompare(right.endpoint)
        || left.contentFingerprint.localeCompare(right.contentFingerprint));
      next.ingestion.acceptedCount = Number(next.ingestion.acceptedCount || 0) + 1;
    }
    next.lastError = null;
    refreshTaskFromCaptures(next, capture.taskId, now);
    maybeCompleteQueue(next, now);
    assertSensitiveFree(next);
    return touch(next, now);
  }

  function recordsOf(value) {
    if (Array.isArray(value)) return value;
    for (const key of ["records", "entries", "requests", "responses", "logs", "items"]) {
      if (Array.isArray(value?.[key])) return value[key];
    }
    if (Array.isArray(value?.log?.entries)) return value.log.entries;
    return value == null ? [] : [value];
  }

  function ingestCaptures(state, records, options) {
    let next = clone(state);
    for (const record of recordsOf(records)) next = ingestCapture(next, record, options);
    return next;
  }

  function restoreQueueState(snapshot, options) {
    const next = clone(snapshot);
    validateQueueState(next);
    const now = isoNow(options?.now);
    const maxRetries = Number(next.config.maxRetries || 0);
    for (const task of next.tasks) {
      if (task.status !== "running") continue;
      if (Number(task.attempts || 0) <= maxRetries) {
        task.status = "retry-wait";
        task.nextRetryAt = now;
      } else {
        task.status = "failed";
        task.nextRetryAt = null;
      }
      task.lastFinishedAt = now;
      task.durationMs = task.lastStartedAt ? Math.max(0, timestamp(now) - timestamp(task.lastStartedAt)) : null;
      task.lastError = { code: "INTERRUPTED", message: "任务中断，已从本地断点恢复" };
    }
    next.currentTaskId = null;
    if (next.queueStatus === "running") next.queueStatus = options?.autoResume ? "running" : "paused";
    if (next.queueStatus === "paused" && options?.autoResume) next.queueStatus = "running";
    next.pausedAt = next.queueStatus === "paused" ? now : null;
    refreshAllTasks(next, now);
    maybeCompleteQueue(next, now);
    assertSensitiveFree(next);
    return touch(next, now);
  }

  function refreshAllTasks(state, now) {
    const groups = groupCaptures(state.captures);
    for (const task of state.tasks) {
      const terminal = terminalStatusFor(task, groups.get(task.taskId));
      if (!terminal) continue;
      task.status = terminal;
      task.lastFinishedAt = task.lastFinishedAt || now;
      task.nextRetryAt = null;
      task.lastError = null;
      if (state.unavailableTailProbe?.targetTaskId === task.taskId) delete state.unavailableTailProbe;
    }
    return state;
  }

  function createCheckpoint(state) {
    validateQueueState(state);
    const output = clone(state);
    assertSensitiveFree(output);
    return output;
  }

  function serializeCheckpoint(state, spacing) {
    return JSON.stringify(createCheckpoint(state), null, spacing == null ? 0 : spacing);
  }

  function unitMultiplier(unit) {
    if (unit === "亿") return 100000000;
    if (unit === "万") return 10000;
    if (unit === "千") return 1000;
    return 1;
  }

  function parseScaledNumber(value, inheritedUnit) {
    const match = String(value == null ? "" : value).trim().match(/^([+-]?\d+(?:\.\d+)?)\s*(亿|万|千)?$/);
    if (!match) return null;
    return Number(match[1]) * unitMultiplier(match[2] || inheritedUnit || "");
  }

  function parseInterval(raw) {
    if (raw === null || raw === undefined || raw === "") return null;
    if (typeof raw === "number" && Number.isFinite(raw)) {
      return { raw, lower: raw, upper: raw, lowerClosed: true, upperClosed: true };
    }
    const text = String(raw).trim().replace(/[,，]/g, "").replace(/～/g, "~");
    const above = text.match(/^([+-]?\d+(?:\.\d+)?)\s*(亿|万|千)?\s*(?:以上|\+)$/);
    if (above) return { raw, lower: Number(above[1]) * unitMultiplier(above[2] || ""), upper: null, lowerClosed: true, upperClosed: false };
    const below = text.match(/^(?:小于|<)\s*([+-]?\d+(?:\.\d+)?)\s*(亿|万|千)?$/);
    if (below) return { raw, lower: 0, upper: Number(below[1]) * unitMultiplier(below[2] || ""), lowerClosed: true, upperClosed: false };
    const range = text.match(/^([+-]?\d+(?:\.\d+)?)\s*(亿|万|千)?\s*~\s*([+-]?\d+(?:\.\d+)?)\s*(亿|万|千)?$/);
    if (range) {
      const sharedUnit = range[4] || range[2] || "";
      return {
        raw,
        lower: parseScaledNumber(`${range[1]}${range[2] || sharedUnit}`, sharedUnit),
        upper: parseScaledNumber(`${range[3]}${range[4] || sharedUnit}`, sharedUnit),
        lowerClosed: true,
        upperClosed: false
      };
    }
    return { raw, lower: null, upper: null, lowerClosed: false, upperClosed: false };
  }

  function buildDataset(state, options) {
    validateQueueState(state);
    const generatedAt = isoNow(options?.now);
    const groups = groupCaptures(state.captures);
    const expectedIds = new Set(state.tasks.map(task => task.taskId));
    const windows = [];
    const conflicts = [];
    const datasetTasks = [];
    const categoryVariants = new Map();

    for (const capture of state.captures) {
      if (capture?.endpoint !== OVERVIEW_PATH || !capture?.category?.categoryDisplayName) continue;
      const key = String(capture.category.categoryDisplayName);
      categoryVariants.set(key, (categoryVariants.get(key) || 0) + Number(capture.occurrences || 1));
    }
    const category = [...categoryVariants.entries()]
      .sort((left, right) => right[1] - left[1] || left[0].localeCompare(right[0]))
      .map(([displayName]) => state.captures.find(capture => capture?.category?.categoryDisplayName === displayName)?.category)
      .find(Boolean) || null;

    for (const task of [...state.tasks].sort((a, b) => a.sequence - b.sequence)) {
      const group = groups.get(task.taskId) || { range: [], overview: [] };
      let status = "missing";
      if (group.range.length > 1 || group.overview.length > 1) {
        status = "conflict";
        conflicts.push({
          taskId: task.taskId,
          requestDate: task.requestDate,
          rangeVariants: group.range.length,
          overviewVariants: group.overview.length,
          rangeFingerprints: group.range.map(item => item.contentFingerprint),
          overviewFingerprints: group.overview.map(item => item.contentFingerprint)
        });
      } else if (group.range.length === 1 && group.overview.length === 1) {
        const rangeCapture = group.range[0];
        const overviewCapture = group.overview[0];
        const range = rangeCapture.response.range;
        const matches = boundaryMatches(task, range);
        status = matches ? "completed" : "boundary-mismatch";
        windows.push({
          taskId: task.taskId,
          sequence: task.sequence,
          requestDate: task.requestDate,
          startDate: range.startDate,
          endDate: range.endDate,
          compareStartDate: range.compareStartDate,
          compareEndDate: range.compareEndDate,
          boundaryMatches: matches,
          rangeCapturedAt: rangeCapture.lastCapturedAt || rangeCapture.capturedAt,
          overviewCapturedAt: overviewCapture.lastCapturedAt || overviewCapture.capturedAt,
          market: clone(overviewCapture.response.market),
          gmvInterval: parseInterval(overviewCapture.response.market.alipayInshopAmt)
        });
      }
      datasetTasks.push({
        sequence: task.sequence,
        taskId: task.taskId,
        cateId: task.cateId,
        periodType: task.periodType,
        requestDate: task.requestDate,
        expectedStartDate: task.expectedStartDate,
        expectedEndDate: task.expectedEndDate,
        status
      });
    }

    const extraDates = [];
    for (const [taskId, group] of groups.entries()) {
      if (expectedIds.has(taskId) || group.range.length !== 1 || group.overview.length !== 1) continue;
      extraDates.push(group.overview[0].request.requestDate);
    }
    windows.sort((a, b) => a.requestDate.localeCompare(b.requestDate));
    conflicts.sort((a, b) => a.requestDate.localeCompare(b.requestDate));
    extraDates.sort();
    const completedTaskCount = datasetTasks.filter(task => task.status === "completed").length;
    const missingDates = datasetTasks.filter(task => task.status === "missing").map(task => task.requestDate);
    const conflictTaskCount = datasetTasks.filter(task => task.status === "conflict").length;
    const boundaryMismatchCount = datasetTasks.filter(task => task.status === "boundary-mismatch").length;
    const expectedTaskCount = datasetTasks.length;
    const dataset = {
      schemaVersion: DATASET_SCHEMA_VERSION,
      kind: "dataset",
      generatedAt,
      cateId: state.cateId,
      ...(category ? {
        categoryPath: clone(category.categoryPath),
        categoryName: category.categoryName,
        categoryDisplayName: category.categoryDisplayName
      } : {}),
      periodType: state.periodType,
      analysisRange: clone(state.analysisRange),
      queryRange: clone(state.queryRange),
      ...(state.tailClosure ? { tailClosure: clone(state.tailClosure) } : {}),
      completeness: {
        expectedTaskCount,
        completedTaskCount,
        missingTaskCount: missingDates.length,
        conflictTaskCount,
        unexpectedWindowCount: extraDates.length,
        boundaryMismatchCount,
        status: expectedTaskCount > 0
          && completedTaskCount === expectedTaskCount
          && conflictTaskCount === 0
          && boundaryMismatchCount === 0
          ? "ready"
          : "incomplete"
      },
      missingDates,
      extraDates,
      conflicts,
      tasks: datasetTasks,
      windows
    };
    assertSensitiveFree(dataset);
    return dataset;
  }

  function getStats(state, options) {
    validateQueueState(state);
    const now = isoNow(options?.now);
    const totalTaskCount = state.tasks.length;
    const completedTaskCount = state.tasks.filter(task => task.status === "completed").length;
    const conflictTaskCount = state.tasks.filter(task => task.status === "conflict").length;
    const boundaryMismatchTaskCount = state.tasks.filter(task => task.status === "boundary-mismatch").length;
    const failedTaskCount = state.tasks.filter(task => task.status === "failed").length;
    const retryingTaskCount = state.tasks.filter(task => task.status === "retry-wait").length;
    const pendingTaskCount = state.tasks.filter(task => task.status === "pending").length;
    const runningTaskCount = state.tasks.filter(task => task.status === "running").length;
    const stoppedTaskCount = state.tasks.filter(task => task.status === "stopped").length;
    const missingTaskCount = totalTaskCount - completedTaskCount - conflictTaskCount - boundaryMismatchTaskCount;
    const remainingTaskCount = pendingTaskCount + retryingTaskCount + runningTaskCount;
    const processedTaskCount = totalTaskCount - remainingTaskCount;
    const durations = state.tasks
      .filter(task => task.durationMs !== null && task.durationMs !== undefined)
      .map(task => Number(task.durationMs))
      .filter(value => Number.isFinite(value) && value >= 0);
    const averageTaskMs = durations.length
      ? Math.round(durations.reduce((sum, value) => sum + value, 0) / durations.length)
      : Number(state.config.estimatedTaskMs || 0);
    const retryWaitMs = state.tasks
      .filter(task => task.status === "retry-wait" && task.nextRetryAt)
      .reduce((sum, task) => sum + Math.max(0, timestamp(task.nextRetryAt) - timestamp(now)), 0);
    const estimatedRemainingMs = Math.max(0, remainingTaskCount * (averageTaskMs + Number(state.config.minIntervalMs || 0)) + retryWaitMs);
    const active = state.tasks.find(task => task.taskId === state.currentTaskId)
      || state.tasks.find(task => task.status === "pending" || task.status === "retry-wait" || task.status === "running")
      || state.tasks.filter(task => TERMINAL_TASK_STATUSES.has(task.status)).sort((a, b) => b.sequence - a.sequence)[0]
      || null;
    const progressPercent = totalTaskCount ? Math.round(processedTaskCount / totalTaskCount * 10000) / 100 : 0;
    return {
      status: state.queueStatus,
      queueStatus: state.queueStatus,
      total: totalTaskCount,
      totalTaskCount,
      completed: completedTaskCount,
      completedTaskCount,
      missing: missingTaskCount,
      missingTaskCount,
      conflicts: conflictTaskCount,
      conflictTaskCount,
      boundaryMismatches: boundaryMismatchTaskCount,
      boundaryMismatchTaskCount,
      failed: failedTaskCount,
      failedTaskCount,
      retrying: retryingTaskCount,
      retryingTaskCount,
      pending: pendingTaskCount,
      pendingTaskCount,
      running: runningTaskCount,
      runningTaskCount,
      stopped: stoppedTaskCount,
      stoppedTaskCount,
      remaining: remainingTaskCount,
      remainingTaskCount,
      processedTaskCount,
      currentTaskId: active?.taskId || null,
      currentDate: active?.requestDate || null,
      progressPercent,
      averageTaskMs,
      estimatedRemainingMs,
      estimatedRemainingSeconds: Math.ceil(estimatedRemainingMs / 1000),
      etaAt: estimatedRemainingMs ? new Date(timestamp(now) + estimatedRemainingMs).toISOString() : null,
      acceptedCaptureCount: Number(state.ingestion?.acceptedCount || 0),
      duplicateCaptureCount: Number(state.ingestion?.duplicateCount || 0),
      rejectedCaptureCount: Number(state.ingestion?.rejectedCount || 0)
    };
  }

  return Object.freeze({
    MANIFEST_SCHEMA_VERSION,
    DATASET_SCHEMA_VERSION,
    CAPTURE_SCHEMA_VERSION,
    RANGE_PATH,
    OVERVIEW_PATH,
    ENDPOINTS,
    MARKET_FIELDS,
    QUEUE_STATUSES,
    TASK_STATUSES,
    parseDate,
    formatDate,
    addDays,
    dateSequence,
    makeTaskId,
    generateManifest,
    canonicalEndpoint,
    parseJsonLike,
    stableStringify,
    contentFingerprint,
    parseInterval,
    normalizeRange,
    normalizeMarket,
    normalizeCategoryMetadata,
    scanSensitive,
    assertSensitiveFree,
    sanitizeCaptureRecord,
    createQueueState,
    startQueue,
    pauseQueue,
    resumeQueue,
    stopQueue,
    nextTask,
    beginTask,
    beginNextTask,
    claimNextTask,
    recordTaskFailure,
    assessUnavailableTail,
    recordUnavailableTailProbe,
    finalizeUnavailableTail,
    ingestCapture,
    ingestCaptures,
    restoreQueueState,
    createCheckpoint,
    serializeCheckpoint,
    buildDataset,
    getStats,
    // Concise aliases for runtime adapters and tests.
    createManifest: generateManifest,
    createState: createQueueState,
    restoreState: restoreQueueState,
    sanitizeRecord: sanitizeCaptureRecord,
    toDataset: buildDataset,
    getQueueStats: getStats
  });
});
