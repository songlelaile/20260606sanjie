import "./report-engine.js";

const activeTabs = new Set();
const attachJobs = new Map();
const requests = new Map();
const sockets = new Map();
const transports = new Map();
const observedResponses = new Map();
const capturedResponses = new Map();

const BODY_LIMIT = 10_000_000;
const SENSITIVE_QUERY = /(token|sign|cookie|authorization|password|secret|session|csrf|dynamicToken|webOpSessionId|uniqueItemCampaign)/i;
const RECORD_DB_NAME = "dmp-cdp-monitor-records";
const RECORD_DB_VERSION = 2;
const DEFAULT_AI_CONFIG = { enabled: true, endpoint: "http://127.0.0.1:8787/report" };
const DEFAULT_PROVIDER_PROFILE = {
  provider: "openai-compatible",
  providerName: "ChatGPT / OpenAI-compatible",
  visionModel: "gpt-5.6-sol",
  textModel: "gpt-5.6-sol",
  baseUrl: "https://api.openai.com/v1",
  hasApiKey: false,
  keySource: "none"
};
const OFFICIAL_SITE = "https://shaozhuangai.com";
const OFFICIAL_SESSION_COOKIE = "sanjie_session";
const OFFICIAL_AUTH_TIMEOUT_MS = 10_000;
const OFFICIAL_AUTH_ALARM = "dmp-official-site-heartbeat";
let recordDbPromise;

async function readOfficialSession() {
  try {
    const cookies = await chrome.cookies.getAll({ name: OFFICIAL_SESSION_COOKIE, domain: "shaozhuangai.com" });
    cookies.sort((left, right) => String(left.domain || "").length - String(right.domain || "").length);
    return cookies.find(cookie => cookie.value)?.value || "";
  } catch {
    return "";
  }
}

async function checkOfficialSiteAccess() {
  const token = await readOfficialSession();
  if (!token) {
    return { ok: false, reason: "nologin", error: "请先登录 shaozhuangai.com，再使用达摩盘自动化" };
  }
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), OFFICIAL_AUTH_TIMEOUT_MS);
  try {
    const response = await fetch(`${OFFICIAL_SITE}/api/auth/me`, {
      method: "GET",
      headers: { "x-sanjie-session": token },
      cache: "no-store",
      signal: controller.signal
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok || !result?.data) {
      const error = response.status === 401
        ? "官网登录已失效，请重新登录 shaozhuangai.com"
        : `官网在线校验失败（HTTP ${response.status}）`;
      return { ok: false, reason: response.status === 401 ? "invalid" : "unavailable", error };
    }
    if (result.data.service?.online !== true || result.data.capabilities?.dmpAutomation !== true) {
      const entitlement = result.data.dmpEntitlement || null;
      const expired = entitlement?.status === "expired";
      return {
        ok: false,
        reason: expired ? "expired" : "denied",
        entitlement,
        error: expired
          ? "达摩盘自动化的 30 天授权已到期，请联系管理员付费续费"
          : "当前官网账号未开通达摩盘自动化权限，请联系管理员付费开通"
      };
    }
    return {
      ok: true,
      user: result.data,
      checkedAt: result.data.service?.checkedAt || new Date().toISOString()
    };
  } catch (error) {
    const timeoutMessage = error?.name === "AbortError" ? "官网在线校验超时" : "官网暂时不可达";
    return { ok: false, reason: "offline", error: `${timeoutMessage}，插件已停止运行` };
  } finally {
    clearTimeout(timeout);
  }
}

async function lockTabForOfficialAuth(tabId, message) {
  if (activeTabs.has(tabId)) {
    await chrome.debugger.detach({ tabId }).catch(() => {});
    activeTabs.delete(tabId);
  }
  await chrome.action.setBadgeBackgroundColor({ tabId, color: "#8a2f2f" }).catch(() => {});
  await chrome.action.setBadgeText({ tabId, text: "LOCK" }).catch(() => {});
  await publishStatus(tabId, false, message);
}

async function verifyOfficialSiteForTab(tabId) {
  const authorization = await checkOfficialSiteAccess();
  if (authorization.ok) return authorization;
  await lockTabForOfficialAuth(tabId, authorization.error || "官网在线校验失败");
  throw new Error(authorization.error || "官网在线校验失败");
}

function normalizeAiEndpoint(value) {
  let url;
  try { url = new URL(String(value || DEFAULT_AI_CONFIG.endpoint)); }
  catch { throw new Error("报告端点不是有效 URL"); }
  if (url.protocol !== "http:" || !["127.0.0.1", "localhost"].includes(url.hostname)) throw new Error("报告端点必须是本机 http://127.0.0.1 或 http://localhost");
  if (!url.port) url.port = "8787";
  url.pathname = "/report";
  url.search = "";
  url.hash = "";
  return url.toString();
}

async function getAiConfig() {
  const stored = await chrome.storage.local.get("dmpAiConfig");
  const candidate = { ...DEFAULT_AI_CONFIG, ...(stored.dmpAiConfig || {}) };
  return { enabled: candidate.enabled !== false, endpoint: normalizeAiEndpoint(candidate.endpoint) };
}

async function saveAiConfig(config) {
  const normalized = { enabled: config?.enabled !== false, endpoint: normalizeAiEndpoint(config?.endpoint) };
  await chrome.storage.local.set({ dmpAiConfig: normalized });
  return normalized;
}

function localServiceUrl(endpoint, pathname, search = "") {
  const url = new URL(normalizeAiEndpoint(endpoint));
  url.pathname = pathname;
  url.search = search;
  url.hash = "";
  return url.toString();
}

function publicProviderProfile(value = {}) {
  return {
    ...DEFAULT_PROVIDER_PROFILE,
    provider: String(value.provider || DEFAULT_PROVIDER_PROFILE.provider),
    providerName: String(value.providerName || DEFAULT_PROVIDER_PROFILE.providerName),
    visionModel: String(value.visionModel || DEFAULT_PROVIDER_PROFILE.visionModel),
    textModel: String(value.textModel || DEFAULT_PROVIDER_PROFILE.textModel),
    baseUrl: String(value.baseUrl || DEFAULT_PROVIDER_PROFILE.baseUrl),
    hasApiKey: Boolean(value.hasApiKey),
    keySource: String(value.keySource || (value.hasApiKey ? "local-profile" : "none"))
  };
}

async function getProviderProfile() {
  const config = await getAiConfig();
  const response = await fetchWithTimeout(localServiceUrl(config.endpoint, "/config"), { method: "GET", cache: "no-store" }, 8_000);
  const result = await response.json().catch(() => ({}));
  if (!response.ok || !result.ok) throw new Error(result.error || `配置端口返回 ${response.status}`);
  return publicProviderProfile(result.profile);
}

async function saveProviderProfile(profile) {
  const config = await getAiConfig();
  const response = await fetchWithTimeout(localServiceUrl(config.endpoint, "/config"), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    cache: "no-store",
    body: JSON.stringify({ profile: {
      provider: profile?.provider,
      providerName: profile?.providerName,
      visionModel: profile?.visionModel,
      textModel: profile?.textModel,
      baseUrl: profile?.baseUrl,
      apiKey: profile?.apiKey,
      clearApiKey: Boolean(profile?.clearApiKey)
    } })
  }, 12_000);
  const result = await response.json().catch(() => ({}));
  if (!response.ok || !result.ok) throw new Error(result.error || `配置端口返回 ${response.status}`);
  return publicProviderProfile(result.profile);
}

async function fetchWithTimeout(url, options = {}, timeoutMs = 90_000) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try { return await fetch(url, { ...options, signal: controller.signal }); }
  catch (error) {
    if (error?.name === "AbortError") throw new Error("本机服务请求超时");
    throw error;
  } finally { clearTimeout(timeout); }
}

async function aiHealth(probe = false) {
  const config = await getAiConfig();
  const response = await fetchWithTimeout(localServiceUrl(config.endpoint, "/health", probe ? "?probe=1" : ""), { method: "GET", cache: "no-store" }, probe ? 15_000 : 8_000);
  const health = await response.json().catch(() => ({}));
  if (!response.ok || !health.ok) throw new Error(health.error || `端口返回 ${response.status}`);
  return health;
}

async function verifyQcAdminKey(key) {
  const config = await getAiConfig();
  const response = await fetchWithTimeout(localServiceUrl(config.endpoint, "/qc/auth"), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    cache: "no-store",
    body: JSON.stringify({ key: String(key || "") })
  }, 8_000);
  const result = await response.json().catch(() => ({}));
  if (!response.ok || !result.ok) return { ok: false, error: result.error || "管理员登录失败" };
  return { ok: true, expiresIn: Math.max(60, Math.min(600, Number(result.expires_in) || 600)) };
}

// 深度解析：把脱敏后的接口原始数值 + 本地报告一起送到本机端口，
// 让 API 在原始响应里定位本地引擎没能填上的格子。返回的是"格子清单"，
// 由调用方（overlay）用 applyAnalysis 逐格校验后才写进表格。
async function analyzeWithLocalService(payload, report) {
  const config = await getAiConfig();
  if (!config.enabled) return { ok: false, skipped: true, error: "ChatGPT API 深度解析未启用" };
  const response = await fetchWithTimeout(localServiceUrl(config.endpoint, "/analyze"), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    cache: "no-store",
    body: JSON.stringify({ payload, report })
  }, 200_000);
  const result = await response.json().catch(() => ({}));
  // 四类错误码（NO_JSON/PARSE_FAILED/CALC_FAILED/API_FAILED）要原样带回给页面，
  // 不能压成一句话——页面要据此显示"没获取到 JSON/解析失败/计算错误/API 失败"。
  if (!response.ok || !result.ok) {
    return {
      ok: false,
      code: result.code || "API_FAILED",
      error: result.error || `深度解析端口返回 ${response.status}`,
      detail: result.detail || {}
    };
  }
  return result;
}

async function generateAiReport(report) {
  const config = await getAiConfig();
  if (!config.enabled) return { ok: false, skipped: true, error: "ChatGPT API 校验未启用" };
  const localValidation = globalThis.DmpReportEngine?.validateCanonicalReport(report);
  if (!localValidation?.ok) throw new Error(localValidation?.error || "本地标准报告校验失败");
  const response = await fetchWithTimeout(config.endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    cache: "no-store",
    body: JSON.stringify({ report })
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok || !result.ok) throw new Error(result.error || `报告端口返回 ${response.status}`);
  if (JSON.stringify(result.report) !== JSON.stringify(report)) throw new Error("端口返回报告与本地数据不一致，已拒绝采用");
  const returnedValidation = globalThis.DmpReportEngine?.validateCanonicalReport(result.report);
  if (!returnedValidation?.ok) throw new Error(returnedValidation?.error || "端口返回报告结构无效");
  return result;
}

function openRecordDb() {
  if (recordDbPromise) return recordDbPromise;
  recordDbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(RECORD_DB_NAME, RECORD_DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      const store = db.objectStoreNames.contains("records")
        ? request.transaction.objectStore("records")
        : db.createObjectStore("records", { keyPath: "id", autoIncrement: true });
      if (!store.indexNames.contains("byTabId")) store.createIndex("byTabId", "tabId", { unique: false });
      if (!store.indexNames.contains("byCapturedAt")) store.createIndex("byCapturedAt", "capturedAt", { unique: false });
      if (!store.indexNames.contains("byTabIdCapturedAt")) {
        store.createIndex("byTabIdCapturedAt", ["tabId", "capturedAt"], { unique: false });
      }
      if (!db.objectStoreNames.contains("jobs")) {
        db.createObjectStore("jobs", { keyPath: "tabId" });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("无法打开本地数据存储"));
  });
  return recordDbPromise;
}

async function persistRecord(tabId, record) {
  const db = await openRecordDb();
  await new Promise((resolve, reject) => {
    const tx = db.transaction("records", "readwrite");
    tx.objectStore("records").add({ tabId, capturedAt: record.capturedAt || new Date().toISOString(), record });
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error || new Error("本地数据写入失败"));
    tx.onabort = () => reject(tx.error || new Error("本地数据写入中止"));
  });
}

async function getPersistedRecords(tabId, since = "") {
  const db = await openRecordDb();
  return await new Promise((resolve, reject) => {
    const tx = db.transaction("records", "readonly");
    const store = tx.objectStore("records");
    const request = since && store.indexNames.contains("byTabIdCapturedAt")
      ? store.index("byTabIdCapturedAt").getAll(IDBKeyRange.bound([tabId, since], [tabId, "\uffff"]))
      : store.index("byTabId").getAll(tabId);
    request.onsuccess = () => resolve(request.result.map(item => item.record));
    request.onerror = () => reject(request.error || new Error("本地数据读取失败"));
  });
}

async function saveJob(tabId, job) {
  const db = await openRecordDb();
  await new Promise((resolve, reject) => {
    const tx = db.transaction("jobs", "readwrite");
    tx.objectStore("jobs").put({ tabId, updatedAt: new Date().toISOString(), job });
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error || new Error("报告任务保存失败"));
    tx.onabort = () => reject(tx.error || new Error("报告任务保存中止"));
  });
}

async function getJob(tabId) {
  const db = await openRecordDb();
  return await new Promise((resolve, reject) => {
    const tx = db.transaction("jobs", "readonly");
    const request = tx.objectStore("jobs").get(tabId);
    request.onsuccess = () => resolve(request.result?.job || null);
    request.onerror = () => reject(request.error || new Error("报告任务读取失败"));
  });
}

async function deleteJob(tabId) {
  const db = await openRecordDb();
  await new Promise((resolve, reject) => {
    const tx = db.transaction("jobs", "readwrite");
    tx.objectStore("jobs").delete(tabId);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error || new Error("报告任务删除失败"));
    tx.onabort = () => reject(tx.error || new Error("报告任务删除中止"));
  });
}

async function clearPersistedRecords(tabId) {
  const db = await openRecordDb();
  await new Promise((resolve, reject) => {
    const tx = db.transaction("records", "readwrite");
    const store = tx.objectStore("records");
    const request = store.index("byTabId").getAllKeys(tabId);
    request.onsuccess = () => request.result.forEach(key => store.delete(key));
    request.onerror = () => reject(request.error || new Error("本地数据清单读取失败"));
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error || new Error("本地数据清空失败"));
    tx.onabort = () => reject(tx.error || new Error("本地数据清空中止"));
  });
}

function canonicalRecordPath(record) {
  let value = String(record?.pathname || "");
  if (!value) {
    try { value = new URL(record?.url || "").pathname; } catch { value = String(record?.url || "").split("?")[0]; }
  }
  return value.replace(/^\/api_2\//, "/api/").replace(/\.json$/, "").replace(/\/+$/, "");
}

async function clearPersistedRecordPaths(tabId, paths) {
  const wanted = new Set((paths || []).map(path => canonicalRecordPath({ pathname: path })).filter(Boolean));
  if (!wanted.size) return 0;
  const db = await openRecordDb();
  return await new Promise((resolve, reject) => {
    const tx = db.transaction("records", "readwrite");
    const request = tx.objectStore("records").index("byTabId").openCursor(IDBKeyRange.only(tabId));
    let deleted = 0;
    request.onsuccess = () => {
      const cursor = request.result;
      if (!cursor) return;
      if (wanted.has(canonicalRecordPath(cursor.value?.record))) {
        cursor.delete();
        deleted += 1;
      }
      cursor.continue();
    };
    request.onerror = () => reject(request.error || new Error("本地数据筛选失败"));
    tx.oncomplete = () => resolve(deleted);
    tx.onerror = () => reject(tx.error || new Error("本地数据局部清理失败"));
    tx.onabort = () => reject(tx.error || new Error("本地数据局部清理中止"));
  });
}

function clearTabNetworkState(tabId) {
  const prefix = `${tabId}:`;
  for (const map of [requests, sockets, transports]) {
    for (const key of map.keys()) if (String(key).startsWith(prefix)) map.delete(key);
  }
  observedResponses.delete(tabId);
  capturedResponses.delete(tabId);
}

function sourceKey(source) {
  return `${source.tabId}:${source.sessionId || "root"}`;
}

function requestKey(source, requestId) {
  return `${sourceKey(source)}:${requestId}`;
}

function safeUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    for (const key of [...url.searchParams.keys()]) {
      if (SENSITIVE_QUERY.test(key)) url.searchParams.set(key, "[REDACTED]");
    }
    return url.toString();
  } catch {
    return rawUrl;
  }
}

function urlSummary(rawUrl) {
  try {
    const url = new URL(rawUrl);
    return {
      origin: url.origin,
      pathname: url.pathname,
      queryKeys: [...new Set([...url.searchParams.keys()])]
    };
  } catch {
    return { origin: "", pathname: rawUrl || "", queryKeys: [] };
  }
}

function bodyFormat(text, mimeType = "") {
  const value = text.trim();
  if (!value) return "empty";
  try {
    JSON.parse(value);
    return "json";
  } catch {}

  const match = value.match(/^[\w$.[\]]+\s*\(([\s\S]*)\)\s*;?\s*$/);
  if (match) {
    try {
      JSON.parse(match[1]);
      return "jsonp";
    } catch {}
  }

  const mime = mimeType.toLowerCase();
  if (mime.includes("x-www-form-urlencoded") || /^[^=&\s]+=[\s\S]*(?:&[^=&\s]+=|$)/.test(value)) return "form";
  if (mime.includes("html") || /^<!doctype\s+html|^<html[\s>]/i.test(value)) return "html";
  if (mime.includes("xml") || /^<\?xml\s|^<[\w:-]+[\s>]/.test(value)) return "xml";
  if (mime.includes("css")) return "css";
  if (mime.includes("javascript") || mime.includes("ecmascript")) return "javascript";
  return "text";
}

function payloadKeySummary(text, format) {
  try {
    let value = text.trim();
    if (format === "jsonp") {
      const match = value.match(/^[\w$.[\]]+\s*\(([\s\S]*)\)\s*;?\s*$/);
      if (!match) return [];
      value = match[1];
    }

    if (format === "form") {
      return [`form: ${[...new Set([...new URLSearchParams(value).keys()])].slice(0, 50).join(", ")}`];
    }

    const parsed = JSON.parse(value);
    if (Array.isArray(parsed)) {
      const result = [`array: ${parsed.length}`];
      if (parsed[0] && typeof parsed[0] === "object" && !Array.isArray(parsed[0])) {
        result.push(`item: ${Object.keys(parsed[0]).slice(0, 50).join(", ")}`);
      }
      return result;
    }
    if (!parsed || typeof parsed !== "object") return [`root: ${typeof parsed}`];

    const result = [`root: ${Object.keys(parsed).slice(0, 50).join(", ")}`];
    for (const key of ["data", "result", "model", "pageInfo", "page"]) {
      const child = parsed[key];
      if (child && typeof child === "object" && !Array.isArray(child)) {
        result.push(`${key}: ${Object.keys(child).slice(0, 50).join(", ")}`);
      }
    }
    return result;
  } catch {
    return [];
  }
}

function redactJsonValue(value) {
  if (Array.isArray(value)) return value.map(redactJsonValue);
  if (!value || typeof value !== "object") return value;
  return Object.fromEntries(Object.entries(value).map(([key, child]) => [
    key,
    SENSITIVE_QUERY.test(key) ? "[REDACTED]" : redactJsonValue(child)
  ]));
}

function sanitizedPayload(postData, format) {
  try {
    if (format === "json") return JSON.stringify(redactJsonValue(JSON.parse(postData)));
    if (format === "jsonp") {
      const match = postData.trim().match(/^([\w$.[\]]+\s*\()([\s\S]*)(\)\s*;?\s*)$/);
      if (match) return `${match[1]}${JSON.stringify(redactJsonValue(JSON.parse(match[2])))}${match[3]}`;
    }
    if (format === "form") {
      const params = new URLSearchParams(postData);
      for (const key of [...params.keys()]) {
        if (SENSITIVE_QUERY.test(key)) params.set(key, "[REDACTED]");
      }
      return params.toString();
    }
  } catch {}
  return postData;
}

function requestPayload(postData, mimeType = "") {
  if (typeof postData !== "string") {
    return { requestBodyLength: 0, requestBodyTruncated: false, requestFormat: "empty", requestKeys: [], requestBody: "" };
  }
  const format = bodyFormat(postData, mimeType);
  const safeBody = sanitizedPayload(postData, format);
  return {
    requestBodyLength: postData.length,
    requestBodyTruncated: safeBody.length > BODY_LIMIT,
    requestFormat: format,
    requestKeys: payloadKeySummary(safeBody, format),
    requestBody: safeBody.slice(0, BODY_LIMIT)
  };
}

function decodeBase64Utf8(base64) {
  const binary = atob(base64);
  const bytes = Uint8Array.from(binary, char => char.charCodeAt(0));
  return new TextDecoder("utf-8").decode(bytes);
}

function networkRecord(meta, extra = {}) {
  return {
    capturedAt: new Date().toISOString(),
    requestId: meta.requestId,
    url: meta.url,
    origin: meta.origin,
    pathname: meta.pathname,
    queryKeys: meta.queryKeys || [],
    method: meta.method,
    type: meta.type || "Other",
    initiatorType: meta.initiatorType,
    documentUrl: meta.documentUrl,
    requestBodyLength: meta.requestBodyLength || 0,
    requestBodyTruncated: Boolean(meta.requestBodyTruncated),
    requestBodyAvailable: Boolean(meta.requestBodyAvailable),
    requestBodyError: meta.requestBodyError || "",
    requestMimeType: meta.requestMimeType || "",
    requestFormat: meta.requestFormat || "empty",
    requestKeys: meta.requestKeys || [],
    requestBody: meta.requestBody || "",
    status: meta.status,
    statusText: meta.statusText,
    mimeType: meta.mimeType || "",
    protocol: meta.protocol || "",
    fromDiskCache: Boolean(meta.fromDiskCache),
    fromServiceWorker: Boolean(meta.fromServiceWorker),
    ...extra
  };
}

async function publish(tabId, record) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "DMP_CDP_RECORD", record });
  } catch {}
}

async function publishRecord(tabId, record) {
  try {
    await persistRecord(tabId, record);
  } catch (error) {
    await publishStatus(tabId, true, `本地数据保存失败：${String(error.message || error)}`);
  }
  await publish(tabId, record);
}

async function publishStatus(tabId, active, message) {
  try {
    await chrome.tabs.sendMessage(tabId, {
      type: "DMP_CDP_STATUS",
      active,
      message
    });
  } catch {}
}

async function enableTarget(session) {
  await chrome.debugger.sendCommand(session, "Network.enable", {
    maxTotalBufferSize: 500 * 1024 * 1024,
    maxResourceBufferSize: 50 * 1024 * 1024,
    maxPostDataSize: BODY_LIMIT
  });

  // 除 Network 外，打开会产生页面数据或运行时信号的 CDP 域。
  // 这些事件只采集当前页/当前调试目标，不读取 Cookie、Authorization 或 token 值。
  // DOM 是 Input.dispatchMouseEvent 的前置依赖（页签切换需要派发可信点击）。
  for (const domain of ["Runtime", "Log", "Console", "Performance", "DOMStorage", "Page", "DOM"]) {
    await chrome.debugger.sendCommand(session, `${domain}.enable`).catch(() => {});
  }

  try {
    await chrome.debugger.sendCommand(session, "Target.setAutoAttach", {
      autoAttach: true,
      waitForDebuggerOnStart: false,
      flatten: true,
      filter: [
        { type: "iframe", exclude: false },
        { type: "worker", exclude: false },
        { type: "shared_worker", exclude: false },
        { type: "service_worker", exclude: false }
      ]
    });
  } catch {}

  // 快照只是内部核验用的辅助信息，不要阻塞 attach 返回——
  // 调用方拿到 ok 之后会立刻触发路由并发出业务请求，attach 越快返回越不容易丢请求。
  void publishRuntimeSnapshot(session).catch(() => {});
}

function summarizeRemoteObject(object) {
  if (!object) return null;
  const value = object.value;
  if (value === undefined) return object.description || object.unserializableValue || object.type || null;
  if (typeof value === "string") return value.slice(0, BODY_LIMIT);
  if (typeof value === "number" || typeof value === "boolean") return value;
  try { return JSON.parse(JSON.stringify(value)); } catch { return String(value); }
}

async function publishRuntimeSnapshot(session) {
  const expression = `(() => {
    const safeResource = url => { try { const u = new URL(url, location.href); return u.origin + u.pathname; } catch { return String(url || '').split('?')[0]; } };
    return {
      title: document.title,
      url: location.origin + location.pathname,
      readyState: document.readyState,
      visibilityState: document.visibilityState,
      resourceEntries: performance.getEntriesByType('resource').slice(-200).map(x => ({name: safeResource(x.name), initiatorType: x.initiatorType, duration: x.duration, transferSize: x.transferSize})),
      localStorageKeys: Object.keys(localStorage),
      sessionStorageKeys: Object.keys(sessionStorage),
      indexedDB: indexedDB && indexedDB.databases ? 'available' : 'unavailable'
    };
  })()`;
  const result = await chrome.debugger.sendCommand(session, "Runtime.evaluate", { expression, returnByValue: true, awaitPromise: true });
  const value = result?.result?.value;
  if (!value) return;
  await publishRecord(session.tabId, { capturedAt: new Date().toISOString(), kind: "RuntimeSnapshot", source: "Runtime.evaluate", url: value.url, type: "Runtime", status: "snapshot", bodyLength: JSON.stringify(value).length, truncated: false, format: "json", responseKeys: Object.keys(value), body: JSON.stringify(value) });
}

async function markActive(tabId, message = "数据通道已就绪，请刷新或操作页面") {
  await chrome.action.setBadgeBackgroundColor({ tabId, color: "#16803c" });
  await chrome.action.setBadgeText({ tabId, text: "ON" });
  await publishStatus(tabId, true, message);
}

function attachErrorMessage(error) {
  const detail = String(error);
  if (/another debugger|already attached|cannot attach/i.test(detail)) {
    return "数据通道不可用：请关闭此页开发者工具，再到“质检 QC”中刷新 QC 通道";
  }
  return "数据通道初始化失败，请刷新页面后重试";
}

async function attachImpl(tabId) {
  if (activeTabs.has(tabId)) {
    try {
      await enableTarget({ tabId });
      await markActive(tabId, "数据通道已就绪，请刷新或操作页面");
      return;
    } catch {
      activeTabs.delete(tabId);
    }
  }

  // Service Worker 被 Chrome 唤醒后内存状态会重置；先尝试恢复已有调试会话。
  try {
    await enableTarget({ tabId });
    activeTabs.add(tabId);
    await markActive(tabId, "数据通道已恢复，请刷新或操作页面");
    return;
  } catch {}

  try {
    await chrome.debugger.attach({ tabId }, "1.3");
    await enableTarget({ tabId });
  } catch (error) {
    const message = attachErrorMessage(error);
    await chrome.action.setBadgeBackgroundColor({ tabId, color: "#b42318" });
    await chrome.action.setBadgeText({ tabId, text: "ERR" });
    await publishStatus(tabId, false, message);
    throw new Error(message);
  }

  activeTabs.add(tabId);
  await markActive(tabId);
}

async function attach(tabId) {
  const current = attachJobs.get(tabId);
  if (current) return current;

  const job = verifyOfficialSiteForTab(tabId)
    .then(() => attachImpl(tabId))
    .finally(() => attachJobs.delete(tabId));
  attachJobs.set(tabId, job);
  return job;
}

async function detach(tabId) {
  try {
    await chrome.debugger.detach({ tabId });
  } catch {}
  activeTabs.delete(tabId);
  await chrome.action.setBadgeText({ tabId, text: "" });
  await publishStatus(tabId, false, "数据通道已停止");
}

async function reconnect(tabId) {
  await detach(tabId);
  await attach(tabId);
}

function headerValue(headers, wantedName) {
  const entry = Object.entries(headers || {}).find(([name]) => name.toLowerCase() === wantedName.toLowerCase());
  return entry ? String(entry[1]) : "";
}

function requestMetaFromEvent(params) {
  const rawUrl = params.request?.url || "";
  const summary = urlSummary(rawUrl);
  const requestMimeType = headerValue(params.request?.headers, "content-type");
  const payload = requestPayload(params.request?.postData, requestMimeType);
  return {
    requestId: params.requestId,
    rawUrl,
    url: safeUrl(rawUrl),
    ...summary,
    method: params.request?.method || "",
    type: params.type || "Other",
    initiatorType: params.initiator?.type,
    documentUrl: safeUrl(params.documentURL || ""),
    requestMimeType,
    requestBodyAvailable: typeof params.request?.postData === "string",
    hasPostData: Boolean(params.request?.hasPostData),
    ...payload
  };
}

async function ensureRequestPostData(source, meta) {
  if (!meta.hasPostData || meta.requestBodyAvailable) return;
  try {
    const result = await chrome.debugger.sendCommand(source, "Network.getRequestPostData", { requestId: meta.requestId });
    Object.assign(meta, requestPayload(result.postData, meta.requestMimeType), { requestBodyAvailable: true });
  } catch (error) {
    meta.requestBodyError = String(error);
  }
}

async function publishNetworkRecord(tabId, record) {
  await publishRecord(tabId, record);
  const captured = (capturedResponses.get(tabId) || 0) + 1;
  capturedResponses.set(tabId, captured);
  await publishStatus(tabId, true, "数据通道运行中");
}

async function handleFinished(source, params) {
  const key = requestKey(source, params.requestId);
  const meta = requests.get(key) || {
    requestId: params.requestId,
    url: "",
    origin: "",
    pathname: "",
    queryKeys: [],
    type: "Other"
  };

  try {
    await ensureRequestPostData(source, meta);

    const response = await chrome.debugger.sendCommand(
      source,
      "Network.getResponseBody",
      { requestId: params.requestId }
    );

    const isTextBody = !response.base64Encoded || /(json|javascript|ecmascript|text|xml|html|css|svg)/i.test(meta.mimeType || "");
    const fullBody = response.base64Encoded && isTextBody
      ? decodeBase64Utf8(response.body)
      : response.body || "";
    const format = response.base64Encoded && !isTextBody
      ? "binary-base64"
      : bodyFormat(fullBody, meta.mimeType);

    await publishNetworkRecord(source.tabId, networkRecord(meta, {
      encodedDataLength: params.encodedDataLength,
      bodyAvailable: true,
      bodyEncoding: response.base64Encoded ? (isTextBody ? "base64-decoded-utf8" : "base64") : "utf8",
      bodyLength: fullBody.length,
      truncated: fullBody.length > BODY_LIMIT,
      format,
      responseKeys: payloadKeySummary(fullBody, format),
      body: fullBody.slice(0, BODY_LIMIT)
    }));
  } catch (error) {
    await publishNetworkRecord(source.tabId, networkRecord(meta, {
      encodedDataLength: params.encodedDataLength,
      bodyAvailable: false,
      bodyLength: 0,
      truncated: false,
      format: "unavailable",
      responseKeys: [],
      body: "",
      responseBodyError: String(error)
    }));
  } finally {
    requests.delete(key);
  }
}

async function handleEvent(source, method, params) {
  if (method === "Target.attachedToTarget") {
    await enableTarget({ tabId: source.tabId, sessionId: params.sessionId });
    return;
  }

  if (method === "Network.requestWillBeSent") {
    const key = requestKey(source, params.requestId);
    const previous = requests.get(key);
    const current = requestMetaFromEvent(params);
    requests.set(key, current);

    if (params.redirectResponse) {
      const response = params.redirectResponse;
      const rawUrl = response.url || previous?.rawUrl || "";
      const redirectedMeta = {
        ...(previous || {}),
        requestId: params.requestId,
        rawUrl,
        url: safeUrl(rawUrl),
        ...urlSummary(rawUrl),
        status: response.status,
        statusText: response.statusText,
        mimeType: response.mimeType,
        protocol: response.protocol,
        fromDiskCache: response.fromDiskCache,
        fromServiceWorker: response.fromServiceWorker
      };
      await publishNetworkRecord(source.tabId, networkRecord(redirectedMeta, {
        redirect: true,
        redirectTo: current.url,
        bodyAvailable: false,
        bodyLength: 0,
        truncated: false,
        format: "redirect",
        responseKeys: [],
        body: "",
        responseBodyError: "CDP 不提供跳转中间响应体"
      }));
    }
    return;
  }

  if (method === "Network.responseReceived") {
    const key = requestKey(source, params.requestId);
    const current = requests.get(key) || { requestId: params.requestId };
    const rawUrl = params.response.url || current.rawUrl || "";
    requests.set(key, {
      ...current,
      rawUrl,
      url: safeUrl(rawUrl),
      ...urlSummary(rawUrl),
      type: params.type || current.type,
      status: params.response.status,
      statusText: params.response.statusText,
      mimeType: params.response.mimeType,
      protocol: params.response.protocol,
      fromDiskCache: params.response.fromDiskCache,
      fromServiceWorker: params.response.fromServiceWorker
    });

    const observed = (observedResponses.get(source.tabId) || 0) + 1;
    observedResponses.set(source.tabId, observed);
    if (observed <= 3 || observed % 25 === 0) {
      await publishStatus(
        source.tabId,
        true,
        "数据通道运行中"
      );
    }
    return;
  }

  if (method === "Network.loadingFinished") {
    await handleFinished(source, params);
    return;
  }

  if (method === "Network.loadingFailed") {
    const key = requestKey(source, params.requestId);
    const meta = requests.get(key) || { requestId: params.requestId, url: "", type: params.type || "Other" };
    await ensureRequestPostData(source, meta);
    await publishNetworkRecord(source.tabId, networkRecord(meta, {
      failed: true,
      canceled: Boolean(params.canceled),
      blockedReason: params.blockedReason || "",
      corsErrorStatus: params.corsErrorStatus || null,
      bodyAvailable: false,
      bodyLength: 0,
      truncated: false,
      format: "failed",
      responseKeys: [],
      body: "",
      responseBodyError: params.errorText || "Network.loadingFailed"
    }));
    requests.delete(key);
    return;
  }

  if (method === "Runtime.consoleAPICalled") {
    const args = (params.args || []).map(summarizeRemoteObject);
    await publishRecord(source.tabId, { capturedAt: new Date().toISOString(), kind: "Console", source: "Runtime.consoleAPICalled", level: params.type || "log", executionContextId: params.executionContextId, timestamp: params.timestamp, url: "", bodyLength: JSON.stringify(args).length, truncated: false, format: "json", responseKeys: [], body: JSON.stringify({ level: params.type, args }) });
    return;
  }

  if (method === "Runtime.exceptionThrown") {
    const details = params.exceptionDetails || {};
    await publishRecord(source.tabId, { capturedAt: new Date().toISOString(), kind: "RuntimeException", source: "Runtime.exceptionThrown", url: "", text: details.text || "", lineNumber: details.lineNumber, columnNumber: details.columnNumber, bodyLength: JSON.stringify(details).length, truncated: false, format: "json", responseKeys: [], body: JSON.stringify({text: details.text, url: details.url, lineNumber: details.lineNumber, columnNumber: details.columnNumber, exception: summarizeRemoteObject(details.exception)}) });
    return;
  }

  if (method === "Log.entryAdded" || method === "Console.messageAdded") {
    const entry = params.entry || params.message || params;
    await publishRecord(source.tabId, { capturedAt: new Date().toISOString(), kind: "PageLog", source: method, level: entry.level || entry.type || "log", url: entry.url || "", bodyLength: JSON.stringify(entry).length, truncated: false, format: "json", responseKeys: [], body: JSON.stringify(entry) });
    return;
  }

  if (method === "Performance.metrics") {
    await publishRecord(source.tabId, { capturedAt: new Date().toISOString(), kind: "Performance", source: "Performance.metrics", url: "", bodyLength: JSON.stringify(params).length, truncated: false, format: "json", responseKeys: ["metrics"], body: JSON.stringify(params) });
    return;
  }

  if (method === "DOMStorage.domStorageItemAdded" || method === "DOMStorage.domStorageItemUpdated" || method === "DOMStorage.domStorageItemRemoved" || method === "DOMStorage.domStorageItemsCleared") {
    const storageId = params.storageId || {};
    await publishRecord(source.tabId, { capturedAt: new Date().toISOString(), kind: "DOMStorage", source: method, storageType: storageId.isLocalStorage ? "localStorage" : "sessionStorage", securityOrigin: storageId.securityOrigin || "", key: params.key || "", oldValue: params.oldValue == null ? null : "[VALUE_REDACTED]", newValue: params.newValue == null ? null : "[VALUE_REDACTED]", bodyLength: JSON.stringify(params).length, truncated: false, format: "json", responseKeys: [], body: JSON.stringify({key: params.key, value: "[VALUE_REDACTED]", event: method}) });
    return;
  }

  if (method === "Page.frameNavigated") {
    const frame = params.frame || {};
    await publishRecord(source.tabId, { capturedAt: new Date().toISOString(), kind: "PageState", source: "Page.frameNavigated", url: safeUrl(frame.url || ""), frameId: frame.id, securityOrigin: frame.securityOrigin, mimeType: frame.mimeType, bodyLength: JSON.stringify(frame).length, truncated: false, format: "json", responseKeys: [], body: JSON.stringify({id: frame.id, url: safeUrl(frame.url || ""), securityOrigin: frame.securityOrigin, mimeType: frame.mimeType}) });
    return;
  }

  if (method === "Network.webSocketCreated") {
    const summary = urlSummary(params.url || "");
    sockets.set(requestKey(source, params.requestId), {
      requestId: params.requestId,
      rawUrl: params.url,
      url: safeUrl(params.url),
      ...summary,
      method: "GET",
      type: "WebSocket",
      initiatorType: params.initiator?.type,
      requestFormat: "empty",
      requestKeys: [],
      requestBody: "",
      requestBodyAvailable: true
    });
    return;
  }

  if (method === "Network.webSocketWillSendHandshakeRequest") {
    const key = requestKey(source, params.requestId);
    const socket = sockets.get(key) || { requestId: params.requestId, type: "WebSocket", method: "GET" };
    sockets.set(key, socket);
    return;
  }

  if (method === "Network.webSocketHandshakeResponseReceived") {
    const key = requestKey(source, params.requestId);
    const socket = sockets.get(key) || { requestId: params.requestId, url: "", type: "WebSocket", method: "GET" };
    socket.status = params.response?.status;
    socket.statusText = params.response?.statusText;
    socket.protocol = "websocket";
    await publishNetworkRecord(source.tabId, networkRecord(socket, {
      bodyAvailable: false,
      bodyLength: 0,
      truncated: false,
      format: "websocket-handshake",
      responseKeys: [],
      body: "",
      responseBodyError: "WebSocket 握手没有普通 HTTP 响应体"
    }));
    return;
  }

  if (method === "Network.webSocketFrameReceived" || method === "Network.webSocketFrameSent") {
    const socket = sockets.get(requestKey(source, params.requestId));
    if (!socket) return;
    const payload = params.response.payloadData || "";
    const format = params.response.opcode === 1 ? bodyFormat(payload) : "binary-websocket";
    await publishRecord(source.tabId, {
      capturedAt: new Date().toISOString(),
      requestId: params.requestId,
      kind: "WebSocket",
      source: method,
      direction: method.endsWith("Sent") ? "sent" : "received",
      url: socket.url,
      type: "WebSocket",
      opcode: params.response.opcode,
      bodyLength: payload.length,
      truncated: payload.length > BODY_LIMIT,
      format,
      responseKeys: payloadKeySummary(payload, format),
      body: payload.slice(0, BODY_LIMIT)
    });
    return;
  }

  if (method === "Network.webSocketFrameError") {
    const socket = sockets.get(requestKey(source, params.requestId)) || {};
    await publishRecord(source.tabId, {
      capturedAt: new Date().toISOString(),
      requestId: params.requestId,
      kind: "WebSocketError",
      source: method,
      url: socket.url || "",
      type: "WebSocket",
      error: params.errorMessage || "WebSocket frame error"
    });
    return;
  }

  if (method === "Network.webSocketClosed") {
    sockets.delete(requestKey(source, params.requestId));
    return;
  }

  if (method === "Network.eventSourceMessageReceived") {
    const meta = requests.get(requestKey(source, params.requestId)) || {};
    const payload = params.data || "";
    const format = bodyFormat(payload);
    await publishRecord(source.tabId, {
      capturedAt: new Date().toISOString(),
      requestId: params.requestId,
      kind: "EventSourceMessage",
      source: method,
      url: meta.url || "",
      type: "EventSource",
      eventName: params.eventName || "message",
      eventId: params.eventId || "",
      bodyLength: payload.length,
      truncated: payload.length > BODY_LIMIT,
      format,
      responseKeys: payloadKeySummary(payload, format),
      body: payload.slice(0, BODY_LIMIT)
    });
    return;
  }

  if (method === "Network.webTransportCreated") {
    const summary = urlSummary(params.url || "");
    transports.set(requestKey(source, params.transportId), {
      requestId: params.transportId,
      rawUrl: params.url || "",
      url: safeUrl(params.url || ""),
      ...summary,
      method: "CONNECT",
      type: "WebTransport",
      requestBodyAvailable: true
    });
    return;
  }

  if (method === "Network.webTransportConnectionEstablished") {
    const transport = transports.get(requestKey(source, params.transportId)) || {
      requestId: params.transportId,
      url: "",
      method: "CONNECT",
      type: "WebTransport"
    };
    await publishNetworkRecord(source.tabId, networkRecord(transport, {
      status: "connected",
      bodyAvailable: false,
      bodyLength: 0,
      truncated: false,
      format: "webtransport",
      responseKeys: [],
      body: "",
      responseBodyError: "WebTransport 连接没有普通 HTTP 响应体"
    }));
    return;
  }

  if (method === "Network.webTransportClosed") {
    transports.delete(requestKey(source, params.transportId));
    return;
  }
}

chrome.debugger.onEvent.addListener((source, method, params) => {
  void handleEvent(source, method, params).catch(() => {});
});

chrome.debugger.onDetach.addListener((source, reason) => {
  if (!source.tabId) return;
  activeTabs.delete(source.tabId);
  void chrome.action.setBadgeText({ tabId: source.tabId, text: "" }).catch(() => {});
  void publishStatus(source.tabId, false, "数据通道已断开，请刷新页面后重试");
});

chrome.action.onClicked.addListener(tab => {
  if (!tab.id) return;
  void (activeTabs.has(tab.id) ? detach(tab.id) : attach(tab.id)).catch(error => {
    void publishStatus(tab.id, false, attachErrorMessage(error));
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "DMP_QC_ADMIN_VERIFY" && sender.tab?.id) {
    void verifyQcAdminKey(message.key)
      .then(result => sendResponse(result))
      .catch(() => sendResponse({ ok: false, error: "管理员登录服务不可用" }));
    return true;
  }

  if (message?.type === "DMP_CDP_AUTH_CHECK") {
    void checkOfficialSiteAccess()
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ ok: false, reason: "offline", error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_OPEN_LOGIN") {
    void chrome.tabs.create({ url: `${OFFICIAL_SITE}/login` })
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_OPEN_OPTIONS") {
    void chrome.runtime.openOptionsPage()
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_GET_AI_CONFIG") {
    void getAiConfig()
      .then(config => sendResponse({ ok: true, config }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_SAVE_AI_CONFIG") {
    void saveAiConfig(message.config || {})
      .then(config => sendResponse({ ok: true, config }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_GET_PROVIDER_CONFIG") {
    void getProviderProfile()
      .then(profile => sendResponse({ ok: true, profile }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_SAVE_PROVIDER_CONFIG") {
    void saveProviderProfile(message.profile || {})
      .then(profile => sendResponse({ ok: true, profile }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_CLEAR_PROVIDER_API_KEY") {
    void saveProviderProfile({ ...(message.profile || {}), clearApiKey: true })
      .then(profile => sendResponse({ ok: true, profile }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_AI_HEALTH") {
    void aiHealth(Boolean(message.probe))
      .then(health => sendResponse({ ok: true, health }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_AI_GENERATE") {
    void generateAiReport(message.report)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_AI_ANALYZE") {
    void analyzeWithLocalService(message.payload, message.report)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_GET_RECORDS" && sender.tab?.id) {
    void getPersistedRecords(sender.tab.id, typeof message.since === "string" ? message.since : "")
      .then(records => sendResponse({ ok: true, records, count: records.length }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error), records: [] }));
    return true;
  }

  if (message?.type === "DMP_CDP_SAVE_JOB" && sender.tab?.id) {
    void saveJob(sender.tab.id, message.job || null)
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_GET_JOB" && sender.tab?.id) {
    void getJob(sender.tab.id)
      .then(job => sendResponse({ ok: true, job }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error), job: null }));
    return true;
  }

  if (message?.type === "DMP_CDP_DELETE_JOB" && sender.tab?.id) {
    void deleteJob(sender.tab.id)
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_CLEAR_RECORDS" && sender.tab?.id) {
    void clearPersistedRecords(sender.tab.id)
      .then(() => {
        clearTabNetworkState(sender.tab.id);
        sendResponse({ ok: true, records: [], count: 0, clearedAt: new Date().toISOString() });
      })
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_CLEAR_RECORD_PATHS" && sender.tab?.id) {
    void clearPersistedRecordPaths(sender.tab.id, Array.isArray(message.paths) ? message.paths : [])
      .then(deleted => sendResponse({ ok: true, deleted, clearedAt: new Date().toISOString() }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  // 用 CDP Input 域派发浏览器级真实鼠标事件。
  // 关键区别：内容脚本 dispatchEvent 合成的事件 isTrusted 恒为 false，
  // 达摩盘的页签切换逻辑会拒绝响应（实测：埋点 SDK 收到了 mousedown 并上报，
  // 但页面既不切换也不取数）；Input.dispatchMouseEvent 派发的事件 isTrusted 为 true。
  if (message?.type === "DMP_CDP_REAL_CLICK" && sender.tab?.id) {
    const tabId = sender.tab.id;
    const x = Number(message.x);
    const y = Number(message.y);
    if (!Number.isFinite(x) || !Number.isFinite(y)) return sendResponse({ ok: false, error: "坐标无效" });
    if (!activeTabs.has(tabId)) return sendResponse({ ok: false, error: "数据通道未就绪" });

    // buttons 是位掩码（1 = 左键按下），Chrome 对 mousePressed/mouseReleased
    // 需要它才能构造出完整的事件；缺失时事件可能被静默丢弃。
    const send = (type, extra) => chrome.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", {
      type, x, y, button: "left", ...extra
    });

    void (async () => {
      await send("mouseMoved", { button: "none", buttons: 0, clickCount: 0 });
      await send("mousePressed", { buttons: 1, clickCount: 1 });
      await send("mouseReleased", { buttons: 0, clickCount: 1 });
    })()
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_ENSURE_ATTACHED" && sender.tab?.id) {
    // 与 RECONNECT 的区别：不 detach。detach 会摧毁调试会话并丢弃 Chrome 侧
    // 已生效的 Network.enable，一键运行紧接着就改 hash 发业务请求，
    // 空窗期内这些请求会全部记录不到。这里只做幂等的 attach + 重新 enable。
    void attach(sender.tab.id)
      .then(() => sendResponse({ ok: true, attached: true }))
      .catch(error => sendResponse({ ok: false, error: attachErrorMessage(error) }));
    return true;
  }

  if (message?.type !== "DMP_CDP_RECONNECT" || !sender.tab?.id) return;

  void reconnect(sender.tab.id)
    .then(() => sendResponse({ ok: true }))
    .catch(error => sendResponse({ ok: false, error: attachErrorMessage(error) }));
  return true;
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url?.startsWith("https://dmp.taobao.com/") ||
      (changeInfo.status === "loading" && tab.url?.startsWith("https://dmp.taobao.com/"))) {
    void attach(tabId).catch(error => {
      void publishStatus(tabId, false, attachErrorMessage(error));
    });
  }
});

chrome.tabs.onRemoved.addListener(tabId => {
  activeTabs.delete(tabId);
  observedResponses.delete(tabId);
  capturedResponses.delete(tabId);
});

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name !== OFFICIAL_AUTH_ALARM || !activeTabs.size) return;
  void checkOfficialSiteAccess().then(async authorization => {
    if (authorization.ok) return;
    for (const tabId of [...activeTabs]) {
      await lockTabForOfficialAuth(tabId, authorization.error || "官网在线校验失败");
    }
  }).catch(() => {});
});

function ensureOfficialHeartbeat() {
  return chrome.alarms.create(OFFICIAL_AUTH_ALARM, { periodInMinutes: 1 });
}

chrome.runtime.onInstalled.addListener(async () => {
  await ensureOfficialHeartbeat();
  const tabs = await chrome.tabs.query({ url: "https://dmp.taobao.com/*" });
  for (const tab of tabs) {
    if (tab.id) void attach(tab.id).catch(() => {});
  }
});

async function attachOpenDmpTabs() {
  const tabs = await chrome.tabs.query({ url: "https://dmp.taobao.com/*" });
  for (const tab of tabs) {
    if (tab.id) void attach(tab.id).catch(() => {});
  }
}

// 同时覆盖扩展更新、浏览器启动和 Service Worker 重新唤醒三种情况。
void attachOpenDmpTabs().catch(() => {});
chrome.runtime.onStartup.addListener(() => {
  void ensureOfficialHeartbeat();
  void attachOpenDmpTabs().catch(() => {});
});
void ensureOfficialHeartbeat();
