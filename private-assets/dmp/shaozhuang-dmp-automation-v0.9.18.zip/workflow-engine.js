(function initDmpWorkflowEngine(root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.DmpWorkflowEngine = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function createDmpWorkflowEngine() {
  "use strict";

  const COMPARISON_TABS = ["关键指标对比", "推广策略对比", "人群对比"];
  const SCENE_CHANNELS = ["关键词推广", "人群推广", "线索推广", "货品全站推", "店铺运营", "货品运营", "内容营销"];
  const SCENE_PARENT_CHANNELS = {
    "371": "关键词推广",
    "372": "人群推广",
    "376": "货品运营",
    "377": "店铺运营",
    "379": "内容营销",
    "395": "线索推广",
    "435": "货品全站推",
    "436": "货品全站推"
  };
  const SUCCESS_ENTRY_LABELS = ["取得成功品", "获取成功品", "定制成功品", "选择成功品", "设置成功品", "添加成功品", "切换成功品", "修改成功品"];
  const SUCCESS_CLEAR_LABELS = ["全部删除", "清空全部", "全部移除", "全部清除"];

  // 这些值对应“定制成功品”弹窗中用户截图展示的筛选状态。
  const SUCCESS_FILTERS = [
    { key: "priceBand", label: "价格带", selected: ["全部价格带"], options: ["全选"] },
    { key: "growthCycle", label: "打爆周期", selected: ["新品打爆期", "爆品期"], options: ["新品打爆期", "爆品期"] },
    { key: "onlineCycle", label: "上架周期", selected: ["全部上架周期"], options: ["全选"] },
    { key: "rankLevel", label: "TOP水位", selected: ["TOP0.5%以内"], options: ["TOP0.5%以内"] },
    { key: "salesLevel", label: "销售额水位", selected: ["1000w以上", "500万~1000万"], options: ["1000w以上", "500万~1000万"] }
  ];

  function normalizeText(value) {
    return String(value || "").replace(/\s+/g, "").replace(/[～—–]/g, "~").trim();
  }

  function pad2(value) {
    return String(value).padStart(2, "0");
  }

  function localDate(value) {
    return `${value.getFullYear()}-${pad2(value.getMonth() + 1)}-${pad2(value.getDate())}`;
  }

  function pastCompletedDays(days = 30, now = new Date()) {
    const count = Number.isInteger(days) && days > 0 ? days : 30;
    const end = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
    const start = new Date(end.getFullYear(), end.getMonth(), end.getDate() - count + 1);
    return { startDate: localDate(start), endDate: localDate(end), days: count };
  }

  function buildGrowupRouteHash(itemId, nonce = Date.now()) {
    const value = String(itemId || "").trim();
    if (!/^\d{6,20}$/.test(value)) throw new Error("商品 ID 必须是 6–20 位数字");
    return `#!/items/growup-path?spm=&itemId=${encodeURIComponent(value)}&dmpReportTask=${encodeURIComponent(String(nonce))}`;
  }

  function selectedSuccessCount(value) {
    const match = normalizeText(value).match(/已选成功品[（(]?(\d+)\/(\d+)项?[）)]?/);
    return match ? Number(match[1]) : null;
  }

  function buildRecapturePlan(report, job = {}) {
    const quality = report?.quality || {};
    const issues = [...(quality.blockingIssues || []), ...(quality.warnings || [])].map(String);
    const issueText = issues.join("\n");
    const missingModules = new Set((quality.endpointStatus || []).filter(status => !status.usable).map(status => status.module));
    const failedPaths = (quality.endpointCoverage || []).filter(entry => entry.failed > 0).map(entry => String(entry.path || "")).filter(Boolean);
    const missingValues = (quality.deterministicMissing || []).map(String);
    const tabFailures = (job.tabFailures || []).join("\n");
    const tabs = new Set();
    const reasons = new Set(issues);

    const routePatterns = /商品概况|主体商品|成长趋势|成长阶段|日趋势|五渠道消耗|GMV 序列|精确周期GMV|\/api\/goods\/item\/info|\/api\/goods\/grow\/define\/line\/data/;
    const successPatterns = /成功品|\/api\/goods\/grow\/define\/success/;
    const corePatterns = /核心指标|成交笔数|笔单价|总GMV|访客数|完全一致的核心指标卡|\/dataplatform\/dataset\/report\/query/;
    const scenePatterns = /投放场景|场景明细|一级场景|二级明细|场景金额|推广消耗|费比|ROAS|\/api\/goods\/grow\/comparison\/scene(?:\s|:|$)/;
    const keywordPatterns = /关键词响应|关键词样本|\/api\/goods\/grow\/comparison\/scene\/keyword/;
    const periodPatterns = /目标业务周期起止日期|目标周期自然日|日期未|日期控件|30\s*天/;

    const reloadRoute = missingModules.has("商品概况") || missingModules.has("成长阶段与趋势") ||
      routePatterns.test(issueText) || failedPaths.some(path => /item\/info|goods\/grow\/line$|define\/line\/data/.test(path)) ||
      missingValues.some(label => /^对手(?:推广消耗|费比|全域ROAS)$/.test(label));
    const reselectSuccess = missingModules.has("成功品") || successPatterns.test(issueText) ||
      failedPaths.some(path => /define\/success/.test(path));
    const needsCore = missingModules.has("核心指标") || corePatterns.test(issueText) ||
      failedPaths.some(path => /dataplatform\/dataset\/report\/query/.test(path)) ||
      missingValues.some(label => /成交笔数|笔单价|总GMV|访客数/.test(label));
    const needsScenes = missingModules.has("投放场景") || scenePatterns.test(issueText) ||
      failedPaths.some(path => /comparison\/scene$/.test(path)) ||
      missingValues.some(label => /^主体(?:推广消耗|费比|全域ROAS)$/.test(label));
    const needsKeywords = missingModules.has("关键词样本") || keywordPatterns.test(issueText) ||
      failedPaths.some(path => /comparison\/scene\/keyword/.test(path));
    const needsPeriod = periodPatterns.test(issueText);

    if (needsCore || reloadRoute) tabs.add("关键指标对比");
    if (needsScenes || needsKeywords) tabs.add("推广策略对比");
    if (needsPeriod) COMPARISON_TABS.forEach(label => tabs.add(label));
    COMPARISON_TABS.forEach(label => {
      if (tabFailures.includes(label)) tabs.add(label);
    });
    if (job.periodPrecision === "failed" && !needsPeriod) {
      const results = new Map((job.tabResults || []).map(result => [result.label, result]));
      COMPARISON_TABS.forEach(label => {
        const result = results.get(label);
        if (!result || !result.periodConfirmed || result.periodPrecision === "failed") tabs.add(label);
      });
    }

    const missingSceneChannels = new Set((job.sceneMissed || []).filter(channel => SCENE_CHANNELS.includes(channel)));
    const parentMatch = issueText.match(/二级明细响应：([\d、,，\s]+)/);
    if (parentMatch) {
      parentMatch[1].split(/[、,，\s]+/).filter(Boolean).forEach(parentId => {
        const channel = SCENE_PARENT_CHANNELS[parentId];
        if (channel) missingSceneChannels.add(channel);
      });
    }
    if (needsScenes && !missingSceneChannels.size) SCENE_CHANNELS.forEach(channel => missingSceneChannels.add(channel));
    if (needsKeywords && !needsScenes) missingSceneChannels.add("关键词推广");
    if (failedPaths.some(path => /comparison\/scene$/.test(path))) {
      missingSceneChannels.clear();
      SCENE_CHANNELS.forEach(channel => missingSceneChannels.add(channel));
    }

    const replaceablePath = /^(?:\/api\/goods\/item\/info|\/api\/goods\/grow\/line|\/api\/goods\/grow\/define\/success(?:\/load|\/item\/list)?|\/api\/goods\/grow\/define\/line\/data|\/api\/goods\/grow\/comparison\/scene(?:\/keyword)?|\/dataplatform\/dataset\/report\/query)$/;
    const clearPaths = new Set(failedPaths.filter(path => replaceablePath.test(path)));

    if (!reloadRoute && !reselectSuccess && !tabs.size) {
      COMPARISON_TABS.forEach(label => tabs.add(label));
      reasons.add("缺口无法归入已知模块，重新核对三个对比页签");
    }

    const summary = [
      reloadRoute ? "主体概况/趋势" : "",
      reselectSuccess ? "成功品" : "",
      ...tabs,
      missingSceneChannels.size ? `场景渠道：${[...missingSceneChannels].join("、")}` : ""
    ].filter(Boolean).join("；");

    return {
      reloadRoute,
      reselectSuccess,
      tabs: [...tabs],
      sceneChannels: [...missingSceneChannels],
      clearPaths: [...clearPaths],
      reasons: [...reasons],
      summary: summary || "重新核对缺失业务模块"
    };
  }

  return { COMPARISON_TABS, SCENE_CHANNELS, SUCCESS_ENTRY_LABELS, SUCCESS_CLEAR_LABELS, SUCCESS_FILTERS, normalizeText, pastCompletedDays, buildGrowupRouteHash, selectedSuccessCount, buildRecapturePlan };
});
