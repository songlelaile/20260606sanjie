(function initDmpHtmlWriter(root, factory) {
  const reportEngine = root.DmpReportEngine || (typeof module === "object" && module.exports ? require("./report-engine.js") : null);
  const api = factory(reportEngine);
  if (typeof module === "object" && module.exports) module.exports = api;
  root.DmpHtmlWriter = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function createDmpHtmlWriter(reportEngine) {
  "use strict";

  const MIME_TYPE = "text/html;charset=utf-8";
  const REQUIRED_TABLES = Object.freeze([
    "报告总览", "对标总表", "商品与成功品", "周期汇总", "日GMV与费比", "渠道花费",
    "一级场景", "二级场景", "成长阶段数据", "基础指标对比", "关键词样本"
  ]);
  const SECTION_IDS = Object.freeze({
    报告总览: "overview",
    对标总表: "benchmark",
    商品与成功品: "products",
    周期汇总: "period",
    日GMV与费比: "daily",
    渠道花费: "channel",
    一级场景: "scene-primary",
    二级场景: "scene-secondary",
    成长阶段数据: "stages",
    基础指标对比: "metrics",
    关键词样本: "keywords",
  });
  const FREEZE_COLUMNS = Object.freeze({
    对标总表: 2,
    商品与成功品: 3,
    周期汇总: 2,
    日GMV与费比: 1,
    渠道花费: 1,
    一级场景: 3,
    二级场景: 4,
    成长阶段数据: 4,
    基础指标对比: 1,
    关键词样本: 2,
  });

  function escapeHtml(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function isMissing(value) {
    return value === null || value === undefined || value === "" || value === "—";
  }

  function isPercentSemantic(value) {
    const text = String(value || "");
    if (/排名变化/.test(text)) return false;
    if (/变化|变动|相对|环比|同比|差异|提升|下降/.test(text)) return true;
    return !/投入产出比|投产比|ROI|ROAS/i.test(text) && /比|率|变化|相对|CTR|贡献|百分位/i.test(text);
  }

  function isIntegerSemantic(value) {
    return /天数|层级|成交笔数|展现|点击|访客|数量/i.test(String(value || ""));
  }

  function semanticFor(table, row, columnIndex) {
    const column = String(table.columns?.[columnIndex] || "");
    if (table.name === "对标总表") return `${column} ${row?.[1] || ""}`;
    if (table.name === "基础指标对比") return `${column} ${row?.[0] || ""}`;
    return column;
  }

  function formatValue(value, semantic = "") {
    if (isMissing(value)) return "—";
    if (typeof reportEngine?.formatMetricValue === "function") {
      const formatted = reportEngine.formatMetricValue(semantic, value);
      if (formatted !== "" && formatted !== null && formatted !== undefined) return String(formatted);
    }
    if (typeof value !== "number" || !Number.isFinite(value)) {
      if (typeof value === "object") {
        try { return JSON.stringify(value); } catch { return String(value); }
      }
      return String(value);
    }
    if (isPercentSemantic(semantic)) return new Intl.NumberFormat("zh-CN", { style: "percent", minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value);
    if (isIntegerSemantic(semantic)) return new Intl.NumberFormat("zh-CN", { maximumFractionDigits: 0 }).format(value);
    return new Intl.NumberFormat("zh-CN", { minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(value);
  }

  function formatGeneratedAt(value) {
    const date = new Date(value || Date.now());
    if (Number.isNaN(date.getTime())) return String(value || "");
    return new Intl.DateTimeFormat("zh-CN", {
      year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false,
    }).format(date).replace(/\//g, "-");
  }

  function columnWidth(table, columnIndex) {
    return Math.max(88, Math.min(460, Math.round((Number(table.widths?.[columnIndex]) || 15) * 6.6)));
  }

  function stickyOffsets(table) {
    const count = Math.max(0, Number(FREEZE_COLUMNS[table.name]) || 0);
    const offsets = [];
    let left = 0;
    for (let index = 0; index < count; index += 1) {
      offsets[index] = left;
      left += columnWidth(table, index);
    }
    return offsets;
  }

  function columnRole(table, columnIndex) {
    const column = String(table.columns?.[columnIndex] || "");
    if (table.name === "对标总表") return columnIndex === 2 ? "subject" : columnIndex === 3 ? "competitor" : columnIndex === 4 ? "difference" : "";
    if (table.name === "基础指标对比") return columnIndex === 1 ? "subject" : columnIndex === 2 ? "competitor" : columnIndex === 3 ? "difference" : "";
    if (/^主体/.test(column)) return "subject";
    if (/^(对手|目标对手)/.test(column)) return "competitor";
    if (/相对对手/.test(column)) return "difference";
    return "";
  }

  function rowRole(row) {
    const first = String(row?.[0] || "");
    const second = String(row?.[1] || "");
    if (/^主体/.test(first) || /^主体/.test(second)) return "subject";
    if (/目标对手|^对手|^竞品/.test(first) || /目标对手|^对手/.test(second)) return "competitor";
    return "";
  }

  function roleClass(role) {
    if (role === "subject") return " role-subject";
    if (role === "competitor") return " role-competitor";
    if (role === "difference") return " role-difference";
    return "";
  }

  function trendClass(value, role) {
    if (role !== "difference" || typeof value !== "number" || !Number.isFinite(value) || value === 0) return "";
    return value > 0 ? " trend-up" : " trend-down";
  }

  function wrapColumn(column) {
    return /标题|描述|打法|细节|动作|标签|图片|详情/.test(String(column || ""));
  }

  function isMetricColumn(table, columnIndex) {
    const column = String(table.columns?.[columnIndex] || "");
    if (["对标总表", "基础指标对比"].includes(table.name) && columnRole(table, columnIndex)) return true;
    if (/商品ID|场景编号|日期|开始|结束|对象|角色|渠道|页面指标|标题|描述|类目|生命周期|阶段名称|阶段描述|广告打法|执行细节|运营动作|一级场景|二级场景|关键词|词类型|标签|图片|详情/.test(column)) return false;
    return /GMV|消耗|占比|展现|点击|CTR|CPC|成交|ROI|ROAS|费比|转化率|贡献率|笔单价|天数|上架|排名|百分位|访客|数量|日均|变化|金额|价格|层级/i.test(column);
  }

  function hasNonZeroBusinessValue(value) {
    if (isMissing(value)) return false;
    if (typeof value === "number") return Number.isFinite(value) && Math.abs(value) > 1e-12;
    const text = String(value).trim().replace(/,/g, "");
    if (!text) return false;
    if (/^[+-]?0(?:\.0+)?(?:%|万|亿|元|次|笔)?$/i.test(text)) return false;
    if (/^[+-]?0(?:\.0+)?\s*(?:~|～|至|-)\s*[+-]?0(?:\.0+)?(?:%|万|亿|元|次|笔)?$/i.test(text)) return false;
    return true;
  }

  function urlCandidates(value, depth = 0) {
    if (depth > 2 || value == null) return [];
    if (Array.isArray(value)) return value.flatMap(entry => urlCandidates(entry, depth + 1));
    if (typeof value === "object") return Object.values(value).flatMap(entry => urlCandidates(entry, depth + 1));
    const text = String(value).trim();
    if (!text) return [];
    if (/^[{[]/.test(text)) {
      try { return urlCandidates(JSON.parse(text), depth + 1); } catch {}
    }
    if (/^(?:https?:)?\/\//i.test(text)) return [text];
    return text.match(/(?:https?:)?\/\/[^\s"'<>]+/gi) || [];
  }

  function normalizeHttpsUrl(value) {
    for (const candidate of urlCandidates(value)) {
      try {
        const parsed = new URL(candidate.startsWith("//") ? `https:${candidate}` : candidate);
        if (parsed.protocol === "https:") return parsed.href;
      } catch {}
    }
    return "";
  }

  function normalizeImageUrl(value) {
    const safe = normalizeHttpsUrl(value);
    if (!safe) return "";
    try {
      const parsed = new URL(safe);
      const knownImageHost = /(?:^|\.)(?:alicdn\.com|tbcdn\.cn|taobaocdn\.com|img\.example)$/i.test(parsed.hostname);
      const imagePath = /\.(?:avif|gif|jpe?g|png|webp)(?:$|[?&#])/i.test(`${parsed.pathname}${parsed.search}`);
      return knownImageHost || imagePath ? parsed.href : "";
    } catch { return ""; }
  }

  function columnIndex(table, name) {
    return table?.columns?.findIndex(column => String(column || "") === name) ?? -1;
  }

  function tableCell(table, row, name) {
    const index = columnIndex(table, name);
    return index >= 0 ? row?.[index] : "";
  }

  function productFromTable(table, report, role) {
    const subject = role === "subject";
    const row = (table?.rows || []).find(candidate => subject
      ? /^主体/.test(String(candidate?.[0] || ""))
      : /目标对手|^对手|^竞品/.test(String(candidate?.[0] || ""))) || [];
    const imageCell = tableCell(table, row, "图片/详情");
    const pictureUrl = normalizeImageUrl(subject ? (report.item?.pictureUrl || imageCell) : (report.item?.competitorPictureUrl || imageCell));
    const detailUrl = normalizeHttpsUrl(subject ? (report.item?.detailUrl || (!pictureUrl ? imageCell : "")) : (report.item?.competitorDetailUrl || (!pictureUrl ? imageCell : "")));
    return {
      id: String(tableCell(table, row, "商品ID") || (subject ? report.item?.id : report.item?.competitorId) || ""),
      title: String(tableCell(table, row, "商品标题") || (subject ? report.item?.title : report.item?.competitorTitle) || ""),
      category: tableCell(table, row, "类目/成功品描述"),
      price: tableCell(table, row, "标价/价格带"),
      lifecycle: tableCell(table, row, "生命周期"),
      gmv: tableCell(table, row, "30日GMV"),
      pictureUrl,
      detailUrl,
    };
  }

  function renderProductCard(product, role) {
    const subject = role === "subject";
    const roleLabel = subject ? "主体商品" : "目标对手";
    const fallback = String(product.title || roleLabel).trim().slice(0, 1) || "品";
    const image = product.pictureUrl
      ? `<img data-product-image src="${escapeHtml(product.pictureUrl)}" alt="${escapeHtml(product.title || roleLabel)}主图" loading="eager" decoding="async" referrerpolicy="no-referrer">`
      : "";
    const title = product.detailUrl
      ? `<a href="${escapeHtml(product.detailUrl)}" target="_blank" rel="noopener noreferrer">${escapeHtml(product.title || "未识别商品标题")}</a>`
      : escapeHtml(product.title || "未识别商品标题");
    const facts = [
      ["30日GMV", formatValue(product.gmv, "30日GMV")],
      ["生命周期", formatValue(product.lifecycle, "生命周期")],
      ["价格", formatValue(product.price, "价格")],
    ].filter(([, value]) => value !== "—");
    return `<article class="product-card${roleClass(role)}" data-product-role="${role}">
      <div class="product-media"><span aria-hidden="true">${escapeHtml(fallback)}</span>${image}</div>
      <div class="product-copy"><p class="product-role">${roleLabel}</p><h3>${title}</h3><p class="product-id">商品 ID ${escapeHtml(product.id || "—")}</p>
      ${facts.length ? `<dl>${facts.map(([label, value]) => `<div><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(value)}</dd></div>`).join("")}</dl>` : ""}
      ${product.category ? `<p class="product-category">${escapeHtml(product.category)}</p>` : ""}</div>
    </article>`;
  }

  function renderProductCompare(report, productTable) {
    const subject = productFromTable(productTable, report, "subject");
    const competitor = productFromTable(productTable, report, "competitor");
    return `<div class="product-grid">${renderProductCard(subject, "subject")}${renderProductCard(competitor, "competitor")}</div>`;
  }

  function filterSceneRows(table) {
    const groups = new Map();
    for (const row of table.rows || []) {
      const key = [row?.[1], row?.[2], row?.[3], row?.[4]].map(value => String(value ?? "")).join("\u0001");
      const group = groups.get(key) || [];
      group.push(row);
      groups.set(key, group);
    }
    const active = new Set([...groups].filter(([, rows]) => rows.some(row => row.slice(5).some(value => !isMissing(value)))).map(([key]) => key));
    return (table.rows || []).filter(row => active.has([row?.[1], row?.[2], row?.[3], row?.[4]].map(value => String(value ?? "")).join("\u0001")));
  }

  function projectChannelTable(table) {
    const activeRows = (table.rows || []).filter(row => row?.[0] !== "合计" && row.slice(2).some(value => !isMissing(value)));
    const total = (table.rows || []).find(row => row?.[0] === "合计");
    return { ...table, rows: total ? [...activeRows, total] : activeRows };
  }

  function validatedSubjectDailyRows(table, report) {
    const source = Array.isArray(table?.subjectDailyRows) ? table.subjectDailyRows : [];
    if (!source.length) return [];
    const byDate = new Map();
    for (const row of source) {
      const date = String(row?.[0] || "");
      const gmv = Number(row?.[1]);
      if (!/^20\d{2}-\d{2}-\d{2}$/.test(date) || !Number.isFinite(gmv) || gmv < 0 || byDate.has(date)) return [];
      byDate.set(date, gmv);
    }
    const projected = [...byDate].sort(([left], [right]) => left.localeCompare(right));
    const periodTable = (report?.tables || []).find(current => current?.name === "周期汇总");
    const expectedTotal = Number(periodValue(periodTable, "subject", "总GMV"));
    const actualTotal = projected.reduce((sum, row) => sum + row[1], 0);
    if (!Number.isFinite(expectedTotal) || Math.abs(actualTotal - expectedTotal) > 0.01) return [];
    return projected;
  }

  function projectDailyTable(table, report) {
    if ((table.columns || []).includes("主体日GMV") && (table.columns || []).includes("对手日GMV")) return table;
    const columns = (table.columns || []).map((column, index) => {
      if (index === 1 && column === "日GMV") return "对手日GMV";
      if (index >= 2 && index <= 8 && !/^对手/.test(String(column || ""))) return `对手${column}`;
      return column;
    });
    const subjectDaily = validatedSubjectDailyRows(table, report);
    if (!subjectDaily.length) return { ...table, columns };
    const subjectByDate = new Map(subjectDaily);
    const competitorByDate = new Map((table.rows || []).map(row => [String(row?.[0] || ""), row]));
    const dates = [...new Set([...competitorByDate.keys(), ...subjectByDate.keys()])].filter(Boolean).sort();
    return {
      ...table,
      columns: [columns[0], "主体日GMV", ...columns.slice(1)],
      widths: [13, 16, ...(table.widths || []).slice(1)],
      rows: dates.map(date => {
        const competitor = competitorByDate.get(date) || [date, ...Array(Math.max(0, columns.length - 1)).fill("")];
        return [date, subjectByDate.has(date) ? subjectByDate.get(date) : "", ...competitor.slice(1)];
      })
    };
  }

  function projectTable(table, report) {
    if (table.name === "渠道花费") return projectChannelTable(table);
    if (table.name === "日GMV与费比") return projectDailyTable(table, report);
    if (table.name === "一级场景" || table.name === "二级场景") return { ...table, rows: filterSceneRows(table) };
    return table;
  }

  function tableHasBusinessData(table) {
    if (!table) return false;
    if (["报告总览", "商品与成功品", "对标总表", "周期汇总", "基础指标对比"].includes(table.name)) return true;
    if (table.name === "关键词样本") return (table.rows || []).some(row => String(row?.[0] || "").trim());
    if (table.name === "成长阶段数据") return (table.rows || []).some(row => row.some(value => !isMissing(value)));
    if (table.name === "一级场景" || table.name === "二级场景") return (table.rows || []).length > 0;
    if (table.name === "渠道花费") return (table.rows || []).some(row => row.slice(1).some(value => !isMissing(value)));
    if (table.name === "日GMV与费比") return (table.rows || []).some(row => row.slice(1, -1).some(value => !isMissing(value)));
    return (table.rows || []).length > 0;
  }

  function renderCellContent(table, column, value, semantic) {
    if (table.name === "商品与成功品" && /图片|详情/.test(String(column || ""))) {
      const imageUrl = normalizeImageUrl(value);
      if (imageUrl) return `<img class="table-product-image" data-product-image src="${escapeHtml(imageUrl)}" alt="商品主图" loading="lazy" decoding="async" referrerpolicy="no-referrer">`;
      const detailUrl = normalizeHttpsUrl(value);
      if (detailUrl) return `<a class="detail-link" href="${escapeHtml(detailUrl)}" target="_blank" rel="noopener noreferrer">打开详情</a>`;
    }
    return escapeHtml(formatValue(value, semantic));
  }

  function renderTable(table, options = {}) {
    const offsets = stickyOffsets(table);
    const headCells = table.columns.map((column, columnIndex) => {
      const width = columnWidth(table, columnIndex);
      const offset = offsets[columnIndex];
      const sticky = offset == null ? "" : " sticky-col";
      const style = `${offset == null ? "" : `--sticky-left:${offset}px;`}min-width:${width}px;width:${width}px`;
      const metric = isMetricColumn(table, columnIndex) ? " metric-head" : "";
      return `<th class="${`${roleClass(columnRole(table, columnIndex))}${metric}${sticky}`.trim()}" style="${style}">${escapeHtml(column)}</th>`;
    }).join("");
    const head = table.groupedChannel
      ? `<tr><th class="sticky-col" rowspan="2" style="--sticky-left:0px;min-width:${columnWidth(table, 0)}px;width:${columnWidth(table, 0)}px">渠道</th><th class="metric-group" colspan="2">周期消耗</th><th class="metric-group" colspan="2">周期占比</th></tr><tr>${table.columns.slice(1).map((column, offsetIndex) => {
        const columnIndex = offsetIndex + 1;
        const role = columnRole(table, columnIndex);
        return `<th class="${`${roleClass(role)} metric-head`.trim()}" style="min-width:${columnWidth(table, columnIndex)}px;width:${columnWidth(table, columnIndex)}px">${role === "subject" ? "主体" : "目标对手"}</th>`;
      }).join("")}</tr>`
      : `<tr>${headCells}</tr>`;
    const body = table.rows.map((row) => {
      const rowClass = roleClass(rowRole(row));
      const cells = table.columns.map((column, columnIndex) => {
        const width = columnWidth(table, columnIndex);
        const offset = offsets[columnIndex];
        const sticky = offset == null ? "" : " sticky-col";
        const style = `${offset == null ? "" : `--sticky-left:${offset}px;`}min-width:${width}px;width:${width}px`;
        const value = row?.[columnIndex];
        const role = columnRole(table, columnIndex);
        const numeric = isMetricColumn(table, columnIndex) || (typeof value === "number" && Number.isFinite(value)) ? " metric-cell numeric" : "";
        const wrap = wrapColumn(column) ? " wrap" : "";
        const classes = `${roleClass(role)}${trendClass(value, role)}${numeric}${wrap}${sticky}`.trim();
        return `<td class="${classes}" style="${style}">${renderCellContent(table, column, value, semanticFor(table, row, columnIndex))}</td>`;
      }).join("");
      return `<tr class="${rowClass.trim()}">${cells}</tr>`;
    }).join("");
    const sectionId = SECTION_IDS[table.name];
    const sectionNumber = String(options.sectionNumber || REQUIRED_TABLES.indexOf(table.name) + 1).padStart(2, "0");
    return `<section class="report-section" id="${sectionId}">
      <div class="section-heading"><div><p class="section-index">${sectionNumber}</p><h2>${escapeHtml(table.name)}</h2></div><span class="row-total">${table.rows.length} 行</span></div>
      ${table.subtitle ? `<p class="section-note">${escapeHtml(table.subtitle)}</p>` : ""}
      ${options.prelude || ""}
      <div class="table-tools"><label>筛选本表<input type="search" data-table-filter aria-label="筛选${escapeHtml(table.name)}" placeholder="输入关键词"></label><span data-filter-count>${table.rows.length} / ${table.rows.length}</span></div>
      <div class="table-shell"><table><thead>${head}</thead><tbody>${body}</tbody></table></div>
    </section>`;
  }

  function periodRow(table, role) {
    return (table?.rows || []).find(row => role === "subject"
      ? /主体/.test(String(row?.[1] || ""))
      : /目标对手|对手|竞品/.test(String(row?.[1] || ""))) || [];
  }

  function periodValue(table, role, column) {
    const index = columnIndex(table, column);
    return index >= 0 ? periodRow(table, role)?.[index] : "";
  }

  function overviewMetricRows(overviewTable) {
    const wanted = ["总GMV", "推广消耗", "费比", "ROI", "PPC", "全域ROAS"];
    return wanted.map(label => (overviewTable?.rows || []).find(row => String(row?.[0] || "") === label))
      .filter(Boolean)
      .map(row => ({ label: row[0], subject: row[1], competitor: row[2], scope: row[3] }));
  }

  function renderDailySummary(periodTable, overviewTable) {
    const overviewMetrics = overviewMetricRows(overviewTable);
    const metrics = overviewMetrics.length ? overviewMetrics : ["总GMV", "日均GMV", "广告消耗", "费比"].map(label => ({
      label,
      subject: periodValue(periodTable, "subject", label),
      competitor: periodValue(periodTable, "competitor", label),
      scope: ""
    })).filter(metric => !isMissing(metric.subject) || !isMissing(metric.competitor));
    if (!metrics.length) return "";
    return `<div class="daily-summary" aria-label="主体与目标对手周期汇总">${metrics.map(metric => `<article><p>${escapeHtml(metric.label)}</p><div><span class="role-subject"><small>主体</small><strong>${escapeHtml(formatValue(metric.subject, metric.label))}</strong></span><span class="role-competitor"><small>目标对手</small><strong>${escapeHtml(formatValue(metric.competitor, metric.label))}</strong></span></div>${metric.scope ? `<small class="metric-scope">${escapeHtml(metric.scope)}</small>` : ""}</article>`).join("")}</div>`;
  }

  function axisValue(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) return "—";
    if (Math.abs(number) >= 100000000) return `${(number / 100000000).toFixed(number % 100000000 ? 1 : 0)}亿`;
    if (Math.abs(number) >= 10000) return `${(number / 10000).toFixed(number % 10000 ? 1 : 0)}万`;
    return new Intl.NumberFormat("zh-CN", { maximumFractionDigits: 0 }).format(number);
  }

  function seriesPath(values, xFor, yFor) {
    let drawing = false;
    return values.map((value, index) => {
      if (!Number.isFinite(value)) { drawing = false; return ""; }
      const command = drawing ? "L" : "M";
      drawing = true;
      return `${command}${xFor(index).toFixed(1)} ${yFor(value).toFixed(1)}`;
    }).filter(Boolean).join(" ");
  }

  function renderDailyChart(table, periodTable) {
    const rows = table?.rows || [];
    if (rows.length < 2) return "";
    const competitorIndex = table.columns.findIndex(column => /^(?:对手)?日GMV$/.test(String(column || "")));
    const subjectIndex = table.columns.findIndex(column => /^主体日GMV$/.test(String(column || "")));
    const competitorValues = rows.map(row => Number.isFinite(row?.[competitorIndex]) ? row[competitorIndex] : NaN);
    const subjectValues = subjectIndex >= 0 ? rows.map(row => Number.isFinite(row?.[subjectIndex]) ? row[subjectIndex] : NaN) : [];
    const allValues = [...competitorValues, ...subjectValues].filter(Number.isFinite);
    if (competitorIndex < 0 || allValues.length < 2) return "";
    const width = 780;
    const height = 290;
    const left = 66;
    const right = 18;
    const top = 22;
    const bottom = 48;
    const maximum = Math.max(...allValues, 1);
    const chartWidth = width - left - right;
    const chartHeight = height - top - bottom;
    const xFor = index => left + index * chartWidth / Math.max(1, rows.length - 1);
    const yFor = value => top + (1 - value / maximum) * chartHeight;
    const yTicks = [0, .25, .5, .75, 1].map(ratio => {
      const value = maximum * ratio;
      const y = yFor(value);
      return `<g><line x1="${left}" y1="${y.toFixed(1)}" x2="${width - right}" y2="${y.toFixed(1)}" stroke="#dbe7e5"/><text x="${left - 10}" y="${(y + 4).toFixed(1)}" text-anchor="end">${escapeHtml(axisValue(value))}</text></g>`;
    }).join("");
    const tickStep = rows.length >= 20 ? 5 : rows.length >= 8 ? 2 : 1;
    const xIndexes = [];
    for (let index = 0; index < rows.length; index += tickStep) xIndexes.push(index);
    if (xIndexes.at(-1) !== rows.length - 1) xIndexes.push(rows.length - 1);
    const compactDate = value => String(value || "").slice(5);
    const xTicks = xIndexes.map((index, tickIndex) => {
      const date = String(rows[index]?.[0] || "");
      const anchor = tickIndex === 0 ? "start" : tickIndex === xIndexes.length - 1 ? "end" : "middle";
      const x = xFor(index).toFixed(1);
      return `<g data-x-tick data-date="${escapeHtml(date)}"><line x1="${x}" y1="${height - bottom}" x2="${x}" y2="${height - bottom + 5}" stroke="#b8cbc8"/><text x="${x}" y="${height - 12}" text-anchor="${anchor}">${escapeHtml(compactDate(date))}</text></g>`;
    }).join("");
    const competitorPath = seriesPath(competitorValues, xFor, yFor);
    const subjectPath = subjectValues.length ? seriesPath(subjectValues, xFor, yFor) : "";
    const seriesPoints = (values, series) => values.map((value, index) => {
      if (!Number.isFinite(value)) return "";
      const date = String(rows[index]?.[0] || "");
      const role = series === "subject" ? "主体" : "目标对手";
      const metric = "日GMV";
      const formatted = formatValue(value, "GMV");
      const tooltip = `${date}｜${metric}｜${role}：${formatted}`;
      const cx = xFor(index).toFixed(1);
      const cy = yFor(value).toFixed(1);
      return `<g class="chart-point" data-chart-point data-tooltip="${escapeHtml(tooltip)}" data-period="${escapeHtml(date)}" data-metric="${metric}" data-role="${escapeHtml(role)}" data-value="${escapeHtml(value)}" tabindex="0" focusable="true" role="img" aria-label="${escapeHtml(tooltip)}"><circle class="chart-point-hit" cx="${cx}" cy="${cy}" r="10"/><circle class="chart-point-visible" data-series-point="${series}" data-date="${escapeHtml(date)}" data-value="${escapeHtml(value)}" cx="${cx}" cy="${cy}" r="3" fill="${series === "subject" ? "#4d89c9" : "#ed9a46"}"/><title>${escapeHtml(tooltip)}</title></g>`;
    }).join("");
    const mode = subjectPath ? "主体与目标对手逐日" : "目标对手逐日";
    return `<article class="visual-card daily-visual"><div class="visual-title"><div><strong>分日 GMV 对比</strong><small>${escapeHtml(rows[0]?.[0] || "")} 至 ${escapeHtml(rows.at(-1)?.[0] || "")}</small></div><span>${rows.length} 天</span></div>
      <div class="chart-legend"><span class="legend-competitor">目标对手日GMV</span>${subjectPath ? `<span class="legend-subject">主体日GMV</span>` : ""}</div>
      <svg viewBox="0 0 ${width} ${height}" role="img" aria-label="${escapeHtml(mode)}">${yTicks}${xTicks}<path data-series="competitor" d="${competitorPath}" fill="none" stroke="#ed9a46" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>${seriesPoints(competitorValues, "competitor")}${subjectPath ? `<path data-series="subject" d="${subjectPath}" fill="none" stroke="#4d89c9" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>${seriesPoints(subjectValues, "subject")}` : ""}</svg>
    </article>`;
  }

  function renderChannelChart(table) {
    if (!table) return "";
    const subjectIndex = table.columns.findIndex((column) => /^主体\d+日消耗$/.test(String(column || "")));
    const competitorIndex = table.columns.findIndex((column) => /^对手\d+日消耗$/.test(String(column || "")));
    if (subjectIndex < 0 || competitorIndex < 0) return "";
    const rows = table.rows.filter((row) => row?.[0] !== "合计"
      && [row?.[subjectIndex], row?.[competitorIndex]].some(hasNonZeroBusinessValue)).slice(0, 5);
    const values = rows.flatMap((row) => [row[subjectIndex], row[competitorIndex]]).filter((value) => typeof value === "number" && Number.isFinite(value));
    if (!values.length) return "";
    const maximum = Math.max(...values, 1);
    const bars = rows.map((row) => {
      const subjectPresent = typeof row[subjectIndex] === "number" && Number.isFinite(row[subjectIndex]);
      const competitorPresent = typeof row[competitorIndex] === "number" && Number.isFinite(row[competitorIndex]);
      const subject = subjectPresent ? row[subjectIndex] : 0;
      const competitor = competitorPresent ? row[competitorIndex] : 0;
      const subjectWidth = Math.max(0, Math.min(100, subject / maximum * 100));
      const competitorWidth = Math.max(0, Math.min(100, competitor / maximum * 100));
      return `<div class="bar-row"><strong>${escapeHtml(row[0])}</strong><div class="bar-pair"><div><span>主体</span><i class="bar-track${subjectPresent ? "" : " is-missing"}">${subjectPresent ? `<b class="bar-subject" style="width:${subjectWidth.toFixed(2)}%"></b>` : ""}</i><em>${escapeHtml(formatValue(row[subjectIndex], table.columns[subjectIndex]))}</em></div><div><span>对手</span><i class="bar-track${competitorPresent ? "" : " is-missing"}">${competitorPresent ? `<b class="bar-competitor" style="width:${competitorWidth.toFixed(2)}%"></b>` : ""}</i><em>${escapeHtml(formatValue(row[competitorIndex], table.columns[competitorIndex]))}</em></div></div></div>`;
    }).join("");
    return `<article class="visual-card"><div class="visual-title"><div><strong>渠道花费对比</strong><small>主体与目标对手</small></div><span>${rows.length} 个有效渠道</span></div><div class="channel-bars">${bars}</div></article>`;
  }

  function renderOverview(table, report, tableByName) {
    const pairedMetrics = overviewMetricRows(table);
    const cards = pairedMetrics.length
      ? pairedMetrics.map(metric => `<article class="metric-card"><p>${escapeHtml(metric.label)}</p><div class="metric-pair"><span class="role-subject"><small>主体</small><strong>${escapeHtml(formatValue(metric.subject, metric.label))}</strong></span><span class="role-competitor"><small>目标对手</small><strong>${escapeHtml(formatValue(metric.competitor, metric.label))}</strong></span></div>${metric.scope ? `<small class="metric-scope">${escapeHtml(metric.scope)}</small>` : ""}</article>`).join("")
      : (table.kpis || []).map((card, index) => {
        const role = card.role || (index % 2 === 0 ? "subject" : "competitor");
        return `<article class="metric-card${roleClass(role)}"><p>${escapeHtml(card.label || "指标")}</p><strong>${escapeHtml(formatValue(card.value, card.label || ""))}</strong></article>`;
      }).join("");
    // 平台少数据、花费覆盖、取数时段这几行是对读者的口径交代，不能被对象表过滤掉。
    const noticeRows = (table.rows || []).filter((row) => ["数据说明", "花费覆盖", "取数时段提示"].includes(String(row?.[0] || "")));
    const notices = noticeRows.map((row) => `<li><strong>${escapeHtml(row[0])}</strong>${[row[1], row[2], row[3]].map((cell) => String(cell || "").trim()).filter(Boolean).map((cell) => `<span>${escapeHtml(cell)}</span>`).join("")}</li>`).join("");
    const visuals = [renderDailyChart(tableByName.get("日GMV与费比"), tableByName.get("周期汇总")), renderChannelChart(tableByName.get("渠道花费"))].filter(Boolean).join("");
    return `<section class="report-section overview-section" id="overview">
      <div class="section-heading"><div><p class="section-index">01</p><h2>报告总览</h2></div><span class="row-total">${escapeHtml(report.periodLabel || "业务周期")}</span></div>
      ${table.subtitle ? `<p class="section-note">${escapeHtml(table.subtitle)}</p>` : ""}
      ${renderProductCompare(report, tableByName.get("商品与成功品"))}
      <div class="metric-grid">${cards}</div>
      <div class="period-band"><span>分析周期</span><strong>${escapeHtml(report.period?.startDate || "—")} 至 ${escapeHtml(report.period?.endDate || "—")}</strong></div>
      ${notices ? `<ul class="data-notice">${notices}</ul>` : ""}
      ${visuals ? `<h3 class="subheading">数据趋势与结构</h3><div class="visual-grid">${visuals}</div>` : ""}
    </section>`;
  }

  function assertReport(report) {
    if (!report || typeof report !== "object") throw new TypeError("缺少商品成长报告数据");
    const tables = Array.isArray(report.tables) ? report.tables : [];
    const readable = tables.filter(table => REQUIRED_TABLES.includes(table?.name)
      && Array.isArray(table?.columns)
      && Array.isArray(table?.rows)
      && table.rows.every(Array.isArray));
    if (!readable.length) throw new Error("HTML 报告没有可读取的业务数据表");
    return readable;
  }

  function buildHtml(report, options = {}) {
    const readableTables = assertReport(report);
    const tableByName = new Map(readableTables.map((table) => {
      const projected = projectTable(table, report);
      return [projected.name, projected];
    }));
    const generatedAt = options.generatedAt || report.finishedAt || new Date().toISOString();
    const requestedTitle = options.title || report.title || "达摩盘商品成长竞品对标报告｜少壮AI自动化";
    const title = requestedTitle.includes("少壮AI自动化") ? requestedTitle : `${requestedTitle}｜少壮AI自动化`;
    const watermark = Array.from({ length: 54 }, () => "<span>少壮AI自动化 · shaozhuangai.com</span>").join("");
    const visibleNames = REQUIRED_TABLES.filter(name => tableHasBusinessData(tableByName.get(name)));
    const nav = visibleNames.map((name) => `<a href="#${SECTION_IDS[name]}">${escapeHtml(name)}</a>`).join("");
    const sections = visibleNames.map((name, index) => {
      if (name === "报告总览") return renderOverview(tableByName.get(name), report, tableByName);
      const prelude = name === "日GMV与费比" ? renderDailySummary(tableByName.get("周期汇总"), tableByName.get("报告总览")) : "";
      return renderTable(tableByName.get(name), { sectionNumber: index + 1, prelude });
    }).join("");
    return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="color-scheme" content="light">
  <title>${escapeHtml(title)}</title>
  <style>
    :root{--ink:#17313a;--muted:#667c83;--line:#dbe7e5;--paper:#fff;--canvas:#f2f7f6;--deep:#074d4c;--teal:#0f766e;--mint:#dff5ef;--subject:#eaf3ff;--subject-ink:#185a91;--competitor:#fff1df;--competitor-ink:#a85b12;--difference:#f3ecff;--up:#d33c32;--down:#087f5b;--table-body:#edf5f3;--shadow:0 14px 38px rgba(23,49,58,.09)}
    .report-watermark{position:fixed;inset:-16vh -12vw;z-index:2147483646;display:grid;grid-template-columns:repeat(6,minmax(220px,1fr));grid-auto-rows:150px;align-content:center;overflow:hidden;pointer-events:none;transform:rotate(-19deg) scale(1.08);transform-origin:center;opacity:.075}.report-watermark span{display:grid;place-items:center;color:#0b625d;font-size:17px;font-weight:800;letter-spacing:.04em;white-space:nowrap;user-select:none;-webkit-print-color-adjust:exact;print-color-adjust:exact}
    *{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;color:var(--ink);background:radial-gradient(circle at 85% 0,#dff4ef 0,transparent 28rem),var(--canvas);font:14px/1.55 -apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei","Segoe UI",sans-serif;font-variant-numeric:tabular-nums}.hero{padding:42px max(24px,calc((100vw - 1720px)/2));color:#fff;background:linear-gradient(120deg,#063f43,#086660 58%,#109070)}.eyebrow{margin:0 0 8px;color:#aee9dd;font-weight:700;letter-spacing:.14em}.hero h1{margin:0;font-size:clamp(28px,4vw,46px);line-height:1.15}.hero-meta{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:18px}.hero-meta span{padding:6px 11px;border:1px solid rgba(255,255,255,.22);border-radius:999px;background:rgba(255,255,255,.08)}.actions{margin-left:auto}.actions button{padding:8px 13px;color:#084c49;background:#fff;border:0;border-radius:8px;cursor:pointer;font:inherit;font-weight:700}.nav-wrap{position:sticky;top:0;z-index:30;padding:0 max(18px,calc((100vw - 1720px)/2));background:rgba(255,255,255,.94);border-bottom:1px solid var(--line);backdrop-filter:blur(12px)}nav{display:flex;gap:4px;overflow:auto}nav a{flex:0 0 auto;padding:14px 15px;color:#426069;text-decoration:none;border-bottom:3px solid transparent}nav a:hover,nav a:focus{color:var(--teal);border-color:var(--teal)}main{display:grid;gap:22px;max-width:1720px;min-width:0;margin:26px auto;padding:0 18px 42px}.report-section{min-width:0;scroll-margin-top:72px;padding:24px;background:var(--paper);border:1px solid var(--line);border-radius:16px;box-shadow:var(--shadow)}.section-heading{display:flex;align-items:center;justify-content:space-between;gap:14px}.section-heading>div{display:flex;align-items:center;gap:10px}.section-index{margin:0;padding:4px 8px;color:#fff;background:var(--teal);border-radius:7px;font-size:11px;font-weight:800}.section-heading h2{margin:0;font-size:22px}.row-total{padding:4px 9px;color:var(--teal);background:var(--mint);border-radius:999px;font-size:12px}.section-note{margin:12px 0 18px;padding:10px 12px;color:#49666d;background:#f1f8f6;border-left:3px solid #52aa96;border-radius:6px}.data-notice{display:grid;gap:8px;margin:16px 0 0;padding:0;list-style:none}.data-notice li{display:flex;flex-wrap:wrap;gap:10px;align-items:baseline;padding:10px 12px;color:#7a5b18;background:#fdf6e6;border-left:3px solid #e0a52a;border-radius:6px;font-size:13px}.data-notice strong{color:#5d430c}.product-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin-bottom:14px}.product-card{display:grid;grid-template-columns:132px minmax(0,1fr);gap:16px;min-width:0;padding:14px;border:1px solid var(--line);border-radius:14px}.product-media{position:relative;display:grid;place-items:center;width:132px;height:132px;overflow:hidden;color:#fff;background:linear-gradient(145deg,#b8d7d1,#7aaea5);border-radius:11px;font-size:38px;font-weight:800}.product-media>span{opacity:.7}.product-media img{position:absolute;inset:0;width:100%;height:100%;object-fit:contain;background:#fff}.product-copy{min-width:0}.product-role{display:inline-flex;margin:0 0 6px;padding:3px 8px;border-radius:999px;background:rgba(255,255,255,.74);font-size:11px;font-weight:800}.product-copy h3{display:-webkit-box;overflow:hidden;margin:0;font-size:17px;line-height:1.45;-webkit-box-orient:vertical;-webkit-line-clamp:2}.product-copy h3 a{color:inherit;text-decoration:none}.product-copy h3 a:hover{text-decoration:underline}.product-id,.product-category{margin:5px 0 0;color:var(--muted);font-size:12px}.product-category{display:-webkit-box;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:2}.product-copy dl{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px;margin:11px 0 0}.product-copy dl div{min-width:0;padding:7px 8px;background:rgba(255,255,255,.72);border-radius:8px}.product-copy dt{color:var(--muted);font-size:10px}.product-copy dd{overflow:hidden;margin:2px 0 0;text-overflow:ellipsis;white-space:nowrap;font-size:12px;font-weight:700;text-align:right}.metric-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;min-width:0}.metric-card{min-width:0;padding:16px;border:1px solid var(--line);border-radius:12px;background:#fff}.metric-card p{margin:0;color:var(--muted);font-size:12px}.metric-card strong{display:block;margin-top:8px;color:#103d46;font-size:25px;text-align:right}.metric-pair{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px;margin-top:9px}.metric-pair>span{display:block;min-width:0;padding:8px;border-radius:8px}.metric-pair small{display:block;font-size:10px}.metric-card .metric-pair strong{overflow:hidden;margin-top:2px;font-size:16px;text-overflow:ellipsis;white-space:nowrap}.metric-scope{display:block;margin-top:7px;color:var(--muted);font-size:10px;line-height:1.35}.period-band{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-top:14px;padding:13px 16px;color:#fff;background:linear-gradient(135deg,#0b5e5c,#158875);border-radius:11px}.period-band span{color:#c8eee6;font-size:12px}.period-band strong{font-size:16px}.daily-summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin:14px 0}.daily-summary article{padding:12px;border:1px solid var(--line);border-radius:11px;background:#fbfdfd}.daily-summary article>p{margin:0 0 7px;color:var(--muted);font-size:12px}.daily-summary article>div{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px}.daily-summary span{display:block;min-width:0;padding:7px 8px;border-radius:8px}.daily-summary small{display:block;font-size:10px}.daily-summary strong{display:block;overflow:hidden;margin-top:2px;text-align:right;text-overflow:ellipsis;white-space:nowrap;font-size:14px}.daily-summary .metric-scope{margin-top:7px;color:var(--muted);line-height:1.35}.subheading{margin:22px 0 12px;font-size:16px}.visual-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;min-width:0}.visual-grid>.visual-card:only-child{grid-column:1/-1}.visual-card{min-width:0;overflow:hidden;padding:15px;border:1px solid var(--line);border-radius:12px;background:#fbfdfd}.visual-title{display:flex;align-items:flex-start;justify-content:space-between;gap:12px}.visual-title strong{display:block;font-size:16px}.visual-title small{display:block;margin-top:2px;color:var(--muted)}.visual-title>span{color:var(--teal);font-size:12px}.chart-legend{display:flex;justify-content:flex-end;gap:14px;margin-top:5px;color:var(--muted);font-size:11px}.chart-legend span:before{display:inline-block;width:18px;height:3px;margin:0 6px 3px 0;background:#ed9a46;content:""}.chart-legend .legend-subject:before{background:#4d89c9}.chart-legend .dashed:before{height:0;border-top:2px dashed #4d89c9;background:none}.visual-card svg{display:block;width:100%;height:auto;margin-top:4px}.visual-card svg text{fill:#698086;font:11px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}.chart-point{outline:none;cursor:crosshair}.chart-point-hit{fill:transparent;stroke:transparent;pointer-events:all}.chart-point-visible{pointer-events:none}.chart-point:focus .chart-point-visible{stroke:#fff;stroke-width:2}.chart-tooltip{position:fixed;z-index:2147483647;max-width:min(380px,calc(100vw - 16px));padding:8px 10px;border:1px solid rgba(255,255,255,.22);border-radius:7px;color:#fff;background:#103d46;box-shadow:0 8px 24px rgba(5,42,45,.28);font-size:12px;font-weight:700;line-height:1.45;pointer-events:none;white-space:nowrap}.channel-bars{display:grid;gap:10px;margin-top:13px}.bar-row{display:grid;grid-template-columns:92px minmax(0,1fr);gap:9px;align-items:start}.bar-row>strong{font-size:12px}.bar-pair{display:grid;gap:5px}.bar-pair>div{display:grid;grid-template-columns:30px minmax(70px,1fr) 78px;gap:6px;align-items:center}.bar-pair span{color:var(--muted);font-size:11px}.bar-track{display:block;height:7px;overflow:hidden;background:#e7efed;border-radius:999px}.bar-track.is-missing{background:repeating-linear-gradient(135deg,#edf2f1 0,#edf2f1 4px,#d7e1df 4px,#d7e1df 7px)}.bar-track b{display:block;height:100%;border-radius:999px}.bar-subject{background:#5b9bd5}.bar-competitor{background:#ed9a46}.bar-pair em{font-style:normal;text-align:right;font-size:11px}.table-tools{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:12px 0 10px;color:var(--muted);font-size:12px}.table-tools label{display:flex;align-items:center;gap:8px}.table-tools input{width:min(280px,48vw);padding:7px 9px;border:1px solid #bed3cf;border-radius:8px;outline:none;font:inherit}.table-tools input:focus{border-color:var(--teal);box-shadow:0 0 0 3px rgba(15,118,110,.11)}.table-shell{width:100%;max-width:100%;min-width:0;max-height:72vh;overflow:auto;background:#fff;border:1px solid var(--line);border-radius:10px}.table-shell table{width:100%;border-collapse:separate;border-spacing:0;background:#fff;font-size:12px}.table-shell tbody{background:var(--table-body)}th,td{padding:9px 10px;border-right:1px solid #e4eceb;border-bottom:1px solid #e4eceb;text-align:left;vertical-align:middle;white-space:nowrap}th{position:sticky;top:0;z-index:8;color:#fff;background:#0d716b;font-weight:700}.table-shell tbody td{background-color:var(--table-body)}.metric-head,.metric-group{text-align:center;vertical-align:middle}.metric-cell,.numeric{text-align:right;vertical-align:middle;font-variant-numeric:tabular-nums}.table-product-image{display:block;width:72px;height:72px;object-fit:contain;background:#fff;border:1px solid var(--line);border-radius:7px}.detail-link{color:var(--teal);font-weight:700}tbody tr:nth-child(even)>td{background-color:var(--table-body)}tbody tr:hover>td{background-color:#eef8f5}.wrap{white-space:normal;line-height:1.55}.role-subject{color:var(--subject-ink);background-color:var(--subject)!important}.role-competitor{color:var(--competitor-ink);background-color:var(--competitor)!important}.role-difference{background-color:var(--difference)!important}tbody tr.role-subject>td{color:var(--subject-ink);background-color:var(--subject)!important}tbody tr.role-competitor>td{color:var(--competitor-ink);background-color:var(--competitor)!important}.trend-up{color:var(--up)!important}.trend-down{color:var(--down)!important}.sticky-col{position:sticky;left:var(--sticky-left);z-index:5;background:var(--table-body)}.role-subject>.sticky-col,.row-subject>.sticky-col{background:var(--subject)!important}.role-competitor>.sticky-col,.row-competitor>.sticky-col{background:var(--competitor)!important}thead .sticky-col{z-index:12;background:#0d716b}.footer{max-width:1720px;margin:0 auto 30px;padding:0 20px;color:#73898e;text-align:center;font-size:12px}[hidden]{display:none!important}
    .table-shell thead th{color:#fff!important;background:#0d716b!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
    .table-shell thead tr:nth-child(2) th{top:36px}
    @media(max-width:980px){.hero{padding:30px 20px}.actions{width:100%;margin-left:0}.report-section{padding:16px}.metric-grid,.daily-summary{grid-template-columns:repeat(2,minmax(0,1fr))}.visual-grid,.product-grid{grid-template-columns:1fr}.nav-wrap{padding:0 8px}}
    @media(max-width:560px){.metric-grid,.daily-summary{grid-template-columns:1fr}.product-card{grid-template-columns:96px minmax(0,1fr)}.product-media{width:96px;height:96px}.product-copy dl{grid-template-columns:1fr}.bar-row{grid-template-columns:1fr}.period-band{align-items:flex-start;flex-direction:column}.chart-legend{justify-content:flex-start;flex-wrap:wrap}}
    @media print{body{background:#fff}.report-watermark{position:fixed!important;display:grid!important;opacity:.085!important}.hero{padding:24px;background:#075b57!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}.actions,.nav-wrap,.table-tools,.chart-tooltip{display:none!important}.report-section{break-inside:avoid;box-shadow:none}.table-shell{max-height:none;overflow:visible}.sticky-col,th{position:static}main{display:block;margin:0;padding:16px}.report-section{margin-bottom:16px}}
  </style>
</head>
<body>
  <div class="report-watermark" data-report-watermark aria-hidden="true">${watermark}</div>
  <header class="hero">
    <p class="eyebrow">DAMOPAN · GROWTH BENCHMARK</p>
    <h1>${escapeHtml(title)}</h1>
    <div class="hero-meta"><span>主体：${escapeHtml(report.item?.title || "—")}（${escapeHtml(report.item?.id || "—")}）</span><span>目标对手：${escapeHtml(report.item?.competitorTitle || "—")}（${escapeHtml(report.item?.competitorId || "—")}）</span><span>生成时间：${escapeHtml(formatGeneratedAt(generatedAt))}</span><div class="actions"><button type="button" data-print>打印 / 保存 PDF</button></div></div>
  </header>
  <div class="nav-wrap"><nav aria-label="报告目录">${nav}</nav></div>
  <main>${sections}</main>
  <footer class="footer">${escapeHtml(title)}</footer>
  <div class="chart-tooltip" data-chart-tooltip role="status" hidden></div>
  <script>
    (() => {
      document.querySelector('[data-print]')?.addEventListener('click', () => window.print());
      const chartTooltip = document.querySelector('[data-chart-tooltip]');
      let activeChartPoint = null;
      const positionChartTooltip = (clientX, clientY) => {
        if (!chartTooltip || chartTooltip.hidden) return;
        const bounds = chartTooltip.getBoundingClientRect();
        const maximumLeft = Math.max(8, window.innerWidth - bounds.width - 8);
        const maximumTop = Math.max(8, window.innerHeight - bounds.height - 8);
        chartTooltip.style.left = Math.max(8, Math.min(clientX + 12, maximumLeft)) + 'px';
        chartTooltip.style.top = Math.max(8, Math.min(clientY + 12, maximumTop)) + 'px';
      };
      const showChartTooltip = (point, clientX, clientY) => {
        if (!chartTooltip || !point?.dataset.tooltip) return;
        activeChartPoint = point;
        chartTooltip.textContent = point.dataset.tooltip;
        chartTooltip.hidden = false;
        positionChartTooltip(clientX, clientY);
      };
      const hideChartTooltip = (point) => {
        if (!chartTooltip || (point && activeChartPoint !== point)) return;
        activeChartPoint = null;
        chartTooltip.hidden = true;
      };
      document.querySelectorAll('[data-chart-point]').forEach((point) => {
        point.addEventListener('pointerenter', (event) => showChartTooltip(point, event.clientX, event.clientY));
        point.addEventListener('pointermove', (event) => positionChartTooltip(event.clientX, event.clientY));
        point.addEventListener('pointerleave', () => {
          if (document.activeElement !== point) hideChartTooltip(point);
        });
        point.addEventListener('focus', () => {
          const bounds = point.getBoundingClientRect();
          showChartTooltip(point, bounds.left + bounds.width / 2, bounds.bottom);
        });
        point.addEventListener('blur', () => hideChartTooltip(point));
      });
      document.querySelectorAll('[data-product-image]').forEach((image) => {
        const hideBroken = () => { image.hidden = true; };
        image.addEventListener('error', hideBroken);
        if (image.complete && !image.naturalWidth) hideBroken();
      });
      document.querySelectorAll('[data-table-filter]').forEach((input) => {
        const section = input.closest('.report-section');
        const rows = [...section.querySelectorAll('tbody tr')];
        const count = section.querySelector('[data-filter-count]');
        input.addEventListener('input', () => {
          const keyword = input.value.trim().toLocaleLowerCase('zh-CN');
          let visible = 0;
          rows.forEach((row) => {
            const matched = !keyword || row.textContent.toLocaleLowerCase('zh-CN').includes(keyword);
            row.hidden = !matched;
            if (matched) visible += 1;
          });
          if (count) count.textContent = visible + ' / ' + rows.length;
        });
      });
    })();
  </script>
</body>
</html>`;
  }

  return { MIME_TYPE, REQUIRED_TABLES, buildHtml, escapeHtml, formatValue };
});
