(() => {
  "use strict";

  if (window.top !== window || globalThis.DmpUnifiedMode) return;

  const STORAGE_KEY = "dmpUnifiedAutomation:mode";
  const MODES = Object.freeze({
    growth: Object.freeze({ id: "growth", label: "打爆路径" }),
    "competition-shop": Object.freeze({ id: "competition-shop", label: "竞争态势·店铺" }),
  });

  function normalizeMode(value) {
    return Object.prototype.hasOwnProperty.call(MODES, value) ? value : "";
  }

  function routeMode() {
    const route = String(location.hash || "").toLowerCase();
    if (route.includes("compete-situation")) return "competition-shop";
    if (route.includes("growup-path")) return "growth";
    return "";
  }

  function readStoredMode() {
    try {
      return normalizeMode(localStorage.getItem(STORAGE_KEY));
    } catch {
      return "";
    }
  }

  function storeMode(mode) {
    try {
      localStorage.setItem(STORAGE_KEY, mode);
    } catch {}
  }

  // 已知业务路由优先，避免之前保存的竞争态势模式在打爆路径页挂载可见面板。
  const current = routeMode() || readStoredMode() || "growth";
  storeMode(current);

  async function notifyBackground(mode) {
    try {
      return await chrome.runtime.sendMessage({ type: "DMP_UNIFIED_SET_MODE", mode });
    } catch {
      return null;
    }
  }

  async function switchTo(value) {
    const mode = normalizeMode(value);
    if (!mode || mode === current) return false;
    storeMode(mode);
    await notifyBackground(mode);
    location.reload();
    return true;
  }

  globalThis.DmpUnifiedMode = Object.freeze({
    current,
    modes: MODES,
    storageKey: STORAGE_KEY,
    switchTo,
  });

  void notifyBackground(current);
})();
