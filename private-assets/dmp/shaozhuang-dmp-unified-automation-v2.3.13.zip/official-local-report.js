(() => {
  "use strict";

  const REPORT_TITLE = "达摩盘商品成长竞品对标报告｜少壮AI自动化";

  function isExpectedPage() {
    try {
      const current = new URL(location.href);
      return window.top === window.self
        && current.protocol === "https:"
        && (current.hostname === "shaozhuangai.com" || current.hostname === "www.shaozhuangai.com")
        && current.pathname === "/tools/dmp-report"
        && current.searchParams.get("source") === "dmp-extension";
    } catch {
      return false;
    }
  }

  if (!isExpectedPage()) return;
  document.documentElement.classList.add("dmp-extension-report-pending");

  function launchNonce() {
    const value = new URL(location.href).hash.match(/(?:^#|&)launch=([a-f0-9]{48})(?:&|$)/i)?.[1] || "";
    return value.toLowerCase();
  }

  function showError(error) {
    document.title = "报告暂时无法打开｜少壮AI自动化";
    const main = document.createElement("main");
    main.setAttribute("role", "alert");
    main.className = "dmp-extension-report-error";
    const heading = document.createElement("h1");
    heading.textContent = "报告暂时无法打开｜少壮AI自动化";
    const message = document.createElement("p");
    message.textContent = String(error?.message || error || "报告打开失败").slice(0, 240);
    main.append(heading, message);
    if (!document.body) document.documentElement.append(document.createElement("body"));
    document.body.replaceChildren(main);
    document.documentElement.classList.remove("dmp-extension-report-pending");
    document.documentElement.classList.add("dmp-extension-report-error-page");
  }

  async function mountReportFrame() {
    const nonce = launchNonce();
    if (!nonce) throw new Error("报告打开凭证缺失，请从扩展重新打开");
    history.replaceState(null, "", `${location.pathname}${location.search}`);
    const prepared = await chrome.runtime.sendMessage({
      type: "DMP_DIRECT_PREPARE_OFFICIAL_FRAME",
      launchNonce: nonce
    });
    if (!prepared?.ok || !String(prepared.frameUrl || "").startsWith("chrome-extension://")) {
      throw new Error(prepared?.error || "报告打开校验失败");
    }
    const frame = document.createElement("iframe");
    frame.title = REPORT_TITLE;
    frame.src = prepared.frameUrl;
    frame.referrerPolicy = "no-referrer";
    frame.setAttribute("sandbox", "allow-scripts allow-same-origin allow-modals allow-popups allow-popups-to-escape-sandbox");
    frame.className = "dmp-extension-report-frame";
    let stopped = false;
    let keepMounted = null;
    const timeout = setTimeout(() => {
      if (frame.dataset.loaded) return;
      stopped = true;
      keepMounted?.disconnect();
      showError("报告页加载超时，请从扩展重新打开");
    }, 15_000);
    frame.addEventListener("load", () => {
      clearTimeout(timeout);
      frame.dataset.loaded = "true";
      document.documentElement.classList.remove("dmp-extension-report-pending");
    }, { once: true });
    if (!document.body) document.documentElement.append(document.createElement("body"));
    document.title = REPORT_TITLE;
    document.documentElement.classList.add("dmp-extension-report-mounted");
    document.body.replaceChildren(frame);
    keepMounted = new MutationObserver(() => {
      if (!stopped && !frame.isConnected && document.body) document.body.replaceChildren(frame);
    });
    keepMounted.observe(document.documentElement, { childList: true, subtree: true });
  }

  const start = () => void mountReportFrame().catch(showError);
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start, { once: true });
  else start();
})();
