(function initDmpDirectCore(root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.DmpDirectCore = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function createDmpDirectCore() {
  "use strict";

  const STATE_KEY = "dmpDirectLocalStateV1";
  // Use a dedicated page-world namespace so an older installed build cannot
  // short-circuit this listener before the rolling-7 market endpoints exist.
  const PAGE_API_KEY = "__SZ_DMP_DIRECT_MARKET_V2__";
  const SANJIE_ORIGIN = "https://shaozhuangai.com";
  const SANJIE_REPORT_API_PATH = "/api/dmp-reports";
  const SANJIE_MARKET_REPORT_API_PATH = "/api/dmp-market-reports";
  const SANJIE_REPORT_PATH = "/tools/dmp-report";
  const SANJIE_GROWTH_TABLES = Object.freeze([
    "报告总览", "对标总表", "商品与成功品", "周期汇总", "日GMV与费比", "渠道花费",
    "一级场景", "二级场景", "成长阶段数据", "基础指标对比", "关键词样本"
  ]);
  const SANJIE_GROWTH_COLUMNS = Object.freeze({
    "报告总览": Object.freeze(["项目", "主体", "对手", "范围"]),
    "对标总表": Object.freeze(["页面模块", "对标指标", "主体周期值", "对手周期值", "主体相对对手"]),
    "商品与成功品": Object.freeze(["角色", "商品ID", "商品标题", "类目/成功品描述", "标价/价格带", "上架天数", "生命周期", "30日GMV", "30日日均成交", "30日GMV排名", "排名变化", "排名百分位", "年GMV档位", "成交排名", "客群特征", "标签", "图片/详情"]),
    "周期汇总": Object.freeze(["商品ID", "对象", "周期开始", "周期结束", "天数", "成交笔数", "笔单价", "总GMV", "付费成交额", "广告消耗", "费比", "全域ROAS", "付费金额占比", "广告订单贡献率", "日均GMV", "日均消耗", "GMV峰值日", "GMV波动率"]),
    "日GMV与费比": Object.freeze([
      "日期", "主体日GMV", "对手日GMV",
      "主体内容运营日消耗", "对手内容运营日消耗", "主体人群推广日消耗", "对手人群推广日消耗",
      "主体货品全站推日消耗", "对手货品全站推日消耗", "主体线索推广日消耗", "对手线索推广日消耗",
      "主体关键词推广日消耗", "对手关键词推广日消耗", "主体日总消耗", "对手日总消耗",
      "主体日费比", "对手日费比", "阶段"
    ]),
    "渠道花费": Object.freeze(["渠道", "页面指标", "对手30日消耗", "对手30日占比", "主体30日消耗", "主体30日占比"]),
    "一级场景": Object.freeze(["对象", "层级", "一级场景", "二级场景", "场景编号", "消耗", "消耗占比", "分配后消耗", "展现", "点击", "CTR", "CPC", "直接成交金额", "直接ROI"]),
    "二级场景": Object.freeze(["对象", "层级", "一级场景", "二级场景", "场景编号", "消耗", "消耗占比", "分配后消耗", "展现", "点击", "CTR", "CPC", "直接成交金额", "直接ROI"]),
    "成长阶段数据": Object.freeze([
      "阶段", "开始", "结束", "阶段名称", "阶段描述", "广告打法", "执行细节", "运营动作", "天数",
      "主体起始GMV", "对手起始GMV", "主体结束GMV", "对手结束GMV", "主体GMV变化", "对手GMV变化",
      "主体平均日GMV", "对手平均日GMV", "主体阶段总消耗", "对手阶段总消耗", "主体日均消耗", "对手日均消耗",
      "主体第一渠道", "对手第一渠道", "主体第一渠道占比", "对手第一渠道占比"
    ]),
    "基础指标对比": Object.freeze(["指标", "主体值", "对手值", "主体相对对手"]),
    "关键词样本": Object.freeze(["关键词", "词类型", "主体展现", "对手展现", "主体点击", "对手点击", "主体CTR", "对手CTR", "主体支付转化率", "对手支付转化率"])
  });
  const SANJIE_MAX_CELL_LENGTH = 10_000;
  const MAX_RESPONSE_BYTES = 5 * 1024 * 1024;
  const ALLOWED_REQUESTS = Object.freeze({
    "/api/latestDay": Object.freeze({ method: "GET", parser: "latest-day" }),
    "/api/goods/item/info": Object.freeze({ method: "GET", parser: "item-info" }),
    "/api/goods/grow/define/success/load": Object.freeze({ method: "GET", parser: "selected-success-items" }),
    "/api/goods/grow/define/success/item/list": Object.freeze({ method: "GET", parser: "success-item-search" }),
    "/dataplatform/dataset/report/query": Object.freeze({ method: "POST", parser: "index-card" }),
    "/api/goods/grow/define/line/data": Object.freeze({ method: "GET", parser: "growth-line" }),
    "/api/goods/grow/comparison/scene": Object.freeze({ method: "GET", parser: "growth-scenes" }),
    "/api/goods/grow/comparison/scene/keyword": Object.freeze({ method: "GET", parser: "growth-keywords" }),
    "/api/subdivide/market/item/properties": Object.freeze({ method: "GET", parser: "market-properties" }),
    "/api/subdivide/market/date/range": Object.freeze({ method: "GET", parser: "market-date-range" }),
    "/api/subdivide/market/overview": Object.freeze({ method: "POST", parser: "market-overview" }),
    "/api/subdivide/market/item/price/range": Object.freeze({ method: "GET", parser: "market-price-range" }),
    "/api/subdivide/market/item/growth": Object.freeze({ method: "POST", parser: "market-growth" }),
    "/api/subdivide/market/item/chance": Object.freeze({ method: "GET", parser: "market-chance" }),
    "/api/subdivide/market/item/track/list": Object.freeze({ method: "POST", parser: "market-track-list" }),
    "/api/subdivide/market/item/track/detail": Object.freeze({ method: "POST", parser: "market-track-detail" })
  });
  const MARKET_REQUEST_PATHS = Object.freeze([
    "/api/subdivide/market/item/properties",
    "/api/subdivide/market/date/range",
    "/api/subdivide/market/item/price/range",
    "/api/subdivide/market/item/growth",
    "/api/subdivide/market/item/chance",
    "/api/subdivide/market/item/track/list",
    "/api/subdivide/market/item/track/detail"
  ]);

  function canonicalPath(value) {
    const raw = String(value || "").trim();
    let pathname = raw;
    try {
      const parsed = new URL(raw, "https://dmp.taobao.com");
      if ((/^[a-z][a-z\d+.-]*:/i.test(raw) || raw.startsWith("//"))
        && !["https://dmp.taobao.com", "https://dmp.advgateway.taobao.com"].includes(parsed.origin)) return "";
      pathname = parsed.pathname;
    } catch {}
    return pathname
      .replace(/^\/api_2\//, "/api/")
      .replace(/\.json$/, "")
      .replace(/\/+$/, "");
  }

  function requestPolicy(path) {
    return ALLOWED_REQUESTS[canonicalPath(path)] || null;
  }

  function validateRequest(path, method) {
    const canonical = canonicalPath(path);
    const policy = requestPolicy(canonical);
    const normalizedMethod = String(method || policy?.method || "").toUpperCase();
    if (!policy || policy.method !== normalizedMethod) {
      const error = new Error("请求不在达摩盘只读白名单内");
      error.code = "REQUEST_NOT_ALLOWED";
      throw error;
    }
    return { path: canonical, method: normalizedMethod, parser: policy.parser };
  }

  function validIsoDate(value) {
    const date = String(value || "").trim();
    if (!/^20\d{2}-\d{2}-\d{2}$/.test(date)) return "";
    try { return new Date(`${date}T00:00:00Z`).toISOString().slice(0, 10) === date ? date : ""; } catch { return ""; }
  }

  function validateMarketRequest(path, input = {}, captured = {}) {
    const canonical = canonicalPath(path);
    if (!MARKET_REQUEST_PATHS.includes(canonical)) {
      const error = new Error("请求不在达摩盘细分赛道只读白名单内");
      error.code = "REQUEST_NOT_ALLOWED";
      throw error;
    }
    const source = key => input[key] ?? captured[key];
    const result = {};
    if (canonical !== "/api/subdivide/market/date/range") {
      result.cateId = String(source("cateId") ?? "").trim();
      if (!/^\d{1,20}$/.test(result.cateId)) {
        throw Object.assign(new Error("叶子类目 ID 无效"), { code: "INVALID_MARKET_REQUEST" });
      }
    }
    if (!["/api/subdivide/market/item/properties", "/api/subdivide/market/item/price/range"].includes(canonical)) {
      result.periodType = String(source("periodType") ?? "").trim();
      result.date = validIsoDate(source("date") ?? source("requestDate"));
      if (!/^\d{1,2}$/.test(result.periodType) || !result.date) {
        throw Object.assign(new Error("细分赛道周期参数无效"), { code: "INVALID_MARKET_REQUEST" });
      }
    }
    if (canonical === "/api/subdivide/market/item/growth") {
      result.propertyId = String(source("propertyId") ?? "").trim();
      if (!/^[\w.-]{1,80}$/.test(result.propertyId)) {
        throw Object.assign(new Error("细分赛道属性维度模板无效"), { code: "MARKET_TEMPLATE_REQUIRED" });
      }
    }
    if (canonical === "/api/subdivide/market/item/track/list") {
      result.chanceCode = String(source("chanceCode") ?? "").trim();
      if (!/^[\w.-]{1,80}$/.test(result.chanceCode)) {
        throw Object.assign(new Error("细分赛道机会类型模板无效"), { code: "MARKET_TEMPLATE_REQUIRED" });
      }
    }
    if (canonical === "/api/subdivide/market/item/track/detail") {
      result.trackId = String(source("trackId") ?? "").trim();
      if (!result.trackId || result.trackId.length > 500 || /[\u0000-\u001f\u007f]/.test(result.trackId)) {
        throw Object.assign(new Error("细分赛道明细模板无效"), { code: "MARKET_TEMPLATE_REQUIRED" });
      }
    }
    return result;
  }

  function validateJob(input) {
    const subjectItemId = String(input?.subjectItemId || "").trim();
    const successItemId = String(input?.successItemId || "").trim();
    if (!/^\d{6,20}$/.test(subjectItemId)) throw new Error("请输入 6–20 位主体商品 ID");
    if (!/^\d{6,20}$/.test(successItemId)) throw new Error("请输入 6–20 位成功品/竞品 ID");
    if (subjectItemId === successItemId) throw new Error("主体商品与成功品/竞品不能相同");
    return { subjectItemId, successItemId };
  }

  function normalizeDate(value) {
    const digits = String(value || "").replace(/\D/g, "");
    if (!/^20\d{6}$/.test(digits)) return "";
    return `${digits.slice(0, 4)}-${digits.slice(4, 6)}-${digits.slice(6, 8)}`;
  }

  function periodEndingAtLatestDay(days, latestDay) {
    const endDate = normalizeDate(latestDay);
    const count = Number(days);
    if (!endDate || !Number.isInteger(count) || count < 1 || count > 366) return null;
    const end = Date.parse(`${endDate}T00:00:00Z`);
    if (!Number.isFinite(end)) return null;
    const startDate = new Date(end - (count - 1) * 86400000).toISOString().slice(0, 10);
    return { startDate, endDate, days: count };
  }

  function parseRecordBody(record) {
    if (!record || typeof record.body !== "string" || !record.body.trim()) return null;
    try { return JSON.parse(record.body); } catch { return null; }
  }

  function findCateId(value, depth = 0) {
    if (!value || typeof value !== "object" || depth > 14) return "";
    if (Array.isArray(value)) {
      for (const child of value) {
        const found = findCateId(child, depth + 1);
        if (found) return found;
      }
      return "";
    }
    for (const key of ["cateId", "categoryId", "cateid", "leafCateId", "catId"]) {
      const candidate = value[key];
      if (candidate != null && /^\d{1,20}$/.test(String(candidate))) return String(candidate);
    }
    for (const child of Object.values(value)) {
      const found = findCateId(child, depth + 1);
      if (found) return found;
    }
    return "";
  }

  function successItemsFromRecord(record) {
    const body = parseRecordBody(record);
    const candidates = [body?.data, body?.result, body?.payload, body];
    for (const candidate of candidates) {
      if (Array.isArray(candidate)) return candidate;
      for (const key of ["list", "rows", "items"]) if (Array.isArray(candidate?.[key])) return candidate[key];
    }
    return [];
  }

  function successRecordHasTarget(record, itemId) {
    return successItemsFromRecord(record).some(item => String(item?.itemId ?? item?.id ?? "") === String(itemId));
  }

  function sceneIdsFromRecord(record) {
    const body = parseRecordBody(record);
    const candidates = [body?.data, body?.result, body?.payload, body];
    let rows = [];
    for (const candidate of candidates) {
      if (Array.isArray(candidate)) { rows = candidate; break; }
      const found = ["list", "rows", "items"].map(key => candidate?.[key]).find(Array.isArray);
      if (found) { rows = found; break; }
    }
    return [...new Set(rows.map(row => String(row?.sceneId ?? "")).filter(Boolean))];
  }

  function lineMatchesPeriod(line, period) {
    const startDate = normalizeDate(period?.startDate);
    const endDate = normalizeDate(period?.endDate);
    return Boolean(startDate && endDate
      && normalizeDate(line?.requestStart) === startDate
      && normalizeDate(line?.requestEnd) === endDate
      && normalizeDate(line?.actualStart) === startDate
      && normalizeDate(line?.actualEnd) === endDate);
  }

  function requestBusinessValue(record, aliases) {
    const names = Array.isArray(aliases) ? aliases : [aliases];
    try {
      const url = new URL(String(record?.url || ""), "https://dmp.taobao.com");
      for (const name of names) {
        const value = url.searchParams.get(name);
        if (value != null && value !== "") return value;
      }
    } catch {}
    const payload = (() => {
      try { return JSON.parse(String(record?.requestBody || "")); } catch { return null; }
    })();
    for (const source of [payload, payload?.data, payload?.params]) {
      for (const name of names) {
        const value = source?.[name];
        if (value != null && value !== "") return String(value);
      }
    }
    return "";
  }

  function validateDirectRecordScope(record, spec = {}, classification = {}) {
    const path = canonicalPath(record?.pathname || record?.url || spec.path);
    const parsed = classification?.parsed;
    const subjectItemId = String(spec.subjectItemId || "").trim();
    const successItemId = String(spec.successItemId || "").trim();
    const expectedStart = normalizeDate(spec.period?.startDate);
    const expectedEnd = normalizeDate(spec.period?.endDate);
    const reject = (code, message) => {
      const error = new Error(message);
      error.code = code;
      error.record = record;
      error.rejectRecord = true;
      throw error;
    };
    const requireSubject = value => {
      if (subjectItemId && String(value || "") !== subjectItemId) reject("SUBJECT_SCOPE_MISMATCH", "直连响应主体商品与当前任务不一致");
    };
    const requireCompetitor = values => {
      if (!successItemId) return;
      const list = (Array.isArray(values) ? values : [values]).map(String).filter(Boolean);
      if (list.length !== 1 || list[0] !== successItemId) reject("COMPETITOR_SCOPE_MISMATCH", "直连响应竞对商品与当前任务不一致");
    };
    const requirePeriod = (start, end, side) => {
      if (!expectedStart && !expectedEnd) return;
      if (normalizeDate(start) !== expectedStart || normalizeDate(end) !== expectedEnd) {
        reject(side === "competitor" ? "COMPETITOR_PERIOD_MISMATCH" : "SUBJECT_PERIOD_MISMATCH",
          `直连响应${side === "competitor" ? "竞对" : "主体"}周期与当前任务不一致`);
      }
    };

    if (path === "/api/goods/item/info") {
      requireSubject(parsed?.itemId);
    } else if (path === "/api/goods/grow/define/success/load" || path === "/api/goods/grow/define/success/item/list") {
      requireSubject(requestBusinessValue(record, ["itemId", "entityId"]));
    } else if (path === "/dataplatform/dataset/report/query") {
      const subjectIds = Array.isArray(parsed?.subjectItemIds) ? parsed.subjectItemIds.map(String).filter(Boolean) : [];
      if (subjectItemId && (subjectIds.length !== 1 || subjectIds[0] !== subjectItemId)) {
        reject("SUBJECT_SCOPE_MISMATCH", "核心指标卡主体商品与当前任务不一致");
      }
      requireCompetitor(parsed?.competitorItemIds || []);
      requirePeriod(parsed?.subjectStart, parsed?.subjectEnd, "subject");
      requirePeriod(parsed?.competitorStart, parsed?.competitorEnd, "competitor");
      if (parsed?.start || parsed?.end) requirePeriod(parsed?.start, parsed?.end, "subject");
    } else if (path === "/api/goods/grow/define/line/data") {
      requireSubject(parsed?.itemId);
      requireCompetitor(parsed?.successItemId);
      requirePeriod(parsed?.requestStart, parsed?.requestEnd, "subject");
    } else if (path === "/api/goods/grow/comparison/scene" || path === "/api/goods/grow/comparison/scene/keyword") {
      requireSubject(parsed?.itemId);
      requireCompetitor(parsed?.successItemIds || []);
      requirePeriod(parsed?.start, parsed?.end, "subject");
      if (path === "/api/goods/grow/comparison/scene") {
        const expectedParent = String(spec.sceneLevel1Id || "").trim();
        const actualParent = String(parsed?.parentSceneId || "").trim();
        if (actualParent !== expectedParent) reject("SCENE_PARENT_MISMATCH", "直连响应的二级场景父级与请求不一致");
      }
    }
    return { path, subjectItemId, successItemId, period: expectedStart && expectedEnd ? { startDate: expectedStart, endDate: expectedEnd } : null };
  }

  function buildDirectSupplementPlan(quality = {}, options = {}) {
    const missing = Array.isArray(quality) ? quality.map(String) : [
      ...(quality?.deterministicMissing || []),
      ...(quality?.missing || []),
      ...(quality?.blockingIssues || []),
      ...(quality?.warnings || [])
    ].map(String);
    const text = missing.join("\n");
    const needsPaidEfficiency = /(?:主体|对手|竞品)?(?:付费(?:GMV|成交额|成交金额|金额占比|成交额占比|GMV贡献率)|广告(?:GMV|归因GMV)贡献率|推广(?:消耗|花费|费比|ROI|PPC|ROAS)|广告(?:消耗|花费)|费比|(?:全域)?ROAS|\bROI\b|\bPPC\b|点击成本)/i.test(text);
    const needsPromotionDetail = /推广详情|投放场景|一级场景|二级场景|直接成交|场景效率/i.test(text);
    const requests = [];
    if (needsPaidEfficiency) {
      requests.push({
        path: "/dataplatform/dataset/report/query",
        method: "POST",
        label: "核心指标卡（主体/竞品推广消耗、付费GMV、费比、ROI、PPC、ROAS）",
        allTemplates: true
      });
    }
    if (needsPaidEfficiency || needsPromotionDetail) {
      requests.push({ path: "/api/goods/grow/comparison/scene", method: "GET", label: "一级推广场景" });
      const parents = [...new Set((options.sceneParentIds || []).map(value => String(value || "").trim()).filter(Boolean))];
      for (const sceneLevel1Id of parents) {
        requests.push({
          path: "/api/goods/grow/comparison/scene",
          method: "GET",
          label: `二级推广场景 ${sceneLevel1Id}`,
          sceneLevel1Id
        });
      }
    }
    return { requests, missing, needsPaidEfficiency, needsPromotionDetail };
  }

  function safeRenderHttpsUrl(value) {
    const text = String(value || "").trim();
    if (!text || text.length > 2048) return "";
    try {
      const parsed = new URL(text.startsWith("//") ? `https:${text}` : text);
      if (parsed.protocol !== "https:") return "";
      if ([...parsed.searchParams.keys()].some(key => /(?:token|csrf|cookie|authorization|password|secret|(?:^|[_-])sign(?:ature|data)?$|session|webOpSessionId|uniqueItemCampaign)/i.test(key))) return "";
      parsed.hash = "";
      return parsed.toString();
    } catch {
      return "";
    }
  }

  function sanitizeRenderData(value) {
    if (!value || typeof value !== "object" || value.version !== "1") return null;
    const render = { version: "1" };
    if (Number.isFinite(Date.parse(String(value.generated_at || "")))) {
      render.generated_at = new Date(String(value.generated_at)).toISOString();
    }

    const products = {};
    for (const role of ["subject", "competitor"]) {
      const source = value.products?.[role];
      if (!source || typeof source !== "object") continue;
      const pictureUrl = safeRenderHttpsUrl(source.picture_url);
      const detailUrl = safeRenderHttpsUrl(source.detail_url);
      if (pictureUrl || detailUrl) products[role] = {
        ...(pictureUrl ? { picture_url: pictureUrl } : {}),
        ...(detailUrl ? { detail_url: detailUrl } : {})
      };
    }
    if (Object.keys(products).length) render.products = products;

    if (Array.isArray(value.subject_daily_gmv)) {
      const seen = new Set();
      const rows = [];
      for (const row of value.subject_daily_gmv.slice(0, 62)) {
        const date = normalizeDate(row?.date);
        const gmv = String(row?.gmv ?? "").trim();
        if (!date || seen.has(date) || !Number.isFinite(Number(gmv)) || Number(gmv) < 0 || gmv.length > 64) continue;
        seen.add(date);
        rows.push({ date, gmv });
      }
      rows.sort((left, right) => left.date.localeCompare(right.date));
      if (rows.length) render.subject_daily_gmv = rows;
    }

    if (Array.isArray(value.tables)) {
      const layouts = [];
      const seen = new Set();
      for (const layout of value.tables) {
        const name = String(layout?.name || "");
        if (!SANJIE_GROWTH_TABLES.includes(name) || seen.has(name)) continue;
        seen.add(name);
        const subtitle = String(layout?.subtitle || "").slice(0, 300);
        const widths = Array.isArray(layout?.widths)
          ? layout.widths.map(Number).filter(number => Number.isFinite(number) && number >= 4 && number <= 120).map(number => Math.round(number * 100) / 100)
          : [];
        const expectedColumns = SANJIE_GROWTH_COLUMNS[name]?.length || 0;
        if (subtitle || widths.length === expectedColumns) layouts.push({
          name,
          ...(subtitle ? { subtitle } : {}),
          ...(widths.length === expectedColumns ? { widths } : {})
        });
      }
      if (layouts.length) render.tables = layouts;
    }
    return Object.keys(render).length > 1 ? render : null;
  }

  function normalizeSanjieTable(table, index) {
    if (!table || typeof table !== "object") return null;
    const name = String(table.name || `业务模块${index + 1}`).trim().slice(0, 120) || `业务模块${index + 1}`;
    if (SENSITIVE_KEY.test(name)) throw new Error("Sanjie 报告包含敏感鉴权字段");
    const rawRows = Array.isArray(table.rows) ? table.rows : [];
    const sourceRows = rawRows.slice(0, 5000);
    const sourceColumns = Array.isArray(table.columns) ? table.columns.map(String) : [];
    const rowWidths = sourceRows.map(row => Array.isArray(row?.cells) ? row.cells.length : Array.isArray(row) ? row.length : 0);
    const rawWidth = Math.max(1, sourceColumns.length, ...rowWidths);
    const width = Math.min(100, rawWidth);
    let partial = rawRows.length > sourceRows.length
      || rawWidth > width
      || sourceColumns.length === 0
      || rowWidths.some(rowWidth => rowWidth !== sourceColumns.length);
    const columns = Array.from({ length: width }, (_unused, columnIndex) => {
      const value = String(sourceColumns[columnIndex] || `字段${columnIndex + 1}`).slice(0, 300);
      if (SENSITIVE_KEY.test(value)) throw new Error("Sanjie 报告包含敏感鉴权字段");
      return value;
    });
    const rows = sourceRows.map(row => {
      const sourceCells = Array.isArray(row?.cells) ? row.cells : Array.isArray(row) ? row : [];
      const cells = Array.from({ length: width }, (_unused, cellIndex) => {
        const value = String(sourceCells[cellIndex] ?? "");
        if (value.length > SANJIE_MAX_CELL_LENGTH) partial = true;
        return value.slice(0, SANJIE_MAX_CELL_LENGTH);
      });
      return { cells };
    });
    return { table: { name, columns, rows }, partial };
  }

  function sanitizeSourceShop(value) {
    if (!value || typeof value !== "object" || containsSensitiveData(value)) return null;
    const cleanText = (input, maximum) => String(input ?? "")
      .replace(/[\u0000-\u001f\u007f]/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, maximum);
    const declaredSourceShopId = cleanText(value.sourceShopId, 32).replace(/\s+/g, "");
    const legacyNumericShopId = cleanText(value.shopId, 32).replace(/\s+/g, "");
    const sourceShopId = declaredSourceShopId || (/^\d{5,32}$/.test(legacyNumericShopId) ? legacyNumericShopId : "");
    const shopName = cleanText(value.shopName ?? value.sourceShopName, 80);
    if (declaredSourceShopId && !/^\d{5,32}$/.test(declaredSourceShopId)) return null;
    if (shopName && (shopName.length < 2 || containsSensitiveData(shopName))) return null;
    if (!sourceShopId && !shopName) return null;
    const normalized = {
      ...(sourceShopId ? { sourceShopId } : {}),
      ...(shopName ? { shopName } : {})
    };
    return containsSensitiveData(normalized) ? null : normalized;
  }

  function sanitizeMarketWindows(value) {
    if (!Array.isArray(value)) return [];
    if (containsSensitiveData(value)) throw new Error("Sanjie 大盘窗口包含敏感鉴权字段");
    const rows = [];
    for (const candidate of value.slice(0, 2000)) {
      if (!candidate || typeof candidate !== "object" || Array.isArray(candidate)) continue;
      const windowStart = normalizeDate(candidate.startDate || candidate.windowStart || candidate.effectiveStart);
      const windowEnd = normalizeDate(candidate.endDate || candidate.windowEnd || candidate.requestDate);
      const requestDate = normalizeDate(candidate.requestDate || windowEnd);
      if (!windowStart || !windowEnd || windowStart > windowEnd) continue;
      const source = candidate.market && typeof candidate.market === "object" && !Array.isArray(candidate.market)
        ? candidate.market
        : candidate.metrics && typeof candidate.metrics === "object" && !Array.isArray(candidate.metrics)
          ? candidate.metrics
          : null;
      if (!source) continue;
      const metrics = {};
      for (const [rawKey, rawValue] of Object.entries(source).slice(0, 200)) {
        const key = String(rawKey || "")
          .replace(/[\u0000-\u001f\u007f]/g, " ")
          .replace(/\s+/g, " ")
          .trim()
          .slice(0, 120);
        if (!key || SENSITIVE_KEY.test(key)) continue;
        if (rawValue === null || typeof rawValue === "number" || typeof rawValue === "boolean") {
          metrics[key] = typeof rawValue === "number" && !Number.isFinite(rawValue) ? null : rawValue;
          continue;
        }
        if (typeof rawValue === "string") {
          metrics[key] = rawValue
            .replace(/[\u0000-\u001f\u007f]/g, " ")
            .replace(/\s+/g, " ")
            .trim()
            .slice(0, 500) || null;
        }
      }
      if (!Object.keys(metrics).length) continue;
      rows.push({ windowStart, windowEnd, requestDate, metrics });
    }
    if (containsSensitiveData(rows)) throw new Error("Sanjie 大盘窗口包含敏感鉴权字段");
    return rows;
  }

  function sanjieImportPayload(report, subjectItemId, competitorItemId, sourceVersion, quality = "complete", sourceShop = null) {
    if (!report || report.schema_version !== "3.0" || !/^\d{6,20}$/.test(String(report.item_id || ""))) {
      throw new Error("Sanjie 报告结构无效");
    }
    const subject = String(subjectItemId || report.item_id);
    const competitor = String(competitorItemId || "");
    if (!/^\d{6,20}$/.test(subject) || !/^\d{6,20}$/.test(competitor) || subject !== String(report.item_id) || subject === competitor) {
      throw new Error("Sanjie 报告对象无效");
    }
    const renderData = sanitizeRenderData(report.render_data);
    const sourceTables = Array.isArray(report.tables) ? report.tables : [];
    const normalizedEntries = sourceTables
      .map(normalizeSanjieTable)
      .filter(Boolean);
    const normalizedTables = normalizedEntries.map(entry => entry.table);
    const structurallyPartial = sourceTables.length !== normalizedEntries.length
      || !normalizedTables.length
      || normalizedEntries.some(entry => entry.partial);
    const canonical = {
      schema_version: "3.0",
      title: String(report.title || "").slice(0, 200),
      item_id: String(report.item_id),
      period: String(report.period || "").slice(0, 200),
      ...(renderData ? { render_data: renderData } : {}),
      tables: normalizedTables.length ? normalizedTables : [{
        name: "报告总览",
        columns: ["项目", "主体", "对手", "范围"],
        rows: [{ cells: [String(report.title || "达摩盘业务报告"), subject, competitor, String(report.period || "")] }]
      }]
    };
    if (containsSensitiveData(canonical)) throw new Error("Sanjie 报告包含敏感鉴权字段");
    const normalizedSourceShop = sanitizeSourceShop(sourceShop);
    return {
      report: canonical,
      subjectItemId: subject,
      competitorItemId: competitor,
      quality: quality === "complete" && !structurallyPartial ? "complete" : "partial",
      sourceVersion: String(sourceVersion || "").slice(0, 32),
      ...(normalizedSourceShop ? { sourceShop: normalizedSourceShop } : {})
    };
  }

  function sanjieMarketImportPayload(report, sourceVersion, quality = "complete", sourceShop = null, marketWindows = null) {
    if (!report || report.schema_version !== "3.0" || report.report_type !== "market") {
      throw new Error("Sanjie 大盘报告结构无效");
    }
    if (containsSensitiveData(report)) throw new Error("Sanjie 大盘报告包含敏感鉴权字段");
    const scope = report.market_scope && typeof report.market_scope === "object" ? report.market_scope : {};
    const categoryId = String(scope.category_id || "").trim();
    const categoryName = String(scope.category_name || "").replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim().slice(0, 120);
    const categoryPath = Array.isArray(scope.category_path)
      ? scope.category_path.map(value => String(value || "").replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim().slice(0, 120)).filter(Boolean).slice(0, 8)
      : [];
    if (!/^\d{1,20}$/.test(categoryId)
      || String(report.item_id || categoryId) !== categoryId
      || !categoryName
      || !/[\u3400-\u9fff]/u.test(categoryName)
      || !categoryPath.length) {
      throw new Error("Sanjie 大盘报告类目信息无效");
    }
    const sourceTables = Array.isArray(report.tables) ? report.tables : [];
    const normalizedEntries = sourceTables.map(normalizeSanjieTable).filter(Boolean);
    const tables = normalizedEntries.map(entry => entry.table);
    const structurallyPartial = sourceTables.length !== normalizedEntries.length
      || !tables.length
      || normalizedEntries.some(entry => entry.partial);
    if (structurallyPartial) {
      throw new Error("Sanjie 大盘报告表结构不完整或超过归档上限，已停止上传以避免静默丢数");
    }
    const canonical = {
      schema_version: "3.0",
      report_type: "market",
      title: String(report.title || "达摩盘类目大盘趋势报告｜少壮AI自动化").slice(0, 200),
      item_id: categoryId,
      period: String(report.period || "").slice(0, 200),
      market_scope: {
        version: "1",
        category_id: categoryId,
        category_name: categoryName,
        category_path: categoryPath,
        category_display_name: categoryPath.join(" / ")
      },
      tables
    };
    if (containsSensitiveData(canonical)) throw new Error("Sanjie 大盘报告包含敏感鉴权字段");
    const normalizedSourceShop = sanitizeSourceShop(sourceShop);
    const normalizedMarketWindows = sanitizeMarketWindows(marketWindows);
    return {
      reportType: "market",
      report: canonical,
      subjectItemId: categoryId,
      competitorItemId: "",
      quality: quality === "complete" && !structurallyPartial ? "complete" : "partial",
      sourceVersion: String(sourceVersion || "").slice(0, 32),
      ...(normalizedSourceShop ? { sourceShop: normalizedSourceShop } : {}),
      ...(normalizedMarketWindows.length ? { marketWindows: normalizedMarketWindows } : {})
    };
  }

  function sanjieReportUrl(reportId) {
    const id = String(reportId || "").trim();
    if (!/^[a-z\d_-]{6,128}$/i.test(id)) return "";
    const url = new URL(SANJIE_REPORT_PATH, SANJIE_ORIGIN);
    url.searchParams.set("reportId", id);
    url.searchParams.set("view", "report");
    return url.toString();
  }

  function safeErrorText(value, fallback = "取数未完成") {
    const text = String(value?.message || value || "").replace(/https?:\/\/\S+/g, "相关接口").trim();
    return text ? text.slice(0, 240) : fallback;
  }

  const SENSITIVE_KEY = /(?:token|csrf|cookie|authorization|password|secret|(?:^|[_-])sign(?:ature|data)?$|session|webOpSessionId|uniqueItemCampaign)/i;

  function containsSensitiveData(value, depth = 0) {
    if (depth > 30) return true;
    if (Array.isArray(value)) return value.some(child => containsSensitiveData(child, depth + 1));
    if (value && typeof value === "object") {
      return Object.entries(value).some(([key, child]) => SENSITIVE_KEY.test(key) || containsSensitiveData(child, depth + 1));
    }
    if (typeof value !== "string") return false;
    const text = value.trim();
    if (/(?:_tb_token_|(?:cookie|set-cookie|authorization)\s*:|(?:token|csrf|signature|signData|webOpSessionId|uniqueItemCampaign)\s*[=:])/i.test(text)) return true;
    if (/^https?:\/\//i.test(text)) {
      try {
        const url = new URL(text);
        if ([...url.searchParams.keys()].some(key => SENSITIVE_KEY.test(key))) return true;
      } catch {}
    }
    if ((text.startsWith("{") && text.endsWith("}")) || (text.startsWith("[") && text.endsWith("]"))) {
      try { return containsSensitiveData(JSON.parse(text), depth + 1); } catch {}
    }
    return false;
  }

  function assertSafeRecord(record) {
    const policy = validateRequest(record?.pathname || record?.url, record?.method);
    let parsedUrl;
    try { parsedUrl = new URL(String(record?.url || "")); } catch { throw new Error("本地记录来源无效"); }
    if (!["https://dmp.taobao.com", "https://dmp.advgateway.taobao.com"].includes(parsedUrl.origin)) throw new Error("本地记录来源无效");
    if (record?.origin && String(record.origin) !== parsedUrl.origin) throw new Error("本地记录来源不一致");
    if (canonicalPath(parsedUrl.href) !== canonicalPath(record?.pathname || "")) throw new Error("本地记录路径不一致");
    if (record?.kind !== "Network") throw new Error("本地记录类型无效");
    if (!record?.bodyAvailable || record?.truncated || typeof record?.body !== "string") throw new Error("本地记录响应体不完整");
    if (record.body.length > MAX_RESPONSE_BYTES) throw new Error("本地记录超过大小限制");
    if (containsSensitiveData(String(record.url || ""))
      || containsSensitiveData(String(record.requestBody || ""))
      || containsSensitiveData(String(record.body || ""))) {
      throw new Error("敏感鉴权字段不得离开页面上下文");
    }
    return policy;
  }

  return {
    STATE_KEY, PAGE_API_KEY, SANJIE_ORIGIN, SANJIE_REPORT_API_PATH, SANJIE_MARKET_REPORT_API_PATH,
    SANJIE_REPORT_PATH, SANJIE_GROWTH_TABLES, SANJIE_GROWTH_COLUMNS,
    SANJIE_MAX_CELL_LENGTH, MAX_RESPONSE_BYTES, ALLOWED_REQUESTS,
    canonicalPath, requestPolicy, validateRequest, validateMarketRequest, validateJob, normalizeDate, periodEndingAtLatestDay,
    parseRecordBody, findCateId, successItemsFromRecord, successRecordHasTarget, sceneIdsFromRecord, lineMatchesPeriod,
    requestBusinessValue, validateDirectRecordScope,
    buildDirectSupplementPlan,
    sanjieImportPayload, sanjieMarketImportPayload, sanjieReportUrl, sanitizeRenderData, sanitizeSourceShop, sanitizeMarketWindows,
    safeErrorText, containsSensitiveData, assertSafeRecord
  };
});
