(function initDmpRolling7HtmlWriter(root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.DmpRolling7HtmlWriter = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function createDmpRolling7HtmlWriter() {
  "use strict";

  const SCHEMA_VERSION = "dmp-market-rolling7/1.0";
  const BUSINESS_TIME_ZONE = "Asia/Shanghai";
  const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;
  const FIELD_DEFS = Object.freeze([
    { key: "alipayInshopAmt", popKey: "alipayInshopAmtPop", label: "成交金额", kind: "money", module: "market", monthlyAggregation: "flow" },
    { key: "alipayUv", popKey: "alipayUvPop", label: "成交人数（支付买家）", kind: "count", module: "market", monthlyAggregation: "flow" },
    { key: "newCustCnt", popKey: "newCustCntPop", label: "新客成交人数", kind: "count", module: "crowd", monthlyAggregation: "flow" },
    { key: "nup", popKey: "nupPop", label: "新客客单价", kind: "money", module: "crowd" },
    { key: "qup", popKey: "qupPop", label: "老客客单价", kind: "money", module: "crowd" },
    { key: "apf", popKey: "apfPop", label: "人均购买频次", kind: "frequency", module: "crowd" },
    { key: "saleCnt", popKey: "saleCntPop", label: "动销商品数", kind: "count", module: "market" },
    { key: "newCnt", popKey: "newCntPop", label: "新品数", kind: "count", module: "product" },
    { key: "hotCnt", popKey: "hotCntPop", label: "热销商品数", kind: "count", module: "product" },
    { key: "clk", popKey: "clkPop", label: "点击量", kind: "count", module: "efficiency", monthlyAggregation: "flow" },
    { key: "cvr", popKey: "cvrPop", label: "支付转化率", kind: "percent", module: "efficiency" },
    { key: "roi", popKey: "roiPop", label: "ROI", kind: "ratio", module: "efficiency" }
  ]);
  const FIELD_BY_KEY = Object.freeze(Object.fromEntries(FIELD_DEFS.map(field => [field.key, field])));
  const MODULES = Object.freeze([
    { id: "market", title: "市场规模", keys: ["alipayInshopAmt", "alipayUv", "saleCnt"] },
    { id: "crowd", title: "消费人群", keys: ["newCustCnt", "nup", "qup", "apf"] },
    { id: "product", title: "商品供给", keys: ["newCnt", "hotCnt"] },
    { id: "efficiency", title: "流量转化", keys: ["clk", "cvr", "roi"] }
  ]);
  const OVERVIEW_KEYS = Object.freeze(["alipayInshopAmt", "alipayUv", "clk", "saleCnt", "cvr", "roi"]);
  const CORE_KPI_KEYS = Object.freeze(["alipayInshopAmt", "alipayUv", "clk", "cvr"]);
  const TREND_KEYS = Object.freeze(["alipayInshopAmt", "alipayUv", "clk", "saleCnt", "cvr", "roi"]);
  const CATEGORY_DISPLAY_BY_ID = Object.freeze({
    "50015382": "大家电-厨房大电-油烟机"
  });
  const MARKET_COLUMNS = Object.freeze(FIELD_DEFS.flatMap(field => [
    [field.key, field.label],
    [field.popKey, `${field.label}环比`]
  ]));
  const SENSITIVE_KEY_PATTERN = /(?:token|csrf|cookie|authorization|password|passwd|secret|(?:^|[_-])auth(?:$|[_-])|(?:^|[_-])sign(?:ature|data)?$|session|webOpSessionId|uniqueItemCampaign)/i;
  const SENSITIVE_TEXT_PATTERN = /(?:_tb_token_|(?:cookie|set-cookie|authorization)\s*:|(?:token|csrf|signature|signData|webOpSessionId|uniqueItemCampaign)\s*[=:])/i;

  function escapeHtml(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function hasValue(value) {
    return value !== null && value !== undefined && value !== "";
  }

  function displayValue(value) {
    if (!hasValue(value)) return "—";
    if (typeof value === "object") return JSON.stringify(value);
    return String(value);
  }

  function shanghaiDateKey(value) {
    const text = String(value == null ? "" : value).trim();
    if (ISO_DATE.test(text)) {
      const parsed = new Date(`${text}T00:00:00Z`);
      return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === text ? text : "";
    }
    const normalized = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?$/.test(text)
      ? `${text}+08:00`
      : text;
    const parsed = new Date(normalized);
    if (!Number.isFinite(parsed.getTime())) return "";
    try {
      const parts = new Intl.DateTimeFormat("en-CA", {
        timeZone: BUSINESS_TIME_ZONE,
        year: "numeric",
        month: "2-digit",
        day: "2-digit"
      }).formatToParts(parsed);
      const values = Object.fromEntries(parts.map(part => [part.type, part.value]));
      return values.year && values.month && values.day ? `${values.year}-${values.month}-${values.day}` : "";
    } catch {
      return new Date(parsed.getTime() + 8 * 60 * 60 * 1000).toISOString().slice(0, 10);
    }
  }

  function assertSensitiveFree(value) {
    const seen = typeof WeakSet === "function" ? new WeakSet() : null;
    function visit(current, path) {
      if (current == null) return;
      if (typeof current === "string") {
        if (SENSITIVE_TEXT_PATTERN.test(current)) throw new Error(`报告数据包含禁止字段: ${path}`);
        return;
      }
      if (typeof current !== "object") return;
      if (seen) {
        if (seen.has(current)) return;
        seen.add(current);
      }
      for (const key of Object.keys(current)) {
        const childPath = `${path}.${key}`;
        if (SENSITIVE_KEY_PATTERN.test(key)) throw new Error(`报告数据包含禁止字段: ${childPath}`);
        visit(current[key], childPath);
      }
    }
    visit(value, "$");
    return true;
  }

  function validateDataset(dataset) {
    if (!dataset || dataset.schemaVersion !== SCHEMA_VERSION || dataset.kind !== "dataset") {
      throw new Error("报告数据格式无效");
    }
    assertSensitiveFree(dataset);
    const quality = dataset.completeness || {};
    const countFields = ["expectedTaskCount", "completedTaskCount", "missingTaskCount", "conflictTaskCount", "boundaryMismatchCount", "unexpectedWindowCount"];
    if (countFields.some(field => !Number.isInteger(quality[field]) || quality[field] < 0)) {
      throw new Error("报告完整性信息缺失或无效");
    }
    const expected = quality.expectedTaskCount;
    const baselines = Array.isArray(dataset.baselines) ? dataset.baselines : [];
    if (quality.status !== "ready" || expected <= 0 || quality.completedTaskCount !== expected
      || quality.missingTaskCount !== 0 || quality.conflictTaskCount !== 0
      || quality.boundaryMismatchCount !== 0 || quality.unexpectedWindowCount !== 0
      || !Array.isArray(dataset.windows) || dataset.windows.length + baselines.length !== expected) {
      throw new Error("报告数据尚未完整，暂不能生成报告");
    }
    const dates = new Set();
    for (const window of dataset.windows) {
      if (window?.boundaryMatches !== true || !window?.market || typeof window.market !== "object") {
        throw new Error("报告日期范围或市场数据结构无效");
      }
      const requestDate = shanghaiDateKey(window.requestDate);
      if (!requestDate) throw new Error("报告业务日期无效");
      if (dates.has(requestDate)) throw new Error(`报告日期重复: ${requestDate}`);
      dates.add(requestDate);
    }
    const baselineIds = new Set();
    for (const baseline of baselines) {
      if (baseline?.boundaryMatches !== true || !baseline?.market || typeof baseline.market !== "object") {
        throw new Error("历史周期范围或市场数据结构无效");
      }
      const baselineId = String(baseline.taskId || `${baseline.startDate || ""}:${baseline.endDate || ""}`);
      if (baselineIds.has(baselineId)) throw new Error("历史周期数据重复");
      baselineIds.add(baselineId);
    }
    return true;
  }

  function resolveCategoryIdentity(dataset, options = {}) {
    const cateId = String(dataset?.cateId || "").trim();
    const mappedDisplayName = CATEGORY_DISPLAY_BY_ID[cateId] || "";
    const mappedPath = mappedDisplayName ? mappedDisplayName.split("-") : [];
    const categoryPath = Array.isArray(dataset?.categoryPath) && dataset.categoryPath.length
      ? dataset.categoryPath.map(value => String(value || "").trim()).filter(Boolean)
      : mappedPath;
    const categoryName = String(dataset?.categoryName || categoryPath.at(-1) || "").trim();
    const categoryDisplayName = String(mappedDisplayName || dataset?.categoryDisplayName
      || (categoryPath.length ? categoryPath.join(" / ") : "类目")).trim();
    if (options.requireChinesePath
      && (!categoryName || !/[\u3400-\u9fff]/u.test(categoryName) || !categoryPath.length)) {
      throw new Error("缺少真实中文类目名称，本地报告已保留，暂不归档");
    }
    return { cateId, categoryPath, categoryName, categoryDisplayName };
  }

  function unitMultiplier(unit) {
    if (unit === "亿") return 100000000;
    if (unit === "万") return 10000;
    if (unit === "千") return 1000;
    return 1;
  }

  function tokenParts(value) {
    const match = String(value == null ? "" : value).trim().match(/^([+-]?(?:\d+(?:\.\d+)?|\.\d+))\s*(亿|万|千)?\s*(%)?$/);
    if (!match) return null;
    return { number: Number(match[1]), unit: match[2] || "", percent: Boolean(match[3]) };
  }

  function scaledToken(parts, inheritedUnit, inheritedPercent) {
    if (!parts || !Number.isFinite(parts.number)) return null;
    const value = parts.number * unitMultiplier(parts.unit || inheritedUnit || "");
    return parts.percent || inheritedPercent ? value / 100 : value;
  }

  function parseReferenceValue(raw, kind = "number") {
    if (!hasValue(raw)) return null;
    if (typeof raw === "number") {
      if (!Number.isFinite(raw)) return null;
      return { raw, reference: raw, lower: raw, upper: raw, bounded: true, exact: true, open: null, kind };
    }
    const text = String(raw).trim().replace(/[,，]/g, "").replace(/[～–—]/g, "~").replace(/％/g, "%").replace(/\s+/g, " ");
    if (!text) return null;
    const above = text.match(/^(.+?)\s*(?:以上|及以上)$/) || text.match(/^(?:>|大于|高于|超过)\s*(.+)$/) || text.match(/^(.+?)\s*\+$/);
    const below = text.match(/^(.+?)\s*(?:以下|及以下|以内)$/) || text.match(/^(?:<|小于|低于|不超过)\s*(.+)$/);
    if (above) {
      const lower = scaledToken(tokenParts(above[1]), "", false);
      return Number.isFinite(lower) ? { raw, reference: null, lower, upper: null, bounded: false, exact: false, open: "above", kind } : null;
    }
    if (below) {
      const upper = scaledToken(tokenParts(below[1]), "", false);
      return Number.isFinite(upper) ? { raw, reference: null, lower: null, upper, bounded: false, exact: false, open: "below", kind } : null;
    }
    const range = text.match(/^(.+?)\s*(?:~|至)\s*(.+)$/);
    if (range) {
      const leftParts = tokenParts(range[1]);
      const rightParts = tokenParts(range[2]);
      if (!leftParts || !rightParts) return null;
      const inheritedUnit = rightParts.unit || leftParts.unit || "";
      const inheritedPercent = leftParts.percent || rightParts.percent;
      let lower = scaledToken(leftParts, inheritedUnit, inheritedPercent);
      let upper = scaledToken(rightParts, inheritedUnit, inheritedPercent);
      if (!Number.isFinite(lower) || !Number.isFinite(upper)) return null;
      if (lower > upper) [lower, upper] = [upper, lower];
      return { raw, reference: (lower + upper) / 2, lower, upper, bounded: true, exact: lower === upper, open: null, kind };
    }
    const parts = tokenParts(text);
    if (!parts) return null;
    const exact = scaledToken(parts, "", parts.percent);
    return Number.isFinite(exact) ? { raw, reference: exact, lower: exact, upper: exact, bounded: true, exact: true, open: null, kind } : null;
  }

  function fitValue(raw, kind) {
    return parseReferenceValue(raw, kind)?.reference ?? null;
  }

  function parseChange(raw) {
    if (!hasValue(raw)) return null;
    if (typeof raw === "number") return Number.isFinite(raw) ? raw : null;
    const match = String(raw).trim().replace(/％/g, "%").match(/^([+-]?(?:\d+(?:\.\d+)?|\.\d+))\s*(%)?$/);
    if (!match) return null;
    const value = Number(match[1]);
    return Number.isFinite(value) ? (match[2] ? value / 100 : value) : null;
  }

  function median(values) {
    const sorted = (values || []).filter(value => typeof value === "number" && Number.isFinite(value)).sort((left, right) => left - right);
    if (!sorted.length) return null;
    const middle = Math.floor(sorted.length / 2);
    return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
  }

  function numericText(value, minimumFractionDigits, maximumFractionDigits) {
    if (typeof value !== "number" || !Number.isFinite(value)) return "—";
    return value.toLocaleString("zh-CN", { minimumFractionDigits, maximumFractionDigits });
  }

  function scaledBusinessText(value, divisor, suffix, fractionDigits = null) {
    const minimumFractionDigits = Number.isInteger(fractionDigits) ? fractionDigits : 0;
    const maximumFractionDigits = Number.isInteger(fractionDigits) ? fractionDigits : 3;
    return `${numericText(value / divisor, minimumFractionDigits, maximumFractionDigits)}${suffix}`;
  }

  function fittedDisplayFractionDigits(step, divisor) {
    if (!Number.isFinite(step) || step <= 0 || !Number.isFinite(divisor) || divisor <= 0) return null;
    const scaledStep = step / divisor;
    if (scaledStep >= 1) return 0;
    if (scaledStep >= 0.1) return 1;
    if (scaledStep >= 0.01) return 2;
    return 3;
  }

  function formatMetricValue(fieldOrKind, value, options = {}) {
    if (typeof value !== "number" || !Number.isFinite(value)) return "—";
    const kind = typeof fieldOrKind === "string" ? fieldOrKind : fieldOrKind?.kind || "number";
    if (kind === "money") {
      const absolute = Math.abs(value);
      if (absolute >= 10000) return scaledBusinessText(value, 10000, "万元",
        fittedDisplayFractionDigits(options.displayStep, 10000));
      if (absolute >= 1000) return scaledBusinessText(value, 1000, "千元",
        fittedDisplayFractionDigits(options.displayStep, 1000));
      return numericText(value, 0, 2);
    }
    if (kind === "count") {
      const rounded = Math.round(value);
      const absolute = Math.abs(value);
      if (absolute >= 10000) return scaledBusinessText(rounded, 10000, "万",
        fittedDisplayFractionDigits(options.displayStep, 10000));
      if (absolute >= 1000) return scaledBusinessText(rounded, 1000, "千",
        fittedDisplayFractionDigits(options.displayStep, 1000));
      return numericText(rounded, 0, 0);
    }
    if (kind === "percent") return `${numericText(value * 100, 2, 2)}%`;
    if (kind === "frequency") return `${numericText(value, 2, 2)}次`;
    if (kind === "ratio") return numericText(value, 2, 2);
    return numericText(value, 0, 2);
  }

  function formatParsed(field, parsed) {
    if (!parsed) return "—";
    if (Number.isFinite(parsed.displayReference)) {
      return formatMetricValue(field, parsed.displayReference, { displayStep: parsed.displayStep });
    }
    if (Number.isFinite(parsed.reference)) return formatMetricValue(field, parsed.reference);
    if (parsed.open === "above" && Number.isFinite(parsed.lower)) return `≥${formatMetricValue(field, parsed.lower)}`;
    if (parsed.open === "below" && Number.isFinite(parsed.upper)) return `≤${formatMetricValue(field, parsed.upper)}`;
    return "—";
  }

  function formatChange(value) {
    if (typeof value !== "number" || !Number.isFinite(value)) return "—";
    const normalized = Math.abs(value) < 0.00005 ? 0 : value;
    return `${normalized > 0 ? "+" : ""}${numericText(normalized * 100, 2, 2)}%`;
  }

  function changeClass(value) {
    const normalized = Number.isFinite(value) && Math.abs(value) >= 0.00005 ? value : 0;
    if (!Number.isFinite(value) || normalized === 0) return "is-flat";
    return normalized > 0 ? "is-up" : "is-down";
  }

  function changeGlyph(value) {
    const normalized = Number.isFinite(value) && Math.abs(value) >= 0.00005 ? value : 0;
    if (!Number.isFinite(value) || normalized === 0) return "→";
    return normalized > 0 ? "↑" : "↓";
  }

  function changeValueHtml(value) {
    if (!Number.isFinite(value)) return '<span class="change-value is-missing">—</span>';
    return `<span class="change-value ${changeClass(value)}"><i aria-hidden="true">${changeGlyph(value)}</i>${escapeHtml(formatChange(value))}</span>`;
  }

  function ratioMeterHtml(label, value) {
    if (!Number.isFinite(value) || value < 0 || value > 1) return "";
    const percent = value * 100;
    return `<span class="ratio-meter"><span class="ratio-meter-track" role="progressbar" aria-label="${escapeHtml(label)} ${escapeHtml(formatMetricValue("percent", value))}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${percent.toFixed(1)}"><i class="ratio-meter-fill" style="width:${percent.toFixed(1)}%"></i></span></span>`;
  }

  function addDays(value, days) {
    const date = new Date(`${value}T00:00:00Z`);
    if (!Number.isFinite(date.getTime())) return "";
    date.setUTCDate(date.getUTCDate() + Number(days || 0));
    return date.toISOString().slice(0, 10);
  }

  function weekStart(value) {
    const date = new Date(`${value}T00:00:00Z`);
    const offset = (date.getUTCDay() + 6) % 7;
    return addDays(value, -offset);
  }

  function monthEnd(value) {
    const [year, month] = String(value).slice(0, 7).split("-").map(Number);
    return new Date(Date.UTC(year, month, 0)).toISOString().slice(0, 10);
  }

  function shiftYear(value, offset = -1) {
    const parts = String(value || "").split("-").map(Number);
    if (parts.length !== 3 || parts.some(part => !Number.isInteger(part))) return "";
    const [year, month, day] = parts;
    const targetYear = year + offset;
    const targetMonthEnd = new Date(Date.UTC(targetYear, month, 0)).getUTCDate();
    return new Date(Date.UTC(targetYear, month - 1, Math.min(day, targetMonthEnd))).toISOString().slice(0, 10);
  }

  function dateSpan(startDate, endDate) {
    const start = new Date(`${startDate}T00:00:00Z`).getTime();
    const end = new Date(`${endDate}T00:00:00Z`).getTime();
    return Number.isFinite(start) && Number.isFinite(end) ? Math.floor((end - start) / 86400000) + 1 : 0;
  }

  function parsedReference(value, kind) {
    return Number.isFinite(value)
      ? { raw: null, reference: value, lower: value, upper: value, bounded: true, exact: false, open: null, kind }
      : null;
  }

  function metricStatsFor(rows) {
    const output = {};
    for (const field of FIELD_DEFS) {
      const points = rows.map(row => ({ row, value: row.metrics[field.key].current?.reference })).filter(point => Number.isFinite(point.value));
      const peak = points.length ? points.reduce((best, point) => point.value > best.value ? point : best) : null;
      const trough = points.length ? points.reduce((best, point) => point.value < best.value ? point : best) : null;
      const first = points[0] || null;
      const last = points.at(-1) || null;
      output[field.key] = {
        median: median(points.map(point => point.value)), peak, trough, first, last,
        firstToLast: first && last && first.value !== 0 ? last.value / first.value - 1 : null,
        validWindowCount: points.length
      };
    }
    return output;
  }

  function stableHash(value) {
    let hash = 2166136261;
    for (const character of String(value || "")) {
      hash ^= character.codePointAt(0);
      hash = Math.imul(hash, 16777619);
    }
    return hash >>> 0;
  }

  function fittedTailPlan(value) {
    const absolute = Math.abs(value);
    if (absolute >= 100000000) return { bucket: 100000000, step: 1000000 };
    if (absolute >= 10000000) return { bucket: 10000000, step: 100000 };
    if (absolute >= 1000000) return { bucket: 100000, step: 1000 };
    if (absolute >= 100000) return { bucket: 10000, step: 100 };
    if (absolute >= 10000) return { bucket: 1000, step: 10 };
    if (absolute >= 1000) return { bucket: 100, step: 1 };
    return null;
  }

  function stabilizeFittedTail(value, seed, lower, upper) {
    if (!Number.isFinite(value) || value === 0) return value;
    const plan = fittedTailPlan(value);
    if (!plan) return value;
    const sign = value < 0 ? -1 : 1;
    const absolute = Math.abs(value);
    const prefix = Math.floor(absolute / plan.bucket) * plan.bucket;
    const candidates = Array.from({ length: 100 }, (_, index) => sign * (prefix + index * plan.step));
    const hasBounds = Number.isFinite(lower) && Number.isFinite(upper);
    if (!hasBounds) return candidates[stableHash(seed) % candidates.length];
    const min = Math.min(lower, upper);
    const max = Math.max(lower, upper);
    const bounded = candidates.filter(candidate => candidate >= min && candidate <= max);
    if (bounded.length) return bounded[stableHash(seed) % bounded.length];
    return Math.min(max, Math.max(min, value));
  }

  function medianParsed(rows, field) {
    return parsedReference(median(rows.map(row => row.metrics[field.key].current?.reference)), field.kind);
  }

  function monthlyFlowParsed(rows, field, startDate, endDate, seed) {
    const totalDays = dateSpan(startDate, endDate);
    if (!totalDays) return null;
    const completeRoundCount = Math.floor(totalDays / 7);
    const remainderDays = totalDays % 7;
    const rowsByEnd = new Map(rows.map(row => [String(row.window.endDate || row.window.requestDate), row]));
    const fullRows = [];
    for (let round = 0; round < completeRoundCount; round += 1) {
      const roundStart = addDays(startDate, round * 7);
      const roundEnd = addDays(roundStart, 6);
      const row = rowsByEnd.get(roundEnd);
      if (!row || row.window.startDate !== roundStart || row.window.endDate !== roundEnd) return null;
      fullRows.push(row);
    }
    const tailStart = remainderDays ? addDays(endDate, 1 - remainderDays) : "";
    const tailRows = remainderDays
      ? rows.filter(row => row.window.requestDate >= tailStart && row.window.requestDate <= endDate
        && row.window.startDate >= startDate && row.window.endDate <= endDate)
      : [];
    if (remainderDays && tailRows.length !== remainderDays) return null;
    const component = key => {
      const fullValues = fullRows.map(row => row.metrics[field.key].current?.[key]);
      if (fullValues.some(value => !Number.isFinite(value))) return null;
      let value = fullValues.reduce((sum, current) => sum + current, 0);
      if (remainderDays) {
        const tailValues = tailRows.map(row => row.metrics[field.key].current?.[key]);
        if (tailValues.some(tailValue => !Number.isFinite(tailValue))) return null;
        const tailValue = median(tailValues);
        if (!Number.isFinite(tailValue)) return null;
        value += tailValue / 7 * remainderDays;
      }
      return value;
    };
    const reference = component("reference");
    if (!Number.isFinite(reference)) return null;
    const lower = component("lower");
    const upper = component("upper");
    const displayPlan = fittedTailPlan(reference);
    const fitFingerprint = [reference, lower, upper]
      .map(value => Number.isFinite(value) ? Number(value).toPrecision(15) : "")
      .join("|");
    const displayReference = stabilizeFittedTail(reference, `${seed}|${fitFingerprint}`);
    return {
      raw: null,
      reference,
      displayReference,
      displayStep: displayPlan?.step || null,
      lower: Number.isFinite(lower) ? lower : null,
      upper: Number.isFinite(upper) ? upper : null,
      bounded: Number.isFinite(lower) && Number.isFinite(upper),
      exact: false,
      open: null,
      kind: field.kind,
      estimated: true,
      aggregation: "monthly-round-fit"
    };
  }

  function buildBusinessModel(dataset) {
    validateDataset(dataset);
    const range = dataset.analysisRange || {};
    const rows = [...dataset.windows].sort((left, right) => shanghaiDateKey(left.requestDate).localeCompare(shanghaiDateKey(right.requestDate))).map(sourceWindow => {
      const requestDate = shanghaiDateKey(sourceWindow.requestDate);
      const window = requestDate === sourceWindow.requestDate ? sourceWindow : { ...sourceWindow, requestDate };
      const metrics = Object.fromEntries(FIELD_DEFS.map(field => [field.key, {
        current: parseReferenceValue(window.market[field.key], field.kind),
        change: parseChange(window.market[field.popKey]),
        compare: null,
        compareSource: null
      }]));
      return {
        window,
        metrics,
        inAnalysis: String(window.requestDate) >= String(range.startDate || "") && String(window.requestDate) <= String(range.endDate || "9999-12-31")
      };
    });
    const rowsByDate = new Map(rows.map(row => [String(row.window.requestDate), row]));
    for (const row of rows) {
      const compareRow = rowsByDate.get(String(row.window.compareEndDate));
      for (const field of FIELD_DEFS) {
        const metric = row.metrics[field.key];
        const direct = compareRow?.metrics?.[field.key]?.current || null;
        if (direct) {
          metric.compare = direct;
          metric.compareSource = "window";
        } else if (Number.isFinite(metric.current?.reference) && Number.isFinite(metric.change) && metric.change > -1) {
          const reference = metric.current.reference / (1 + metric.change);
          metric.compare = parsedReference(reference, field.kind);
          metric.compareSource = "change";
        }
        metric.change = resolvedMetricChange(metric);
      }
    }
    const analysisRows = rows.filter(row => row.inAnalysis);
    if (!analysisRows.length) throw new Error("所选业务周期没有可用数据");
    return {
      dataset, rows, rowsByDate, analysisRows, latestRow: analysisRows.at(-1),
      metricStats: metricStatsFor(analysisRows), analysisWindowCount: analysisRows.length, dataWindowCount: rows.length
    };
  }

  function rowHasBusinessData(row) {
    return FIELD_DEFS.some(field => row?.metrics?.[field.key]?.current != null);
  }

  function actualCollectedRows(model) {
    const tasks = Array.isArray(model?.dataset?.tasks) ? model.dataset.tasks : [];
    const taskById = new Map(tasks.map(task => [String(task?.taskId || ""), task]));
    return model.rows.filter(row => {
      if (row?.window?.boundaryMatches !== true || !rowHasBusinessData(row)) return false;
      if (!taskById.size) return true;
      const task = taskById.get(String(row.window.taskId || ""));
      return task?.status === "completed" && task?.kind !== "historical-baseline";
    });
  }

  function buildPeriodCatalog(value) {
    const model = value?.rowsByDate ? value : buildBusinessModel(value);
    const analysisStart = String(model.dataset.analysisRange?.startDate || "");
    const analysisEnd = String(model.dataset.analysisRange?.endDate || "");
    const days = model.analysisRows.map(row => ({
      key: row.window.requestDate,
      startDate: row.window.requestDate,
      endDate: row.window.requestDate,
      label: row.window.requestDate
    }));
    const weeks = [];
    for (let start = weekStart(analysisStart); start && start <= weekStart(analysisEnd); start = addDays(start, 7)) {
      const end = addDays(start, 6);
      const row = model.rowsByDate.get(end);
      if (row?.window?.startDate === start && row?.window?.endDate === end) {
        weeks.push({ key: start, startDate: start, endDate: end, label: `${start} 至 ${end}` });
      }
    }
    const months = [];
    for (let cursor = `${analysisStart.slice(0, 7)}-01`; cursor <= `${analysisEnd.slice(0, 7)}-01`;) {
      const end = monthEnd(cursor);
      const complete = cursor >= analysisStart && end <= analysisEnd
        && model.rows.filter(row => row.window.requestDate >= cursor && row.window.requestDate <= end).length === dateSpan(cursor, end);
      if (complete) months.push({ key: cursor.slice(0, 7), startDate: cursor, endDate: end, label: cursor.slice(0, 7) });
      const [year, month] = cursor.split("-").map(Number);
      cursor = new Date(Date.UTC(year, month, 1)).toISOString().slice(0, 10);
    }
    const collectedRows = actualCollectedRows(model);
    const collectedStartDate = collectedRows[0]?.window?.requestDate || "";
    const collectedEndDate = collectedRows.at(-1)?.window?.requestDate || "";
    const allCollected = collectedRows.length ? [{
      key: `${collectedStartDate}:${collectedEndDate}`,
      startDate: collectedStartDate,
      endDate: collectedEndDate,
      label: `${collectedStartDate} 至 ${collectedEndDate}（${collectedRows.length}个有效业务日）`,
      actualDates: collectedRows.map(row => row.window.requestDate)
    }] : [];
    return {
      "all-collected": allCollected,
      "natural-day": days,
      "natural-week": weeks,
      "natural-month": months,
      defaultMode: months.length ? "natural-month" : weeks.length ? "natural-week" : days.length ? "natural-day" : "analysis-range"
    };
  }

  function aggregateMetrics(rows, compareRows, options = {}) {
    return Object.fromEntries(FIELD_DEFS.map(field => {
      const isMonthlyFlow = options.periodMode === "natural-month" && field.monthlyAggregation === "flow";
      const current = isMonthlyFlow
        ? monthlyFlowParsed(rows, field, options.currentStartDate, options.currentEndDate,
          `${options.cateId}|${String(options.currentStartDate || "").slice(0, 7)}|${field.key}|monthly-fit-v1`)
        : medianParsed(rows, field);
      const compare = isMonthlyFlow
        ? monthlyFlowParsed(compareRows || [], field, options.compareStartDate, options.compareEndDate,
          `${options.cateId}|${String(options.compareStartDate || "").slice(0, 7)}|${field.key}|monthly-fit-v1`)
        : medianParsed(compareRows || [], field);
      const currentValue = current?.reference;
      const compareValue = compare?.reference;
      const change = Number.isFinite(currentValue) && Number.isFinite(compareValue)
        ? compareValue === 0 ? currentValue === 0 ? 0 : null : currentValue / compareValue - 1
        : null;
      return [field.key, {
        current,
        compare,
        change,
        compareSource: compareRows?.length ? "period" : null
      }];
    }));
  }

  function metricChange(current, compare) {
    return Number.isFinite(current) && Number.isFinite(compare)
      ? compare === 0 ? current === 0 ? 0 : null : current / compare - 1
      : null;
  }

  function resolvedMetricChange(metric) {
    const computed = metricChange(metric?.current?.reference, metric?.compare?.reference);
    if (metric?.current?.exact && metric?.compare?.exact) return computed;
    return Number.isFinite(metric?.change) ? metric.change : computed;
  }

  function periodMetricsForRows(base, rows, mode, startDate, endDate) {
    if (!rows.length || rows.length !== dateSpan(startDate, endDate)) return null;
    if (mode === "natural-day") return base.rowsByDate.get(endDate)?.metrics || null;
    if (mode === "natural-week") {
      const exact = base.rowsByDate.get(endDate);
      if (exact?.window?.startDate === startDate && exact?.window?.endDate === endDate) return exact.metrics;
    }
    return aggregateMetrics(rows, [], {
      periodMode: mode,
      cateId: base.dataset.cateId,
      currentStartDate: startDate,
      currentEndDate: endDate
    });
  }

  function resolveReportView(value, options = {}) {
    const base = value?.rowsByDate ? value : buildBusinessModel(value);
    const catalog = buildPeriodCatalog(base);
    const requestedMode = String(options.periodMode || "");
    const mode = requestedMode === "analysis-range" || requestedMode === "custom-range"
      ? requestedMode
      : catalog[requestedMode]?.length ? requestedMode : catalog.defaultMode;
    const availableStartDate = String(base.dataset.analysisRange?.startDate || base.analysisRows[0]?.window?.requestDate || "");
    const availableEndDate = String(base.dataset.analysisRange?.endDate || base.analysisRows.at(-1)?.window?.requestDate || "");
    const analysisRangeChoice = {
      key: `${availableStartDate}:${availableEndDate}`,
      startDate: availableStartDate,
      endDate: availableEndDate,
      label: `${availableStartDate} 至 ${availableEndDate}`
    };
    let customStartDate = ISO_DATE.test(String(options.customStartDate || "")) ? String(options.customStartDate) : availableStartDate;
    let customEndDate = ISO_DATE.test(String(options.customEndDate || "")) ? String(options.customEndDate) : availableEndDate;
    if (customStartDate > customEndDate) [customStartDate, customEndDate] = [customEndDate, customStartDate];
    customStartDate = customStartDate < availableStartDate ? availableStartDate : customStartDate;
    customEndDate = customEndDate > availableEndDate ? availableEndDate : customEndDate;
    if (customStartDate > customEndDate) {
      customStartDate = availableStartDate;
      customEndDate = availableEndDate;
    }
    const customRangeChoice = {
      key: `${customStartDate}:${customEndDate}`,
      startDate: customStartDate,
      endDate: customEndDate,
      label: `${customStartDate} 至 ${customEndDate}`
    };
    const choices = mode === "analysis-range" ? [analysisRangeChoice]
      : mode === "custom-range" ? [customRangeChoice] : catalog[mode] || [];
    const selected = choices.find(choice => choice.key === String(options.periodKey || "")) || choices.at(-1);
    const selectedActualDates = mode === "all-collected" ? new Set(selected.actualDates || []) : null;
    const viewRows = mode === "all-collected"
      ? base.rows.filter(row => selectedActualDates.has(row.window.requestDate))
      : base.rows.filter(row => row.window.requestDate >= selected.startDate && row.window.requestDate <= selected.endDate);
    let summaryMetrics;
    let compareStartDate;
    let compareEndDate;
    if (mode === "natural-day") {
      const exact = base.rowsByDate.get(selected.endDate);
      compareStartDate = addDays(selected.startDate, -1);
      compareEndDate = compareStartDate;
      const compareRow = base.rowsByDate.get(compareEndDate);
      summaryMetrics = Object.fromEntries(FIELD_DEFS.map(field => {
        const current = exact?.metrics?.[field.key]?.current || null;
        const compare = compareRow?.metrics?.[field.key]?.current || null;
        return [field.key, {
          current,
          compare,
          change: metricChange(current?.reference, compare?.reference),
          compareSource: compare ? "previous-day" : null
        }];
      }));
    } else if (mode === "natural-week") {
      const exact = base.rowsByDate.get(selected.endDate);
      summaryMetrics = exact?.metrics || aggregateMetrics(viewRows, []);
      compareStartDate = addDays(selected.startDate, -7);
      compareEndDate = addDays(selected.endDate, -7);
    } else if (mode === "natural-month") {
      compareEndDate = addDays(selected.startDate, -1);
      compareStartDate = `${compareEndDate.slice(0, 7)}-01`;
      const compareRows = base.rows.filter(row => row.window.requestDate >= compareStartDate && row.window.requestDate <= compareEndDate);
      const completeCompare = compareRows.length === dateSpan(compareStartDate, compareEndDate) ? compareRows : [];
      summaryMetrics = aggregateMetrics(viewRows, completeCompare, {
        periodMode: mode,
        cateId: base.dataset.cateId,
        currentStartDate: selected.startDate,
        currentEndDate: selected.endDate,
        compareStartDate,
        compareEndDate
      });
    } else {
      const days = Math.max(1, dateSpan(selected.startDate, selected.endDate));
      compareEndDate = addDays(selected.startDate, -1);
      compareStartDate = addDays(compareEndDate, 1 - days);
      const compareRows = base.rows.filter(row => row.window.requestDate >= compareStartDate && row.window.requestDate <= compareEndDate);
      summaryMetrics = aggregateMetrics(viewRows, compareRows.length === days ? compareRows : []);
    }
    const yearOverYearStartDate = shiftYear(selected.startDate, -1);
    const yearOverYearEndDate = shiftYear(selected.endDate, -1);
    const yearOverYearRows = base.rows.filter(row => row.window.requestDate >= yearOverYearStartDate
      && row.window.requestDate <= yearOverYearEndDate);
    const yearOverYearMetrics = periodMetricsForRows(base, yearOverYearRows, mode,
      yearOverYearStartDate, yearOverYearEndDate);
    const modeLabel = mode === "natural-month" ? "自然月" : mode === "natural-week" ? "自然周"
      : mode === "natural-day" ? "自然日" : mode === "custom-range" ? "自定义区间"
        : mode === "all-collected" ? "全部已采周期" : "当前业务区间";
    return {
      ...base,
      catalog,
      periodMode: mode,
      periodKey: selected.key,
      periodChoices: choices,
      periodStartDate: selected.startDate,
      periodEndDate: selected.endDate,
      periodLabel: mode === "natural-day" ? selected.startDate
        : mode === "all-collected" ? selected.label : `${selected.startDate} 至 ${selected.endDate}`,
      compareStartDate,
      compareEndDate,
      compareLabel: `${compareStartDate} 至 ${compareEndDate}`,
      yearOverYearStartDate,
      yearOverYearEndDate,
      yearOverYearMetrics,
      modeLabel,
      valueLabel: mode === "natural-month" ? "本月" : mode === "natural-week" ? "本周" : mode === "natural-day" ? "当日"
        : mode === "custom-range" ? "自选周期" : mode === "all-collected" ? "全部已采" : "本期",
      compareValueLabel: mode === "natural-month" ? "上月" : mode === "natural-week" ? "上周" : mode === "natural-day" ? "前一日" : mode === "custom-range" ? "上一周期" : "上期",
      availableStartDate,
      availableEndDate,
      viewRows,
      analysisRows: viewRows,
      latestRow: viewRows.at(-1),
      summaryMetrics,
      metricStats: metricStatsFor(viewRows),
      analysisWindowCount: viewRows.length,
      actualCollectedDayCount: mode === "all-collected" ? viewRows.length : null
    };
  }

  function metricHasData(model, key) {
    return model.viewRows.some(row => row.metrics[key]?.current);
  }

  function buildHistoricalPeriods(dataset) {
    return (Array.isArray(dataset?.baselines) ? dataset.baselines : []).map((period, index) => {
      if (!period?.market || typeof period.market !== "object") return null;
      const metrics = Object.fromEntries(FIELD_DEFS.map(field => {
        const current = parseReferenceValue(period.market[field.key], field.kind);
        const change = parseChange(period.market[field.popKey]);
        const currentValue = current?.reference;
        const compare = Number.isFinite(currentValue) && Number.isFinite(change) && change > -1
          ? parsedReference(currentValue / (1 + change), field.kind)
          : null;
        return [field.key, { current, compare, change }];
      }));
      const keys = FIELD_DEFS.filter(field => metrics[field.key].current).map(field => field.key);
      if (!keys.length) return null;
      return {
        key: String(period.taskId || `${period.startDate || ""}:${period.endDate || ""}:${index}`),
        startDate: String(period.startDate || ""),
        endDate: String(period.endDate || ""),
        compareStartDate: String(period.compareStartDate || ""),
        compareEndDate: String(period.compareEndDate || ""),
        periodLabel: period.startDate && period.endDate ? `${period.startDate} 至 ${period.endDate}` : "—",
        compareLabel: period.compareStartDate && period.compareEndDate
          ? `${period.compareStartDate} 至 ${period.compareEndDate}` : "—",
        metrics,
        keys
      };
    }).filter(Boolean);
  }

  function comparisonMetricSet(metrics, side = "current") {
    return Object.fromEntries(FIELD_DEFS.map(field => [field.key, metrics?.[field.key]?.[side] || null]));
  }

  function comparisonShortLabel(startDate, endDate) {
    if (startDate === endDate) return startDate;
    if (String(startDate).endsWith("-01") && monthEnd(startDate) === endDate) return String(startDate).slice(0, 7);
    return `${startDate} 至 ${endDate}`;
  }

  function buildPeriodComparison(value, options = {}) {
    const model = value?.summaryMetrics && value?.periodMode
      ? value
      : resolveReportView(buildBusinessModel(value), options);
    const currentMetrics = comparisonMetricSet(model.summaryMetrics);
    let previousMetrics = comparisonMetricSet(model.summaryMetrics, "compare");
    for (const historical of buildHistoricalPeriods(model.dataset)) {
      const exact = historical.startDate === model.compareStartDate && historical.endDate === model.compareEndDate
        ? comparisonMetricSet(historical.metrics)
        : historical.compareStartDate === model.compareStartDate && historical.compareEndDate === model.compareEndDate
          ? comparisonMetricSet(historical.metrics, "compare") : null;
      if (exact) {
        previousMetrics = Object.fromEntries(FIELD_DEFS.map(field => [field.key,
          previousMetrics[field.key] || exact[field.key] || null]));
      }
    }
    const periods = [
      {
        key: "current",
        startDate: model.periodStartDate,
        endDate: model.periodEndDate,
        label: model.periodLabel,
        shortLabel: comparisonShortLabel(model.periodStartDate, model.periodEndDate),
        sourceLabel: model.periodMode === "custom-range" ? "自选周期" : model.modeLabel,
        metrics: currentMetrics,
        isPrimary: true
      },
      {
        key: "previous",
        startDate: model.compareStartDate,
        endDate: model.compareEndDate,
        label: model.compareLabel,
        shortLabel: comparisonShortLabel(model.compareStartDate, model.compareEndDate),
        sourceLabel: "上一周期",
        metrics: previousMetrics,
        isPrimary: false
      }
    ];
    const keys = FIELD_DEFS.filter(field => periods.some(period => period.metrics[field.key])).map(field => field.key);
    const changes = Object.fromEntries(keys.map(key => {
      const metric = model.summaryMetrics[key];
      const resolved = resolvedMetricChange(metric);
      return [key, Number.isFinite(resolved)
        ? resolved
        : metricChange(currentMetrics[key]?.reference, previousMetrics[key]?.reference)];
    }));
    return {
      periods,
      selectedPeriods: periods,
      selectedKeys: periods.map(period => period.key),
      keys,
      changes,
      valueLabel: model.valueLabel,
      compareValueLabel: model.compareValueLabel
    };
  }

  function yearOverYearChange(model, key) {
    return metricChange(
      model.summaryMetrics[key]?.current?.reference,
      model.yearOverYearMetrics?.[key]?.current?.reference
    );
  }

  function hasYearOverYearData(model, key = "") {
    if (key) return Number.isFinite(model.yearOverYearMetrics?.[key]?.current?.reference);
    return FIELD_DEFS.some(field => Number.isFinite(model.yearOverYearMetrics?.[field.key]?.current?.reference));
  }

  function metricCard(model, key) {
    const field = FIELD_BY_KEY[key];
    const metric = model.summaryMetrics[key];
    const change = resolvedMetricChange(metric);
    const yoyChange = yearOverYearChange(model, key);
    const showYearOverYear = hasYearOverYearData(model);
    return `<article class="metric-card core-kpi-card">
      <div class="metric-head"><span>${escapeHtml(field.label)}</span><em>${escapeHtml(model.valueLabel)}</em></div>
      <strong class="metric-value">${escapeHtml(formatParsed(field, metric.current))}</strong>
      <div class="kpi-comparison-grid${showYearOverYear ? " has-yoy" : ""}">
        <span><small>${escapeHtml(model.compareValueLabel)}</small><b>${escapeHtml(formatParsed(field, metric.compare))}</b></span>
        <span><small>环比</small>${changeValueHtml(change)}</span>
        ${showYearOverYear ? `<span><small>同比</small>${changeValueHtml(yoyChange)}</span>` : ""}
      </div>
    </article>`;
  }

  function safeRatio(numerator, denominator) {
    return Number.isFinite(numerator) && Number.isFinite(denominator) && denominator > 0 ? numerator / denominator : null;
  }

  function derivedCard(model, label, currentValue, compareValue, kind) {
    if (!Number.isFinite(currentValue) && !Number.isFinite(compareValue)) return "";
    const difference = metricChange(currentValue, compareValue);
    return `<div class="derived-card"><span class="derived-label">${escapeHtml(label)}</span><div class="derived-current"><small>${escapeHtml(model.valueLabel)}</small><strong>${escapeHtml(formatMetricValue(kind, currentValue))}</strong></div><div class="derived-compare"><span><small>${escapeHtml(model.compareValueLabel)}</small><b>${escapeHtml(formatMetricValue(kind, compareValue))}</b></span><span><small>环比</small>${changeValueHtml(difference)}</span></div>${kind === "percent" ? ratioMeterHtml(label, currentValue) : ""}</div>`;
  }

  function moduleDerivedCards(model, moduleId) {
    const ref = (key, side = "current") => model.summaryMetrics[key]?.[side]?.reference;
    const ratio = (numerator, denominator) => [
      safeRatio(ref(numerator), ref(denominator)),
      safeRatio(ref(numerator, "compare"), ref(denominator, "compare"))
    ];
    if (moduleId === "market") {
      const values = ratio("alipayInshopAmt", "saleCnt");
      return derivedCard(model, "单动销商品成交额", values[0], values[1], "money");
    }
    if (moduleId === "crowd") {
      const values = ratio("newCustCnt", "alipayUv");
      return derivedCard(model, "新客成交占比", values[0], values[1], "percent");
    }
    if (moduleId === "product") {
      const newValues = ratio("newCnt", "saleCnt");
      const hotValues = ratio("hotCnt", "saleCnt");
      return `${derivedCard(model, "新品占比", newValues[0], newValues[1], "percent")}${derivedCard(model, "热销商品占比", hotValues[0], hotValues[1], "percent")}`;
    }
    return "";
  }

  function businessMetricRow(model, key) {
    const field = FIELD_BY_KEY[key];
    const metric = model.summaryMetrics[key];
    const change = resolvedMetricChange(metric);
    const yoyChange = yearOverYearChange(model, key);
    const showYearOverYear = hasYearOverYearData(model);
    return `<div class="business-metric-row${showYearOverYear ? " has-yoy" : ""}">
      <span class="business-metric-name">${escapeHtml(field.label)}</span>
      <strong>${escapeHtml(formatParsed(field, metric.current))}</strong>
      <span>${escapeHtml(formatParsed(field, metric.compare))}</span>
      <span>${changeValueHtml(change)}</span>
      ${showYearOverYear ? `<span>${changeValueHtml(yoyChange)}</span>` : ""}
    </div>`;
  }

  function renderBusinessDistribution(model, modules, index) {
    const panels = modules.map(module => {
      const keys = module.keys.filter(key => metricHasData(model, key));
      if (!keys.length) return "";
      const derived = moduleDerivedCards(model, module.id);
      const showYearOverYear = hasYearOverYearData(model);
      return `<article class="distribution-module" id="${module.id}"><header><h3>${escapeHtml(module.title)}</h3><span>${keys.length} 项</span></header>
        <div class="business-metric-header${showYearOverYear ? " has-yoy" : ""}"><span>指标</span><span>${escapeHtml(model.valueLabel)}</span><span>${escapeHtml(model.compareValueLabel)}</span><span>环比</span>${showYearOverYear ? "<span>同比</span>" : ""}</div>
        <div class="business-metric-list">${keys.map(key => businessMetricRow(model, key)).join("")}</div>
        ${derived ? `<div class="distribution-derived">${derived}</div>` : ""}</article>`;
    }).filter(Boolean).join("");
    return panels ? `<section class="section" id="distribution"><div class="section-title"><div><span class="section-index">${String(index).padStart(2, "0")}</span><h2>类目经营概览</h2></div><span>${escapeHtml(model.periodLabel)}</span></div><div class="business-distribution-grid">${panels}</div></section>` : "";
  }

  function renderPeriodComparison(comparison, index) {
    const periods = comparison.selectedPeriods;
    if (!comparison.keys.length) return "";
    const headers = periods.map(period => `<th scope="col" class="comparison-period-heading${period.isPrimary ? " is-primary" : ""}"><strong>${escapeHtml(period.shortLabel)}</strong>${period.label !== period.shortLabel ? `<small>${escapeHtml(period.label)}</small>` : ""}<em>${escapeHtml(period.sourceLabel)}</em></th>`).join("");
    const rows = comparison.keys.map(key => {
      const field = FIELD_BY_KEY[key];
      const current = periods.find(period => period.isPrimary)?.metrics[key] || null;
      const previous = periods.find(period => !period.isPrimary)?.metrics[key] || null;
      const difference = comparison.changes[key];
      return `<tr><th scope="row">${escapeHtml(field.label)}</th><td class="comparison-value-cell is-primary"><strong>${escapeHtml(formatParsed(field, current))}</strong></td><td class="comparison-value-cell"><span>${escapeHtml(formatParsed(field, previous))}</span></td><td class="comparison-change-cell">${changeValueHtml(difference)}</td></tr>`;
    }).join("");
    return `<section class="section" id="history"><div class="section-title"><div><span class="section-index">${String(index).padStart(2, "0")}</span><h2>类目周期环比</h2></div><span>${escapeHtml(comparison.valueLabel)}对比${escapeHtml(comparison.compareValueLabel)} · ${comparison.keys.length} 项指标</span></div><div class="period-comparison-wrap"><table class="period-comparison-table"><thead><tr><th scope="col" class="comparison-metric-heading">指标</th>${headers}<th scope="col" class="comparison-change-heading">环比</th></tr></thead><tbody>${rows}</tbody></table></div></section>`;
  }

  function axisValue(field, value) {
    if (!Number.isFinite(value)) return "—";
    if (field.kind === "percent") return `${numericText(value * 100, 0, 2)}%`;
    return formatMetricValue(field, value);
  }

  function trendChart(model, key) {
    const field = FIELD_BY_KEY[key];
    const dailyEquivalent = model.periodMode === "natural-month" && field.monthlyAggregation === "flow";
    const points = model.viewRows.map(row => ({
      date: row.window.requestDate,
      value: Number.isFinite(row.metrics[key].current?.reference)
        ? row.metrics[key].current.reference / (dailyEquivalent ? 7 : 1)
        : null
    }));
    const finitePoints = points.map((point, index) => ({ ...point, index })).filter(point => Number.isFinite(point.value));
    if (finitePoints.length < 2) return "";
    const width = 720, height = 250, left = 94, right = 20, top = 22, bottom = 38;
    let min = Math.min(...finitePoints.map(point => point.value));
    let max = Math.max(...finitePoints.map(point => point.value));
    if (min === max) {
      const minimumSpread = field.kind === "percent" ? 0.005
        : field.kind === "ratio" || field.kind === "frequency" ? 0.1 : 1;
      const spread = Math.max(Math.abs(max) * 0.08, minimumSpread);
      min -= spread;
      max += spread;
    }
    const padding = (max - min) * 0.08;
    min -= padding;
    max += padding;
    const x = index => left + index * (width - left - right) / Math.max(1, points.length - 1);
    const y = value => top + (max - value) * (height - top - bottom) / (max - min);
    let drawing = false;
    const path = points.map((point, index) => {
      if (!Number.isFinite(point.value)) {
        drawing = false;
        return "";
      }
      const command = drawing ? "L" : "M";
      drawing = true;
      return `${command}${x(index).toFixed(2)},${y(point.value).toFixed(2)}`;
    }).filter(Boolean).join(" ");
    const grid = Array.from({ length: 5 }, (_, index) => {
      const ratio = index / 4;
      const gridY = top + ratio * (height - top - bottom);
      return `<line x1="${left}" y1="${gridY.toFixed(2)}" x2="${width - right}" y2="${gridY.toFixed(2)}"/><text x="${left - 10}" y="${(gridY + 4).toFixed(2)}">${escapeHtml(axisValue(field, max - ratio * (max - min)))}</text>`;
    }).join("");
    const labels = [0, Math.floor((points.length - 1) / 2), points.length - 1]
      .filter((value, index, values) => values.indexOf(value) === index)
      .map(index => `<text class="x-label" x="${x(index).toFixed(2)}" y="${height - 10}" text-anchor="${index === 0 ? "start" : index === points.length - 1 ? "end" : "middle"}">${escapeHtml(points[index].date.slice(5))}</text>`).join("");
    const firstToLast = finitePoints[0].value !== 0 ? finitePoints.at(-1).value / finitePoints[0].value - 1 : null;
    const trendLabel = model.periodMode === "natural-month"
      ? dailyEquivalent ? "月内日均趋势" : "月内业务趋势"
      : "周期业务趋势";
    const metricLabel = dailyEquivalent ? `${field.label}（日均）` : field.label;
    const lastFiniteIndex = finitePoints.at(-1).index;
    const chartPoints = points.map((point, index) => {
      if (!Number.isFinite(point.value)) return "";
      const tooltip = `${point.date}｜${metricLabel}｜类目大盘：${formatMetricValue(field, point.value)}`;
      const cx = x(index).toFixed(2);
      const cy = y(point.value).toFixed(2);
      return `<g class="chart-point" data-chart-point data-tooltip="${escapeHtml(tooltip)}" data-period="${escapeHtml(point.date)}" data-metric="${escapeHtml(metricLabel)}" data-role="类目大盘" data-value="${escapeHtml(point.value)}" tabindex="0" focusable="true" role="img" aria-label="${escapeHtml(tooltip)}"><circle class="chart-point-hit" cx="${cx}" cy="${cy}" r="10"/><circle class="trend-point${index === lastFiniteIndex ? " trend-last" : ""}" cx="${cx}" cy="${cy}" r="${index === lastFiniteIndex ? "4" : "3"}"/><title>${escapeHtml(tooltip)}</title></g>`;
    }).join("");
    return `<article class="chart-card"><div class="chart-head"><div><h3>${escapeHtml(field.label)}趋势</h3><span>${escapeHtml(trendLabel)}</span></div><div><b>首末变化 ${escapeHtml(formatChange(firstToLast))}</b></div></div>
      <svg class="trend-svg" viewBox="0 0 ${width} ${height}" role="img" aria-label="${escapeHtml(field.label)}${escapeHtml(trendLabel)}"><g class="chart-grid">${grid}${labels}</g><path class="trend-line" d="${path}"/>${chartPoints}</svg></article>`;
  }

  function renderTrends(model, index) {
    const charts = TREND_KEYS.filter(key => metricHasData(model, key)).map(key => trendChart(model, key)).filter(Boolean);
    return charts.length ? `<section class="section" id="trends"><div class="section-title"><div><span class="section-index">${String(index).padStart(2, "0")}</span><h2>类目趋势</h2></div><span>${escapeHtml(model.periodLabel)}</span></div><div class="chart-grid-wrap">${charts.join("")}</div></section>` : "";
  }

  function detailTable(model, module) {
    const keys = module.keys.filter(key => metricHasData(model, key));
    if (!keys.length) return "";
    const headers = ["日期", ...keys.flatMap(key => [FIELD_BY_KEY[key].label, `${FIELD_BY_KEY[key].label}环比`])];
    const rows = model.viewRows.map(row => `<tr><td class="date-cell">${escapeHtml(row.window.requestDate)}</td>${keys.map(key => {
      const field = FIELD_BY_KEY[key];
      const metric = row.metrics[key];
      const change = resolvedMetricChange(metric);
      return `<td class="number-cell">${escapeHtml(formatParsed(field, metric.current))}</td><td class="number-cell ${changeClass(change)}">${escapeHtml(formatChange(change))}</td>`;
    }).join("")}</tr>`).join("");
    return `<details class="detail-group"><summary><span>${escapeHtml(module.title)}每日数据</span></summary><div class="table-wrap detail-table"><table><thead><tr>${headers.map(header => `<th>${escapeHtml(header)}</th>`).join("")}</tr></thead><tbody>${rows}</tbody></table></div></details>`;
  }

  function renderDetails(model, index) {
    const groups = MODULES.map(module => detailTable(model, module)).filter(Boolean);
    return groups.length ? `<section class="section" id="details"><div class="section-title"><div><span class="section-index">${String(index).padStart(2, "0")}</span><h2>类目每日数据</h2></div><span>${escapeHtml(model.periodLabel)}</span></div><div class="detail-groups">${groups.join("")}</div></section>` : "";
  }

  function watermarkMarkup() {
    return `<div class="report-watermark" data-report-watermark aria-hidden="true">${Array.from({ length: 54 }, () => "<span>少壮AI自动化 · shaozhuangai.com</span>").join("")}</div>`;
  }

  const TRACK_SCORE_DEFS = Object.freeze([
    { key: "aScore", label: "搜索潜力" },
    { key: "bScore", label: "成交潜力" },
    { key: "cScore", label: "拉新潜力" },
    { key: "eScore", label: "蓝海指数" }
  ]);
  const TRACK_SCORE_BY_KEY = Object.freeze(Object.fromEntries(TRACK_SCORE_DEFS.map(item => [item.key, item])));
  const TRACK_ARCHIVE_COLUMNS = Object.freeze([
    "周期", "周期开始", "周期结束", "属性维度", "属性值", "价格带",
    "搜索潜力", "成交潜力", "拉新潜力", "蓝海指数"
  ]);
  const TRACK_ARCHIVE_TABLE_PREFIX = "细分赛道矩阵-";
  const TRACK_ARCHIVE_MAX_ROWS = 5000;
  const TRACK_ARCHIVE_NAME_PART_MAX_LENGTH = 72;

  function trackSnapshot(dataset) {
    const value = dataset?.track || dataset?.trackSnapshot;
    return value && value.schemaVersion === "dmp-track/1.0" && Array.isArray(value.properties) ? value : null;
  }

  function trackProperties(dataset) {
    return (trackSnapshot(dataset)?.properties || []).filter(property => property
      && String(property.propertyId || "").trim()
      && String(property.propertyName || "").trim()
      && Array.isArray(property.periods)
      && property.periods.length);
  }

  function trackPeriodKey(period) {
    return [period?.periodType, period?.date, period?.startDate, period?.endDate].map(value => String(value || "")).join("|");
  }

  function sortedTrackPeriods(property) {
    return [...(property?.periods || [])].filter(period => period && Array.isArray(period.rows))
      .sort((left, right) => String(right.endDate || right.date || "").localeCompare(String(left.endDate || left.date || ""))
        || String(right.startDate || "").localeCompare(String(left.startDate || "")));
  }

  function trackLatestContract(dataset) {
    const snapshot = trackSnapshot(dataset);
    const source = snapshot?.audit?.latestContract;
    if (Number(snapshot?.audit?.contractVersion || 0) < 3
      || snapshot?.audit?.authoritativePriceRangeCaptured !== true
      || !source || typeof source !== "object" || Array.isArray(source)
      || !Array.isArray(source.expectedPriceRanges) || source.expectedPriceRanges.length === 0) return null;
    const periodType = String(source.periodType || "").trim();
    const normalizeRequest = value => {
      const requestPeriodType = String(value?.periodType || "").trim();
      const date = String(value?.date || "").trim();
      return requestPeriodType === periodType && /^\d{1,2}$/.test(periodType) && /^20\d{2}-\d{2}(?:-\d{2})?$/.test(date)
        ? { periodType, date }
        : null;
    };
    const currentRequest = normalizeRequest(source.currentRequest);
    if (!currentRequest || !Array.isArray(source.expectedProperties) || !source.expectedProperties.length) return null;
    const previousRequest = source.previousRequest == null ? null : normalizeRequest(source.previousRequest);
    if (source.previousRequest != null && !previousRequest) return null;
    return {
      periodType,
      currentRequest,
      previousRequest,
      expectedProperties: source.expectedProperties.map(property => ({
        propertyId: String(property?.propertyId || "").trim(),
        propertyName: String(property?.propertyName || "").trim()
      })).filter(property => property.propertyId && property.propertyName)
    };
  }

  function matchedPreviousTrackPeriod(periods, current) {
    if (!current) return null;
    return periods.find(period => period !== current
      && String(period.periodType || "") === String(current.periodType || "")
      && String(period.startDate || "") === String(current.compareStartDate || "")
      && String(period.endDate || "") === String(current.compareEndDate || "")) || null;
  }

  function trackView(dataset, options = {}) {
    const contract = trackLatestContract(dataset);
    if (!contract || contract.expectedProperties.length === 0) return null;
    const expectedPropertyIds = new Set(contract.expectedProperties.map(property => property.propertyId));
    const properties = trackProperties(dataset).filter(property => expectedPropertyIds.has(String(property.propertyId || "")));
    if (properties.length !== expectedPropertyIds.size) return null;
    const property = properties.find(item => String(item.propertyId) === String(options.trackPropertyId || "")) || properties[0];
    const periods = sortedTrackPeriods(property);
    const requestedPeriod = periods.find(period => trackPeriodKey(period) === String(options.trackPeriodKey || ""));
    const contractCurrent = periods.find(period => String(period?.periodType || "") === contract.currentRequest.periodType
      && String(period?.date || "") === contract.currentRequest.date) || null;
    const current = requestedPeriod || contractCurrent;
    if (!current) return null;
    const previous = requestedPeriod
      ? matchedPreviousTrackPeriod(periods, current)
      : contract.previousRequest
        ? periods.find(period => String(period?.periodType || "") === contract.previousRequest.periodType
          && String(period?.date || "") === contract.previousRequest.date) || null
        : null;
    const metric = TRACK_SCORE_BY_KEY[options.trackMetric] ? options.trackMetric : "aScore";
    const requestedMode = ["current", "previous", "delta"].includes(options.trackView) ? options.trackView : "current";
    const mode = requestedMode === "current" || previous ? requestedMode : "current";
    return { contract, properties, property, periods, current, previous, metric, mode };
  }

  function trackPeriodLabel(period) {
    if (!period) return "—";
    if (period.startDate && period.endDate) return `${period.startDate} 至 ${period.endDate}`;
    return String(period.date || "—");
  }

  function trackPropertyValueNames(view) {
    const names = [];
    const add = value => {
      const text = String(value || "").trim();
      if (text && !names.includes(text)) names.push(text);
    };
    for (const value of view.current?.columns || []) add(value);
    for (const row of view.current?.rows || []) for (const cell of row?.cells || []) add(cell?.propertyValueName ?? cell?.property);
    return names;
  }

  function trackPriceBandNames(dataset, view) {
    const names = [];
    const add = value => {
      const text = String(value || "").trim();
      if (text && !names.includes(text)) names.push(text);
    };
    for (const row of view.current?.rows || []) add(row?.priceRange);
    return names;
  }

  function trackCell(period, priceRange, propertyValueName) {
    const row = (period?.rows || []).find(item => String(item?.priceRange || "") === String(priceRange));
    return (row?.cells || []).find(item => String(item?.propertyValueName ?? item?.property ?? "") === String(propertyValueName)) || null;
  }

  function trackScore(cell, metric) {
    const scores = cell?.scores;
    if (!scores || !Object.prototype.hasOwnProperty.call(scores, metric)) return null;
    return typeof scores[metric] === "number" && Number.isFinite(scores[metric]) ? scores[metric] : null;
  }

  function trackMatrixScore(cell, metric) {
    const raw = trackScore(cell, metric);
    return Number.isFinite(raw) ? Math.round(raw * 100) : null;
  }

  function trackScoreText(value, mode = "current") {
    if (!Number.isFinite(value)) return "—";
    const rounded = Math.round(value * 10000) / 10000;
    const text = Number.isInteger(rounded) ? String(rounded) : String(rounded).replace(/0+$/, "").replace(/\.$/, "");
    return mode === "delta" && rounded > 0 ? `+${text}` : text;
  }

  function trackMatrixValues(dataset, view) {
    const values = [];
    for (const priceRange of trackPriceBandNames(dataset, view)) {
      for (const propertyValueName of trackPropertyValueNames(view)) {
        const current = trackMatrixScore(trackCell(view.current, priceRange, propertyValueName), view.metric);
        const previous = trackMatrixScore(trackCell(view.previous, priceRange, propertyValueName), view.metric);
        if (Number.isFinite(current)) values.push(current);
        if (Number.isFinite(previous)) values.push(previous);
      }
    }
    return values;
  }

  function trackHeatStyle(value, scale, mode) {
    if (!Number.isFinite(value) || !Number.isFinite(scale) || scale <= 0) return "";
    const intensity = Math.max(0, Math.min(1, Math.abs(value) / scale));
    return `--track-heat:${(0.08 + intensity * 0.34).toFixed(3)}`;
  }

  function renderTrackSection(dataset, options, index) {
    const view = trackView(dataset, options);
    const unavailable = detail => `<section class="section track-section" id="tracks"><div class="section-title"><div><span class="section-index">${String(index).padStart(2, "0")}</span><h2>细分赛道：价格带 × 属性</h2></div><span>部分数据</span></div><p class="opportunity-empty"><strong>细分赛道数据待补采</strong><br/>${escapeHtml(detail)}；缺失值未按 0 处理，完成补采后会显示本期及精确上一周期矩阵。</p></section>`;
    if (!view?.current) return unavailable("当前类目尚未形成可验证的完整交叉矩阵");
    const propertyNames = trackPropertyValueNames(view);
    const priceBands = trackPriceBandNames(dataset, view);
    if (!propertyNames.length || !priceBands.length) return unavailable("当前周期的属性值或价格带未完整返回");
    const periodOptions = view.periods.map(period => `<option value="${escapeHtml(trackPeriodKey(period))}"${period === view.current ? " selected" : ""}>${escapeHtml(trackPeriodLabel(period))}</option>`).join("");
    const propertyOptions = view.properties.map(property => `<option value="${escapeHtml(property.propertyId)}"${property === view.property ? " selected" : ""}>${escapeHtml(property.propertyName)}</option>`).join("");
    const metricOptions = TRACK_SCORE_DEFS.map(metric => `<option value="${metric.key}"${metric.key === view.metric ? " selected" : ""}>${escapeHtml(metric.label)}</option>`).join("");
    const viewOptions = [
      ["current", "本期"],
      ["previous", "上一周期"],
      ["delta", "变化值"]
    ].map(([value, label]) => `<option value="${value}"${value === view.mode ? " selected" : ""}${value !== "current" && !view.previous ? " disabled" : ""}>${label}${value !== "current" && !view.previous ? "（未采集）" : ""}</option>`).join("");
    const allValues = trackMatrixValues(dataset, view);
    const scale = view.mode === "delta"
      ? Math.max(0, ...priceBands.flatMap(priceRange => propertyNames.map(propertyValueName => {
        const current = trackMatrixScore(trackCell(view.current, priceRange, propertyValueName), view.metric);
        const previous = trackMatrixScore(trackCell(view.previous, priceRange, propertyValueName), view.metric);
        return Number.isFinite(current) && Number.isFinite(previous) ? Math.abs(current - previous) : 0;
      })))
      : Math.max(0, ...allValues.map(value => Math.abs(value)));
    const rows = priceBands.map(priceRange => {
      const cells = propertyNames.map(propertyValueName => {
        const current = trackMatrixScore(trackCell(view.current, priceRange, propertyValueName), view.metric);
        const previous = trackMatrixScore(trackCell(view.previous, priceRange, propertyValueName), view.metric);
        const delta = Number.isFinite(current) && Number.isFinite(previous) ? current - previous : null;
        const value = view.mode === "previous" ? previous : view.mode === "delta" ? delta : current;
        const tone = view.mode === "delta" && Number.isFinite(value) ? value > 0 ? " is-positive" : value < 0 ? " is-negative" : " is-zero" : "";
        const secondary = view.previous && view.mode !== "delta"
          ? `<small>${view.mode === "current" ? "上期" : "本期"} ${escapeHtml(trackScoreText(view.mode === "current" ? previous : current))}</small>`
          : view.mode === "delta" && Number.isFinite(current) && Number.isFinite(previous)
            ? `<small>${escapeHtml(trackScoreText(previous))} → ${escapeHtml(trackScoreText(current))}</small>`
            : "";
        return `<td class="track-heat-cell${tone}${Number.isFinite(value) ? "" : " is-missing"}" style="${trackHeatStyle(value, scale, view.mode)}"><strong>${escapeHtml(trackScoreText(value, view.mode))}</strong>${secondary}</td>`;
      }).join("");
      const displayBand = /以上$/.test(priceRange) ? `≥${priceRange.replace(/以上$/, "")}` : priceRange;
      return `<tr><th scope="row">${escapeHtml(displayBand)}</th>${cells}</tr>`;
    }).join("");
    const comparisonLabel = view.previous
      ? `${trackPeriodLabel(view.current)} 对比 ${trackPeriodLabel(view.previous)}`
      : `${trackPeriodLabel(view.current)} · 上一周期未采集`;
    return `<section class="section track-section" id="tracks"><div class="section-title"><div><span class="section-index">${String(index).padStart(2, "0")}</span><h2>细分赛道：价格带 × ${escapeHtml(view.property.propertyName)}</h2></div><span>${escapeHtml(comparisonLabel)}</span></div>
      <div class="track-controls"><label><span>属性维度</span><select data-track-property>${propertyOptions}</select></label><label><span>赛道周期</span><select data-track-period>${periodOptions}</select></label><label><span>矩阵指标</span><select data-track-metric>${metricOptions}</select></label><label><span>对比视图</span><select data-track-view>${viewOptions}</select></label></div>
      <div class="track-legend"><span>${escapeHtml(TRACK_SCORE_BY_KEY[view.metric].label)}</span><span>价格带为行，属性值为列；本期与上一周期共用色阶，变化值为分值绝对差</span></div>
      <div class="track-heatmap-wrap"><table class="track-heatmap-table"><thead><tr><th scope="col">价格带</th>${propertyNames.map(name => `<th scope="col">${escapeHtml(name)}</th>`).join("")}</tr></thead><tbody>${rows}</tbody></table></div>
    </section>`;
  }

  function trackArchiveNamePart(value) {
    const cleaned = String(value || "")
      .replace(/[\u0000-\u001f\u007f\u200b-\u200f\u202a-\u202e\u2060\ufeff]/g, " ")
      .replace(/[\\/:*?"<>|]+/g, "-")
      .replace(/\s+/g, " ")
      .replace(/-+/g, "-")
      .replace(/^-|-$/g, "")
      .trim() || "未命名属性";
    if (cleaned.length <= TRACK_ARCHIVE_NAME_PART_MAX_LENGTH) return cleaned;
    const hash = stableHash(cleaned).toString(36).padStart(7, "0").slice(-7);
    return `${cleaned.slice(0, TRACK_ARCHIVE_NAME_PART_MAX_LENGTH - hash.length - 1).trim()}-${hash}`;
  }

  function trackArchiveTableStems(properties) {
    const nameParts = properties.map(property => trackArchiveNamePart(property?.propertyName));
    const counts = new Map(nameParts.map(name => [name, nameParts.filter(candidate => candidate === name).length]));
    const used = new Set();
    return properties.map((property, index) => {
      const namePart = nameParts[index];
      const identity = [property?.propertyId, property?.propertyName].map(value => String(value || "")).join("|");
      const identityHash = stableHash(identity).toString(36).padStart(7, "0").slice(-7);
      let stem = `${TRACK_ARCHIVE_TABLE_PREFIX}${namePart}${counts.get(namePart) > 1 ? `-${identityHash}` : ""}`;
      if (used.has(stem)) stem = `${TRACK_ARCHIVE_TABLE_PREFIX}${namePart}-${identityHash}`;
      let collision = 2;
      const baseStem = stem;
      while (used.has(stem)) stem = `${baseStem}-${collision++}`;
      used.add(stem);
      return stem;
    });
  }

  function trackArchivePeriodCoordinateGroups(property, period) {
    const groups = [];
    const propertyNames = [...new Set([
      ...(period.columns || []),
      ...(period.rows || []).flatMap(row => (row?.cells || []).map(cell => cell?.propertyValueName ?? cell?.property))
    ].map(value => String(value || "").trim()).filter(Boolean))];
    const priceBands = [...new Set((period.rows || [])
      .map(row => String(row?.priceRange || "").trim()).filter(Boolean))];
    for (const priceRange of priceBands) {
      for (const propertyValueName of propertyNames) {
        const cell = trackCell(period, priceRange, propertyValueName);
        groups.push([{ cells: [
          trackPeriodLabel(period),
          opportunityPrimitive(period.startDate),
          opportunityPrimitive(period.endDate),
          property.propertyName,
          propertyValueName,
          displayPriceBand(priceRange),
          ...TRACK_SCORE_DEFS.map(metric => trackScoreText(trackMatrixScore(cell, metric.key)))
        ] }]);
      }
    }
    return groups;
  }

  function trackArchivePropertyChunks(property) {
    const chunks = [];
    let current = [];
    const flush = () => {
      if (current.length) chunks.push(current);
      current = [];
    };
    for (const period of sortedTrackPeriods(property)) {
      const groups = trackArchivePeriodCoordinateGroups(property, period);
      const periodRowCount = groups.reduce((total, group) => total + group.length, 0);
      if (!periodRowCount) continue;
      if (periodRowCount <= TRACK_ARCHIVE_MAX_ROWS) {
        if (current.length + periodRowCount > TRACK_ARCHIVE_MAX_ROWS) flush();
        current.push(...groups.flat());
        continue;
      }
      flush();
      for (const group of groups) {
        if (group.length > TRACK_ARCHIVE_MAX_ROWS) throw new Error("细分赛道单坐标指标数超过归档上限");
        if (current.length + group.length > TRACK_ARCHIVE_MAX_ROWS) flush();
        current.push(...group);
      }
      flush();
    }
    flush();
    return chunks;
  }

  function buildTrackArchiveTables(dataset) {
    const properties = trackProperties(dataset);
    const stems = trackArchiveTableStems(properties);
    return properties.flatMap((property, propertyIndex) => {
      const chunks = trackArchivePropertyChunks(property);
      return chunks.map((rows, chunkIndex) => ({
        name: chunks.length === 1
          ? stems[propertyIndex]
          : `${stems[propertyIndex]}-分片${String(chunkIndex + 1).padStart(2, "0")}`,
        columns: [...TRACK_ARCHIVE_COLUMNS],
        rows
      }));
    });
  }

  function buildTrackStatusTable(dataset) {
    const snapshot = trackSnapshot(dataset);
    const view = trackView(dataset, {});
    const matrixReady = Boolean(view?.current
      && trackPropertyValueNames(view).length
      && trackPriceBandNames(dataset, view).length);
    const opportunity = matrixReady ? opportunityPeriod(dataset, view) : null;
    const opportunityReady = Boolean(opportunity
      && String(opportunity.status || "") === "ready"
      && Array.isArray(opportunity.chanceGroups)
      && opportunity.chanceGroups.every(group => String(group?.status || "") === "ready"));
    const period = view?.current ? trackPeriodLabel(view.current) : "—";
    return {
      name: "细分赛道数据状态",
      columns: ["模块", "数据状态", "实际周期", "说明"],
      rows: [
        { cells: [
          "价格带 × 属性矩阵",
          matrixReady ? "完整" : "部分数据",
          period,
          matrixReady ? "已按当前合同返回" : "待补采；缺失值未按0处理"
        ] },
        { cells: [
          "货品增长机会",
          opportunityReady ? "完整" : "部分数据",
          period,
          opportunityReady ? "已返回当前周期机会分类与赛道明细" : "待补采；已返回数据仍保留展示"
        ] },
        { cells: [
          "报告数据状态",
          snapshot?.status === "ready" && matrixReady && opportunityReady ? "完整" : "部分数据",
          period,
          snapshot?.status === "ready" && matrixReady && opportunityReady ? "本期数据已完成" : "报告可打开，并可继续补采"
        ] }
      ]
    };
  }

  const OPPORTUNITY_METRIC_DEFS = Object.freeze([
    { key: "schCnt", label: "搜索人数" },
    { key: "schCntPop", label: "搜索人数环比", kind: "percent" },
    { key: "alipayAmt", label: "成交金额" },
    { key: "alipayAmtPop", label: "成交金额环比", kind: "percent" },
    { key: "alipayAmtRank", label: "成交金额排名" },
    { key: "alipayAmtRankPop", label: "成交金额排名环比", kind: "percent" },
    { key: "alipayCnt", label: "成交人数" },
    { key: "alipayCntPop", label: "成交人数环比", kind: "percent" },
    { key: "newCustCnt", label: "新客成交人数" },
    { key: "newCustCntPop", label: "新客成交人数环比", kind: "percent" },
    { key: "saleCnt", label: "动销商品数" },
    { key: "saleCntPop", label: "动销商品数环比", kind: "percent" },
    { key: "concentration", label: "市场集中度", kind: "percent" },
    { key: "concentrationJudge", label: "市场集中度分类" },
    { key: "dtcRatio", label: "直销占比", kind: "percent" },
    { key: "dtcRatioJudge", label: "直销占比分类" }
  ]);
  const CROWD_DIMENSION_LABELS = Object.freeze({
    gender: "性别", age: "年龄", city_level: "城市等级", pp_level: "消费力"
  });
  const STRUCTURE_METRIC_DEFS = Object.freeze([
    { key: "costZb", label: "消耗占比", kind: "percent" },
    { key: "clk", label: "点击量" },
    { key: "clkPop", label: "点击量环比", kind: "percent" },
    { key: "ctr", label: "点击率", kind: "percent" },
    { key: "ctrPop", label: "点击率环比", kind: "percent" },
    { key: "cvr", label: "支付转化率", kind: "percent" },
    { key: "cvrPop", label: "支付转化率环比", kind: "percent" },
    { key: "roi", label: "ROI" },
    { key: "roiPop", label: "ROI环比", kind: "percent" }
  ]);

  function opportunityPeriod(dataset, view) {
    const periods = Array.isArray(trackSnapshot(dataset)?.opportunities) ? trackSnapshot(dataset).opportunities : [];
    if (!view?.current) return null;
    return periods.find(period => trackPeriodKey(period) === trackPeriodKey(view.current))
      || periods.find(period => String(period?.periodType || "") === String(view.current.periodType || "")
        && String(period?.date || "") === String(view.current.date || ""))
      || null;
  }

  function opportunityCoordinates(track) {
    const source = Array.isArray(track?.coordinates)
      ? track.coordinates
      : track?.coordinates && typeof track.coordinates === "object"
        ? [track.coordinates]
        : track && ["propertyId", "propertyName", "propertyValueName", "priceRange"].some(key => hasValue(track[key]))
          ? [track]
          : [];
    return source.filter(value => value && typeof value === "object" && !Array.isArray(value)).map(value => ({
      propertyId: String(value.propertyId ?? "").trim(),
      propertyName: String(value.propertyName ?? value.property ?? "").trim(),
      propertyValueName: String(value.propertyValueName ?? value.propertyValue ?? value.valueName ?? "").trim(),
      priceRange: String(value.priceRange ?? value.priceBand ?? "").trim()
    }));
  }

  function coordinateMatchesProperty(coordinate, property) {
    if (!coordinate || !property) return false;
    const idMatches = coordinate.propertyId && String(coordinate.propertyId) === String(property.propertyId);
    const nameMatches = coordinate.propertyName && String(coordinate.propertyName) === String(property.propertyName);
    return Boolean(idMatches || nameMatches);
  }

  function opportunityTrackCoordinates(track, property) {
    const coordinates = opportunityCoordinates(track);
    if (!coordinates.length) return [];
    return coordinates.filter(coordinate => coordinateMatchesProperty(coordinate, property));
  }

  function opportunityTrackBelongsToProperty(track, property) {
    const coordinates = opportunityCoordinates(track);
    return !coordinates.length || coordinates.some(coordinate => coordinateMatchesProperty(coordinate, property));
  }

  function uniqueOpportunityValues(values) {
    return [...new Set(values.map(value => String(value || "").trim()).filter(Boolean))];
  }

  function displayPriceBand(value) {
    const text = String(value || "").trim();
    return /以上$/.test(text) ? `≥${text.replace(/以上$/, "")}` : text || "—";
  }

  function opportunityCoordinateCells(track, property) {
    const coordinates = opportunityTrackCoordinates(track, property);
    return {
      propertyName: uniqueOpportunityValues(coordinates.map(value => value.propertyName)).join("、") || "—",
      propertyValueName: uniqueOpportunityValues(coordinates.map(value => value.propertyValueName)).join("、") || "—",
      priceRange: uniqueOpportunityValues(coordinates.map(value => value.priceRange)).map(displayPriceBand).join("、") || "—"
    };
  }

  function opportunityPrimitive(value) {
    if (!hasValue(value) || (typeof value === "number" && !Number.isFinite(value))) return "—";
    if (["string", "number", "boolean"].includes(typeof value)) return String(value);
    return "—";
  }

  function opportunityPercent(value) {
    if (!hasValue(value)) return "—";
    if (typeof value === "string") return /%/.test(value) ? value : opportunityPrimitive(value);
    if (typeof value !== "number" || !Number.isFinite(value)) return "—";
    const percent = Math.abs(value) <= 1 ? value * 100 : value;
    const rounded = Math.round(percent * 100) / 100;
    return `${rounded}%`;
  }

  function opportunityMetricValue(value, definition) {
    return definition?.kind === "percent" ? opportunityPercent(value) : opportunityPrimitive(value);
  }

  function opportunityCollected(track) {
    if (!track || !Object.prototype.hasOwnProperty.call(track, "collected") || track.collected == null) return "—";
    if (track.collected === true || track.collected === 1 || track.collected === "1") return "已关注";
    if (track.collected === false || track.collected === 0 || track.collected === "0") return "未关注";
    return opportunityPrimitive(track.collected);
  }

  function normalizedOpportunityGroups(period) {
    if (!period || !Array.isArray(period.chanceGroups)) return [];
    return period.chanceGroups.filter(group => group && typeof group === "object" && !Array.isArray(group)).map(group => {
      const sourceTracks = Array.isArray(group.tracks) ? group.tracks : [];
      const seen = new Set();
      const tracks = sourceTracks.filter(track => {
        if (!track || typeof track !== "object" || Array.isArray(track)) return false;
        const key = String(track.trackId || "").trim() || `${String(track.trackName || "").trim()}|${JSON.stringify(opportunityCoordinates(track))}`;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });
      const chance = tracks.find(track => track?.detail?.chance)?.detail?.chance || {};
      return {
        title: String(group.title ?? chance.title ?? "机会分组").trim() || "机会分组",
        tag: String(group.tag ?? chance.tag ?? "").trim(),
        description: String(group.description ?? chance.description ?? "").trim(),
        tracks
      };
    });
  }

  function opportunityGroups(dataset, view) {
    const period = opportunityPeriod(dataset, view);
    const groups = normalizedOpportunityGroups(period).map(group => ({
      ...group,
      tracks: group.tracks.filter(track => opportunityTrackBelongsToProperty(track, view.property))
    }));
    return { period, groups };
  }

  function opportunityOverallRows(detail) {
    const track = detail?.track && typeof detail.track === "object" ? detail.track : {};
    const shop = detail?.shop && typeof detail.shop === "object" ? detail.shop : {};
    return OPPORTUNITY_METRIC_DEFS.filter(definition => hasValue(track[definition.key]) || hasValue(shop[definition.key])).map(definition => ({
      label: definition.label,
      track: opportunityMetricValue(track[definition.key], definition),
      shop: opportunityMetricValue(shop[definition.key], definition)
    }));
  }

  function crowdFieldLabel(value) {
    const labels = {
      name: "特征", label: "特征", title: "特征", feature: "特征", value: "数值", data: "数值",
      ratio: "占比", rate: "占比", percent: "占比", proportion: "占比", index: "指数", count: "人数"
    };
    return labels[String(value || "")] || "数值";
  }

  function crowdInsightEntries(value) {
    if (!hasValue(value)) return [];
    if (["string", "number", "boolean"].includes(typeof value)) return [{ feature: "特征", value: opportunityPrimitive(value) }];
    if (Array.isArray(value)) return value.flatMap((entry, index) => {
      if (["string", "number", "boolean"].includes(typeof entry)) return [{ feature: `特征${index + 1}`, value: opportunityPrimitive(entry) }];
      if (!entry || typeof entry !== "object" || Array.isArray(entry)) return [];
      const titleKey = ["name", "label", "title", "feature"].find(key => hasValue(entry[key]));
      const valueKey = ["value", "data", "ratio", "rate", "percent", "proportion", "index", "count"].find(key => hasValue(entry[key]));
      if (titleKey && valueKey) return [{ feature: opportunityPrimitive(entry[titleKey]), value: opportunityPrimitive(entry[valueKey]) }];
      return Object.entries(entry).filter(([, item]) => ["string", "number", "boolean"].includes(typeof item))
        .map(([key, item]) => ({ feature: crowdFieldLabel(key), value: opportunityPrimitive(item) }));
    });
    if (typeof value === "object") return Object.entries(value)
      .filter(([, item]) => ["string", "number", "boolean"].includes(typeof item))
      .map(([key, item]) => ({ feature: crowdFieldLabel(key), value: opportunityPrimitive(item) }));
    return [];
  }

  function opportunityCrowdRows(detail) {
    const crowd = detail?.crowd && typeof detail.crowd === "object" ? detail.crowd : {};
    return Object.entries(CROWD_DIMENSION_LABELS).flatMap(([key, label]) => {
      const source = crowd[key];
      const insight = source && typeof source === "object" && !Array.isArray(source) && Object.prototype.hasOwnProperty.call(source, "dataInsight")
        ? source.dataInsight
        : source;
      return crowdInsightEntries(insight).map(entry => ({ dimension: label, ...entry }));
    });
  }

  function opportunityStructureRows(detail) {
    const structure = detail?.structure && typeof detail.structure === "object" ? detail.structure : {};
    return [["赛道整体", structure.track], ["本店表现", structure.shop]].flatMap(([scope, rows]) => (Array.isArray(rows) ? rows : [])
      .filter(row => row && typeof row === "object" && !Array.isArray(row))
      .map(row => ({
        scope,
        scene: opportunityPrimitive(row.marketSceneName),
        values: STRUCTURE_METRIC_DEFS.map(definition => opportunityMetricValue(row[definition.key], definition))
      })));
  }

  function renderOpportunityDetail(track) {
    const overallRows = opportunityOverallRows(track?.detail);
    const crowdRows = opportunityCrowdRows(track?.detail);
    const structureRows = opportunityStructureRows(track?.detail);
    if (!overallRows.length && !crowdRows.length && !structureRows.length) return "";
    const overall = overallRows.length ? `<article class="opportunity-subtable"><h4>赛道整体 vs 本店表现</h4><div class="table-wrap"><table><thead><tr><th>指标</th><th>赛道整体</th><th>本店表现</th></tr></thead><tbody>${overallRows.map(row => `<tr><td>${escapeHtml(row.label)}</td><td class="number-cell">${escapeHtml(row.track)}</td><td class="number-cell">${escapeHtml(row.shop)}</td></tr>`).join("")}</tbody></table></div></article>` : "";
    const crowd = crowdRows.length ? `<article class="opportunity-subtable"><h4>人群特征</h4><div class="table-wrap"><table><thead><tr><th>人群维度</th><th>特征</th><th>数值</th></tr></thead><tbody>${crowdRows.map(row => `<tr><td>${escapeHtml(row.dimension)}</td><td>${escapeHtml(row.feature)}</td><td>${escapeHtml(row.value)}</td></tr>`).join("")}</tbody></table></div></article>` : "";
    const structure = structureRows.length ? `<article class="opportunity-subtable is-wide"><h4>投放结构</h4><div class="table-wrap"><table><thead><tr><th>口径</th><th>推广场景</th>${STRUCTURE_METRIC_DEFS.map(definition => `<th>${escapeHtml(definition.label)}</th>`).join("")}</tr></thead><tbody>${structureRows.map(row => `<tr><td>${escapeHtml(row.scope)}</td><td>${escapeHtml(row.scene)}</td>${row.values.map(value => `<td class="number-cell">${escapeHtml(value)}</td>`).join("")}</tr>`).join("")}</tbody></table></div></article>` : "";
    return `<details class="opportunity-detail"><summary>${escapeHtml(opportunityPrimitive(track?.trackName))}详情</summary><div class="opportunity-detail-grid">${overall}${crowd}${structure}</div></details>`;
  }

  function renderTrackOpportunitySection(dataset, options, index) {
    const view = trackView(dataset, options);
    const unavailable = detail => `<section class="section opportunity-section" id="opportunities"><div class="section-title"><div><span class="section-index">${String(index).padStart(2, "0")}</span><h2>货品增长机会</h2></div><span>部分数据</span></div><p class="opportunity-empty"><strong>货品增长机会待补采</strong><br/>${escapeHtml(detail)}；已返回数据仍可查看，缺失值未按 0 处理。</p></section>`;
    if (!view?.current) return unavailable("价格带属性矩阵尚未完成");
    const { period, groups } = opportunityGroups(dataset, view);
    if (!period || !groups.length) return unavailable("当前周期的机会分类或赛道明细尚未完整返回");
    const cards = groups.map(group => `<article class="chance-card"><div><h3>${escapeHtml(group.title)}</h3><span>${escapeHtml(group.tag || "—")}</span></div><p>${escapeHtml(group.description || "—")}</p><strong>${group.tracks.length} 条赛道</strong></article>`).join("");
    const groupMarkup = groups.map(group => {
      const rows = group.tracks.map(track => {
        const coordinates = opportunityCoordinateCells(track, view.property);
        return `<tr><td><strong>${escapeHtml(opportunityPrimitive(track.trackName))}</strong></td><td>${escapeHtml(coordinates.propertyName)}</td><td>${escapeHtml(coordinates.propertyValueName)}</td><td>${escapeHtml(coordinates.priceRange)}</td><td class="number-cell">${escapeHtml(Number.isFinite(track.dScore) ? trackScoreText(track.dScore) : "—")}</td><td class="number-cell">${escapeHtml(opportunityPrimitive(track.shopAlipayRank))}</td><td>${escapeHtml(opportunityCollected(track))}</td></tr>`;
      }).join("");
      const list = group.tracks.length
        ? `<div class="table-wrap opportunity-track-table"><table><thead><tr><th>赛道名称</th><th>属性维度</th><th>属性值</th><th>价格带</th><th>综合潜力指数</th><th>本店成交排名</th><th>关注状态</th></tr></thead><tbody>${rows}</tbody></table></div>`
        : `<p class="opportunity-empty">当前属性维度暂无赛道</p>`;
      const details = group.tracks.map(renderOpportunityDetail).filter(Boolean).join("");
      return `<article class="chance-group"><header><div><h3>${escapeHtml(group.title)}</h3><span>${escapeHtml(group.tag || "—")}</span></div><strong>${group.tracks.length} 条赛道</strong></header><p>${escapeHtml(group.description || "—")}</p>${list}${details}</article>`;
    }).join("");
    return `<section class="section opportunity-section" id="opportunities"><div class="section-title"><div><span class="section-index">${String(index).padStart(2, "0")}</span><h2>货品增长机会</h2></div><span>${escapeHtml(view.property.propertyName)} · ${escapeHtml(trackPeriodLabel(period))}</span></div><div class="chance-card-grid">${cards}</div><div class="chance-group-list">${groupMarkup}</div></section>`;
  }

  function archiveTablesFromAtomicGroups(name, columns, atomicGroups) {
    const chunks = [];
    let current = [];
    const flush = () => {
      if (current.length) chunks.push(current);
      current = [];
    };
    for (const atomicGroup of atomicGroups) {
      const rows = Array.isArray(atomicGroup) ? atomicGroup : [];
      if (!rows.length) continue;
      if (rows.length > TRACK_ARCHIVE_MAX_ROWS) {
        throw new Error(`${name}单个周期或赛道原子组超过归档上限`);
      }
      if (current.length + rows.length > TRACK_ARCHIVE_MAX_ROWS) flush();
      current.push(...rows);
    }
    flush();
    if (!chunks.length) return [{ name, columns: [...columns], rows: [] }];
    return chunks.map((rows, index) => ({
      name: chunks.length === 1 ? name : `${name}-分片${String(index + 1).padStart(2, "0")}`,
      columns: [...columns],
      rows
    }));
  }

  function buildTrackOpportunityArchiveTables(dataset) {
    const snapshot = trackSnapshot(dataset);
    const periods = [...(Array.isArray(snapshot?.opportunities) ? snapshot.opportunities : [])]
      .filter(period => period && typeof period === "object" && Array.isArray(period.chanceGroups))
      .sort((left, right) => String(right.endDate || right.date || "").localeCompare(String(left.endDate || left.date || ""))
        || String(right.startDate || "").localeCompare(String(left.startDate || "")));
    if (!periods.length) return [];

    const knownProperties = (snapshot?.properties || []).filter(property => property
      && String(property.propertyId || "").trim()
      && String(property.propertyName || "").trim()).map(property => ({
        propertyId: String(property.propertyId),
        propertyName: String(property.propertyName)
      }));
    const overviewAtoms = [];
    const opportunityAtoms = [];
    const overallAtoms = [];
    const crowdAtoms = [];
    const structureAtoms = [];
    const periodCells = period => [
      trackPeriodLabel(period),
      opportunityPrimitive(period.startDate),
      opportunityPrimitive(period.endDate)
    ];
    const coordinateGroups = track => {
      const groups = new Map();
      for (const coordinate of opportunityCoordinates(track)) {
        const propertyId = String(coordinate.propertyId || "");
        const propertyName = String(coordinate.propertyName || "");
        const key = propertyId || propertyName || "—";
        if (!groups.has(key)) groups.set(key, { propertyId, propertyName, coordinates: [] });
        groups.get(key).coordinates.push(coordinate);
      }
      if (!groups.size) groups.set("—", { propertyId: "", propertyName: "", coordinates: [] });
      return [...groups.values()];
    };
    const coordinateCells = group => ({
      propertyName: group.propertyName || knownProperties.find(property => property.propertyId === group.propertyId)?.propertyName || "—",
      propertyValueName: uniqueOpportunityValues(group.coordinates.map(value => value.propertyValueName)).join("、") || "—",
      priceRange: uniqueOpportunityValues(group.coordinates.map(value => value.priceRange)).map(displayPriceBand).join("、") || "—"
    });

    for (const period of periods) {
      const prefix = periodCells(period);
      const groups = normalizedOpportunityGroups(period);
      const propertyContexts = [...knownProperties];
      for (const group of groups) {
        for (const track of group.tracks) {
          for (const coordinate of opportunityCoordinates(track)) {
            if (propertyContexts.some(property => coordinateMatchesProperty(coordinate, property))) continue;
            const propertyId = String(coordinate.propertyId || "");
            const propertyName = String(coordinate.propertyName || "");
            if (propertyId || propertyName) propertyContexts.push({ propertyId, propertyName });
          }
        }
      }
      if (!propertyContexts.length) propertyContexts.push({ propertyId: "", propertyName: "" });

      if (!groups.length) {
        overviewAtoms.push(propertyContexts.map(property => ({ cells: [
          ...prefix, property.propertyName || "—", "—", "—", "—", 0
        ] })));
      }
      for (const group of groups) {
        const groupOverviewRows = [];
        for (const property of propertyContexts) {
          const count = group.tracks.filter(track => opportunityCoordinates(track)
            .some(coordinate => coordinateMatchesProperty(coordinate, property))).length;
          groupOverviewRows.push({ cells: [
            ...prefix, property.propertyName || "—", group.title, group.tag || "—", group.description || "—", count
          ] });
        }
        const unassignedCount = group.tracks.filter(track => !opportunityCoordinates(track).length).length;
        if (unassignedCount) groupOverviewRows.push({ cells: [
          ...prefix, "—", group.title, group.tag || "—", group.description || "—", unassignedCount
        ] });
        overviewAtoms.push(groupOverviewRows);

        for (const track of group.tracks) {
          const trackOpportunityRows = [];
          const trackOverallRows = [];
          const trackCrowdRows = [];
          const trackStructureRows = [];
          for (const coordinateGroup of coordinateGroups(track)) {
            const coordinates = coordinateCells(coordinateGroup);
            const common = [
              ...prefix, group.title, opportunityPrimitive(track.trackName), coordinates.propertyName,
              coordinates.propertyValueName, coordinates.priceRange
            ];
            trackOpportunityRows.push({ cells: [
              ...prefix, group.title, group.tag || "—", group.description || "—", opportunityPrimitive(track.trackName),
              coordinates.propertyName, coordinates.propertyValueName, coordinates.priceRange,
              Number.isFinite(track.dScore) ? trackScoreText(track.dScore) : "—",
              opportunityPrimitive(track.shopAlipayRank), opportunityCollected(track)
            ] });
            for (const row of opportunityOverallRows(track.detail)) trackOverallRows.push({ cells: [
              ...common, row.label, row.track, row.shop
            ] });
            for (const row of opportunityCrowdRows(track.detail)) trackCrowdRows.push({ cells: [
              ...common, row.dimension, row.feature, row.value
            ] });
            for (const row of opportunityStructureRows(track.detail)) trackStructureRows.push({ cells: [
              ...common, row.scope, row.scene, ...row.values
            ] });
          }
          opportunityAtoms.push(trackOpportunityRows);
          overallAtoms.push(trackOverallRows);
          crowdAtoms.push(trackCrowdRows);
          structureAtoms.push(trackStructureRows);
        }
      }
    }

    const definitions = [
      ["货品增长机会概览", ["周期", "周期开始", "周期结束", "属性维度", "机会类型", "机会标签", "机会说明", "赛道数量"], overviewAtoms],
      ["货品增长机会", ["周期", "周期开始", "周期结束", "机会类型", "机会标签", "机会说明", "赛道名称", "属性维度", "属性值", "价格带", "综合潜力指数", "本店成交排名", "关注状态"], opportunityAtoms],
      ["赛道整体与本店", ["周期", "周期开始", "周期结束", "机会类型", "赛道名称", "属性维度", "属性值", "价格带", "指标", "赛道整体", "本店表现"], overallAtoms],
      ["赛道人群", ["周期", "周期开始", "周期结束", "机会类型", "赛道名称", "属性维度", "属性值", "价格带", "人群维度", "特征", "数值"], crowdAtoms],
      ["赛道投放结构", ["周期", "周期开始", "周期结束", "机会类型", "赛道名称", "属性维度", "属性值", "价格带", "口径", "推广场景", ...STRUCTURE_METRIC_DEFS.map(definition => definition.label)], structureAtoms]
    ];
    return definitions.flatMap(([name, columns, atoms]) => archiveTablesFromAtomicGroups(name, columns, atoms));
  }

  function buildArchiveReport(dataset) {
    const model = buildBusinessModel(dataset);
    const { categoryPath, categoryName, categoryDisplayName } = resolveCategoryIdentity(dataset,
      { requireChinesePath: true });
    const catalog = buildPeriodCatalog(model);
    const defaultView = resolveReportView(model, { periodMode: catalog.defaultMode });
    const moduleTables = MODULES.map(module => {
      const keys = module.keys.filter(key => defaultView.summaryMetrics[key]?.current);
      if (!keys.length) return null;
      return {
        name: module.title,
        columns: ["指标", defaultView.valueLabel, defaultView.compareValueLabel, "环比"],
        rows: keys.map(key => {
          const field = FIELD_BY_KEY[key];
          const metric = defaultView.summaryMetrics[key];
          return { cells: [
            field.label,
            formatParsed(field, metric.current),
            formatParsed(field, metric.compare),
            formatChange(resolvedMetricChange(metric))
          ] };
        })
      };
    }).filter(Boolean);
    const periodTable = (mode, name) => {
      const views = (catalog[mode] || []).map(choice => {
        const view = resolveReportView(model, { periodMode: mode, periodKey: choice.key });
        return { choice, view };
      });
      const fields = FIELD_DEFS.filter(field => views.some(({ view }) => view.summaryMetrics[field.key]?.current));
      if (!views.length || !fields.length) return null;
      return {
        name,
        columns: [mode === "natural-day" ? "日期" : "周期", ...fields.map(field => field.label)],
        rows: views.map(({ view }) => ({ cells: [view.periodLabel,
          ...fields.map(field => formatParsed(field, view.summaryMetrics[field.key]?.current))] }))
      };
    };
    const comparison = buildPeriodComparison(defaultView);
    const comparisonTable = comparison.keys.length ? {
      name: "类目周期环比",
      columns: ["指标", ...comparison.periods.map(period => period.label), "环比"],
      rows: comparison.keys.map(key => {
        const field = FIELD_BY_KEY[key];
        return { cells: [
          field.label,
          ...comparison.periods.map(period => formatParsed(field, period.metrics[key])),
          formatChange(comparison.changes[key])
        ] };
      })
    } : null;
    const historicalPeriods = buildHistoricalPeriods(dataset);
    const historicalColumns = historicalPeriods.flatMap(period => [
      { label: period.periodLabel, metrics: comparisonMetricSet(period.metrics) },
      { label: period.compareLabel, metrics: comparisonMetricSet(period.metrics, "compare") }
    ]);
    const historicalKeys = FIELD_DEFS.filter(field => historicalColumns.some(column => column.metrics[field.key])).map(field => field.key);
    const historicalTable = historicalColumns.length && historicalKeys.length ? {
      name: "类目历史周期",
      columns: ["指标", ...historicalColumns.map(column => column.label)],
      rows: historicalKeys.map(key => {
        const field = FIELD_BY_KEY[key];
        return { cells: [field.label, ...historicalColumns.map(column => formatParsed(field, column.metrics[key]))] };
      })
    } : null;
    const report = {
      schema_version: "3.0",
      report_type: "market",
      title: "少壮AI自动化报告",
      // market 类型中 item_id 是官网现有归档主键的兼容位，语义仍由 market_scope 明确为类目，不是商品。
      item_id: String(dataset.cateId || ""),
      period: defaultView.periodLabel,
      market_scope: {
        version: "1",
        category_id: String(dataset.cateId || ""),
        category_name: categoryName,
        category_path: categoryPath,
        category_display_name: categoryDisplayName
      },
      tables: [
        {
          name: "报告总览",
          columns: ["项目", "内容"],
          rows: [
            { cells: ["当前类目", categoryDisplayName] },
            { cells: ["业务周期", defaultView.periodLabel] }
          ]
        },
        ...moduleTables,
        buildTrackStatusTable(dataset),
        ...buildTrackArchiveTables(dataset),
        ...buildTrackOpportunityArchiveTables(dataset),
        ...(comparisonTable ? [comparisonTable] : []),
        ...(historicalTable ? [historicalTable] : []),
        periodTable("natural-day", "自然日汇总"),
        periodTable("natural-week", "自然周汇总"),
        periodTable("natural-month", "自然月汇总")
      ].filter(Boolean)
    };
    assertSensitiveFree(report);
    return report;
  }

  function buildHtml(dataset, options = {}) {
    const model = resolveReportView(buildBusinessModel(dataset), options);
    const comparison = buildPeriodComparison(model);
    const availableModules = MODULES.filter(module => module.keys.some(key => metricHasData(model, key)));
    const overviewKeys = OVERVIEW_KEYS.filter(key => metricHasData(model, key));
    const coreKeys = CORE_KPI_KEYS.filter(key => overviewKeys.includes(key));
    const visibleCoreKeys = coreKeys.length ? coreKeys : overviewKeys.slice(0, 4);
    let sectionIndex = 1;
    const overviewMarkup = visibleCoreKeys.length
      ? `<section class="section" id="overview"><div class="section-title"><div><span class="section-index">${String(sectionIndex++).padStart(2, "0")}</span><h2>类目核心指标</h2></div><span>${escapeHtml(model.periodLabel)}</span></div><div class="core-kpi-grid">${visibleCoreKeys.map(key => metricCard(model, key)).join("")}</div></section>`
      : "";
    const historicalMarkup = renderPeriodComparison(comparison, sectionIndex);
    if (historicalMarkup) sectionIndex += 1;
    const distributionMarkup = renderBusinessDistribution(model, availableModules, sectionIndex++);
    const hasSelectedBusinessData = Boolean(overviewMarkup || distributionMarkup);
    const shouldRenderTrackStatus = Boolean(trackSnapshot(dataset) || hasSelectedBusinessData);
    const trackMarkup = shouldRenderTrackStatus ? renderTrackSection(dataset, options, sectionIndex) : "";
    if (trackMarkup) sectionIndex += 1;
    const opportunityMarkup = shouldRenderTrackStatus ? renderTrackOpportunitySection(dataset, options, sectionIndex) : "";
    if (opportunityMarkup) sectionIndex += 1;
    const trendMarkup = renderTrends(model, sectionIndex++);
    const detailsMarkup = model.periodMode === "natural-month" ? "" : renderDetails(model, sectionIndex++);
    const emptyMarkup = !overviewMarkup && !distributionMarkup && !trackMarkup && !opportunityMarkup && !trendMarkup && !detailsMarkup
      ? `<section class="empty-state" role="status"><strong>暂无类目大盘数据</strong><span>${escapeHtml(model.periodLabel)} 没有可展示的达摩盘类目数据</span></section>`
      : "";
    const navItems = [];
    if (overviewMarkup) navItems.push(["overview", "类目核心"]);
    if (historicalMarkup) navItems.push(["history", "周期环比"]);
    if (distributionMarkup) navItems.push(["distribution", "经营概览"]);
    if (trackMarkup) navItems.push(["tracks", "细分赛道"]);
    if (opportunityMarkup) navItems.push(["opportunities", "货品机会"]);
    if (trendMarkup) navItems.push(["trends", "类目趋势"]);
    if (detailsMarkup) navItems.push(["details", "每日数据"]);
    const title = "少壮AI自动化报告";
    const { categoryDisplayName } = resolveCategoryIdentity(dataset);
    const semanticTitle = `${categoryDisplayName}｜类目大盘报告`;
    const modes = [
      ["all-collected", "全部已采周期"],
      ["analysis-range", "当前区间"],
      ["custom-range", "自定义区间"],
      ["natural-day", "自然日"],
      ["natural-week", "自然周"],
      ["natural-month", "自然月"]
    ];
    const modeOptions = modes.map(([value, label]) => {
      const disabled = value === "analysis-range" || value === "custom-range" ? false : !model.catalog[value]?.length;
      return `<option value="${value}"${value === model.periodMode ? " selected" : ""}${disabled ? " disabled" : ""}>${label}${disabled ? "（暂无完整周期）" : ""}</option>`;
    }).join("");
    const periodOptions = model.periodChoices.map(choice => `<option value="${escapeHtml(choice.key)}"${choice.key === model.periodKey ? " selected" : ""}>${escapeHtml(choice.label)}</option>`).join("");
    const periodSelection = model.periodMode === "custom-range"
      ? `<label class="period-control"><span>开始日期</span><input type="date" min="${escapeHtml(model.availableStartDate)}" max="${escapeHtml(model.availableEndDate)}" value="${escapeHtml(model.periodStartDate)}" data-custom-start></label><label class="period-control"><span>结束日期</span><input type="date" min="${escapeHtml(model.availableStartDate)}" max="${escapeHtml(model.availableEndDate)}" value="${escapeHtml(model.periodEndDate)}" data-custom-end></label><div class="period-control custom-range-action"><span>自动对比上一周期</span><button type="button" data-custom-range-apply>应用时间</button></div>`
      : `<label class="period-control"><span>选择周期</span><select data-period-key>${periodOptions}</select></label>`;
    return `<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light">
<title>${escapeHtml(semanticTitle)}</title><meta name="application-name" content="${escapeHtml(title)}"><style>
:root{color-scheme:light;--green:#0d6f66;--green2:#14877a;--green3:#e8f5f2;--navy:#07514c;--ink:#17313a;--muted:#678087;--line:#d5e3e0;--soft:#f5f8f8;--paper:#fff;--up:#df5738;--down:#1f934c;--orange:#d8872f;--blue:#3d72db;--table-body:#edf5f3}
*{box-sizing:border-box}html{scroll-behavior:smooth;background:#f3f6f6}body{margin:0;color:var(--ink);background:#f3f6f6;font:14px/1.5 -apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;font-variant-numeric:tabular-nums}
.report-watermark{position:fixed;inset:-16vh -12vw;z-index:2147483646;display:grid;grid-template-columns:repeat(6,minmax(220px,1fr));grid-auto-rows:150px;align-content:center;overflow:hidden;pointer-events:none;transform:rotate(-19deg) scale(1.08);transform-origin:center;opacity:.075}.report-watermark span{display:grid;place-items:center;color:#0b625d;font-size:17px;font-weight:800;letter-spacing:.04em;white-space:nowrap;user-select:none;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.hero,.nav,.report{position:relative;z-index:1}.hero{display:flex;align-items:center;justify-content:space-between;gap:24px;min-height:68px;padding:12px max(24px,calc((100vw - 1660px)/2));color:#fff;background:linear-gradient(105deg,#0b5b55,#11957f)}.brand-lockup{display:flex;align-items:center;gap:12px;min-width:0}.brand-mark{display:grid;place-items:center;width:38px;height:38px;border-radius:9px;background:#fff;color:var(--green);font-size:19px;font-weight:900}.hero .eyebrow{margin:0;color:#d1f0ea;font-size:11px;letter-spacing:.12em;font-weight:800}.hero h1{overflow:hidden;margin:1px 0 0;font-size:19px;line-height:1.2;text-overflow:ellipsis;white-space:nowrap}.hero-actions{display:flex;align-items:center;gap:9px}.hero-period{padding:7px 11px;border:1px solid rgba(255,255,255,.32);border-radius:7px;background:rgba(255,255,255,.1);font-size:12px;white-space:nowrap}
.nav{display:flex;align-items:center;gap:5px;padding:5px max(24px,calc((100vw - 1660px)/2));border-bottom:1px solid var(--line);background:rgba(255,255,255,.97);position:sticky;top:0;z-index:20}.nav-links{display:flex;gap:3px;overflow:auto}.nav a{padding:7px 10px;color:#365d64;text-decoration:none;white-space:nowrap;border-radius:5px}.nav a:hover{background:var(--green3);color:var(--green)}button{padding:8px 14px;border:0;border-radius:7px;color:var(--green);background:#fff;font-weight:800;cursor:pointer;box-shadow:0 0 0 1px var(--line);white-space:nowrap}
.report{max-width:1660px;margin:14px auto;padding:0 16px 44px}.market-toolbar{display:grid;grid-template-columns:minmax(300px,1fr) minmax(430px,1.4fr);align-items:center;gap:14px;margin-bottom:12px;padding:12px 14px;border:1px solid var(--line);border-radius:8px;background:rgba(255,255,255,.97);box-shadow:0 5px 18px rgba(20,70,66,.05)}.category-identity{display:grid;grid-template-columns:auto minmax(0,1fr);align-items:center;gap:10px;min-width:0}.category-identity>span{display:grid;place-items:center;width:34px;height:34px;border-radius:7px;color:#fff;background:var(--green);font-weight:900}.category-identity>div{display:grid;min-width:0}.category-identity small{color:var(--muted);font-size:10px}.category-identity strong{overflow:hidden;font-size:15px;text-overflow:ellipsis;white-space:nowrap}
.period-controls{display:flex;align-items:end;gap:9px;min-width:0}.period-control{display:grid;gap:4px;min-width:0;flex:1}.period-control span{color:var(--muted);font-size:11px}.period-control select,.period-control input{width:100%;height:36px;padding:0 10px;border:1px solid #b9d2cd;border-radius:6px;color:var(--ink);background:#fff;font:inherit;font-weight:700}.period-control select{padding-right:32px}.custom-range-action{flex:.8}.custom-range-action button{height:36px;color:#fff;background:var(--green);box-shadow:none}
.section{overflow:hidden;margin-bottom:14px;scroll-margin-top:52px;border:1px solid var(--line);border-radius:8px;background:rgba(255,255,255,.97);box-shadow:0 7px 22px rgba(20,70,66,.05)}.section-title{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:11px 14px;border-bottom:1px solid var(--line)}.section-title>div{display:flex;align-items:center;gap:9px}.section-title h2{margin:0;font-size:17px}.section-title>span{color:var(--muted);font-size:12px;text-align:right}.section-index{display:grid;place-items:center;min-width:29px;height:25px;padding:0 6px;border-radius:5px;background:var(--green);color:#fff;font-size:12px;font-weight:800}
.empty-state{display:grid;place-items:center;gap:5px;min-height:150px;padding:28px;border:1px dashed #a9c9c3;border-radius:8px;color:var(--muted);background:rgba(255,255,255,.94);text-align:center}.empty-state strong{color:var(--ink);font-size:17px}
.core-kpi-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));border-top:4px solid var(--blue)}.metric-card{min-width:0;padding:14px 16px 12px;border-right:1px solid var(--line);background:linear-gradient(145deg,#fff,#f2f8f6)}.metric-card:last-child{border-right:0}.metric-head{display:flex;justify-content:space-between;gap:8px;color:var(--muted)}.metric-head em{font-style:normal;font-size:11px}.metric-value{display:block;margin:8px 0 12px;font-size:28px;line-height:1.18;text-align:right}.kpi-comparison-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:5px}.kpi-comparison-grid.has-yoy{grid-template-columns:repeat(3,minmax(0,1fr))}.kpi-comparison-grid>span{display:grid;gap:2px;min-width:0;padding-top:6px;border-top:1px solid var(--line);color:var(--muted)}.kpi-comparison-grid small{font-size:10px}.kpi-comparison-grid b{overflow:hidden;color:var(--ink);font-size:12px;text-align:right;text-overflow:ellipsis;white-space:nowrap}.is-up,.is-up b{color:var(--up)!important}.is-down,.is-down b{color:var(--down)!important}.is-flat{color:var(--muted)!important}.change-value{display:inline-flex;align-items:center;justify-content:flex-end;gap:3px;min-width:0;font-weight:800;white-space:nowrap}.change-value i{font-style:normal}.change-value.is-missing{color:var(--muted);font-weight:600}
.period-comparison-wrap{overflow:auto;border-top:4px solid var(--blue);background:var(--soft)}.period-comparison-table{width:100%;min-width:760px;border-collapse:separate;border-spacing:0}.period-comparison-table th,.period-comparison-table td{padding:8px 12px;border-right:1px solid var(--line);border-bottom:1px solid var(--line);vertical-align:middle}.period-comparison-table thead th{position:sticky;top:0;z-index:3;color:#fff;background:var(--green);text-align:center}.period-comparison-table .comparison-metric-heading,.period-comparison-table tbody th{left:0;z-index:4;min-width:170px;width:22%;text-align:left}.period-comparison-table tbody th{position:sticky;color:var(--ink);background:#f2f7f6;font-weight:800}.period-comparison-table tbody tr:nth-child(even) th{background:#eaf3f1}.period-comparison-table td{background:var(--table-body)}.period-comparison-table tbody tr:nth-child(even) td{background:var(--table-body)}.period-comparison-table td.is-primary{background:#eef4ff}.comparison-period-heading,.comparison-value-cell{min-width:220px}.comparison-change-heading,.comparison-change-cell{min-width:112px;width:16%}.comparison-value-cell,.comparison-change-cell{text-align:right}.comparison-value-cell strong{color:#155a9a;font-size:14px}.comparison-period-heading strong,.comparison-period-heading small,.comparison-period-heading em{display:block}.comparison-period-heading strong{font-size:14px}.comparison-period-heading small{margin-top:2px;font-size:10px;font-weight:500;opacity:.86}.comparison-period-heading em{width:max-content;margin:4px auto 0;padding:1px 7px;border-radius:999px;color:#174e9a;background:#fff;font-size:10px;font-style:normal}
.business-distribution-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;padding:12px;border-top:4px solid var(--blue);background:var(--soft)}.distribution-module{overflow:hidden;min-width:0;border:1px solid var(--line);border-radius:7px;background:#fff}.distribution-module>header{display:flex;align-items:center;justify-content:space-between;padding:10px 12px;border-bottom:1px solid var(--line)}.distribution-module h3{margin:0;font-size:15px}.distribution-module>header span{color:var(--green);font-size:11px;font-weight:800}.business-metric-header,.business-metric-row{display:grid;grid-template-columns:minmax(128px,1.25fr) repeat(3,minmax(74px,.8fr));align-items:center}.business-metric-header.has-yoy,.business-metric-row.has-yoy{grid-template-columns:minmax(128px,1.25fr) repeat(4,minmax(74px,.8fr))}.business-metric-header{background:var(--green);color:#fff;font-size:11px;font-weight:800}.business-metric-header span{padding:7px 8px;text-align:right}.business-metric-header span:first-child{text-align:left}.business-metric-row{min-height:38px;border-bottom:1px solid var(--line)}.business-metric-row:last-child{border-bottom:0}.business-metric-row:nth-child(even){background:#f7faf9}.business-metric-row>span,.business-metric-row>strong{overflow:hidden;padding:8px;text-align:right;text-overflow:ellipsis;white-space:nowrap}.business-metric-row .business-metric-name{text-align:left}.business-metric-row>strong{color:#155a9a}.distribution-derived{display:flex;flex-wrap:wrap;gap:6px;padding:8px;border-top:1px solid var(--line);background:#fffaf0}.derived-card{display:grid;grid-template-columns:minmax(118px,1fr) minmax(84px,.75fr) minmax(150px,1.25fr);align-items:end;gap:7px;min-width:340px;flex:1;padding:8px 9px;border:1px solid #eadcba;border-radius:5px;background:#fff}.derived-label{align-self:center;color:#79673b;font-weight:700}.derived-current{display:grid;gap:2px;min-width:0;text-align:right}.derived-current small,.derived-compare small{color:var(--muted);font-size:10px}.derived-current strong{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.derived-compare{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}.derived-compare>span{display:grid;gap:2px;min-width:0;text-align:right}.derived-compare b{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ratio-meter{grid-column:1/-1;display:block}.ratio-meter-track{display:block;overflow:hidden;width:100%;height:4px;border-radius:999px;background:#e5ecea}.ratio-meter-fill{display:block;height:100%;border-radius:inherit;background:linear-gradient(90deg,var(--green2),#63b9aa)}
.track-controls{display:grid;grid-template-columns:repeat(4,minmax(150px,1fr));gap:9px;padding:12px 14px;background:var(--soft)}.track-controls label{display:grid;gap:4px}.track-controls label>span{color:var(--muted);font-size:11px}.track-controls select{width:100%;height:36px;padding:0 10px;border:1px solid #b9d2cd;border-radius:6px;color:var(--ink);background:#fff;font:inherit;font-weight:700}.track-legend{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:8px 14px;border-top:1px solid var(--line);color:var(--muted);font-size:11px}.track-legend span:first-child{color:var(--green);font-weight:800}.track-heatmap-wrap{overflow:auto;border-top:4px solid var(--blue);background:#fff}.track-heatmap-table{width:max-content;min-width:100%;border-collapse:separate;border-spacing:0}.track-heatmap-table th,.track-heatmap-table td{min-width:132px;padding:10px 11px;border-right:1px solid var(--line);border-bottom:1px solid var(--line)}.track-heatmap-table thead th{position:sticky;top:0;z-index:3;background:var(--green);color:#fff;text-align:center}.track-heatmap-table thead th:first-child,.track-heatmap-table tbody th{position:sticky;left:0;z-index:4;min-width:116px}.track-heatmap-table tbody th{background:#eef5f3;color:var(--ink);text-align:left}.track-heatmap-table .track-heat-cell{background:rgba(61,114,219,var(--track-heat,0));text-align:center}.track-heatmap-table .track-heat-cell.is-positive{background:rgba(61,114,219,var(--track-heat,0))}.track-heatmap-table .track-heat-cell.is-negative{background:rgba(13,111,102,var(--track-heat,0))}.track-heatmap-table .track-heat-cell.is-zero{background:#f3f6f6}.track-heatmap-table .track-heat-cell.is-missing{background:#fff;color:#8a9a9e}.track-heat-cell strong,.track-heat-cell small{display:block}.track-heat-cell strong{font-size:14px}.track-heat-cell small{margin-top:2px;color:#5f747a;font-size:10px}
.chance-card-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px;padding:12px 14px;background:var(--soft);border-top:4px solid var(--blue)}.chance-card{display:grid;gap:8px;min-width:0;padding:12px;border:1px solid var(--line);border-radius:8px;background:#fff}.chance-card>div,.chance-group>header,.chance-group>header>div{display:flex;align-items:center;gap:8px}.chance-card>div,.chance-group>header{justify-content:space-between}.chance-card h3,.chance-group h3{margin:0;font-size:15px}.chance-card span,.chance-group header span{display:inline-block;padding:2px 7px;border-radius:999px;color:var(--green);background:var(--green3);font-size:10px;font-weight:800;white-space:nowrap}.chance-card p,.chance-group>p{margin:0;color:var(--muted);font-size:12px}.chance-card>strong{color:var(--green);font-size:13px}.chance-group-list{display:grid;gap:12px;padding:14px}.chance-group{overflow:hidden;border:1px solid var(--line);border-radius:9px;background:#fff}.chance-group>header{padding:11px 12px;border-bottom:1px solid var(--line);background:#f8fbfa}.chance-group>header>strong{color:var(--green);font-size:12px}.chance-group>p{padding:8px 12px;border-bottom:1px solid var(--line)}.opportunity-track-table table{min-width:980px}.opportunity-track-table th:first-child,.opportunity-track-table td:first-child{min-width:260px;text-align:left}.opportunity-empty{margin:0;padding:18px 12px!important;color:var(--muted);text-align:center}.opportunity-detail{margin:9px 10px;border:1px solid var(--line);border-radius:7px;background:#fff}.opportunity-detail summary{padding:9px 11px;color:var(--green);font-size:12px;font-weight:800;cursor:pointer;background:var(--soft)}.opportunity-detail-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;padding:10px}.opportunity-subtable{min-width:0;border:1px solid var(--line);border-radius:6px;overflow:hidden}.opportunity-subtable.is-wide{grid-column:1/-1}.opportunity-subtable h4{margin:0;padding:8px 10px;color:var(--green);background:#f8fbfa;font-size:12px}.opportunity-subtable th,.opportunity-subtable td{min-width:105px;padding:7px 8px;font-size:11px}.opportunity-subtable th:first-child,.opportunity-subtable td:first-child{min-width:115px}
.chart-grid-wrap{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;padding:18px}.chart-card{min-width:0;padding:15px;border:1px solid var(--line);border-radius:12px;background:#fbfdfd}.chart-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px}.chart-head h3{margin:0;font-size:17px}.chart-head span{color:var(--muted)}.chart-head>div:last-child{display:grid;gap:2px;color:var(--muted);font-size:12px;text-align:right}.trend-svg{display:block;width:100%;height:auto;margin-top:8px}.chart-grid line{stroke:#dce9e6;stroke-width:1}.chart-grid text{fill:#71888d;font-size:11px;text-anchor:end}.trend-line{fill:none;stroke:var(--green2);stroke-width:3;stroke-linecap:round;stroke-linejoin:round}.chart-point{outline:none;cursor:crosshair}.chart-point-hit{fill:transparent;stroke:transparent;pointer-events:all}.trend-point{fill:var(--green2);stroke:#fff;stroke-width:1.5;pointer-events:none}.trend-last{fill:var(--orange);stroke-width:2}.chart-point:focus .trend-point{stroke:var(--navy);stroke-width:2.5}.chart-tooltip{position:fixed;z-index:2147483647;max-width:min(380px,calc(100vw - 16px));padding:8px 10px;border:1px solid rgba(255,255,255,.22);border-radius:7px;color:#fff;background:#103d46;box-shadow:0 8px 24px rgba(5,42,45,.28);font-size:12px;font-weight:700;line-height:1.45;pointer-events:none;white-space:nowrap}
.table-wrap{overflow:auto}table{width:max-content;min-width:100%;border-collapse:separate;border-spacing:0;color:var(--ink);background:var(--table-body)}thead{position:sticky;top:0;z-index:2}tbody,tbody tr{color:var(--ink);background:var(--table-body)}th{min-width:125px;padding:11px 12px;border-right:1px solid rgba(255,255,255,.38);background:var(--green);color:#fff;text-align:center;white-space:nowrap}td,tbody td{padding:10px 12px;border-right:1px solid var(--line);border-bottom:1px solid var(--line);color:var(--ink);background-color:var(--table-body);white-space:nowrap;vertical-align:middle}.date-cell{text-align:center}.number-cell{text-align:right}tbody tr:nth-child(even) td{background-color:var(--table-body)}
.detail-groups{padding:14px}.detail-group{overflow:hidden;margin-bottom:10px;border:1px solid var(--line);border-radius:10px;background:#fff}.detail-group:last-child{margin-bottom:0}.detail-group summary{display:flex;align-items:center;justify-content:space-between;padding:13px 15px;color:var(--green);font-weight:800;cursor:pointer;background:var(--soft)}.detail-group summary b{font-size:12px}.detail-table{max-height:68vh;border-top:1px solid var(--line)}.scope{display:inline-block;min-width:42px;padding:3px 7px;border-radius:999px;text-align:center;font-size:12px}.scope.is-analysis{color:#fff;background:var(--green)}.scope.is-padding{color:#6b7e82;background:#e8eeec}.foot{padding:9px 4px;color:var(--muted);text-align:right}
@media(max-width:1180px){.market-toolbar{grid-template-columns:1fr 1.5fr}.business-distribution-grid,.chart-grid-wrap,.opportunity-detail-grid{grid-template-columns:1fr}.opportunity-subtable.is-wide{grid-column:auto}.track-controls{grid-template-columns:repeat(2,minmax(150px,1fr))}}@media(max-width:760px){.hero{padding-inline:14px}.hero-period{display:none}.report{padding-inline:7px}.nav{padding-inline:7px}.market-toolbar{grid-template-columns:1fr}.period-controls{flex-wrap:wrap}.period-control{flex-basis:calc(50% - 5px)}.custom-range-action{flex-basis:100%}.core-kpi-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.metric-card:nth-child(2){border-right:0}.metric-card:nth-child(-n+2){border-bottom:1px solid var(--line)}.business-distribution-grid{padding:7px}.distribution-module{overflow-x:auto}.distribution-module>header,.business-metric-header,.business-metric-list,.distribution-derived{min-width:650px}.period-comparison-table{min-width:720px}.comparison-period-heading,.comparison-value-cell{min-width:210px}.period-comparison-table .comparison-metric-heading,.period-comparison-table tbody th{min-width:130px;width:130px}.comparison-change-heading,.comparison-change-cell{min-width:105px}.track-controls{grid-template-columns:1fr}.track-legend{align-items:flex-start;flex-direction:column;gap:3px}.chance-card-grid{grid-template-columns:1fr}.chance-group-list{padding:7px}.chart-grid-wrap{grid-template-columns:1fr;padding:8px}.section-title{align-items:flex-start}}
@media(max-width:480px){.core-kpi-grid{grid-template-columns:1fr}.metric-card{border-right:0;border-bottom:1px solid var(--line)}.metric-card:last-child{border-bottom:0}.hero-actions button{padding-inline:10px}.hero h1{font-size:16px}}
@media print{*{-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}body{background:#fff}.report-watermark{position:fixed!important;display:grid!important;opacity:.085!important}.nav,.chart-tooltip{display:none!important}.hero{min-height:50px;padding:8mm}.hero-actions{display:none}.report{max-width:none;margin:0;padding:5mm}.market-toolbar,.section{break-inside:avoid;box-shadow:none}.period-comparison-wrap{overflow:visible}.period-comparison-table{min-width:0;table-layout:fixed}.period-comparison-table th,.period-comparison-table td{min-width:0!important;padding:6px 7px}.period-comparison-table .comparison-metric-heading,.period-comparison-table tbody th{width:24%}.comparison-change-heading,.comparison-change-cell{width:16%}.period-comparison-table thead th,.period-comparison-table tbody th{position:static}.business-distribution-grid,.chart-grid-wrap{grid-template-columns:repeat(2,minmax(0,1fr))}.detail-group:not([open]){display:none}.table-wrap{overflow:visible;max-height:none}thead{position:static}th{background:var(--green)!important;color:#fff!important}.ratio-meter-fill{print-color-adjust:exact!important;-webkit-print-color-adjust:exact!important}}
</style></head><body>${watermarkMarkup()}
<header class="hero"><div class="brand-lockup"><span class="brand-mark">少</span><div><p class="eyebrow">DAMOPAN · CATEGORY MARKET REPORT</p><h1>${escapeHtml(semanticTitle)}</h1></div></div><div class="hero-actions"><span class="hero-period">${escapeHtml(model.modeLabel)} · ${escapeHtml(model.periodLabel)}</span><button type="button" data-print>打印 / 保存 PDF</button></div></header>
<nav class="nav"><div class="nav-links">${navItems.map(([id, label]) => `<a href="#${id}">${escapeHtml(label)}</a>`).join("")}</div></nav>
<main class="report"><section class="market-toolbar" aria-label="类目与周期"><div class="category-identity"><span>类</span><div><small>当前类目</small><strong>${escapeHtml(categoryDisplayName)}</strong></div></div><div class="period-controls"><label class="period-control"><span>统计口径</span><select data-period-mode>${modeOptions}</select></label>${periodSelection}</div></section>
${overviewMarkup}${historicalMarkup}${distributionMarkup}${trackMarkup}${opportunityMarkup}${trendMarkup}${detailsMarkup}${emptyMarkup}<p class="foot">少壮AI自动化 · shaozhuangai.com</p></main><div class="chart-tooltip" data-chart-tooltip role="status" hidden></div><script>
(() => {
  document.querySelector('[data-print]')?.addEventListener('click', () => window.print());
  const chartTooltip = document.querySelector('[data-chart-tooltip]');
  let activeChartPoint = null;
  const positionChartTooltip = (clientX, clientY) => {
    if (!chartTooltip || chartTooltip.hidden) return;
    const bounds = chartTooltip.getBoundingClientRect();
    const maximumLeft = Math.max(8, window.innerWidth - bounds.width - 8);
    const maximumTop = Math.max(8, window.innerHeight - bounds.height - 8);
    chartTooltip.style.left = Math.max(8, Math.min(clientX + 12, maximumLeft)) + 'px';
    chartTooltip.style.top = Math.max(8, Math.min(clientY + 12, maximumTop)) + 'px';
  };
  const showChartTooltip = (point, clientX, clientY) => {
    if (!chartTooltip || !point?.dataset.tooltip) return;
    activeChartPoint = point;
    chartTooltip.textContent = point.dataset.tooltip;
    chartTooltip.hidden = false;
    positionChartTooltip(clientX, clientY);
  };
  const hideChartTooltip = (point) => {
    if (!chartTooltip || (point && activeChartPoint !== point)) return;
    activeChartPoint = null;
    chartTooltip.hidden = true;
  };
  document.querySelectorAll('[data-chart-point]').forEach((point) => {
    point.addEventListener('pointerenter', (event) => showChartTooltip(point, event.clientX, event.clientY));
    point.addEventListener('pointermove', (event) => positionChartTooltip(event.clientX, event.clientY));
    point.addEventListener('pointerleave', () => {
      if (document.activeElement !== point) hideChartTooltip(point);
    });
    point.addEventListener('focus', () => {
      const bounds = point.getBoundingClientRect();
      showChartTooltip(point, bounds.left + bounds.width / 2, bounds.bottom);
    });
    point.addEventListener('blur', () => hideChartTooltip(point));
  });
})();
</script></body></html>`;
  }

  return Object.freeze({
    SCHEMA_VERSION, BUSINESS_TIME_ZONE, FIELD_DEFS, MARKET_COLUMNS, validateDataset, displayValue, shanghaiDateKey, resolveCategoryIdentity,
    parseReferenceValue, fitValue, parseChange, median, formatMetricValue, formatParsed, changeGlyph,
    formatChange, stableHash, fittedTailPlan, stabilizeFittedTail, monthlyFlowParsed,
    buildBusinessModel, buildPeriodCatalog, resolveReportView, buildHistoricalPeriods, buildPeriodComparison,
    trackView, renderTrackSection, renderTrackOpportunitySection, buildTrackArchiveTables, buildTrackOpportunityArchiveTables,
    buildArchiveReport, buildHtml
  });
});
