(() => {
  "use strict";

  const htmlWriter = globalThis.DmpHtmlWriter;
  const loading = document.querySelector('[data-role="loading"]');
  const message = document.querySelector('[data-role="message"]');

  function showError(error) {
    loading?.setAttribute("data-error", "");
    const title = loading?.querySelector("h1");
    if (title) title.textContent = "报告暂时无法打开";
    if (message) message.textContent = String(error?.message || error || "本机没有完整报告").slice(0, 240);
  }

  function bindReportActions() {
    document.querySelector("[data-print]")?.addEventListener("click", () => window.print());
    document.querySelectorAll("[data-product-image]").forEach(image => {
      const hideBroken = () => { image.hidden = true; };
      image.addEventListener("error", hideBroken);
      if (image.complete && !image.naturalWidth) hideBroken();
    });
    document.querySelectorAll("[data-table-filter]").forEach(input => {
      const section = input.closest(".report-section");
      const rows = [...(section?.querySelectorAll("tbody tr") || [])];
      const count = section?.querySelector("[data-filter-count]");
      input.addEventListener("input", () => {
        const keyword = input.value.trim().toLocaleLowerCase("zh-CN");
        let visible = 0;
        rows.forEach(row => {
          const matched = !keyword || row.textContent.toLocaleLowerCase("zh-CN").includes(keyword);
          row.hidden = !matched;
          if (matched) visible += 1;
        });
        if (count) count.textContent = `${visible} / ${rows.length}`;
      });
    });
  }

  async function openReport() {
    if (!htmlWriter?.buildHtml) throw new Error("HTML 报告模块未就绪");
    if (window.top === window.self) throw new Error("请从扩展的“打开 HTML”进入报告");
    const frameNonce = new URL(location.href).hash.match(/(?:^#|&)frame=([a-f0-9]{48})(?:&|$)/i)?.[1]?.toLowerCase() || "";
    if (!frameNonce) throw new Error("报告读取凭证缺失，请从扩展重新打开");
    const result = await chrome.runtime.sendMessage({ type: "DMP_DIRECT_GET_REPORT_FOR_FRAME", frameNonce });
    if (!result?.ok) throw new Error(result?.error || "本机报告读取失败");
    history.replaceState(null, "", location.pathname);
    const report = result.report;
    const generated = htmlWriter.buildHtml(report);
    const parsed = new DOMParser().parseFromString(generated, "text/html");
    parsed.querySelectorAll("script").forEach(script => script.remove());
    const nextHead = [...parsed.head.childNodes].map(node => document.importNode(node, true));
    const nextBody = [...parsed.body.childNodes].map(node => document.importNode(node, true));
    document.head.replaceChildren(...nextHead);
    document.body.replaceChildren(...nextBody);
    bindReportActions();
  }

  void openReport().catch(showError);
})();
