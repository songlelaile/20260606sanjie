const SHARE_PATH = /^\/shared\/dmp-reports\/[A-Fa-f0-9]{64}\/?$/;
const REPORT_PATH = "/tools/dmp-report";
const REPORT_ID = /^[a-z\d_-]{6,128}$/i;

export function normalizeOfficialShareUrl(value, officialSite) {
  try {
    const officialOrigin = new URL(officialSite).origin;
    const candidate = new URL(String(value || ""), `${officialOrigin}/`);
    if (!SHARE_PATH.test(candidate.pathname)) return "";
    return new URL(`${candidate.pathname}${candidate.search}${candidate.hash}`, officialOrigin).toString();
  } catch {
    return "";
  }
}

export function normalizeOfficialReportUrl(value, officialSite) {
  try {
    const officialOrigin = new URL(officialSite).origin;
    const candidate = new URL(String(value || ""), `${officialOrigin}/`);
    if (candidate.pathname !== REPORT_PATH) return "";
    const reportIds = candidate.searchParams.getAll("reportId");
    if (reportIds.length !== 1 || !REPORT_ID.test(reportIds[0])) return "";
    const official = new URL(REPORT_PATH, officialOrigin);
    official.searchParams.set("reportId", reportIds[0]);
    official.searchParams.set("view", "report");
    return official.toString();
  } catch {
    return "";
  }
}
