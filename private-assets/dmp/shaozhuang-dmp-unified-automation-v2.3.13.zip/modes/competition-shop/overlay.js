(function initCompetitionSituationAutomation() {
  "use strict";

  if ((window.top && window.top !== window) || (globalThis.DmpUnifiedMode && globalThis.DmpUnifiedMode.current !== "competition-shop") || document.getElementById("dmp-competition-automation")) return;

  const engine = globalThis.DmpCompetitionReportEngine;
  const writer = globalThis.DmpCompetitionXlsxWriter;
  const htmlWriter = globalThis.DmpCompetitionHtmlWriter;
  const competitorDom = globalThis.DmpCompetitionCompetitorDom;
  const automationCore = globalThis.DmpCompetitionAutomationCore;
  if (!engine || !writer || !htmlWriter || !competitorDom || !automationCore) {
    console.error("达摩盘竞争态势报告组件未加载");
    return;
  }
  const unifiedMode = globalThis.DmpUnifiedMode || { current: "competition-shop", switchTo: async () => false };

  const EXTENSION_VERSION = chrome.runtime.getManifest().version;
  const COMPETITOR_STORAGE_KEY = "competitionSituationAutomation:competitorName";
  const INTERNAL_EXPORT_VISIBLE_MS = 600_000;
  const INTERNAL_EXPORT_TRIPLE_CLICK_MS = 900;

  const wait = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds));
  const send = (type, payload = {}) => new Promise((resolve) => {
    chrome.runtime.sendMessage({ type, ...payload }, (result) => {
      if (chrome.runtime.lastError) resolve({ ok: false, error: "扩展连接已失效，请重新加载扩展并刷新页面" });
      else resolve(result || { ok: false, error: "扩展没有返回结果" });
    });
  });

  function fileStamp(date = new Date()) {
    const pad = (value) => String(value).padStart(2, "0");
    return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}-${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())}`;
  }

  function downloadBlob(filename, value, type) {
    const blob = value instanceof Blob ? value : new Blob([value], { type });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    document.documentElement.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1200);
  }

  function safePage() {
    return {
      title: document.title,
      origin: location.origin,
      pathname: location.pathname,
      route: location.hash.split("?")[0],
    };
  }

  function normalizeText(value) {
    return String(value || "").replace(/[\s\u00a0]+/g, " ").trim();
  }

  function businessFacingText(value) {
    return String(value ?? "")
      .replace(/\/(?:api|api_2|dataplatform)\/[^\s；，、）)]*/gi, "相关数据")
      .replace(/\b(?:API|CDP|XHR|Fetch|JSON)\b/gi, "数据")
      .replace(/接口/g, "数据项")
      .replace(/抓包/g, "数据")
      .replace(/响应体|响应/g, "页面数据")
      .replace(/落库/g, "加载完成")
      .replace(/解析/g, "处理")
      .replace(/\s{2,}/g, " ")
      .trim();
  }

  function mount() {
    if (!document.documentElement || document.getElementById("dmp-competition-automation")) return;
    const host = document.createElement("div");
    host.id = "dmp-competition-automation";
    const shadow = host.attachShadow({ mode: "closed" });
    shadow.innerHTML = `
      <style>
        :host { all: initial; }
        * { box-sizing: border-box; }
        .panel { position:fixed; right:14px; bottom:14px; z-index:2147483647; width:min(680px,calc(100vw - 28px)); max-height:78vh; overflow:hidden; color:#eaf7eb; background:#07130a; border:1px solid #4f8b58; border-radius:12px; box-shadow:0 16px 44px rgba(0,0,0,.42); font:12px/1.45 -apple-system,BlinkMacSystemFont,"PingFang SC","Segoe UI",sans-serif; }
        header { display:grid; grid-template-columns:minmax(0,1fr) auto auto; align-items:center; gap:8px; padding:10px 12px; background:#102516; border-bottom:1px solid #315a38; }
        header strong { min-width:0; overflow:hidden; font-size:14px; white-space:nowrap; text-overflow:ellipsis; }
        .header-main { display:flex; align-items:center; gap:8px; min-width:0; overflow:hidden; }
        .status { min-width:0; color:#ffd66b; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
        .mode-switch { min-width:118px; padding:4px 7px; color:#eaf7eb; background:#17351f; border:1px solid #4f8b58; border-radius:6px; font:inherit; }
        button { border:0; border-radius:6px; cursor:pointer; font:inherit; }
        button:disabled { opacity:.45; cursor:not-allowed; }
        .collapse { min-width:26px; padding:3px 7px; background:#24472b; color:#fff; }
        .body { max-height:calc(78vh - 44px); overflow:auto; }
        .task { padding:12px; border-bottom:1px solid #315a38; background:#0b1c0f; }
        .task-row { display:grid; grid-template-columns:minmax(0,1fr) auto; gap:8px; }
        .input-line { display:grid; grid-template-columns:58px minmax(0,1fr); align-items:center; gap:7px; }
        .input-line > span { color:#a8cdae; white-space:nowrap; }
        input { width:100%; min-width:0; padding:8px 10px; color:#f4fff5; background:#07130a; border:1px solid #4f8b58; border-radius:6px; outline:none; font:13px/1.3 -apple-system,BlinkMacSystemFont,"PingFang SC","Segoe UI",sans-serif; }
        input:focus { border-color:#8fc99a; box-shadow:0 0 0 2px rgba(143,201,154,.15); }
        .run { padding:8px 15px; background:#208548; color:#fff; font-weight:700; white-space:nowrap; }
        .task-meta { display:flex; gap:7px; align-items:center; flex-wrap:wrap; margin-top:8px; color:#afd5b5; }
        .pill { padding:2px 7px; border-radius:999px; background:#193e25; color:#bce8c4; }
        .pill.good { background:#164c2a; color:#baf1c5; }
        .pill.warn { background:#5a4315; color:#ffe294; }
        .pill.bad { background:#5e2828; color:#ffb3b3; }
        .step { min-width:0; overflow:hidden; white-space:nowrap; text-overflow:ellipsis; }
        .progress { height:5px; margin-top:9px; overflow:hidden; background:#18311d; border-radius:999px; }
        .progress > i { display:block; width:0; height:100%; background:linear-gradient(90deg,#2ea35b,#8ed09d); transition:width .25s ease; }
        .downloads { display:flex; gap:7px; margin-top:10px; }
        .downloads button { flex:1; min-width:0; padding:6px 8px; color:#fff; background:#24472b; white-space:nowrap; }
        .downloads .primary { background:#1c6b35; }
        .runtime-stop { margin-top:8px; }
        .runtime-stop[hidden] { display:none; }
        .runtime-stop button { width:100%; padding:5px; color:#ffc3c3; background:#472222; border:1px solid #7b3f3f; }
        .recapture { display:flex; align-items:center; gap:8px; margin-top:8px; padding:8px; border:1px solid #795f22; border-radius:7px; background:#30250e; color:#ffe294; }
        .recapture[hidden] { display:none; }
        .recapture button { flex:0 0 auto; padding:7px 11px; color:#fff; background:#b77717; font-weight:700; }
        .recapture span { min-width:0; word-break:break-word; }
        .preview { padding:10px 12px 12px; }
        .preview-head { display:flex; align-items:center; justify-content:space-between; gap:8px; margin-bottom:7px; }
        .preview-head strong { font-size:13px; }
        .preview-head select { min-width:150px; max-width:230px; padding:4px 7px; color:#eaf7eb; background:#132c19; border:1px solid #4f8b58; border-radius:5px; font:inherit; }
        .preview-quality { color:#9ed7a6; }
        .table-wrap { max-height:280px; overflow:auto; border:1px solid #315a38; border-radius:7px; background:#0a190d; }
        table { width:100%; border-collapse:separate; border-spacing:0; color:#dcefe0; font-size:11px; }
        th { position:sticky; top:0; z-index:1; padding:7px 8px; text-align:left; white-space:nowrap; color:#fff; background:#1f6b49; }
        td { max-width:220px; padding:6px 8px; vertical-align:top; border-bottom:1px solid #183d23; word-break:break-word; }
        tbody tr:nth-child(even) td { background:#0d2112; }
        .empty { padding:24px 12px; color:#8fb095; text-align:center; }
        .hint { margin-top:7px; color:#7fa787; }
      </style>
      <section class="panel" data-panel>
        <header>
          <div class="header-main"><strong title="达摩盘一体化自动取数｜少壮AI自动化">一体化自动取数｜少壮AI自动化 v${EXTENSION_VERSION}</strong><span class="status" data-status>等待运行</span></div>
          <select class="mode-switch" data-mode-switch title="切换取数模式"><option value="growth">打爆路径</option><option value="competition-shop">竞争态势·店铺</option></select>
          <button class="collapse" data-collapse title="收起/展开">—</button>
        </header>
        <div class="body" data-body>
          <section class="task">
            <div class="task-row">
              <label class="input-line"><span>竞店</span><input data-competitor placeholder="最多3家，逗号分隔" /></label>
              <button class="run" data-run>一键运行</button>
            </div>
            <div class="task-meta">
              <span class="pill">自定义近7天 + 近30天</span>
              <span class="pill" data-period-state>周期待确认</span>
              <span class="pill" data-job-state>等待运行</span>
              <span class="step" data-step>自动采集并打开官网 HTML 报告</span>
            </div>
            <div class="progress"><i data-progress></i></div>
            <div class="downloads" data-downloads>
              <button class="primary" data-online disabled>打开官网 HTML</button>
              <button class="primary" data-share disabled>分享在线报告</button>
              <button data-check>检查完整性</button>
              <button data-history>历史报告</button>
            </div>
            <div class="runtime-stop" data-stop-wrap hidden><button data-stop>停止当前采集</button></div>
            <div class="recapture" data-recapture-wrap hidden>
              <button data-manual>补齐缺失数据</button>
              <span data-recapture-summary>请按提示打开缺失模块，完成后停止并重新检查。</span>
            </div>
          </section>
          <section class="preview">
            <div class="preview-head"><strong>业务表格预览</strong><select data-preview-table disabled><option>尚未生成</option></select><span class="preview-quality" data-preview-quality>等待取数</span></div>
            <div class="table-wrap" data-preview-wrap><div class="empty">填写竞店名称后点击“一键运行”</div></div>
          </section>
        </div>
      </section>`;
    document.documentElement.appendChild(host);

    const get = (selector) => shadow.querySelector(selector);
    const statusNode = get("[data-status]");
    const stepNode = get("[data-step]");
    const jobStateNode = get("[data-job-state]");
    const previewTableNode = get("[data-preview-table]");
    const previewWrapNode = get("[data-preview-wrap]");
    const previewQualityNode = get("[data-preview-quality]");
    const recaptureWrapNode = get("[data-recapture-wrap]");
    const recaptureSummaryNode = get("[data-recapture-summary]");
    const stopWrapNode = get("[data-stop-wrap]");
    const competitorInputNode = get("[data-competitor]");
    const modeSwitchNode = get("[data-mode-switch]");
    const periodStateNode = get("[data-period-state]");
    const downloadsNode = get("[data-downloads]");
    const actionButtons = ["run", "manual", "stop", "check", "online", "share", "history"]
      .map((name) => get(`[data-${name}]`))
      .filter(Boolean);
    let statsTimer = null;
    let automationRunning = false;
    let cancelRequested = false;
    let lastReport = null;
    let lastArchive = null;
    let collapsed = false;
    let internalExportButton = null;
    let internalExportHideTimer = null;
    let internalExportUnlockPending = false;
    let internalExportDownloadPending = false;
    let statusClickTimes = [];

    function setJobState(message, tone = "") {
      jobStateNode.textContent = message;
      jobStateNode.className = `pill ${tone}`.trim();
    }

    function setPeriodState(message, tone = "") {
      periodStateNode.textContent = message;
      periodStateNode.className = `pill ${tone}`.trim();
    }

    function setStatus(message, error = false) {
      const displayMessage = businessFacingText(message);
      statusNode.textContent = displayMessage;
      statusNode.style.color = error ? "#ff9d9d" : "#ffd66b";
      stepNode.textContent = displayMessage;
    }

    function setProgress(value) {
      get("[data-progress]").style.width = `${Math.max(0, Math.min(100, Number(value) || 0))}%`;
    }

    function updateInternalExportButton() {
      if (!internalExportButton) return;
      internalExportButton.disabled = automationRunning
        || internalExportDownloadPending
        || lastReport?.quality?.exportAllowed !== true;
    }

    function hideInternalExport() {
      clearTimeout(internalExportHideTimer);
      internalExportHideTimer = null;
      internalExportButton?.remove();
      internalExportButton = null;
    }

    function showInternalExport() {
      hideInternalExport();
      const button = document.createElement("button");
      button.type = "button";
      button.className = "primary";
      button.dataset.internalExport = "";
      button.textContent = "内部导出";
      button.addEventListener("click", () => void authorizeAndDownloadInternalExport());
      downloadsNode.prepend(button);
      internalExportButton = button;
      updateInternalExportButton();
      internalExportHideTimer = setTimeout(hideInternalExport, INTERNAL_EXPORT_VISIBLE_MS);
    }

    async function unlockInternalExport() {
      if (internalExportUnlockPending || internalExportDownloadPending || internalExportButton) return;
      internalExportUnlockPending = true;
      setStatus("正在校验内部导出权限…");
      try {
        const result = await send("DMP_CDP_VERIFY_REPORT_EXPORT", {
          reportType: "competition",
          clientVersion: EXTENSION_VERSION
        });
        if (!result?.ok) throw new Error(result?.error || "内部导出权限校验未通过");
        showInternalExport();
        setStatus(lastReport?.quality?.exportAllowed
          ? "内部导出已临时开启，10 分钟内可使用一次。"
          : "内部导出已临时开启；需先生成完整报告。");
      } catch (error) {
        hideInternalExport();
        setStatus(String(error?.message || error), true);
      } finally {
        internalExportUnlockPending = false;
      }
    }

    function setBusy(busy) {
      actionButtons.forEach((button) => { button.disabled = busy; });
      competitorInputNode.disabled = busy;
      get("[data-stop]").disabled = !busy;
      stopWrapNode.hidden = !busy;
      if (busy) {
        recaptureWrapNode.hidden = true;
        setJobState("运行中");
      } else if (lastReport?.quality?.complete) {
        get("[data-online]").disabled = !lastArchive?.ok || !lastArchive?.reportId;
        get("[data-share]").disabled = false;
        get("[data-check]").disabled = false;
        get("[data-history]").disabled = false;
        get("[data-manual]").disabled = true;
        recaptureWrapNode.hidden = true;
        setJobState("数据完整", "good");
      } else if (lastReport?.quality) {
        get("[data-online]").disabled = true;
        get("[data-share]").disabled = true;
        get("[data-check]").disabled = false;
        get("[data-history]").disabled = false;
        get("[data-manual]").disabled = false;
        recaptureWrapNode.hidden = false;
        setJobState("待补采", "warn");
      } else {
        get("[data-online]").disabled = true;
        get("[data-share]").disabled = true;
        get("[data-check]").disabled = false;
        get("[data-history]").disabled = false;
        get("[data-manual]").disabled = true;
        recaptureWrapNode.hidden = true;
        setJobState("等待运行");
      }
      updateInternalExportButton();
    }

    function applyStats(stats = {}) {
      if (!competitorInputNode.value.trim() && stats.session?.competitorName) competitorInputNode.value = String(stats.session.competitorName);
    }

    function displayCell(value) {
      if (value == null || value === "") return "—";
      if (typeof value === "object") {
        try { return JSON.stringify(value); } catch { return String(value); }
      }
      return String(value);
    }

    function renderSelectedTable(report, tableName) {
      previewWrapNode.replaceChildren();
      const current = report?.tables?.find((table) => table.name === tableName) || report?.tables?.[0];
      if (!current?.rows?.length) {
        const empty = document.createElement("div");
        empty.className = "empty";
        empty.textContent = `${current?.name || "该业务表"}暂无数据`;
        previewWrapNode.appendChild(empty);
        return;
      }
      const table = document.createElement("table");
      const thead = document.createElement("thead");
      const headRow = document.createElement("tr");
      (current.columns || []).forEach((label) => {
        const th = document.createElement("th");
        th.textContent = displayCell(label);
        headRow.appendChild(th);
      });
      thead.appendChild(headRow);
      const tbody = document.createElement("tbody");
      current.rows.slice(0, 120).forEach((row) => {
        const tr = document.createElement("tr");
        (Array.isArray(row) ? row : Object.values(row || {})).forEach((value) => {
          const td = document.createElement("td");
          td.textContent = displayCell(value);
          tr.appendChild(td);
        });
        tbody.appendChild(tr);
      });
      table.append(thead, tbody);
      previewWrapNode.appendChild(table);
    }

    function renderReportPreview(report) {
      const tables = Array.isArray(report?.tables) ? report.tables : [];
      const selected = previewTableNode.value;
      previewTableNode.replaceChildren();
      tables.forEach((table) => {
        const option = document.createElement("option");
        option.value = table.name;
        option.textContent = `${table.name}（${table.rows?.length || 0}）`;
        previewTableNode.appendChild(option);
      });
      previewQualityNode.textContent = report?.quality?.complete ? "数据完整" : "待补齐";
      previewTableNode.disabled = tables.length === 0;
      previewTableNode.value = tables.some((table) => table.name === selected)
        ? selected
        : (tables.find((table) => table.name === "对标总表")?.name || tables[0]?.name || "");
      renderSelectedTable(report, previewTableNode.value);
    }

    async function refreshStats() {
      const result = await send("COMP_SITUATION_STATS");
      if (!result?.ok) {
        setStatus(result?.error || "统计读取失败", true);
        return null;
      }
      applyStats(result.stats);
      return result.stats;
    }

    function scheduleStats() {
      clearTimeout(statsTimer);
      statsTimer = setTimeout(() => void refreshStats(), 300);
    }

    function applyQuality(report) {
      lastReport = report;
      const quality = report?.quality;
      renderReportPreview(report);
      if (!quality) {
        previewQualityNode.textContent = "无法生成";
        previewQualityNode.style.color = "#ff9d9d";
        recaptureWrapNode.hidden = true;
        setJobState("生成失败", "bad");
        return;
      }
      if (quality.complete) {
        previewQualityNode.textContent = "数据完整";
        previewQualityNode.style.color = "#9ed7a6";
        recaptureWrapNode.hidden = true;
        setJobState("数据完整", "good");
      } else {
        const issues = quality.blockingIssues || [];
        previewQualityNode.textContent = "待补齐";
        previewQualityNode.style.color = "#ffb3b3";
        recaptureSummaryNode.textContent = businessFacingText(issues.slice(0, 2).join("；")) || "请按提示打开缺失模块，完成后停止并重新检查。";
        recaptureWrapNode.hidden = automationRunning;
        setJobState("待补采", "warn");
      }
      if (!automationRunning) setBusy(false);
    }

    async function buildCurrentReport() {
      const result = await send("COMP_SITUATION_GET_RECORDS");
      if (!result?.ok) throw new Error(result?.error || "读取抓包失败");
      const report = engine.buildReport(result.records || [], { session: result.session || null, page: safePage() });
      applyQuality(report);
      return { report, records: result.records || [], session: result.session || null };
    }

    const ARCHIVE_SENSITIVE_KEY = /(?:cookie|token|authorization|password|secret|session|csrf|webOpSessionId|uniqueItemCampaign)/i;

    function normalizeCompetitionTableForArchive(table, index) {
      if (!table || typeof table !== "object") return null;
      const allRows = Array.isArray(table.rows) ? table.rows : [];
      const rawRows = allRows.slice(0, 5000);
      const rawColumns = Array.isArray(table.columns) ? table.columns : [];
      const rowWidths = rawRows.map((row) => Array.isArray(row?.cells) ? row.cells.length : Array.isArray(row) ? row.length : Object.values(row || {}).length);
      const rawWidth = Math.max(1, rawColumns.length, ...rowWidths);
      const width = Math.min(100, rawWidth);
      let partial = allRows.length > rawRows.length
        || rawWidth > width
        || rawColumns.length === 0
        || rowWidths.some((rowWidth) => rowWidth !== rawColumns.length);
      const sensitiveColumns = new Set();
      const columns = Array.from({ length: width }, (_unused, columnIndex) => {
        const label = String(rawColumns[columnIndex] || `字段${columnIndex + 1}`).slice(0, 300);
        if (ARCHIVE_SENSITIVE_KEY.test(label)) {
          sensitiveColumns.add(columnIndex);
          return `字段${columnIndex + 1}`;
        }
        return label;
      });
      const rows = rawRows.map((row) => {
        const sourceCells = Array.isArray(row?.cells) ? row.cells : Array.isArray(row) ? row : Object.values(row || {});
        return Array.from({ length: width }, (_unused, cellIndex) => {
          if (sensitiveColumns.has(cellIndex)) return "";
          const value = sourceCells[cellIndex];
          if (value == null || typeof value === "number" || typeof value === "boolean") return value ?? "";
          const text = String(value);
          if (text.length > 10_000) partial = true;
          return text.slice(0, 10_000);
        });
      });
      const rawName = String(table.name || `业务模块${index + 1}`).trim().slice(0, 120);
      return {
        table: {
          ...table,
          name: !rawName || ARCHIVE_SENSITIVE_KEY.test(rawName) ? `业务模块${index + 1}` : rawName,
          columns,
          rows
        },
        partial
      };
    }

    function toArchivableCompetitionReport(report) {
      const sourceTables = Array.isArray(report?.tables) ? report.tables : [];
      const entries = sourceTables
        .map(normalizeCompetitionTableForArchive)
        .filter(Boolean);
      const tables = entries.map((entry) => entry.table);
      const normalized = {
        ...report,
        tables: tables.length ? tables : [{ name: "报告总览", columns: ["项目", "内容"], rows: [["归档状态", "部分数据"]] }]
      };
      return {
        canonical: engine.toCanonicalReport(normalized),
        partial: sourceTables.length !== entries.length || !tables.length || entries.some((entry) => entry.partial)
      };
    }

    async function archiveReportToOfficialCenter(report = lastReport, { openReport = false, force = false } = {}) {
      const current = report || (await buildCurrentReport()).report;
      if (!current) throw new Error("尚未生成可归档报告");
      if (!force && lastArchive?.ok && lastArchive.reportId) {
        if (openReport) {
          const opened = await send("DMP_CDP_OPEN_REPORT", { reportId: lastArchive.reportId });
          lastArchive = { ...lastArchive, opened: Boolean(opened?.ok), openError: opened?.ok ? "" : (opened?.error || "官网报告打开失败") };
        }
        return lastArchive;
      }
      const { canonical, partial: structurallyPartial } = toArchivableCompetitionReport(current);
      const result = await send("COMP_SITUATION_SYNC_REPORT", {
        report: canonical,
        subjectItemId: current.subjectId,
        competitorItemId: (current.competitorIds || []).join(","),
        quality: current.quality?.complete === true && current.quality?.exportAllowed === true && !structurallyPartial ? "complete" : "partial",
        openReport
      });
      if (!result?.ok || !result.reportId) throw new Error(result?.error || "在线报告保存失败");
      lastArchive = result;
      return result;
    }

    async function copyShareLink(value) {
      try {
        await navigator.clipboard.writeText(value);
      } catch {
        const input = document.createElement("textarea");
        input.value = value;
        input.style.cssText = "position:fixed;left:-9999px;opacity:0";
        document.documentElement.appendChild(input);
        input.select();
        document.execCommand("copy");
        input.remove();
      }
    }

    async function createOnlineShare(report = lastReport) {
      const archived = await archiveReportToOfficialCenter(report);
      const result = await send("COMP_SITUATION_CREATE_SHARE", { reportId: archived.reportId });
      if (!result?.ok || !result.shareUrl) throw new Error(result?.error || "分享链接生成失败");
      await copyShareLink(result.shareUrl);
      return result.shareUrl;
    }

    function ensureNotCancelled() {
      if (cancelRequested) throw new Error("用户已停止本轮自动取数");
    }

    function visible(element) {
      if (!element?.isConnected || host.contains(element)) return false;
      const rect = element.getBoundingClientRect?.();
      if (!rect || rect.width < 2 || rect.height < 2) return false;
      const style = getComputedStyle(element);
      return style.visibility !== "hidden" && style.display !== "none" && Number(style.opacity || 1) > 0;
    }

    function renderedTextElement(element) {
      if (!element?.isConnected || host.contains(element)) return false;
      let current = element;
      for (let depth = 0; current && depth < 6; depth += 1, current = current.parentElement) {
        const style = getComputedStyle(current);
        if (style.visibility === "hidden" || style.display === "none" || Number(style.opacity || 1) <= 0) return false;
        const rect = current.getBoundingClientRect?.();
        if (rect && rect.width >= 2 && rect.height >= 2) return true;
      }
      return false;
    }

    function labelOf(element) {
      return normalizeText(element.value || element.getAttribute?.("aria-label") || element.getAttribute?.("title") || element.textContent);
    }

    function clickTarget(element) {
      return element.closest?.("button,a,[role='button'],[role='tab'],li,label,input,[tabindex]") || element;
    }

    function resultActionTarget(element) {
      return element.closest?.("button,a,[role='button']") || element;
    }

    function candidateScore(element, wanted, exact) {
      const target = clickTarget(element);
      const rect = target.getBoundingClientRect();
      const tag = target.tagName?.toLowerCase();
      const interactive = ["button", "a", "li", "label", "input"].includes(tag) || /button|tab|option/.test(target.getAttribute?.("role") || "");
      return (exact ? 200 : 80) + (interactive ? 45 : 0) + Math.max(0, 30 - labelOf(target).length) + Math.max(0, 20 - rect.top / 80) - Math.max(0, labelOf(element).length - wanted.length);
    }

    function textCandidates(labels, regex = null, scope = document, exactOnly = false) {
      const selector = "button,a,[role='button'],[role='tab'],[role='option'],li,label,input,span,div";
      const nodes = [
        ...(scope instanceof Element && scope.matches(selector) ? [scope] : []),
        ...scope.querySelectorAll(selector),
      ];
      const output = [];
      for (const node of nodes) {
        if (!visible(node)) continue;
        const text = labelOf(node);
        if (!text || text.length > 90) continue;
        for (const label of labels) {
          const exact = text === label;
          if (exact || (!exactOnly && text.includes(label))) output.push({ element: clickTarget(node), score: candidateScore(node, label, exact) });
        }
        if (regex?.test(text)) output.push({ element: clickTarget(node), score: candidateScore(node, text, true) });
      }
      const best = new Map();
      for (const item of output) if (!best.has(item.element) || best.get(item.element).score < item.score) best.set(item.element, item);
      return [...best.values()].sort((a, b) => b.score - a.score).map((item) => item.element).slice(0, 8);
    }

    function exactTextNodes(text, scope = document) {
      const selector = "button,a,[role='button'],[role='tab'],[role='option'],li,label,span,div,strong";
      return [
        ...(scope instanceof Element && scope.matches(selector) ? [scope] : []),
        ...scope.querySelectorAll(selector),
      ].filter((node) => visible(node) && labelOf(node) === text)
        .sort((left, right) => {
          const a = left.getBoundingClientRect();
          const b = right.getBoundingClientRect();
          return a.width * a.height - b.width * b.height;
        });
    }

    async function waitForCondition(check, timeoutMs = 6000, description = "页面控件") {
      const started = Date.now();
      while (Date.now() - started < timeoutMs) {
        ensureNotCancelled();
        const result = check();
        if (result) return result;
        await wait(120);
      }
      throw new Error(`${description}未在 ${Math.ceil(timeoutMs / 1000)} 秒内出现`);
    }

    function dispatchSynthetic(element) {
      const view = element.ownerDocument?.defaultView || window;
      const rect = element.getBoundingClientRect();
      const base = { bubbles: true, cancelable: true, view, clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2, button: 0, buttons: 1 };
      try {
        element.dispatchEvent(new MouseEvent("mouseover", { ...base, buttons: 0 }));
        if (view.PointerEvent) element.dispatchEvent(new PointerEvent("pointerdown", { ...base, pointerId: 1, pointerType: "mouse", isPrimary: true }));
        element.dispatchEvent(new MouseEvent("mousedown", base));
        if (view.PointerEvent) element.dispatchEvent(new PointerEvent("pointerup", { ...base, buttons: 0, pointerId: 1, pointerType: "mouse", isPrimary: true }));
        element.dispatchEvent(new MouseEvent("mouseup", { ...base, buttons: 0 }));
        element.dispatchEvent(new MouseEvent("click", { ...base, buttons: 0 }));
        return true;
      } catch { return false; }
    }

    async function trustedClick(element) {
      if (!visible(element)) return false;
      element.scrollIntoView?.({ block: "center", inline: "center" });
      await wait(180);
      const rect = element.getBoundingClientRect();
      const x = Math.round(rect.left + rect.width / 2);
      const y = Math.round(rect.top + rect.height / 2);
      if (x < 0 || y < 0 || x > innerWidth || y > innerHeight) return false;
      const previousVisibility = host.style.visibility;
      host.style.visibility = "hidden";
      await wait(50);
      const result = await send("COMP_SITUATION_REAL_CLICK", { x, y });
      host.style.visibility = previousVisibility;
      if (result?.ok) return true;
      return dispatchSynthetic(element);
    }

    function setNativeValue(element, value) {
      const prototype = element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
      if (setter) setter.call(element, value);
      else element.value = value;
      element.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        inputType: value ? "insertText" : "deleteContentBackward",
        data: value || null,
      }));
      element.dispatchEvent(new Event("change", { bubbles: true }));
    }

    function dispatchSyntheticEnter(element) {
      element.focus?.();
      element.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true }));
      element.dispatchEvent(new KeyboardEvent("keyup", { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true }));
    }

    async function trustedClearInput(element) {
      if (!visible(element)) return false;
      element.scrollIntoView?.({ block: "center", inline: "center" });
      await wait(180);
      const rect = element.getBoundingClientRect();
      const x = Math.round(rect.left + rect.width / 2);
      const y = Math.round(rect.top + rect.height / 2);
      if (x < 0 || y < 0 || x > innerWidth || y > innerHeight) return false;
      const previousVisibility = host.style.visibility;
      host.style.visibility = "hidden";
      await wait(50);
      const result = await send("COMP_SITUATION_REAL_INPUT", {
        x,
        y,
        text: "",
        pressEnter: false,
        skipClear: false,
      });
      host.style.visibility = previousVisibility;
      await wait(140);
      if (element.isConnected && element.value !== "") {
        try { setNativeValue(element, ""); } catch {}
        await wait(140);
      }
      return Boolean(result?.ok || !element.isConnected || element.value === "");
    }

    async function trustedFill(element, value, pressEnter = false) {
      if (!visible(element)) return false;
      const expectedValue = String(value);
      element.scrollIntoView?.({ block: "center", inline: "center" });
      await wait(180);
      const rect = element.getBoundingClientRect();
      const x = Math.round(rect.left + rect.width / 2);
      const y = Math.round(rect.top + rect.height / 2);
      if (x < 0 || y < 0 || x > innerWidth || y > innerHeight) return false;
      const previousVisibility = host.style.visibility;
      host.style.visibility = "hidden";
      await wait(50);
      const result = await send("COMP_SITUATION_REAL_INPUT", {
        x,
        y,
        text: expectedValue,
        pressEnter: false,
        skipClear: true,
      });
      host.style.visibility = previousVisibility;
      await wait(140);
      if (element.isConnected && element.value !== expectedValue) {
        try { setNativeValue(element, expectedValue); } catch {}
        await wait(140);
      }
      if (!element.isConnected || element.value !== expectedValue) return false;
      if (pressEnter) {
        const beforeEnterVisibility = host.style.visibility;
        host.style.visibility = "hidden";
        await wait(50);
        const enterResult = await send("COMP_SITUATION_REAL_INPUT", {
          x,
          y,
          text: "",
          pressEnter: true,
          skipClear: true,
        });
        host.style.visibility = beforeEnterVisibility;
        if (!enterResult?.ok) {
          await wait(180);
          dispatchSyntheticEnter(element);
        }
      }
      return Boolean(result?.ok || element.value === expectedValue);
    }

    function activeLoadingSignals() {
      const selectors = [
        '[aria-busy="true"]',
        '[data-loading="true"]',
        '.mx-loading-mask',
        '.mxgc-loading-mask',
        '.next-loading-tip',
        '.ant-spin-spinning',
        '.el-loading-mask',
        '[class*="loading-mask"]',
        '[class*="loading-spinner"]',
        '[class*="loading-indicator"]',
        '[class*="skeleton"]',
      ].join(",");
      return [...document.querySelectorAll(selectors)].filter((node) => visible(node) && !host.contains(node)).length;
    }

    async function waitForDataSettled(options = {}) {
      const minimumMs = Math.max(0, Number(options.minimumMs ?? 1200));
      const maximumMs = Math.max(minimumMs + 500, Number(options.maximumMs ?? 20000));
      const quietMs = Math.max(500, Number(options.quietMs ?? 1000));
      const noActivityGraceMs = Math.max(minimumMs, Number(options.noActivityGraceMs ?? 3200));
      const requireActivity = Boolean(options.requireActivity);
      const allowNoActivity = options.allowNoActivity !== false;
      const description = String(options.description || "页面数据");
      const started = Date.now();
      let previousRecords = Number.isFinite(Number(options.baselineRecords)) ? Number(options.baselineRecords) : null;
      let quietSince = null;
      let sawActivity = false;
      let lastPending = 0;
      let lastLoadingSignals = 0;
      while (Date.now() - started < maximumMs) {
        ensureNotCancelled();
        await wait(250);
        const stats = await refreshStats();
        const currentRecords = Number(stats?.records || 0);
        const pending = Number(stats?.pendingBusinessRequests || 0);
        const loadingSignals = activeLoadingSignals();
        const recordChanged = previousRecords != null && currentRecords !== previousRecords;
        if (recordChanged || pending > 0 || loadingSignals > 0) {
          sawActivity = true;
          quietSince = null;
        } else if (quietSince == null) quietSince = Date.now();
        previousRecords = currentRecords;
        lastPending = pending;
        lastLoadingSignals = loadingSignals;
        const elapsed = Date.now() - started;
        const activitySatisfied = !requireActivity || sawActivity || (allowNoActivity && elapsed >= noActivityGraceMs);
        if (elapsed >= minimumMs && activitySatisfied && quietSince != null && Date.now() - quietSince >= quietMs) return stats;
      }
      throw new Error(`${description}加载超时：仍有 ${lastPending} 个业务请求、${lastLoadingSignals} 个页面加载状态`);
    }

    async function clickLabels(labels, progress, step, regex = null, scope = document, exactOnly = false) {
      ensureNotCancelled();
      setProgress(progress);
      setStatus(step);
      const candidates = textCandidates(labels, regex, scope, exactOnly);
      for (const candidate of candidates.slice(0, 4)) {
        if (!await trustedClick(candidate)) continue;
        await waitForDataSettled({ minimumMs: 1200, maximumMs: 18000, quietMs: 1000, noActivityGraceMs: 2800, description: step });
        return true;
      }
      return false;
    }

    const ATTRIBUTION_LABELS = Object.freeze({ 1: "全域归因", 2: "广告域归因" });

    function attributionAnchor() {
      return exactTextNodes("归因范围")[0] || null;
    }

    function attributionTrigger() {
      const anchor = attributionAnchor();
      const anchorRect = anchor?.getBoundingClientRect?.();
      const labels = Object.values(ATTRIBUTION_LABELS);
      const selectors = "[role='combobox'],[aria-haspopup='listbox'],[aria-expanded],.mx-trigger,button,span,div";
      const seen = new Set();
      const candidates = [];
      for (const node of document.querySelectorAll(selectors)) {
        if (!visible(node) || host.contains(node)) continue;
        const nodeText = labelOf(node);
        if (!labels.includes(nodeText)) continue;
        const target = node.closest?.("[role='combobox'],[aria-haspopup='listbox'],[aria-expanded],.mx-trigger") || clickTarget(node);
        if (!visible(target) || seen.has(target) || target.closest?.("[role='listbox'],[role='menu'],ul")) continue;
        seen.add(target);
        const rect = target.getBoundingClientRect();
        const vertical = anchorRect ? Math.abs((rect.top + rect.height / 2) - (anchorRect.top + anchorRect.height / 2)) : 0;
        const gap = anchorRect ? rect.left - anchorRect.right : 0;
        const semantic = target.matches?.("[role='combobox'],[aria-haspopup='listbox'],[aria-expanded],.mx-trigger") ? 1 : 0;
        const penalty = vertical * 10 + Math.abs(gap) + (gap < -30 ? 1600 : 0);
        candidates.push({ target, semantic, penalty, area: rect.width * rect.height });
      }
      return candidates
        .sort((left, right) => right.semantic - left.semantic || left.penalty - right.penalty || left.area - right.area)[0]?.target || null;
    }

    function currentAttributionLabel(trigger = attributionTrigger()) {
      const text = labelOf(trigger);
      return Object.values(ATTRIBUTION_LABELS).find((label) => text.includes(label)) || "";
    }

    function attributionPopup(trigger = attributionTrigger()) {
      const labels = Object.values(ATTRIBUTION_LABELS);
      return [...document.querySelectorAll("[role='listbox'],[role='menu'],[id^='mx_output_'],ul,div")]
        .filter((node) => visible(node) && !host.contains(node))
        .filter((node) => !trigger || (node !== trigger && !node.contains(trigger) && !trigger.contains(node)))
        .filter((node) => {
          const text = normalizeText(node.textContent);
          return text.length <= 240 && labels.every((label) => text.includes(label));
        })
        .sort((left, right) => {
          const a = left.getBoundingClientRect();
          const b = right.getBoundingClientRect();
          return a.width * a.height - b.width * b.height || normalizeText(left.textContent).length - normalizeText(right.textContent).length;
        })[0] || null;
    }

    function attributionOption(label, popup, trigger) {
      const candidates = exactTextNodes(label, popup)
        .map((node) => node.closest?.("li,[role='option'],button,[mx-click],[tabindex]") || node)
        .filter((node) => visible(node) && node !== trigger && !node.contains(trigger) && !trigger?.contains(node));
      return candidates.sort((left, right) => {
        const semanticLeft = left.matches?.("li,[role='option'],button,[mx-click],[tabindex]") ? 1 : 0;
        const semanticRight = right.matches?.("li,[role='option'],button,[mx-click],[tabindex]") ? 1 : 0;
        const a = left.getBoundingClientRect();
        const b = right.getBoundingClientRect();
        return semanticRight - semanticLeft || a.width * a.height - b.width * b.height;
      })[0] || null;
    }

    async function chooseAttributionOption(label) {
      let trigger = await waitForCondition(attributionTrigger, 5000, "归因范围下拉框");
      if (currentAttributionLabel(trigger) === label) return false;
      let popup = attributionPopup(trigger);
      if (!popup) {
        if (!await trustedClick(trigger)) throw new Error("无法展开“归因范围”下拉框");
        popup = await waitForCondition(() => attributionPopup(trigger), 5000, "归因范围选项");
      }
      const option = attributionOption(label, popup, trigger);
      if (!option || !await trustedClick(option)) throw new Error(`无法选择“${label}”`);
      trigger = await waitForCondition(() => {
        const current = attributionTrigger();
        return current && currentAttributionLabel(current) === label ? current : null;
      }, 5000, `“${label}”选中状态`);
      await waitForDataSettled({ minimumMs: 1400, maximumMs: 20000, quietMs: 1000, noActivityGraceMs: 3200, description: `“${label}”数据` });
      return Boolean(trigger);
    }

    async function setAttributionScale(scale, force = false) {
      const label = ATTRIBUTION_LABELS[scale];
      if (!label) throw new Error(`未知归因范围：${scale}`);
      let trigger = await waitForCondition(attributionTrigger, 5000, "归因范围下拉框");
      if (currentAttributionLabel(trigger) === label && force) {
        const fallback = Object.values(ATTRIBUTION_LABELS).find((value) => value !== label);
        await chooseAttributionOption(fallback);
        trigger = await waitForCondition(attributionTrigger, 3000, "归因范围回切控件");
      }
      if (currentAttributionLabel(trigger) !== label) await chooseAttributionOption(label);
      return currentAttributionLabel(attributionTrigger()) === label;
    }

    async function capturedAttributionRecords(expected, scale, startIndex) {
      const result = await send("COMP_SITUATION_GET_RECORDS");
      if (!result?.ok) throw new Error(result?.error || "无法读取归因渠道请求");
      return automationCore.matchingFlowIndicatorRecords(result.records || [], expected, scale, {
        startIndex,
        requireCompetitor: true,
        requireUsable: true,
        minimumCompetitors: automationCore.parseCompetitorNames(competitorInputNode.value).slice(0, 3).length,
      });
    }

    async function ensureAttributionCaptured(expected, scale, startIndex, progress, step) {
      ensureNotCancelled();
      setProgress(progress);
      setStatus(step);
      if ((await capturedAttributionRecords(expected, scale, startIndex)).length) {
        await waitForDataSettled({ minimumMs: 700, maximumMs: 12000, quietMs: 900, description: `近${expected.days}天${ATTRIBUTION_LABELS[scale]}数据` });
        return true;
      }
      const label = ATTRIBUTION_LABELS[scale];
      const force = currentAttributionLabel(attributionTrigger()) === label;
      if (!await setAttributionScale(scale, force)) throw new Error(`“${label}”未能选中`);
      const started = Date.now();
      while (Date.now() - started < 20000) {
        ensureNotCancelled();
        const matches = await capturedAttributionRecords(expected, scale, startIndex);
        if (matches.length) {
          await waitForDataSettled({ minimumMs: 700, maximumMs: 12000, quietMs: 900, description: `近${expected.days}天${label}数据` });
          return true;
        }
        await wait(350);
      }
      throw new Error(`已选中“${label}”，但未捕获近${expected.days}天渠道接口；请重新运行`);
    }

    const FLOW_STRUCTURES = Object.freeze({
      paidFree: Object.freeze({
        label: "付免流量结构",
        endpoint: "/api/competition/analysis/flow/paid_free/structural",
        labels: Object.freeze(["付免流量结构", "付费/免费流量", "付费免费流量", "付费/免费", "流量构成", "流量结构"]),
        alternateLabels: Object.freeze(["无界投资结构", "投放成本结构", "投放成本", "投放结构", "成本结构"]),
      }),
      investor: Object.freeze({
        label: "无界投资结构",
        endpoint: "/api/competition/analysis/flow/investor/structural",
        labels: Object.freeze(["无界投资结构", "投放成本结构", "投放成本", "投放结构", "成本结构"]),
        alternateLabels: Object.freeze(["付免流量结构", "付费/免费流量", "付费免费流量", "付费/免费", "流量构成", "流量结构"]),
      }),
    });

    async function capturedStructureRecords(expected, endpoint, startIndex) {
      const result = await send("COMP_SITUATION_GET_RECORDS");
      if (!result?.ok) throw new Error(result?.error || "无法读取流量结构请求");
      return automationCore.matchingRecords(result.records || [], expected, {
        startIndex,
        requireCompetitor: true,
        requireUsable: true,
      }).filter((record) => automationCore.canonicalPath(record) === endpoint);
    }

    async function ensureStructureCaptured(expected, structureKey, startIndex, progress, step) {
      ensureNotCancelled();
      const structure = FLOW_STRUCTURES[structureKey];
      if (!structure) throw new Error(`未知流量结构：${structureKey}`);
      setProgress(progress);
      setStatus(step);
      if ((await capturedStructureRecords(expected, structure.endpoint, startIndex)).length) return true;

      await clickLabels(
        structure.alternateLabels,
        progress,
        `近${expected.days}天：先切换另一结构以刷新“${structure.label}”…`,
        null,
        document,
        true,
      );
      const clicked = await clickLabels(structure.labels, progress, step, null, document, true);
      if (!clicked) throw new Error(`未找到“${structure.label}”选项，无法触发 ${structure.endpoint}`);

      const started = Date.now();
      while (Date.now() - started < 20000) {
        ensureNotCancelled();
        if ((await capturedStructureRecords(expected, structure.endpoint, startIndex)).length) {
          await waitForDataSettled({ minimumMs: 700, maximumMs: 12000, quietMs: 900, description: `近${expected.days}天${structure.label}数据` });
          return true;
        }
        await wait(350);
      }
      throw new Error(`已切换“${structure.label}”，但未捕获 ${structure.endpoint}`);
    }

    function findCompetitorCard() {
      for (const title of exactTextNodes("竞争店铺")) {
        const card = title.closest(".mxgc-grid");
        if (card && visible(card)) return card;
      }
      return null;
    }

    function selectedShopCount(card) {
      return (normalizeText(card?.textContent).match(/ID:\s*\d+/g) || []).length;
    }

    function findCompetitorDialog() {
      for (const title of exactTextNodes("添加竞店")) {
        let current = title;
        for (let depth = 0; current && depth < 10; depth += 1, current = current.parentElement) {
          const text = normalizeText(current.textContent);
          const hasSearch = Boolean(current.querySelector('input[placeholder="输入关键词回车搜索店铺"]'));
          const hasFooter = exactTextNodes("确定", current).length > 0 && exactTextNodes("取消", current).length > 0;
          if (text.includes("已添加店铺") && (hasSearch || text.includes("所有店铺")) && hasFooter) return current;
        }
      }
      return null;
    }

    function selectedShopsColumn(dialog) {
      const headings = [...dialog.querySelectorAll("div,span")]
        .filter((node) => visible(node) && /^已添加店铺（\d+\/\d+）$/.test(labelOf(node)))
        .sort((left, right) => left.getBoundingClientRect().width - right.getBoundingClientRect().width);
      return headings[0]?.parentElement?.parentElement || null;
    }

    function selectedColumnHasShop(column, competitorName) {
      return exactTextNodes(competitorName, column || document).length > 0;
    }

    function selectedColumnCount(column) {
      const heading = [...(column?.querySelectorAll("div,span") || [])].find((node) => /^已添加店铺（\d+\/\d+）$/.test(labelOf(node)));
      return Number(labelOf(heading).match(/（(\d+)\//)?.[1] || 0);
    }

    function selectedColumnLimit(column) {
      const heading = [...(column?.querySelectorAll("div,span") || [])].find((node) => /^已添加店铺（\d+\/\d+）$/.test(labelOf(node)));
      return Number(labelOf(heading).match(/\/(\d+)）/)?.[1] || 0);
    }

    function searchResultsColumn(dialog) {
      const searchInput = dialog?.querySelector('input[placeholder="输入关键词回车搜索店铺"]');
      if (!searchInput) return null;
      let current = searchInput.parentElement;
      while (current && current !== dialog) {
        const addLabels = competitorDom.exactVisibleTextElements(current, "添加", { isVisible: renderedTextElement });
        if (addLabels.length > 0) return current;
        current = current.parentElement;
      }
      return dialog;
    }

    function findExactSearchResultAdd(dialog, competitorName) {
      const wanted = normalizeText(competitorName);
      const searchInput = dialog.querySelector('input[placeholder="输入关键词回车搜索店铺"]');
      if (!searchInput || !wanted) return null;
      const resultColumn = searchResultsColumn(dialog);
      if (!resultColumn) return null;
      return competitorDom.findExactRowAction(resultColumn, wanted, "添加", {
        isVisible: renderedTextElement,
        clickTarget: resultActionTarget,
      });
    }

    async function ensureCompetitorSelected(competitorNames, progress) {
      const names = [...new Set((competitorNames || []).map((name) => String(name).trim()).filter(Boolean))];
      if (!names.length) throw new Error("至少填写 1 家竞争店铺");
      if (names.length > 3) throw new Error("竞争店铺最多填写 3 家，请用逗号分隔");
      setProgress(progress);
      setStatus(`确认 ${names.length} 家竞争店铺：${names.join("、")}…`);
      const card = await waitForCondition(findCompetitorCard, 6000, "竞争店铺卡片");
      const cardHasAll = (target) => names.every((name) => exactTextNodes(name, target || document).length > 0);
      if (cardHasAll(card) && selectedShopCount(card) === names.length) {
        setStatus("竞店已选中，等待当前页面数据加载完成…");
        await waitForDataSettled({ minimumMs: 1200, maximumMs: 18000, quietMs: 1000, noActivityGraceMs: 2800, description: "当前竞店页面数据" });
        return card;
      }
      const settings = card.querySelector(".mxgc-grid-header .mxgc-btn-link") || card.querySelector(".mxgc-btn-link");
      if (!settings || !await trustedClick(settings)) throw new Error("无法打开“竞争店铺”右上角设置按钮");
      const dialog = await waitForCondition(findCompetitorDialog, 7000, "“添加竞店”弹窗");
      let selectedColumn = selectedShopsColumn(dialog);
      if (!selectedColumn) throw new Error("“添加竞店”弹窗缺少已添加店铺区域");
      const pageLimit = selectedColumnLimit(selectedColumn);
      if (pageLimit && names.length > pageLimit) throw new Error(`当前页面最多允许选择 ${pageLimit} 家竞争店铺`);

      if (!(names.every((name) => selectedColumnHasShop(selectedColumn, name)) && selectedColumnCount(selectedColumn) === names.length)) {
        const removeAll = textCandidates(["全部删除"], null, selectedColumn, true)[0];
        if (selectedColumnCount(selectedColumn) > 0 && (!removeAll || !await trustedClick(removeAll))) throw new Error("无法清空原有竞争店铺");
        if (removeAll) {
          await waitForCondition(() => {
            const currentDialog = findCompetitorDialog();
            const currentColumn = currentDialog && selectedShopsColumn(currentDialog);
            return currentColumn && selectedColumnCount(currentColumn) === 0 ? currentColumn : null;
          }, 4000, "竞店清空结果");
        }

        for (let index = 0; index < names.length; index += 1) {
          const competitorName = names[index];
          const beforeSearchDialog = findCompetitorDialog();
          const beforeSearchColumn = beforeSearchDialog && selectedShopsColumn(beforeSearchDialog);
          if (!beforeSearchColumn || selectedColumnCount(beforeSearchColumn) !== index) {
            throw new Error(`准备添加第 ${index + 1} 家竞店时，右侧已添加列表状态不一致`);
          }
          let add = null;
          let searchError = null;
          for (let attempt = 1; attempt <= 2 && !add; attempt += 1) {
            const currentDialog = findCompetitorDialog();
            const searchInput = currentDialog?.querySelector('input[placeholder="输入关键词回车搜索店铺"]');
            if (!searchInput) throw new Error("未找到竞店搜索框“输入关键词回车搜索店铺”");
            setStatus(`添加竞争店铺 ${index + 1}/${names.length}：先清空上一个搜索词${attempt > 1 ? "（重试）" : ""}…`);
            if (!await trustedClearInput(searchInput)) throw new Error(`添加“${competitorName}”前未能清空上一个搜索词`);
            const readySearchInput = await waitForCondition(() => {
              const refreshed = findCompetitorDialog();
              const input = refreshed?.querySelector('input[placeholder="输入关键词回车搜索店铺"]');
              return input && input.value === "" ? input : null;
            }, 3000, `添加“${competitorName}”前的空搜索框`);
            setStatus(`添加竞争店铺 ${index + 1}/${names.length}：输入“${competitorName}”并按 Enter${attempt > 1 ? "（重试）" : ""}…`);
            const beforeSearch = await refreshStats();
            if (!await trustedFill(readySearchInput, competitorName, true)) throw new Error(`竞争店铺“${competitorName}”未能独立写入搜索框并回车`);
            try {
              await waitForDataSettled({
                baselineRecords: Number(beforeSearch?.records || 0),
                minimumMs: 650,
                maximumMs: 12000,
                quietMs: 700,
                requireActivity: true,
                allowNoActivity: false,
                description: `竞店“${competitorName}”搜索结果`,
              });
              add = await waitForCondition(() => {
                const refreshed = findCompetitorDialog();
                return refreshed && findExactSearchResultAdd(refreshed, competitorName);
              }, attempt === 1 ? 5000 : 8000, `竞店搜索结果中完全同名的“${competitorName}”`);
            } catch (error) {
              if (cancelRequested) throw error;
              searchError = error;
              if (attempt === 1) setStatus(`“${competitorName}”未出现结果，重新聚焦并按 Enter 搜索…`);
            }
          }
          if (!add) throw searchError || new Error(`搜索结果中未找到店名完全一致的“${competitorName}”，已停止以避免错选`);
          if (!await trustedClick(add)) throw new Error(`无法添加竞争店铺“${competitorName}”`);
          selectedColumn = await waitForCondition(() => {
            const refreshed = findCompetitorDialog();
            const currentColumn = refreshed && selectedShopsColumn(refreshed);
            return currentColumn
              && selectedColumnCount(currentColumn) === index + 1
              && selectedColumnHasShop(currentColumn, competitorName)
              ? currentColumn
              : null;
          }, 10000, `第 ${index + 1} 家竞店“${competitorName}”精确添加状态`);
          setStatus(`第 ${index + 1}/${names.length} 家竞店已加入右侧列表，继续下一家…`);
        }
      }

      const completedDialog = findCompetitorDialog();
      const completedColumn = completedDialog && selectedShopsColumn(completedDialog);
      if (!completedColumn
        || selectedColumnCount(completedColumn) !== names.length
        || !names.every((name) => selectedColumnHasShop(completedColumn, name))) {
        throw new Error(`竞店尚未全部加入右侧列表，已添加 ${selectedColumnCount(completedColumn)}/${names.length} 家`);
      }
      setStatus("竞店已添加，准备确认并等待页面重新加载…");
      const beforeConfirm = await refreshStats();
      const currentDialog = findCompetitorDialog();
      const confirm = currentDialog && textCandidates(["确定"], null, currentDialog, true)[0];
      if (!confirm || !await trustedClick(confirm)) throw new Error("无法确认竞争店铺选择");
      const updatedCard = await waitForCondition(() => {
        const current = findCompetitorCard();
        return current && selectedShopCount(current) === names.length && cardHasAll(current) ? current : null;
      }, 12000, `${names.length} 家竞争店铺回填`);
      if (selectedShopCount(updatedCard) !== names.length) throw new Error(`竞争店铺未保持 ${names.length} 家选择，请重新运行`);
      setStatus(`已确认 ${names.length} 家竞店，等待页面数据加载完成…`);
      await waitForDataSettled({
        baselineRecords: Number(beforeConfirm?.records || 0),
        minimumMs: 1800,
        maximumMs: 25000,
        quietMs: 1100,
        noActivityGraceMs: 5000,
        requireActivity: true,
        description: "竞店切换后的页面数据",
      });
      return updatedCard;
    }

    function portraitShopInputs() {
      const inputs = [...document.querySelectorAll('input:not([type="radio"]):not([type="checkbox"]):not([type="hidden"])')]
        .filter((node) => visible(node) && !host.contains(node));
      const labels = exactTextNodes("请填写店铺id");
      const matched = [];
      for (const label of labels) {
        const labelRect = label.getBoundingClientRect();
        const candidate = inputs.map((input) => {
          const rect = input.getBoundingClientRect();
          const vertical = Math.abs((rect.top + rect.height / 2) - (labelRect.top + labelRect.height / 2));
          const gap = rect.left - labelRect.right;
          return { input, vertical, gap, score: vertical * 10 + Math.abs(gap) };
        }).filter((item) => item.vertical <= 42 && item.gap >= -12 && item.gap <= 900)
          .sort((left, right) => left.score - right.score)[0]?.input;
        if (candidate && !matched.includes(candidate)) matched.push(candidate);
      }
      const ordered = matched.sort((left, right) => left.getBoundingClientRect().left - right.getBoundingClientRect().left);
      if (ordered.length >= 2) return { subject: ordered[0], competitor: ordered.at(-1) };

      const anchor = exactTextNodes("人群画像分析")[0];
      const anchorRect = anchor?.getBoundingClientRect();
      const fallback = inputs.filter((input) => {
        const rect = input.getBoundingClientRect();
        return anchorRect
          && rect.top >= anchorRect.bottom
          && rect.top <= anchorRect.bottom + 420
          && (/^[\d,，、;；\s]+$/.test(input.value) || input.value === "");
      }).sort((left, right) => left.getBoundingClientRect().left - right.getBoundingClientRect().left);
      return fallback.length >= 2 ? { subject: fallback[0], competitor: fallback.at(-1) } : null;
    }

    async function waitForPortraitCapture(shopId, startIndex, position, total, timeoutMs = 30000) {
      const started = Date.now();
      let lastStatus = null;
      while (Date.now() - started < timeoutMs) {
        ensureNotCancelled();
        const result = await send("COMP_SITUATION_GET_RECORDS");
        if (!result?.ok) throw new Error(result?.error || `无法回读竞店 ${shopId} 的画像请求`);
        lastStatus = automationCore.portraitCaptureStatus(result.records || [], shopId, { startIndex });
        if (lastStatus.complete) {
          setStatus(`人群画像 ${position}/${total}：店铺 ID ${shopId} 的六类画像已单独返回。`);
          await waitForDataSettled({
            baselineRecords: Number((result.records || []).length),
            minimumMs: 600,
            maximumMs: 12000,
            quietMs: 800,
            description: `店铺 ID ${shopId} 画像数据`,
          });
          return lastStatus;
        }
        const coverageState = lastStatus.coverageLoaded ? "覆盖规模已返回" : "等待覆盖规模";
        setStatus(`人群画像 ${position}/${total}：等待店铺 ID ${shopId}，${coverageState}，已返回 ${lastStatus.tags.length}/6 个画像维度…`);
        await wait(400);
      }
      const missing = [];
      if (!lastStatus) missing.push("画像请求状态");
      else {
        if (!lastStatus.coverageLoaded) missing.push("覆盖规模接口");
        missing.push(...lastStatus.missingTags.map((tagName) => `${tagName}画像`));
      }
      throw new Error(`店铺 ID ${shopId} 未完成单店画像取数，缺少：${missing.join("、") || "单店画像完成信号"}`);
    }

    async function capturePortraitCompetitors(competitorNames, startProgress, endProgress) {
      const names = automationCore.parseCompetitorNames(competitorNames).slice(0, 3);
      const initialFields = await waitForCondition(portraitShopInputs, 7000, "人群画像店铺 ID 输入框");
      const before = await send("COMP_SITUATION_GET_RECORDS");
      if (!before?.ok) throw new Error(before?.error || "无法读取人群画像对象记录");
      const inputShopIds = automationCore.parseShopIds(initialFields.competitor.value);
      const capturedShopIds = automationCore.portraitCompareShopIds(before.records || []);
      const competitorShopIds = [...new Set([...inputShopIds, ...capturedShopIds])].slice(0, names.length);
      const subjectShopId = automationCore.parseShopIds(initialFields.subject.value)[0] || "";
      if (competitorShopIds.length !== names.length) {
        throw new Error(`人群画像只识别到 ${competitorShopIds.length}/${names.length} 家竞店店铺 ID，请确认“对比对象”已显示全部 ID`);
      }
      const recorded = await send("COMP_SITUATION_RECORD_PORTRAIT_SHOPS", {
        subjectShopId,
        competitorShopIds,
      });
      if (!recorded?.ok) throw new Error(recorded?.error || "无法记录三家竞店画像店铺 ID");

      const span = endProgress - startProgress;
      for (let index = 0; index < competitorShopIds.length; index += 1) {
        const shopId = competitorShopIds[index];
        let captured = null;
        let lastError = null;
        for (let attempt = 1; attempt <= 2 && !captured; attempt += 1) {
          const fields = await waitForCondition(portraitShopInputs, 5000, "人群画像店铺 ID 输入框");
          setProgress(startProgress + span * (index / Math.max(1, competitorShopIds.length)));
          setStatus(`人群画像 ${index + 1}/${competitorShopIds.length}：清空上一个竞店 ID${attempt > 1 ? "（重试）" : ""}…`);
          if (!await trustedClearInput(fields.competitor)) throw new Error(`切换店铺 ID ${shopId} 前未能清空对比对象`);
          const emptyInput = await waitForCondition(() => {
            const current = portraitShopInputs()?.competitor;
            return current && current.value === "" ? current : null;
          }, 3000, `店铺 ID ${shopId} 输入前的空对比对象`);
          const baseline = await send("COMP_SITUATION_GET_RECORDS");
          if (!baseline?.ok) throw new Error(baseline?.error || "无法建立画像取数起点");
          setStatus(`人群画像 ${index + 1}/${competitorShopIds.length}：单独输入店铺 ID ${shopId} 并取数…`);
          if (!await trustedFill(emptyInput, shopId, true)) throw new Error(`店铺 ID ${shopId} 未能独立写入对比对象`);
          const filledInput = await waitForCondition(() => {
            const current = portraitShopInputs()?.competitor;
            return current && current.value === shopId ? current : null;
          }, 3000, `店铺 ID ${shopId} 独立回填`);
          filledInput.dispatchEvent(new Event("change", { bubbles: true }));
          filledInput.blur?.();
          try {
            captured = await waitForPortraitCapture(
              shopId,
              (baseline.records || []).length,
              index + 1,
              competitorShopIds.length,
              attempt === 1 ? 24000 : 32000,
            );
          } catch (error) {
            if (cancelRequested) throw error;
            lastError = error;
          }
        }
        if (!captured) throw lastError || new Error(`店铺 ID ${shopId} 的画像取数失败`);
        setProgress(startProgress + span * ((index + 1) / competitorShopIds.length));
      }
      setStatus(`三家竞店画像已按 ${competitorShopIds.join("、")} 分别取数完成。`);
      return competitorShopIds;
    }

    function rangeRootForLabel(label) {
      const roots = [...document.querySelectorAll(".mxgc-calendar-rangepicker")].filter(visible);
      const labels = exactTextNodes(label);
      let best = null;
      for (const labelNode of labels) {
        const labelRect = labelNode.getBoundingClientRect();
        for (const root of roots) {
          const rect = root.getBoundingClientRect();
          const vertical = Math.abs((rect.top + rect.height / 2) - (labelRect.top + labelRect.height / 2));
          const gap = rect.left - labelRect.right;
          const penalty = vertical * 8 + Math.abs(gap) + (gap < -24 ? 2000 : 0) + (vertical > 64 ? 1200 : 0);
          if (!best || penalty < best.penalty) best = { root, penalty };
        }
      }
      return best?.root || null;
    }

    function rangeTrigger(root) {
      return root?.querySelector(":scope > .mx-trigger") || root?.querySelector(".mx-trigger") || null;
    }

    function rangeControlMatches(label, startDate, endDate) {
      const root = rangeRootForLabel(label);
      const text = labelOf(rangeTrigger(root));
      const startMatches = text.includes(startDate);
      const endMatches = text.includes(endDate) || (text.includes("昨日") && endDate === automationCore.yesterday());
      return startMatches && endMatches ? root : null;
    }

    function visibleRangePopup(root) {
      const direct = root?.id && document.getElementById(`mx_output_${root.id}`);
      if (direct && visible(direct) && direct.querySelectorAll(".mxgc-calendar-datepicker").length >= 2) return direct;
      return [...document.querySelectorAll('[id^="mx_output_"]')]
        .filter((node) => visible(node) && normalizeText(node.textContent).includes("选择日期：") && node.querySelectorAll(".mxgc-calendar-datepicker").length >= 2)
        .at(-1) || null;
    }

    function visibleDatePopup(datePicker) {
      const direct = datePicker?.id && document.getElementById(`mx_output_${datePicker.id}`);
      if (direct && visible(direct) && direct.querySelector('span[title^="20"]')) return direct;
      return [...document.querySelectorAll('[id^="mx_output_"]')]
        .filter((node) => visible(node) && node.querySelector('span[title^="20"]'))
        .at(-1) || null;
    }

    async function chooseDateInRangePopup(rangePopup, pickerIndex, isoDate) {
      let pickers = [...rangePopup.querySelectorAll(".mxgc-calendar-datepicker")].filter(visible);
      const datePicker = pickers[pickerIndex];
      const trigger = datePicker && rangeTrigger(datePicker);
      if (!trigger || !await trustedClick(trigger)) throw new Error(`无法打开${pickerIndex === 0 ? "开始" : "结束"}日期选择器`);
      let calendar = await waitForCondition(() => visibleDatePopup(datePicker), 5000, `${isoDate} 日期面板`);
      const target = automationCore.parseIsoDate(isoDate);
      if (!target) throw new Error(`日期格式无效：${isoDate}`);
      for (let attempt = 0; attempt < 36; attempt += 1) {
        calendar = visibleDatePopup(datePicker) || calendar;
        const cell = calendar.querySelector(`span[title="${isoDate}"]`);
        if (cell && visible(cell)) {
          if (!cell.hasAttribute("mx-click")) throw new Error(`日期 ${isoDate} 不在页面允许范围内`);
          if (!await trustedClick(cell)) throw new Error(`日期 ${isoDate} 点选失败`);
          await wait(260);
          return true;
        }
        const header = [...calendar.querySelectorAll("span")].find((node) => /^\d{4}年\d{2}月$/.test(labelOf(node)));
        if (!header) throw new Error(`无法识别 ${isoDate} 所在月份`);
        const match = labelOf(header).match(/^(\d{4})年(\d{2})月$/);
        const currentIndex = Number(match[1]) * 12 + Number(match[2]) - 1;
        const targetIndex = target.getFullYear() * 12 + target.getMonth();
        const children = [...header.parentElement.children].filter((node) => node.hasAttribute?.("mx-click"));
        const headerIndex = children.indexOf(header);
        const monthButton = targetIndex < currentIndex ? children[headerIndex - 1] : children[headerIndex + 1];
        if (!monthButton || !await trustedClick(monthButton)) throw new Error(`无法翻页到 ${isoDate} 所在月份`);
        await wait(180);
      }
      throw new Error(`日期 ${isoDate} 超出可自动选择范围`);
    }

    async function setRangeControl(label, startDate, endDate, progress) {
      setProgress(progress);
      setStatus(`${label}：${startDate} 至 ${endDate}…`);
      const root = await waitForCondition(() => rangeRootForLabel(label), 5000, `“${label}”控件`);
      const trigger = rangeTrigger(root);
      if (!trigger || !await trustedClick(trigger)) throw new Error(`无法打开“${label}”`);
      let popup = await waitForCondition(() => visibleRangePopup(root), 5000, `“${label}”日期弹窗`);
      await chooseDateInRangePopup(popup, 0, startDate);
      popup = await waitForCondition(() => visibleRangePopup(root), 3000, `“${label}”开始日期回填`);
      await chooseDateInRangePopup(popup, 1, endDate);
      popup = await waitForCondition(() => visibleRangePopup(root), 3000, `“${label}”结束日期回填`);
      const confirm = textCandidates(["确定"], null, popup, true)[0];
      const beforeConfirm = await refreshStats();
      if (!confirm || !await trustedClick(confirm)) throw new Error(`无法确认“${label}”`);
      await waitForCondition(() => rangeControlMatches(label, startDate, endDate), 7000, `“${label}”日期回填`);
      setStatus(`${label}已修改，等待页面数据加载完成…`);
      await waitForDataSettled({
        baselineRecords: Number(beforeConfirm?.records || 0),
        minimumMs: 1600,
        maximumMs: 25000,
        quietMs: 1100,
        noActivityGraceMs: 4200,
        requireActivity: true,
        description: `${label}修改后的页面数据`,
      });
    }

    async function latestBusinessDate() {
      const result = await send("COMP_SITUATION_GET_RECORDS");
      if (!result?.ok) throw new Error(result?.error || "无法读取当前业务日期");
      const fromRecords = automationCore.latestBusinessEndDate(result.records || [], "");
      if (fromRecords) return fromRecords;
      const analysisRoot = rangeRootForLabel("分析周期");
      const text = labelOf(rangeTrigger(analysisRoot));
      const explicitDates = text.match(/\d{4}-\d{2}-\d{2}/g) || [];
      if (explicitDates.length >= 2) return explicitDates.at(-1);
      if (text.includes("昨日")) return automationCore.yesterday();
      return automationCore.yesterday();
    }

    async function selectPeriod(days, progress, latestDate) {
      const expected = automationCore.customPeriod(days, latestDate);
      if (!expected) throw new Error(`无法计算近${days}天自定义周期`);
      const before = await send("COMP_SITUATION_GET_RECORDS");
      const startIndex = before?.ok ? (before.records || []).length : 0;
      setPeriodState(`近${days}天设置中`, "warn");
      await setRangeControl("分析周期", expected.beginDate, expected.endDate, progress);
      await setRangeControl("对比周期", expected.peerBeginDate, expected.peerEndDate, progress + 2);
      setStatus(`近${days}天周期已设置，等待最终口径数据稳定…`);
      await waitForDataSettled({ minimumMs: 900, maximumMs: 15000, quietMs: 1000, noActivityGraceMs: 2400, description: `近${days}天周期数据` });
      return { expected, startIndex };
    }

    async function verifyCapturedPeriod(expected, startIndex) {
      const started = Date.now();
      let lastSeen = null;
      const minimumCompetitors = automationCore.parseCompetitorNames(competitorInputNode.value).slice(0, 3).length;
      while (Date.now() - started < 22000) {
        ensureNotCancelled();
        const result = await send("COMP_SITUATION_GET_RECORDS");
        if (!result?.ok) throw new Error(result?.error || "无法回读周期请求");
        const records = result.records || [];
        const recent = automationCore.matchingRecords(records, expected, {
          startIndex,
          requireCompetitor: true,
          requireUsable: true,
          minimumCompetitors,
        });
        if (recent.length) {
          setStatus(`近${expected.days}天业务响应已返回，等待同批接口全部完成…`);
          await waitForDataSettled({ minimumMs: 700, maximumMs: 15000, quietMs: 1000, description: `近${expected.days}天业务数据` });
          return recent;
        }
        const competitionRecords = records.filter(automationCore.isCompetitionAnalysisRecord);
        lastSeen = competitionRecords.length ? automationCore.requestOfRecord(competitionRecords.at(-1)) : null;
        await wait(350);
      }
      const seenText = lastSeen
        ? `${lastSeen.beginDate || "—"}~${lastSeen.endDate || "—"} / ${lastSeen.peerBeginDate || "—"}~${lastSeen.peerEndDate || "—"} / competitorIds=${automationCore.competitorTokens(lastSeen).length}`
        : "尚未捕获竞争态势业务请求";
      throw new Error(`周期接口校验失败：期望 ${expected.beginDate}~${expected.endDate}，对比 ${expected.peerBeginDate}~${expected.peerEndDate}；实际 ${seenText}`);
    }

    async function collectPeriod(days, startProgress, endProgress, latestDate, competitorNames) {
      const span = endProgress - startProgress;
      const { expected, startIndex } = await selectPeriod(days, startProgress, latestDate);
      await clickLabels(["基础分析", "基础指标", "基础表现"], startProgress + span * 0.18, `近${days}天：采集基础分析…`);
      await verifyCapturedPeriod(expected, startIndex);
      setPeriodState(`${days}天 ${expected.beginDate}~${expected.endDate}`, "good");
      await clickLabels(["流量分析", "流量来源分析", "流量来源"], startProgress + span * 0.34, `近${days}天：进入流量分析…`);
      await ensureAttributionCaptured(expected, 2, startIndex, startProgress + span * 0.46, `近${days}天：采集并校验广告域渠道…`);
      await ensureStructureCaptured(expected, "paidFree", startIndex, startProgress + span * 0.57, `近${days}天：采集并校验付免流量结构…`);
      await ensureStructureCaptured(expected, "investor", startIndex, startProgress + span * 0.68, `近${days}天：采集并校验无界投资结构…`);
      if (days === 30) await ensureAttributionCaptured(expected, 1, startIndex, startProgress + span * 0.78, "近30天：采集并校验全域渠道…");
      const portraitOpened = await clickLabels(["客群分析", "人群分析", "人群画像"], startProgress + span * 0.88, `近${days}天：采集人群画像…`);
      if (days === 30) {
        if (!portraitOpened && !portraitShopInputs()) throw new Error("未能进入人群画像模块");
        await capturePortraitCompetitors(competitorNames, startProgress + span * 0.9, endProgress);
      }
      setProgress(endProgress);
    }

    async function publishOnlineReport(report = lastReport) {
      const current = report || (await buildCurrentReport()).report;
      try {
        await archiveReportToOfficialCenter(current, { openReport: true });
      } catch (error) {
        lastArchive = { ok: false, error: String(error?.message || error) };
      }
      return current;
    }

    function downloadAuthorizedExcel(current, authorization) {
      if (authorization?.authorized !== true) throw new Error("官网未授权本次内部导出");
      if (!current.quality?.exportAllowed) throw new Error(`业务数据未完整：${current.quality?.blockingIssues?.slice(0, 3).join("；") || "请检查页面模块"}`);
      const bytes = writer.buildXlsx(current);
      downloadBlob(`达摩盘竞争态势分析报告_${fileStamp()}.xlsx`, bytes, writer.MIME_TYPE);
      return current;
    }

    async function authorizeAndDownloadInternalExport() {
      if (internalExportDownloadPending) return;
      internalExportDownloadPending = true;
      hideInternalExport();
      setStatus("正在校验报告并申请本次内部导出…");
      try {
        const current = lastReport || (await buildCurrentReport()).report;
        if (!current?.quality?.exportAllowed) {
          throw new Error(`业务数据未完整：${current?.quality?.blockingIssues?.slice(0, 3).join("；") || "请检查页面模块"}`);
        }
        const archived = await archiveReportToOfficialCenter(current, { force: true });
        const result = await send("DMP_CDP_AUTHORIZE_REPORT_EXPORT", {
          reportId: archived.reportId,
          reportType: "competition",
          format: "xlsx",
          clientVersion: EXTENSION_VERSION
        });
        if (!result?.ok || result?.authorization?.authorized !== true) {
          throw new Error(result?.error || "官网未授权本次内部导出");
        }
        downloadAuthorizedExcel(current, result.authorization);
        setStatus("内部表格已下载；本次导出入口已关闭。");
      } catch (error) {
        setStatus(String(error?.message || error), true);
      } finally {
        internalExportDownloadPending = false;
      }
    }

    function missingAttributionTasks(report = lastReport) {
      const scaleByLabel = { 全域归因: 1, 广告域归因: 2 };
      const tasks = [];
      for (const issue of report?.quality?.blockingIssues || []) {
        const match = String(issue).match(/^缺少近(7|30)天(全域归因|广告域归因)渠道指标$/);
        if (match) tasks.push({ days: Number(match[1]), scale: scaleByLabel[match[2]], label: match[2] });
      }
      return tasks;
    }

    function missingStructureTasks(report = lastReport) {
      const tasks = new Map();
      const add = (days, structureKey) => {
        const structure = FLOW_STRUCTURES[structureKey];
        if (structure) tasks.set(`${days}|${structureKey}`, { days, structureKey, label: structure.label });
      };
      const missingEndpoints = new Set(report?.quality?.missingEndpoints || []);
      for (const [structureKey, structure] of Object.entries(FLOW_STRUCTURES)) {
        if (missingEndpoints.has(structure.endpoint)) add(30, structureKey);
      }
      for (const issue of report?.quality?.blockingIssues || []) {
        const match = String(issue).match(/^缺少近(7|30)天流量\/投放结构$/);
        if (!match) continue;
        add(Number(match[1]), "paidFree");
        add(Number(match[1]), "investor");
      }
      return [...tasks.values()];
    }

    async function recaptureFlowTasks(attributionTasks, structureTasks) {
      if (automationRunning || (!attributionTasks.length && !structureTasks.length)) return;
      automationRunning = true;
      cancelRequested = false;
      setBusy(true);
      setJobState("流量补采中", "warn");
      const originalScroll = { x: scrollX, y: scrollY };
      try {
        setStatus("恢复监听并补采缺失渠道与流量结构…");
        const competitorNames = automationCore.parseCompetitorNames(competitorInputNode.value);
        const competitorName = competitorNames.join("，");
        const started = await send("COMP_SITUATION_START", { reset: false, note: competitorName, competitorName, competitorNames });
        if (!started?.ok) throw new Error(started?.error || "无法继续采集");
        applyStats(started.stats);
        const latestDate = await latestBusinessDate();
        const grouped = new Map();
        for (const task of attributionTasks) {
          if (!grouped.has(task.days)) grouped.set(task.days, { attribution: [], structures: [] });
          grouped.get(task.days).attribution.push(task);
        }
        for (const task of structureTasks) {
          if (!grouped.has(task.days)) grouped.set(task.days, { attribution: [], structures: [] });
          grouped.get(task.days).structures.push(task);
        }
        let taskIndex = 0;
        for (const [days, periodTasks] of grouped) {
          const baseProgress = 8 + taskIndex * (74 / Math.max(1, grouped.size));
          const { expected, startIndex } = await selectPeriod(days, baseProgress, latestDate);
          await clickLabels(["流量分析", "流量来源分析", "流量来源"], baseProgress + 8, `近${days}天：进入流量分析…`);
          for (const task of periodTasks.attribution) {
            await ensureAttributionCaptured(expected, task.scale, startIndex, baseProgress + 20, `近${days}天：补采并校验${task.label}渠道…`);
          }
          for (const task of periodTasks.structures) {
            await ensureStructureCaptured(expected, task.structureKey, startIndex, baseProgress + 34, `近${days}天：补采并校验${task.label}…`);
          }
          taskIndex += 1;
        }
        await waitForDataSettled({ minimumMs: 1200, maximumMs: 20000, quietMs: 1100, description: "流量补采接口" });
        const stopped = await send("COMP_SITUATION_STOP");
        if (stopped?.stats) applyStats(stopped.stats);
        setProgress(94);
        const { report } = await buildCurrentReport();
        if (!report.quality?.exportAllowed) {
          try {
            await archiveReportToOfficialCenter(report);
          } catch (error) {
            lastArchive = { ok: false, error: String(error?.message || error) };
          }
          setStatus(lastArchive?.ok
            ? "渠道与流量结构已补采；部分报告已保存到官网，请继续按提示补采。"
            : "渠道与流量结构已补采，仍有其他缺项，请继续按提示补采。", !lastArchive?.ok);
          return;
        }
        setStatus("缺失流量数据已补齐，正在保存并打开官网 HTML 报告…");
        await publishOnlineReport(report);
        setProgress(100);
        setStatus(lastArchive?.ok
          ? lastArchive.opened ? "缺失数据已补齐，官网 HTML 报告已在新窗口打开。" : "报告已保存到官网，可点击“打开官网 HTML”重试。"
          : "数据已补齐，但官网报告保存失败，请稍后重试。", !lastArchive?.ok);
      } catch (error) {
        await send("COMP_SITUATION_STOP");
        setStatus(String(error?.message || error), true);
      } finally {
        automationRunning = false;
        setBusy(false);
        scrollTo(originalScroll.x, originalScroll.y);
      }
    }

    async function runAutomation() {
      if (automationRunning) return;
      if (!location.hash.includes("compete-situation")) {
        setStatus("请先打开达摩盘“竞争态势分析”页面。", true);
        return;
      }
      const competitorNames = automationCore.parseCompetitorNames(competitorInputNode.value);
      if (!competitorNames.length) {
      setStatus("请填写 1–3 个竞店搜索词，多家用逗号分隔。", true);
        competitorInputNode.focus();
        return;
      }
      if (competitorNames.length > 3) {
        setStatus("竞争店铺最多填写 3 家，请删除多余名称。", true);
        competitorInputNode.focus();
        return;
      }
      const competitorName = competitorNames.join("，");
      competitorInputNode.value = competitorName;
      await chrome.storage.local.set({ [COMPETITOR_STORAGE_KEY]: competitorName });
      automationRunning = true;
      cancelRequested = false;
      lastReport = null;
      lastArchive = null;
      hideInternalExport();
      setBusy(true);
      setProgress(2);
      previewQualityNode.textContent = "运行中";
      previewQualityNode.style.color = "#ffd66b";
      setPeriodState("周期待设置", "warn");
      const originalScroll = { x: scrollX, y: scrollY };
      try {
        setStatus("建立全量接口采集通道…");
        const started = await send("COMP_SITUATION_START", { reset: true, note: competitorName, competitorName, competitorNames });
        if (!started?.ok) throw new Error(started?.error || "无法开始采集，请刷新达摩盘页面后重试");
        applyStats(started.stats);
        await waitForDataSettled({ minimumMs: 1200, maximumMs: 15000, quietMs: 1000, noActivityGraceMs: 2800, description: "初始页面数据" });
        await ensureCompetitorSelected(competitorNames, 8);
        const latestDate = await latestBusinessDate();
        setPeriodState(`数据截止 ${latestDate}`);
        await collectPeriod(7, 12, 47, latestDate, competitorNames);
        await collectPeriod(30, 49, 86, latestDate, competitorNames);
        setProgress(90);
        setStatus("等待最后一批接口落库…");
        await waitForDataSettled({ minimumMs: 1400, maximumMs: 25000, quietMs: 1200, description: "最后一批接口" });
        const stopped = await send("COMP_SITUATION_STOP");
        if (stopped?.stats) applyStats(stopped.stats);
        setProgress(94);
        setStatus("校验接口、周期、渠道和画像完整性…");
        const { report } = await buildCurrentReport();
        if (!report.quality?.exportAllowed) {
          setProgress(96);
          try {
            await archiveReportToOfficialCenter(report);
          } catch (error) {
            lastArchive = { ok: false, error: String(error?.message || error) };
          }
          setStatus(lastArchive?.ok
            ? "自动遍历已完成；部分报告已保存到官网，可按提示继续补采。"
            : "自动遍历已完成，但仍有缺项。可按提示手动补采后再生成报告。", !lastArchive?.ok);
          return;
        }
        setStatus("数据完整，正在保存并打开官网 HTML 报告…");
        await publishOnlineReport(report);
        setProgress(100);
        setStatus(lastArchive?.ok
          ? lastArchive.opened ? "已完成，官网 HTML 报告已在新窗口打开。" : "报告已保存到官网，可点击“打开官网 HTML”重试。"
          : "数据已完成，但官网报告保存失败，请确认官网登录与授权后重试。", !lastArchive?.ok);
      } catch (error) {
        await send("COMP_SITUATION_STOP");
        setPeriodState("选择或校验失败", "bad");
        setStatus(String(error?.message || error), true);
      } finally {
        automationRunning = false;
        setBusy(false);
        scrollTo(originalScroll.x, originalScroll.y);
      }
    }

    get("[data-run]").addEventListener("click", () => void runAutomation());

    modeSwitchNode.value = unifiedMode.current;
    modeSwitchNode.addEventListener("change", async () => {
      const requested = modeSwitchNode.value;
      if (automationRunning) {
        modeSwitchNode.value = unifiedMode.current;
        setStatus("当前取数正在运行，请停止后再切换模式。", true);
        return;
      }
      modeSwitchNode.disabled = true;
      setStatus("正在切换取数模式…");
      await unifiedMode.switchTo(requested);
    });

    get("[data-manual]").addEventListener("click", async () => {
      const attributionTasks = missingAttributionTasks();
      const structureTasks = missingStructureTasks();
      if (attributionTasks.length || structureTasks.length) {
        await recaptureFlowTasks(attributionTasks, structureTasks);
        return;
      }
      setStatus("正在恢复采集通道…");
      const competitorNames = automationCore.parseCompetitorNames(competitorInputNode.value).slice(0, 3);
      const competitorName = competitorNames.join("，");
      const result = await send("COMP_SITUATION_START", { reset: false, note: competitorName, competitorName, competitorNames });
      if (!result?.ok) return setStatus(result?.error || "无法继续采集", true);
      applyStats(result.stats);
      setBusy(true);
      setJobState("手动补采中", "warn");
      setStatus("已继续采集。请打开缺失模块；若目标选项已显示，请先切到另一项再切回来，随后停止并检查。" );
    });

    get("[data-stop]").addEventListener("click", async () => {
      cancelRequested = true;
      const result = await send("COMP_SITUATION_STOP");
      if (result?.stats) applyStats(result.stats);
      if (!automationRunning) {
        setBusy(false);
        setJobState(result?.ok ? "采集已停止" : "停止失败", result?.ok ? "" : "bad");
      }
      setStatus(result?.ok ? "已停止采集，当前记录已保留。" : (result?.error || "停止失败"), !result?.ok);
    });

    get("[data-check]").addEventListener("click", async () => {
      setStatus("正在检查业务数据完整性…");
      try {
        const { report } = await buildCurrentReport();
        try {
          await archiveReportToOfficialCenter(report);
        } catch (error) {
          lastArchive = { ok: false, error: String(error?.message || error) };
        }
        setStatus(report.quality.complete
          ? lastArchive?.ok ? "数据完整，报告已保存到官网。" : "数据完整，官网保存暂未完成。"
          : lastArchive?.ok ? "部分报告已保存到官网；数据尚未完整，请按下方提示补采。" : "数据尚未完整，请按下方提示补采。",
        !lastArchive?.ok);
      } catch (error) { setStatus(String(error?.message || error), true); }
    });

    get("[data-online]").addEventListener("click", async () => {
      const reportId = lastArchive?.reportId;
      if (!reportId) return;
      get("[data-online]").disabled = true;
      const result = await send("DMP_CDP_OPEN_REPORT", { reportId });
      setStatus(result?.ok ? "官网 HTML 报告已在新窗口打开。" : (result?.error || "官网报告打开失败，请重试。"), !result?.ok);
      if (!automationRunning) get("[data-online]").disabled = false;
    });

    get("[data-share]").addEventListener("click", async () => {
      setStatus("正在生成官网公开只读链接…");
      get("[data-share]").disabled = true;
      try {
        await createOnlineShare();
        setStatus("官网公开只读链接已复制；任何拿到链接的人均可直接打开。" );
      } catch (error) {
        setStatus(String(error?.message || error), true);
      } finally {
        if (!automationRunning && lastReport?.quality?.complete) get("[data-share]").disabled = false;
      }
    });

    get("[data-history]").addEventListener("click", async () => {
      const result = await send("DMP_CDP_OPEN_REPORT_CENTER");
      setStatus(result?.ok ? "已打开官网历史报告中心。" : (result?.error || "历史报告中心打开失败。"), !result?.ok);
    });

    previewTableNode.addEventListener("change", () => {
      if (lastReport) renderSelectedTable(lastReport, previewTableNode.value);
    });

    competitorInputNode.addEventListener("change", () => {
      void chrome.storage.local.set({ [COMPETITOR_STORAGE_KEY]: competitorInputNode.value.trim() });
    });

    window.addEventListener("keydown", (event) => {
      if (event.repeat || event.ctrlKey || event.metaKey) return;
      if (event.altKey && event.shiftKey && event.code === "KeyD") {
        event.preventDefault();
        void unlockInternalExport();
      }
    }, true);

    statusNode.addEventListener("click", () => {
      const now = Date.now();
      statusClickTimes = statusClickTimes.filter((timestamp) => now - timestamp <= INTERNAL_EXPORT_TRIPLE_CLICK_MS);
      statusClickTimes.push(now);
      if (statusClickTimes.length < 3) return;
      statusClickTimes = [];
      void unlockInternalExport();
    });

    get("[data-collapse]").addEventListener("click", () => {
      collapsed = !collapsed;
      get("[data-body]").style.display = collapsed ? "none" : "block";
      get("[data-collapse]").textContent = collapsed ? "+" : "—";
      get("[data-panel]").classList.toggle("collapsed", collapsed);
    });
    chrome.runtime.onMessage.addListener((message) => {
      if (message?.type !== "COMP_SITUATION_STATUS") return;
      if (message.record) scheduleStats();
      if (message.message && !automationRunning) setStatus(message.message);
    });
    setBusy(false);
    void chrome.storage.local.get(COMPETITOR_STORAGE_KEY).then((stored) => {
      if (!competitorInputNode.value.trim() && stored?.[COMPETITOR_STORAGE_KEY]) competitorInputNode.value = String(stored[COMPETITOR_STORAGE_KEY]);
    });
    void refreshStats();
  }

  if (document.documentElement) mount();
  else document.addEventListener("readystatechange", mount, { once: true });
})();
