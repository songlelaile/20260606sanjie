(function initDmpTrackEngine(root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.DmpTrackEngine = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function createDmpTrackEngine() {
  "use strict";

  const ENDPOINTS = Object.freeze({
    properties: "/api/subdivide/market/item/properties",
    dateRange: "/api/subdivide/market/date/range",
    priceRange: "/api/subdivide/market/item/price/range",
    growth: "/api/subdivide/market/item/growth",
    chance: "/api/subdivide/market/item/chance",
    trackList: "/api/subdivide/market/item/track/list",
    trackDetail: "/api/subdivide/market/item/track/detail"
  });
  const SCORE_FIELDS = Object.freeze(["aScore", "bScore", "cScore", "dScore", "eScore"]);
  const CHANCE_FIELDS = Object.freeze(["code", "title", "tag", "description"]);
  const TRACK_DETAIL_FIELDS = Object.freeze([
    "schCnt", "schCntPop", "alipayCnt", "alipayCntPop", "newCustCnt", "newCustCntPop",
    "saleCnt", "saleCntPop", "concentration", "concentrationJudge", "dtcRatio", "dtcRatioJudge"
  ]);
  const SHOP_DETAIL_FIELDS = Object.freeze([
    "alipayAmt", "alipayAmtPop", "alipayAmtRank", "alipayAmtRankPop",
    "alipayCnt", "alipayCntPop", "saleCnt", "saleCntPop"
  ]);
  const CROWD_FIELDS = Object.freeze(["gender", "age", "city_level", "pp_level"]);
  const STRUCTURE_FIELDS = Object.freeze([
    "marketSceneName", "costZb", "clk", "clkPop", "ctr", "ctrPop", "cvr", "cvrPop", "roi", "roiPop"
  ]);
  const DETAIL_FIELDS = Object.freeze([...new Set([...TRACK_DETAIL_FIELDS, ...SHOP_DETAIL_FIELDS])]);
  const BUSINESS_KEYS = new Set(["cateId", "periodType", "date", "propertyId", "chanceCode", "trackId"]);
  const SENSITIVE_KEY = /(?:token|csrf|cookie|authorization|password|secret|(?:^|[_-])sign(?:ature|data)?$|session|dynamicToken|webOpSessionId|uniqueItemCampaign)/i;

  function hasOwn(value, key) {
    return Boolean(value && Object.prototype.hasOwnProperty.call(value, key));
  }

  function isPlainObject(value) {
    return Boolean(value && typeof value === "object" && !Array.isArray(value));
  }

  function hasUnknownField(value, allowed) {
    if (!isPlainObject(value)) return true;
    const allowedSet = allowed instanceof Set ? allowed : new Set(allowed);
    return Object.keys(value).some(key => !allowedSet.has(key) || SENSITIVE_KEY.test(key));
  }

  function copyOptionalPrimitive(target, source, key, maxLength = 500) {
    if (!hasOwn(source, key)) return true;
    const value = source[key];
    if (value == null || typeof value === "boolean") {
      target[key] = value;
      return true;
    }
    if (typeof value === "number") {
      if (!Number.isFinite(value)) return false;
      target[key] = value;
      return true;
    }
    if (typeof value === "string") {
      target[key] = cleanText(value, maxLength);
      return true;
    }
    return false;
  }

  function sanitizeInsightValue(value, depth = 0, state = { nodes: 0, seen: new WeakSet() }) {
    state.nodes += 1;
    if (state.nodes > 2_000 || depth > 8) return { ok: false };
    if (value == null || typeof value === "boolean") return { ok: true, value };
    if (typeof value === "number") return Number.isFinite(value) ? { ok: true, value } : { ok: false };
    if (typeof value === "string") return { ok: true, value: cleanText(value, 4_000) };
    if (!value || typeof value !== "object" || state.seen.has(value)) return { ok: false };
    state.seen.add(value);
    if (Array.isArray(value)) {
      if (value.length > 500) return { ok: false };
      const output = [];
      for (const child of value) {
        const parsed = sanitizeInsightValue(child, depth + 1, state);
        if (!parsed.ok) return { ok: false };
        output.push(parsed.value);
      }
      return { ok: true, value: output };
    }
    if (!isPlainObject(value)) return { ok: false };
    const entries = Object.entries(value);
    if (entries.length > 500) return { ok: false };
    const output = {};
    for (const [key, child] of entries) {
      if (!key || key.length > 120 || SENSITIVE_KEY.test(key) || ["__proto__", "prototype", "constructor"].includes(key)) {
        return { ok: false };
      }
      const parsed = sanitizeInsightValue(child, depth + 1, state);
      if (!parsed.ok) return { ok: false };
      output[key] = parsed.value;
    }
    return { ok: true, value: output };
  }

  function canonicalPath(value) {
    let pathname = String(value || "");
    try { pathname = new URL(pathname, "https://dmp.taobao.com").pathname; } catch {}
    return pathname.replace(/^\/api_2\//, "/api/").replace(/\.json$/, "").replace(/\/+$/, "");
  }

  function recordPath(record) {
    return canonicalPath(record?.canonicalPath || record?.pathname || record?.request?.url || record?.requestUrl || record?.url || "");
  }

  function parseJsonText(value) {
    if (value && typeof value === "object") return value;
    let text = typeof value === "string" ? value.trim() : "";
    if (!text) return null;
    const fenced = text.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);
    if (fenced) text = fenced[1];
    for (let depth = 0; depth < 3; depth += 1) {
      try {
        const parsed = JSON.parse(text);
        if (typeof parsed === "string") { text = parsed.trim(); continue; }
        return parsed;
      } catch {}
      const jsonp = text.match(/^[\w$.[\]]+\s*\(([\s\S]*)\)\s*;?\s*$/);
      if (!jsonp) break;
      text = jsonp[1].trim();
    }
    return null;
  }

  function parseResponse(record) {
    return parseJsonText(record?.body ?? record?.responseBody ?? record?.response?.body ?? record?.response?.content?.text);
  }

  function requestPayload(record) {
    const candidates = [
      record?.requestBody,
      record?.requestPostData,
      record?.request?.postData,
      record?.postData
    ];
    for (const candidate of candidates) {
      const parsed = parseJsonText(candidate);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) return parsed;
      if (typeof candidate !== "string" || !candidate.trim()) continue;
      try {
        const params = new URLSearchParams(candidate);
        if (params.size) return Object.fromEntries(params);
      } catch {}
    }
    return null;
  }

  function requestBusiness(record) {
    const output = {};
    try {
      const url = new URL(record?.request?.url || record?.requestUrl || record?.url || "", "https://dmp.taobao.com");
      for (const [key, value] of url.searchParams) {
        if (BUSINESS_KEYS.has(key) && !SENSITIVE_KEY.test(key)) output[key] = value;
      }
    } catch {}
    const visit = (value, depth = 0) => {
      if (!value || typeof value !== "object" || depth > 5) return;
      if (Array.isArray(value)) {
        for (const child of value) visit(child, depth + 1);
        return;
      }
      for (const [key, child] of Object.entries(value)) {
        if (BUSINESS_KEYS.has(key) && !SENSITIVE_KEY.test(key) && (typeof child === "string" || typeof child === "number")) {
          output[key] = child;
        } else if (child && typeof child === "object") visit(child, depth + 1);
      }
    };
    visit(requestPayload(record));
    return output;
  }

  function cleanText(value, maxLength = 500) {
    return String(value ?? "")
      .replace(/<br\s*\/?\s*>/gi, "\n")
      .replace(/<[^>]*>/g, "")
      .replace(/&nbsp;/gi, " ")
      .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, "")
      .trim()
      .slice(0, maxLength);
  }

  function normalizeBand(value) {
    return cleanText(value).replace(/[\uffe5\u00a5,\uff0c\s]/g, "").replace(/\.0(?=~|\u4ee5\u4e0a|$)/g, "").replace(/[\uff5e～–—]/g, "~");
  }

  function normalizeDate(value) {
    const digits = String(value || "").replace(/\D/g, "");
    if (!/^20\d{6}$/.test(digits)) return "";
    const date = `${digits.slice(0, 4)}-${digits.slice(4, 6)}-${digits.slice(6, 8)}`;
    try { return new Date(`${date}T00:00:00Z`).toISOString().slice(0, 10) === date ? date : ""; } catch { return ""; }
  }

  function validCateId(value) {
    const text = String(value ?? "").trim();
    return /^\d{1,20}$/.test(text) ? text : "";
  }

  function scalarId(value) {
    const text = String(value ?? "").trim();
    return text && text.length <= 100 && !/[\u0000-\u001f\u007f]/.test(text) ? text : "";
  }

  function firstOwn(value, keys) {
    for (const key of keys) if (hasOwn(value, key)) return value[key];
    return undefined;
  }

  function parsePropertyValue(entry) {
    if (typeof entry === "string" || typeof entry === "number") {
      const name = cleanText(entry);
      return name ? { id: "", name } : null;
    }
    if (!entry || typeof entry !== "object" || Array.isArray(entry)) return null;
    const allowed = new Set(["propertyValueId", "propertyValueName", "valueId", "valueName", "id", "name", "value"]);
    if (Object.keys(entry).some(key => !allowed.has(key) || SENSITIVE_KEY.test(key))) return null;
    const id = scalarId(firstOwn(entry, ["propertyValueId", "valueId", "id"]));
    const name = cleanText(firstOwn(entry, ["propertyValueName", "valueName", "name", "value"]));
    return name ? { id, name } : null;
  }

  function parseProperties(record, response) {
    const request = requestBusiness(record);
    const cateId = validCateId(request.cateId);
    const data = response?.data;
    const list = Array.isArray(data?.list) ? data.list
      : Array.isArray(data?.properties) ? data.properties
        : Array.isArray(data?.propertyList) ? data.propertyList
          : null;
    if (!cateId || !list) return { ok: false, reason: "response-shape-not-recognized" };
    const properties = [];
    for (const entry of list) {
      if (!entry || typeof entry !== "object" || Array.isArray(entry)) return { ok: false, reason: "properties-entry-invalid" };
      const allowed = new Set([
        "propertyId", "propertyName", "propertyValues", "propertyValueList",
        "propId", "propName", "values", "valueList", "id", "name"
      ]);
      if (Object.keys(entry).some(key => !allowed.has(key) || SENSITIVE_KEY.test(key))) return { ok: false, reason: "properties-unmapped-field" };
      const propertyId = scalarId(firstOwn(entry, ["propertyId", "propId", "id"]));
      const propertyName = cleanText(firstOwn(entry, ["propertyName", "propName", "name"]));
      const rawValues = firstOwn(entry, ["propertyValues", "propertyValueList", "values", "valueList"]);
      if (!propertyId || !propertyName || !Array.isArray(rawValues)) return { ok: false, reason: "properties-entry-invalid" };
      const propertyValues = rawValues.map(parsePropertyValue);
      if (propertyValues.some(value => !value)) return { ok: false, reason: "property-value-invalid" };
      const seenNames = new Set();
      const deduped = propertyValues.filter(value => {
        if (seenNames.has(value.name)) return false;
        seenNames.add(value.name);
        return true;
      });
      properties.push({ propertyId, propertyName, propertyValues: deduped });
    }
    return { ok: true, value: { cateId, properties } };
  }

  function parseDateRange(record, response) {
    const request = requestBusiness(record);
    const periodType = scalarId(request.periodType);
    const date = normalizeDate(request.date);
    const data = response?.data;
    if (!periodType || !date || !data || typeof data !== "object" || Array.isArray(data)) return { ok: false, reason: "response-shape-not-recognized" };
    const startDate = normalizeDate(data.startDate);
    const endDate = normalizeDate(data.endDate);
    const compareStartDate = normalizeDate(data.compareStartDate);
    const compareEndDate = normalizeDate(data.compareEndDate);
    if (!startDate || !endDate || startDate > endDate) return { ok: false, reason: "date-range-invalid" };
    if ((compareStartDate && !compareEndDate) || (!compareStartDate && compareEndDate) || (compareStartDate && compareStartDate > compareEndDate)) {
      return { ok: false, reason: "compare-date-range-invalid" };
    }
    return { ok: true, value: { periodType, date, startDate, endDate, compareStartDate, compareEndDate } };
  }

  function parsePriceRanges(record, response) {
    const cateId = validCateId(requestBusiness(record).cateId);
    const list = response?.data?.list;
    if (!cateId || !Array.isArray(list)) return { ok: false, reason: "response-shape-not-recognized" };
    const priceRanges = [];
    for (const entry of list) {
      const allowed = new Set(["priceRangeName", "minPrice", "maxPrice", "priceRangeId"]);
      if (!entry || typeof entry !== "object" || Array.isArray(entry) || Object.keys(entry).some(key => !allowed.has(key) || SENSITIVE_KEY.test(key))) {
        return { ok: false, reason: "price-range-unmapped-field" };
      }
      const name = normalizeBand(entry.priceRangeName);
      const minPrice = typeof entry.minPrice === "number" && Number.isFinite(entry.minPrice) ? entry.minPrice : null;
      const maxPrice = typeof entry.maxPrice === "number" && Number.isFinite(entry.maxPrice) ? entry.maxPrice : null;
      const id = scalarId(entry.priceRangeId);
      const openEnded = /\u4ee5\u4e0a$/.test(name) || (Number.isFinite(maxPrice) && maxPrice >= 9_999_999_999);
      if (!name || minPrice == null || minPrice < 0 || (!openEnded && (maxPrice == null || maxPrice <= minPrice))) {
        return { ok: false, reason: "price-range-invalid" };
      }
      priceRanges.push({ name, minPrice, maxPrice, id, openEnded });
    }
    return { ok: true, value: { cateId, priceRanges } };
  }

  function parseGrowth(record, response) {
    const request = requestBusiness(record);
    const cateId = validCateId(request.cateId);
    const periodType = scalarId(request.periodType);
    const date = normalizeDate(request.date);
    const propertyId = scalarId(request.propertyId);
    const data = response?.data;
    const columns = data?.headers?.columns;
    const rows = data?.rows;
    if (!cateId || !periodType || !date || !propertyId || !Array.isArray(columns) || !columns.length
      || !columns.every(value => typeof value === "string" && cleanText(value)) || !Array.isArray(rows)) {
      return { ok: false, reason: "response-shape-not-recognized" };
    }
    const cleanColumns = columns.map(value => cleanText(value));
    const parsedRows = [];
    for (const row of rows) {
      if (!row || typeof row !== "object" || Array.isArray(row)
        || Object.keys(row).some(key => !["priceRange", "values"].includes(key))
        || !normalizeBand(row.priceRange) || !Array.isArray(row.values) || row.values.length !== cleanColumns.length) {
        return { ok: false, reason: "growth-matrix-shape-invalid" };
      }
      const cells = [];
      for (let index = 0; index < row.values.length; index += 1) {
        const cell = row.values[index];
        if (!cell || typeof cell !== "object" || Array.isArray(cell) || Object.keys(cell).some(key => !SCORE_FIELDS.includes(key))) {
          return { ok: false, reason: "growth-score-unmapped-field" };
        }
        const scores = {};
        for (const field of SCORE_FIELDS) {
          if (!hasOwn(cell, field) || cell[field] == null) continue;
          if (typeof cell[field] !== "number" || !Number.isFinite(cell[field])) return { ok: false, reason: "growth-score-invalid" };
          scores[field] = cell[field];
        }
        cells.push({ propertyValueName: cleanColumns[index], scores });
      }
      parsedRows.push({ priceRange: normalizeBand(row.priceRange), cells });
    }
    return { ok: true, value: { cateId, periodType, date, propertyId, columns: cleanColumns, rows: parsedRows } };
  }

  function parseChance(record, response) {
    const request = requestBusiness(record);
    const cateId = validCateId(request.cateId);
    const periodType = scalarId(request.periodType);
    const date = normalizeDate(request.date);
    const data = response?.data;
    if (!cateId || !periodType || !date || hasUnknownField(data, ["list"]) || !Array.isArray(data.list)) {
      return { ok: false, reason: "response-shape-not-recognized" };
    }
    const chanceGroups = [];
    const seenCodes = new Set();
    for (const entry of data.list) {
      if (hasUnknownField(entry, CHANCE_FIELDS)) return { ok: false, reason: "chance-unmapped-field" };
      if (!["string", "number"].includes(typeof entry.code)
        || typeof entry.title !== "string"
        || (entry.tag != null && typeof entry.tag !== "string")
        || (entry.description != null && typeof entry.description !== "string")) {
        return { ok: false, reason: "chance-entry-invalid" };
      }
      const code = scalarId(entry.code);
      const title = cleanText(entry.title, 200);
      if (!code || !title || seenCodes.has(code)) return { ok: false, reason: "chance-entry-invalid" };
      const chance = {
        code,
        title,
        tag: cleanText(entry.tag, 200),
        description: cleanText(entry.description, 2_000)
      };
      seenCodes.add(code);
      chanceGroups.push(chance);
    }
    return { ok: true, value: { cateId, periodType, date, chanceGroups } };
  }

  function parseTrackList(record, response) {
    const request = requestBusiness(record);
    const cateId = validCateId(request.cateId);
    const periodType = scalarId(request.periodType);
    const date = normalizeDate(request.date);
    const chanceCode = scalarId(request.chanceCode);
    const data = response?.data;
    const list = data?.list;
    if (!cateId || !periodType || !date || !chanceCode || hasUnknownField(data, ["list"]) || !Array.isArray(list)) {
      return { ok: false, reason: "response-shape-not-recognized" };
    }
    const tracks = [];
    const seenTrackIds = new Set();
    for (const entry of list) {
      const allowed = new Set(["trackId", "trackName", "dScore", "collected", "shopAlipayRank"]);
      if (hasUnknownField(entry, allowed)) {
        return { ok: false, reason: "track-list-unmapped-field" };
      }
      if (!["string", "number"].includes(typeof entry.trackId) || typeof entry.trackName !== "string") {
        return { ok: false, reason: "track-list-entry-invalid" };
      }
      const trackId = scalarId(entry.trackId);
      const trackName = cleanText(entry.trackName);
      if (!trackId || !trackName || seenTrackIds.has(trackId)) return { ok: false, reason: "track-list-entry-invalid" };
      const track = { trackId, trackName };
      if (hasOwn(entry, "dScore")) {
        if (entry.dScore == null) track.dScore = entry.dScore;
        else if (typeof entry.dScore === "number" && Number.isFinite(entry.dScore)) track.dScore = entry.dScore;
        else return { ok: false, reason: "track-list-score-invalid" };
      }
      if (hasOwn(entry, "collected") && entry.collected != null
        && typeof entry.collected !== "boolean"
        && !(typeof entry.collected === "number" && Number.isFinite(entry.collected))) {
        return { ok: false, reason: "track-list-value-invalid" };
      }
      if (!copyOptionalPrimitive(track, entry, "shopAlipayRank") || !copyOptionalPrimitive(track, entry, "collected")) {
        return { ok: false, reason: "track-list-value-invalid" };
      }
      seenTrackIds.add(trackId);
      tracks.push(track);
    }
    return { ok: true, value: { cateId, periodType, date, chanceCode, tracks } };
  }

  function parseMetricSection(value, allowedFields, scope, required = false) {
    if (value === undefined) return required
      ? { ok: false, reason: `${scope}-missing` }
      : { ok: true, present: false, value: undefined };
    if (value === null) return required
      ? { ok: false, reason: `${scope}-invalid` }
      : { ok: true, present: true, value: null };
    if (hasUnknownField(value, allowedFields)) return { ok: false, reason: `${scope}-unmapped-field` };
    const parsed = {};
    for (const field of allowedFields) {
      if (!copyOptionalPrimitive(parsed, value, field, 1_000)) return { ok: false, reason: `${scope}-value-invalid` };
    }
    return { ok: true, present: true, value: parsed };
  }

  function parseDetailChance(value) {
    if (value === undefined) return { ok: true, present: false, value: undefined };
    if (value === null) return { ok: true, present: true, value: null };
    if (hasUnknownField(value, CHANCE_FIELDS)) return { ok: false, reason: "track-detail-chance-unmapped-field" };
    const parsed = {};
    for (const field of CHANCE_FIELDS) {
      if (!copyOptionalPrimitive(parsed, value, field, field === "description" ? 2_000 : 200)) {
        return { ok: false, reason: "track-detail-chance-value-invalid" };
      }
    }
    return { ok: true, present: true, value: parsed };
  }

  function parseCrowd(value) {
    if (value === undefined) return { ok: true, present: false, value: undefined };
    if (value === null) return { ok: true, present: true, value: null };
    if (hasUnknownField(value, CROWD_FIELDS)) return { ok: false, reason: "track-detail-crowd-unmapped-field" };
    const parsed = {};
    for (const field of CROWD_FIELDS) {
      if (!hasOwn(value, field)) continue;
      const feature = value[field];
      if (feature === null) {
        parsed[field] = null;
        continue;
      }
      if (hasUnknownField(feature, ["dataInsight"])) return { ok: false, reason: "track-detail-crowd-feature-unmapped-field" };
      const output = {};
      if (hasOwn(feature, "dataInsight")) {
        const insight = sanitizeInsightValue(feature.dataInsight);
        if (!insight.ok) return { ok: false, reason: "track-detail-crowd-value-invalid" };
        output.dataInsight = insight.value;
      }
      parsed[field] = output;
    }
    return { ok: true, present: true, value: parsed };
  }

  function parseStructureRows(value, scope) {
    if (value === undefined) return { ok: true, present: false, value: undefined };
    if (value === null) return { ok: true, present: true, value: null };
    if (!Array.isArray(value)) return { ok: false, reason: `${scope}-invalid` };
    const rows = [];
    for (const entry of value) {
      if (hasUnknownField(entry, STRUCTURE_FIELDS)) return { ok: false, reason: `${scope}-unmapped-field` };
      const row = {};
      for (const field of STRUCTURE_FIELDS) {
        if (!copyOptionalPrimitive(row, entry, field, 500)) return { ok: false, reason: `${scope}-value-invalid` };
      }
      if (!cleanText(row.marketSceneName)) return { ok: false, reason: `${scope}-scene-missing` };
      rows.push(row);
    }
    return { ok: true, present: true, value: rows };
  }

  function parseStructure(value) {
    if (value === undefined) return { ok: true, present: false, value: undefined };
    if (value === null) return { ok: true, present: true, value: null };
    if (hasUnknownField(value, ["track", "shop"])) return { ok: false, reason: "track-detail-structure-unmapped-field" };
    const track = parseStructureRows(value.track, "track-detail-structure-track");
    const shop = parseStructureRows(value.shop, "track-detail-structure-shop");
    if (!track.ok) return track;
    if (!shop.ok) return shop;
    return {
      ok: true,
      present: true,
      value: {
        ...(track.present ? { track: track.value } : {}),
        ...(shop.present ? { shop: shop.value } : {})
      }
    };
  }

  function parseTrackDetail(record, response) {
    const request = requestBusiness(record);
    const cateId = validCateId(request.cateId);
    const periodType = scalarId(request.periodType);
    const date = normalizeDate(request.date);
    const trackId = scalarId(request.trackId);
    const data = response?.data;
    if (!cateId || !periodType || !date || !trackId || hasUnknownField(data, ["chance", "track", "shop", "crowd", "structure"])) {
      return { ok: false, reason: "response-shape-not-recognized" };
    }
    const chance = parseDetailChance(data.chance);
    const track = parseMetricSection(data.track, TRACK_DETAIL_FIELDS, "track-detail-track", true);
    const shop = parseMetricSection(data.shop, SHOP_DETAIL_FIELDS, "track-detail-shop");
    const crowd = parseCrowd(data.crowd);
    const structure = parseStructure(data.structure);
    for (const section of [chance, track, shop, crowd, structure]) if (!section.ok) return section;
    const detail = {
      track: track.value,
      ...(chance.present ? { chance: chance.value } : {}),
      ...(shop.present ? { shop: shop.value } : {}),
      ...(crowd.present ? { crowd: crowd.value } : {}),
      ...(structure.present ? { structure: structure.value } : {})
    };
    return { ok: true, value: { cateId, periodType, date, trackId, metrics: { ...track.value }, detail } };
  }

  function classifyRecord(record) {
    const path = recordPath(record);
    const parser = path === ENDPOINTS.properties ? parseProperties
      : path === ENDPOINTS.dateRange ? parseDateRange
        : path === ENDPOINTS.priceRange ? parsePriceRanges
          : path === ENDPOINTS.growth ? parseGrowth
            : path === ENDPOINTS.chance ? parseChance
              : path === ENDPOINTS.trackList ? parseTrackList
                : path === ENDPOINTS.trackDetail ? parseTrackDetail
                  : null;
    if (!parser) return null;
    const response = parseResponse(record);
    if (!response || typeof response !== "object") return { path, ok: false, reason: "response-unparseable", capturedAt: String(record?.capturedAt || "") };
    const apiInfo = response?.info || response?.result?.info;
    if (apiInfo?.ok === false || (apiInfo?.code != null && Number(apiInfo.code) !== 0)) {
      return { path, ok: false, reason: "api-error", capturedAt: String(record?.capturedAt || "") };
    }
    const parsed = parser(record, response);
    return { path, ...parsed, capturedAt: String(record?.capturedAt || "") };
  }

  function parseBandBounds(name) {
    const normalized = normalizeBand(name);
    const closed = normalized.match(/^(-?\d+(?:\.\d+)?)~(-?\d+(?:\.\d+)?)$/);
    if (closed) return { minPrice: Number(closed[1]), maxPrice: Number(closed[2]), openEnded: false };
    const open = normalized.match(/^(-?\d+(?:\.\d+)?)\u4ee5\u4e0a$/);
    if (open) return { minPrice: Number(open[1]), maxPrice: null, openEnded: true };
    return { minPrice: null, maxPrice: null, openEnded: /\u4ee5\u4e0a$/.test(normalized) };
  }

  function periodKey(value) {
    return `${value.periodType}|${value.date}`;
  }

  function sameValue(left, right) {
    return JSON.stringify(left) === JSON.stringify(right);
  }

  function trackMatchesCell(track, property, propertyValueName, priceRange, range) {
    const name = normalizeBand(track.trackName);
    const propertyName = normalizeBand(property.propertyName);
    const valueName = normalizeBand(propertyValueName);
    const band = normalizeBand(priceRange);
    if (propertyName && name.includes(propertyName) && name.includes(valueName) && name.includes(band)) return true;
    const id = String(track.trackId || "");
    const rangeMatch = range?.id ? id.endsWith(`_${range.id}`) : true;
    return rangeMatch && id.includes(`_${propertyValueName}_`) && (!property.propertyName || id.includes(`_${property.propertyName}_`));
  }

  function buildSnapshots(records, options = {}) {
    const classified = (records || []).map((record, sequence) => {
      const entry = classifyRecord(record);
      return entry ? { ...entry, sequence } : null;
    }).filter(Boolean);
    const audit = Object.values(ENDPOINTS).map(path => {
      const entries = classified.filter(entry => entry.path === path);
      return {
        path,
        records: entries.length,
        parsed: entries.filter(entry => entry.ok).length,
        failed: entries.filter(entry => !entry.ok).length,
        reasons: [...new Set(entries.filter(entry => !entry.ok).map(entry => entry.reason))]
      };
    });
    const blocking = classified.filter(entry => !entry.ok).map(entry => `${entry.path}:${entry.reason}`);
    const parsed = classified.filter(entry => entry.ok);
    const discovered = [...new Set(parsed.map(entry => entry.value?.cateId).filter(Boolean))];
    const requestedCateId = validCateId(options.cateId);
    const cateId = requestedCateId || (discovered.length === 1 ? discovered[0] : "");
    if (!cateId) {
      return {
        schemaVersion: "dmp-track/1.0",
        status: blocking.length ? "failed" : "empty",
        cateId: "",
        priceRanges: [],
        properties: [],
        opportunities: [],
        audit,
        blockingIssues: [...new Set([...blocking, ...(discovered.length > 1 ? ["category-ambiguous"] : [])])]
      };
    }

    const inRequestedPeriod = value => (!options.periodType || String(value.periodType) === String(options.periodType))
      && (!options.date || value.date === normalizeDate(options.date));

    const propertyMap = new Map();
    const ensureProperty = propertyId => {
      if (!propertyMap.has(propertyId)) propertyMap.set(propertyId, { propertyId, propertyName: "", valueMap: new Map(), periods: [] });
      return propertyMap.get(propertyId);
    };
    for (const entry of parsed.filter(item => item.path === ENDPOINTS.properties && item.value.cateId === cateId)) {
      for (const source of entry.value.properties) {
        const target = ensureProperty(source.propertyId);
        if (target.propertyName && target.propertyName !== source.propertyName) blocking.push(`property-name-conflict:${source.propertyId}`);
        if (!target.propertyName) target.propertyName = source.propertyName;
        for (const value of source.propertyValues) {
          const key = value.id || value.name;
          const existing = target.valueMap.get(key);
          if (existing && existing.name !== value.name) blocking.push(`property-value-conflict:${source.propertyId}:${key}`);
          else target.valueMap.set(key, value);
        }
      }
    }

    const growthEntries = parsed.filter(entry => entry.path === ENDPOINTS.growth
      && entry.value.cateId === cateId
      && inRequestedPeriod(entry.value));
    for (const entry of growthEntries) {
      const target = ensureProperty(entry.value.propertyId);
      for (const column of entry.value.columns) {
        if (![...target.valueMap.values()].some(value => value.name === column)) target.valueMap.set(`name:${column}`, { id: "", name: column });
      }
      target.periods.push({ ...entry.value, sequence: entry.sequence });
    }

    const dateRanges = new Map();
    for (const entry of parsed.filter(item => item.path === ENDPOINTS.dateRange)) {
      const key = periodKey(entry.value);
      const existing = dateRanges.get(key);
      if (existing && !sameValue(existing.value, entry.value)) blocking.push(`date-range-conflict:${key}`);
      if (!existing || entry.sequence > existing.sequence) dateRanges.set(key, entry);
    }

    const rangeMap = new Map();
    for (const entry of parsed.filter(item => item.path === ENDPOINTS.priceRange && item.value.cateId === cateId)) {
      for (const range of entry.value.priceRanges) {
        const existing = rangeMap.get(range.name);
        if (existing && !sameValue(existing, range)) blocking.push(`price-range-conflict:${range.name}`);
        else if (!existing) rangeMap.set(range.name, range);
      }
    }
    for (const entry of growthEntries) {
      for (const row of entry.value.rows) {
        if (rangeMap.has(row.priceRange)) continue;
        const bounds = parseBandBounds(row.priceRange);
        rangeMap.set(row.priceRange, { name: row.priceRange, minPrice: bounds.minPrice, maxPrice: bounds.maxPrice, id: "", openEnded: bounds.openEnded });
      }
    }

    const chancePeriods = new Map();
    for (const entry of parsed.filter(item => item.path === ENDPOINTS.chance
      && item.value.cateId === cateId && inRequestedPeriod(item.value))) {
      const key = periodKey(entry.value);
      const existing = chancePeriods.get(key);
      if (existing && !sameValue(existing.value.chanceGroups, entry.value.chanceGroups)) blocking.push(`chance-conflict:${key}`);
      if (!existing || entry.sequence > existing.sequence) chancePeriods.set(key, entry);
    }

    const trackListGroups = new Map();
    for (const entry of parsed.filter(item => item.path === ENDPOINTS.trackList
      && item.value.cateId === cateId && inRequestedPeriod(item.value))) {
      const key = `${periodKey(entry.value)}|${entry.value.chanceCode}`;
      const existing = trackListGroups.get(key);
      if (existing && !sameValue(existing.value.tracks, entry.value.tracks)) blocking.push(`track-list-group-conflict:${key}`);
      if (!existing || entry.sequence > existing.sequence) trackListGroups.set(key, entry);
    }

    const trackPeriods = new Map();
    for (const entry of trackListGroups.values()) {
      const key = periodKey(entry.value);
      if (!trackPeriods.has(key)) trackPeriods.set(key, new Map());
      const trackMap = trackPeriods.get(key);
      for (const track of entry.value.tracks) {
        const existing = trackMap.get(track.trackId) || { ...track, chanceCodes: [] };
        if (!sameValue({ ...existing, chanceCodes: undefined }, track)) blocking.push(`track-list-conflict:${key}:${track.trackId}`);
        if (!existing.chanceCodes.includes(entry.value.chanceCode)) existing.chanceCodes.push(entry.value.chanceCode);
        trackMap.set(track.trackId, existing);
      }
    }

    const detailMap = new Map();
    for (const entry of parsed.filter(item => item.path === ENDPOINTS.trackDetail
      && item.value.cateId === cateId && inRequestedPeriod(item.value))) {
      const key = `${periodKey(entry.value)}|${entry.value.trackId}`;
      const existing = detailMap.get(key);
      if (existing && !sameValue(existing.value.detail, entry.value.detail)) blocking.push(`track-detail-conflict:${key}`);
      if (!existing || entry.sequence > existing.sequence) detailMap.set(key, entry);
    }

    const trackCoordinates = new Map();
    const addTrackCoordinate = (key, coordinate) => {
      if (!trackCoordinates.has(key)) trackCoordinates.set(key, []);
      const coordinates = trackCoordinates.get(key);
      if (!coordinates.some(existing => sameValue(existing, coordinate))) coordinates.push(coordinate);
    };

    for (const property of propertyMap.values()) {
      if (!property.propertyName) blocking.push(`property-metadata-missing:${property.propertyId}`);
      const deduped = new Map();
      for (const growth of property.periods) {
        const key = periodKey(growth);
        const existing = deduped.get(key);
        const comparable = { ...growth, sequence: undefined };
        if (existing && !sameValue({ ...existing, sequence: undefined }, comparable)) blocking.push(`growth-period-conflict:${property.propertyId}:${key}`);
        if (!existing || growth.sequence > existing.sequence) deduped.set(key, growth);
      }
      property.periods = [...deduped.values()].map(growth => {
        const key = periodKey(growth);
        const range = dateRanges.get(key)?.value;
        if (!range) blocking.push(`date-range-missing:${property.propertyId}:${key}`);
        const tracks = [...(trackPeriods.get(key)?.values() || [])];
        const rows = growth.rows.map(row => ({
          priceRange: row.priceRange,
          cells: row.cells.map(cell => {
            const priceRange = rangeMap.get(row.priceRange);
            const matches = tracks.filter(track => trackMatchesCell(track, property, cell.propertyValueName, row.priceRange, priceRange));
            const output = { propertyValueName: cell.propertyValueName, scores: { ...cell.scores } };
            for (const track of matches) {
              addTrackCoordinate(`${key}|${track.trackId}`, {
                propertyId: property.propertyId,
                propertyName: property.propertyName,
                propertyValueName: cell.propertyValueName,
                priceRange: row.priceRange
              });
            }
            if (matches.length > 1) blocking.push(`track-cell-ambiguous:${property.propertyId}:${key}:${row.priceRange}:${cell.propertyValueName}`);
            if (matches.length === 1) {
              const track = matches[0];
              const detail = detailMap.get(`${key}|${track.trackId}`)?.value?.detail;
              if (detail) {
                output.detail = {
                  trackId: track.trackId,
                  trackName: track.trackName,
                  chanceCodes: [...track.chanceCodes],
                  ...(hasOwn(track, "dScore") ? { dScore: track.dScore } : {}),
                  ...(hasOwn(track, "shopAlipayRank") ? { shopAlipayRank: track.shopAlipayRank } : {}),
                  ...(hasOwn(track, "collected") ? { collected: track.collected } : {}),
                  ...(isPlainObject(detail.track) ? detail.track : {}),
                  ...(isPlainObject(detail.shop) ? detail.shop : {}),
                  ...detail
                };
              }
            }
            return output;
          })
        }));
        return {
          periodType: growth.periodType,
          date: growth.date,
          startDate: range?.startDate || "",
          endDate: range?.endDate || "",
          compareStartDate: range?.compareStartDate || "",
          compareEndDate: range?.compareEndDate || "",
          columns: [...growth.columns],
          rows
        };
      }).sort((left, right) => right.date.localeCompare(left.date) || right.periodType.localeCompare(left.periodType));
      const current = property.periods[0];
      if (current?.compareEndDate && !property.periods.some(period => period.periodType === current.periodType && period.date === current.compareEndDate)) {
        blocking.push(`compare-growth-missing:${property.propertyId}:${current.compareEndDate}`);
      }
    }

    const listsByPeriod = new Map();
    for (const entry of trackListGroups.values()) {
      const key = periodKey(entry.value);
      if (!listsByPeriod.has(key)) listsByPeriod.set(key, new Map());
      listsByPeriod.get(key).set(entry.value.chanceCode, entry);
    }
    const detailsByPeriod = new Map();
    for (const entry of detailMap.values()) {
      const key = periodKey(entry.value);
      if (!detailsByPeriod.has(key)) detailsByPeriod.set(key, new Map());
      detailsByPeriod.get(key).set(entry.value.trackId, entry);
    }

    const opportunityPeriodKeys = new Set(growthEntries.map(entry => periodKey(entry.value)));
    for (const key of chancePeriods.keys()) opportunityPeriodKeys.add(key);
    for (const entry of trackListGroups.values()) opportunityPeriodKeys.add(periodKey(entry.value));
    for (const entry of detailMap.values()) opportunityPeriodKeys.add(periodKey(entry.value));

    const opportunities = [...opportunityPeriodKeys].map(key => {
      const separator = key.indexOf("|");
      const periodType = key.slice(0, separator);
      const date = key.slice(separator + 1);
      const range = dateRanges.get(key)?.value;
      const chanceEntry = chancePeriods.get(key);
      const periodLists = listsByPeriod.get(key) || new Map();
      const periodDetails = detailsByPeriod.get(key) || new Map();
      const periodIssues = [];
      if (!range) periodIssues.push("date-range-missing");
      if (!chanceEntry) periodIssues.push("chance-missing");

      const groupDefinitions = (chanceEntry?.value?.chanceGroups || []).map(group => ({ ...group }));
      const definedCodes = new Set(groupDefinitions.map(group => group.code));
      for (const code of periodLists.keys()) {
        if (!definedCodes.has(code)) {
          groupDefinitions.push({ code, title: "", tag: "", description: "" });
          periodIssues.push(`chance-group-metadata-missing:${code}`);
        }
      }

      const representedDetailIds = new Set();
      const chanceGroups = groupDefinitions.map(definition => {
        const listEntry = periodLists.get(definition.code);
        const groupIssues = [];
        if (!listEntry) groupIssues.push("track-list-missing");
        const tracks = (listEntry?.value?.tracks || []).map(source => {
          const detailEntry = periodDetails.get(source.trackId);
          if (detailEntry) representedDetailIds.add(source.trackId);
          else groupIssues.push(`track-detail-missing:${source.trackId}`);
          return {
            ...source,
            coordinates: (trackCoordinates.get(`${key}|${source.trackId}`) || []).map(coordinate => ({ ...coordinate })),
            ...(detailEntry ? { detail: detailEntry.value.detail } : {})
          };
        });
        const issues = [...new Set(groupIssues)];
        for (const issue of issues) periodIssues.push(`${definition.code}:${issue}`);
        return {
          ...definition,
          status: issues.length ? "partial" : "ready",
          issues,
          tracks
        };
      });

      const orphanDetails = [];
      for (const [trackId, detailEntry] of periodDetails) {
        if (representedDetailIds.has(trackId)) continue;
        orphanDetails.push({ trackId, detail: detailEntry.value.detail });
        periodIssues.push(`track-detail-unmatched:${trackId}`);
      }
      const issues = [...new Set(periodIssues)];
      for (const issue of issues) blocking.push(`opportunity:${key}:${issue}`);
      return {
        periodType,
        date,
        startDate: range?.startDate || "",
        endDate: range?.endDate || "",
        compareStartDate: range?.compareStartDate || "",
        compareEndDate: range?.compareEndDate || "",
        status: issues.length ? "partial" : "ready",
        issues,
        chanceGroups,
        ...(orphanDetails.length ? { orphanDetails } : {})
      };
    }).sort((left, right) => right.date.localeCompare(left.date) || right.periodType.localeCompare(left.periodType));

    const priceRanges = [...rangeMap.values()].sort((left, right) => {
      if (Number.isFinite(left.minPrice) && Number.isFinite(right.minPrice)) return left.minPrice - right.minPrice;
      if (Number.isFinite(left.minPrice)) return -1;
      if (Number.isFinite(right.minPrice)) return 1;
      return left.name.localeCompare(right.name, "zh-CN");
    });
    const properties = [...propertyMap.values()].map(property => ({
      propertyId: property.propertyId,
      propertyName: property.propertyName,
      propertyValues: [...property.valueMap.values()],
      periods: property.periods
    }));
    const uniqueBlocking = [...new Set(blocking)];
    const opportunityPaths = new Set([ENDPOINTS.chance, ENDPOINTS.trackList, ENDPOINTS.trackDetail]);
    const hasCoreParserFailure = classified.some(entry => !entry.ok && !opportunityPaths.has(entry.path));
    const status = hasCoreParserFailure ? "failed"
      : !growthEntries.length ? (parsed.length ? "partial" : "empty")
        : uniqueBlocking.length ? "partial"
          : "ready";
    return {
      schemaVersion: "dmp-track/1.0",
      status,
      cateId,
      priceRanges,
      properties,
      opportunities,
      audit,
      blockingIssues: uniqueBlocking
    };
  }

  return {
    ENDPOINTS,
    SCORE_FIELDS,
    DETAIL_FIELDS,
    TRACK_DETAIL_FIELDS,
    SHOP_DETAIL_FIELDS,
    CROWD_FIELDS,
    STRUCTURE_FIELDS,
    canonicalPath,
    parseResponse,
    requestBusiness,
    classifyRecord,
    buildSnapshots,
    normalizeBand
  };
});
