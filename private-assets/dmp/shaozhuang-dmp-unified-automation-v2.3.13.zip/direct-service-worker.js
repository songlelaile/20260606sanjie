import "./direct-core.js";
import "./completeness-engine.js";
import "./report-engine.js";
import "./rolling7-engine.js";
import "./track-engine.js";
import "./rolling7-html-writer.js";
import { normalizeOfficialReportUrl } from "./official-share-url.mjs";

const core = globalThis.DmpDirectCore;
const completeness = globalThis.DmpCompletenessEngine;
const reportEngine = globalThis.DmpReportEngine;
const rolling7 = globalThis.DmpRolling7Engine;
const trackEngine = globalThis.DmpTrackEngine;
const rolling7HtmlWriter = globalThis.DmpRolling7HtmlWriter;
if (!core || !completeness || !reportEngine || !rolling7) throw new Error("取数核心模块加载失败");

let runningPromise = null;
let storedArchivePromise = null;
const DRAFT_KEY = "dmpDirectDraftConfigV1";
let draftWriteTail = Promise.resolve();
const SANJIE_SESSION_COOKIE = "sanjie_session";
const SANJIE_ACTIVE_SHOP_COOKIE = "sanjie_active_shop";
const SANJIE_IMPORT_TIMEOUT_MS = 20_000;
const SANJIE_MARKET_NORMALIZED_REPORT_MAX_BYTES = 8 * 1024 * 1024;
const SANJIE_MARKET_HTTP_BODY_MAX_BYTES = SANJIE_MARKET_NORMALIZED_REPORT_MAX_BYTES + 64 * 1024;
const OFFICIAL_AUTH_TIMEOUT_MS = 10_000;
const OFFICIAL_AUTH_CACHE_MS = 20_000;
const OFFICIAL_LAUNCH_TTL_MS = 60_000;
const OFFICIAL_COOKIE_URLS = ["https://www.shaozhuangai.com/", "https://shaozhuangai.com/"];
const RECOVERABLE_SANJIE_CODES = new Set([
  "SANJIE_LOGIN_REQUIRED", "SANJIE_TIMEOUT", "SANJIE_UNAVAILABLE", "SANJIE_IMPORT_UNCERTAIN",
  "SANJIE_REPORT_REJECTED", "SANJIE_IMPORT_FAILED", "REPORT_NOT_UPLOADABLE"
]);
const ARCHIVE_OUTBOX_LIMIT = 100;
const DIRECT_REQUEST_MAX_ATTEMPTS = 3;
const DIRECT_REQUEST_RETRY_BASE_MS = 750;
const DIRECT_READINESS_MAX_SAMPLES = 4;
const DIRECT_READINESS_SAMPLE_DELAY_MS = 250;
const DIRECT_AVAILABILITY_LOOKBACK_DAYS = 7;
const DIRECT_PARTIAL_PROGRESS = 99;
const ROLLING7_STATE_KEY = "dmpMarketRolling7StateV1";
const ROLLING7_DATASET_KEY = "dmpMarketRolling7DatasetV1";
const ROLLING7_HTML_KEY = "dmpMarketRolling7HtmlV1";
const ROLLING7_TRACK_KEY = "dmpMarketTrackSnapshotV1";
const ROLLING7_TRACK_CHANCE_PATH = "/api/subdivide/market/item/chance";
const ROLLING7_TRACK_CONTRACT_VERSION = 3;
const ROLLING7_TRACK_LATEST_CONTRACT_VERSION = 1;
const ROLLING7_TRACK_REQUIRED_SCORE_KEYS = Object.freeze(["aScore", "bScore", "cScore", "eScore"]);
const ROLLING7_ALARM_NAME = "dmpMarketRolling7ResumeV1";
const ROLLING7_ALARM_DELAY_MINUTES = 0.5;
const ROLLING7_MIN_INTERVAL_MS = 1200;
const ROLLING7_RETRY_BASE_MS = 1500;
const ROLLING7_MAX_RETRIES = 2;
const ROLLING7_TAIL_CONFIRMATION_ROUNDS = 3;
const ROLLING7_PAGE_API_CAPABILITY = "market-rolling7-v1";
const ROLLING7_TRACK_PAGE_API_CAPABILITY = "market-track-v1";
const ROLLING7_PAGE_API_MIN_VERSION = 1;
const ROLLING7_PAGE_API_MAX_VERSION = 2;
const ROLLING7_BLOCKING_CODES = new Set([
  "NO_DMP_TAB", "TAB_UNAVAILABLE", "PAGE_API_UNAVAILABLE", "TEMPLATE_REQUIRED",
  "LOGIN_REQUIRED", "API_ERROR", "UNEXPECTED_ORIGIN", "REQUEST_NOT_ALLOWED", "INVALID_REQUEST",
  "INVALID_CATE_ID", "INVALID_DATE", "INVALID_DATE_RANGE", "INVALID_PERIOD_TYPE",
  "BASELINE_PERIOD_UNVERIFIED"
]);
const ROLLING7_OPTIONAL_BASELINE_FALLBACK_CODES = new Set(["INVALID_REQUEST"]);
const ROLLING7_MISSING_RETRY_CODES = new Set([
  "INVALID_REQUEST", "API_ERROR", "MARKET_DATA_UNAVAILABLE", "HTTP_ERROR", "TIMEOUT", "REQUEST_FAILED"
]);
let rolling7State = null;
let rolling7MutationTail = Promise.resolve();
let rolling7Promise = null;
let rolling7ArchivePromise = null;
let rolling7InitializationPromise = null;
let rolling7TrackCollectionPromise = null;
let rolling7LoadError = null;
let rolling7IgnorePersistedState = false;

function normalizeArchiveOutbox(value) {
  return Array.isArray(value) ? value.slice() : [];
}

function normalizeDatasetTemplateBody(value) {
  const templateBody = String(value || "").trim();
  if (!templateBody || templateBody.length > 512 * 1024 || core.containsSensitiveData(templateBody)) return "";
  let payload;
  try { payload = JSON.parse(templateBody); } catch { return ""; }
  if (!payload || typeof payload !== "object" || Array.isArray(payload)
    || String(payload?.type ?? payload?.data?.type ?? payload?.params?.type ?? "").toUpperCase() !== "INDEX_CARD") return "";
  return templateBody;
}

function normalizeDatasetTemplates(value) {
  if (!Array.isArray(value)) return [];
  const seen = new Set();
  const rows = [];
  for (const entry of value.slice(0, 64)) {
    const templateId = String(entry?.templateId || "").trim();
    const templateBody = normalizeDatasetTemplateBody(entry?.templateBody);
    if (!/^idx-[a-f\d]{8,64}$/i.test(templateId) || !templateBody || seen.has(templateId)) continue;
    seen.add(templateId);
    rows.push({ templateId, templateBody });
  }
  return rows;
}

function normalizeExpectedShop(value) {
  if (!value || typeof value !== "object" || core.containsSensitiveData(value)) return null;
  const sourceShop = core.sanitizeSourceShop(value);
  const officialShopId = String(value.officialShopId || "").trim();
  if (!officialShopId || !sourceShop?.sourceShopId || !sourceShop?.shopName) return null;
  return Object.freeze({ officialShopId, sourceShopId: sourceShop.sourceShopId, shopName: sourceShop.shopName });
}

function normalizeLocalState(value) {
  const state = value && typeof value === "object" ? value : {};
  const sourceShop = core.sanitizeSourceShop(state.sourceShop);
  const expectedShop = normalizeExpectedShop(state.expectedShop || state.job?.expectedShop);
  const datasetTemplate = normalizeDatasetTemplateBody(state.datasetTemplate);
  const primaryDatasetTemplate = normalizeDatasetTemplateBody(state.primaryDatasetTemplate) || datasetTemplate;
  return {
    lastConfig: { subjectItemId: "", successItemId: "" },
    datasetTemplate: "",
    datasetTemplates: [],
    primaryDatasetTemplateId: "",
    primaryDatasetTemplate: "",
    job: null,
    report: null,
    sanjie: null,
    sourceShop: null,
    expectedShop: null,
    ...state,
    schemaVersion: 2,
    sourceShop,
    expectedShop,
    archiveOutbox: normalizeArchiveOutbox(state.archiveOutbox),
    datasetTemplate,
    datasetTemplates: normalizeDatasetTemplates(state.datasetTemplates),
    primaryDatasetTemplateId: /^idx-[a-f\d]{8,64}$/i.test(String(state.primaryDatasetTemplateId || ""))
      ? String(state.primaryDatasetTemplateId)
      : "",
    primaryDatasetTemplate
  };
}

async function readLocalState() {
  const stored = await chrome.storage.local.get(core.STATE_KEY);
  return normalizeLocalState(stored[core.STATE_KEY]);
}

async function writeLocalState(next) {
  const state = normalizeLocalState(next);
  await chrome.storage.local.set({ [core.STATE_KEY]: state });
  return state;
}

function rolling7SafeError(error, fallback = "滚动7天取数失败") {
  const rawCode = String(error?.code || error?.name || "REQUEST_FAILED");
  const code = /^[A-Za-z0-9_-]{1,64}$/.test(rawCode) ? rawCode : "REQUEST_FAILED";
  const candidate = {
    code,
    message: core.safeErrorText(error, fallback).slice(0, 240)
  };
  try {
    rolling7.assertSensitiveFree(candidate);
    return candidate;
  } catch {
    return { code: "REQUEST_FAILED", message: fallback };
  }
}

function emptyPublicRolling7State() {
  return {
    status: "idle",
    total: 0,
    completed: 0,
    missing: 0,
    conflicts: 0,
    boundaryMismatches: 0,
    failed: 0,
    currentDate: null,
    estimatedRemainingMs: 0,
    progress: 0,
    reportReady: false,
    reportPartial: false,
    error: rolling7LoadError?.message || "",
    errorCode: rolling7LoadError?.code || "",
    config: null
  };
}

function rolling7CurrentDate() {
  try {
    const parts = new Intl.DateTimeFormat("en-CA", {
      timeZone: "Asia/Shanghai",
      year: "numeric",
      month: "2-digit",
      day: "2-digit"
    }).formatToParts(new Date());
    const values = Object.fromEntries(parts.map(part => [part.type, part.value]));
    if (values.year && values.month && values.day) return `${values.year}-${values.month}-${values.day}`;
  } catch {}
  return new Date().toISOString().slice(0, 10);
}

function migrateUnavailableRolling7Tail(state, error = state?.lastError, taskId = null) {
  if (!state || !["running", "paused"].includes(state.queueStatus)) return state;
  const configuredRounds = Number(state.config?.tailConfirmationRounds || 0);
  const legacyCheckpoint = configuredRounds < 1;
  // New checkpoints already persist each real observation. Replaying the finalizer while the
  // service worker boots would fabricate another round without a new page response. Only old
  // checkpoints (created before the confirmation fields existed) receive the one-time migration.
  if (!legacyCheckpoint) return state;
  return rolling7.finalizeUnavailableTail(state, taskId, error, {
    currentDate: rolling7CurrentDate(),
    requiredRounds: legacyCheckpoint ? 1 : configuredRounds,
    allowLegacyApiError: legacyCheckpoint
  });
}

function publicRolling7State(state) {
  if (!state) return emptyPublicRolling7State();
  const stats = rolling7.getStats(state);
  const probe = state.unavailableTailProbe && typeof state.unavailableTailProbe === "object"
    ? state.unavailableTailProbe
    : null;
  const probing = state.queueStatus === "running"
    && probe
    && Number(probe.observedRounds || 0) < Number(probe.requiredRounds || 0);
  const reportReady = state.queueStatus === "completed"
    && stats.totalTaskCount > 0
    && stats.completedTaskCount === stats.totalTaskCount
    && stats.missingTaskCount === 0
    && stats.conflictTaskCount === 0
    && stats.boundaryMismatchTaskCount === 0
    && stats.failedTaskCount === 0;
  return {
    status: probing ? "retrying" : stats.queueStatus,
    queueStatus: stats.queueStatus,
    total: stats.totalTaskCount,
    completed: stats.completedTaskCount,
    missing: stats.missingTaskCount,
    conflicts: stats.conflictTaskCount,
    boundaryMismatches: stats.boundaryMismatchTaskCount,
    failed: stats.failedTaskCount,
    retrying: stats.retryingTaskCount,
    currentDate: stats.currentDate,
    estimatedRemainingMs: stats.estimatedRemainingMs,
    progress: stats.progressPercent,
    reportReady,
    reportPartial: Boolean(state.historicalBaselineOmission || state.rangeCorrection || state.tailClosure),
    availability: probe ? {
      targetDate: String(probe.targetDate || ""),
      lastAvailableWindowDate: String(probe.lastAvailableWindowDate || ""),
      observedLagDays: Number.isInteger(Number(probe.observedLagDays)) ? Number(probe.observedLagDays) : null,
      observedRounds: Number(probe.observedRounds || 0),
      requiredRounds: Number(probe.requiredRounds || 0),
      remainingRounds: Math.max(0, Number(probe.requiredRounds || 0) - Number(probe.observedRounds || 0))
    } : state.tailClosure ? {
      targetDate: "",
      lastAvailableWindowDate: String(state.tailClosure.lastAvailableWindowDate || ""),
      observedLagDays: Number.isInteger(Number(state.tailClosure.observedLagDays)) ? Number(state.tailClosure.observedLagDays) : null,
      observedRounds: Number(state.tailClosure.observedRounds || 0),
      requiredRounds: Number(state.tailClosure.requiredRounds || 0),
      remainingRounds: 0
    } : null,
    tailClosure: state.tailClosure && typeof state.tailClosure === "object" ? {
      requestedAnalysisEndDate: String(state.tailClosure.requestedAnalysisEndDate || ""),
      effectiveAnalysisEndDate: String(state.tailClosure.effectiveAnalysisEndDate || ""),
      lastAvailableWindowDate: String(state.tailClosure.lastAvailableWindowDate || ""),
      omittedTaskCount: Number(state.tailClosure.omittedTaskCount || 0),
      observedRounds: Number(state.tailClosure.observedRounds || 0),
      requiredRounds: Number(state.tailClosure.requiredRounds || 0),
      observedLagDays: Number.isInteger(Number(state.tailClosure.observedLagDays)) ? Number(state.tailClosure.observedLagDays) : null
    } : null,
    archive: state.archive && typeof state.archive === "object" ? {
      status: String(state.archive.status || ""),
      archived: state.archive.archived === true,
      reportId: String(state.archive.reportId || ""),
      reportUrl: String(state.archive.reportUrl || ""),
      error: String(state.archive.error || "")
    } : null,
    error: state.lastError?.message || "",
    errorCode: state.lastError?.code || "",
    config: {
      cateId: state.cateId,
      periodType: state.periodType,
      analysisStart: state.requestedAnalysisRange?.startDate || state.analysisRange?.startDate || "",
      analysisEnd: state.requestedAnalysisRange?.endDate || state.analysisRange?.endDate || "",
      effectiveAnalysisStart: state.analysisRange?.startDate || "",
      effectiveAnalysisEnd: state.analysisRange?.endDate || "",
      queryStart: state.queryRange?.startDate || "",
      queryEnd: state.queryRange?.endDate || ""
    }
  };
}

async function broadcastRolling7(state) {
  try {
    await chrome.runtime.sendMessage({
      type: "DMP_ROLLING7_PROGRESS",
      state: publicRolling7State(state)
    });
  } catch {
    // Popup is normally closed while the queue runs; persisted state remains authoritative.
  }
}

async function syncRolling7Alarm(state) {
  if (!chrome.alarms) return;
  try {
    if (state?.queueStatus === "running") {
      await chrome.alarms.create(ROLLING7_ALARM_NAME, { delayInMinutes: ROLLING7_ALARM_DELAY_MINUTES });
    } else {
      await chrome.alarms.clear(ROLLING7_ALARM_NAME);
    }
  } catch {
    // The in-flight worker loop still proceeds; the alarm is only a MV3 wake-up checkpoint.
  }
}

async function readPersistedRolling7State() {
  if (rolling7IgnorePersistedState) return null;
  const stored = await chrome.storage.local.get(ROLLING7_STATE_KEY);
  const snapshot = stored[ROLLING7_STATE_KEY];
  if (!snapshot) return null;
  return rolling7.createCheckpoint(snapshot);
}

function rolling7TrackShopScope(value) {
  const expectedShop = normalizeExpectedShop(value);
  return expectedShop ? {
    officialShopId: expectedShop.officialShopId,
    sourceShopId: expectedShop.sourceShopId,
    shopName: expectedShop.shopName
  } : null;
}

function sameRolling7TrackShopScope(value, expectedShopInput) {
  const expected = rolling7TrackShopScope(expectedShopInput);
  const actual = rolling7TrackShopScope(value?.scope);
  return Boolean(expected && actual
    && expected.officialShopId === actual.officialShopId
    && expected.sourceShopId === actual.sourceShopId
    && expected.shopName === actual.shopName);
}

function validRolling7TrackSnapshot(value, cateId = "", expectedShopInput = null) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  if (value.schemaVersion !== "dmp-track/1.0") return null;
  if (!["ready", "partial", "empty", "failed"].includes(String(value.status || ""))) return null;
  if (!Array.isArray(value.priceRanges) || !Array.isArray(value.properties) || !Array.isArray(value.blockingIssues)) return null;
  const expectedCateId = String(cateId || "").trim();
  if (expectedCateId && String(value.cateId || "").trim() !== expectedCateId) return null;
  if (expectedShopInput && !sameRolling7TrackShopScope(value, expectedShopInput)) return null;
  try {
    rolling7.assertSensitiveFree(value);
  } catch {
    return null;
  }
  return value;
}

function rolling7TrackCellHasCompleteBusinessScores(cell) {
  const scores = cell?.scores;
  return Boolean(scores && typeof scores === "object" && !Array.isArray(scores)
    && ROLLING7_TRACK_REQUIRED_SCORE_KEYS.every(key =>
      typeof scores[key] === "number" && Number.isFinite(scores[key])));
}

function rolling7TrackPriceRangeName(value) {
  return String(value || "")
    .replace(/[￥¥,，\s]/g, "")
    .replace(/\.0(?=~|以上|$)/g, "")
    .replace(/[﹏～–—]/g, "~")
    .trim();
}

function rolling7TrackLatestContract(value) {
  const snapshot = validRolling7TrackSnapshot(value, value?.cateId);
  const source = snapshot?.audit?.latestContract;
  if (!snapshot || Number(snapshot.audit?.contractVersion || 0) < ROLLING7_TRACK_CONTRACT_VERSION
    || snapshot.audit?.authoritativePriceRangeCaptured !== true
    || !source || typeof source !== "object" || Array.isArray(source)
    || Number(source.version || 0) < ROLLING7_TRACK_LATEST_CONTRACT_VERSION) return null;
  const periodType = String(source.periodType || "").trim();
  const normalizeRequest = request => {
    if (!request || typeof request !== "object" || Array.isArray(request)) return null;
    const requestPeriodType = String(request.periodType || "").trim();
    const date = String(request.date || "").trim();
    return requestPeriodType === periodType && /^\d{1,2}$/.test(requestPeriodType)
      && /^20\d{2}-\d{2}-\d{2}$/.test(date)
      ? { periodType: requestPeriodType, date }
      : null;
  };
  if (!/^\d{1,2}$/.test(periodType)) return null;
  const currentRequest = normalizeRequest(source.currentRequest);
  if (!currentRequest) return null;
  const previousRequest = source.previousRequest == null ? null : normalizeRequest(source.previousRequest);
  if (snapshot.audit?.previousBoundaryVerified === true ? !previousRequest : previousRequest != null) return null;

  if (!Array.isArray(source.expectedPriceRanges) || source.expectedPriceRanges.length === 0) return null;
  const expectedPriceRanges = source.expectedPriceRanges.map(range => ({
    id: String(range?.id || "").trim(),
    name: rolling7TrackPriceRangeName(range?.name ?? range)
  }));
  if (expectedPriceRanges.some(range => !range.name)
    || new Set(expectedPriceRanges.map(range => range.name)).size !== expectedPriceRanges.length) return null;

  if (!Array.isArray(source.expectedProperties) || source.expectedProperties.length === 0) return null;
  const expectedProperties = source.expectedProperties.map(property => ({
    propertyId: String(property?.propertyId || "").trim(),
    propertyName: String(property?.propertyName || "").trim(),
    propertyValues: Array.isArray(property?.propertyValues) ? property.propertyValues.map(propertyValue => ({
      id: String(propertyValue?.id || "").trim(),
      name: String(propertyValue?.name ?? propertyValue?.propertyValueName ?? propertyValue ?? "").trim()
    })) : []
  }));
  if (expectedProperties.some(property => !property.propertyId || !property.propertyName
      || property.propertyValues.length === 0
      || property.propertyValues.some(propertyValue => !propertyValue.name)
      || new Set(property.propertyValues.map(propertyValue => propertyValue.name)).size !== property.propertyValues.length)
    || new Set(expectedProperties.map(property => property.propertyId)).size !== expectedProperties.length) return null;
  return {
    version: ROLLING7_TRACK_LATEST_CONTRACT_VERSION,
    periodType,
    currentRequest,
    previousRequest,
    requests: previousRequest ? [currentRequest, previousRequest] : [currentRequest],
    expectedPriceRanges,
    expectedProperties
  };
}

function rolling7TrackPeriodHasBusinessValue(period, expectedPriceRanges, expectedPropertyValues) {
  if (!Array.isArray(period?.columns) || !Array.isArray(period?.rows) || period.rows.length === 0
    || !Array.isArray(expectedPriceRanges) || expectedPriceRanges.length === 0
    || !Array.isArray(expectedPropertyValues) || expectedPropertyValues.length === 0) return false;
  const propertyValueNames = period.columns.map(value => String(value || "").trim());
  if (propertyValueNames.some(name => !name)
    || new Set(propertyValueNames).size !== propertyValueNames.length
    || propertyValueNames.length !== expectedPropertyValues.length
    || expectedPropertyValues.some(name => !propertyValueNames.includes(name))) return false;
  const actualPriceRanges = period.rows.map(row => rolling7TrackPriceRangeName(row?.priceRange));
  if (actualPriceRanges.some(name => !name)
    || new Set(actualPriceRanges).size !== actualPriceRanges.length
    || actualPriceRanges.length !== expectedPriceRanges.length
    || expectedPriceRanges.some(name => !actualPriceRanges.includes(name))) return false;
  return period.rows.every(row => {
    if (!Array.isArray(row?.cells)) return false;
    const cellNames = row.cells.map(cell =>
      String(cell?.propertyValueName ?? cell?.property ?? "").trim());
    if (cellNames.some(name => !name)
      || new Set(cellNames).size !== cellNames.length
      || cellNames.length !== propertyValueNames.length
      || propertyValueNames.some(name => !cellNames.includes(name))) return false;
    return row.cells.every(rolling7TrackCellHasCompleteBusinessScores);
  });
}

function rolling7TrackMatrixContractComplete(value) {
  const snapshot = validRolling7TrackSnapshot(value, value?.cateId);
  const latestContract = rolling7TrackLatestContract(snapshot);
  if (!snapshot || !latestContract) return false;
  const expectedPriceRanges = latestContract.expectedPriceRanges.map(range => range.name);
  return latestContract.expectedProperties.every(expectedProperty => {
    const property = snapshot.properties.find(candidate =>
      String(candidate?.propertyId || "").trim() === expectedProperty.propertyId);
    if (!property || String(property?.propertyName || "").trim() !== expectedProperty.propertyName
      || !Array.isArray(property.periods)) return false;
    const expectedPropertyValues = expectedProperty.propertyValues.map(propertyValue => propertyValue.name);
    return latestContract.requests.every(request => property.periods.some(period =>
      String(period?.date || "") === request.date
      && String(period?.periodType || "") === request.periodType
      && Array.isArray(period?.columns)
      && period.columns.length > 0
      && rolling7TrackPeriodHasBusinessValue(period, expectedPriceRanges, expectedPropertyValues)));
  });
}

function rolling7TrackOpportunityContractComplete(value) {
  const snapshot = validRolling7TrackSnapshot(value, value?.cateId);
  const latestContract = rolling7TrackLatestContract(snapshot);
  if (!snapshot || !latestContract
    || snapshot.audit?.opportunityCaptureAttempted !== true
    || snapshot.audit?.opportunityCaptureComplete !== true) return false;
  if (!Array.isArray(snapshot.opportunities)) return false;
  return latestContract.requests.every(request => snapshot.opportunities.some(period =>
    String(period?.date || "") === request.date
    && String(period?.periodType || "") === request.periodType
    && String(period?.status || "") === "ready"
    && Array.isArray(period?.chanceGroups)
    && Array.isArray(period?.issues)
    && period.issues.length === 0
    && period.chanceGroups.every(group => String(group?.status || "") === "ready"
      && Array.isArray(group?.issues) && group.issues.length === 0
      && Array.isArray(group?.tracks))));
}

function reusableRolling7TrackSnapshot(value) {
  return Boolean(value
    && value.status === "ready"
    && rolling7TrackMatrixContractComplete(value)
    && rolling7TrackOpportunityContractComplete(value));
}

function rolling7TrackPeriodIdentity(value) {
  return [value?.periodType, value?.date, value?.startDate, value?.endDate]
    .map(part => String(part || ""))
    .join("|");
}

function mergeRolling7TrackSnapshots(previousValue, nextValue) {
  const next = validRolling7TrackSnapshot(nextValue, nextValue?.cateId);
  if (!next) return validRolling7TrackSnapshot(previousValue, previousValue?.cateId);
  const previous = validRolling7TrackSnapshot(previousValue, next.cateId);
  const previousHasHistory = Boolean(previous?.properties.some(property =>
    Array.isArray(property?.periods) && property.periods.length));
  if (!previous || (!["ready", "partial"].includes(previous.status) && !previousHasHistory)) return next;
  if (!["ready", "partial"].includes(next.status)
    || !next.properties.some(property => Array.isArray(property?.periods) && property.periods.length)) {
    const carriedFailure = {
      ...previous,
      ...next,
      priceRanges: previous.priceRanges,
      properties: previous.properties,
      opportunities: Array.isArray(previous.opportunities) ? previous.opportunities : []
    };
    if (!Object.prototype.hasOwnProperty.call(next, "error")) delete carriedFailure.error;
    return validRolling7TrackSnapshot(carriedFailure, next.cateId) || next;
  }

  const rangeMap = new Map();
  for (const range of [...previous.priceRanges, ...next.priceRanges]) {
    const key = String(range?.id || "").trim() || String(range?.name || "").trim();
    if (key) rangeMap.set(key, range);
  }
  const propertyMap = new Map();
  for (const source of [...previous.properties, ...next.properties]) {
    const propertyId = String(source?.propertyId || "").trim();
    if (!propertyId) continue;
    const existing = propertyMap.get(propertyId);
    const valueMap = new Map();
    for (const value of [...(existing?.propertyValues || []), ...(source?.propertyValues || [])]) {
      const key = String(value?.id || "").trim() || String(value?.name || "").trim();
      if (key) valueMap.set(key, value);
    }
    const periodMap = new Map();
    for (const period of [...(existing?.periods || []), ...(source?.periods || [])]) {
      const key = rolling7TrackPeriodIdentity(period);
      if (key && key !== "|||") periodMap.set(key, period);
    }
    propertyMap.set(propertyId, {
      ...(existing || {}),
      ...source,
      propertyValues: [...valueMap.values()],
      periods: [...periodMap.values()].sort((left, right) =>
        String(right?.endDate || right?.date || "").localeCompare(String(left?.endDate || left?.date || "")))
    });
  }
  const opportunityMap = new Map();
  for (const period of [...(previous.opportunities || []), ...(next.opportunities || [])]) {
    const key = rolling7TrackPeriodIdentity(period);
    if (key && key !== "|||") opportunityMap.set(key, period);
  }
  return validRolling7TrackSnapshot({
    ...next,
    priceRanges: [...rangeMap.values()],
    properties: [...propertyMap.values()],
    opportunities: [...opportunityMap.values()].sort((left, right) =>
      String(right?.endDate || right?.date || "").localeCompare(String(left?.endDate || left?.date || "")))
  }, next.cateId) || next;
}

function mergeRolling7TrackDataset(dataset, trackSnapshot, expectedShopInput = null) {
  const snapshot = validRolling7TrackSnapshot(trackSnapshot, dataset?.cateId, expectedShopInput);
  if (!snapshot) {
    const current = validRolling7TrackSnapshot(dataset?.track, dataset?.cateId, expectedShopInput);
    if (current) return { ...dataset, track: current };
    if (!dataset || typeof dataset !== "object") return dataset;
    const { track: _staleTrack, trackSnapshot: _staleTrackSnapshot, ...cleanDataset } = dataset;
    return cleanDataset;
  }
  const { trackSnapshot: _legacyTrackSnapshot, ...cleanDataset } = dataset;
  return { ...cleanDataset, track: snapshot };
}

async function readStoredRolling7TrackSnapshot(cateId = "", expectedShopInput = null) {
  try {
    const expectedShop = normalizeExpectedShop(expectedShopInput);
    if (!expectedShop) return null;
    const stored = await chrome.storage.local.get(ROLLING7_TRACK_KEY);
    return validRolling7TrackSnapshot(stored[ROLLING7_TRACK_KEY], cateId, expectedShop);
  } catch {
    return null;
  }
}

async function persistRolling7State(state) {
  const checkpoint = rolling7.createCheckpoint(state);
  const expectedShop = normalizeExpectedShop(checkpoint.expectedShop);
  const sourceShop = core.sanitizeSourceShop(checkpoint.sourceShop);
  const trackSnapshot = await readStoredRolling7TrackSnapshot(checkpoint.cateId, expectedShop);
  const dataset = mergeRolling7TrackDataset({
    ...rolling7.buildDataset(checkpoint),
    ...(sourceShop ? { sourceShop } : {}),
    ...(expectedShop ? { expectedShop } : {})
  }, trackSnapshot, expectedShop);
  rolling7.assertSensitiveFree(checkpoint);
  rolling7.assertSensitiveFree(dataset);
  await chrome.storage.local.set({
    [ROLLING7_STATE_KEY]: checkpoint,
    [ROLLING7_DATASET_KEY]: dataset
  });
  if (rolling7DatasetIsReady(dataset) && rolling7HtmlWriter?.buildHtml) {
    const html = rolling7HtmlWriter.buildHtml(dataset);
    rolling7.assertSensitiveFree(html);
    await chrome.storage.local.set({ [ROLLING7_HTML_KEY]: html });
  } else {
    await chrome.storage.local.set({ [ROLLING7_HTML_KEY]: null });
  }
  rolling7IgnorePersistedState = false;
  rolling7State = checkpoint;
  await syncRolling7Alarm(checkpoint);
  await broadcastRolling7(checkpoint);
  return checkpoint;
}

function mutateRolling7State(mutator) {
  const operation = rolling7MutationTail
    .catch(() => {})
    .then(async () => {
      if (!rolling7State) rolling7State = await readPersistedRolling7State();
      const next = await mutator(rolling7State);
      if (!next) return rolling7State;
      return persistRolling7State(next);
    });
  rolling7MutationTail = operation.then(() => undefined, () => undefined);
  return operation;
}

async function currentRolling7State() {
  await rolling7MutationTail.catch(() => {});
  if (!rolling7State) rolling7State = await readPersistedRolling7State();
  return rolling7State;
}

async function ensureRolling7Initialized() {
  if (rolling7InitializationPromise) return rolling7InitializationPromise;
  rolling7InitializationPromise = (async () => {
    try {
      const snapshot = await readPersistedRolling7State();
      rolling7LoadError = null;
      rolling7IgnorePersistedState = false;
      if (!snapshot) return null;
      const interrupted = Boolean(snapshot.currentTaskId)
        || snapshot.tasks.some(task => task.status === "running");
      const restored = interrupted
        ? rolling7.restoreQueueState(snapshot, { autoResume: snapshot.queueStatus === "running" })
        : snapshot;
      return persistRolling7State(migrateUnavailableRolling7Tail(restored));
    } catch (error) {
      rolling7LoadError = rolling7SafeError(error, "本地滚动7天断点无效，未自动继续");
      rolling7IgnorePersistedState = true;
      rolling7State = null;
      return null;
    }
  })();
  return rolling7InitializationPromise;
}

function normalizeDraftValue(value) {
  const text = String(value ?? "").trim();
  if (!/^\d{0,20}$/.test(text)) {
    const error = new Error("商品 ID 草稿只能包含数字且不超过 20 位");
    error.code = "INVALID_DRAFT";
    throw error;
  }
  return text;
}

function normalizeDraft(input) {
  return {
    subjectItemId: normalizeDraftValue(input?.subjectItemId),
    successItemId: normalizeDraftValue(input?.successItemId),
    savedAt: new Date().toISOString()
  };
}

function saveDraft(input) {
  const draft = normalizeDraft(input);
  draftWriteTail = draftWriteTail
    .catch(() => {})
    .then(async () => {
      await chrome.storage.local.set({ [DRAFT_KEY]: draft });
      return draft;
    });
  return draftWriteTail;
}

async function readDraftAfterPendingWrites() {
  await draftWriteTail.catch(() => {});
  const stored = await chrome.storage.local.get(DRAFT_KEY);
  return Object.prototype.hasOwnProperty.call(stored, DRAFT_KEY)
    ? normalizeDraft(stored[DRAFT_KEY])
    : null;
}

function publicJob(job) {
  if (!job) return null;
  return {
    id: job.id,
    subjectItemId: job.subjectItemId,
    successItemId: job.successItemId,
    status: job.status,
    statusLabel: job.statusLabel,
    step: job.step,
    progress: job.progress,
    startedAt: job.startedAt,
    finishedAt: job.finishedAt || "",
    period: job.period || null,
    requestedPeriod: job.requestedPeriod || null,
    effectivePeriod: job.effectivePeriod || job.period || null,
    previousPeriod: job.previousPeriod || null,
    commonLatestDay: job.commonLatestDay || "",
    latestDay: job.latestDay || "",
    recordCount: Number(job.recordCount || 0),
    sceneCount: Number(job.sceneCount || 0),
    sceneMissed: Array.isArray(job.sceneMissed) ? job.sceneMissed : [],
    warnings: Array.isArray(job.warnings) ? job.warnings : [],
    expectedShop: normalizeExpectedShop(job.expectedShop),
    enforceExpectedShop: job.enforceExpectedShop === true,
    error: job.error || "",
    errorCode: job.errorCode || ""
  };
}

async function readSanjieSessions() {
  const queries = [
    ...OFFICIAL_COOKIE_URLS.map(url => ({ url, name: SANJIE_SESSION_COOKIE })),
    { domain: "shaozhuangai.com", name: SANJIE_SESSION_COOKIE }
  ];
  const settled = await Promise.allSettled(queries.map(query => chrome.cookies.getAll(query)));
  const nowSeconds = Date.now() / 1000;
  const values = [];
  const seen = new Set();
  for (const result of settled) {
    if (result.status !== "fulfilled") continue;
    for (const cookie of result.value || []) {
      const value = String(cookie?.value || "");
      if (!value || seen.has(value) || (cookie.expirationDate && Number(cookie.expirationDate) <= nowSeconds)) continue;
      seen.add(value);
      values.push(value);
    }
  }
  return values;
}

let activeSanjieSession = "";

async function readSanjieSession() {
  const sessions = await readSanjieSessions();
  return sessions.includes(activeSanjieSession) ? activeSanjieSession : sessions[0] || "";
}

async function readSanjieActiveShopId() {
  const settled = await Promise.allSettled(OFFICIAL_COOKIE_URLS.map(url =>
    chrome.cookies.getAll({ url, name: SANJIE_ACTIVE_SHOP_COOKIE })));
  for (const result of settled) {
    if (result.status !== "fulfilled") continue;
    const selected = [...(result.value || [])]
      .filter(cookie => String(cookie?.value || "").trim())
      .sort((left, right) => String(right.path || "").length - String(left.path || "").length)[0];
    if (selected?.value) return String(selected.value).trim();
  }
  return "";
}

let officialAuthCache = { expiresAt: 0, result: null };
const OFFICIAL_LAUNCH_KEY_PREFIX = "dmpOfficialReportLaunchV1:";
const OFFICIAL_FRAME_KEY_PREFIX = "dmpOfficialReportFrameV1:";
const ROLLING7_REPORT_FRAME_KEY_PREFIX = "dmpMarketRolling7ReportFrameV1:";

function officialLocalFallbackUrl(launchNonce) {
  return `${core.SANJIE_ORIGIN}/tools/dmp-report?source=dmp-extension#launch=${encodeURIComponent(launchNonce)}`;
}

function officialArchivedReportUrl(value) {
  return normalizeOfficialReportUrl(value, core.SANJIE_ORIGIN);
}

async function openOfficialArchivedReport(value) {
  const reportUrl = officialArchivedReportUrl(value);
  if (!reportUrl) {
    const error = new Error("官网报告链接无效");
    error.code = "SANJIE_REPORT_URL_INVALID";
    throw error;
  }
  const tab = await chrome.tabs.create({ url: reportUrl });
  return { reportUrl, tabId: tab?.id || null };
}

function createLaunchNonce() {
  const bytes = new Uint8Array(24);
  crypto.getRandomValues(bytes);
  return [...bytes].map(value => value.toString(16).padStart(2, "0")).join("");
}

function officialNonceKey(prefix, nonce) {
  return `${prefix}${nonce}`;
}

async function readOfficialNonce(prefix, nonce) {
  const key = officialNonceKey(prefix, nonce);
  const stored = await chrome.storage.session.get(key);
  return stored[key] || null;
}

async function writeOfficialNonce(prefix, nonce, value) {
  const key = officialNonceKey(prefix, nonce);
  await chrome.storage.session.set({ [key]: value });
}

async function deleteOfficialNonce(prefix, nonce) {
  await chrome.storage.session.remove(officialNonceKey(prefix, nonce));
}

async function cleanupOfficialLaunches(now = Date.now()) {
  const stored = await chrome.storage.session.get(null);
  const expired = Object.entries(stored)
    .filter(([key, value]) => (key.startsWith(OFFICIAL_LAUNCH_KEY_PREFIX)
      || key.startsWith(OFFICIAL_FRAME_KEY_PREFIX)
      || key.startsWith(ROLLING7_REPORT_FRAME_KEY_PREFIX))
      && (!value || Number(value.expiresAt || 0) <= now))
    .map(([key]) => key);
  if (expired.length) await chrome.storage.session.remove(expired);
}

function isOfficialSiteOrigin(value) {
  try {
    const parsed = new URL(String(value || ""));
    return parsed.protocol === "https:"
      && (parsed.hostname === "shaozhuangai.com" || parsed.hostname === "www.shaozhuangai.com");
  } catch {
    return false;
  }
}

function isOfficialLocalReportPage(value) {
  try {
    const parsed = new URL(String(value || ""));
    return isOfficialSiteOrigin(parsed.origin)
      && parsed.pathname === "/tools/dmp-report"
      && parsed.searchParams.get("source") === "dmp-extension";
  } catch {
    return false;
  }
}

async function prepareOfficialReportFrame(message, sender) {
  await cleanupOfficialLaunches();
  const nonce = String(message?.launchNonce || "");
  const launch = await readOfficialNonce(OFFICIAL_LAUNCH_KEY_PREFIX, nonce);
  const senderUrl = sender?.url || sender?.tab?.url || "";
  if (!/^[a-f0-9]{48}$/.test(nonce)
    || !launch
    || launch.used
    || launch.expiresAt <= Date.now()
    || sender?.id !== chrome.runtime.id
    || Number(sender?.frameId || 0) !== 0
    || !isOfficialSiteOrigin(sender?.origin)
    || !isOfficialLocalReportPage(senderUrl)
    || !isOfficialLocalReportPage(sender?.tab?.url)
    || (launch.tabId != null && Number(sender?.tab?.id) !== Number(launch.tabId))) {
    throw new Error("报告打开凭证已失效，请从扩展重新打开");
  }
  await writeOfficialNonce(OFFICIAL_LAUNCH_KEY_PREFIX, nonce, {
    ...launch,
    tabId: launch.tabId == null ? sender.tab.id : launch.tabId,
    used: true
  });
  requireOfficialSiteAccess(await checkOfficialSiteAccess(true));
  const state = await readLocalState();
  if (!isArchivableStoredReport(state.report)) {
    throw new Error("本机没有可归档的 HTML 报告");
  }
  const frameNonce = createLaunchNonce();
  await writeOfficialNonce(OFFICIAL_FRAME_KEY_PREFIX, frameNonce, {
    tabId: sender.tab.id,
    expiresAt: Date.now() + OFFICIAL_LAUNCH_TTL_MS
  });
  await deleteOfficialNonce(OFFICIAL_LAUNCH_KEY_PREFIX, nonce);
  return { ok: true, frameUrl: `${chrome.runtime.getURL("direct-report.html")}#frame=${frameNonce}` };
}

function isDirectReportFrame(value) {
  try {
    const parsed = new URL(String(value || ""));
    return parsed.protocol === "chrome-extension:" && parsed.pathname === "/direct-report.html";
  } catch {
    return false;
  }
}

function isRolling7ReportPage(value) {
  try {
    const parsed = new URL(String(value || ""));
    return parsed.protocol === "chrome-extension:"
      && parsed.hostname === chrome.runtime.id
      && parsed.pathname === "/rolling7-report.html";
  } catch {
    return false;
  }
}

function rolling7DatasetIsReady(dataset) {
  const quality = dataset?.completeness || {};
  const countFields = ["expectedTaskCount", "completedTaskCount", "missingTaskCount", "conflictTaskCount", "boundaryMismatchCount", "unexpectedWindowCount"];
  if (countFields.some(field => !Number.isInteger(quality[field]) || quality[field] < 0)) return false;
  const baselineQuality = dataset?.baselineCompleteness;
  if (baselineQuality && typeof baselineQuality === "object") {
    const baselineCountFields = ["expectedTaskCount", "completedTaskCount", "missingTaskCount", "conflictTaskCount", "boundaryMismatchCount"];
    if (baselineCountFields.some(field => !Number.isInteger(baselineQuality[field]) || baselineQuality[field] < 0)) return false;
    if (baselineQuality.expectedTaskCount > 0 && (
      baselineQuality.status !== "ready"
      || baselineQuality.completedTaskCount !== baselineQuality.expectedTaskCount
      || baselineQuality.missingTaskCount !== 0
      || baselineQuality.conflictTaskCount !== 0
      || baselineQuality.boundaryMismatchCount !== 0
    )) return false;
  }
  const expected = quality.expectedTaskCount;
  return dataset?.schemaVersion === rolling7.DATASET_SCHEMA_VERSION
    && dataset?.kind === "dataset"
    && quality.status === "ready"
    && expected > 0
    && quality.completedTaskCount === expected
    && quality.missingTaskCount === 0
    && quality.conflictTaskCount === 0
    && quality.boundaryMismatchCount === 0
    && quality.unexpectedWindowCount === 0
    && Array.isArray(dataset.windows)
    && Array.isArray(dataset.baselines || [])
    && dataset.windows.length + (dataset.baselines || []).length === expected;
}

async function readStoredRolling7Dataset() {
  const stored = await chrome.storage.local.get([ROLLING7_DATASET_KEY, ROLLING7_TRACK_KEY]);
  const storedDataset = stored[ROLLING7_DATASET_KEY];
  const expectedShop = normalizeExpectedShop(storedDataset?.expectedShop);
  if (!expectedShop) throw directShopError("SHOP_REQUIRED", "类目大盘任务缺少不可变店铺身份，已拒绝读取和归档");
  const dataset = mergeRolling7TrackDataset(
    storedDataset,
    validRolling7TrackSnapshot(stored[ROLLING7_TRACK_KEY], storedDataset?.cateId, expectedShop),
    expectedShop
  );
  rolling7.assertSensitiveFree(dataset);
  if (!rolling7DatasetIsReady(dataset)) {
    const error = new Error("滚动7天数据尚未完整闭合，不能生成完整 HTML 报告");
    error.code = "ROLLING7_REPORT_NOT_READY";
    throw error;
  }
  return dataset;
}

async function readStoredRolling7Html(dataset) {
  if (!rolling7HtmlWriter?.buildHtml) throw new Error("滚动7天 HTML 报告模块未就绪");
  const stored = await chrome.storage.local.get(ROLLING7_HTML_KEY);
  const current = stored[ROLLING7_HTML_KEY];
  const expected = rolling7HtmlWriter.buildHtml(dataset);
  rolling7.assertSensitiveFree(expected);
  if (current === expected) {
    rolling7.assertSensitiveFree(current);
    return current;
  }
  await chrome.storage.local.set({ [ROLLING7_HTML_KEY]: expected });
  return expected;
}

async function openRolling7StoredReport() {
  await cleanupOfficialLaunches();
  await readStoredRolling7Dataset();
  const frameNonce = createLaunchNonce();
  await writeOfficialNonce(ROLLING7_REPORT_FRAME_KEY_PREFIX, frameNonce, {
    tabId: null,
    expiresAt: Date.now() + OFFICIAL_LAUNCH_TTL_MS
  });
  try {
    const tab = await chrome.tabs.create({ url: `${chrome.runtime.getURL("rolling7-report.html")}#frame=${frameNonce}` });
    return { ok: true, tabId: tab?.id || null };
  } catch (error) {
    await deleteOfficialNonce(ROLLING7_REPORT_FRAME_KEY_PREFIX, frameNonce);
    throw error;
  }
}

async function synchronizeAndOpenRolling7OfficialReport() {
  requireOfficialSiteAccess(await checkOfficialSiteAccess(true));
  await readStoredRolling7Dataset();
  const synchronized = await scheduleStoredRolling7Archive("manual-open");
  const state = await currentRolling7State();
  const reportUrl = officialArchivedReportUrl(
    synchronized?.reportUrl || state?.archive?.reportUrl
  );
  if (synchronized?.ok !== true || !reportUrl) {
    const opened = await openRolling7StoredReport();
    return {
      ok: true,
      archived: false,
      fallback: true,
      localFallback: true,
      tabId: opened.tabId,
      archiveError: String(
        synchronized?.error
          || state?.archive?.error
          || "官网类目报告同步未完成，本机完整报告已打开"
      ),
      errorCode: String(synchronized?.errorCode || "SANJIE_IMPORT_FAILED")
    };
  }
  const opened = await openOfficialArchivedReport(reportUrl);
  return {
    ok: true,
    archived: true,
    reportId: String(synchronized.reportId || state?.archive?.reportId || ""),
    reportUrl: opened.reportUrl,
    tabId: opened.tabId
  };
}

async function readRolling7FrameReport(message, sender) {
  await cleanupOfficialLaunches();
  const nonce = String(message?.frameNonce || "");
  const frame = await readOfficialNonce(ROLLING7_REPORT_FRAME_KEY_PREFIX, nonce);
  if (!/^[a-f0-9]{48}$/.test(nonce)
    || !frame
    || frame.expiresAt <= Date.now()
    || sender?.id !== chrome.runtime.id
    || Number(sender?.frameId || 0) !== 0
    || !isRolling7ReportPage(sender?.url)
    || (frame.tabId != null && Number(sender?.tab?.id) !== Number(frame.tabId))) {
    throw new Error("滚动报告读取凭证已失效，请从扩展重新打开");
  }
  await deleteOfficialNonce(ROLLING7_REPORT_FRAME_KEY_PREFIX, nonce);
  const dataset = await readStoredRolling7Dataset();
  return { ok: true, dataset, html: await readStoredRolling7Html(dataset) };
}

async function readOfficialFrameReport(message, sender) {
  await cleanupOfficialLaunches();
  const nonce = String(message?.frameNonce || "");
  const frame = await readOfficialNonce(OFFICIAL_FRAME_KEY_PREFIX, nonce);
  if (!/^[a-f0-9]{48}$/.test(nonce)
    || !frame
    || frame.expiresAt <= Date.now()
    || sender?.id !== chrome.runtime.id
    || Number(sender?.frameId) <= 0
    || Number(sender?.tab?.id) !== Number(frame.tabId)
    || !isDirectReportFrame(sender?.url)
    || !isOfficialLocalReportPage(sender?.tab?.url)) {
    throw new Error("报告读取凭证已失效，请从扩展重新打开");
  }
  await deleteOfficialNonce(OFFICIAL_FRAME_KEY_PREFIX, nonce);
  requireOfficialSiteAccess(await checkOfficialSiteAccess(true));
  const state = await readLocalState();
  if (!isArchivableStoredReport(state.report)) {
    throw new Error("本机没有可归档的 HTML 报告");
  }
  return { ok: true, report: state.report };
}

async function checkOfficialSiteAccess(force = false) {
  const now = Date.now();
  if (!force && officialAuthCache.result?.ok && officialAuthCache.expiresAt > now) {
    return structuredClone(officialAuthCache.result);
  }
  const tokens = await readSanjieSessions();
  if (!tokens.length) {
    return { ok: false, reason: "nologin", error: "请先登录 shaozhuangai.com，再使用达摩盘自动化" };
  }
  for (const token of tokens) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), OFFICIAL_AUTH_TIMEOUT_MS);
    try {
      const response = await fetch(`${core.SANJIE_ORIGIN}/api/auth/me`, {
        method: "GET",
        headers: { "x-sanjie-session": token },
        cache: "no-store",
        credentials: "omit",
        redirect: "error",
        signal: controller.signal
      });
      const result = await response.json().catch(() => ({}));
      if (response.status === 401) continue;
      if (!response.ok || !result?.data) {
        return {
          ok: false,
          reason: "unavailable",
          error: `官网在线校验失败（HTTP ${response.status}）`
        };
      }
      activeSanjieSession = token;
      const entitlement = result.data.dmpEntitlement || null;
      if (result.data.service?.online !== true || result.data.capabilities?.dmpAutomation !== true) {
        const expired = entitlement?.status === "expired";
        return {
          ok: false,
          reason: expired ? "expired" : "denied",
          error: expired
            ? "达摩盘自动化的 30 天授权已到期，请联系管理员付费续费"
            : "当前官网账号未开通达摩盘自动化权限，请联系管理员付费开通"
        };
      }
      const verified = {
        ok: true,
        checkedAt: result.data.service?.checkedAt || new Date().toISOString(),
        entitlement: {
          status: String(entitlement?.status || "active"),
          expiresAt: String(entitlement?.expiresAt || ""),
          remainingDays: Number(entitlement?.remainingDays || 0)
        }
      };
      officialAuthCache = { result: verified, expiresAt: now + OFFICIAL_AUTH_CACHE_MS };
      return structuredClone(verified);
    } catch (error) {
      return {
        ok: false,
        reason: "offline",
        error: error?.name === "AbortError" ? "官网在线校验超时，插件已停止运行" : "官网暂时不可达，插件已停止运行"
      };
    } finally {
      clearTimeout(timeout);
    }
  }
  return { ok: false, reason: "invalid", error: "官网登录已失效，请重新登录 shaozhuangai.com" };
}

function requireOfficialSiteAccess(result) {
  if (result?.ok) return result;
  const error = new Error(result?.error || "shaozhuangai.com 授权核验未通过");
  error.code = `OFFICIAL_AUTH_${String(result?.reason || "FAILED").toUpperCase()}`;
  throw error;
}

function sanjieComparableReport(report) {
  const renderData = core.sanitizeRenderData(report?.render_data);
  if (renderData) delete renderData.generated_at;
  return JSON.stringify({
    schema_version: String(report?.schema_version || ""),
    item_id: String(report?.item_id || ""),
    period: String(report?.period || ""),
    render_data: renderData,
    tables: Array.isArray(report?.tables) ? report.tables.map(table => ({
      name: String(table?.name || ""),
      columns: Array.isArray(table?.columns) ? table.columns.map(String) : [],
      rows: Array.isArray(table?.rows) ? table.rows.map(row => ({ cells: Array.isArray(row?.cells) ? row.cells.map(String) : [] })) : []
    })) : []
  });
}

function archiveReportQuality(report) {
  return report?.quality?.complete === true
    && report?.quality?.exportAllowed === true
    && report?.quality?.status === "ready"
    && Number(report?.quality?.failedRecords || 0) === 0
    ? "complete"
    : "partial";
}

function archiveFingerprintHash(value) {
  let left = 0x811c9dc5;
  let right = 0x9e3779b9;
  const text = String(value || "");
  for (let index = 0; index < text.length; index += 1) {
    const code = text.charCodeAt(index);
    left ^= code;
    left = Math.imul(left, 0x01000193) >>> 0;
    right ^= code + index;
    right = Math.imul(right, 0x85ebca6b) >>> 0;
  }
  return `${left.toString(16).padStart(8, "0")}${right.toString(16).padStart(8, "0")}`;
}

function archiveOutboxFingerprint(report, context = {}) {
  const ids = storedReportArchiveIds({
    report,
    lastConfig: context.lastConfig,
    job: context.job
  });
  const canonical = reportEngine.toCanonicalReport(report);
  const period = report?.period || context.job?.period || null;
  const sourceShop = core.sanitizeSourceShop(context.sourceShop || context.job?.sourceShop);
  const expectedShop = normalizeExpectedShop(context.expectedShop || context.job?.expectedShop);
  const fingerprint = archiveFingerprintHash(JSON.stringify({
    subjectItemId: ids.subjectItemId,
    successItemId: ids.successItemId,
    period,
    sourceShopIdentity: sourceShop?.sourceShopId || sourceShop?.shopName || "",
    expectedShopIdentity: expectedShop?.officialShopId || "",
    report: sanjieComparableReport(canonical)
  }));
  return { ids, fingerprint, period, sourceShop, expectedShop };
}

function archiveOutboxEntry(state, report = state?.report, job = state?.job, sanjie = state?.sanjie) {
  const identity = archiveOutboxFingerprint(report, {
    lastConfig: state?.lastConfig,
    job,
    sourceShop: state?.sourceShop,
    expectedShop: state?.expectedShop
  });
  const now = new Date().toISOString();
  const outbox = normalizeArchiveOutbox(state?.archiveOutbox);
  const existingIndex = outbox.findIndex(entry => entry?.fingerprint === identity.fingerprint);
  if (existingIndex < 0 && outbox.length >= ARCHIVE_OUTBOX_LIMIT) {
    const error = new Error(`本地待归档报告已达 ${ARCHIVE_OUTBOX_LIMIT} 份，请联网登录官网完成补传后再开始新任务`);
    error.code = "ARCHIVE_OUTBOX_FULL";
    throw error;
  }
  const existing = existingIndex >= 0 ? outbox[existingIndex] : null;
  const sequence = existing?.sequence || outbox.reduce((maximum, entry) => Math.max(maximum, Number(entry?.sequence || 0)), 0) + 1;
  const entry = {
    id: existing?.id || `growth-${identity.fingerprint}`,
    fingerprint: identity.fingerprint,
    sequence,
    queuedAt: existing?.queuedAt || now,
    updatedAt: now,
    lastConfig: identity.ids,
    period: identity.period,
    sourceShop: identity.sourceShop,
    expectedShop: identity.expectedShop,
    report,
    job: publicJob(job),
    sanjie: sanjie && typeof sanjie === "object" ? { ...sanjie } : null,
    attempts: Number(existing?.attempts || 0)
  };
  if (existingIndex >= 0) outbox[existingIndex] = entry;
  else outbox.push(entry);
  state.archiveOutbox = outbox;
  return entry;
}

function archiveEntryIndex(state, fingerprint) {
  return normalizeArchiveOutbox(state?.archiveOutbox)
    .findIndex(entry => entry?.fingerprint === fingerprint);
}

function updateArchiveOutboxEntry(state, fingerprint, updates) {
  const outbox = normalizeArchiveOutbox(state?.archiveOutbox);
  const index = outbox.findIndex(entry => entry?.fingerprint === fingerprint);
  if (index < 0) return null;
  outbox[index] = {
    ...outbox[index],
    ...updates,
    updatedAt: new Date().toISOString()
  };
  state.archiveOutbox = outbox;
  return outbox[index];
}

function removeArchiveOutboxEntry(state, fingerprint) {
  const outbox = normalizeArchiveOutbox(state?.archiveOutbox);
  state.archiveOutbox = outbox.filter(entry => entry?.fingerprint !== fingerprint);
}

function sortedArchiveOutbox(state) {
  return normalizeArchiveOutbox(state?.archiveOutbox)
    .filter(entry => isArchivableStoredReport(entry?.report))
    .slice()
    .sort((left, right) => String(left?.queuedAt || "").localeCompare(String(right?.queuedAt || ""))
      || Number(left?.sequence || 0) - Number(right?.sequence || 0));
}

function currentArchiveFingerprint(state) {
  if (!isArchivableStoredReport(state?.report)) return "";
  try {
    return archiveOutboxFingerprint(state.report, state).fingerprint;
  } catch {
    return "";
  }
}

async function ensureCurrentReportQueued(state) {
  if (!isArchivableStoredReport(state?.report) || isArchivedSanjieState(state?.sanjie)) return null;
  const entry = archiveOutboxEntry(state, state.report, state.job, state.sanjie);
  await writeLocalState(state);
  return entry;
}

async function requestSanjie(token, method, body = "", apiPath = core.SANJIE_REPORT_API_PATH, expectedShopInput = null) {
  const safeApiPath = apiPath === core.SANJIE_MARKET_REPORT_API_PATH
    ? core.SANJIE_MARKET_REPORT_API_PATH
    : core.SANJIE_REPORT_API_PATH;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), SANJIE_IMPORT_TIMEOUT_MS);
  const expectedShop = normalizeExpectedShop(expectedShopInput);
  try {
    const response = await fetch(`${core.SANJIE_ORIGIN}${safeApiPath}`, {
      method,
      headers: {
        ...(body ? { "Content-Type": "application/json" } : {}),
        "x-sanjie-session": token,
        ...(expectedShop ? { "x-sanjie-shop": expectedShop.officialShopId } : {})
      },
      cache: "no-store",
      credentials: "omit",
      redirect: "error",
      body: body || undefined,
      signal: controller.signal
    });
    const result = await response.json().catch(() => ({}));
    return { response, result };
  } catch (error) {
    const wrapped = new Error(error?.name === "AbortError" ? "官网报告归档超时" : "官网报告中心暂时不可用");
    wrapped.code = error?.name === "AbortError" ? "SANJIE_TIMEOUT" : "SANJIE_UNAVAILABLE";
    wrapped.archivePhase = method === "POST" ? "post" : "lookup";
    throw wrapped;
  } finally {
    clearTimeout(timeout);
  }
}

function marketComparableReport(report) {
  return JSON.stringify({
    schema_version: String(report?.schema_version || ""),
    report_type: String(report?.report_type || ""),
    period: String(report?.period || ""),
    market_scope: report?.market_scope || null,
    tables: Array.isArray(report?.tables) ? report.tables.map(table => ({
      name: String(table?.name || ""),
      columns: Array.isArray(table?.columns) ? table.columns.map(String) : [],
      rows: Array.isArray(table?.rows) ? table.rows.map(row => ({ cells: Array.isArray(row?.cells) ? row.cells.map(String) : [] })) : []
    })) : []
  });
}

function archiveCandidateMatchesSourceShop(candidate, payload) {
  const expected = core.sanitizeSourceShop(payload?.sourceShop);
  if (!expected) return true;
  // GET /api/dmp-reports returns the website's internal shopId. The numeric
  // sourceShopId captured from DMP is an external seller/shop identity and must
  // never be compared with that internal relation id. Without a visible shop
  // name there is no safe reconciliation key, so retry by POST and let the
  // website resolve the tenant/store relationship.
  if (!expected.shopName) return false;
  const clean = value => String(value || "")
    .normalize("NFKC")
    .replace(/[\u0000-\u001f\u007f]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .toLocaleLowerCase();
  return clean(candidate?.shopName) === clean(expected.shopName);
}

async function importMarketReportToSanjie(report, options = {}) {
  const expectedShop = normalizeExpectedShop(options.expectedShop);
  if (!expectedShop) throw directShopError("SHOP_REQUIRED", "类目大盘归档缺少不可变店铺身份，已停止且不会写入官网");
  const token = await readSanjieSession();
  if (!token) {
    const error = new Error("请先登录 shaozhuangai.com，完整大盘报告已保留在本机");
    error.code = "SANJIE_LOGIN_REQUIRED";
    error.archivePhase = "auth";
    throw error;
  }
  const payload = core.sanjieMarketImportPayload(
    report,
    chrome.runtime.getManifest().version,
    options.quality === "partial" ? "partial" : "complete",
    options.sourceShop,
    options.marketWindows
  );
  const encoder = new TextEncoder();
  if (encoder.encode(JSON.stringify(payload.report)).byteLength > SANJIE_MARKET_NORMALIZED_REPORT_MAX_BYTES) {
    const error = new Error("大盘规范化报告超过官网归档上限");
    error.code = "SANJIE_REPORT_TOO_LARGE";
    error.archivePhase = "validation";
    throw error;
  }
  const body = JSON.stringify(payload);
  if (encoder.encode(body).byteLength > SANJIE_MARKET_HTTP_BODY_MAX_BYTES) {
    const error = new Error("大盘报告 HTTP 请求超过官网归档上限");
    error.code = "SANJIE_REPORT_TOO_LARGE";
    error.archivePhase = "validation";
    throw error;
  }
  if (options.reconcileFirst === true) {
    const listed = await requestSanjie(token, "GET", "", core.SANJIE_MARKET_REPORT_API_PATH, expectedShop);
    if (listed.response.ok && Array.isArray(listed.result?.data?.reports)) {
      const comparable = marketComparableReport(payload.report);
      const existing = listed.result.data.reports.find(candidate =>
        marketComparableReport(candidate?.report) === comparable
        && archiveCandidateMatchesSourceShop(candidate, payload));
      const existingUrl = officialArchivedReportUrl(core.sanjieReportUrl(existing?.id));
      if (existing?.id && existingUrl) return {
        ok: true,
        reportId: String(existing.id),
        reportUrl: existingUrl,
        savedAt: String(existing.createdAt || new Date().toISOString()),
        reused: true
      };
    }
  }
  const { response, result } = await requestSanjie(
    token,
    "POST",
    body,
    core.SANJIE_MARKET_REPORT_API_PATH,
    expectedShop
  );
  const saved = result?.data?.report;
  const reportUrl = officialArchivedReportUrl(core.sanjieReportUrl(saved?.id));
  if (!response.ok || !saved?.id || !reportUrl) {
    const error = new Error(response.status === 401
      ? "官网登录已失效，大盘报告已保留在本机"
      : result?.error || `官网大盘报告归档失败（HTTP ${response.status}）`);
    error.code = response.status === 401
      ? "SANJIE_LOGIN_REQUIRED"
      : response.status >= 500 || [408, 425, 429].includes(response.status)
        ? "SANJIE_UNAVAILABLE"
        : response.ok ? "SANJIE_IMPORT_UNCERTAIN" : "SANJIE_REPORT_REJECTED";
    error.archivePhase = response.status === 401
      ? "auth"
      : response.status >= 400 && response.status < 500 ? "validation" : "post";
    throw error;
  }
  return { ok: true, reportId: String(saved.id), reportUrl, savedAt: String(saved.createdAt || new Date().toISOString()) };
}

async function synchronizeStoredRolling7Report(trigger = "worker-wake") {
  const state = await currentRolling7State();
  const publicState = publicRolling7State(state);
  if (!state || !publicState.reportReady || !rolling7HtmlWriter?.buildArchiveReport) return { ok: false, skipped: "not-ready" };
  await scheduleRolling7TrackCollection(state).catch(() => null);
  const expectedShop = normalizeExpectedShop(state.expectedShop);
  if (!expectedShop) throw directShopError("SHOP_REQUIRED", "类目大盘任务缺少不可变店铺身份，已停止且不会写入官网");
  const dataset = mergeRolling7TrackDataset(
    rolling7.buildDataset(state),
    await readStoredRolling7TrackSnapshot(state.cateId, expectedShop),
    expectedShop
  );
  if (!/[\u3400-\u9fff]/u.test(String(dataset.categoryName || "").trim())
    || !Array.isArray(dataset.categoryPath)
    || !dataset.categoryPath.some(value => String(value || "").trim())) {
    return { ok: false, skipped: "category-metadata-missing" };
  }
  const report = rolling7HtmlWriter.buildArchiveReport(dataset);
  const sourceShop = core.sanitizeSourceShop(state.sourceShop);
  const track = validRolling7TrackSnapshot(dataset.track, dataset.cateId, expectedShop);
  const archiveQuality = state.historicalBaselineOmission || state.rangeCorrection || state.tailClosure
    || track?.status !== "ready"
    || !rolling7TrackMatrixContractComplete(track)
    || !rolling7TrackOpportunityContractComplete(track)
    ? "partial"
    : "complete";
  const fingerprint = archiveFingerprintHash(JSON.stringify({
    sourceShopIdentity: sourceShop?.sourceShopId || sourceShop?.shopName || "",
    archiveQuality,
    report: marketComparableReport(report),
    marketWindows: core.sanitizeMarketWindows(dataset.windows)
  }));
  if (state.archive?.status === "archived" && state.archive?.fingerprint === fingerprint && state.archive?.reportUrl) {
    return { ok: true, skipped: "already-archived", ...state.archive };
  }
  const reconcileFirst = state.archive?.errorPhase === "post" && state.archive?.fingerprint === fingerprint;
  await mutateRolling7State(current => current ? {
    ...current,
    archive: {
      status: "archiving",
      archived: false,
      fingerprint,
      trigger: String(trigger || ""),
      startedAt: new Date().toISOString(),
      error: "",
      errorCode: "",
      errorPhase: ""
    }
  } : null);
  try {
    const saved = await importMarketReportToSanjie(report, {
      reconcileFirst,
      quality: archiveQuality,
      sourceShop,
      marketWindows: dataset.windows,
      expectedShop
    });
    const archived = {
      status: "archived",
      archived: true,
      fingerprint,
      reportId: saved.reportId,
      reportUrl: saved.reportUrl,
      savedAt: saved.savedAt,
      reused: saved.reused === true,
      error: "",
      errorCode: "",
      errorPhase: ""
    };
    await mutateRolling7State(current => current ? { ...current, archive: archived } : null);
    return { ok: true, ...archived };
  } catch (error) {
    const safe = rolling7SafeError(error, "官网大盘报告未归档，本机报告已保留");
    const failed = {
      status: "failed",
      archived: false,
      fingerprint,
      error: safe.message,
      errorCode: String(error?.code || safe.code || "SANJIE_IMPORT_FAILED"),
      errorPhase: String(error?.archivePhase || "unknown"),
      failedAt: new Date().toISOString()
    };
    await mutateRolling7State(current => current ? { ...current, archive: failed } : null);
    return { ok: false, ...failed };
  }
}

function scheduleStoredRolling7Archive(trigger = "worker-wake") {
  if (rolling7ArchivePromise) return rolling7ArchivePromise;
  rolling7ArchivePromise = synchronizeStoredRolling7Report(trigger)
    .finally(() => { rolling7ArchivePromise = null; });
  return rolling7ArchivePromise;
}

function findExistingSanjieReport(payload, reports) {
  const comparable = sanjieComparableReport(payload.report);
  return reports.find(candidate =>
    String(candidate?.subjectItemId || "") === payload.subjectItemId
    && String(candidate?.competitorItemId || "") === payload.competitorItemId
    && archiveCandidateMatchesSourceShop(candidate, payload)
    && sanjieComparableReport(candidate?.report) === comparable
    && core.sanjieReportUrl(candidate?.id)
  );
}

async function importCanonicalReportToSanjie(canonical, job, options = {}) {
  const token = await readSanjieSession();
  if (!token) {
    const error = new Error("请先登录 shaozhuangai.com，再重新点击开始取数");
    error.code = "SANJIE_LOGIN_REQUIRED";
    throw error;
  }
  const expectedShop = normalizeExpectedShop(options.expectedShop || job?.expectedShop);
  if (options.requireExpectedShop === true && !expectedShop) {
    throw directShopError("SHOP_REQUIRED", "报告写入前缺少不可变店铺身份，已停止且不会写入");
  }
  const payload = core.sanjieImportPayload(
    canonical,
    job.subjectItemId,
    job.successItemId,
    chrome.runtime.getManifest().version,
    options.quality,
    options.sourceShop
  );
  if (expectedShop) payload.expectedShop = expectedShop;
  const body = JSON.stringify(payload);
  if (new TextEncoder().encode(body).byteLength > 2 * 1024 * 1024) {
    const error = new Error("最终业务报告超过官网归档上限");
    error.code = "SANJIE_REPORT_TOO_LARGE";
    throw error;
  }

  if (options.reconcileFirst === true) {
    const listed = expectedShop
      ? await requestSanjie(token, "GET", "", core.SANJIE_REPORT_API_PATH, expectedShop)
      : await requestSanjie(token, "GET");
    if (listed.response.status === 401) {
      const error = new Error("官网登录已失效，请重新登录后再运行");
      error.code = "SANJIE_LOGIN_REQUIRED";
      error.archivePhase = "lookup";
      throw error;
    }
    if (!listed.response.ok || !Array.isArray(listed.result?.data?.reports)) {
      const error = new Error(listed.result?.error || `官网报告查重失败（HTTP ${listed.response.status}）`);
      error.code = "SANJIE_UNAVAILABLE";
      error.archivePhase = "lookup";
      throw error;
    }
    const existing = findExistingSanjieReport(payload, listed.result.data.reports);
    if (existing) {
      const reportUrl = officialArchivedReportUrl(core.sanjieReportUrl(existing.id));
      if (!reportUrl) {
        const error = new Error("官网报告中心返回了无效编号");
        error.code = "SANJIE_IMPORT_UNCERTAIN";
        error.archivePhase = "lookup";
        throw error;
      }
      return {
        ok: true,
        reportId: String(existing.id),
        reportUrl,
        savedAt: String(existing.createdAt || new Date().toISOString()),
        reused: true
      };
    }
  }

  let archiveResponse;
  if (expectedShop) {
    archiveResponse = await requestSanjie(token, "POST", body, core.SANJIE_REPORT_API_PATH, expectedShop);
  } else {
    const { response, result } = await requestSanjie(token, "POST", body);
    archiveResponse = { response, result };
  }
  const { response, result } = archiveResponse;
  const saved = result?.data?.report;
  const reportUrl = officialArchivedReportUrl(core.sanjieReportUrl(saved?.id));
  if (!response.ok || !saved?.id || !reportUrl) {
    const error = new Error(response.status === 401
      ? "官网登录已失效，请重新登录后再运行"
      : result?.error || `官网报告归档失败（HTTP ${response.status}）`);
    error.code = response.status === 401
      ? "SANJIE_LOGIN_REQUIRED"
      : response.status >= 500 || [408, 425, 429].includes(response.status)
        ? "SANJIE_UNAVAILABLE"
        : response.ok
          ? "SANJIE_IMPORT_UNCERTAIN"
          : "SANJIE_REPORT_REJECTED";
    error.archivePhase = response.status === 401
      ? "auth"
      : response.status >= 400 && response.status < 500
        ? "validation"
        : "post";
    throw error;
  }
  return { ok: true, reportId: String(saved.id), reportUrl, savedAt: String(saved.createdAt || new Date().toISOString()) };
}

async function broadcast(job) {
  const message = { type: "DMP_DIRECT_PROGRESS", job: publicJob(job) };
  try { await chrome.runtime.sendMessage(message); } catch {}
}

async function saveProgress(state, job, step, progress, statusLabel = "运行中", phase = "collecting") {
  job.step = step;
  job.progress = Math.max(0, Math.min(100, Number(progress || 0)));
  job.statusLabel = statusLabel;
  if (["collecting", "retrying"].includes(phase)) job.status = phase;
  await writeLocalState({ ...state, job: publicJob(job) });
  await broadcast(job);
}

function isDmpTab(tab) {
  try { return new URL(tab?.url || "").hostname === "dmp.taobao.com"; } catch { return false; }
}

async function findDmpTabs() {
  const [active, all] = await Promise.all([
    chrome.tabs.query({ active: true, currentWindow: true }),
    chrome.tabs.query({ url: "https://dmp.taobao.com/*" })
  ]);
  const byId = new Map();
  for (const tab of [...active.filter(isDmpTab), ...all.filter(isDmpTab)]) if (tab?.id) byId.set(tab.id, tab);
  const tabs = [...byId.values()].sort((left, right) => {
    const activeDelta = Number(Boolean(right.active)) - Number(Boolean(left.active));
    return activeDelta || Number(right.lastAccessed || 0) - Number(left.lastAccessed || 0);
  });
  if (!tabs.length) {
    const error = new Error("请先登录并保持一个达摩盘页面打开");
    error.code = "NO_DMP_TAB";
    throw error;
  }
  if (tabs.every(tab => tab.discarded || tab.frozen)) {
    const error = new Error("达摩盘页面已被 Chrome 冻结，请手动打开一次后重试");
    error.code = "TAB_UNAVAILABLE";
    throw error;
  }
  return tabs.filter(tab => !tab.discarded && !tab.frozen);
}

async function executeInMain(tabId, func, args = []) {
  const results = await chrome.scripting.executeScript({
    target: { tabId, frameIds: [0] },
    world: "MAIN",
    func,
    args
  });
  return results?.[0]?.result;
}

async function readSourceShopFromDmpTab(tabId) {
  try {
    const candidate = await executeInMain(tabId, () => {
      if (location.hostname !== "dmp.taobao.com") return null;
      const clean = (value, maximum = 80) => String(value ?? "")
        .replace(/[\u0000-\u001f\u007f]/g, " ")
        .replace(/\s+/g, " ")
        .trim()
        .slice(0, maximum);
      const ignored = /^(?:店铺|店铺名称|切换店铺|主店|本店|账号|账户|达摩盘|阿里妈妈|淘宝|天猫)$/u;
      const visible = element => {
        if (!element) return false;
        try {
          const rect = element.getBoundingClientRect();
          const style = getComputedStyle(element);
          return rect.width > 0 && rect.height > 0
            && style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0";
        } catch {
          return false;
        }
      };
      const selectors = [
        "[data-shop-name]", "[data-seller-name]", "[data-nick]",
        '[class*="shop-name"]', '[class*="shopName"]', '[class*="seller-name"]',
        '[class*="sellerName"]', '[class*="merchant-name"]', '[class*="merchantName"]',
        '[class*="account-name"]', '[class*="accountName"]', '[class*="shop-switch"]',
        '[class*="shopSwitch"]'
      ];
      const namedNodes = [...document.querySelectorAll(selectors.join(","))]
        .filter(element => {
          if (!visible(element)) return false;
          const rect = element.getBoundingClientRect();
          return rect.top >= 0 && rect.top < 220
            || Boolean(element.closest('header,[role="banner"],[class*="header"],[class*="account"],[class*="shop-switch"],[class*="shopSwitch"]'));
        })
        .map(element => ({
          element,
          name: clean(element.getAttribute("data-shop-name")
            || element.getAttribute("data-seller-name")
            || element.getAttribute("data-nick")
            || element.textContent)
        }))
        .filter(entry => entry.name.length >= 2 && !ignored.test(entry.name));
      const bodyNames = String(document.body?.innerText || "")
        .slice(0, 6000)
        .split(/\r?\n/)
        .map(value => clean(value))
        .reduce((names, value, index, lines) => {
          const inline = value.match(/^当前店铺\s*[:：]\s*(.+)$/u)?.[1] || "";
          const adjacent = /^当前店铺\s*[:：]?$/u.test(value) ? lines[index + 1] || "" : "";
          const name = clean(inline || adjacent);
          if (name.length >= 2 && name.length <= 80 && !ignored.test(name)) names.push(name);
          return names;
        }, []);
      const named = namedNodes[0] || null;
      const shopName = named?.name || bodyNames[0] || "";
      let identityNode = named?.element || null;
      let sourceShopId = "";
      for (let depth = 0; identityNode && depth < 5 && !sourceShopId; depth += 1, identityNode = identityNode.parentElement) {
        sourceShopId = ["data-shop-id", "data-seller-id", "data-user-id", "data-member-id"]
          .map(attribute => clean(identityNode.getAttribute?.(attribute), 32).replace(/\s+/g, ""))
          .find(value => /^\d{5,32}$/.test(value)) || "";
      }
      if (!shopName && !sourceShopId) return null;
      return {
        ...(sourceShopId ? { sourceShopId } : {}),
        ...(shopName ? { shopName } : {})
      };
    });
    return core.sanitizeSourceShop(candidate);
  } catch {
    return null;
  }
}

function directShopLabel(value) {
  const shop = value && typeof value === "object" ? value : {};
  return [String(shop.shopName || "").trim(), String(shop.sourceShopId || "").trim()].filter(Boolean).join(" / ") || "未识别";
}

function sameDirectSourceShop(expectedShop, sourceShop) {
  const expected = normalizeExpectedShop(expectedShop);
  const actual = core.sanitizeSourceShop(sourceShop);
  return Boolean(expected && actual?.sourceShopId && actual?.shopName
    && expected.sourceShopId === actual.sourceShopId
    && expected.shopName.normalize("NFKC").replace(/\s+/g, " ").trim() === actual.shopName.normalize("NFKC").replace(/\s+/g, " ").trim());
}

function directShopError(code, message) {
  const error = new Error(message);
  error.code = code;
  error.failureKind = "shop-lock";
  error.rejectRecord = true;
  return error;
}

async function bindDirectExpectedShop(tabId, sourceShop, suppliedExpectedShop = null) {
  const source = core.sanitizeSourceShop(sourceShop);
  if (!source?.sourceShopId || !source?.shopName) {
    throw directShopError("SHOP_REQUIRED", "当前达摩盘页面缺少可验证的店铺 ID 或店铺名，已停止且不会写入官网");
  }
  const supplied = normalizeExpectedShop(suppliedExpectedShop);
  if (supplied && !sameDirectSourceShop(supplied, source)) {
    throw directShopError("SHOP_MISMATCH", `任务绑定店铺 ${directShopLabel(supplied)}，当前页面为 ${directShopLabel(source)}`);
  }
  const token = await readSanjieSession();
  const officialShopId = supplied?.officialShopId || await readSanjieActiveShopId();
  if (!token || !officialShopId) {
    throw directShopError("SHOP_REQUIRED", "官网未登录或未选择目标店铺，已停止且不会写入");
  }
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), OFFICIAL_AUTH_TIMEOUT_MS);
  try {
    const body = {
      sourceShop: source,
      reportType: "growth",
      officialShopId,
      ...(supplied ? { expectedShop: supplied } : {})
    };
    const response = await fetch(`${core.SANJIE_ORIGIN}/api/dmp-source-data/shop-session`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-sanjie-session": token,
        "x-sanjie-shop": officialShopId
      },
      cache: "no-store",
      credentials: "omit",
      redirect: "error",
      body: JSON.stringify(body),
      signal: controller.signal
    });
    const result = await response.json().catch(() => ({}));
    const mapped = core.sanitizeSourceShop(result?.data?.sourceShop || source);
    const mappedOfficialShopId = String(result?.data?.shop?.id || "").trim();
    const expectedShop = normalizeExpectedShop({
      officialShopId: mappedOfficialShopId,
      sourceShopId: mapped?.sourceShopId,
      shopName: mapped?.shopName
    });
    if (!response.ok || !expectedShop) {
      throw directShopError(result?.code || "SHOP_INVALID", result?.error || `店铺身份映射失败（HTTP ${response.status}）`);
    }
    if (mappedOfficialShopId !== officialShopId || !sameDirectSourceShop(expectedShop, source)
      || (supplied && JSON.stringify(expectedShop) !== JSON.stringify(supplied))) {
      throw directShopError("SHOP_MISMATCH", "页面店铺、任务店铺与官网店铺映射不一致，已停止且不会写入");
    }
    const latestSource = await readSourceShopFromDmpTab(tabId);
    if (!sameDirectSourceShop(expectedShop, latestSource)) {
      throw directShopError("SHOP_MISMATCH", `任务绑定店铺 ${directShopLabel(expectedShop)}，当前页面为 ${directShopLabel(latestSource)}`);
    }
    return expectedShop;
  } catch (error) {
    if (error?.failureKind === "shop-lock") throw error;
    throw directShopError(error?.name === "AbortError" ? "SHOP_INVALID" : "SHOP_INVALID",
      error?.name === "AbortError" ? "店铺身份映射超时，已停止且不会写入" : core.safeErrorText(error, "店铺身份映射失败"));
  } finally {
    clearTimeout(timeout);
  }
}

async function assertDirectExpectedShop(tabId, expectedShop) {
  const expected = normalizeExpectedShop(expectedShop);
  if (!expected) throw directShopError("SHOP_REQUIRED", "任务未绑定可验证店铺，已停止且不会写入");
  const actual = await readSourceShopFromDmpTab(tabId);
  if (!sameDirectSourceShop(expected, actual)) {
    throw directShopError("SHOP_MISMATCH", `任务绑定店铺 ${directShopLabel(expected)}，当前页面为 ${directShopLabel(actual)}；请切回目标店铺后重新开始`);
  }
  return actual;
}

async function ensurePageApi(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId, frameIds: [0] },
    world: "MAIN",
    files: ["direct-main.js"]
  });
  const readiness = await executeInMain(tabId, (key, capability, minVersion, maxVersion) => {
    const api = globalThis[key];
    const version = Number(api?.version || 0);
    return Number.isInteger(version)
      && version >= minVersion
      && version <= maxVersion
      && Array.isArray(api.capabilities)
      && api.capabilities.includes(capability)
      && typeof api.readiness === "function"
      ? {
          ...api.readiness(),
          pageApiVersion: version,
          pageApiCapabilities: api.capabilities.slice()
        }
      : { ok: false, error: "滚动7天页面监听器未就绪，请重新加载测试扩展后刷新页面" };
  }, [
    core.PAGE_API_KEY,
    ROLLING7_PAGE_API_CAPABILITY,
    ROLLING7_PAGE_API_MIN_VERSION,
    ROLLING7_PAGE_API_MAX_VERSION
  ]);
  if (!readiness?.ok) {
    const error = new Error(readiness?.error || "达摩盘页面监听器未就绪，请刷新页面后重试");
    error.code = "PAGE_API_UNAVAILABLE";
    throw error;
  }
  return readiness;
}

function directReadinessSignature(readiness) {
  const ids = readinessIndexCardTemplateIds(readiness).sort();
  const primary = (Array.isArray(readiness?.indexCardPrimaryTemplateIds) ? readiness.indexCardPrimaryTemplateIds : [])
    .map(String).filter(Boolean).sort();
  const paths = (Array.isArray(readiness?.capturedPaths) ? readiness.capturedPaths : []).map(String).sort();
  return JSON.stringify({ ids, primary, paths, revision: Number(readiness?.templateRevision || 0) });
}

function mergeDirectReadinessSnapshots(snapshots) {
  const rows = (Array.isArray(snapshots) ? snapshots : []).filter(value => value?.ok);
  if (!rows.length) return null;
  const latest = rows.at(-1);
  const union = key => [...new Set(rows.flatMap(row => Array.isArray(row?.[key]) ? row[key].map(String) : []).filter(Boolean))];
  const marketPaths = [...new Set(rows.flatMap(row => Object.keys(row?.marketTemplates || {})))];
  const marketTemplates = {};
  for (const path of marketPaths) {
    const seen = new Set();
    marketTemplates[path] = [];
    for (const row of rows) {
      for (const template of Array.isArray(row?.marketTemplates?.[path]) ? row.marketTemplates[path] : []) {
        const key = JSON.stringify(Object.fromEntries(Object.entries(template || {}).sort(([left], [right]) => left.localeCompare(right))));
        if (!key || seen.has(key)) continue;
        seen.add(key);
        marketTemplates[path].push(template);
      }
    }
  }
  const signatures = rows.map(directReadinessSignature);
  return {
    ...latest,
    requestTemplateCount: Math.max(...rows.map(row => Number(row.requestTemplateCount || 0))),
    capturedPaths: union("capturedPaths").sort(),
    indexCardTemplateIds: union("indexCardTemplateIds"),
    indexCardPrimaryTemplateIds: union("indexCardPrimaryTemplateIds"),
    indexCardTemplateCount: union("indexCardTemplateIds").length,
    hasIndexCardTemplate: union("indexCardTemplateIds").length > 0,
    marketTemplates,
    readinessSampleCount: rows.length,
    readinessStable: signatures.length > 1 && signatures.at(-1) === signatures.at(-2)
  };
}

async function ensureStablePageReadiness(tabId, options = {}) {
  const maxSamples = Math.max(2, Math.min(6, Number(options.maxSamples || DIRECT_READINESS_MAX_SAMPLES)));
  const delayMs = Math.max(0, Number(options.delayMs ?? DIRECT_READINESS_SAMPLE_DELAY_MS));
  const snapshots = [];
  let stableCount = 0;
  let previousSignature = "";
  for (let index = 0; index < maxSamples; index += 1) {
    const readiness = await ensurePageApi(tabId);
    snapshots.push(readiness);
    const signature = directReadinessSignature(readiness);
    stableCount = signature === previousSignature ? stableCount + 1 : 1;
    previousSignature = signature;
    if (stableCount >= 2) break;
    if (delayMs > 0) await new Promise(resolve => setTimeout(resolve, delayMs));
  }
  return mergeDirectReadinessSnapshots(snapshots) || await ensurePageApi(tabId);
}

async function selectReadyDmpTab(hasStoredDatasetTemplate) {
  const tabs = await findDmpTabs();
  const candidates = [];
  const failures = [];
  for (const tab of tabs) {
    try {
      const readiness = await ensureStablePageReadiness(tab.id);
      const readyForRun = Number(readiness.requestTemplateCount || 0) > 0
        && (Boolean(readiness.hasIndexCardTemplate) || Boolean(hasStoredDatasetTemplate));
      candidates.push({ tab, readiness, readyForRun });
    } catch (error) {
      failures.push(core.safeErrorText(error));
    }
  }
  candidates.sort((left, right) => {
    const readyDelta = Number(right.readyForRun) - Number(left.readyForRun);
    const indexDelta = Number(Boolean(right.readiness.hasIndexCardTemplate)) - Number(Boolean(left.readiness.hasIndexCardTemplate));
    const countDelta = Number(right.readiness.requestTemplateCount || 0) - Number(left.readiness.requestTemplateCount || 0);
    const activeDelta = Number(Boolean(right.tab.active)) - Number(Boolean(left.tab.active));
    return readyDelta || indexDelta || countDelta || activeDelta || Number(right.tab.lastAccessed || 0) - Number(left.tab.lastAccessed || 0);
  });
  if (candidates.length) return candidates[0];
  const error = new Error(failures[0] || "达摩盘页面监听器未就绪，请刷新页面后重试");
  error.code = "PAGE_API_UNAVAILABLE";
  throw error;
}

async function requestFromPage(tabId, spec) {
  const result = await executeInMain(tabId, async (key, capability, minVersion, maxVersion, requestSpec) => {
    const api = globalThis[key];
    const version = Number(api?.version || 0);
    if (!api || !Number.isInteger(version) || version < minVersion || version > maxVersion
      || !Array.isArray(api.capabilities)
      || !api.capabilities.includes(capability)
      || typeof api.request !== "function") {
      return { ok: false, error: { code: "PAGE_API_UNAVAILABLE", message: "页面监听器未就绪" } };
    }
    return api.request(requestSpec);
  }, [
    core.PAGE_API_KEY,
    ROLLING7_PAGE_API_CAPABILITY,
    ROLLING7_PAGE_API_MIN_VERSION,
    ROLLING7_PAGE_API_MAX_VERSION,
    spec
  ]);
  if (result?.record) core.assertSafeRecord(result.record);
  if (!result?.ok || !result.record) {
    const error = new Error(result?.error?.message || "达摩盘接口取数失败");
    error.code = result?.error?.code || "REQUEST_FAILED";
    if (result?.record) error.record = result.record;
    throw error;
  }
  return result.record;
}

function trackTemplateRows(readiness, path) {
  const rows = readiness?.marketTemplates?.[path];
  return Array.isArray(rows)
    ? rows.filter(row => row && typeof row === "object" && !Array.isArray(row))
    : [];
}

function trackTemplateMatchesScope(readiness, path, cateId, periodType) {
  return trackTemplateRows(readiness, path).some(row =>
    String(row.cateId || "") === String(cateId || "")
    && String(row.periodType || "") === String(periodType || "")
    && /^20\d{2}-\d{2}-\d{2}$/.test(String(row.date || "")));
}

function readinessTrackChanceCodes(readiness, cateId, periodType) {
  const scopedTemplateValues = trackTemplateRows(readiness, "/api/subdivide/market/item/track/list")
    .filter(row => String(row.cateId || "") === String(cateId || "")
      && String(row.periodType || "") === String(periodType || ""))
    .map(row => row.chanceCode);
  const values = scopedTemplateValues;
  return [...new Set(values.map(value => String(value || "").trim())
    .filter(value => /^[\w.-]{1,80}$/.test(value)))];
}

function assertTrackRecordScope(record, path, input) {
  const expected = core.validateMarketRequest(path, input);
  const captured = {};
  for (const key of ["cateId", "periodType", "date", "propertyId", "chanceCode", "trackId"]) {
    const value = core.requestBusinessValue(record, key);
    if (value !== "") captured[key] = value;
  }
  let actual;
  try {
    actual = core.validateMarketRequest(path, {}, captured);
  } catch {
    actual = null;
  }
  if (!actual || Object.entries(expected).some(([key, value]) => String(actual[key] ?? "") !== String(value ?? ""))) {
    const error = new Error("细分赛道回放记录与当前类目、周期或业务维度不一致");
    error.code = "TRACK_SCOPE_MISMATCH";
    error.record = record;
    throw error;
  }
  return actual;
}

function trackCollectionIssue(error, fallback = "细分赛道数据采集失败") {
  const safe = rolling7SafeError(error, fallback);
  return { code: safe.code, message: safe.message };
}

function failedTrackSnapshot(cateId, error, audit = {}, expectedShopInput = null) {
  const issue = trackCollectionIssue(error);
  const scope = rolling7TrackShopScope(expectedShopInput);
  return {
    schemaVersion: "dmp-track/1.0",
    status: "failed",
    cateId: String(cateId || ""),
    ...(scope ? { scope } : {}),
    priceRanges: [],
    properties: [],
    audit: {
      ...audit,
      contractVersion: ROLLING7_TRACK_CONTRACT_VERSION,
      collectedAt: new Date().toISOString(),
      requestCount: Number(audit.requestCount || 0),
      errorCount: Number(audit.errorCount || 0)
    },
    blockingIssues: [issue.message],
    error: issue
  };
}

function emptyTrackSnapshot(cateId, error, audit = {}, expectedShopInput = null) {
  const issue = trackCollectionIssue(error, "细分赛道请求模板尚未学习");
  const scope = rolling7TrackShopScope(expectedShopInput);
  return {
    schemaVersion: "dmp-track/1.0",
    status: "empty",
    cateId: String(cateId || ""),
    ...(scope ? { scope } : {}),
    priceRanges: [],
    properties: [],
    audit: {
      ...audit,
      contractVersion: ROLLING7_TRACK_CONTRACT_VERSION,
      collectedAt: new Date().toISOString(),
      requestCount: Number(audit.requestCount || 0),
      errorCount: Number(audit.errorCount || 0)
    },
    blockingIssues: [issue.message],
    error: issue
  };
}

function rolling7TrackBuildLatestContract(audit, built) {
  const source = audit?.latestContract && typeof audit.latestContract === "object"
    && !Array.isArray(audit.latestContract) ? audit.latestContract : {};
  const periodType = String(source.periodType || "").trim();
  const currentDate = String(source.currentRequest?.date || audit?.currentPeriodRequestDate || "").trim();
  const previousDate = String(source.previousRequest?.date || audit?.previousPeriodRequestDate || "").trim();
  const expectedPriceRangeSource = Array.isArray(source.expectedPriceRanges)
    ? source.expectedPriceRanges : [];
  const expectedPropertySource = Array.isArray(source.expectedProperties)
    && source.expectedProperties.length ? source.expectedProperties : (built?.properties || []);
  return {
    version: ROLLING7_TRACK_LATEST_CONTRACT_VERSION,
    periodType,
    currentRequest: { periodType, date: currentDate },
    previousRequest: audit?.previousBoundaryVerified === true
      ? { periodType, date: previousDate }
      : null,
    expectedPriceRanges: expectedPriceRangeSource.map(range => ({
      id: String(range?.id || "").trim(),
      name: rolling7TrackPriceRangeName(range?.name ?? range)
    })),
    expectedProperties: expectedPropertySource.map(property => ({
      propertyId: String(property?.propertyId || "").trim(),
      propertyName: String(property?.propertyName || "").trim(),
      propertyValues: (Array.isArray(property?.propertyValues) ? property.propertyValues : []).map(propertyValue => ({
        id: String(propertyValue?.id || "").trim(),
        name: String(propertyValue?.name ?? propertyValue?.propertyValueName ?? propertyValue ?? "").trim()
      }))
    }))
  };
}

function finalizedTrackSnapshot(records, cateId, issues, audit, expectedShopInput = null) {
  if (!trackEngine?.buildSnapshots) {
    const error = new Error("细分赛道解析模块未就绪");
    error.code = "TRACK_ENGINE_UNAVAILABLE";
    return failedTrackSnapshot(cateId, error, audit, expectedShopInput);
  }
  try {
    const built = trackEngine.buildSnapshots(records, { cateId: String(cateId || "") });
    const collectedIssues = issues.map(issue => issue.message).filter(Boolean);
    const blockingIssues = [...new Set([...(built?.blockingIssues || []), ...collectedIssues])];
    const status = collectedIssues.length && built?.status === "ready" ? "partial" : String(built?.status || "empty");
    const latestContract = rolling7TrackBuildLatestContract(audit, built);
    const requiredOpportunityRequests = [latestContract.currentRequest];
    if (latestContract.previousRequest) requiredOpportunityRequests.push(latestContract.previousRequest);
    const opportunityCaptureComplete = audit.opportunityCaptureAttempted === true
      && requiredOpportunityRequests.length > 0
      && requiredOpportunityRequests.every(request => (built?.opportunities || []).some(period =>
        String(period?.date || "") === request.date
        && String(period?.periodType || "") === request.periodType
        && String(period?.status || "") === "ready"
        && Array.isArray(period?.chanceGroups)
        && Array.isArray(period?.issues)
        && period.issues.length === 0
        && period.chanceGroups.every(group => String(group?.status || "") === "ready"
          && Array.isArray(group?.issues) && group.issues.length === 0
          && Array.isArray(group?.tracks))));
    const snapshot = {
      ...built,
      schemaVersion: "dmp-track/1.0",
      status: ["ready", "partial", "empty", "failed"].includes(status) ? status : "partial",
      cateId: String(cateId || ""),
      ...(rolling7TrackShopScope(expectedShopInput) ? { scope: rolling7TrackShopScope(expectedShopInput) } : {}),
      priceRanges: Array.isArray(built?.priceRanges) ? built.priceRanges : [],
      properties: Array.isArray(built?.properties) ? built.properties : [],
      audit: {
        ...(built?.audit && typeof built.audit === "object" && !Array.isArray(built.audit) ? built.audit : {}),
        endpointAudit: Array.isArray(built?.audit) ? built.audit : [],
        contractVersion: ROLLING7_TRACK_CONTRACT_VERSION,
        collectedAt: new Date().toISOString(),
        requestCount: Number(audit.requestCount || 0),
        errorCount: Number(audit.errorCount || 0),
        currentPeriodRequestDate: String(audit.currentPeriodRequestDate || ""),
        previousPeriodRequestDate: String(audit.previousPeriodRequestDate || ""),
        previousBoundaryVerified: audit.previousBoundaryVerified === true,
        authoritativePriceRangeCaptured: audit.authoritativePriceRangeCaptured === true,
        latestContract,
        opportunityCaptureAttempted: audit.opportunityCaptureAttempted === true,
        opportunityCaptureComplete
      },
      blockingIssues
    };
    if (issues.length) snapshot.error = issues[0];
    return validRolling7TrackSnapshot(snapshot, cateId)
      || failedTrackSnapshot(cateId, Object.assign(new Error("细分赛道快照结构无效"), { code: "TRACK_SNAPSHOT_INVALID" }), audit, expectedShopInput);
  } catch (error) {
    return failedTrackSnapshot(cateId, error, audit, expectedShopInput);
  }
}

async function persistRolling7TrackSnapshot(snapshot, expectedShopInput = null) {
  const expectedShop = normalizeExpectedShop(expectedShopInput);
  if (!expectedShop) throw directShopError("SHOP_REQUIRED", "细分赛道任务缺少不可变店铺身份，已拒绝写入缓存");
  const normalized = validRolling7TrackSnapshot(snapshot, snapshot?.cateId, expectedShop);
  if (!normalized) {
    const error = new Error("细分赛道快照无效，已拒绝写入");
    error.code = "TRACK_SNAPSHOT_INVALID";
    throw error;
  }
  const previous = await readStoredRolling7TrackSnapshot(normalized.cateId, expectedShop);
  const merged = mergeRolling7TrackSnapshots(previous, normalized);
  await chrome.storage.local.set({ [ROLLING7_TRACK_KEY]: merged });
  await mutateRolling7State(state => state
    && sameRolling7TrackShopScope(merged, state.expectedShop)
    && String(state.cateId || "") === String(merged.cateId || "")
    ? { ...state }
    : null);
  return merged;
}

async function fetchTrackRecord(tabId, path, input) {
  if (!trackEngine?.classifyRecord || !trackEngine?.ENDPOINTS) {
    const error = new Error("细分赛道解析模块未就绪");
    error.code = "TRACK_ENGINE_UNAVAILABLE";
    throw error;
  }
  const request = core.validateMarketRequest(path, input);
  const record = await requestFromPage(tabId, {
    path,
    method: core.requestPolicy(path)?.method,
    ...request
  });
  assertTrackRecordScope(record, path, request);
  const classification = trackEngine.classifyRecord(record);
  if (!classification || classification.path !== path || classification.ok !== true) {
    const error = new Error(`细分赛道接口返回结构无效${classification?.reason ? `：${classification.reason}` : ""}`);
    error.code = "TRACK_SHAPE_MISMATCH";
    error.record = record;
    throw error;
  }
  return { record, classification };
}

async function fetchTrackChanceCodes(tabId, input) {
  if (!trackEngine?.classifyRecord) {
    const error = new Error("细分赛道解析模块未就绪");
    error.code = "TRACK_ENGINE_UNAVAILABLE";
    throw error;
  }
  const request = core.validateMarketRequest(ROLLING7_TRACK_CHANCE_PATH, input);
  const record = await requestFromPage(tabId, {
    path: ROLLING7_TRACK_CHANCE_PATH,
    method: core.requestPolicy(ROLLING7_TRACK_CHANCE_PATH)?.method,
    ...request
  });
  assertTrackRecordScope(record, ROLLING7_TRACK_CHANCE_PATH, request);
  const classification = trackEngine.classifyRecord(record);
  if (!classification || classification.path !== ROLLING7_TRACK_CHANCE_PATH || classification.ok !== true
    || !Array.isArray(classification.value?.chanceGroups)) {
    const error = new Error(`细分赛道机会类型返回结构无效${classification?.reason ? `：${classification.reason}` : ""}`);
    error.code = "TRACK_CHANCE_SHAPE_MISMATCH";
    error.record = record;
    throw error;
  }
  const chanceCodes = [...new Set(classification.value.chanceGroups
    .map(group => String(group?.code || "").trim())
    .filter(code => /^[\w.-]{1,80}$/.test(code)))];
  if (chanceCodes.length !== classification.value.chanceGroups.length) {
    const error = new Error("细分赛道机会类型 code 无效");
    error.code = "TRACK_CHANCE_SHAPE_MISMATCH";
    error.record = record;
    throw error;
  }
  return { record, classification, chanceCodes };
}

function validTrackTemplateAnchor(rows, cateId) {
  return rows.find(row => String(row.cateId || "") === String(cateId || "")
    && /^\d{1,2}$/.test(String(row.periodType || ""))
    && /^20\d{2}-\d{2}-\d{2}$/.test(String(row.date || ""))
    && /^[\w.-]{1,80}$/.test(String(row.propertyId || ""))) || null;
}

function trackPreviousRequestDate(periodType, currentRange) {
  if (String(periodType || "") === "3") return String(currentRange?.startDate || "");
  return String(currentRange?.compareEndDate || "");
}

function exactPreviousTrackBoundary(currentRange, previousRange) {
  return Boolean(currentRange?.compareStartDate && currentRange?.compareEndDate
    && previousRange?.startDate === currentRange.compareStartDate
    && previousRange?.endDate === currentRange.compareEndDate);
}

async function findTrackReadyDmpTab(cateId, preferredTabId = null) {
  const candidates = [];
  if (preferredTabId != null && Number.isInteger(Number(preferredTabId)) && Number(preferredTabId) > 0) {
    try {
      const readiness = await ensurePageApi(Number(preferredTabId));
      candidates.push({ tab: { id: Number(preferredTabId), active: true, lastAccessed: Date.now() }, readiness });
    } catch {}
  }
  for (const tab of await findDmpTabs()) {
    if (candidates.some(candidate => candidate.tab.id === tab.id)) continue;
    try {
      candidates.push({ tab, readiness: await ensurePageApi(tab.id) });
    } catch {}
  }
  const endpoints = trackEngine?.ENDPOINTS || {};
  return candidates
    .filter(candidate => (Number(candidate.readiness?.pageApiVersion || 0) === 1
        || candidate.readiness?.pageApiCapabilities?.includes(ROLLING7_TRACK_PAGE_API_CAPABILITY))
      && candidate.readiness?.marketTrackTemplateReady === true
      && trackTemplateRows(candidate.readiness, endpoints.properties)
        .some(row => !row.cateId || String(row.cateId) === String(cateId || ""))
      && trackTemplateRows(candidate.readiness, endpoints.priceRange)
        .some(row => !row.cateId || String(row.cateId) === String(cateId || ""))
      && Boolean(validTrackTemplateAnchor(trackTemplateRows(candidate.readiness, endpoints.growth), cateId)))
    .sort((left, right) => Number(Boolean(right.tab.active)) - Number(Boolean(left.tab.active))
      || Number(right.tab.lastAccessed || 0) - Number(left.tab.lastAccessed || 0))[0] || null;
}

async function collectRolling7TrackSnapshot(state, preferredTabId = null) {
  const cateId = String(state?.cateId || "").trim();
  const expectedShop = normalizeExpectedShop(state?.expectedShop);
  if (!expectedShop) throw directShopError("SHOP_REQUIRED", "细分赛道任务缺少不可变店铺身份，已停止且不会写入缓存");
  const baseAudit = { requestCount: 0, errorCount: 0, authoritativePriceRangeCaptured: false };
  if (!cateId) {
    const error = new Error("类目 ID 缺失，无法采集细分赛道");
    error.code = "TRACK_CATE_REQUIRED";
    return persistRolling7TrackSnapshot(failedTrackSnapshot(cateId, error, baseAudit, expectedShop), expectedShop);
  }
  if (!trackEngine?.ENDPOINTS) {
    const error = new Error("细分赛道解析模块未就绪");
    error.code = "TRACK_ENGINE_UNAVAILABLE";
    return persistRolling7TrackSnapshot(failedTrackSnapshot(cateId, error, baseAudit, expectedShop), expectedShop);
  }
  const selected = await findTrackReadyDmpTab(cateId, preferredTabId);
  if (!selected) {
    const error = new Error("请先在达摩盘市场机会洞察页打开一次目标类目的价格带属性矩阵");
    error.code = "TRACK_TEMPLATE_REQUIRED";
    return persistRolling7TrackSnapshot(emptyTrackSnapshot(cateId, error, baseAudit, expectedShop), expectedShop);
  }

  const { tab, readiness } = selected;
  await assertDirectExpectedShop(tab.id, expectedShop);
  const endpoints = trackEngine.ENDPOINTS;
  const anchor = validTrackTemplateAnchor(trackTemplateRows(readiness, endpoints.growth), cateId);
  if (!anchor) {
    const error = new Error("未学习到目标类目的属性、周期与日期参数");
    error.code = "TRACK_TEMPLATE_REQUIRED";
    return persistRolling7TrackSnapshot(emptyTrackSnapshot(cateId, error, baseAudit, expectedShop), expectedShop);
  }

  const records = [];
  const issues = [];
  const periodType = String(anchor.periodType);
  const currentDate = String(anchor.date);
  const audit = {
    requestCount: 0,
    errorCount: 0,
    currentPeriodRequestDate: currentDate,
    previousPeriodRequestDate: "",
    previousBoundaryVerified: false,
    opportunityCaptureAttempted: false,
    authoritativePriceRangeCaptured: false,
    latestContract: {
      version: ROLLING7_TRACK_LATEST_CONTRACT_VERSION,
      periodType,
      currentRequest: { periodType, date: currentDate },
      previousRequest: null,
      expectedPriceRanges: [],
      expectedProperties: []
    }
  };
  let lastRequestAt = 0;
  const beginRequest = async () => {
    await assertDirectExpectedShop(tab.id, expectedShop);
    const elapsed = Date.now() - lastRequestAt;
    if (audit.requestCount > 0 && elapsed < ROLLING7_MIN_INTERVAL_MS) {
      await sleepRolling7(ROLLING7_MIN_INTERVAL_MS - elapsed);
    }
    lastRequestAt = Date.now();
    audit.requestCount += 1;
  };
  const collect = async (path, input, options = {}) => {
    await beginRequest();
    try {
      const result = await fetchTrackRecord(tab.id, path, input);
      records.push(result.record);
      return result.classification.value;
    } catch (error) {
      audit.errorCount += 1;
      const issue = trackCollectionIssue(error, options.fallback || "细分赛道数据采集失败");
      issues.push(issue);
      if (options.required) throw error;
      return null;
    }
  };
  const collectChanceCodes = async input => {
    await beginRequest();
    try {
      const result = await fetchTrackChanceCodes(tab.id, input);
      records.push(result.record);
      return result.chanceCodes;
    } catch (error) {
      audit.errorCount += 1;
      issues.push(trackCollectionIssue(error, "细分赛道机会类型采集失败"));
      return null;
    }
  };
  const collectOpportunityPeriod = async date => {
    audit.opportunityCaptureAttempted = true;
    const fallbackCodes = readinessTrackChanceCodes(readiness, cateId, periodType);
    let chanceCodes = null;
    if (trackTemplateMatchesScope(readiness, ROLLING7_TRACK_CHANCE_PATH, cateId, periodType)) {
      chanceCodes = await collectChanceCodes({ cateId, periodType, date });
    }
    if (chanceCodes == null) chanceCodes = fallbackCodes;
    if (!chanceCodes.length
      && !trackTemplateMatchesScope(readiness, ROLLING7_TRACK_CHANCE_PATH, cateId, periodType)) {
      const error = new Error("未学习到机会类型模板，且无可回放的机会 code");
      error.code = "TRACK_CHANCE_TEMPLATE_REQUIRED";
      issues.push(trackCollectionIssue(error));
      return;
    }

    const trackIds = new Set();
    for (const chanceCode of [...new Set(chanceCodes)]) {
      const listValue = await collect(endpoints.trackList, {
        cateId,
        periodType,
        date,
        chanceCode
      }, { fallback: `机会 ${chanceCode} 的赛道清单采集失败` });
      for (const track of Array.isArray(listValue?.tracks) ? listValue.tracks : []) {
        const trackId = String(track?.trackId || "").trim();
        if (trackId && trackId.length <= 500 && !/[\u0000-\u001f\u007f]/.test(trackId)) trackIds.add(trackId);
      }
    }
    if (!trackIds.size) return;

    if (!trackTemplateMatchesScope(readiness, endpoints.trackDetail, cateId, periodType)) {
      const error = new Error("未学习到赛道明细模板，已保留机会清单");
      error.code = "TRACK_DETAIL_TEMPLATE_REQUIRED";
      issues.push(trackCollectionIssue(error));
      return;
    }
    for (const trackId of trackIds) {
      await collect(endpoints.trackDetail, {
        cateId,
        periodType,
        date,
        trackId
      }, { fallback: `赛道 ${trackId} 明细采集失败` });
    }
  };

  let propertiesValue;
  try {
    propertiesValue = await collect(endpoints.properties, { cateId }, {
      required: true,
      fallback: "细分赛道属性清单采集失败"
    });
  } catch (error) {
    return persistRolling7TrackSnapshot(failedTrackSnapshot(cateId, error, audit, expectedShop), expectedShop);
  }
  const properties = Array.isArray(propertiesValue?.properties)
    ? [...new Map(propertiesValue.properties
        .filter(property => /^[\w.-]{1,80}$/.test(String(property?.propertyId || "")))
        .map(property => [String(property.propertyId), property])).values()]
    : [];
  audit.latestContract.expectedProperties = properties.map(property => ({
    propertyId: String(property?.propertyId || "").trim(),
    propertyName: String(property?.propertyName || "").trim(),
    propertyValues: (Array.isArray(property?.propertyValues) ? property.propertyValues : []).map(propertyValue => ({
      id: String(propertyValue?.id || "").trim(),
      name: String(propertyValue?.name ?? propertyValue?.propertyValueName ?? propertyValue ?? "").trim()
    }))
  }));
  if (!properties.length) {
    const error = new Error("属性清单未返回可采集的属性维度");
    error.code = "TRACK_PROPERTIES_EMPTY";
    return persistRolling7TrackSnapshot(finalizedTrackSnapshot(records, cateId, [
      ...issues,
      trackCollectionIssue(error)
    ], audit, expectedShop), expectedShop);
  }

  const priceRangesValue = await collect(endpoints.priceRange, { cateId }, { fallback: "价格带区间采集失败" });
  audit.authoritativePriceRangeCaptured = Array.isArray(priceRangesValue?.priceRanges)
    && priceRangesValue.priceRanges.length > 0;
  audit.latestContract.expectedPriceRanges = (Array.isArray(priceRangesValue?.priceRanges)
    ? priceRangesValue.priceRanges : []).map(range => ({
    id: String(range?.id || "").trim(),
    name: rolling7TrackPriceRangeName(range?.name ?? range)
  }));

  const currentRange = await collect(endpoints.dateRange, {
    periodType,
    date: currentDate
  }, { fallback: "本期周期边界采集失败" });

  for (const property of properties) {
    await collect(endpoints.growth, {
      cateId,
      periodType,
      date: currentDate,
      propertyId: String(property.propertyId)
    }, { fallback: `${property.propertyName || property.propertyId}本期价格带矩阵采集失败` });
  }
  await collectOpportunityPeriod(currentDate);

  const previousDate = trackPreviousRequestDate(periodType, currentRange);
  audit.previousPeriodRequestDate = previousDate;
  if (previousDate && currentRange?.compareStartDate && currentRange?.compareEndDate) {
    const previousRange = await collect(endpoints.dateRange, {
      periodType,
      date: previousDate
    }, { fallback: "上一周期边界采集失败" });
    if (previousRange && exactPreviousTrackBoundary(currentRange, previousRange)) {
      audit.previousBoundaryVerified = true;
      audit.latestContract.previousRequest = { periodType, date: previousDate };
      for (const property of properties) {
        await collect(endpoints.growth, {
          cateId,
          periodType,
          date: previousDate,
          propertyId: String(property.propertyId)
        }, { fallback: `${property.propertyName || property.propertyId}上一周期价格带矩阵采集失败` });
      }
      await collectOpportunityPeriod(previousDate);
    } else if (previousRange) {
      const error = new Error("上一周期边界与本期接口返回的对比周期不一致，已停止环比矩阵采集");
      error.code = "TRACK_PREVIOUS_BOUNDARY_MISMATCH";
      issues.push(trackCollectionIssue(error));
    }
  } else {
    const error = new Error("本期未返回可验证的上一周期边界，仅保留本期矩阵");
    error.code = "TRACK_PREVIOUS_UNVERIFIED";
    issues.push(trackCollectionIssue(error));
  }

  return persistRolling7TrackSnapshot(finalizedTrackSnapshot(records, cateId, issues, audit, expectedShop), expectedShop);
}

function scheduleRolling7TrackCollection(state, preferredTabId = null, options = {}) {
  if (rolling7TrackCollectionPromise) return rolling7TrackCollectionPromise;
  rolling7TrackCollectionPromise = (async () => {
    const expectedShop = normalizeExpectedShop(state?.expectedShop);
    if (!expectedShop) throw directShopError("SHOP_REQUIRED", "细分赛道任务缺少不可变店铺身份，已停止且不会读取缓存");
    const existing = await readStoredRolling7TrackSnapshot(state?.cateId, expectedShop);
    if (options.force !== true && reusableRolling7TrackSnapshot(existing)) {
      return existing;
    }
    return collectRolling7TrackSnapshot(state, preferredTabId);
  })()
    .catch(async error => {
      const expectedShop = normalizeExpectedShop(state?.expectedShop);
      if (!expectedShop || String(error?.code || "").startsWith("SHOP_")) throw error;
      return persistRolling7TrackSnapshot(failedTrackSnapshot(state?.cateId, error, {}, expectedShop), expectedShop);
    })
    .finally(() => { rolling7TrackCollectionPromise = null; });
  return rolling7TrackCollectionPromise;
}

async function selectRolling7DmpTab() {
  const tabs = await findDmpTabs();
  const candidates = [];
  const failures = [];
  for (const tab of tabs) {
    try {
      const readiness = await ensurePageApi(tab.id);
      candidates.push({ tab, readiness });
    } catch (error) {
      failures.push(rolling7SafeError(error).message);
    }
  }
  const ready = candidates
    .filter(candidate => candidate.readiness?.marketRolling7Ready === true)
    .sort((left, right) => {
      const activeDelta = Number(Boolean(right.tab.active)) - Number(Boolean(left.tab.active));
      const countDelta = Number(right.readiness.requestTemplateCount || 0) - Number(left.readiness.requestTemplateCount || 0);
      return activeDelta || countDelta || Number(right.tab.lastAccessed || 0) - Number(left.tab.lastAccessed || 0);
    });
  if (ready.length) return ready[0];
  if (candidates.length) {
    const error = new Error("请先在当前已登录达摩盘页面正常打开一次叶子类目市场，让日期范围与市场概览两个接口完成请求");
    error.code = "TEMPLATE_REQUIRED";
    throw error;
  }
  const error = new Error(failures[0] || "达摩盘页面监听器未就绪，请刷新页面后重试");
  error.code = "PAGE_API_UNAVAILABLE";
  throw error;
}

function rolling7RequestSpec(task, path) {
  return {
    path,
    method: path === rolling7.RANGE_PATH ? "GET" : "POST",
    cateId: task.cateId,
    periodType: task.periodType,
    requestDate: task.requestDate
  };
}

function rolling7TaskIsCurrent(state, task) {
  if (!state || !task || !["running", "paused"].includes(state.queueStatus)) return false;
  if (state.currentTaskId !== task.taskId || state.cateId !== task.cateId) return false;
  return state.tasks.some(item => item.taskId === task.taskId && item.status === "running");
}

function rolling7WaitMs(state) {
  const now = Date.now();
  const candidates = [state?.nextAllowedAt, ...(state?.tasks || [])
    .filter(task => task.status === "retry-wait")
    .map(task => task.nextRetryAt)]
    .filter(Boolean)
    .map(value => new Date(value).valueOf())
    .filter(value => Number.isFinite(value) && value > now);
  const delay = candidates.length ? Math.min(...candidates) - now : 250;
  return Math.max(100, Math.min(1000, delay));
}

function sleepRolling7(milliseconds) {
  return new Promise(resolve => setTimeout(resolve, Math.max(0, Number(milliseconds) || 0)));
}

async function pauseRolling7ForError(error, taskId = null) {
  const safe = rolling7SafeError(error);
  return mutateRolling7State(state => {
    if (!state || state.queueStatus === "stopped" || state.queueStatus === "completed") return state;
    let next = state;
    if (next.queueStatus === "running") next = rolling7.pauseQueue(next);
    next = rolling7.createCheckpoint(next);
    if (taskId) {
      const task = next.tasks.find(item => item.taskId === taskId);
      if (task?.status === "running") {
        task.status = "pending";
        task.attempts = Math.max(0, Number(task.attempts || 0) - 1);
        task.lastStartedAt = null;
        task.lastFinishedAt = null;
        task.nextRetryAt = null;
        task.durationMs = null;
        task.lastError = safe;
        if (next.currentTaskId === taskId) next.currentTaskId = null;
        next.nextAllowedAt = null;
      }
    }
    next = { ...next, lastError: safe, updatedAt: new Date().toISOString() };
    rolling7.assertSensitiveFree(next);
    return next;
  });
}

async function recordRolling7Failure(taskId, error, options = {}) {
  const safe = rolling7SafeError(error);
  return mutateRolling7State(state => {
    if (!state || state.queueStatus === "stopped") return state;
    let next = rolling7.recordTaskFailure(state, taskId, safe);
    const failedTask = next.tasks.find(task => task.taskId === taskId);
    if (options.correctRange === true && failedTask?.status === "failed") {
      next = rolling7.correctUnavailableRange(next, taskId, safe);
    }
    if (state.queueStatus === "paused" && next.queueStatus === "running") next = rolling7.pauseQueue(next);
    return next;
  });
}

function isLegacyMarketUnavailableError(error) {
  if (String(error?.code || "") !== "API_ERROR") return false;
  const pathname = String(error?.record?.pathname || "");
  if (pathname !== rolling7.RANGE_PATH && pathname !== rolling7.OVERVIEW_PATH) return false;
  return /暂未返回可用数据|暂无数据|数据未产出/.test(String(error?.message || ""));
}

function unavailableRolling7TailOptions(state, error) {
  return {
    currentDate: rolling7CurrentDate(),
    requiredRounds: Number(state?.config?.tailConfirmationRounds || ROLLING7_TAIL_CONFIRMATION_ROUNDS),
    allowLegacyApiError: isLegacyMarketUnavailableError(error)
  };
}

async function processUnavailableRolling7Tail(taskId, error) {
  let decision = "not-eligible";
  const next = await mutateRolling7State(state => {
    if (!state || state.queueStatus === "stopped" || state.queueStatus === "completed") return null;
    const options = unavailableRolling7TailOptions(state, error);
    const assessment = rolling7.assessUnavailableTail(state, taskId, error, options);
    if (!assessment.eligible) return null;
    const candidate = rolling7.finalizeUnavailableTail(state, taskId, error, options);
    const closed = candidate?.queueStatus === "completed"
      && candidate?.tailClosure?.closedAt
      && candidate.tasks.length < state.tasks.length;
    if (closed) {
      decision = "closed";
      return candidate;
    }
    decision = "retrying";
    return rolling7.recordTaskFailure(candidate, taskId, rolling7SafeError(error));
  });
  return { decision, state: next };
}

async function runRolling7Queue() {
  await ensureRolling7Initialized();
  if (rolling7Promise) return rolling7Promise;
  rolling7Promise = (async () => {
    let tabId = null;
    while (true) {
      const snapshot = await currentRolling7State();
      if (!snapshot || snapshot.queueStatus !== "running") break;

      if (!tabId) {
        try {
          const selected = await selectRolling7DmpTab();
          tabId = selected.tab.id;
          const expectedShop = normalizeExpectedShop(snapshot.expectedShop);
          if (!expectedShop) throw directShopError("SHOP_REQUIRED", "类目大盘任务缺少不可变店铺身份，已停止且不会采集");
          await assertDirectExpectedShop(tabId, expectedShop);
          await mutateRolling7State(state => state
            && JSON.stringify(normalizeExpectedShop(state.expectedShop)) === JSON.stringify(expectedShop)
            ? { ...state, sourceShop: core.sanitizeSourceShop(expectedShop) }
            : null);
        } catch (error) {
          await pauseRolling7ForError(error);
          break;
        }
      }

      let task = null;
      await mutateRolling7State(state => {
        if (!state || state.queueStatus !== "running") return null;
        const claimed = rolling7.claimNextTask(state);
        task = claimed.task;
        return task ? claimed.state : null;
      });

      if (!task) {
        const waiting = await currentRolling7State();
        if (!waiting || waiting.queueStatus !== "running") break;
        await sleepRolling7(rolling7WaitMs(waiting));
        continue;
      }

      // Yield once after claiming so a user pause/stop command can win before a new request
      // is dispatched. The identity gate below still accepts responses that were already in flight.
      await sleepRolling7(0);
      const beforeRange = await currentRolling7State();
      if (!rolling7TaskIsCurrent(beforeRange, task) || beforeRange.queueStatus !== "running") {
        if (beforeRange?.queueStatus === "running") continue;
        break;
      }

      try {
        const rangeRecord = await requestFromPage(tabId, {
          ...rolling7RequestSpec(task, rolling7.RANGE_PATH),
          expectedShop: beforeRange.expectedShop
        });
        const rangeCapture = rolling7.sanitizeCaptureRecord(rangeRecord, { cateId: task.cateId });
        if (!rangeCapture || rangeCapture.taskId !== task.taskId) {
          const error = new Error("日期范围响应与当前滚动任务不匹配");
          error.code = "CAPTURE_MISMATCH";
          throw error;
        }
        if (task.kind === rolling7.BASELINE_TASK_KIND
          && !rolling7.boundaryMatches(task, rangeCapture.response?.range)) {
          const error = new Error("当前页面返回的分析周期与任务不一致，请手动切换对应周期后重试");
          error.code = "BASELINE_PERIOD_UNVERIFIED";
          throw error;
        }
        let rangeAccepted = false;
        await mutateRolling7State(state => {
          if (!rolling7TaskIsCurrent(state, task)) return null;
          rangeAccepted = true;
          return rolling7.ingestCapture(state, rangeCapture);
        });
        if (!rangeAccepted) continue;

        const afterRange = await currentRolling7State();
        if (!rolling7TaskIsCurrent(afterRange, task)) {
          if (afterRange?.queueStatus === "running") continue;
          break;
        }
        if (afterRange.queueStatus !== "running") break;

        const overviewRecord = await requestFromPage(tabId, {
          ...rolling7RequestSpec(task, rolling7.OVERVIEW_PATH),
          expectedShop: afterRange.expectedShop
        });
        const overviewCapture = rolling7.sanitizeCaptureRecord(overviewRecord, { cateId: task.cateId });
        if (!overviewCapture || overviewCapture.taskId !== task.taskId) {
          const error = new Error("市场概览响应与当前滚动任务不匹配");
          error.code = "CAPTURE_MISMATCH";
          throw error;
        }
        let overviewAccepted = false;
        const afterOverview = await mutateRolling7State(state => {
          if (!rolling7TaskIsCurrent(state, task)) return null;
          overviewAccepted = true;
          return rolling7.ingestCapture(state, overviewCapture);
        });
        if (!overviewAccepted) continue;
        const finishedTask = afterOverview?.tasks?.find(item => item.taskId === task.taskId);
        if (finishedTask?.status === "running") {
          const error = new Error("两类核心响应尚未形成完整滚动窗口");
          error.code = "PAIR_INCOMPLETE";
          throw error;
        }
      } catch (error) {
        const current = await currentRolling7State();
        if (!current || current.queueStatus === "stopped") break;
        if (!rolling7TaskIsCurrent(current, task)) continue;
        if (task.kind === rolling7.BASELINE_TASK_KIND
          && ROLLING7_OPTIONAL_BASELINE_FALLBACK_CODES.has(String(error?.code || ""))) {
          let omitted = false;
          await mutateRolling7State(state => {
            if (!rolling7TaskIsCurrent(state, task)) return null;
            omitted = true;
            return rolling7.omitOptionalBaseline(state, { code: error.code });
          });
          if (omitted) continue;
        }
        const unavailableTail = await processUnavailableRolling7Tail(task.taskId, error);
        if (unavailableTail.decision === "closed") break;
        if (unavailableTail.decision === "retrying") continue;
        if (task.kind === rolling7.DAILY_TASK_KIND
          && ROLLING7_MISSING_RETRY_CODES.has(String(error?.code || ""))) {
          const corrected = await recordRolling7Failure(task.taskId, error, { correctRange: true });
          if (corrected?.queueStatus === "completed") break;
          if (corrected?.queueStatus === "paused") break;
          tabId = null;
          continue;
        }
        if (ROLLING7_BLOCKING_CODES.has(String(error?.code || ""))) {
          await pauseRolling7ForError(error, task.taskId);
          break;
        }
        await recordRolling7Failure(task.taskId, error);
        tabId = null;
      }
    }
    const finished = await currentRolling7State();
    if (publicRolling7State(finished).reportReady) {
      await scheduleRolling7TrackCollection(finished, tabId, { force: true }).catch(() => null);
      await synchronizeStoredRolling7Report("queue-completed").catch(() => null);
    }
    return publicRolling7State(await currentRolling7State());
  })().finally(() => {
    rolling7Promise = null;
    void currentRolling7State()
      .then(state => {
        if (state?.queueStatus === "running") void runRolling7Queue();
      })
      .catch(() => {});
  });
  return rolling7Promise;
}

function sameRolling7Config(state, input, expectedShopInput = null) {
  const requested = state?.requestedAnalysisRange || state?.analysisRange;
  const expectedShop = normalizeExpectedShop(expectedShopInput);
  const storedExpectedShop = normalizeExpectedShop(state?.expectedShop);
  return Boolean(state)
    && Boolean(expectedShop && storedExpectedShop)
    && JSON.stringify(expectedShop) === JSON.stringify(storedExpectedShop)
    && state.cateId === String(input.cateId || "").trim()
    && state.periodType === "1"
    && Boolean(state.historicalBaseline) === (input.includeHistoricalBaseline === true)
    && requested?.startDate === String(input.analysisStart || "").trim()
    && requested?.endDate === String(input.analysisEnd || "").trim();
}

async function startRolling7(input) {
  await ensureRolling7Initialized();
  const tabs = await findDmpTabs();
  const selectedTab = tabs[0];
  if (!selectedTab?.id) {
    const error = new Error("请先打开达摩盘类目大盘页面");
    error.code = "DMP_TAB_REQUIRED";
    throw error;
  }
  const sourceShop = await readSourceShopFromDmpTab(selectedTab.id);
  const suppliedExpectedShop = normalizeExpectedShop(input?.expectedShop);
  const expectedShop = suppliedExpectedShop
    ? (await assertDirectExpectedShop(selectedTab.id, suppliedExpectedShop), suppliedExpectedShop)
    : await bindDirectExpectedShop(selectedTab.id, sourceShop, null);
  const next = await mutateRolling7State(state => {
    if (state?.queueStatus === "running") {
      const error = new Error("滚动7天任务已在运行");
      error.code = "QUEUE_ALREADY_RUNNING";
      throw error;
    }
    if (sameRolling7Config(state, input, expectedShop) && state.queueStatus === "paused") {
      return rolling7.resumeQueue(state);
    }
    if (sameRolling7Config(state, input, expectedShop) && state.queueStatus === "stopped") {
      return rolling7.startQueue(state, { restartStopped: true });
    }
    const manifest = rolling7.generateManifest({
      cateId: input.cateId,
      periodType: "1",
      analysisStart: input.analysisStart,
      analysisEnd: input.analysisEnd,
      paddingDays: 6,
      includeHistoricalBaseline: input.includeHistoricalBaseline === true
    });
    const created = rolling7.createQueueState(manifest, {
      maxRetries: ROLLING7_MAX_RETRIES,
      retryBaseMs: ROLLING7_RETRY_BASE_MS,
      minIntervalMs: ROLLING7_MIN_INTERVAL_MS,
      tailConfirmationRounds: ROLLING7_TAIL_CONFIRMATION_ROUNDS
    });
    created.sourceShop = core.sanitizeSourceShop(expectedShop);
    created.expectedShop = expectedShop;
    rolling7LoadError = null;
    return rolling7.startQueue(created);
  });
  void runRolling7Queue();
  return { ok: true, state: publicRolling7State(next) };
}

async function pauseRolling7() {
  await ensureRolling7Initialized();
  const next = await mutateRolling7State(state => state ? rolling7.pauseQueue(state) : null);
  return { ok: true, state: publicRolling7State(next) };
}

async function resumeRolling7() {
  await ensureRolling7Initialized();
  const next = await mutateRolling7State(state => {
    if (!state) {
      const error = new Error("没有可继续的滚动7天断点");
      error.code = "QUEUE_NOT_FOUND";
      throw error;
    }
    return rolling7.resumeQueue(state);
  });
  void runRolling7Queue();
  return { ok: true, state: publicRolling7State(next) };
}

async function stopRolling7() {
  await ensureRolling7Initialized();
  const next = await mutateRolling7State(state => state ? rolling7.stopQueue(state) : null);
  return { ok: true, state: publicRolling7State(next) };
}

async function getRolling7ClientState() {
  await ensureRolling7Initialized();
  return { ok: true, state: publicRolling7State(await currentRolling7State()) };
}

function parseLatestDay(record) {
  const body = core.parseRecordBody(record);
  const candidates = [body?.data, body?.result?.data, body?.latestDay, body?.data?.latestDay];
  for (const value of candidates) {
    const normalized = core.normalizeDate(value);
    if (normalized) return normalized;
  }
  return "";
}

function directValidDate(value) {
  const date = core.normalizeDate(value);
  if (!date) return "";
  try { return new Date(`${date}T00:00:00Z`).toISOString().slice(0, 10) === date ? date : ""; } catch { return ""; }
}

function directShiftDate(value, offsetDays) {
  const date = directValidDate(value);
  const offset = Number(offsetDays);
  if (!date || !Number.isInteger(offset)) return "";
  return new Date(Date.parse(`${date}T00:00:00Z`) + offset * 86400000).toISOString().slice(0, 10);
}

function directPeriod(startDate, endDate) {
  const start = directValidDate(startDate);
  const end = directValidDate(endDate);
  if (!start || !end || start > end) return null;
  const days = Math.round((Date.parse(`${end}T00:00:00Z`) - Date.parse(`${start}T00:00:00Z`)) / 86400000) + 1;
  return Number.isInteger(days) && days >= 1 && days <= 366 ? { startDate: start, endDate: end, days } : null;
}

function normalizeDirectRequestedPeriod(input, latestDay, defaultDays = 30) {
  const latest = directValidDate(latestDay);
  if (!latest) return null;
  const source = input?.requestedPeriod || input?.period
    || ((input?.startDate || input?.endDate) ? { startDate: input.startDate, endDate: input.endDate } : null);
  if (!source) return { period: core.periodEndingAtLatestDay(defaultDays, latest), corrected: false, corrections: [] };
  let start = directValidDate(source.startDate || source.start || "");
  let end = directValidDate(source.endDate || source.end || "");
  const corrections = [];
  if (!start && !end) {
    const error = new Error("自选周期日期无效");
    error.code = "INVALID_DATE_RANGE";
    throw error;
  }
  if (!start) {
    start = directShiftDate(end, -(defaultDays - 1));
    corrections.push("缺少开始日，按默认周期补齐");
  }
  if (!end) {
    end = directShiftDate(start, defaultDays - 1);
    corrections.push("缺少结束日，按默认周期补齐");
  }
  if (start > end) {
    [start, end] = [end, start];
    corrections.push("开始日晚于结束日，已自动互换");
  }
  let period = directPeriod(start, end);
  if (!period) {
    period = core.periodEndingAtLatestDay(366, end);
    corrections.push("自选周期超过 366 天，已保留结束日并截取最近 366 天");
  }
  return { period, corrected: corrections.length > 0, corrections };
}

function resolveDirectEffectivePeriod(requestedPeriod, commonLatestDay) {
  const requested = directPeriod(requestedPeriod?.startDate, requestedPeriod?.endDate);
  const latest = directValidDate(commonLatestDay);
  if (!requested || !latest) return null;
  const effective = requested.endDate > latest
    ? core.periodEndingAtLatestDay(requested.days, latest)
    : requested;
  const previousEnd = directShiftDate(effective.startDate, -1);
  const previousPeriod = core.periodEndingAtLatestDay(effective.days, previousEnd);
  return {
    requestedPeriod: requested,
    effectivePeriod: effective,
    previousPeriod,
    commonLatestDay: latest,
    corrected: requested.startDate !== effective.startDate || requested.endDate !== effective.endDate
  };
}

function directRetryDecision(error) {
  const code = String(error?.code || "");
  const status = Number(error?.record?.status ?? error?.status);
  if (code === "TIMEOUT" || code === "EMPTY_RESPONSE") return { retryable: true, reason: code };
  if (code === "HTTP_ERROR" && (status === 429 || status >= 500 && status <= 599)) {
    return { retryable: true, reason: `HTTP_${status}` };
  }
  return { retryable: false, reason: code || "REQUEST_FAILED" };
}

function directTerminalCollectionError(error) {
  return new Set([
    "SHOP_REQUIRED", "SHOP_INVALID", "SHOP_MISMATCH", "LOGIN_REQUIRED", "REQUEST_NOT_ALLOWED",
    "SUBJECT_SCOPE_MISMATCH", "COMPETITOR_SCOPE_MISMATCH", "SCENE_PARENT_MISMATCH"
  ]).has(String(error?.code || ""));
}

async function runDirectRequestWithRetry(operation, context = {}) {
  let lastError;
  const attempts = Math.max(1, Math.min(DIRECT_REQUEST_MAX_ATTEMPTS, Number(context.maxAttempts || DIRECT_REQUEST_MAX_ATTEMPTS)));
  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    try {
      return await operation(attempt);
    } catch (error) {
      lastError = error;
      const decision = directRetryDecision(error);
      if (!decision.retryable || attempt >= attempts) break;
      const delayMs = Math.max(0, Number(context.retryBaseMs ?? DIRECT_REQUEST_RETRY_BASE_MS)) * 2 ** (attempt - 1);
      if (context.state && context.job) {
        context.job.retryCount = Number(context.job.retryCount || 0) + 1;
        await saveProgress(
          context.state,
          context.job,
          `${String(context.label || "数据请求")}暂未返回，自动重试 ${attempt + 1}/${attempts}`,
          Number(context.job.progress || 0),
          "重试中",
          "retrying"
        );
      }
      if (delayMs > 0) await new Promise(resolve => setTimeout(resolve, delayMs));
    }
  }
  throw lastError;
}

function classifyBusinessRecord(record, expectedParser) {
  const classification = completeness.classifyGrowthRecord(record);
  if (!classification || classification.status === "failed" || classification.status === "ignored") {
    const error = new Error("接口已返回，但业务结构未通过完整性检查");
    error.code = "SHAPE_MISMATCH";
    error.record = record;
    throw error;
  }
  if (expectedParser && classification.parser !== expectedParser) {
    const error = new Error("接口返回的数据类型与目标模块不一致");
    error.code = "SHAPE_MISMATCH";
    throw error;
  }
  return classification;
}

async function fetchBusinessRecord(tabId, spec, expectedParser, retryContext = {}) {
  return runDirectRequestWithRetry(async () => {
    if (spec?.expectedShop) await assertDirectExpectedShop(tabId, spec.expectedShop);
    const record = await requestFromPage(tabId, spec);
    const classification = classifyBusinessRecord(record, expectedParser);
    core.validateDirectRecordScope(record, spec, classification);
    return { record, classification };
  }, retryContext);
}

function baseSpec(job, path, method = "GET", extra = {}) {
  const expectedShop = normalizeExpectedShop(job?.expectedShop);
  if (job?.enforceExpectedShop === true && !expectedShop) {
    throw directShopError("SHOP_REQUIRED", "任务未绑定可验证店铺，已停止且不会发起业务请求");
  }
  return {
    path,
    method,
    subjectItemId: job.subjectItemId,
    successItemId: job.successItemId,
    latestDay: job.latestDay || "",
    period: job.period || null,
    ...extra,
    expectedShop
  };
}

function readinessIndexCardTemplateIds(readiness) {
  const source = Array.isArray(readiness?.indexCardTemplateIds) ? readiness.indexCardTemplateIds : [];
  return [...new Set(source.map(value => String(value || "").trim()).filter(value => /^idx-[a-f\d]{8,64}$/i.test(value)))].slice(0, 64);
}

function cardHasPrimarySalesMetrics(classification) {
  const identities = new Set((classification?.parsed?.metricRows || []).map(row => completeness.metricIdentity(row?.name)));
  return identities.has("orders") && identities.has("aov");
}

function directPrimaryProbeRequests(readiness, state) {
  const stored = new Map(normalizeDatasetTemplates(state?.datasetTemplates).map(entry => [entry.templateId, entry.templateBody]));
  const orderedIds = [
    ...(Array.isArray(readiness?.indexCardPrimaryTemplateIds) ? readiness.indexCardPrimaryTemplateIds : []),
    state?.primaryDatasetTemplateId,
    ...readinessIndexCardTemplateIds(readiness),
    ...stored.keys()
  ].map(value => String(value || "").trim()).filter(Boolean);
  const seen = new Set();
  const rows = [];
  for (const templateId of orderedIds) {
    if (seen.has(templateId)) continue;
    seen.add(templateId);
    rows.push({ templateId, templateBody: stored.get(templateId) || "" });
    if (rows.length >= 8) break;
  }
  if (!rows.length && (state?.primaryDatasetTemplate || state?.datasetTemplate)) {
    rows.push({ templateId: "", templateBody: String(state.primaryDatasetTemplate || state.datasetTemplate) });
  }
  return rows;
}

async function probeDirectPrimaryCard(tabId, state, job, readiness, period) {
  const requests = directPrimaryProbeRequests(readiness, state);
  if (!requests.length) {
    const error = new Error("缺少可用的成交核心卡模板");
    error.code = "INDEX_CARD_PRIMARY_TEMPLATE_MISSING";
    throw error;
  }
  let lastError = null;
  for (const request of requests) {
    try {
      const result = await fetchBusinessRecord(tabId, baseSpec(job, "/dataplatform/dataset/report/query", "POST", {
        period,
        ...(request.templateId ? { templateId: request.templateId } : {}),
        ...(request.templateBody ? { templateBody: request.templateBody } : {})
      }), "index-card", { state, job, label: "探测核心指标可用日" });
      if (cardHasPrimarySalesMetrics(result.classification)) return result;
    } catch (error) {
      lastError = error;
      if ([
        "SHOP_REQUIRED", "SHOP_INVALID", "SHOP_MISMATCH", "LOGIN_REQUIRED", "REQUEST_NOT_ALLOWED",
        "SUBJECT_SCOPE_MISMATCH", "COMPETITOR_SCOPE_MISMATCH",
        "SUBJECT_PERIOD_MISMATCH", "COMPETITOR_PERIOD_MISMATCH"
      ].includes(String(error?.code || ""))) throw error;
    }
  }
  const error = lastError || new Error("当前周期的成交核心卡未返回成交笔数与笔单价");
  if (!error.code) error.code = "INDEX_CARD_PRIMARY_TEMPLATE_MISSING";
  throw error;
}

function directAvailabilityMiss(error) {
  return new Set([
    "API_ERROR", "INDEX_CARD_PRIMARY_TEMPLATE_MISSING",
    "SUBJECT_PERIOD_MISMATCH", "COMPETITOR_PERIOD_MISMATCH"
  ]).has(String(error?.code || ""));
}

function directLineCoversExactPeriod(line, period) {
  if (!core.lineMatchesPeriod(line, period)) return false;
  const expectedDates = completeness.enumerateDates(period?.startDate, period?.endDate);
  const actualDates = [...new Set((Array.isArray(line?.daily) ? line.daily : [])
    .map(row => directValidDate(row?.date)).filter(Boolean))].sort();
  return expectedDates.length === Number(period?.days || 0)
    && actualDates.length === expectedDates.length
    && expectedDates.every((date, index) => actualDates[index] === date);
}

async function probeDirectCommonLatestDay(tabId, state, job, readiness, latestDay, periodDays) {
  const latest = directValidDate(latestDay);
  const days = Number(periodDays);
  if (!latest || !Number.isInteger(days) || days < 1 || days > 366) {
    const error = new Error("可采周期探测参数无效");
    error.code = "INVALID_DATE_RANGE";
    throw error;
  }
  const attempts = [];
  for (let offset = 0; offset < DIRECT_AVAILABILITY_LOOKBACK_DAYS; offset += 1) {
    const candidateDay = directShiftDate(latest, -offset);
    const period = core.periodEndingAtLatestDay(days, candidateDay);
    await saveProgress(state, job, `探测各核心端点共同可用日 ${offset + 1}/${DIRECT_AVAILABILITY_LOOKBACK_DAYS}`, Math.max(20, Number(job.progress || 0)));
    const settled = await Promise.allSettled([
      probeDirectPrimaryCard(tabId, state, job, readiness, period),
      fetchBusinessRecord(tabId, baseSpec(job, "/api/goods/grow/define/line/data", "GET", { period }), "growth-line", {
        state, job, label: "探测成长趋势可用日"
      }).then(result => {
        if (!directLineCoversExactPeriod(result.classification?.parsed, period)) {
          const error = new Error("成长趋势实际日期集与候选周期不一致");
          error.code = "SUBJECT_PERIOD_MISMATCH";
          throw error;
        }
        return result;
      }),
      fetchBusinessRecord(tabId, baseSpec(job, "/api/goods/grow/comparison/scene", "GET", { period }), "growth-scenes", {
        state, job, label: "探测推广场景可用日"
      }).then(result => {
        if (!Array.isArray(result.classification?.parsed?.rows) || !result.classification.parsed.rows.length) {
          const error = new Error("推广场景未返回当前周期数据");
          error.code = "API_ERROR";
          throw error;
        }
        return result;
      })
    ]);
    const failures = settled.filter(result => result.status === "rejected").map(result => result.reason);
    attempts.push({ candidateDay, period, ok: failures.length === 0, codes: failures.map(error => String(error?.code || "REQUEST_FAILED")) });
    if (!failures.length) return { commonLatestDay: candidateDay, period, attempts };
    const fatal = failures.find(error => !directAvailabilityMiss(error));
    if (fatal) throw fatal;
  }
  const error = new Error(`从 ${latest} 向前 ${DIRECT_AVAILABILITY_LOOKBACK_DAYS} 天内，核心指标、趋势与场景接口没有共同可用日`);
  error.code = "COMMON_LATEST_DAY_UNAVAILABLE";
  error.attempts = attempts;
  throw error;
}

function mergeIndexCardResults(results, primary, job) {
  if (!Array.isArray(results) || results.length < 2 || !primary?.record) return null;
  const ordered = [primary, ...results.filter(result => result !== primary)];
  const merged = new Map();
  for (const result of ordered) {
    for (const row of result.classification?.parsed?.metricRows || []) {
      const identity = completeness.metricIdentity(row?.name);
      if (!identity || identity === "raw:") continue;
      const previous = merged.get(identity);
      if (!previous) {
        merged.set(identity, { ...row });
        continue;
      }
      for (const key of ["subject", "competitor", "difference", "trend"]) {
        if ((previous[key] === null || previous[key] === undefined || previous[key] === "")
          && row[key] !== null && row[key] !== undefined && row[key] !== "") previous[key] = row[key];
      }
    }
  }
  const list = [...merged.values()].map(row => ({
    name: String(row.name || ""),
    value: row.subject ?? null,
    c_value: row.competitor ?? null,
    diff_value: row.difference ?? null,
    trend: row.trend ?? null
  })).filter(row => row.name);
  if (!list.length) return null;
  const body = JSON.stringify({
    info: { ok: true, code: 0 },
    data: {
      rangeDesc: `数据范围为：${job.period.startDate}至${job.period.endDate}`,
      INDEX_CARD: { list }
    }
  });
  const capturedAt = new Date().toISOString();
  const record = {
    ...primary.record,
    source: "direct-worker-index-card-merge",
    capturedAt,
    requestId: `direct-index-merged-${Date.now()}`,
    encodedDataLength: body.length,
    bodyLength: body.length,
    responseKeys: ["info", "data"],
    body,
    templateId: "idx-merged-period",
    templateFingerprint: "idx-merged-period",
    templateOrdinal: -1,
    templateIds: results.map(result => String(result.templateId || result.record?.templateId || "")).filter(Boolean)
  };
  core.assertSafeRecord(record);
  const classification = classifyBusinessRecord(record, "index-card");
  core.validateDirectRecordScope(record, baseSpec(job, "/dataplatform/dataset/report/query", "POST"), classification);
  return { record, classification };
}

async function fetchPeriodIndexCards(tabId, state, job, readiness, records, options = {}) {
  const readinessIds = readinessIndexCardTemplateIds(readiness);
  const stored = new Map(normalizeDatasetTemplates(state.datasetTemplates).map(entry => [entry.templateId, entry.templateBody]));
  const templateIds = [];
  const seenTemplateIds = new Set();
  for (const templateId of [...readinessIds, ...stored.keys()]) {
    if (!templateId || seenTemplateIds.has(templateId)) continue;
    seenTemplateIds.add(templateId);
    templateIds.push(templateId);
  }
  // 当前页面探测到的模板与历史已验证模板必须取稳定并集。页面切换模块时常只
  // 暴露一部分模板，若以 readiness 覆盖本地集合，会把费用效率卡永久抹掉。
  const requests = templateIds.length
    ? templateIds.map(templateId => ({ templateId, templateBody: stored.get(templateId) || "" }))
    : [{ templateId: "", templateBody: String(state.primaryDatasetTemplate || state.datasetTemplate || "") }];
  const results = [];
  const failures = [];
  for (let index = 0; index < requests.length; index += 1) {
    const nextProgress = 28 + Math.round((index + 1) / requests.length * 6);
    const stepPrefix = String(options.stepPrefix || "获取主体与竞品核心指标");
    await saveProgress(state, job, `${stepPrefix} ${index + 1}/${requests.length}`, Math.max(Number(job.progress || 0), nextProgress));
    const request = requests[index];
    try {
      const result = await fetchBusinessRecord(tabId, baseSpec(job, "/dataplatform/dataset/report/query", "POST", {
        ...(request.templateId ? { templateId: request.templateId } : {}),
        ...(request.templateBody ? { templateBody: request.templateBody } : {})
      }), "index-card", { state, job, label: `${stepPrefix} ${index + 1}/${requests.length}` });
      result.templateId = String(result.record?.templateId || request.templateId || "");
      result.templateBody = String(result.record?.requestBody || request.templateBody || "");
      results.push(result);
      records.push(result.record);
    } catch (error) {
      if (options.preserveFailedRecords !== false
        && error?.record && !error?.rejectRecord && !records.includes(error.record)) records.push(error.record);
      failures.push(error);
      if (options.continueOnError === false) throw error;
    }
  }
  const readinessPrimaryIds = new Set(Array.isArray(readiness?.indexCardPrimaryTemplateIds)
    ? readiness.indexCardPrimaryTemplateIds.map(String)
    : []);
  const primaryCandidates = results.filter(result => cardHasPrimarySalesMetrics(result.classification));
  const primary = primaryCandidates.find(result => readinessPrimaryIds.has(result.templateId)) || primaryCandidates[0] || null;
  if (!primary && options.requirePrimary !== false) {
    const error = new Error("已抓取的核心指标模板中没有同时包含成交笔数与笔单价的主卡");
    error.code = "INDEX_CARD_PRIMARY_TEMPLATE_MISSING";
    throw error;
  }
  const capturedTemplates = results.map(result => ({
    templateId: result.templateId,
    templateBody: result.templateBody
  }));
  const capturedById = new Map(normalizeDatasetTemplates(capturedTemplates)
    .map(entry => [entry.templateId, entry.templateBody]));
  state.datasetTemplates = normalizeDatasetTemplates(templateIds.map(templateId => ({
    templateId,
    templateBody: capturedById.get(templateId) || stored.get(templateId) || ""
  })));
  if (primary) {
    state.primaryDatasetTemplateId = primary.templateId;
    state.primaryDatasetTemplate = primary.templateBody;
    state.datasetTemplate = state.primaryDatasetTemplate;
  }
  const merged = primary ? mergeIndexCardResults(results, primary, job) : null;
  if (merged) records.push(merged.record);
  job.recordCount = records.length;
  await writeLocalState({ ...state, job: publicJob(job) });
  return { results, primary, merged, failures };
}

async function fetchSubjectDailyCards(tabId, state, job, records) {
  const dates = completeness.enumerateDates(job.period?.startDate, job.period?.endDate);
  if (dates.length !== Number(job.period?.days || 0)) {
    const error = new Error("主体逐日核心指标日期范围不完整");
    error.code = "SUBJECT_DAILY_PERIOD_INVALID";
    throw error;
  }
  const batchSize = 2;
  const failures = [];
  for (let offset = 0; offset < dates.length; offset += batchSize) {
    const batch = dates.slice(offset, offset + batchSize);
    const completed = Math.min(dates.length, offset + batch.length);
    const progress = 36 + Math.round(completed / dates.length * 18);
    await saveProgress(state, job, `获取主体每日成交 ${completed}/${dates.length}`, progress);
    const settled = await Promise.allSettled(batch.map(date => fetchBusinessRecord(tabId, baseSpec(
      job,
      "/dataplatform/dataset/report/query",
      "POST",
      {
        period: { startDate: date, endDate: date, days: 1 },
        ...(state.primaryDatasetTemplateId ? { templateId: state.primaryDatasetTemplateId } : {}),
        templateBody: state.primaryDatasetTemplate || state.datasetTemplate
      }
    ), "index-card", { state, job, label: `主体每日成交 ${date}` })));
    for (const result of settled) {
      if (result.status === "fulfilled") records.push(result.value.record);
      else {
        if (result.reason?.record && !result.reason?.rejectRecord && !records.includes(result.reason.record)) records.push(result.reason.record);
        failures.push(result.reason);
      }
    }
    job.recordCount = records.length;
  }
  if (failures.length) {
    job.warnings = [...new Set([...(job.warnings || []), `主体逐日核心指标有 ${failures.length} 天未取全，已保留其他日期并进入补采`])];
  }
  return { failures, completed: dates.length - failures.length, expected: dates.length };
}

function buildPartialReport(records, job, options = {}) {
  if (!job.period || !records.length) return null;
  try {
    const built = reportEngine.buildReport(records, job.subjectItemId, {
      ...job,
      periodConfirmed: true,
      periodPrecision: "exact",
      visitedPaths: ["商品概况", "成功品", "核心指标", "成长阶段与趋势", "投放场景", "关键词样本"]
    });
    return built;
  } catch (error) {
    if (options.throwOnError) {
      const wrapped = new Error(`本地报告生成失败：${core.safeErrorText(error, "报告结构与当前数据不兼容")}`);
      wrapped.code = "REPORT_BUILD_FAILED";
      throw wrapped;
    }
    return null;
  }
}

function directSupplementError(error, fallback) {
  const rawCode = String(error?.code || "REQUEST_FAILED");
  return {
    code: /^[A-Za-z0-9_-]{1,64}$/.test(rawCode) ? rawCode : "REQUEST_FAILED",
    message: core.safeErrorText(error, fallback).slice(0, 240)
  };
}

async function runDirectSupplementPass(tabId, state, job, readiness, records, report, sceneParentIds = []) {
  const plan = core.buildDirectSupplementPlan(report?.quality, { sceneParentIds });
  const baseState = {
    requests: plan.requests,
    missing: plan.missing,
    needsPaidEfficiency: plan.needsPaidEfficiency,
    needsPromotionDetail: plan.needsPromotionDetail,
    attempted: false,
    attemptCount: 0,
    passCompleted: plan.requests.length === 0,
    resolved: plan.requests.length === 0,
    addedRecordCount: 0,
    errors: [],
    remainingRequests: plan.requests,
    remainingMissing: plan.missing
  };
  state.lastSupplementPlan = baseState;
  if (!plan.requests.length) return { report, plan: baseState };

  let activeReadiness = readiness;
  try {
    activeReadiness = await ensureStablePageReadiness(tabId);
  } catch (error) {
    job.warnings = [...new Set([...(job.warnings || []), `补采前模板重新发现失败，已使用本轮稳定并集：${core.safeErrorText(error)}`])];
  }

  const startedWith = records.length;
  const errors = [];
  state.lastSupplementPlan = { ...baseState, attempted: true, attemptCount: 1, passCompleted: false };
  await saveProgress(state, job, "关键指标有缺口，自动补抓 1 轮", Math.max(Number(job.progress || 0), 93));

  const wantsAllIndexCards = plan.requests.some(request => request?.allTemplates === true
    && core.canonicalPath(request.path) === "/dataplatform/dataset/report/query");
  if (wantsAllIndexCards) {
    try {
      const result = await fetchPeriodIndexCards(tabId, state, job, activeReadiness, records, {
        continueOnError: true,
        requirePrimary: false,
        preserveStoredTemplates: true,
        preserveFailedRecords: false,
        stepPrefix: "自动补抓周期核心指标"
      });
      for (const error of result.failures || []) errors.push(directSupplementError(error, "周期核心指标补抓失败"));
    } catch (error) {
      errors.push(directSupplementError(error, "周期核心指标补抓失败"));
    }
  }

  const sceneRequests = plan.requests.filter(request => core.canonicalPath(request?.path) === "/api/goods/grow/comparison/scene");
  for (let index = 0; index < sceneRequests.length; index += 1) {
    const request = sceneRequests[index];
    const sceneLevel1Id = String(request.sceneLevel1Id || "").trim();
    const label = sceneLevel1Id ? `二级推广场景 ${sceneLevel1Id}` : "一级推广场景";
    const nextProgress = 95 + Math.round(((index + 1) / Math.max(1, sceneRequests.length)) * 3);
    await saveProgress(state, job, `自动补抓${label} ${index + 1}/${sceneRequests.length}`, Math.max(Number(job.progress || 0), nextProgress));
    try {
      const result = await fetchBusinessRecord(tabId, baseSpec(job, request.path, request.method || "GET", {
        ...(sceneLevel1Id ? { sceneLevel1Id } : {})
      }), "growth-scenes", { state, job, label: `${label}补抓` });
      records.push(result.record);
    } catch (error) {
      errors.push(directSupplementError(error, `${label}补抓失败`));
    }
    job.recordCount = records.length;
  }

  job.recordCount = records.length;
  job.finishedAt = new Date().toISOString();
  let supplementedReport = report;
  try {
    supplementedReport = buildPartialReport(records, job, { throwOnError: true });
  } catch (error) {
    errors.push(directSupplementError(error, "补抓后报告重建失败"));
  }
  const remaining = core.buildDirectSupplementPlan(supplementedReport?.quality, { sceneParentIds });
  const finalPlan = {
    ...baseState,
    attempted: true,
    attemptCount: 1,
    passCompleted: true,
    resolved: remaining.requests.length === 0,
    addedRecordCount: records.length - startedWith,
    errors,
    remainingRequests: remaining.requests,
    remainingMissing: remaining.missing
  };
  state.lastSupplementPlan = finalPlan;
  if (errors.length || remaining.requests.length) {
    const warning = remaining.requests.length
      ? `自动补抓已完成 1 轮，仍有 ${remaining.requests.length} 类缺口，报告按当前可用数据生成`
      : `自动补抓已完成 1 轮，${errors.length} 个请求未成功，报告按当前可用数据生成`;
    job.warnings = [...new Set([...(job.warnings || []), warning])];
  }
  await saveProgress(state, job, finalPlan.resolved ? "关键指标补抓完成" : "补抓完成，保留已获取数据", Math.max(Number(job.progress || 0), 98));
  return { report: supplementedReport, plan: finalPlan };
}

async function finishWithSanjieImport(state, job, report, options = {}) {
  if (!report || typeof report !== "object") throw new Error("本机没有可归档的报告");
  const expectedShop = normalizeExpectedShop(options.expectedShop || job.expectedShop || state.expectedShop);
  if (job.enforceExpectedShop === true) {
    if (!expectedShop || !Number.isInteger(Number(job.tabId))) {
      throw directShopError("SHOP_REQUIRED", "报告归档前缺少不可变店铺身份，已停止且不会写入");
    }
    await assertDirectExpectedShop(Number(job.tabId), expectedShop);
  }
  const canonical = reportEngine.toCanonicalReport(report);
  const archiveQuality = archiveReportQuality(report);
  if (expectedShop) state.expectedShop = expectedShop;
  state.report = report;
  state.sanjie = {
    ok: false,
    status: "archiving",
    archived: false,
    reportId: "",
    reportUrl: "",
    savedAt: "",
    attemptedAt: new Date().toISOString(),
    errorCode: "SANJIE_IMPORT_UNCERTAIN",
    errorPhase: "post",
    error: "官网报告正在归档"
  };
  const queued = archiveOutboxEntry(state, report, job, state.sanjie);
  await writeLocalState(state);
  await saveProgress(state, job, "归档到官网报告中心", 96);
  try {
    const imported = await importCanonicalReportToSanjie(canonical, job, {
      reconcileFirst: job.reconcileArchiveFirst === true,
      quality: archiveQuality,
      sourceShop: core.sanitizeSourceShop(options.sourceShop || state.sourceShop),
      expectedShop,
      requireExpectedShop: job.enforceExpectedShop === true
    });
    state.sanjie = {
      ...imported,
      status: "archived",
      archived: true,
      attemptedAt: new Date().toISOString(),
      autoOpened: false,
      openError: "",
      errorCode: "",
      errorPhase: "",
      error: ""
    };
    removeArchiveOutboxEntry(state, queued.fingerprint);
    if (archiveQuality === "complete" && job.enforceExpectedShop !== true) job.status = "completed";
    else job.status = archiveQuality === "complete" ? "complete" : "partial";
    job.statusLabel = archiveQuality === "complete" ? "已完成" : "部分数据，待补采";
    job.step = archiveQuality === "complete" ? "官网历史报告已归档" : "官网历史报告已归档（部分数据）";
    delete job.errorCode;
    delete job.error;
  } catch (error) {
    const retainPostUncertainty = job.reconcileArchiveFirst === true
      && error?.archivePhase === "lookup";
    state.sanjie = {
      ok: false,
      status: "failed",
      archived: false,
      reportId: "",
      reportUrl: "",
      savedAt: "",
      attemptedAt: new Date().toISOString(),
      errorCode: error?.code || "SANJIE_IMPORT_FAILED",
      errorPhase: retainPostUncertainty ? "post" : error?.archivePhase || "unknown",
      error: core.safeErrorText(error, "官网报告未归档")
    };
    job.status = "blocked";
    job.statusLabel = "归档失败";
    job.errorCode = state.sanjie.errorCode;
    job.error = state.sanjie.error;
    job.step = `官网归档失败；本地报告已保留：${state.sanjie.error}`;
    updateArchiveOutboxEntry(state, queued.fingerprint, {
      job: publicJob(job),
      sanjie: state.sanjie,
      attempts: Number(queued.attempts || 0) + 1
    });
  }
  job.finishedAt = new Date().toISOString();
  if (state.sanjie.ok && archiveQuality !== "complete") job.progress = DIRECT_PARTIAL_PROGRESS;
  else job.progress = 100;
  state.job = publicJob(job);
  await writeLocalState(state);
  await broadcast(job);
  if (!state.sanjie.ok) {
    return {
      ok: false,
      archived: false,
      localFallback: true,
      error: state.sanjie.error,
      code: state.sanjie.errorCode,
      job: publicJob(job),
      reportReady: true
    };
  }

  if (options.autoOpen === false) {
    return {
      ok: true,
      archived: true,
      reportReady: true,
      reportUrl: state.sanjie.reportUrl,
      autoOpened: false,
      openError: "",
      job: publicJob(job)
    };
  }

  try {
    const opened = await openOfficialArchivedReport(state.sanjie.reportUrl);
    state.sanjie.autoOpened = true;
    state.sanjie.reportUrl = opened.reportUrl;
    state.sanjie.openedAt = new Date().toISOString();
    job.step = "官网历史报告已归档并打开";
  } catch (error) {
    state.sanjie.autoOpened = false;
    state.sanjie.openError = core.safeErrorText(error, "官网历史报告自动打开失败");
    job.step = "官网历史报告已归档；可点击“打开官网报告”查看";
  }
  state.job = publicJob(job);
  await writeLocalState(state);
  await broadcast(job);
  return {
    ok: true,
    archived: true,
    reportReady: true,
    reportUrl: state.sanjie.reportUrl,
    autoOpened: state.sanjie.autoOpened,
    openError: state.sanjie.openError || "",
    job: publicJob(job)
  };
}

async function runDirectJob(input) {
  const ids = core.validateJob(input);
  const previous = await readLocalState();
  await ensureCurrentReportQueued(previous);
  const hasReusableReport = isArchivableStoredReport(previous.report)
    && String(previous.lastConfig?.subjectItemId || "") === ids.subjectItemId
    && String(previous.lastConfig?.successItemId || "") === ids.successItemId;
  const canResumeFinalization = hasReusableReport
    && previous.sanjie?.ok !== true
    && RECOVERABLE_SANJIE_CODES.has(String(previous.sanjie?.errorCode || ""));
  if (!canResumeFinalization && normalizeArchiveOutbox(previous.archiveOutbox).length >= ARCHIVE_OUTBOX_LIMIT) {
    const error = new Error(`本地待归档报告已达 ${ARCHIVE_OUTBOX_LIMIT} 份，请联网登录官网完成补传后再开始新任务`);
    error.code = "ARCHIVE_OUTBOX_FULL";
    throw error;
  }
  const reconcileArchiveFirst = canResumeFinalization
    && previous.sanjie?.errorPhase === "post";
  const state = {
    schemaVersion: 2,
    lastConfig: ids,
    datasetTemplate: String(previous.datasetTemplate || ""),
    datasetTemplates: normalizeDatasetTemplates(previous.datasetTemplates),
    primaryDatasetTemplateId: String(previous.primaryDatasetTemplateId || ""),
    primaryDatasetTemplate: String(previous.primaryDatasetTemplate || previous.datasetTemplate || ""),
    job: null,
    report: canResumeFinalization ? previous.report : null,
    sanjie: canResumeFinalization ? previous.sanjie : null,
    sourceShop: canResumeFinalization ? core.sanitizeSourceShop(previous.sourceShop) : null,
    expectedShop: canResumeFinalization
      ? normalizeExpectedShop(previous.expectedShop || previous.job?.expectedShop)
      : normalizeExpectedShop(input?.expectedShop),
    archiveOutbox: normalizeArchiveOutbox(previous.archiveOutbox)
  };
  const records = [];
  const job = {
    id: `direct-${Date.now()}-${ids.subjectItemId}-${ids.successItemId}`,
    ...ids,
    status: "collecting",
    statusLabel: "准备中",
    step: "查找已登录的达摩盘页面",
    progress: 1,
    startedAt: new Date().toISOString(),
    recordCount: 0,
    sceneCount: 0,
    sceneMissed: [],
    warnings: [],
    requireSubjectDaily: true,
    expectedShop: state.expectedShop,
    enforceExpectedShop: true,
    reconcileArchiveFirst
  };
  state.job = publicJob(job);
  await writeLocalState(state);
  await broadcast(job);

  try {
    await saveProgress(state, job, "准备取数", 2);
    requireOfficialSiteAccess(await checkOfficialSiteAccess());
    // Reports queued by releases predating the immutable shop lock have no
    // expectedShop to revalidate. Keep that historical outbox recoverable, but
    // never use this compatibility path for a newly collected or already-bound job.
    if (canResumeFinalization && !state.expectedShop && previous.job?.enforceExpectedShop !== true) {
      job.enforceExpectedShop = false;
      job.period = previous.report.period || null;
      job.requestedPeriod = previous.job?.requestedPeriod || job.period;
      job.effectivePeriod = previous.job?.effectivePeriod || job.period;
      job.previousPeriod = previous.job?.previousPeriod || null;
      job.commonLatestDay = previous.job?.commonLatestDay || previous.report.period?.endDate || "";
      job.latestDay = previous.report.period?.endDate || "";
      return await finishWithSanjieImport(state, job, previous.report);
    }
    const hasStoredIndexCardTemplate = Boolean(state.datasetTemplate || state.primaryDatasetTemplate || state.datasetTemplates.length);
    const selected = await selectReadyDmpTab(hasStoredIndexCardTemplate);
    const { tab } = selected;
    let readiness = selected.readiness;
    job.tabId = tab.id;
    state.sourceShop = await readSourceShopFromDmpTab(tab.id);
    state.expectedShop = await bindDirectExpectedShop(tab.id, state.sourceShop, state.expectedShop);
    state.sourceShop = core.sanitizeSourceShop(state.expectedShop);
    job.expectedShop = state.expectedShop;
    if (canResumeFinalization) {
      job.period = previous.report.period || null;
      job.requestedPeriod = previous.job?.requestedPeriod || job.period;
      job.effectivePeriod = previous.job?.effectivePeriod || job.period;
      job.previousPeriod = previous.job?.previousPeriod || null;
      job.commonLatestDay = previous.job?.commonLatestDay || previous.report.period?.endDate || "";
      job.latestDay = previous.report.period?.endDate || "";
      return await finishWithSanjieImport(state, job, previous.report, { expectedShop: state.expectedShop });
    }
    await saveProgress(state, job, "确认页面本机请求模板", 5);
    job.templatePaths = readiness.capturedPaths || [];
    if (!readiness.requestTemplateCount) {
      const error = new Error("加载测试扩展后，请刷新一次达摩盘页面再运行；无需切换页面或日期");
      error.code = "TEMPLATE_REQUIRED";
      throw error;
    }
    if (!readiness.hasIndexCardTemplate && !hasStoredIndexCardTemplate) {
      const error = new Error("请在达摩盘“货品-打爆路径”页面刷新一次，让插件学习核心指标请求模板");
      error.code = "TEMPLATE_REQUIRED";
      throw error;
    }

    await saveProgress(state, job, "读取达摩盘最新业务日期", 9);
    const latestRecord = await runDirectRequestWithRetry(async () => {
      await assertDirectExpectedShop(tab.id, job.expectedShop);
      return requestFromPage(tab.id, baseSpec(job, "/api/latestDay"));
    }, { state, job, label: "读取最新业务日" });
    job.latestDay = parseLatestDay(latestRecord);
    const requestedSelection = normalizeDirectRequestedPeriod(input, job.latestDay, 30);
    job.requestedPeriod = requestedSelection?.period || null;
    job.period = job.requestedPeriod;
    if (!job.period) {
      const error = new Error("达摩盘没有返回可用的最新业务日期");
      error.code = "LATEST_DAY_UNAVAILABLE";
      throw error;
    }
    if (requestedSelection.corrected) job.warnings.push(...requestedSelection.corrections);

    await saveProgress(state, job, "获取主体商品概况", 15);
    const itemResult = await fetchBusinessRecord(tab.id, baseSpec(job, "/api/goods/item/info"), "item-info", {
      state, job, label: "获取主体商品概况"
    });
    records.push(itemResult.record);
    job.recordCount = records.length;
    const cateId = core.findCateId(core.parseRecordBody(itemResult.record));

    await saveProgress(state, job, "只读确认目标成功品", 22);
    const searchResult = await fetchBusinessRecord(tab.id, baseSpec(job, "/api/goods/grow/define/success/item/list", "GET", { cateId }), "success-item-search", {
      state, job, label: "确认目标成功品"
    });
    if (!core.successRecordHasTarget(searchResult.record, job.successItemId)) {
      const error = new Error("只读搜索未找到目标成功品，请确认与主体属于同一叶子类目");
      error.code = "SUCCESS_NOT_FOUND";
      error.record = searchResult.record;
      error.rejectRecord = true;
      throw error;
    }
    records.push(searchResult.record);
    job.recordCount = records.length;

    readiness = await ensureStablePageReadiness(tab.id);
    const availability = await probeDirectCommonLatestDay(
      tab.id,
      state,
      job,
      readiness,
      job.latestDay,
      job.requestedPeriod.days
    );
    const resolvedPeriod = resolveDirectEffectivePeriod(job.requestedPeriod, availability.commonLatestDay);
    if (!resolvedPeriod) {
      const error = new Error("无法根据共同可用日生成实际采集周期");
      error.code = "EFFECTIVE_PERIOD_UNAVAILABLE";
      throw error;
    }
    job.commonLatestDay = resolvedPeriod.commonLatestDay;
    job.effectivePeriod = resolvedPeriod.effectivePeriod;
    job.previousPeriod = resolvedPeriod.previousPeriod;
    job.period = resolvedPeriod.effectivePeriod;
    if (resolvedPeriod.corrected) {
      job.warnings = [...new Set([...(job.warnings || []),
        `用户选择周期 ${job.requestedPeriod.startDate} 至 ${job.requestedPeriod.endDate} 超出各核心端点共同可用日，已自动调整为 ${job.period.startDate} 至 ${job.period.endDate}`])];
    }
    await saveProgress(state, job, `实际可采周期 ${job.period.startDate} 至 ${job.period.endDate}`, 27);

    const periodCards = await fetchPeriodIndexCards(tab.id, state, job, readiness, records);
    if (periodCards.failures.length) {
      job.warnings.push(`周期核心指标有 ${periodCards.failures.length} 个模板未取全，已保留其他模板并进入补采`);
    }

    await fetchSubjectDailyCards(tab.id, state, job, records);

    await saveProgress(state, job, "获取成长趋势与五渠道消耗", 58);
    try {
      const lineResult = await fetchBusinessRecord(tab.id, baseSpec(job, "/api/goods/grow/define/line/data"), "growth-line", {
        state, job, label: "成长趋势与五渠道消耗"
      });
      if (!directLineCoversExactPeriod(lineResult.classification?.parsed, job.period)) {
        const error = new Error("成长趋势实际日期集与已确认可采周期不一致");
        error.code = "SUBJECT_PERIOD_MISMATCH";
        error.record = lineResult.record;
        error.rejectRecord = true;
        throw error;
      }
      records.push(lineResult.record);
    } catch (error) {
      if (directTerminalCollectionError(error)) throw error;
      if (error?.record && !error?.rejectRecord && !records.includes(error.record)) records.push(error.record);
      job.warnings.push(`成长趋势与五渠道消耗未取全：${core.safeErrorText(error)}`);
    }
    job.recordCount = records.length;

    await saveProgress(state, job, "获取一级投放场景", 65);
    let sceneIds = [];
    try {
      const level1Result = await fetchBusinessRecord(tab.id, baseSpec(job, "/api/goods/grow/comparison/scene"), "growth-scenes", {
        state, job, label: "一级投放场景"
      });
      records.push(level1Result.record);
      sceneIds = core.sceneIdsFromRecord(level1Result.record);
    } catch (error) {
      if (directTerminalCollectionError(error)) throw error;
      if (error?.record && !error?.rejectRecord && !records.includes(error.record)) records.push(error.record);
      job.warnings.push(`一级投放场景未取全：${core.safeErrorText(error)}`);
    }
    if (sceneIds.length > 20) {
      const error = new Error("一级场景数量异常，已停止本次后台取数");
      error.code = "SCENE_LIMIT_EXCEEDED";
      throw error;
    }
    job.sceneCount = sceneIds.length;
    job.recordCount = records.length;

    for (let index = 0; index < sceneIds.length; index += 1) {
      const sceneId = sceneIds[index];
      const progress = 67 + Math.round(((index + 1) / Math.max(1, sceneIds.length)) * 15);
      await saveProgress(state, job, `获取二级场景 ${index + 1}/${sceneIds.length}`, progress);
      try {
        const level2Result = await fetchBusinessRecord(tab.id, baseSpec(job, "/api/goods/grow/comparison/scene", "GET", { sceneLevel1Id: sceneId }), "growth-scenes", {
          state, job, label: `二级投放场景 ${sceneId}`
        });
        records.push(level2Result.record);
      } catch (error) {
        if (directTerminalCollectionError(error)) throw error;
        if (error?.record && !error?.rejectRecord && !records.includes(error.record)) records.push(error.record);
        job.sceneMissed.push(sceneId);
        job.warnings.push(`二级投放场景 ${sceneId} 未取全：${core.safeErrorText(error)}`);
      }
      job.recordCount = records.length;
    }

    await saveProgress(state, job, "获取关键词样本", 86);
    try {
      const keywordResult = await fetchBusinessRecord(tab.id, baseSpec(job, "/api/goods/grow/comparison/scene/keyword"), "growth-keywords", {
        state, job, label: "关键词样本"
      });
      records.push(keywordResult.record);
    } catch (error) {
      if (directTerminalCollectionError(error)) throw error;
      if (error?.record && !error?.rejectRecord && !records.includes(error.record)) records.push(error.record);
      job.warnings.push(`关键词样本未取全：${core.safeErrorText(error)}`);
    }
    job.recordCount = records.length;

    await saveProgress(state, job, "本地生成 11 张业务表", 92);
    job.finishedAt = new Date().toISOString();
    let report = buildPartialReport(records, job, { throwOnError: true });
    const supplemented = await runDirectSupplementPass(tab.id, state, job, readiness, records, report, sceneIds);
    report = supplemented.report;
    const strictGapDays = Number(report.quality?.platformGap?.days || 0);
    const toleratedGapDays = Number(completeness.PLATFORM_DAY_GAP_TOLERANCE || 2);
    if (strictGapDays > toleratedGapDays) {
      const issue = `请求周期内缺少 ${strictGapDays} 天平台数据，超过允许的 ${toleratedGapDays} 天范围`;
      report.quality.complete = false;
      report.quality.exportAllowed = false;
      report.quality.status = "partial";
      report.quality.missing = [...new Set([...(report.quality.missing || []), issue])];
      report.quality.blockingIssues = [...new Set([...(report.quality.blockingIssues || []), issue])];
    }
    return await finishWithSanjieImport(state, job, report);
  } catch (error) {
    if (error?.record && !error?.rejectRecord && !records.includes(error.record)) records.push(error.record);
    job.finishedAt = new Date().toISOString();
    job.status = "blocked";
    job.statusLabel = "已阻断";
    job.progress = directTerminalCollectionError(error) ? 100 : DIRECT_PARTIAL_PROGRESS;
    job.errorCode = error?.code || "DIRECT_RUN_FAILED";
    job.error = core.safeErrorText(error, "取数未完成");
    job.step = job.error;
    const partial = buildPartialReport(records, job);
    if (partial?.quality) {
      partial.quality.complete = false;
      partial.quality.exportAllowed = false;
      partial.quality.status = directTerminalCollectionError(error) ? "blocked" : "partial";
      partial.quality.missing = [...new Set([...(partial.quality.missing || []), `任务失败：${job.error}`])];
    }
    if (partial && !directTerminalCollectionError(error)) {
      job.warnings = [...new Set([...(job.warnings || []), `已归档当前可用数据：${job.error}`])];
      return await finishWithSanjieImport(state, job, partial, { expectedShop: state.expectedShop });
    }
    state.report = partial;
    state.job = publicJob(job);
    await writeLocalState(state);
    await broadcast(job);
    return { ok: false, error: job.error, code: job.errorCode, job: publicJob(job), reportReady: false };
  } finally {
    records.length = 0;
  }
}

async function getClientState() {
  const draft = await readDraftAfterPendingWrites();
  const state = await readLocalState();
  if (["running", "collecting", "retrying"].includes(state.job?.status) && !runningPromise) {
    state.job = {
      ...state.job,
      status: "interrupted",
      statusLabel: "需要重试",
      step: "上次任务因扩展后台中断，请重新运行",
      error: "上次任务未完成",
      errorCode: "WORKER_INTERRUPTED"
    };
    await writeLocalState(state);
  }
  return { ok: true, state: { ...state, job: publicJob(state.job) }, draft };
}

function storedReportArchiveIds(state) {
  const report = state?.report || {};
  const overview = (report.tables || []).find(table => table?.name === "报告总览");
  const itemRow = (overview?.rows || []).find(row => String(row?.[0] || "") === "商品ID") || [];
  return core.validateJob({
    subjectItemId: state?.lastConfig?.subjectItemId
      || state?.job?.subjectItemId
      || report.item?.id
      || itemRow[1],
    successItemId: state?.lastConfig?.successItemId
      || state?.job?.successItemId
      || report.item?.competitorId
      || itemRow[2]
  });
}

function storedReportArchiveJob(state) {
  const ids = storedReportArchiveIds(state);
  const previous = state?.job || {};
  return {
    id: `archive-existing-${Date.now()}-${ids.subjectItemId}-${ids.successItemId}`,
    ...ids,
    status: "collecting",
    statusLabel: "同步中",
    step: "同步现有报告到官网",
    progress: 96,
    startedAt: previous.startedAt || new Date().toISOString(),
    period: state.report?.period || previous.period || null,
    latestDay: state.report?.period?.endDate || previous.latestDay || "",
    recordCount: Number(state.report?.recordCount || previous.recordCount || 0),
    sceneCount: Number(previous.sceneCount || 0),
    sceneMissed: Array.isArray(previous.sceneMissed) ? previous.sceneMissed : [],
    warnings: Array.isArray(previous.warnings) ? previous.warnings : [],
    expectedShop: normalizeExpectedShop(state.expectedShop || previous.expectedShop),
    enforceExpectedShop: previous.enforceExpectedShop === true,
    reconcileArchiveFirst: state.sanjie?.errorPhase === "post"
      || state.sanjie?.status === "archiving"
  };
}

async function openOfficialLocalFallback(archiveFailure = null) {
  const launchNonce = createLaunchNonce();
  const reportUrl = officialLocalFallbackUrl(launchNonce);
  await cleanupOfficialLaunches();
  await writeOfficialNonce(OFFICIAL_LAUNCH_KEY_PREFIX, launchNonce, {
    tabId: null,
    expiresAt: Date.now() + OFFICIAL_LAUNCH_TTL_MS,
    used: false
  });
  let tab;
  try {
    tab = await chrome.tabs.create({ url: reportUrl });
  } catch (error) {
    await deleteOfficialNonce(OFFICIAL_LAUNCH_KEY_PREFIX, launchNonce);
    throw error;
  }
  const pending = await readOfficialNonce(OFFICIAL_LAUNCH_KEY_PREFIX, launchNonce);
  if (pending && !pending.used && pending.tabId == null) {
    await writeOfficialNonce(OFFICIAL_LAUNCH_KEY_PREFIX, launchNonce, { ...pending, tabId: tab?.id || null });
  }
  return {
    ok: true,
    archived: false,
    fallback: true,
    reportUrl,
    archiveError: archiveFailure?.error || "",
    archiveCode: archiveFailure?.code || ""
  };
}

function isArchivableStoredReport(report) {
  return Boolean(report && typeof report === "object"
    && (Array.isArray(report.tables) || report.item?.id));
}

function isArchivedSanjieState(sanjie) {
  return sanjie?.ok === true
    && sanjie?.archived !== false
    && Boolean(sanjie?.reportId)
    && Boolean(officialArchivedReportUrl(sanjie?.reportUrl));
}

function stateForArchiveOutboxEntry(entry) {
  return normalizeLocalState({
    lastConfig: entry?.lastConfig,
    job: entry?.job,
    report: entry?.report,
    sanjie: entry?.sanjie,
    sourceShop: entry?.sourceShop,
    expectedShop: entry?.expectedShop,
    archiveOutbox: []
  });
}

async function synchronizeArchiveOutboxEntry(state, entry) {
  const entryState = stateForArchiveOutboxEntry(entry);
  let job;
  try {
    job = storedReportArchiveJob(entryState);
  } catch (error) {
    const failure = {
      ok: false,
      status: "failed",
      archived: false,
      reportId: "",
      reportUrl: "",
      savedAt: "",
      attemptedAt: new Date().toISOString(),
      errorCode: error?.code || "ARCHIVE_IDENTITY_INVALID",
      errorPhase: "identity",
      error: core.safeErrorText(error, "报告商品身份无效")
    };
    updateArchiveOutboxEntry(state, entry.fingerprint, {
      sanjie: failure,
      attempts: Number(entry.attempts || 0) + 1
    });
    await writeLocalState(state);
    return { ok: false, archived: false, code: failure.errorCode, error: failure.error, nonRetryable: true };
  }

  const isCurrent = entry.fingerprint === currentArchiveFingerprint(state);
  const attemptedAt = new Date().toISOString();
  const archiving = {
    ok: false,
    status: "archiving",
    archived: false,
    reportId: "",
    reportUrl: "",
    savedAt: "",
    attemptedAt,
    errorCode: "SANJIE_IMPORT_UNCERTAIN",
    errorPhase: "post",
    error: "官网报告正在归档"
  };
  updateArchiveOutboxEntry(state, entry.fingerprint, {
    job: publicJob(job),
    sanjie: archiving,
    attempts: Number(entry.attempts || 0) + 1
  });
  if (isCurrent) state.sanjie = archiving;
  await writeLocalState(state);

  try {
    const canonical = reportEngine.toCanonicalReport(entry.report);
    const imported = await importCanonicalReportToSanjie(canonical, job, {
      reconcileFirst: job.reconcileArchiveFirst === true,
      quality: archiveReportQuality(entry.report),
      sourceShop: core.sanitizeSourceShop(entry.sourceShop || entryState.sourceShop),
      expectedShop: normalizeExpectedShop(entry.expectedShop || entryState.expectedShop),
      requireExpectedShop: job.enforceExpectedShop === true
    });
    const archived = {
      ...imported,
      status: "archived",
      archived: true,
      attemptedAt,
      autoOpened: false,
      openError: "",
      errorCode: "",
      errorPhase: "",
      error: ""
    };
    removeArchiveOutboxEntry(state, entry.fingerprint);
    if (isCurrent) {
      state.sanjie = archived;
      const quality = archiveReportQuality(entry.report);
      if (quality === "complete" && job.enforceExpectedShop !== true) job.status = "completed";
      else job.status = quality === "complete" ? "complete" : "partial";
      job.statusLabel = quality === "complete" ? "已完成" : "部分数据，待补采";
      job.step = archiveReportQuality(entry.report) === "complete"
        ? "官网历史报告已归档"
        : "官网历史报告已归档（部分数据）";
      job.progress = quality === "complete" ? 100 : DIRECT_PARTIAL_PROGRESS;
      job.finishedAt = new Date().toISOString();
      delete job.errorCode;
      delete job.error;
      state.job = publicJob(job);
    }
    await writeLocalState(state);
    if (isCurrent) await broadcast(job);
    return {
      ok: true,
      archived: true,
      reportReady: true,
      reportUrl: archived.reportUrl,
      autoOpened: false,
      job: publicJob(job)
    };
  } catch (error) {
    const retainPostUncertainty = job.reconcileArchiveFirst === true
      && error?.archivePhase === "lookup";
    const failure = {
      ok: false,
      status: "failed",
      archived: false,
      reportId: "",
      reportUrl: "",
      savedAt: "",
      attemptedAt,
      errorCode: error?.code || "SANJIE_IMPORT_FAILED",
      errorPhase: retainPostUncertainty ? "post" : error?.archivePhase || "unknown",
      error: core.safeErrorText(error, "官网报告未归档")
    };
    job.status = "blocked";
    job.statusLabel = "归档失败";
    job.progress = 100;
    job.finishedAt = new Date().toISOString();
    job.errorCode = failure.errorCode;
    job.error = failure.error;
    job.step = `官网归档失败；本地报告已保留：${failure.error}`;
    updateArchiveOutboxEntry(state, entry.fingerprint, {
      job: publicJob(job),
      sanjie: failure
    });
    if (isCurrent) {
      state.sanjie = failure;
      state.job = publicJob(job);
    }
    await writeLocalState(state);
    if (isCurrent) await broadcast(job);
    return { ok: false, archived: false, error: failure.error, code: failure.errorCode };
  }
}

function synchronizeStoredReport(options = {}) {
  if (storedArchivePromise) return storedArchivePromise;
  storedArchivePromise = (async () => {
    if (runningPromise) return { ok: false, skipped: "running" };
    let state = await readLocalState();
    try {
      await ensureCurrentReportQueued(state);
    } catch (error) {
      return { ok: false, skipped: "outbox-full", code: error?.code || "ARCHIVE_OUTBOX_FULL", error: core.safeErrorText(error) };
    }
    state = await readLocalState();
    const currentFingerprint = currentArchiveFingerprint(state);
    if (isArchivedSanjieState(state.sanjie) && currentFingerprint && archiveEntryIndex(state, currentFingerprint) >= 0) {
      removeArchiveOutboxEntry(state, currentFingerprint);
      await writeLocalState(state);
    }
    const queue = sortedArchiveOutbox(state);
    if (!queue.length) {
      if (isArchivedSanjieState(state.sanjie)) {
        return { ok: true, archived: true, reused: true, reportUrl: officialArchivedReportUrl(state.sanjie.reportUrl) };
      }
      return { ok: false, skipped: "no-report" };
    }
    if (options.authorized !== true) {
      const access = await checkOfficialSiteAccess(Boolean(options.forceAuth));
      if (!access?.ok) {
        return { ok: false, skipped: "auth", reason: access?.reason || "unavailable" };
      }
    }

    let archivedCount = 0;
    let skippedCount = 0;
    let latest = null;
    for (const queued of queue) {
      const failureCode = String(queued?.sanjie?.errorCode || "");
      if (queued?.sanjie?.status === "failed"
        && failureCode
        && !RECOVERABLE_SANJIE_CODES.has(failureCode)) {
        skippedCount += 1;
        continue;
      }
      latest = await synchronizeArchiveOutboxEntry(state, queued);
      state = await readLocalState();
      if (!latest.ok) {
        if (latest.nonRetryable) {
          skippedCount += 1;
          continue;
        }
        return { ...latest, archivedCount, pendingCount: sortedArchiveOutbox(state).length };
      }
      archivedCount += 1;
    }
    if (latest?.ok) return { ...latest, archivedCount, pendingCount: sortedArchiveOutbox(state).length };
    return { ok: false, skipped: "non-retryable", skippedCount, pendingCount: sortedArchiveOutbox(state).length };
  })().finally(() => {
    storedArchivePromise = null;
  });
  return storedArchivePromise;
}

function scheduleStoredReportArchive(trigger = "worker-wake") {
  return synchronizeStoredReport({ trigger }).catch(() => ({ ok: false, skipped: "error" }));
}

async function openArchivedStoredReport(state) {
  const reportUrl = officialArchivedReportUrl(state?.sanjie?.reportUrl);
  if (!reportUrl) throw new Error("官网归档记录的报告链接无效；本地报告仍已保留");
  const opened = await openOfficialArchivedReport(reportUrl);
  state.sanjie.autoOpened = true;
  state.sanjie.openedAt = new Date().toISOString();
  if (state.job) state.job.step = "官网历史报告已归档并打开";
  await writeLocalState(state);
  return { ok: true, archived: true, fallback: false, reportUrl: opened.reportUrl };
}

async function openStoredReport() {
  requireOfficialSiteAccess(await checkOfficialSiteAccess(true));
  let state = await readLocalState();
  if (!isArchivableStoredReport(state.report)) {
    return { ok: false, error: "本机没有可归档的 HTML 报告" };
  }
  if (isArchivedSanjieState(state.sanjie)) return openArchivedStoredReport(state);
  if (runningPromise) return { ok: false, error: "取数任务仍在运行，请完成后再打开报告" };

  let synced = await synchronizeStoredReport({ authorized: true, trigger: "manual-open" });
  state = await readLocalState();
  if (isArchivedSanjieState(state.sanjie)) return openArchivedStoredReport(state);
  if (synced?.skipped === "auth") {
    synced = await synchronizeStoredReport({ authorized: true, trigger: "manual-open-retry" });
    state = await readLocalState();
    if (isArchivedSanjieState(state.sanjie)) return openArchivedStoredReport(state);
  }
  if (synced?.skipped && !["error"].includes(synced.skipped)) {
    return { ok: false, error: "报告同步任务暂未完成，请稍后重试" };
  }
  return openOfficialLocalFallback(synced);
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "DMP_ROLLING7_OPEN_REPORT") {
    synchronizeAndOpenRolling7OfficialReport()
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: rolling7SafeError(error, "官网报告打开失败").message, code: error?.code || "REPORT_OPEN_FAILED" }));
    return true;
  }
  if (message?.type === "DMP_ROLLING7_GET_REPORT_FOR_FRAME") {
    readRolling7FrameReport(message, _sender)
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: rolling7SafeError(error, "滚动报告读取失败").message, code: error?.code || "REPORT_READ_FAILED" }));
    return true;
  }
  if (message?.type === "DMP_ROLLING7_GET_STATE") {
    getRolling7ClientState()
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: rolling7SafeError(error).message, code: error?.code || "STATE_READ_FAILED" }));
    return true;
  }
  if (message?.type === "DMP_ROLLING7_START") {
    startRolling7(message)
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: rolling7SafeError(error).message, code: error?.code || "QUEUE_START_FAILED" }));
    return true;
  }
  if (message?.type === "DMP_ROLLING7_PAUSE") {
    pauseRolling7()
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: rolling7SafeError(error).message, code: error?.code || "QUEUE_PAUSE_FAILED" }));
    return true;
  }
  if (message?.type === "DMP_ROLLING7_RESUME") {
    resumeRolling7()
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: rolling7SafeError(error).message, code: error?.code || "QUEUE_RESUME_FAILED" }));
    return true;
  }
  if (message?.type === "DMP_ROLLING7_STOP") {
    stopRolling7()
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: rolling7SafeError(error).message, code: error?.code || "QUEUE_STOP_FAILED" }));
    return true;
  }
  if (message?.type === "DMP_DIRECT_AUTH_CHECK") {
    checkOfficialSiteAccess(Boolean(message.force))
      .then(result => {
        sendResponse(result);
        if (result?.ok) {
          void scheduleStoredReportArchive("auth-success");
          void scheduleStoredRolling7Archive("auth-success");
        }
      })
      .catch(error => sendResponse({ ok: false, reason: "offline", error: core.safeErrorText(error) }));
    return true;
  }
  if (message?.type === "DMP_DIRECT_OPEN_LOGIN") {
    chrome.tabs.create({ url: `${core.SANJIE_ORIGIN}/login` })
      .then(tab => sendResponse({ ok: true, tabId: tab?.id || null }))
      .catch(error => sendResponse({ ok: false, error: core.safeErrorText(error) }));
    return true;
  }
  if (message?.type === "DMP_DIRECT_SAVE_DRAFT") {
    saveDraft(message.draft)
      .then(draft => sendResponse({ ok: true, draft }))
      .catch(error => sendResponse({ ok: false, error: core.safeErrorText(error), code: error?.code || "DRAFT_SAVE_FAILED" }));
    return true;
  }
  if (message?.type === "DMP_DIRECT_GET_STATE") {
    getClientState().then(sendResponse).catch(error => sendResponse({ ok: false, error: core.safeErrorText(error) }));
    return true;
  }
  if (message?.type === "DMP_DIRECT_PREPARE_OFFICIAL_FRAME") {
    prepareOfficialReportFrame(message, _sender)
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: core.safeErrorText(error) }));
    return true;
  }
  if (message?.type === "DMP_DIRECT_GET_REPORT_FOR_FRAME") {
    readOfficialFrameReport(message, _sender)
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: core.safeErrorText(error) }));
    return true;
  }
  if (message?.type === "DMP_DIRECT_OPEN_HTML") {
    openStoredReport()
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: core.safeErrorText(error) }));
    return true;
  }
  if (message?.type === "DMP_DIRECT_START") {
    if (runningPromise) {
      sendResponse({ ok: false, error: "已有取数任务正在运行" });
      return false;
    }
    try {
      core.validateJob(message);
    } catch (error) {
      sendResponse({ ok: false, error: core.safeErrorText(error) });
      return false;
    }
    const pendingArchive = storedArchivePromise;
    runningPromise = (pendingArchive ? pendingArchive.catch(() => null) : Promise.resolve())
      .then(() => runDirectJob(message));
    runningPromise
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: core.safeErrorText(error) }))
      .finally(() => {
        runningPromise = null;
        void scheduleStoredReportArchive("job-finished");
      });
    return true;
  }
  return false;
});

if (chrome.runtime.onInstalled?.addListener) {
  chrome.runtime.onInstalled.addListener(() => {
    void scheduleStoredReportArchive("installed-or-updated");
    void scheduleStoredRolling7Archive("installed-or-updated");
  });
}
if (chrome.runtime.onStartup?.addListener) {
  chrome.runtime.onStartup.addListener(() => {
    void scheduleStoredReportArchive("browser-startup");
    void scheduleStoredRolling7Archive("browser-startup");
  });
  void scheduleStoredReportArchive("worker-wake");
  void scheduleStoredRolling7Archive("worker-wake");
}
if (chrome.alarms?.onAlarm?.addListener) {
  chrome.alarms.onAlarm.addListener(alarm => {
    if (alarm?.name !== ROLLING7_ALARM_NAME) return;
    void ensureRolling7Initialized().then(() => currentRolling7State()).then(state => {
      if (state?.queueStatus === "running") void runRolling7Queue();
    });
  });
}
if (chrome.cookies.onChanged?.addListener) {
  chrome.cookies.onChanged.addListener(changeInfo => {
    if (!changeInfo?.removed && changeInfo?.cookie?.name === SANJIE_SESSION_COOKIE) {
      officialAuthCache = { expiresAt: 0, result: null };
      void scheduleStoredReportArchive("login-cookie-changed");
      void scheduleStoredRolling7Archive("login-cookie-changed");
    }
  });
}

void ensureRolling7Initialized().then(state => {
  if (state?.queueStatus === "running") void runRolling7Queue();
  else if (publicRolling7State(state).reportReady) {
    void scheduleRolling7TrackCollection(state)
      .catch(() => null)
      .then(() => scheduleStoredRolling7Archive("rolling-state-ready"));
  }
});
