(() => {
  "use strict";

  const root = globalThis;
  const PAGE_API_KEY = "__SZ_DMP_DIRECT_MARKET_V2__";
  const PAGE_API_VERSION = 2;
  const PAGE_API_CAPABILITY = "market-rolling7-v1";
  const PAGE_TRACK_CAPABILITY = "market-track-v1";
  if (Number(root[PAGE_API_KEY]?.version || 0) >= PAGE_API_VERSION) return;

  const PAGE_ORIGIN = "https://dmp.taobao.com";
  const GATEWAY_ORIGIN = "https://dmp.advgateway.taobao.com";
  const ALLOWED_ORIGINS = new Set([PAGE_ORIGIN, GATEWAY_ORIGIN]);
  const MAX_TEMPLATE_BYTES = 512 * 1024;
  const MAX_RESPONSE_BYTES = 5 * 1024 * 1024;
  const REQUEST_TIMEOUT_MS = 20_000;
  const ALLOWED = Object.freeze({
    "/api/latestDay": "GET",
    "/api/goods/item/info": "GET",
    "/api/goods/grow/define/success/load": "GET",
    "/api/goods/grow/define/success/item/list": "GET",
    "/dataplatform/dataset/report/query": "POST",
    "/api/goods/grow/define/line/data": "GET",
    "/api/goods/grow/comparison/scene": "GET",
    "/api/goods/grow/comparison/scene/keyword": "GET",
    "/api/subdivide/market/item/properties": "GET",
    "/api/subdivide/market/date/range": "GET",
    "/api/subdivide/market/overview": "POST",
    "/api/subdivide/market/item/price/range": "GET",
    "/api/subdivide/market/item/growth": "POST",
    "/api/subdivide/market/item/chance": "GET",
    "/api/subdivide/market/item/track/list": "POST",
    "/api/subdivide/market/item/track/detail": "POST"
  });
  const TRACK_PATHS = new Set([
    "/api/subdivide/market/item/properties",
    "/api/subdivide/market/date/range",
    "/api/subdivide/market/item/price/range",
    "/api/subdivide/market/item/growth",
    "/api/subdivide/market/item/chance",
    "/api/subdivide/market/item/track/list",
    "/api/subdivide/market/item/track/detail"
  ]);
  const MARKET_PATHS = new Set([...TRACK_PATHS, "/api/subdivide/market/overview"]);
  const MARKET_POST_PATHS = new Set([
    "/api/subdivide/market/item/growth",
    "/api/subdivide/market/item/track/list",
    "/api/subdivide/market/item/track/detail"
  ]);
  const MARKET_BUSINESS_KEYS = new Set(["cateId", "periodType", "date", "propertyId", "chanceCode", "trackId"]);
  const SAFE_QUERY_KEYS = new Set([
    "itemId", "successItemId", "succItemIds", "startDate", "endDate", "sceneLevel1Id",
    "scene", "keyword", "cateId", "thedate", "sceneCode", "page", "pageSize", "periodType", "date",
    "propertyId", "chanceCode", "trackId"
  ]);
  const BUSINESS_QUERY_KEYS = new Set([
    ...SAFE_QUERY_KEYS, "growthStage", "sellerLevel", "gmvRankRateLevel"
  ]);
  const SENSITIVE_KEY = /(?:token|csrf|cookie|authorization|password|secret|(?:^|[_-])sign(?:ature|data)?$|session|webOpSessionId|uniqueItemCampaign)/i;
  const templates = new Map();
  let templateSequence = 0;
  const originalFetch = typeof root.fetch === "function" ? root.fetch : null;
  const NativeXHR = typeof root.XMLHttpRequest === "function" ? root.XMLHttpRequest : null;

  function canonicalPath(value) {
    let pathname = "";
    try {
      const url = new URL(String(value || ""), root.location?.href || "https://dmp.taobao.com/");
      if (!ALLOWED_ORIGINS.has(url.origin)) return "";
      pathname = url.pathname;
    } catch { return ""; }
    return pathname.replace(/^\/api_2\//, "/api/").replace(/\.json$/, "").replace(/\/+$/, "");
  }

  function bodyString(value) {
    if (value == null) return "";
    if (typeof value === "string") return value.length <= MAX_TEMPLATE_BYTES ? value : "";
    if (typeof URLSearchParams !== "undefined" && value instanceof URLSearchParams) {
      const text = value.toString();
      return text.length <= MAX_TEMPLATE_BYTES ? text : "";
    }
    return "";
  }

  function contentType(headers) {
    try { return new Headers(headers || {}).get("content-type") || ""; } catch { return ""; }
  }

  function stableStringify(value) {
    if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
    if (value && typeof value === "object") {
      return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(",")}}`;
    }
    return JSON.stringify(value);
  }

  function fingerprintHash(value) {
    let hash = 2166136261;
    const text = String(value || "");
    for (let index = 0; index < text.length; index += 1) {
      hash ^= text.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
  }

  function normalizedDatasetFilters(value) {
    const parsed = typeof value === "string" ? parseJson(value) : value;
    if (!Array.isArray(parsed)) return value;
    return parsed.map(filter => {
      if (!filter || typeof filter !== "object" || Array.isArray(filter)) return filter;
      const marker = `${filter.expression || ""}|${filter.description || ""}|${filter.name || ""}`;
      const output = {};
      for (const [key, child] of Object.entries(filter)) {
        if (SENSITIVE_KEY.test(key) || /^(?:hasAuth|authInfo|credentials?)$/i.test(key)) continue;
        if (key === "values" && /item_id|\u5b9d\u8d1dID/i.test(marker)) output[key] = ["<item-id>"];
        else if (key === "values" && /thedate|\u65e5\u671f|\u65f6\u95f4/i.test(marker)) output[key] = ["<start-date>", "<end-date>"];
        else output[key] = child;
      }
      return output;
    });
  }

  function normalizedDatasetTemplateBody(raw) {
    const payload = parseJson(raw);
    if (!payload || typeof payload !== "object" || Array.isArray(payload)) return "";
    const visit = (value, key = "", depth = 0) => {
      if (depth > 20) return null;
      if (key === "filterCondition" || key === "filterCompareCondition") {
        return normalizedDatasetFilters(value);
      }
      if (Array.isArray(value)) return value.map(child => visit(child, "", depth + 1));
      if (value && typeof value === "object") {
        const output = {};
        for (const [childKey, child] of Object.entries(value)) {
          if (SENSITIVE_KEY.test(childKey) || /^(?:hasAuth|authInfo|credentials?)$/i.test(childKey)) continue;
          output[childKey] = visit(child, childKey, depth + 1);
        }
        return output;
      }
      return value;
    };
    return stableStringify(visit(payload));
  }

  function datasetTemplateFingerprint(raw) {
    const normalized = normalizedDatasetTemplateBody(raw);
    return normalized ? `idx-${fingerprintHash(normalized)}` : "";
  }

  function metricNamesFromResponseText(raw) {
    const response = parseJson(raw);
    const card = response?.data?.INDEX_CARD || response?.INDEX_CARD;
    if (!card || typeof card !== "object") return [];
    const names = [];
    if (Array.isArray(card.list)) {
      for (const row of card.list) names.push(String(row?.field?.name || row?.name || "").trim());
    } else if (Array.isArray(card.fields)) {
      for (const field of card.fields) names.push(String(field?.name || "").trim());
    }
    return [...new Set(names.filter(name => name && name.length <= 100 && !SENSITIVE_KEY.test(name)))];
  }

  function primarySalesMetricNames(names) {
    const identities = new Set((names || []).map(name => String(name).toLowerCase().replace(/[\s_\-/\uff08\uff09()\u3010\u3011\[\]\uff1a:]+/g, "")));
    const hasOrders = ["成交笔数", "支付成交笔数", "支付笔数", "alipaycnt", "alipaycnt1d"].some(name => identities.has(name));
    const hasAov = ["笔单价", "客单价", "平均订单金额", "unitprice", "avgorder"].some(name => identities.has(name));
    return hasOrders && hasAov;
  }

  function rememberTemplate(entry) {
    const path = canonicalPath(entry?.url);
    if (!path || !ALLOWED[path]) return;
    const method = String(entry.method || "GET").toUpperCase();
    if (method !== ALLOWED[path]) return;
    const body = bodyString(entry.body ?? entry.requestPostData ?? entry.postData);
    const current = templates.get(path) || [];
    const fingerprint = path === "/dataplatform/dataset/report/query" && datasetType({ body }) === "INDEX_CARD"
      ? datasetTemplateFingerprint(body)
      : "";
    const metricNames = Array.isArray(entry.metricNames) ? [...new Set(entry.metricNames.map(String).filter(Boolean))] : [];
    const template = {
      path,
      url: String(entry.url),
      method,
      body,
      requestPostData: body,
      contentType: String(entry.contentType || ""),
      capturedAt: Date.now(),
      captureOrdinal: templateSequence++,
      ...(fingerprint ? { templateId: fingerprint, fingerprint, metricNames, primarySales: primarySalesMetricNames(metricNames) } : {})
    };
    const duplicate = current.findIndex(candidate => fingerprint
      ? candidate.fingerprint === fingerprint
      : candidate.url === template.url && candidate.method === method && candidate.body === body);
    if (duplicate >= 0) {
      const previous = current[duplicate];
      template.firstCapturedAt = previous.firstCapturedAt || previous.capturedAt;
      template.firstOrdinal = Number.isInteger(previous.firstOrdinal) ? previous.firstOrdinal : previous.captureOrdinal;
      if (!metricNames.length && Array.isArray(previous.metricNames)) {
        template.metricNames = previous.metricNames;
        template.primarySales = previous.primarySales === true;
      }
      current.splice(duplicate, 1);
    } else {
      template.firstCapturedAt = template.capturedAt;
      template.firstOrdinal = template.captureOrdinal;
    }
    current.push(template);
    const limit = MARKET_PATHS.has(path) ? 128 : path === "/dataplatform/dataset/report/query" ? 64 : 8;
    while (current.length > limit) current.shift();
    templates.set(path, current);
  }

  async function rememberFetchTemplate(descriptor, response) {
    const entry = descriptor && typeof descriptor.then === "function" ? await descriptor.catch(() => null) : descriptor;
    if (!entry) return;
    if (canonicalPath(entry.url) === "/dataplatform/dataset/report/query" && response?.clone) {
      try {
        const length = Number(response.headers?.get?.("content-length") || 0);
        if (!Number.isFinite(length) || length <= MAX_RESPONSE_BYTES) {
          const text = await response.clone().text();
          if (text.length <= MAX_RESPONSE_BYTES) entry.metricNames = metricNamesFromResponseText(text);
        }
      } catch {}
    }
    rememberTemplate(entry);
  }

  function describeFetchTemplate(input, init) {
    let url = "";
    let method = "GET";
    let body = "";
    let mime = "";
    try {
      if (typeof Request !== "undefined" && input instanceof Request) {
        url = input.url;
        method = String(init?.method || input.method || "GET").toUpperCase();
        mime = contentType(init?.headers || input.headers);
        if (init && Object.prototype.hasOwnProperty.call(init, "body")) {
          body = bodyString(init.body);
        } else if (method !== "GET" && method !== "HEAD") {
          return input.clone().text()
            .then(text => ({ url, method, body: bodyString(text), contentType: mime }))
            .catch(() => null);
        }
      } else {
        url = new URL(String(input || ""), root.location?.href || "https://dmp.taobao.com/").href;
        method = String(init?.method || "GET").toUpperCase();
        body = bodyString(init?.body);
        mime = contentType(init?.headers);
      }
      return { url, method, body, contentType: mime };
    } catch { return null; }
  }

  if (originalFetch) {
    const wrappedFetch = function fetch(input, init) {
      const descriptor = describeFetchTemplate(input, init);
      const result = Reflect.apply(originalFetch, this, arguments);
      Promise.resolve(result).then(response => {
        if (!response?.ok) return;
        let templateResponse = response;
        try { if (response?.clone) templateResponse = response.clone(); } catch {}
        void rememberFetchTemplate(descriptor, templateResponse);
      }).catch(() => {});
      return result;
    };
    try { Object.defineProperty(wrappedFetch, "toString", { value: originalFetch.toString.bind(originalFetch) }); } catch {}
    root.fetch = wrappedFetch;
  }

  if (NativeXHR?.prototype) {
    const xhrMeta = new WeakMap();
    const originalOpen = NativeXHR.prototype.open;
    const originalSetRequestHeader = NativeXHR.prototype.setRequestHeader;
    const originalSend = NativeXHR.prototype.send;
    NativeXHR.prototype.open = function open(method, url) {
      xhrMeta.set(this, {
        method: String(method || "GET").toUpperCase(),
        url: new URL(String(url || ""), root.location?.href || "https://dmp.taobao.com/").href,
        contentType: ""
      });
      return Reflect.apply(originalOpen, this, arguments);
    };
    NativeXHR.prototype.setRequestHeader = function setRequestHeader(name, value) {
      const meta = xhrMeta.get(this);
      if (meta && String(name).toLowerCase() === "content-type") meta.contentType = String(value || "");
      return Reflect.apply(originalSetRequestHeader, this, arguments);
    };
    NativeXHR.prototype.send = function send(body) {
      const meta = xhrMeta.get(this);
      if (meta && typeof this.addEventListener === "function") {
        meta.body = body;
        this.addEventListener("loadend", () => {
          if (Number(this.status) >= 200 && Number(this.status) < 300) {
            try { meta.metricNames = metricNamesFromResponseText(this.responseText); } catch {}
            rememberTemplate(meta);
          }
        }, { once: true });
      }
      return Reflect.apply(originalSend, this, arguments);
    };
  }

  function parseJson(text) {
    try { return JSON.parse(String(text || "")); } catch { return null; }
  }

  function parseRequestPayload(template) {
    const raw = template?.body ?? template?.requestPostData ?? template?.postData ?? "";
    const parsed = parseJson(raw);
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) return parsed;
    try {
      const params = new URLSearchParams(String(raw || ""));
      return params.size ? Object.fromEntries(params) : null;
    } catch { return null; }
  }

  function datasetType(template) {
    const payload = parseRequestPayload(template);
    return String(payload?.type ?? payload?.data?.type ?? payload?.params?.type ?? "").trim().toUpperCase();
  }

  function latestTemplates(path) {
    return [...(templates.get(path) || [])].sort((left, right) => right.capturedAt - left.capturedAt);
  }

  function indexCardTemplates() {
    return latestTemplates("/dataplatform/dataset/report/query")
      .filter(candidate => datasetType(candidate) === "INDEX_CARD" && candidate.templateId)
      .sort((left, right) => Number(left.firstOrdinal ?? left.captureOrdinal) - Number(right.firstOrdinal ?? right.captureOrdinal)
        || String(left.templateId).localeCompare(String(right.templateId)));
  }

  function businessParams(template) {
    const output = {};
    try {
      const url = new URL(String(template?.url || ""));
      for (const [key, value] of url.searchParams) if (MARKET_BUSINESS_KEYS.has(key)) output[key] = value;
    } catch {}
    const visit = (value, depth = 0) => {
      if (!value || typeof value !== "object" || depth > 4) return;
      if (Array.isArray(value)) {
        for (const child of value) visit(child, depth + 1);
        return;
      }
      for (const [key, child] of Object.entries(value)) {
        if (MARKET_BUSINESS_KEYS.has(key) && (typeof child === "string" || typeof child === "number")) output[key] = child;
        else if (child && typeof child === "object") visit(child, depth + 1);
      }
    };
    visit(parseRequestPayload(template));
    return output;
  }

  function marketTemplatePeriodType(path, template) {
    return MARKET_PATHS.has(path) ? String(businessParams(template).periodType || "") : "";
  }

  function marketTemplateMatches(path, template, spec = {}, options = {}) {
    const params = businessParams(template);
    const requestedDate = spec.date ?? spec.requestDate;
    if (spec.cateId != null && params.cateId != null && String(params.cateId) !== String(spec.cateId)) return false;
    if (spec.periodType != null && params.periodType != null && String(params.periodType) !== String(spec.periodType)) return false;
    if (!options.allowDimensionRewrite && path === "/api/subdivide/market/item/growth" && spec.propertyId != null) {
      return params.propertyId != null && String(params.propertyId) === String(spec.propertyId);
    }
    if (!options.allowDimensionRewrite && path === "/api/subdivide/market/item/track/list" && spec.chanceCode != null) {
      return params.chanceCode != null && String(params.chanceCode) === String(spec.chanceCode);
    }
    if (path === "/api/subdivide/market/date/range" && requestedDate != null && params.date == null) return false;
    return true;
  }

  function selectTemplate(path, spec) {
    const candidates = latestTemplates(path);
    if (path === "/dataplatform/dataset/report/query") {
      const cards = indexCardTemplates();
      const requestedId = String(spec?.templateId || spec?.templateFingerprint || "").trim();
      if (requestedId) return cards.find(candidate => candidate.templateId === requestedId || candidate.fingerprint === requestedId) || null;
      if (spec?.templateOrdinal != null && Number.isInteger(Number(spec.templateOrdinal)) && Number(spec.templateOrdinal) >= 0) {
        return cards[Number(spec.templateOrdinal)] || null;
      }
      if (spec?.templateBody) {
        const legacyFingerprint = datasetTemplateFingerprint(spec.templateBody);
        return cards.find(candidate => candidate.fingerprint === legacyFingerprint) || null;
      }
      return cards.find(candidate => candidate.primarySales) || candidates.find(candidate => datasetType(candidate) === "INDEX_CARD") || null;
    }
    if (MARKET_PATHS.has(path)) {
      const exact = candidates.find(candidate => marketTemplateMatches(path, candidate, spec));
      if (exact) return exact;
      if (path === "/api/subdivide/market/item/growth" || path === "/api/subdivide/market/item/track/list") {
        return candidates.find(candidate => marketTemplateMatches(path, candidate, spec, { allowDimensionRewrite: true })) || null;
      }
      return null;
    }
    return candidates[0] || null;
  }

  function selectAuthTemplate() {
    return [...templates.values()].flat().sort((left, right) => right.capturedAt - left.capturedAt)[0] || null;
  }

  function dateLike(example, value) {
    const date = String(value || "");
    return /^\d{8}$/.test(String(example || "")) ? date.replaceAll("-", "") : date;
  }

  function setDate(url, key, value) {
    const existing = url.searchParams.get(key) || "";
    url.searchParams.set(key, dateLike(existing, value));
  }

  function validDate(value) {
    const date = String(value || "").trim();
    if (!/^20\d{2}-\d{2}-\d{2}$/.test(date)) return "";
    try { return new Date(`${date}T00:00:00Z`).toISOString().slice(0, 10) === date ? date : ""; } catch { return ""; }
  }

  function requiredText(value, pattern, message, code = "INVALID_MARKET_REQUEST") {
    const text = String(value ?? "").trim();
    if (!pattern.test(text)) {
      const error = new Error(message);
      error.code = code;
      throw error;
    }
    return text;
  }

  function trackParams(path, template, spec = {}) {
    const captured = businessParams(template);
    const output = {
      cateId: spec.cateId ?? captured.cateId,
      periodType: spec.periodType ?? captured.periodType,
      date: spec.date ?? spec.requestDate ?? captured.date,
      propertyId: spec.propertyId ?? captured.propertyId,
      chanceCode: spec.chanceCode ?? captured.chanceCode,
      trackId: spec.trackId ?? captured.trackId
    };
    if (path !== "/api/subdivide/market/date/range") {
      output.cateId = requiredText(output.cateId, /^\d{1,20}$/, "叶子类目 ID 无效");
    }
    if (!["/api/subdivide/market/item/properties", "/api/subdivide/market/item/price/range"].includes(path)) {
      output.periodType = requiredText(output.periodType, /^\d{1,2}$/, "细分赛道周期类型无效");
      output.date = validDate(output.date);
      if (!output.date) {
        const error = new Error("细分赛道请求日期无效");
        error.code = "INVALID_MARKET_REQUEST";
        throw error;
      }
    }
    if (path === "/api/subdivide/market/item/growth") {
      output.propertyId = requiredText(output.propertyId, /^[\w.-]{1,80}$/, "细分赛道属性维度模板无效", "MARKET_TEMPLATE_REQUIRED");
    }
    if (path === "/api/subdivide/market/item/track/list") {
      output.chanceCode = requiredText(output.chanceCode, /^[\w.-]{1,80}$/, "细分赛道机会类型模板无效", "MARKET_TEMPLATE_REQUIRED");
    }
    if (path === "/api/subdivide/market/item/track/detail") {
      const trackId = String(output.trackId ?? "").trim();
      if (!trackId || trackId.length > 500 || /[\u0000-\u001f\u007f]/.test(trackId)) {
        const error = new Error("细分赛道明细模板无效");
        error.code = "MARKET_TEMPLATE_REQUIRED";
        throw error;
      }
      output.trackId = trackId;
    }
    return output;
  }

  function setTrackUrl(url, path, params) {
    const set = (key, value, force = false) => {
      if (value == null || value === "") return;
      if (force || url.searchParams.has(key)) url.searchParams.set(key, String(value));
    };
    if (path === "/api/subdivide/market/date/range") {
      set("periodType", params.periodType, true);
      set("date", params.date, true);
      return;
    }
    if (["/api/subdivide/market/item/properties", "/api/subdivide/market/item/price/range"].includes(path)) {
      set("cateId", params.cateId, true);
      return;
    }
    if (path === "/api/subdivide/market/item/chance") {
      set("cateId", params.cateId, true);
      set("periodType", params.periodType, true);
      set("date", params.date, true);
      return;
    }
    for (const key of MARKET_BUSINESS_KEYS) set(key, params[key]);
  }

  function alignTrackBody(raw, path, spec, template) {
    const parsedJson = parseJson(raw);
    const encoded = !parsedJson;
    let payload = parsedJson;
    if (!payload) {
      try {
        const params = new URLSearchParams(String(raw || ""));
        payload = params.size ? Object.fromEntries(params) : null;
      } catch { payload = null; }
    }
    if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
      const error = new Error("请先在达摩盘市场机会洞察页加载一次目标类目，让插件学习只读请求模板");
      error.code = "MARKET_TEMPLATE_REQUIRED";
      throw error;
    }
    const params = trackParams(path, template, spec);
    const assign = key => {
      if (params[key] == null || params[key] === "") return;
      const existing = payload[key];
      payload[key] = typeof existing === "number" && /^-?\d+(?:\.\d+)?$/.test(String(params[key]))
        ? Number(params[key])
        : String(params[key]);
    };
    for (const key of ["cateId", "periodType", "date"]) assign(key);
    if (path === "/api/subdivide/market/item/growth") assign("propertyId");
    if (path === "/api/subdivide/market/item/track/list") assign("chanceCode");
    if (path === "/api/subdivide/market/item/track/detail") assign("trackId");
    return encoded ? new URLSearchParams(payload).toString() : JSON.stringify(payload);
  }

  function createRequestUrl(path, template, authTemplate, spec) {
    const endpoint = path === "/dataplatform/dataset/report/query" ? `${path}.json` : path;
    let url;
    if (template) {
      url = new URL(template.url);
    } else {
      url = new URL(endpoint, path === "/dataplatform/dataset/report/query" ? GATEWAY_ORIGIN : authTemplate.url);
      const source = new URL(authTemplate.url);
      for (const [key, value] of source.searchParams) {
        if (!BUSINESS_QUERY_KEYS.has(key)) url.searchParams.append(key, value);
      }
    }
    if (!ALLOWED_ORIGINS.has(url.origin) || canonicalPath(url.href) !== path) throw new Error("页面请求模板不属于允许的数据接口");
    url.hash = "";

    if (path === "/api/latestDay") url.searchParams.set("sceneCode", "goodsGrowPathSuccItemList");
    if (path === "/api/goods/item/info") {
      url.searchParams.set("itemId", spec.subjectItemId);
      url.searchParams.set("scene", "1");
    }
    if (path === "/api/goods/grow/define/success/load") {
      url.searchParams.set("itemId", spec.subjectItemId);
      url.searchParams.delete("thedate");
    }
    if (path === "/api/goods/grow/define/success/item/list") {
      const cateId = String(spec.cateId || url.searchParams.get("cateId") || "");
      if (!/^\d{1,20}$/.test(cateId)) {
        const error = new Error("未取得主体商品叶子类目；目标不是已选成功品时暂时无法只读搜索");
        error.code = "CATE_REQUIRED";
        throw error;
      }
      url.searchParams.set("cateId", cateId);
      url.searchParams.set("itemId", spec.subjectItemId);
      url.searchParams.set("growthStage", "2,4,1,3,5,6");
      url.searchParams.set("sellerLevel", "1,2,3,4,5,6,7,8,9");
      url.searchParams.set("gmvRankRateLevel", "1,2");
      url.searchParams.set("pageSize", "20");
      url.searchParams.set("page", "1");
      url.searchParams.set("keyword", spec.successItemId);
      if (spec.latestDay) url.searchParams.set("thedate", spec.latestDay);
    }
    if (path === "/api/goods/grow/define/line/data") {
      url.searchParams.set("itemId", spec.subjectItemId);
      url.searchParams.set("successItemId", spec.successItemId);
      setDate(url, "startDate", spec.period.startDate);
      setDate(url, "endDate", spec.period.endDate);
    }
    if (path === "/api/goods/grow/comparison/scene" || path === "/api/goods/grow/comparison/scene/keyword") {
      url.searchParams.set("itemId", spec.subjectItemId);
      url.searchParams.set("succItemIds", spec.successItemId);
      setDate(url, "startDate", spec.period.startDate);
      setDate(url, "endDate", spec.period.endDate);
      if (path === "/api/goods/grow/comparison/scene") {
        if (spec.sceneLevel1Id) url.searchParams.set("sceneLevel1Id", String(spec.sceneLevel1Id));
        else url.searchParams.delete("sceneLevel1Id");
      }
    }
    if (TRACK_PATHS.has(path)) setTrackUrl(url, path, trackParams(path, template, spec));
    return url;
  }

  function alignMarketOverviewBody(raw, spec) {
    const payload = parseJson(raw);
    if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
      const error = new Error("叶子类目市场概览模板尚未捕获；请先正常打开一次叶子类目市场页面");
      error.code = "TEMPLATE_REQUIRED";
      throw error;
    }
    const cateId = String(spec?.cateId || "");
    const periodType = String(spec?.periodType || "1");
    const date = String(spec?.requestDate || "");
    if (!/^\d{1,20}$/.test(cateId) || !["1", "2"].includes(periodType) || !/^20\d{2}-\d{2}-\d{2}$/.test(date)) {
      const error = new Error("市场分析公开业务参数无效");
      error.code = "INVALID_REQUEST";
      throw error;
    }
    return JSON.stringify({ cateId, periodType, date });
  }

  function alignDatasetBody(raw, spec) {
    const payload = parseJson(raw);
    if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
      const error = new Error("核心指标请求模板尚未捕获；请刷新一次达摩盘打爆路径页面");
      error.code = "TEMPLATE_REQUIRED";
      throw error;
    }
    const type = String(payload.type ?? payload?.data?.type ?? payload?.params?.type ?? "").toUpperCase();
    if (type !== "INDEX_CARD") {
      const error = new Error("尚未捕获核心指标模板；请刷新一次达摩盘打爆路径页面");
      error.code = "TEMPLATE_REQUIRED";
      throw error;
    }
    const align = (key, itemId) => {
      let filters = payload[key];
      const encoded = typeof filters === "string";
      if (encoded) filters = parseJson(filters);
      if (!Array.isArray(filters)) return false;
      filters = filters.map(filter => {
        const marker = `${filter?.expression || ""}|${filter?.description || ""}|${filter?.name || ""}`;
        if (/item_id|宝贝ID/i.test(marker)) return { ...filter, values: [String(itemId)] };
        if (/thedate|日期|时间/i.test(marker)) {
          const example = Array.isArray(filter?.values) ? filter.values[0] : "";
          return { ...filter, values: [dateLike(example, spec.period.startDate), dateLike(example, spec.period.endDate)] };
        }
        return filter;
      });
      payload[key] = encoded ? JSON.stringify(filters) : filters;
      return true;
    };
    if (!align("filterCondition", spec.subjectItemId) || !align("filterCompareCondition", spec.successItemId)) {
      const error = new Error("核心指标模板缺少商品或日期筛选条件");
      error.code = "TEMPLATE_REQUIRED";
      throw error;
    }
    return JSON.stringify(payload);
  }

  function sanitizeUrlString(value) {
    const text = String(value || "");
    if (!/^https?:\/\//i.test(text)) return text;
    try {
      const url = new URL(text);
      for (const key of [...url.searchParams.keys()]) if (SENSITIVE_KEY.test(key)) url.searchParams.delete(key);
      return url.toString();
    } catch { return text; }
  }

  function sanitizeValue(value, depth = 0) {
    if (depth > 24) return null;
    if (Array.isArray(value)) return value.map(child => sanitizeValue(child, depth + 1));
    if (value && typeof value === "object") {
      const output = {};
      for (const [key, child] of Object.entries(value)) {
        if (SENSITIVE_KEY.test(key)) continue;
        output[key] = sanitizeValue(child, depth + 1);
      }
      return output;
    }
    if (typeof value === "string") {
      const text = value.trim();
      if ((text.startsWith("{") && text.endsWith("}")) || (text.startsWith("[") && text.endsWith("]"))) {
        const nested = parseJson(text);
        if (nested && typeof nested === "object") return JSON.stringify(sanitizeValue(nested, depth + 1));
      }
      return sanitizeUrlString(value);
    }
    return value;
  }

  function safeRecordUrl(url) {
    const safe = new URL(url.origin + url.pathname);
    for (const [key, value] of url.searchParams) if (SAFE_QUERY_KEYS.has(key)) safe.searchParams.append(key, value);
    return safe.toString();
  }

  async function readTextCapped(response) {
    const length = Number(response.headers?.get?.("content-length") || 0);
    if (Number.isFinite(length) && length > MAX_RESPONSE_BYTES) throw new Error("接口响应超过本地处理上限");
    if (!response.body?.getReader || typeof TextDecoder === "undefined") {
      const text = await response.text();
      if (text.length > MAX_RESPONSE_BYTES) throw new Error("接口响应超过本地处理上限");
      return text;
    }
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let bytes = 0;
    let text = "";
    while (true) {
      const chunk = await reader.read();
      if (chunk.done) break;
      bytes += chunk.value?.byteLength || 0;
      if (bytes > MAX_RESPONSE_BYTES) {
        try { await reader.cancel(); } catch {}
        throw new Error("接口响应超过本地处理上限");
      }
      text += decoder.decode(chunk.value, { stream: true });
    }
    return text + decoder.decode();
  }

  function failure(code, message, record = null) {
    const output = { ok: false, error: { code: String(code || "REQUEST_FAILED"), message: String(message || "取数失败").slice(0, 240) } };
    if (record) output.record = record;
    return output;
  }

  function marketBusinessFailure(apiInfo, record) {
    const businessText = [
      apiInfo?.message,
      apiInfo?.msg,
      apiInfo?.errorMessage,
      apiInfo?.subMessage
    ].filter(value => value != null).map(String).join(" ").slice(0, 600);
    if (/(?:未登录|登录.*(?:失效|过期)|请.*登录|login|session.*(?:expired|invalid))/i.test(businessText)) {
      return failure("LOGIN_REQUIRED", "达摩盘登录已失效，请重新登录后继续", record);
    }
    if (/(?:无权限|没有权限|权限不足|未授权|禁止访问|forbidden|permission|access\s*denied)/i.test(businessText)) {
      return failure("REQUEST_NOT_ALLOWED", "当前账号无权读取该类目或周期", record);
    }
    if (/(?:参数.*(?:错误|无效)|日期.*(?:格式|无效)|类目.*(?:错误|无效)|invalid\s*(?:param|date|cate))/i.test(businessText)) {
      return failure("INVALID_REQUEST", "达摩盘拒绝了当前类目或日期参数", record);
    }
    // A parsed HTTP-2xx market response that is neither an auth, permission nor parameter
    // failure is only a no-data candidate. The worker still requires a continuous completed
    // prefix and three identical tail observations before it may close the unavailable suffix.
    return failure("MARKET_DATA_UNAVAILABLE", "达摩盘暂未返回可用数据", record);
  }

  async function request(spec) {
    try {
      if (root.location?.hostname !== "dmp.taobao.com" || root.location?.protocol !== "https:") return failure("UNEXPECTED_ORIGIN", "请保持一个已登录的达摩盘页面打开");
      if (!originalFetch) return failure("FETCH_UNAVAILABLE", "当前页面不支持接口请求");
      if (!spec || typeof spec !== "object") return failure("INVALID_REQUEST", "请求参数无效");
      const path = canonicalPath(`${GATEWAY_ORIGIN}${String(spec.path || "")}`);
      const method = String(spec.method || ALLOWED[path] || "").toUpperCase();
      if (!path || ALLOWED[path] !== method) return failure("REQUEST_NOT_ALLOWED", "请求不在达摩盘只读白名单内");
      const marketRequest = MARKET_PATHS.has(path);
      if (!marketRequest && !/^\d{6,20}$/.test(String(spec.subjectItemId || "")) && path !== "/api/latestDay") return failure("INVALID_ITEM", "主体商品 ID 无效");
      if (spec.successItemId && !/^\d{6,20}$/.test(String(spec.successItemId))) return failure("INVALID_ITEM", "成功品/竞品 ID 无效");

      const template = selectTemplate(path, spec);
      if (path === "/dataplatform/dataset/report/query"
        && (spec.templateId || spec.templateFingerprint || spec.templateOrdinal != null)
        && !template && !spec.templateBody) {
        return failure("INDEX_CARD_TEMPLATE_REQUIRED", "指定的核心指标模板已不在当前页面，请刷新达摩盘页面后重试");
      }
      const needsExactTemplate = path === "/api/subdivide/market/date/range"
        || path === "/api/subdivide/market/overview"
        || path === "/api/subdivide/market/item/chance"
        || MARKET_POST_PATHS.has(path);
      if (needsExactTemplate && !template) {
        const trackOnlyRequest = path !== "/api/subdivide/market/date/range"
          && path !== "/api/subdivide/market/overview";
        return failure(
          trackOnlyRequest ? "MARKET_TEMPLATE_REQUIRED" : "TEMPLATE_REQUIRED",
          trackOnlyRequest
            ? "请先在达摩盘市场机会洞察页加载对应周期与属性维度"
            : "请先在当前达摩盘页面手动切换一次对应分析周期"
        );
      }
      const authTemplate = template || selectAuthTemplate();
      if (!authTemplate) return failure("TEMPLATE_REQUIRED", "尚未捕获达摩盘本机请求模板；加载扩展后请刷新一次达摩盘页面");
      const url = createRequestUrl(path, template, authTemplate, spec);
      let requestBody = "";
      let requestMimeType = "";
      if (method === "POST") {
        requestBody = path === "/api/subdivide/market/overview"
          ? alignMarketOverviewBody(template?.body || "", spec)
          : MARKET_POST_PATHS.has(path)
            ? alignTrackBody(template?.body ?? template?.requestPostData ?? "", path, spec, template)
            : alignDatasetBody(template?.body || spec.templateBody || "", spec);
        requestMimeType = template?.contentType || "application/json";
      }

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
      let response;
      let rawText;
      try {
        response = await Reflect.apply(originalFetch, root, [url.href, {
          method,
          credentials: "include",
          cache: "no-store",
          headers: method === "POST" ? { "Content-Type": requestMimeType } : undefined,
          body: method === "POST" ? requestBody : undefined,
          signal: controller.signal
        }]);
        rawText = await readTextCapped(response);
      } finally {
        clearTimeout(timeout);
      }
      const parsed = parseJson(rawText);
      const sanitizedBody = JSON.stringify(sanitizeValue(parsed));
      let requestPayload = method === "POST" ? parseJson(requestBody) : null;
      if (!requestPayload && method === "POST") {
        try {
          const params = new URLSearchParams(requestBody);
          if (params.size) requestPayload = Object.fromEntries(params);
        } catch {}
      }
      const sanitizedRequestBody = requestPayload ? JSON.stringify(sanitizeValue(requestPayload)) : "";
      const safeUrl = safeRecordUrl(url);
      const capturedAt = new Date().toISOString();
      const record = {
        kind: "Network",
        source: "direct-main",
        capturedAt,
        requestId: `direct-${Date.now()}-${Math.random().toString(16).slice(2)}`,
        url: safeUrl,
        origin: url.origin,
        pathname: url.pathname,
        queryKeys: [...new URL(safeUrl).searchParams.keys()],
        method,
        type: "Fetch",
        initiatorType: "direct-main",
        documentUrl: `${root.location.origin}${root.location.pathname}`,
        requestBodyLength: sanitizedRequestBody.length,
        requestBodyTruncated: false,
        requestBodyAvailable: Boolean(sanitizedRequestBody),
        requestMimeType,
        requestFormat: sanitizedRequestBody ? "json" : "empty",
        requestKeys: Object.keys(parseJson(sanitizedRequestBody) || {}),
        requestBody: sanitizedRequestBody,
        status: response.status,
        statusText: response.statusText || "",
        mimeType: response.headers?.get?.("content-type") || "application/json",
        protocol: "fetch",
        fromDiskCache: false,
        fromServiceWorker: false,
        encodedDataLength: sanitizedBody.length,
        bodyAvailable: true,
        bodyEncoding: "",
        bodyLength: sanitizedBody.length,
        truncated: false,
        format: "json",
        responseKeys: Object.keys(sanitizeValue(parsed) || {}),
        body: sanitizedBody,
        templateSource: template ? "page-memory" : "page-auth+local-body",
        ...(path === "/dataplatform/dataset/report/query" && template?.templateId ? {
          templateId: template.templateId,
          templateFingerprint: template.fingerprint,
          templateOrdinal: indexCardTemplates().findIndex(candidate => candidate.templateId === template.templateId)
        } : {})
      };
      if (!response.ok) {
        const loginExpired = response.status === 401 || response.status === 403;
        return failure(
          loginExpired ? "LOGIN_REQUIRED" : "HTTP_ERROR",
          loginExpired ? "达摩盘登录已失效，请重新登录后继续" : `数据接口返回 ${response.status}`,
          record
        );
      }
      if (!String(rawText || "").trim()) return failure("EMPTY_RESPONSE", "接口返回空响应，可稍后自动重试", record);
      if (!parsed) return failure("LOGIN_REQUIRED", "接口未返回业务数据，请确认达摩盘仍处于登录状态", record);
      const apiInfo = parsed?.info || parsed?.result?.info;
      if (apiInfo?.ok === false || (apiInfo?.code != null && Number(apiInfo.code) !== 0)) {
        return marketRequest
          ? marketBusinessFailure(apiInfo, record)
          : failure("API_ERROR", "达摩盘暂未返回可用数据", record);
      }
      return { ok: true, record };
    } catch (error) {
      const code = error?.code || (error?.name === "AbortError" ? "TIMEOUT" : "REQUEST_FAILED");
      return failure(code, error?.name === "AbortError" ? "接口请求超时" : error?.message);
    }
  }

  function readiness() {
    const paths = [...templates.entries()].filter(([, values]) => values.length).map(([path]) => path).sort();
    const marketPeriodTypes = ["1", "2"].filter(periodType =>
      latestTemplates("/api/subdivide/market/date/range")
        .some(candidate => marketTemplatePeriodType("/api/subdivide/market/date/range", candidate) === periodType)
      && latestTemplates("/api/subdivide/market/overview")
        .some(candidate => marketTemplatePeriodType("/api/subdivide/market/overview", candidate) === periodType));
    const marketTemplates = {};
    for (const path of TRACK_PATHS) {
      marketTemplates[path] = latestTemplates(path).map(template => businessParams(template));
    }
    const trackPropertyIds = [...new Set(marketTemplates["/api/subdivide/market/item/growth"]
      .map(row => String(row.propertyId ?? "").trim()).filter(Boolean))];
    const trackChanceCodes = [...new Set(marketTemplates["/api/subdivide/market/item/track/list"]
      .map(row => String(row.chanceCode ?? "").trim()).filter(Boolean))];
    const marketTrackEndpointCounts = Object.fromEntries([...TRACK_PATHS]
      .map(path => [path, marketTemplates[path].length]));
    const indexCards = indexCardTemplates();
    const indexCardTemplateIds = indexCards.map(template => template.templateId);
    const indexCardPrimaryTemplateIds = indexCards.filter(template => template.primarySales).map(template => template.templateId);
    return {
      ok: true,
      version: PAGE_API_VERSION,
      requestTemplateCount: [...templates.values()].reduce((sum, values) => sum + values.length, 0),
      capturedPaths: paths,
      hasIndexCardTemplate: indexCards.length > 0,
      indexCardTemplateCount: indexCards.length,
      indexCardTemplateIds,
      indexCardPrimaryTemplateIds,
      templateRevision: templateSequence,
      lastTemplateCapturedAt: Math.max(0, ...[...templates.values()].flat().map(template => Number(template.capturedAt || 0))),
      hasMarketDateRangeTemplate: latestTemplates("/api/subdivide/market/date/range").length > 0,
      hasMarketOverviewTemplate: latestTemplates("/api/subdivide/market/overview").length > 0,
      marketRolling7Ready: latestTemplates("/api/subdivide/market/date/range").length > 0
        && latestTemplates("/api/subdivide/market/overview").length > 0,
      marketSupportedPeriodTypes: marketPeriodTypes,
      marketRolling30BaselineReady: marketPeriodTypes.includes("2"),
      marketTemplateCount: Object.values(marketTemplates).reduce((sum, values) => sum + values.length, 0),
      marketTemplates,
      marketTrackEndpointCounts,
      trackPropertyIds,
      trackChanceCodes,
      hasMarketPropertiesTemplate: marketTemplates["/api/subdivide/market/item/properties"].length > 0,
      hasMarketGrowthTemplate: trackPropertyIds.length > 0,
      hasMarketChanceTemplate: marketTemplates["/api/subdivide/market/item/chance"].length > 0,
      marketTrackTemplateReady: marketTemplates["/api/subdivide/market/item/properties"].length > 0
        && trackPropertyIds.length > 0
    };
  }

  Object.defineProperty(root, PAGE_API_KEY, {
    value: Object.freeze({
      version: PAGE_API_VERSION,
      capabilities: Object.freeze([PAGE_API_CAPABILITY, PAGE_TRACK_CAPABILITY]),
      readiness,
      request
    }),
    configurable: false,
    enumerable: false,
    writable: false
  });
})();
