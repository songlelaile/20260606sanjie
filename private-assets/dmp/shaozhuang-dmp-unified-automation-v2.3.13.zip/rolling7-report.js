(() => {
  "use strict";

  const writer = globalThis.DmpRolling7HtmlWriter;
  const loading = document.querySelector('[data-role="loading"]');
  const message = document.querySelector('[data-role="message"]');
  let reportDataset = null;
  let viewState = {
    periodMode: "",
    periodKey: "",
    customStartDate: "",
    customEndDate: "",
    trackPropertyId: "",
    trackPeriodKey: "",
    trackMetric: "aScore",
    trackView: "current"
  };

  function showError(error) {
    loading?.setAttribute("data-error", "");
    const title = loading?.querySelector("h1");
    if (title) title.textContent = "报告暂时无法打开";
    if (message) message.textContent = String(error?.message || error || "本机没有可用报告数据").slice(0, 240);
  }

  function renderReport() {
    if (!reportDataset) throw new Error("本机报告数据读取失败");
    const generated = writer.buildHtml(reportDataset, viewState);
    const parsed = new DOMParser().parseFromString(generated, "text/html");
    parsed.querySelectorAll("script").forEach(script => script.remove());
    const nextHead = [...parsed.head.childNodes].map(node => document.importNode(node, true));
    const nextBody = [...parsed.body.childNodes].map(node => document.importNode(node, true));
    document.head.replaceChildren(...nextHead);
    document.body.replaceChildren(...nextBody);
    bindActions();
  }

  function bindChartTooltips() {
    const tooltip = document.querySelector("[data-chart-tooltip]");
    if (!tooltip) return;
    let activePoint = null;
    const position = (clientX, clientY) => {
      if (tooltip.hidden) return;
      const bounds = tooltip.getBoundingClientRect();
      const maximumLeft = Math.max(8, window.innerWidth - bounds.width - 8);
      const maximumTop = Math.max(8, window.innerHeight - bounds.height - 8);
      tooltip.style.left = `${Math.max(8, Math.min(clientX + 12, maximumLeft))}px`;
      tooltip.style.top = `${Math.max(8, Math.min(clientY + 12, maximumTop))}px`;
    };
    const show = (point, clientX, clientY) => {
      if (!point?.dataset.tooltip) return;
      activePoint = point;
      tooltip.textContent = point.dataset.tooltip;
      tooltip.hidden = false;
      position(clientX, clientY);
    };
    const hide = point => {
      if (point && activePoint !== point) return;
      activePoint = null;
      tooltip.hidden = true;
    };
    document.querySelectorAll("[data-chart-point]").forEach(point => {
      point.addEventListener("pointerenter", event => show(point, event.clientX, event.clientY));
      point.addEventListener("pointermove", event => position(event.clientX, event.clientY));
      point.addEventListener("pointerleave", () => {
        if (document.activeElement !== point) hide(point);
      });
      point.addEventListener("focus", () => {
        const bounds = point.getBoundingClientRect();
        show(point, bounds.left + bounds.width / 2, bounds.bottom);
      });
      point.addEventListener("blur", () => hide(point));
    });
  }

  function bindActions() {
    bindChartTooltips();
    const rerenderAtCurrentScroll = update => {
      const scrollTop = window.scrollY;
      viewState = { ...viewState, ...update };
      renderReport();
      window.scrollTo({ top: scrollTop, behavior: "auto" });
    };
    document.querySelector("[data-print]")?.addEventListener("click", () => window.print());
    document.querySelector("[data-period-mode]")?.addEventListener("change", event => {
      rerenderAtCurrentScroll({
        periodMode: String(event.target.value || ""),
        periodKey: "",
        customStartDate: "",
        customEndDate: ""
      });
    });
    const applyCustomRange = () => {
      const startDate = String(document.querySelector("[data-custom-start]")?.value || "");
      const endDate = String(document.querySelector("[data-custom-end]")?.value || "");
      rerenderAtCurrentScroll({ periodMode: "custom-range", periodKey: "", customStartDate: startDate, customEndDate: endDate });
    };
    document.querySelector("[data-custom-range-apply]")?.addEventListener("click", applyCustomRange);
    document.querySelectorAll("[data-custom-start],[data-custom-end]").forEach(input => {
      input.addEventListener("keydown", event => {
        if (event.key === "Enter") applyCustomRange();
      });
    });
    document.querySelector("[data-period-key]")?.addEventListener("change", event => {
      rerenderAtCurrentScroll({ periodKey: String(event.target.value || "") });
    });
    document.querySelector("[data-track-property]")?.addEventListener("change", event => {
      rerenderAtCurrentScroll({
        trackPropertyId: String(event.target.value || ""),
        trackPeriodKey: "",
        trackView: "current"
      });
    });
    document.querySelector("[data-track-period]")?.addEventListener("change", event => {
      rerenderAtCurrentScroll({ trackPeriodKey: String(event.target.value || ""), trackView: "current" });
    });
    document.querySelector("[data-track-metric]")?.addEventListener("change", event => {
      rerenderAtCurrentScroll({ trackMetric: String(event.target.value || "aScore") });
    });
    document.querySelector("[data-track-view]")?.addEventListener("change", event => {
      rerenderAtCurrentScroll({ trackView: String(event.target.value || "current") });
    });
  }

  async function openReport() {
    if (!writer?.buildHtml) throw new Error("报告模块未就绪");
    const frameNonce = new URL(location.href).hash.match(/(?:^#|&)frame=([a-f0-9]{48})(?:&|$)/i)?.[1]?.toLowerCase() || "";
    if (!frameNonce) throw new Error("报告读取凭证缺失，请从扩展重新打开");
    const result = await chrome.runtime.sendMessage({ type: "DMP_ROLLING7_GET_REPORT_FOR_FRAME", frameNonce });
    if (!result?.ok) throw new Error(result?.error || "本机报告数据读取失败");
    history.replaceState(null, "", location.pathname);
    reportDataset = result.dataset;
    const catalog = writer.buildPeriodCatalog(reportDataset);
    viewState = {
      periodMode: catalog.defaultMode,
      periodKey: "",
      customStartDate: "",
      customEndDate: "",
      trackPropertyId: "",
      trackPeriodKey: "",
      trackMetric: "aScore",
      trackView: "current"
    };
    renderReport();
  }

  void openReport().catch(showError);
})();
