import "./report-engine.js";
import { normalizeOfficialShareUrl } from "./official-share-url.mjs";

const activeTabs = new Set();
const attachJobs = new Map();
const requests = new Map();
const sockets = new Map();
const transports = new Map();
const observedResponses = new Map();
const capturedResponses = new Map();
const tabModes = new Map();
const competitionSessions = new Map();

const BODY_LIMIT = 10_000_000;
const SENSITIVE_QUERY = /(token|sign|cookie|authorization|password|secret|session|csrf|dynamicToken|webOpSessionId|uniqueItemCampaign)/i;
const RECORD_DB_NAME = "dmp-cdp-monitor-records";
const RECORD_DB_VERSION = 3;
const MODE_GROWTH = "growth";
const MODE_COMPETITION_SHOP = "competition-shop";
const VALID_MODES = new Set([MODE_GROWTH, MODE_COMPETITION_SHOP]);
const OFFICIAL_SITE = "https://shaozhuangai.com";
const CLOUD_RUNTIME_BASE = `${OFFICIAL_SITE}/api/dmp-runtime`;
const DEFAULT_AI_CONFIG = Object.freeze({ enabled: true, endpoint: `${CLOUD_RUNTIME_BASE}/report`, mode: "managed" });
const OFFICIAL_SESSION_COOKIE = "sanjie_session";
const OFFICIAL_AUTH_TIMEOUT_MS = 10_000;
const OFFICIAL_REPORT_SYNC_TIMEOUT_MS = 120_000;
const OFFICIAL_REPORT_SHARE_TIMEOUT_MS = 45_000;
const OFFICIAL_REPORT_SHARE_ATTEMPTS = 2;
const OFFICIAL_REPORT_RETRY_DELAY_MS = 1_000;
const OFFICIAL_AUTH_ALARM = "dmp-official-site-heartbeat";
let recordDbPromise;

function normalizeMode(value) {
  return VALID_MODES.has(value) ? value : MODE_GROWTH;
}

function tabModeStorageKey(tabId) {
  return `dmpUnifiedMode:${tabId}`;
}

async function setTabMode(tabId, value) {
  const mode = normalizeMode(value);
  tabModes.set(tabId, mode);
  await chrome.storage.local.set({ [tabModeStorageKey(tabId)]: mode });
  return mode;
}

async function getTabMode(tabId) {
  if (tabModes.has(tabId)) return tabModes.get(tabId);
  const stored = await chrome.storage.local.get(tabModeStorageKey(tabId));
  const mode = normalizeMode(stored?.[tabModeStorageKey(tabId)]);
  tabModes.set(tabId, mode);
  return mode;
}

function competitionSessionStorageKey(tabId) {
  return `competitionCaptureSession:${tabId}`;
}

async function saveCompetitionSession(tabId, session) {
  competitionSessions.set(tabId, session);
  await chrome.storage.local.set({ [competitionSessionStorageKey(tabId)]: session });
}

async function getCompetitionSession(tabId) {
  if (competitionSessions.has(tabId)) return competitionSessions.get(tabId);
  const stored = await chrome.storage.local.get(competitionSessionStorageKey(tabId));
  const session = stored?.[competitionSessionStorageKey(tabId)] || null;
  if (session) competitionSessions.set(tabId, session);
  return session;
}

async function readOfficialSession() {
  try {
    const cookies = await chrome.cookies.getAll({ name: OFFICIAL_SESSION_COOKIE, domain: "shaozhuangai.com" });
    cookies.sort((left, right) => String(left.domain || "").length - String(right.domain || "").length);
    return cookies.find(cookie => cookie.value)?.value || "";
  } catch {
    return "";
  }
}

async function checkOfficialSiteAccess() {
  const token = await readOfficialSession();
  if (!token) {
    return { ok: false, reason: "nologin", error: "请先登录 shaozhuangai.com，再使用达摩盘自动化" };
  }
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), OFFICIAL_AUTH_TIMEOUT_MS);
  try {
    const response = await fetch(`${OFFICIAL_SITE}/api/auth/me`, {
      method: "GET",
      headers: { "x-sanjie-session": token },
      cache: "no-store",
      signal: controller.signal
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok || !result?.data) {
      const error = response.status === 401
        ? "官网登录已失效，请重新登录 shaozhuangai.com"
        : `官网在线校验失败（HTTP ${response.status}）`;
      return { ok: false, reason: response.status === 401 ? "invalid" : "unavailable", error };
    }
    if (result.data.service?.online !== true || result.data.capabilities?.dmpAutomation !== true) {
      const entitlement = result.data.dmpEntitlement || null;
      const expired = entitlement?.status === "expired";
      return {
        ok: false,
        reason: expired ? "expired" : "denied",
        entitlement,
        error: expired
          ? "达摩盘自动化的 30 天授权已到期，请联系管理员付费续费"
          : "当前官网账号未开通达摩盘自动化权限，请联系管理员付费开通"
      };
    }
    return {
      ok: true,
      user: result.data,
      checkedAt: result.data.service?.checkedAt || new Date().toISOString()
    };
  } catch (error) {
    const timeoutMessage = error?.name === "AbortError" ? "官网在线校验超时" : "官网暂时不可达";
    return { ok: false, reason: "offline", error: `${timeoutMessage}，插件已停止运行` };
  } finally {
    clearTimeout(timeout);
  }
}

async function syncDmpReportToOfficialSite(payload) {
  const token = await readOfficialSession();
  if (!token) return { ok: false, error: "官网登录已失效，暂未保存到报告中心" };
  let response;
  try {
    response = await fetchWithTimeout(`${OFFICIAL_SITE}/api/dmp-reports`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-sanjie-session": token
      },
      cache: "no-store",
      body: JSON.stringify({
        report: payload?.report,
        subjectItemId: payload?.subjectItemId,
        competitorItemId: payload?.competitorItemId,
        quality: payload?.quality,
        reportType: payload?.reportType || payload?.report?.report_type || payload?.report?.reportType || MODE_GROWTH,
        sourceVersion: chrome.runtime.getManifest().version
      })
    }, OFFICIAL_REPORT_SYNC_TIMEOUT_MS);
  } catch (error) {
    if (error?.code === "REQUEST_TIMEOUT") {
      return {
        ok: false,
        error: "云端保存报告响应超时（已等待 120 秒）；报告可能已保存，请打开官网报告中心确认后再重试"
      };
    }
    throw error;
  }
  const result = await response.json().catch(() => ({}));
  if (!response.ok || !result?.data?.report?.id) {
    return { ok: false, error: result?.error || `报告中心暂时不可用（HTTP ${response.status}）` };
  }
  const reportId = result.data.report.id;
  const reportUrl = officialReportUrl(reportId);
  if (payload?.openReport === true) {
    try {
      const opened = await openOfficialReportWindow(reportId);
      return { ok: true, reportId, reportUrl, opened: true, windowId: opened.windowId, savedAt: result.data.report.createdAt };
    } catch (error) {
      return {
        ok: true,
        reportId,
        reportUrl,
        opened: false,
        openError: String(error?.message || error),
        savedAt: result.data.report.createdAt
      };
    }
  }
  return { ok: true, reportId, reportUrl, opened: false, savedAt: result.data.report.createdAt };
}

function officialReportUrl(reportId) {
  const url = new URL("/tools/dmp-report", OFFICIAL_SITE);
  url.searchParams.set("reportId", String(reportId || ""));
  url.searchParams.set("view", "report");
  return url.toString();
}

async function openOfficialReportWindow(reportId) {
  const id = String(reportId || "").trim();
  if (!id) throw new Error("缺少官网报告编号");
  const reportUrl = officialReportUrl(id);
  const created = await chrome.windows.create({ url: reportUrl, focused: true, type: "normal" });
  return { reportUrl, windowId: created?.id };
}

async function createDmpReportShare(payload) {
  const token = await readOfficialSession();
  if (!token) return { ok: false, error: "请先登录 shaozhuangai.com，再生成在线分享链接" };
  let lastError = null;
  for (let attempt = 1; attempt <= OFFICIAL_REPORT_SHARE_ATTEMPTS; attempt += 1) {
    try {
      const response = await fetchWithTimeout(`${OFFICIAL_SITE}/api/dmp-report-shares`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-sanjie-session": token
        },
        cache: "no-store",
        body: JSON.stringify({ reportId: String(payload?.reportId || "") })
      }, OFFICIAL_REPORT_SHARE_TIMEOUT_MS);
      const result = await response.json().catch(() => ({}));
      const share = result?.data?.share;
      const shareUrl = normalizeOfficialShareUrl(share?.url, OFFICIAL_SITE);
      if (response.ok && shareUrl) {
        return { ok: true, shareUrl, shareId: share.id, createdAt: share.createdAt };
      }
      lastError = new Error(result?.error || (response.ok
        ? "官网返回的分享地址无效，请稍后重新生成"
        : `分享链接暂时不可用（HTTP ${response.status}）`));
      if (![502, 503, 504].includes(response.status) || attempt >= OFFICIAL_REPORT_SHARE_ATTEMPTS) break;
    } catch (error) {
      lastError = error;
      if (!isRetryableOfficialWriteError(error) || attempt >= OFFICIAL_REPORT_SHARE_ATTEMPTS) break;
    }
    await waitForOfficialRetry(attempt);
  }
  const timeout = lastError?.code === "REQUEST_TIMEOUT";
  return {
    ok: false,
    error: timeout
      ? "在线分享链接生成超时，已自动重试 1 次，请稍后再试"
      : String(lastError?.message || lastError || "分享链接暂时不可用")
  };
}

function isRetryableOfficialWriteError(error) {
  return error?.code === "REQUEST_TIMEOUT" || error?.name === "TypeError";
}

function waitForOfficialRetry(attempt) {
  return new Promise(resolve => setTimeout(resolve, OFFICIAL_REPORT_RETRY_DELAY_MS * Math.max(1, attempt)));
}

async function lockTabForOfficialAuth(tabId, message) {
  if (activeTabs.has(tabId)) {
    await chrome.debugger.detach({ tabId }).catch(() => {});
    activeTabs.delete(tabId);
  }
  await chrome.action.setBadgeBackgroundColor({ tabId, color: "#8a2f2f" }).catch(() => {});
  await chrome.action.setBadgeText({ tabId, text: "LOCK" }).catch(() => {});
  await publishStatus(tabId, false, message);
}

async function verifyOfficialSiteForTab(tabId) {
  const authorization = await checkOfficialSiteAccess();
  if (authorization.ok) return authorization;
  await lockTabForOfficialAuth(tabId, authorization.error || "官网在线校验失败");
  throw new Error(authorization.error || "官网在线校验失败");
}

async function getAiConfig() {
  return { ...DEFAULT_AI_CONFIG };
}

function cloudRuntimeUrl(action) {
  const name = String(action || "").replace(/^\/+/, "");
  if (!/^(health|analyze|report)$/.test(name)) throw new Error("云端服务路径无效");
  return `${CLOUD_RUNTIME_BASE}/${name}`;
}

async function fetchWithTimeout(url, options = {}, timeoutMs = 90_000) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try { return await fetch(url, { ...options, signal: controller.signal }); }
  catch (error) {
    if (error?.name === "AbortError") {
      const timeoutError = new Error("云端服务请求超时");
      timeoutError.code = "REQUEST_TIMEOUT";
      throw timeoutError;
    }
    throw error;
  } finally { clearTimeout(timeout); }
}

async function cloudRequestHeaders(json = false) {
  const token = await readOfficialSession();
  if (!token) throw new Error("请先登录 shaozhuangai.com");
  return {
    ...(json ? { "Content-Type": "application/json" } : {}),
    "x-sanjie-session": token
  };
}

async function aiHealth() {
  const response = await fetchWithTimeout(cloudRuntimeUrl("health"), {
    method: "GET",
    headers: await cloudRequestHeaders(),
    cache: "no-store"
  }, 10_000);
  const health = await response.json().catch(() => ({}));
  if (!response.ok || !health.ok) throw new Error(health.error || `云端服务返回 ${response.status}`);
  return health;
}

// 深度解析把插件采集批次和本地报告送到已授权的官网云端。
async function analyzeWithCloudService(payload, report) {
  const response = await fetchWithTimeout(cloudRuntimeUrl("analyze"), {
    method: "POST",
    headers: await cloudRequestHeaders(true),
    cache: "no-store",
    body: JSON.stringify({ payload, report })
  }, 200_000);
  const result = await response.json().catch(() => ({}));
  // 四类错误码（NO_JSON/PARSE_FAILED/CALC_FAILED/API_FAILED）要原样带回给页面，
  // 不能压成一句话——页面要据此显示"没获取到 JSON/解析失败/计算错误/API 失败"。
  if (!response.ok || !result.ok) {
    return {
      ok: false,
      code: result.code || "API_FAILED",
      error: result.error || `云端深度解析返回 ${response.status}`,
      detail: result.detail || {}
    };
  }
  return result;
}

async function generateAiReport(report) {
  const localValidation = globalThis.DmpReportEngine?.validateCanonicalReport(report);
  if (!localValidation?.ok) throw new Error(localValidation?.error || "本地标准报告校验失败");
  const response = await fetchWithTimeout(cloudRuntimeUrl("report"), {
    method: "POST",
    headers: await cloudRequestHeaders(true),
    cache: "no-store",
    body: JSON.stringify({ report })
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok || !result.ok) throw new Error(result.error || `云端报告服务返回 ${response.status}`);
  if (JSON.stringify(result.report) !== JSON.stringify(report)) throw new Error("端口返回报告与本地数据不一致，已拒绝采用");
  const returnedValidation = globalThis.DmpReportEngine?.validateCanonicalReport(result.report);
  if (!returnedValidation?.ok) throw new Error(returnedValidation?.error || "端口返回报告结构无效");
  return result;
}

function openRecordDb() {
  if (recordDbPromise) return recordDbPromise;
  recordDbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(RECORD_DB_NAME, RECORD_DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      const store = db.objectStoreNames.contains("records")
        ? request.transaction.objectStore("records")
        : db.createObjectStore("records", { keyPath: "id", autoIncrement: true });
      if (!store.indexNames.contains("byTabId")) store.createIndex("byTabId", "tabId", { unique: false });
      if (!store.indexNames.contains("byCapturedAt")) store.createIndex("byCapturedAt", "capturedAt", { unique: false });
      if (!store.indexNames.contains("byTabIdCapturedAt")) {
        store.createIndex("byTabIdCapturedAt", ["tabId", "capturedAt"], { unique: false });
      }
      if (!store.indexNames.contains("byTabMode")) store.createIndex("byTabMode", ["tabId", "mode"], { unique: false });
      if (!store.indexNames.contains("byTabModeCapturedAt")) {
        store.createIndex("byTabModeCapturedAt", ["tabId", "mode", "capturedAt"], { unique: false });
      }
      if (!db.objectStoreNames.contains("jobs")) {
        db.createObjectStore("jobs", { keyPath: "tabId" });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("无法打开本地数据存储"));
  });
  return recordDbPromise;
}

async function persistRecord(tabId, record, requestedMode = "") {
  const mode = requestedMode ? normalizeMode(requestedMode) : await getTabMode(tabId);
  const session = mode === MODE_COMPETITION_SHOP ? await getCompetitionSession(tabId) : null;
  const taggedRecord = {
    ...record,
    captureMode: mode,
    runId: record?.runId || session?.id || "",
  };
  const db = await openRecordDb();
  await new Promise((resolve, reject) => {
    const tx = db.transaction("records", "readwrite");
    tx.objectStore("records").add({
      tabId,
      mode,
      runId: taggedRecord.runId,
      capturedAt: taggedRecord.capturedAt || new Date().toISOString(),
      record: taggedRecord,
    });
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error || new Error("本地数据写入失败"));
    tx.onabort = () => reject(tx.error || new Error("本地数据写入中止"));
  });
  return taggedRecord;
}

async function getPersistedRecords(tabId, since = "", requestedMode = "") {
  const mode = requestedMode ? normalizeMode(requestedMode) : "";
  const db = await openRecordDb();
  return await new Promise((resolve, reject) => {
    const tx = db.transaction("records", "readonly");
    const store = tx.objectStore("records");
    let request;
    if (mode && since && store.indexNames.contains("byTabModeCapturedAt")) {
      request = store.index("byTabModeCapturedAt").getAll(IDBKeyRange.bound([tabId, mode, since], [tabId, mode, "\uffff"]));
    } else if (mode && store.indexNames.contains("byTabMode")) {
      request = store.index("byTabMode").getAll(IDBKeyRange.only([tabId, mode]));
    } else if (since && store.indexNames.contains("byTabIdCapturedAt")) {
      request = store.index("byTabIdCapturedAt").getAll(IDBKeyRange.bound([tabId, since], [tabId, "\uffff"]));
    } else {
      request = store.index("byTabId").getAll(tabId);
    }
    request.onsuccess = () => resolve(request.result
      .filter(item => !mode || normalizeMode(item.mode || item.record?.captureMode) === mode)
      .map(item => item.record));
    request.onerror = () => reject(request.error || new Error("本地数据读取失败"));
  });
}

async function saveJob(tabId, job) {
  const db = await openRecordDb();
  await new Promise((resolve, reject) => {
    const tx = db.transaction("jobs", "readwrite");
    tx.objectStore("jobs").put({ tabId, updatedAt: new Date().toISOString(), job });
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error || new Error("报告任务保存失败"));
    tx.onabort = () => reject(tx.error || new Error("报告任务保存中止"));
  });
}

async function getJob(tabId) {
  const db = await openRecordDb();
  return await new Promise((resolve, reject) => {
    const tx = db.transaction("jobs", "readonly");
    const request = tx.objectStore("jobs").get(tabId);
    request.onsuccess = () => resolve(request.result?.job || null);
    request.onerror = () => reject(request.error || new Error("报告任务读取失败"));
  });
}

async function deleteJob(tabId) {
  const db = await openRecordDb();
  await new Promise((resolve, reject) => {
    const tx = db.transaction("jobs", "readwrite");
    tx.objectStore("jobs").delete(tabId);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error || new Error("报告任务删除失败"));
    tx.onabort = () => reject(tx.error || new Error("报告任务删除中止"));
  });
}

async function clearPersistedRecords(tabId, requestedMode = "") {
  const mode = requestedMode ? normalizeMode(requestedMode) : "";
  const db = await openRecordDb();
  await new Promise((resolve, reject) => {
    const tx = db.transaction("records", "readwrite");
    const store = tx.objectStore("records");
    const request = store.index("byTabId").openCursor(IDBKeyRange.only(tabId));
    request.onsuccess = () => {
      const cursor = request.result;
      if (!cursor) return;
      const itemMode = normalizeMode(cursor.value?.mode || cursor.value?.record?.captureMode);
      if (!mode || itemMode === mode) cursor.delete();
      cursor.continue();
    };
    request.onerror = () => reject(request.error || new Error("本地数据清单读取失败"));
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error || new Error("本地数据清空失败"));
    tx.onabort = () => reject(tx.error || new Error("本地数据清空中止"));
  });
}

function canonicalRecordPath(record) {
  let value = String(record?.pathname || "");
  if (!value) {
    try { value = new URL(record?.url || "").pathname; } catch { value = String(record?.url || "").split("?")[0]; }
  }
  return value.replace(/^\/api_2\//, "/api/").replace(/\.json$/, "").replace(/\/+$/, "");
}

async function clearPersistedRecordPaths(tabId, paths, requestedMode = "") {
  const mode = requestedMode ? normalizeMode(requestedMode) : "";
  const wanted = new Set((paths || []).map(path => canonicalRecordPath({ pathname: path })).filter(Boolean));
  if (!wanted.size) return 0;
  const db = await openRecordDb();
  return await new Promise((resolve, reject) => {
    const tx = db.transaction("records", "readwrite");
    const request = tx.objectStore("records").index("byTabId").openCursor(IDBKeyRange.only(tabId));
    let deleted = 0;
    request.onsuccess = () => {
      const cursor = request.result;
      if (!cursor) return;
      const itemMode = normalizeMode(cursor.value?.mode || cursor.value?.record?.captureMode);
      if ((!mode || itemMode === mode) && wanted.has(canonicalRecordPath(cursor.value?.record))) {
        cursor.delete();
        deleted += 1;
      }
      cursor.continue();
    };
    request.onerror = () => reject(request.error || new Error("本地数据筛选失败"));
    tx.oncomplete = () => resolve(deleted);
    tx.onerror = () => reject(tx.error || new Error("本地数据局部清理失败"));
    tx.onabort = () => reject(tx.error || new Error("本地数据局部清理中止"));
  });
}

function storedRecordIdentity(record) {
  return [record?.requestId, record?.capturedAt, record?.kind, record?.source, record?.pathname || record?.url].join("|");
}

async function clearPersistedRecordIds(tabId, identities, requestedMode = "") {
  const mode = requestedMode ? normalizeMode(requestedMode) : "";
  const wanted = new Set((identities || []).map(String).filter(Boolean));
  if (!wanted.size) return 0;
  const db = await openRecordDb();
  return await new Promise((resolve, reject) => {
    const tx = db.transaction("records", "readwrite");
    const request = tx.objectStore("records").index("byTabId").openCursor(IDBKeyRange.only(tabId));
    let deleted = 0;
    request.onsuccess = () => {
      const cursor = request.result;
      if (!cursor) return;
      const itemMode = normalizeMode(cursor.value?.mode || cursor.value?.record?.captureMode);
      if ((!mode || itemMode === mode) && wanted.has(storedRecordIdentity(cursor.value?.record))) {
        cursor.delete();
        deleted += 1;
      }
      cursor.continue();
    };
    request.onerror = () => reject(request.error || new Error("本地数据筛选失败"));
    tx.oncomplete = () => resolve(deleted);
    tx.onerror = () => reject(tx.error || new Error("本地数据局部清理失败"));
    tx.onabort = () => reject(tx.error || new Error("本地数据局部清理中止"));
  });
}

function clearTabNetworkState(tabId) {
  const prefix = `${tabId}:`;
  for (const map of [requests, sockets, transports]) {
    for (const key of map.keys()) if (String(key).startsWith(prefix)) map.delete(key);
  }
  observedResponses.delete(tabId);
  capturedResponses.delete(tabId);
}

function sourceKey(source) {
  return `${source.tabId}:${source.sessionId || "root"}`;
}

function requestKey(source, requestId) {
  return `${sourceKey(source)}:${requestId}`;
}

function safeUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    for (const key of [...url.searchParams.keys()]) {
      if (SENSITIVE_QUERY.test(key)) url.searchParams.set(key, "[REDACTED]");
    }
    return url.toString();
  } catch {
    return rawUrl;
  }
}

function sanitizeStoredRecord(record) {
  const value = record && typeof record === "object" ? JSON.parse(JSON.stringify(record)) : {};
  value.url = safeUrl(value.url || "");
  value.documentUrl = safeUrl(value.documentUrl || "");
  if (typeof value.requestBody === "string") value.requestBody = sanitizedPayload(value.requestBody, value.requestFormat || bodyFormat(value.requestBody, value.requestMimeType || ""));
  delete value.requestHeaders;
  delete value.responseHeaders;
  return value;
}

function urlSummary(rawUrl) {
  try {
    const url = new URL(rawUrl);
    return {
      origin: url.origin,
      pathname: url.pathname,
      queryKeys: [...new Set([...url.searchParams.keys()])]
    };
  } catch {
    return { origin: "", pathname: rawUrl || "", queryKeys: [] };
  }
}

function bodyFormat(text, mimeType = "") {
  const value = text.trim();
  if (!value) return "empty";
  try {
    JSON.parse(value);
    return "json";
  } catch {}

  const match = value.match(/^[\w$.[\]]+\s*\(([\s\S]*)\)\s*;?\s*$/);
  if (match) {
    try {
      JSON.parse(match[1]);
      return "jsonp";
    } catch {}
  }

  const mime = mimeType.toLowerCase();
  if (mime.includes("x-www-form-urlencoded") || /^[^=&\s]+=[\s\S]*(?:&[^=&\s]+=|$)/.test(value)) return "form";
  if (mime.includes("html") || /^<!doctype\s+html|^<html[\s>]/i.test(value)) return "html";
  if (mime.includes("xml") || /^<\?xml\s|^<[\w:-]+[\s>]/.test(value)) return "xml";
  if (mime.includes("css")) return "css";
  if (mime.includes("javascript") || mime.includes("ecmascript")) return "javascript";
  return "text";
}

function payloadKeySummary(text, format) {
  try {
    let value = text.trim();
    if (format === "jsonp") {
      const match = value.match(/^[\w$.[\]]+\s*\(([\s\S]*)\)\s*;?\s*$/);
      if (!match) return [];
      value = match[1];
    }

    if (format === "form") {
      return [`form: ${[...new Set([...new URLSearchParams(value).keys()])].slice(0, 50).join(", ")}`];
    }

    const parsed = JSON.parse(value);
    if (Array.isArray(parsed)) {
      const result = [`array: ${parsed.length}`];
      if (parsed[0] && typeof parsed[0] === "object" && !Array.isArray(parsed[0])) {
        result.push(`item: ${Object.keys(parsed[0]).slice(0, 50).join(", ")}`);
      }
      return result;
    }
    if (!parsed || typeof parsed !== "object") return [`root: ${typeof parsed}`];

    const result = [`root: ${Object.keys(parsed).slice(0, 50).join(", ")}`];
    for (const key of ["data", "result", "model", "pageInfo", "page"]) {
      const child = parsed[key];
      if (child && typeof child === "object" && !Array.isArray(child)) {
        result.push(`${key}: ${Object.keys(child).slice(0, 50).join(", ")}`);
      }
    }
    return result;
  } catch {
    return [];
  }
}

function redactJsonValue(value) {
  if (Array.isArray(value)) return value.map(redactJsonValue);
  if (!value || typeof value !== "object") return value;
  return Object.fromEntries(Object.entries(value).map(([key, child]) => [
    key,
    SENSITIVE_QUERY.test(key) ? "[REDACTED]" : redactJsonValue(child)
  ]));
}

function sanitizedPayload(postData, format) {
  try {
    if (format === "json") return JSON.stringify(redactJsonValue(JSON.parse(postData)));
    if (format === "jsonp") {
      const match = postData.trim().match(/^([\w$.[\]]+\s*\()([\s\S]*)(\)\s*;?\s*)$/);
      if (match) return `${match[1]}${JSON.stringify(redactJsonValue(JSON.parse(match[2])))}${match[3]}`;
    }
    if (format === "form") {
      const params = new URLSearchParams(postData);
      for (const key of [...params.keys()]) {
        if (SENSITIVE_QUERY.test(key)) params.set(key, "[REDACTED]");
      }
      return params.toString();
    }
  } catch {}
  return postData;
}

function requestPayload(postData, mimeType = "") {
  if (typeof postData !== "string") {
    return { requestBodyLength: 0, requestBodyTruncated: false, requestFormat: "empty", requestKeys: [], requestBody: "" };
  }
  const format = bodyFormat(postData, mimeType);
  const safeBody = sanitizedPayload(postData, format);
  return {
    requestBodyLength: postData.length,
    requestBodyTruncated: safeBody.length > BODY_LIMIT,
    requestFormat: format,
    requestKeys: payloadKeySummary(safeBody, format),
    requestBody: safeBody.slice(0, BODY_LIMIT)
  };
}

function decodeBase64Utf8(base64) {
  const binary = atob(base64);
  const bytes = Uint8Array.from(binary, char => char.charCodeAt(0));
  return new TextDecoder("utf-8").decode(bytes);
}

function networkRecord(meta, extra = {}) {
  return {
    capturedAt: new Date().toISOString(),
    requestId: meta.requestId,
    url: meta.url,
    origin: meta.origin,
    pathname: meta.pathname,
    queryKeys: meta.queryKeys || [],
    method: meta.method,
    type: meta.type || "Other",
    initiatorType: meta.initiatorType,
    documentUrl: meta.documentUrl,
    requestBodyLength: meta.requestBodyLength || 0,
    requestBodyTruncated: Boolean(meta.requestBodyTruncated),
    requestBodyAvailable: Boolean(meta.requestBodyAvailable),
    requestBodyError: meta.requestBodyError || "",
    requestMimeType: meta.requestMimeType || "",
    requestFormat: meta.requestFormat || "empty",
    requestKeys: meta.requestKeys || [],
    requestBody: meta.requestBody || "",
    status: meta.status,
    statusText: meta.statusText,
    mimeType: meta.mimeType || "",
    protocol: meta.protocol || "",
    fromDiskCache: Boolean(meta.fromDiskCache),
    fromServiceWorker: Boolean(meta.fromServiceWorker),
    ...extra
  };
}

async function publish(tabId, record) {
  try {
    const type = record?.captureMode === MODE_COMPETITION_SHOP ? "COMP_SITUATION_STATUS" : "DMP_CDP_RECORD";
    const payload = type === "COMP_SITUATION_STATUS"
      ? { type, active: true, record }
      : { type, record };
    await chrome.tabs.sendMessage(tabId, payload);
  } catch {}
}

async function publishRecord(tabId, record) {
  const mode = await getTabMode(tabId);
  if (mode === MODE_COMPETITION_SHOP) {
    const session = await getCompetitionSession(tabId);
    if (!session?.active) return null;
  }
  let storedRecord = record;
  try {
    storedRecord = await persistRecord(tabId, record, mode);
  } catch (error) {
    await publishStatus(tabId, true, `本地数据保存失败：${String(error.message || error)}`);
  }
  await publish(tabId, storedRecord);
  return storedRecord;
}

async function publishStatus(tabId, active, message) {
  try {
    const mode = await getTabMode(tabId);
    await chrome.tabs.sendMessage(tabId, {
      type: mode === MODE_COMPETITION_SHOP ? "COMP_SITUATION_STATUS" : "DMP_CDP_STATUS",
      active,
      message
    });
  } catch {}
}

async function enableTarget(session) {
  await chrome.debugger.sendCommand(session, "Network.enable", {
    maxTotalBufferSize: 500 * 1024 * 1024,
    maxResourceBufferSize: 50 * 1024 * 1024,
    maxPostDataSize: BODY_LIMIT
  });

  // 除 Network 外，打开会产生页面数据或运行时信号的 CDP 域。
  // 这些事件只采集当前页/当前调试目标，不读取 Cookie、Authorization 或 token 值。
  // DOM 是 Input.dispatchMouseEvent 的前置依赖（页签切换需要派发可信点击）。
  for (const domain of ["Runtime", "Performance", "DOMStorage", "Page", "DOM"]) {
    await chrome.debugger.sendCommand(session, `${domain}.enable`).catch(() => {});
  }

  try {
    await chrome.debugger.sendCommand(session, "Target.setAutoAttach", {
      autoAttach: true,
      waitForDebuggerOnStart: false,
      flatten: true,
      filter: [
        { type: "iframe", exclude: false },
        { type: "worker", exclude: false },
        { type: "shared_worker", exclude: false },
        { type: "service_worker", exclude: false }
      ]
    });
  } catch {}

  // 快照只是内部核验用的辅助信息，不要阻塞 attach 返回——
  // 调用方拿到 ok 之后会立刻触发路由并发出业务请求，attach 越快返回越不容易丢请求。
  void publishRuntimeSnapshot(session).catch(() => {});
}

function summarizeRemoteObject(object) {
  if (!object) return null;
  const value = object.value;
  if (value === undefined) return object.description || object.unserializableValue || object.type || null;
  if (typeof value === "string") return value.slice(0, BODY_LIMIT);
  if (typeof value === "number" || typeof value === "boolean") return value;
  try { return JSON.parse(JSON.stringify(value)); } catch { return String(value); }
}

async function publishRuntimeSnapshot(session) {
  const expression = `(() => {
    const safeResource = url => { try { const u = new URL(url, location.href); return u.origin + u.pathname; } catch { return String(url || '').split('?')[0]; } };
    return {
      title: document.title,
      url: location.origin + location.pathname,
      readyState: document.readyState,
      visibilityState: document.visibilityState,
      resourceEntries: performance.getEntriesByType('resource').slice(-200).map(x => ({name: safeResource(x.name), initiatorType: x.initiatorType, duration: x.duration, transferSize: x.transferSize})),
      localStorageKeys: Object.keys(localStorage),
      sessionStorageKeys: Object.keys(sessionStorage),
      indexedDB: indexedDB && indexedDB.databases ? 'available' : 'unavailable'
    };
  })()`;
  const result = await chrome.debugger.sendCommand(session, "Runtime.evaluate", { expression, returnByValue: true, awaitPromise: true });
  const value = result?.result?.value;
  if (!value) return;
  await publishRecord(session.tabId, { capturedAt: new Date().toISOString(), kind: "RuntimeSnapshot", source: "Runtime.evaluate", url: value.url, type: "Runtime", status: "snapshot", bodyLength: JSON.stringify(value).length, truncated: false, format: "json", responseKeys: Object.keys(value), body: JSON.stringify(value) });
}

async function markActive(tabId, message = "数据通道已就绪，请刷新或操作页面") {
  await chrome.action.setBadgeBackgroundColor({ tabId, color: "#16803c" });
  await chrome.action.setBadgeText({ tabId, text: "ON" });
  await publishStatus(tabId, true, message);
}

function attachErrorMessage(error) {
  const detail = String(error);
  if (/another debugger|already attached|cannot attach/i.test(detail)) {
    return "数据通道不可用，请刷新达摩盘页面后重试";
  }
  return "数据通道初始化失败，请刷新页面后重试";
}

async function attachImpl(tabId) {
  if (activeTabs.has(tabId)) {
    try {
      await enableTarget({ tabId });
      await markActive(tabId, "数据通道已就绪，请刷新或操作页面");
      return;
    } catch {
      activeTabs.delete(tabId);
    }
  }

  // Service Worker 被 Chrome 唤醒后内存状态会重置；先尝试恢复已有调试会话。
  try {
    await enableTarget({ tabId });
    activeTabs.add(tabId);
    await markActive(tabId, "数据通道已恢复，请刷新或操作页面");
    return;
  } catch {}

  try {
    await chrome.debugger.attach({ tabId }, "1.3");
    await enableTarget({ tabId });
  } catch (error) {
    const message = attachErrorMessage(error);
    await chrome.action.setBadgeBackgroundColor({ tabId, color: "#b42318" });
    await chrome.action.setBadgeText({ tabId, text: "ERR" });
    await publishStatus(tabId, false, message);
    throw new Error(message);
  }

  activeTabs.add(tabId);
  await markActive(tabId);
}

async function attach(tabId) {
  const current = attachJobs.get(tabId);
  if (current) return current;

  const job = verifyOfficialSiteForTab(tabId)
    .then(() => attachImpl(tabId))
    .finally(() => attachJobs.delete(tabId));
  attachJobs.set(tabId, job);
  return job;
}

async function detach(tabId) {
  try {
    await chrome.debugger.detach({ tabId });
  } catch {}
  activeTabs.delete(tabId);
  await chrome.action.setBadgeText({ tabId, text: "" });
  await publishStatus(tabId, false, "数据通道已停止");
}

async function reconnect(tabId) {
  await detach(tabId);
  await attach(tabId);
}

function headerValue(headers, wantedName) {
  const entry = Object.entries(headers || {}).find(([name]) => name.toLowerCase() === wantedName.toLowerCase());
  return entry ? String(entry[1]) : "";
}

function requestMetaFromEvent(params) {
  const rawUrl = params.request?.url || "";
  const summary = urlSummary(rawUrl);
  const requestMimeType = headerValue(params.request?.headers, "content-type");
  const payload = requestPayload(params.request?.postData, requestMimeType);
  return {
    requestId: params.requestId,
    rawUrl,
    url: safeUrl(rawUrl),
    ...summary,
    method: params.request?.method || "",
    type: params.type || "Other",
    initiatorType: params.initiator?.type,
    documentUrl: safeUrl(params.documentURL || ""),
    requestMimeType,
    requestBodyAvailable: typeof params.request?.postData === "string",
    hasPostData: Boolean(params.request?.hasPostData),
    ...payload
  };
}

async function ensureRequestPostData(source, meta) {
  if (!meta.hasPostData || meta.requestBodyAvailable) return;
  try {
    const result = await chrome.debugger.sendCommand(source, "Network.getRequestPostData", { requestId: meta.requestId });
    Object.assign(meta, requestPayload(result.postData, meta.requestMimeType), { requestBodyAvailable: true });
  } catch (error) {
    meta.requestBodyError = String(error);
  }
}

async function publishNetworkRecord(tabId, record) {
  const storedRecord = await publishRecord(tabId, record);
  if (!storedRecord) return;
  const captured = (capturedResponses.get(tabId) || 0) + 1;
  capturedResponses.set(tabId, captured);
  await publishStatus(tabId, true, "数据通道运行中");
}

async function handleFinished(source, params) {
  const key = requestKey(source, params.requestId);
  const meta = requests.get(key) || {
    requestId: params.requestId,
    url: "",
    origin: "",
    pathname: "",
    queryKeys: [],
    type: "Other"
  };

  try {
    await ensureRequestPostData(source, meta);

    const response = await chrome.debugger.sendCommand(
      source,
      "Network.getResponseBody",
      { requestId: params.requestId }
    );

    const isTextBody = !response.base64Encoded || /(json|javascript|ecmascript|text|xml|html|css|svg)/i.test(meta.mimeType || "");
    const fullBody = response.base64Encoded && isTextBody
      ? decodeBase64Utf8(response.body)
      : response.body || "";
    const format = response.base64Encoded && !isTextBody
      ? "binary-base64"
      : bodyFormat(fullBody, meta.mimeType);

    await publishNetworkRecord(source.tabId, networkRecord(meta, {
      encodedDataLength: params.encodedDataLength,
      bodyAvailable: true,
      bodyEncoding: response.base64Encoded ? (isTextBody ? "base64-decoded-utf8" : "base64") : "utf8",
      bodyLength: fullBody.length,
      truncated: fullBody.length > BODY_LIMIT,
      format,
      responseKeys: payloadKeySummary(fullBody, format),
      body: fullBody.slice(0, BODY_LIMIT)
    }));
  } catch (error) {
    await publishNetworkRecord(source.tabId, networkRecord(meta, {
      encodedDataLength: params.encodedDataLength,
      bodyAvailable: false,
      bodyLength: 0,
      truncated: false,
      format: "unavailable",
      responseKeys: [],
      body: "",
      responseBodyError: String(error)
    }));
  } finally {
    requests.delete(key);
  }
}

async function handleEvent(source, method, params) {
  if (method === "Target.attachedToTarget") {
    await enableTarget({ tabId: source.tabId, sessionId: params.sessionId });
    return;
  }

  if (method === "Network.requestWillBeSent") {
    const key = requestKey(source, params.requestId);
    const previous = requests.get(key);
    const current = requestMetaFromEvent(params);
    requests.set(key, current);

    if (params.redirectResponse) {
      const response = params.redirectResponse;
      const rawUrl = response.url || previous?.rawUrl || "";
      const redirectedMeta = {
        ...(previous || {}),
        requestId: params.requestId,
        rawUrl,
        url: safeUrl(rawUrl),
        ...urlSummary(rawUrl),
        status: response.status,
        statusText: response.statusText,
        mimeType: response.mimeType,
        protocol: response.protocol,
        fromDiskCache: response.fromDiskCache,
        fromServiceWorker: response.fromServiceWorker
      };
      await publishNetworkRecord(source.tabId, networkRecord(redirectedMeta, {
        redirect: true,
        redirectTo: current.url,
        bodyAvailable: false,
        bodyLength: 0,
        truncated: false,
        format: "redirect",
        responseKeys: [],
        body: "",
        responseBodyError: "CDP 不提供跳转中间响应体"
      }));
    }
    return;
  }

  if (method === "Network.responseReceived") {
    const key = requestKey(source, params.requestId);
    const current = requests.get(key) || { requestId: params.requestId };
    const rawUrl = params.response.url || current.rawUrl || "";
    requests.set(key, {
      ...current,
      rawUrl,
      url: safeUrl(rawUrl),
      ...urlSummary(rawUrl),
      type: params.type || current.type,
      status: params.response.status,
      statusText: params.response.statusText,
      mimeType: params.response.mimeType,
      protocol: params.response.protocol,
      fromDiskCache: params.response.fromDiskCache,
      fromServiceWorker: params.response.fromServiceWorker
    });

    const observed = (observedResponses.get(source.tabId) || 0) + 1;
    observedResponses.set(source.tabId, observed);
    if (observed <= 3 || observed % 25 === 0) {
      await publishStatus(
        source.tabId,
        true,
        "数据通道运行中"
      );
    }
    return;
  }

  if (method === "Network.loadingFinished") {
    await handleFinished(source, params);
    return;
  }

  if (method === "Network.loadingFailed") {
    const key = requestKey(source, params.requestId);
    const meta = requests.get(key) || { requestId: params.requestId, url: "", type: params.type || "Other" };
    await ensureRequestPostData(source, meta);
    await publishNetworkRecord(source.tabId, networkRecord(meta, {
      failed: true,
      canceled: Boolean(params.canceled),
      blockedReason: params.blockedReason || "",
      corsErrorStatus: params.corsErrorStatus || null,
      bodyAvailable: false,
      bodyLength: 0,
      truncated: false,
      format: "failed",
      responseKeys: [],
      body: "",
      responseBodyError: params.errorText || "Network.loadingFailed"
    }));
    requests.delete(key);
    return;
  }

  if (method === "Runtime.consoleAPICalled") {
    return;
  }

  if (method === "Runtime.exceptionThrown") {
    return;
  }

  if (method === "Log.entryAdded" || method === "Console.messageAdded") {
    return;
  }

  if (method === "Performance.metrics") {
    await publishRecord(source.tabId, { capturedAt: new Date().toISOString(), kind: "Performance", source: "Performance.metrics", url: "", bodyLength: JSON.stringify(params).length, truncated: false, format: "json", responseKeys: ["metrics"], body: JSON.stringify(params) });
    return;
  }

  if (method === "DOMStorage.domStorageItemAdded" || method === "DOMStorage.domStorageItemUpdated" || method === "DOMStorage.domStorageItemRemoved" || method === "DOMStorage.domStorageItemsCleared") {
    const storageId = params.storageId || {};
    await publishRecord(source.tabId, { capturedAt: new Date().toISOString(), kind: "DOMStorage", source: method, storageType: storageId.isLocalStorage ? "localStorage" : "sessionStorage", securityOrigin: storageId.securityOrigin || "", key: params.key || "", oldValue: params.oldValue == null ? null : "[VALUE_REDACTED]", newValue: params.newValue == null ? null : "[VALUE_REDACTED]", bodyLength: JSON.stringify(params).length, truncated: false, format: "json", responseKeys: [], body: JSON.stringify({key: params.key, value: "[VALUE_REDACTED]", event: method}) });
    return;
  }

  if (method === "Page.frameNavigated") {
    const frame = params.frame || {};
    await publishRecord(source.tabId, { capturedAt: new Date().toISOString(), kind: "PageState", source: "Page.frameNavigated", url: safeUrl(frame.url || ""), frameId: frame.id, securityOrigin: frame.securityOrigin, mimeType: frame.mimeType, bodyLength: JSON.stringify(frame).length, truncated: false, format: "json", responseKeys: [], body: JSON.stringify({id: frame.id, url: safeUrl(frame.url || ""), securityOrigin: frame.securityOrigin, mimeType: frame.mimeType}) });
    return;
  }

  if (method === "Network.webSocketCreated") {
    const summary = urlSummary(params.url || "");
    sockets.set(requestKey(source, params.requestId), {
      requestId: params.requestId,
      rawUrl: params.url,
      url: safeUrl(params.url),
      ...summary,
      method: "GET",
      type: "WebSocket",
      initiatorType: params.initiator?.type,
      requestFormat: "empty",
      requestKeys: [],
      requestBody: "",
      requestBodyAvailable: true
    });
    return;
  }

  if (method === "Network.webSocketWillSendHandshakeRequest") {
    const key = requestKey(source, params.requestId);
    const socket = sockets.get(key) || { requestId: params.requestId, type: "WebSocket", method: "GET" };
    sockets.set(key, socket);
    return;
  }

  if (method === "Network.webSocketHandshakeResponseReceived") {
    const key = requestKey(source, params.requestId);
    const socket = sockets.get(key) || { requestId: params.requestId, url: "", type: "WebSocket", method: "GET" };
    socket.status = params.response?.status;
    socket.statusText = params.response?.statusText;
    socket.protocol = "websocket";
    await publishNetworkRecord(source.tabId, networkRecord(socket, {
      bodyAvailable: false,
      bodyLength: 0,
      truncated: false,
      format: "websocket-handshake",
      responseKeys: [],
      body: "",
      responseBodyError: "WebSocket 握手没有普通 HTTP 响应体"
    }));
    return;
  }

  if (method === "Network.webSocketFrameReceived" || method === "Network.webSocketFrameSent") {
    const socket = sockets.get(requestKey(source, params.requestId));
    if (!socket) return;
    const payload = params.response.payloadData || "";
    const format = params.response.opcode === 1 ? bodyFormat(payload) : "binary-websocket";
    await publishRecord(source.tabId, {
      capturedAt: new Date().toISOString(),
      requestId: params.requestId,
      kind: "WebSocket",
      source: method,
      direction: method.endsWith("Sent") ? "sent" : "received",
      url: socket.url,
      type: "WebSocket",
      opcode: params.response.opcode,
      bodyLength: payload.length,
      truncated: payload.length > BODY_LIMIT,
      format,
      responseKeys: payloadKeySummary(payload, format),
      body: payload.slice(0, BODY_LIMIT)
    });
    return;
  }

  if (method === "Network.webSocketFrameError") {
    const socket = sockets.get(requestKey(source, params.requestId)) || {};
    await publishRecord(source.tabId, {
      capturedAt: new Date().toISOString(),
      requestId: params.requestId,
      kind: "WebSocketError",
      source: method,
      url: socket.url || "",
      type: "WebSocket",
      error: params.errorMessage || "WebSocket frame error"
    });
    return;
  }

  if (method === "Network.webSocketClosed") {
    sockets.delete(requestKey(source, params.requestId));
    return;
  }

  if (method === "Network.eventSourceMessageReceived") {
    const meta = requests.get(requestKey(source, params.requestId)) || {};
    const payload = params.data || "";
    const format = bodyFormat(payload);
    await publishRecord(source.tabId, {
      capturedAt: new Date().toISOString(),
      requestId: params.requestId,
      kind: "EventSourceMessage",
      source: method,
      url: meta.url || "",
      type: "EventSource",
      eventName: params.eventName || "message",
      eventId: params.eventId || "",
      bodyLength: payload.length,
      truncated: payload.length > BODY_LIMIT,
      format,
      responseKeys: payloadKeySummary(payload, format),
      body: payload.slice(0, BODY_LIMIT)
    });
    return;
  }

  if (method === "Network.webTransportCreated") {
    const summary = urlSummary(params.url || "");
    transports.set(requestKey(source, params.transportId), {
      requestId: params.transportId,
      rawUrl: params.url || "",
      url: safeUrl(params.url || ""),
      ...summary,
      method: "CONNECT",
      type: "WebTransport",
      requestBodyAvailable: true
    });
    return;
  }

  if (method === "Network.webTransportConnectionEstablished") {
    const transport = transports.get(requestKey(source, params.transportId)) || {
      requestId: params.transportId,
      url: "",
      method: "CONNECT",
      type: "WebTransport"
    };
    await publishNetworkRecord(source.tabId, networkRecord(transport, {
      status: "connected",
      bodyAvailable: false,
      bodyLength: 0,
      truncated: false,
      format: "webtransport",
      responseKeys: [],
      body: "",
      responseBodyError: "WebTransport 连接没有普通 HTTP 响应体"
    }));
    return;
  }

  if (method === "Network.webTransportClosed") {
    transports.delete(requestKey(source, params.transportId));
    return;
  }
}

async function competitionStats(tabId) {
  const records = await getPersistedRecords(tabId, "", MODE_COMPETITION_SHOP);
  const endpoints = new Set(records.map(record => `${record.method || ""} ${canonicalRecordPath(record)}`));
  const pendingForTab = [...requests.entries()]
    .filter(([key]) => String(key).startsWith(`${tabId}:`))
    .map(([, meta]) => meta);
  const pendingBusinessRequests = pendingForTab.filter(meta => {
    const path = canonicalRecordPath(meta);
    return path.startsWith("/api/competition/") || path.startsWith("/api/dmp/") || path === "/api/latestDay";
  }).length;
  const session = await getCompetitionSession(tabId);
  return {
    records: records.length,
    endpoints: endpoints.size,
    missingBodies: records.filter(record => !record.bodyAvailable).length,
    truncatedBodies: records.filter(record => record.truncated).length,
    pendingRequests: pendingForTab.length,
    pendingBusinessRequests,
    lastRecordAt: records.map(record => record.capturedAt).filter(Boolean).sort().at(-1) || null,
    session,
    active: Boolean(session?.active && activeTabs.has(tabId)),
  };
}

async function dispatchTrustedClick(tabId, x, y) {
  if (!Number.isFinite(x) || !Number.isFinite(y)) throw new Error("点击坐标无效");
  if (!activeTabs.has(tabId)) throw new Error("数据通道尚未启动");
  const send = (type, extra) => chrome.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", {
    type,
    x,
    y,
    button: "left",
    ...extra,
  });
  await send("mouseMoved", { button: "none", buttons: 0, clickCount: 0 });
  await send("mousePressed", { buttons: 1, clickCount: 1 });
  await send("mouseReleased", { buttons: 0, clickCount: 1 });
}

async function dispatchTrustedInput(tabId, message) {
  const x = Number(message.x);
  const y = Number(message.y);
  if (!Number.isFinite(x) || !Number.isFinite(y)) throw new Error("输入坐标无效");
  if (!activeTabs.has(tabId)) throw new Error("数据通道尚未启动");
  const target = { tabId };
  const mouse = (type, extra) => chrome.debugger.sendCommand(target, "Input.dispatchMouseEvent", {
    type,
    x,
    y,
    button: "left",
    ...extra,
  });
  const key = (type, keyName, code, keyCode, modifiers = 0) => chrome.debugger.sendCommand(target, "Input.dispatchKeyEvent", {
    type,
    key: keyName,
    code,
    windowsVirtualKeyCode: keyCode,
    nativeVirtualKeyCode: keyCode,
    modifiers,
  });
  await mouse("mouseMoved", { button: "none", buttons: 0, clickCount: 0 });
  await mouse("mousePressed", { buttons: 1, clickCount: 1 });
  await mouse("mouseReleased", { buttons: 0, clickCount: 1 });
  if (!message.skipClear) {
    await key("rawKeyDown", "a", "KeyA", 65, 4);
    await key("keyUp", "a", "KeyA", 65, 0);
    await key("rawKeyDown", "Backspace", "Backspace", 8, 0);
    await key("keyUp", "Backspace", "Backspace", 8, 0);
  }
  const text = String(message.text || "");
  if (text) await chrome.debugger.sendCommand(target, "Input.insertText", { text });
  if (message.pressEnter) {
    await new Promise(resolve => setTimeout(resolve, 180));
    await chrome.debugger.sendCommand(target, "Input.dispatchKeyEvent", {
      type: "keyDown",
      key: "Enter",
      code: "Enter",
      text: "\r",
      unmodifiedText: "\r",
      windowsVirtualKeyCode: 13,
      nativeVirtualKeyCode: 13,
    });
    await key("keyUp", "Enter", "Enter", 13, 0);
  }
}

chrome.debugger.onEvent.addListener((source, method, params) => {
  void handleEvent(source, method, params).catch(() => {});
});

chrome.debugger.onDetach.addListener((source, reason) => {
  if (!source.tabId) return;
  activeTabs.delete(source.tabId);
  void chrome.action.setBadgeText({ tabId: source.tabId, text: "" }).catch(() => {});
  void publishStatus(source.tabId, false, "数据通道已断开，请刷新页面后重试");
});

chrome.action.onClicked.addListener(tab => {
  if (!tab.id) return;
  void (activeTabs.has(tab.id) ? detach(tab.id) : attach(tab.id)).catch(error => {
    void publishStatus(tab.id, false, attachErrorMessage(error));
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const senderTabId = sender.tab?.id;

  if (message?.type === "DMP_UNIFIED_SET_MODE" && senderTabId) {
    void setTabMode(senderTabId, message.mode)
      .then(mode => sendResponse({ ok: true, mode }))
      .catch(error => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message?.type === "DMP_UNIFIED_GET_MODE" && senderTabId) {
    void getTabMode(senderTabId)
      .then(mode => sendResponse({ ok: true, mode }))
      .catch(error => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message?.type === "COMP_SITUATION_SYNC_REPORT" && senderTabId) {
    void syncDmpReportToOfficialSite({ ...message, reportType: MODE_COMPETITION_SHOP })
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message?.type === "COMP_SITUATION_CREATE_SHARE" && senderTabId) {
    void createDmpReportShare(message)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message?.type === "COMP_SITUATION_REAL_CLICK" && senderTabId) {
    void dispatchTrustedClick(senderTabId, Number(message.x), Number(message.y))
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message?.type === "COMP_SITUATION_REAL_INPUT" && senderTabId) {
    void dispatchTrustedInput(senderTabId, message)
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message?.type === "COMP_SITUATION_START" && senderTabId) {
    void (async () => {
      await setTabMode(senderTabId, MODE_COMPETITION_SHOP);
      if (message.reset !== false) await clearPersistedRecords(senderTabId, MODE_COMPETITION_SHOP);
      clearTabNetworkState(senderTabId);
      const competitorNames = Array.isArray(message.competitorNames)
        ? [...new Set(message.competitorNames.map(name => String(name).trim()).filter(Boolean))].slice(0, 3)
        : String(message.competitorName || message.note || "")
          .split(/[,，、;；\n]+/)
          .map(name => name.trim())
          .filter(Boolean)
          .slice(0, 3);
      const session = {
        id: `competition-shop-${Date.now()}`,
        mode: MODE_COMPETITION_SHOP,
        active: true,
        startedAt: new Date().toISOString(),
        pageUrl: safeUrl(sender.tab?.url || ""),
        note: String(message.note || ""),
        competitorName: String(message.competitorName || message.note || ""),
        competitorNames,
      };
      await saveCompetitionSession(senderTabId, session);
      await attach(senderTabId);
      return { ok: true, session, stats: await competitionStats(senderTabId) };
    })()
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message?.type === "COMP_SITUATION_RECORD_PORTRAIT_SHOPS" && senderTabId) {
    void (async () => {
      const current = await getCompetitionSession(senderTabId) || {};
      const subjectShopId = /^\d+$/.test(String(message.subjectShopId || "").trim())
        ? String(message.subjectShopId).trim()
        : "";
      const portraitCompetitorShopIds = [...new Set((Array.isArray(message.competitorShopIds) ? message.competitorShopIds : [])
        .map(value => String(value || "").trim())
        .filter(value => /^\d+$/.test(value)))].slice(0, 3);
      const competitorNames = Array.isArray(current.competitorNames) ? current.competitorNames : [];
      const portraitShopMappings = portraitCompetitorShopIds.map((shopId, index) => ({
        shopId,
        competitorName: competitorNames[index] || `竞店${index + 1}`,
      }));
      const session = {
        ...current,
        portraitSubjectShopId: subjectShopId,
        portraitCompetitorShopIds,
        portraitShopMappings,
        portraitRecordedAt: new Date().toISOString(),
      };
      await saveCompetitionSession(senderTabId, session);
      return { ok: true, session, stats: await competitionStats(senderTabId) };
    })()
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message?.type === "COMP_SITUATION_STOP" && senderTabId) {
    void (async () => {
      const current = await getCompetitionSession(senderTabId) || {};
      await saveCompetitionSession(senderTabId, {
        ...current,
        active: false,
        stoppedAt: new Date().toISOString(),
      });
      clearTabNetworkState(senderTabId);
      await publishStatus(senderTabId, false, "本轮采集已停止，可检查完整性并生成报告");
      return { ok: true, stats: await competitionStats(senderTabId) };
    })()
      .then(sendResponse)
      .catch(error => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message?.type === "COMP_SITUATION_STATS" && senderTabId) {
    void competitionStats(senderTabId)
      .then(stats => sendResponse({ ok: true, stats }))
      .catch(error => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message?.type === "COMP_SITUATION_GET_RECORDS" && senderTabId) {
    void Promise.all([
      getPersistedRecords(senderTabId, "", MODE_COMPETITION_SHOP),
      getCompetitionSession(senderTabId),
    ])
      .then(([records, session]) => sendResponse({ ok: true, records, session }))
      .catch(error => sendResponse({ ok: false, error: String(error?.message || error), records: [] }));
    return true;
  }

  if (message?.type === "COMP_SITUATION_CLEAR" && senderTabId) {
    void clearPersistedRecords(senderTabId, MODE_COMPETITION_SHOP)
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_AUTH_CHECK") {
    void checkOfficialSiteAccess()
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ ok: false, reason: "offline", error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_OPEN_LOGIN") {
    void chrome.tabs.create({ url: `${OFFICIAL_SITE}/login` })
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_OPEN_OPTIONS") {
    void chrome.runtime.openOptionsPage()
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_GET_AI_CONFIG") {
    void getAiConfig()
      .then(config => sendResponse({ ok: true, config }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_AI_HEALTH") {
    void aiHealth()
      .then(health => sendResponse({ ok: true, health }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_AI_GENERATE") {
    void generateAiReport(message.report)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_SYNC_REPORT") {
    void syncDmpReportToOfficialSite(message)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_CREATE_SHARE") {
    void createDmpReportShare(message)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_OPEN_REPORT_CENTER") {
    void chrome.tabs.create({ url: `${OFFICIAL_SITE}/tools/dmp-report` })
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_OPEN_REPORT") {
    void openOfficialReportWindow(message.reportId)
      .then(result => sendResponse({ ok: true, ...result }))
      .catch(error => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_AI_ANALYZE") {
    void analyzeWithCloudService(message.payload, message.report)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_GET_RECORDS" && sender.tab?.id) {
    void getPersistedRecords(sender.tab.id, typeof message.since === "string" ? message.since : "", MODE_GROWTH)
      .then(records => sendResponse({ ok: true, records, count: records.length }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error), records: [] }));
    return true;
  }

  if (message?.type === "DMP_CDP_SAVE_JOB" && sender.tab?.id) {
    void saveJob(sender.tab.id, message.job || null)
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_GET_JOB" && sender.tab?.id) {
    void getJob(sender.tab.id)
      .then(job => sendResponse({ ok: true, job }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error), job: null }));
    return true;
  }

  if (message?.type === "DMP_CDP_DELETE_JOB" && sender.tab?.id) {
    void deleteJob(sender.tab.id)
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_CLEAR_RECORDS" && sender.tab?.id) {
    void clearPersistedRecords(sender.tab.id, MODE_GROWTH)
      .then(() => {
        clearTabNetworkState(sender.tab.id);
        sendResponse({ ok: true, records: [], count: 0, clearedAt: new Date().toISOString() });
      })
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_CLEAR_RECORD_PATHS" && sender.tab?.id) {
    void clearPersistedRecordPaths(sender.tab.id, Array.isArray(message.paths) ? message.paths : [], MODE_GROWTH)
      .then(deleted => sendResponse({ ok: true, deleted, clearedAt: new Date().toISOString() }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_CLEAR_RECORD_IDS" && sender.tab?.id) {
    void clearPersistedRecordIds(sender.tab.id, Array.isArray(message.identities) ? message.identities : [], MODE_GROWTH)
      .then(deleted => sendResponse({ ok: true, deleted, clearedAt: new Date().toISOString() }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_STORE_RECORD" && sender.tab?.id) {
    const record = sanitizeStoredRecord(message.record);
    void persistRecord(sender.tab.id, record, MODE_GROWTH)
      .then(() => sendResponse({ ok: true, storedAt: new Date().toISOString() }))
      .catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }

  // 用 CDP Input 域派发浏览器级真实鼠标事件。
  // 关键区别：内容脚本 dispatchEvent 合成的事件 isTrusted 恒为 false，
  // 达摩盘的页签切换逻辑会拒绝响应（实测：埋点 SDK 收到了 mousedown 并上报，
  // 但页面既不切换也不取数）；Input.dispatchMouseEvent 派发的事件 isTrusted 为 true。
  if (message?.type === "DMP_CDP_REAL_CLICK" && sender.tab?.id) {
    const tabId = sender.tab.id;
    const x = Number(message.x);
    const y = Number(message.y);
    if (!Number.isFinite(x) || !Number.isFinite(y)) return sendResponse({ ok: false, error: "坐标无效" });
    if (!activeTabs.has(tabId)) return sendResponse({ ok: false, error: "数据通道未就绪" });

    // buttons 是位掩码（1 = 左键按下），Chrome 对 mousePressed/mouseReleased
    // 需要它才能构造出完整的事件；缺失时事件可能被静默丢弃。
    const send = (type, extra) => chrome.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", {
      type, x, y, button: "left", ...extra
    });

    void (async () => {
      await send("mouseMoved", { button: "none", buttons: 0, clickCount: 0 });
      await send("mousePressed", { buttons: 1, clickCount: 1 });
      await send("mouseReleased", { buttons: 0, clickCount: 1 });
    })()
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message?.type === "DMP_CDP_ENSURE_ATTACHED" && sender.tab?.id) {
    // 与 RECONNECT 的区别：不 detach。detach 会摧毁调试会话并丢弃 Chrome 侧
    // 已生效的 Network.enable，一键运行紧接着就改 hash 发业务请求，
    // 空窗期内这些请求会全部记录不到。这里只做幂等的 attach + 重新 enable。
    void setTabMode(sender.tab.id, MODE_GROWTH)
      .then(() => attach(sender.tab.id))
      .then(() => sendResponse({ ok: true, attached: true }))
      .catch(error => sendResponse({ ok: false, error: attachErrorMessage(error) }));
    return true;
  }

  if (message?.type !== "DMP_CDP_RECONNECT" || !sender.tab?.id) return;

  void setTabMode(sender.tab.id, MODE_GROWTH)
    .then(() => reconnect(sender.tab.id))
    .then(() => sendResponse({ ok: true }))
    .catch(error => sendResponse({ ok: false, error: attachErrorMessage(error) }));
  return true;
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url?.startsWith("https://dmp.taobao.com/") ||
      (changeInfo.status === "loading" && tab.url?.startsWith("https://dmp.taobao.com/"))) {
    void attach(tabId).catch(error => {
      void publishStatus(tabId, false, attachErrorMessage(error));
    });
  }
});

chrome.tabs.onRemoved.addListener(tabId => {
  activeTabs.delete(tabId);
  observedResponses.delete(tabId);
  capturedResponses.delete(tabId);
  tabModes.delete(tabId);
  competitionSessions.delete(tabId);
});

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name !== OFFICIAL_AUTH_ALARM || !activeTabs.size) return;
  void checkOfficialSiteAccess().then(async authorization => {
    if (authorization.ok) return;
    for (const tabId of [...activeTabs]) {
      await lockTabForOfficialAuth(tabId, authorization.error || "官网在线校验失败");
    }
  }).catch(() => {});
});

function ensureOfficialHeartbeat() {
  return chrome.alarms.create(OFFICIAL_AUTH_ALARM, { periodInMinutes: 1 });
}

chrome.runtime.onInstalled.addListener(async () => {
  await ensureOfficialHeartbeat();
  const tabs = await chrome.tabs.query({ url: "https://dmp.taobao.com/*" });
  for (const tab of tabs) {
    if (tab.id) void attach(tab.id).catch(() => {});
  }
});

async function attachOpenDmpTabs() {
  const tabs = await chrome.tabs.query({ url: "https://dmp.taobao.com/*" });
  for (const tab of tabs) {
    if (tab.id) void attach(tab.id).catch(() => {});
  }
}

// 同时覆盖扩展更新、浏览器启动和 Service Worker 重新唤醒三种情况。
void attachOpenDmpTabs().catch(() => {});
chrome.runtime.onStartup.addListener(() => {
  void ensureOfficialHeartbeat();
  void attachOpenDmpTabs().catch(() => {});
});
void ensureOfficialHeartbeat();
