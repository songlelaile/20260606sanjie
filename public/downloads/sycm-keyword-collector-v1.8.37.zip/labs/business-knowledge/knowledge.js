'use strict';

(function () {
  var KB = globalThis.SZBusinessKnowledge;
  var MAX_FILE_BYTES = 10 * 1024 * 1024;
  var MAX_TOTAL_BYTES = 30 * 1024 * 1024;
  var state = {
    record: KB ? KB.normalize({}) : {}, sources: [], accountKey: 'local', loading: false,
    obsidian: null, obsidianContext: '', obsidianSources: []
  };
  var ids = [
    'accountState', 'saveState', 'sourceFiles', 'sourceList', 'sourceCount', 'kbName', 'kbEnabled',
    'scopeLink', 'scopeMain', 'scopeDetail', 'contextPreview', 'contextCount', 'saveBtn', 'exportBtn', 'clearBtn', 'hint',
    'fieldBrand', 'fieldCategory', 'fieldAudience', 'fieldScenarios', 'fieldBenefits', 'fieldDifferentiation',
    'fieldTone', 'fieldVisual', 'fieldCompliance', 'obsidianState', 'obsidianBaseUrl', 'obsidianFolder',
    'obsidianMaxNotes', 'obsidianApiKey', 'obsidianEnabled', 'toggleObsidianKey', 'connectObsidianBtn',
    'previewObsidianBtn', 'disconnectObsidianBtn', 'openObsidianCertBtn', 'obsidianHint', 'obsidianSources',
    'obsidianPreviewScope'
  ];
  var el = ids.reduce(function (out, id) { out[id] = document.getElementById(id); return out; }, {});
  var fieldMap = {
    brand: 'fieldBrand', category: 'fieldCategory', audience: 'fieldAudience', scenarios: 'fieldScenarios',
    benefits: 'fieldBenefits', differentiation: 'fieldDifferentiation', tone: 'fieldTone', visual: 'fieldVisual',
    compliance: 'fieldCompliance'
  };

  function setState(text, kind) {
    if (!el.saveState) return;
    el.saveState.textContent = text;
    el.saveState.className = 'pill' + (kind ? ' ' + kind : '');
  }

  function send(type, payload) {
    return new Promise(function (resolve) {
      if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
        resolve(type === 'GET_BUSINESS_KNOWLEDGE'
          ? { ok: true, accountKey: 'local-preview', knowledge: {} }
          : { ok: false, error: '请在 Chrome 扩展页面中保存知识库' });
        return;
      }
      try {
        chrome.runtime.sendMessage(Object.assign({ type: type }, payload || {}), function (resp) {
          var error = chrome.runtime.lastError;
          resolve(error ? { ok: false, error: error.message } : (resp || { ok: false, error: '无响应' }));
        });
      } catch (error) {
        resolve({ ok: false, error: (error && error.message) || String(error) });
      }
    });
  }

  function selectedScope() {
    var value = el.obsidianPreviewScope && el.obsidianPreviewScope.value;
    return value === 'detail' ? 'detail' : (value === 'main' ? 'main' : 'link');
  }

  function obsidianConfigFromForm() {
    return {
      enabled: !!el.obsidianEnabled.checked,
      baseUrl: String(el.obsidianBaseUrl.value || '').trim(),
      folder: String(el.obsidianFolder.value || '').trim(),
      maxNotes: Math.max(1, Math.min(60, Number(el.obsidianMaxNotes.value) || 30)),
      scopes: {
        link: !!el.scopeLink.checked,
        main: !!el.scopeMain.checked,
        detail: !!el.scopeDetail.checked
      }
    };
  }

  function setObsidianHint(text, kind) {
    el.obsidianHint.textContent = text;
    el.obsidianHint.className = 'connection-hint' + (kind ? ' ' + kind : '');
  }

  function renderObsidianSources() {
    el.obsidianSources.innerHTML = '';
    if (!state.obsidianSources.length) {
      var empty = document.createElement('div'); empty.className = 'empty compact';
      empty.textContent = state.obsidian && state.obsidian.connected ? '已连接；点击“刷新当前作用域预览”查看命中的笔记。' : '连接后显示实时命中的笔记来源';
      el.obsidianSources.appendChild(empty);
      return;
    }
    state.obsidianSources.forEach(function (source) {
      var row = document.createElement('div'); row.className = 'obsidian-source';
      var name = document.createElement('strong'); name.textContent = source.path || '未命名笔记'; name.title = source.path || '';
      var meta = document.createElement('span');
      meta.textContent = (source.priority ? ('优先级 ' + source.priority + ' · ') : '') + Number(source.chars || 0).toLocaleString() + ' 字';
      row.appendChild(name); row.appendChild(meta); el.obsidianSources.appendChild(row);
    });
  }

  function renderObsidianConnection(result) {
    result = result || {};
    state.obsidian = result;
    var config = result.config || {};
    if (config.baseUrl) el.obsidianBaseUrl.value = config.baseUrl;
    if (config.folder != null) el.obsidianFolder.value = config.folder;
    if (config.maxNotes) el.obsidianMaxNotes.value = config.maxNotes;
    el.obsidianEnabled.checked = config.enabled !== false;
    if (result.connected) {
      el.obsidianState.textContent = '已连接' + (config.lastNoteCount ? (' · ' + config.lastNoteCount + ' 篇') : '');
      el.obsidianState.className = 'connection-state ok';
      el.obsidianApiKey.value = '';
      el.obsidianApiKey.placeholder = 'Key 已安全保存在本次浏览器会话；如需更换可重新粘贴';
      setObsidianHint('连接可用。AI 会按 link / main / detail 作用域实时读取，正文不会写入扩展长期存储。', 'ok');
    } else if (result.configured && !result.hasSessionKey) {
      el.obsidianState.textContent = '需重新输入 Key';
      el.obsidianState.className = 'connection-state warn';
      el.obsidianApiKey.placeholder = '浏览器会话已结束，请重新粘贴 API Key';
      setObsidianHint('连接参数仍在，但 API Key 已随浏览器会话清除。重新粘贴 Key 并点击连接。', 'warn');
    } else {
      el.obsidianState.textContent = '未连接';
      el.obsidianState.className = 'connection-state';
      setObsidianHint('需要 Obsidian 保持打开，并已启用 Local REST API。建议只授权专用“少壮AI知识库”目录；HTTPS 首次使用需信任本机证书。', '');
    }
    renderObsidianSources();
  }

  function loadObsidianConnection() {
    return send('GET_OBSIDIAN_CONNECTION').then(function (result) {
      if (!result || !result.ok) throw new Error((result && result.error) || 'Obsidian 连接状态读取失败');
      renderObsidianConnection(result);
      return result;
    }).catch(function (error) {
      el.obsidianState.textContent = '连接器异常'; el.obsidianState.className = 'connection-state warn';
      setObsidianHint((error && error.message) || String(error), 'warn');
      return null;
    });
  }

  function originPermissionPattern(baseUrl) {
    var parsed = new URL(baseUrl);
    return parsed.protocol + '//' + parsed.hostname + '/*';
  }

  function ensureObsidianPermission(baseUrl) {
    if (typeof chrome === 'undefined' || !chrome.permissions || !chrome.permissions.request) return Promise.resolve(true);
    var origin;
    try { origin = originPermissionPattern(baseUrl); }
    catch (error) { return Promise.reject(new Error('Obsidian API 地址格式不正确')); }
    return new Promise(function (resolve) {
      // permissions.request 必须直接由用户点击触发；已授权时 Chrome 会立即返回 true。
      chrome.permissions.request({ origins: [origin] }, function (granted) {
        var requestError = chrome.runtime.lastError;
        resolve(!requestError && !!granted);
      });
    });
  }

  function refreshObsidianPreview() {
    if (!state.obsidian || !state.obsidian.connected) {
      setObsidianHint('请先连接 Obsidian，再读取实时预览。', 'warn');
      return Promise.resolve();
    }
    el.previewObsidianBtn.disabled = true;
    setObsidianHint('正在从 Obsidian 实时读取当前作用域…', '');
    return send('PREVIEW_OBSIDIAN_CONTEXT', { scope: selectedScope(), maxChars: 8000 }).then(function (result) {
      if (!result || !result.ok) throw new Error((result && (result.externalError || result.error)) || 'Obsidian 预览读取失败');
      state.obsidianContext = result.externalContext || '';
      state.obsidianSources = Array.isArray(result.sources) ? result.sources : [];
      renderPreview(); renderObsidianSources();
      if (result.externalError && !result.sources.length) {
        setObsidianHint(result.externalError, 'warn');
      } else {
        setObsidianHint('实时读取完成：当前作用域命中 ' + state.obsidianSources.length + ' 篇笔记；未把正文写入插件存储。', 'ok');
      }
    }).catch(function (error) {
      state.obsidianContext = ''; state.obsidianSources = []; renderPreview(); renderObsidianSources();
      setObsidianHint((error && error.message) || String(error), 'warn');
    }).finally(function () { el.previewObsidianBtn.disabled = false; });
  }

  function connectObsidian() {
    var config = obsidianConfigFromForm();
    var apiKey = String(el.obsidianApiKey.value || '').trim().replace(/^Bearer\s+/i, '');
    if (!config.folder && !confirm('当前目录为空，将允许 AI 在每次任务中扫描整个 Vault。Local REST Key 拥有全 Vault 权限，可能误读 Clippings 等网页资料。仍要继续吗？')) return;
    if ((!state.obsidian || !state.obsidian.hasSessionKey) && config.enabled && !apiKey) {
      setObsidianHint('请粘贴 Local REST API 页面中 Bearer 后面的 API Key。', 'warn');
      el.obsidianApiKey.focus(); return;
    }
    el.connectObsidianBtn.disabled = true;
    setObsidianHint('正在申请本机地址权限并测试连接…', '');
    ensureObsidianPermission(config.baseUrl).then(function (granted) {
      if (!granted) throw new Error('未获得本机 Obsidian 地址访问权限，无法连接');
      return send('CONNECT_OBSIDIAN', { config: config, apiKey: apiKey });
    }).then(function (result) {
      if (!result || !result.ok) throw new Error((result && result.error) || '连接失败');
      renderObsidianConnection(result);
      var diagnostics = result.diagnostics || {};
      setObsidianHint('连接成功：' + (diagnostics.service || 'Obsidian Local REST API') +
        (diagnostics.version ? (' v' + diagnostics.version) : '') + '，目录内发现 ' + Number(diagnostics.noteCount || 0) + ' 篇可读笔记。', 'ok');
      return refreshObsidianPreview();
    }).catch(function (error) {
      el.obsidianState.textContent = '连接失败'; el.obsidianState.className = 'connection-state warn';
      setObsidianHint((error && error.message) || String(error), 'warn');
    }).finally(function () { el.connectObsidianBtn.disabled = false; });
  }

  function persistObsidianSettings() {
    if (!state.obsidian || !state.obsidian.configured) return Promise.resolve();
    return send('SAVE_OBSIDIAN_CONNECTION', { config: obsidianConfigFromForm(), apiKey: '' }).then(function (result) {
      if (!result || !result.ok) throw new Error((result && result.error) || 'Obsidian 设置保存失败');
      state.obsidian = result;
      return result;
    }).catch(function (error) {
      setObsidianHint((error && error.message) || String(error), 'warn');
      return null;
    });
  }

  function disconnectObsidian() {
    if (!confirm('确认断开 Obsidian 吗？只会删除插件中的连接参数与会话 Key，不会修改 Vault。')) return;
    el.disconnectObsidianBtn.disabled = true;
    send('DISCONNECT_OBSIDIAN').then(function (result) {
      if (!result || !result.ok) throw new Error((result && result.error) || '断开失败');
      state.obsidianContext = ''; state.obsidianSources = [];
      el.obsidianApiKey.value = '';
      renderObsidianConnection({ ok: true, configured: false, connected: false, hasSessionKey: false, config: obsidianConfigFromForm() });
      renderPreview();
    }).catch(function (error) {
      setObsidianHint((error && error.message) || String(error), 'warn');
    }).finally(function () { el.disconnectObsidianBtn.disabled = false; });
  }

  function openObsidianCertificate() {
    var baseUrl = String(el.obsidianBaseUrl.value || '').trim().replace(/\/+$/, '');
    var url;
    try { url = new URL('/obsidian-local-rest-api.crt', baseUrl).toString(); }
    catch (error) { setObsidianHint('请先填写正确的 HTTPS API 地址。', 'warn'); return; }
    if (!/^https:/.test(url)) { setObsidianHint('当前使用 HTTP，不需要安装 HTTPS 证书。', ''); return; }
    try {
      chrome.tabs.create({ url: url });
      setObsidianHint('已打开证书地址。下载后需在 macOS 钥匙串中设为“始终信任”，然后重启 Chrome。', '');
    } catch (error) {
      window.open(url, '_blank');
    }
  }

  function readFileText(file) {
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onload = function () { resolve(String(reader.result || '')); };
      reader.onerror = function () { reject(reader.error || new Error('文件读取失败')); };
      reader.readAsText(file);
    });
  }

  function workbookText(file) {
    if (globalThis.LOCALTABLES && typeof globalThis.LOCALTABLES.extractWorkbookText === 'function') {
      return globalThis.LOCALTABLES.extractWorkbookText(file, { maxChars: KB.MAX_SOURCE_CHARS }).then(function (result) {
        if (result && result.truncated) el.hint.textContent = 'Excel内容超过知识库正文预算，已在安全解析后截取前12万字。';
        return result && result.text || '';
      });
    }
    return Promise.reject(new Error('Excel 安全解析组件未加载，请重载插件后再试'));
  }

  function parseFile(file) {
    if (!file || !file.size) return Promise.reject(new Error('空文件不能导入'));
    if (file.size > MAX_FILE_BYTES) return Promise.reject(new Error('单文件不能超过 10MB'));
    var ext = String(file && file.name || '').toLowerCase().split('.').pop();
    var parser = /^(xlsx|xls)$/.test(ext) ? workbookText(file) : readFileText(file);
    return parser.then(function (text) {
      text = KB.cleanText(text, KB.MAX_SOURCE_CHARS);
      if (!text) throw new Error('文件没有可读取文本');
      return {
        id: 'kb-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8),
        name: file.name || '未命名资料',
        type: file.type || ('application/' + ext),
        size: Number(file.size) || 0,
        chars: text.length,
        text: text
      };
    });
  }

  function renderSources() {
    el.sourceList.innerHTML = '';
    el.sourceCount.textContent = state.sources.length + ' / ' + KB.MAX_SOURCE_COUNT;
    if (!state.sources.length) {
      var empty = document.createElement('div');
      empty.className = 'empty';
      empty.textContent = '尚未导入资料';
      el.sourceList.appendChild(empty);
      return;
    }
    state.sources.forEach(function (source, idx) {
      var row = document.createElement('div'); row.className = 'source-row';
      var copy = document.createElement('div');
      var name = document.createElement('strong'); name.textContent = source.name;
      var meta = document.createElement('span'); meta.textContent = source.type + ' · ' + source.chars.toLocaleString() + ' 字';
      var chars = document.createElement('b'); chars.textContent = '#' + String(idx + 1).padStart(2, '0');
      var remove = document.createElement('button'); remove.type = 'button'; remove.textContent = '×'; remove.title = '移除资料';
      remove.addEventListener('click', function () { state.sources.splice(idx, 1); renderAll(); setState('有未保存修改', 'warn'); });
      copy.appendChild(name); copy.appendChild(meta); row.appendChild(copy); row.appendChild(chars); row.appendChild(remove);
      el.sourceList.appendChild(row);
    });
  }

  function recordFromForm() {
    var fields = {};
    Object.keys(fieldMap).forEach(function (key) { fields[key] = el[fieldMap[key]].value || ''; });
    return KB.normalize({
      name: el.kbName.value,
      enabled: el.kbEnabled.checked,
      updatedAt: state.record.updatedAt || 0,
      scopes: { link: el.scopeLink.checked, main: el.scopeMain.checked, detail: el.scopeDetail.checked },
      fields: fields,
      sources: state.sources
    });
  }

  function applyRecord(record) {
    record = KB.normalize(record);
    state.record = record;
    state.sources = record.sources.slice();
    el.kbName.value = record.name;
    el.kbEnabled.checked = record.enabled;
    el.scopeLink.checked = record.scopes.link;
    el.scopeMain.checked = record.scopes.main;
    el.scopeDetail.checked = record.scopes.detail;
    Object.keys(fieldMap).forEach(function (key) { el[fieldMap[key]].value = record.fields[key] || ''; });
    renderAll();
  }

  function renderPreview() {
    var record = recordFromForm();
    var scopes = [];
    if (record.scopes.link) scopes.push('链接定位');
    if (record.scopes.main) scopes.push('主图提示词');
    if (record.scopes.detail) scopes.push('详情页提示词');
    var context = KB.contextForScope(record, record.scopes.link ? 'link' : (record.scopes.main ? 'main' : 'detail'));
    if (state.obsidianContext) context = [context, state.obsidianContext].filter(Boolean).join('\n\n');
    el.contextPreview.textContent = context || '当前知识库未启用、未选择调用范围，或还没有有效内容。';
    el.contextCount.textContent = context.length.toLocaleString() + ' 字 · ' + (scopes.join(' / ') || '未调用') +
      (state.obsidianSources.length ? (' · Obsidian ' + state.obsidianSources.length + ' 篇') : '');
  }

  function renderAll() { renderSources(); renderPreview(); }

  function loadCurrent() {
    setState('读取中…', '');
    return send('GET_BUSINESS_KNOWLEDGE').then(function (resp) {
      if (!resp || !resp.ok) throw new Error((resp && resp.error) || '知识库读取失败');
      state.accountKey = resp.accountKey || 'local';
      el.accountState.textContent = state.accountKey === 'local' ? '本机账号' : '当前登录账号';
      el.accountState.className = 'pill ok';
      applyRecord(resp.knowledge || {});
      var summary = KB.summary(resp.knowledge || {});
      setState(summary.ready ? ('已保存 · ' + summary.sourceCount + ' 份资料') : '等待导入', summary.ready ? 'ok' : '');
    }).catch(function (error) {
      el.accountState.textContent = '账号读取失败'; el.accountState.className = 'pill warn';
      setState((error && error.message) || String(error), 'warn');
    });
  }

  function saveCurrent() {
    var record = recordFromForm();
    if (!KB.hasContent(record)) { setState('请先导入资料或填写至少一项业务规则', 'warn'); return; }
    el.saveBtn.disabled = true; setState('保存中…', '');
    send('SAVE_BUSINESS_KNOWLEDGE', { knowledge: Object.assign({}, record, { updatedAt: Date.now() }) }).then(function (resp) {
      if (!resp || !resp.ok) throw new Error((resp && resp.error) || '保存失败');
      applyRecord(resp.knowledge || record);
      setState('已保存 · 三条链路可调用', 'ok');
    }).catch(function (error) {
      setState((error && error.message) || String(error), 'warn');
    }).finally(function () { el.saveBtn.disabled = false; });
  }

  function exportCurrent() {
    var record = recordFromForm();
    var blob = new Blob([JSON.stringify(record, null, 2)], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var link = document.createElement('a');
    link.href = url; link.download = '少壮AI业务知识库_' + new Date().toISOString().slice(0, 10) + '.json';
    document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(url);
    setState('已导出 JSON', 'ok');
  }

  function clearCurrent() {
    if (!confirm('确认清空当前账号的业务知识库吗？API配置、链接清单和图片不会被删除。')) return;
    el.clearBtn.disabled = true;
    send('CLEAR_BUSINESS_KNOWLEDGE').then(function (resp) {
      if (!resp || !resp.ok) throw new Error((resp && resp.error) || '清空失败');
      applyRecord({}); setState('已清空当前账号知识库', 'ok');
    }).catch(function (error) { setState((error && error.message) || String(error), 'warn'); })
      .finally(function () { el.clearBtn.disabled = false; });
  }

  el.sourceFiles.addEventListener('change', function (event) {
    var files = Array.prototype.slice.call((event.target && event.target.files) || []);
    var room = Math.max(0, KB.MAX_SOURCE_COUNT - state.sources.length);
    files = files.slice(0, room);
    if (!files.length) { setState(room ? '未选择文件' : '最多只能导入 8 份资料', 'warn'); return; }
    var existingBytes = state.sources.reduce(function (sum, source) { return sum + (Number(source.size) || 0); }, 0);
    var incomingBytes = files.reduce(function (sum, file) { return sum + (Number(file.size) || 0); }, 0);
    if (existingBytes + incomingBytes > MAX_TOTAL_BYTES) {
      setState('本次知识库原文件总量不能超过 30MB', 'warn');
      event.target.value = '';
      return;
    }
    setState('正在解析 ' + files.length + ' 份资料…', '');
    Promise.allSettled(files.map(parseFile)).then(function (results) {
      var added = 0, errors = [];
      results.forEach(function (result, idx) {
        if (result.status === 'fulfilled') { state.sources.push(result.value); added++; }
        else errors.push((files[idx] && files[idx].name || '文件') + '：' + ((result.reason && result.reason.message) || result.reason));
      });
      var beforeChars = state.sources.reduce(function (sum, source) { return sum + (source.chars || 0); }, 0);
      state.sources = KB.normalize({ sources: state.sources }).sources;
      var afterChars = state.sources.reduce(function (sum, source) { return sum + (source.chars || 0); }, 0);
      renderAll(); event.target.value = '';
      var truncated = beforeChars > afterChars;
      setState('已解析 ' + added + ' 份' + (errors.length ? '，失败 ' + errors.length + ' 份' : '') + (truncated ? '，正文已按12万字上限截取' : '') + ' · 请保存', (errors.length || truncated) ? 'warn' : 'ok');
      if (errors.length || truncated) el.hint.textContent = errors.concat(truncated ? ['知识库正文最多保留12万字；界面已明确标记本次截取。'] : []).join('；');
    });
  });

  Object.keys(fieldMap).forEach(function (key) { el[fieldMap[key]].addEventListener('input', function () { renderPreview(); setState('有未保存修改', 'warn'); }); });
  [el.kbName, el.kbEnabled, el.scopeLink, el.scopeMain, el.scopeDetail].forEach(function (control) {
    control.addEventListener('input', function () { renderPreview(); setState('有未保存修改', 'warn'); });
    control.addEventListener('change', function () { renderPreview(); setState('有未保存修改', 'warn'); });
  });
  [el.scopeLink, el.scopeMain, el.scopeDetail].forEach(function (control) {
    control.addEventListener('change', function () {
      state.obsidianContext = ''; state.obsidianSources = [];
      renderPreview(); renderObsidianSources();
      if (state.obsidian && state.obsidian.connected) {
        setObsidianHint('正在保存 Obsidian 调用范围…', '');
        persistObsidianSettings().then(function () {
          setObsidianHint('调用范围已保存；点击“刷新当前作用域预览”核对实时内容。', 'ok');
        });
      }
    });
  });
  el.saveBtn.addEventListener('click', saveCurrent);
  el.exportBtn.addEventListener('click', exportCurrent);
  el.clearBtn.addEventListener('click', clearCurrent);
  el.toggleObsidianKey.addEventListener('click', function () {
    var showing = el.obsidianApiKey.type === 'text';
    el.obsidianApiKey.type = showing ? 'password' : 'text';
    el.toggleObsidianKey.textContent = showing ? '显示' : '隐藏';
    el.toggleObsidianKey.setAttribute('aria-label', showing ? '显示 API Key' : '隐藏 API Key');
  });
  el.connectObsidianBtn.addEventListener('click', connectObsidian);
  el.previewObsidianBtn.addEventListener('click', refreshObsidianPreview);
  el.disconnectObsidianBtn.addEventListener('click', disconnectObsidian);
  el.openObsidianCertBtn.addEventListener('click', openObsidianCertificate);
  el.obsidianEnabled.addEventListener('change', function () {
    state.obsidianContext = ''; state.obsidianSources = []; renderPreview(); renderObsidianSources();
    persistObsidianSettings();
  });
  el.obsidianPreviewScope.addEventListener('change', function () {
    state.obsidianContext = ''; state.obsidianSources = [];
    renderPreview(); renderObsidianSources();
    if (state.obsidian && state.obsidian.connected) refreshObsidianPreview();
  });
  loadCurrent();
  loadObsidianConnection();
})();
