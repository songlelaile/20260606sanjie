/* image-archive-store.js — 生图结果本机留档、7天回收站与缺失清理 */
(function (root, factory) {
  var api = factory(root || {});
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.SZ_IMAGE_ARCHIVE = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (root) {
  'use strict';

  var DB_NAME = 'sz_image_archive_v1';
  var DB_VERSION = 1;
  var BATCH_STORE = 'batches';
  var ASSET_STORE = 'assets';
  var RETENTION_MS = 7 * 24 * 60 * 60 * 1000;
  var MAX_IMAGE_BYTES = 40 * 1024 * 1024;

  function text(value, max) {
    var out = String(value == null ? '' : value).trim();
    return max ? out.slice(0, max) : out;
  }

  function normalizeAccountKey(value) {
    return text(value, 140) || 'local';
  }

  function textList(value, limit, max) {
    var out = [];
    (Array.isArray(value) ? value : []).forEach(function (item) {
      item = text(item, max || 40);
      if (item && out.indexOf(item) < 0 && out.length < (limit || 8)) out.push(item);
    });
    return out;
  }

  function hashText(value) {
    var h = 2166136261;
    value = String(value || '');
    for (var i = 0; i < value.length; i++) h = Math.imul(h ^ value.charCodeAt(i), 16777619);
    return ('00000000' + (h >>> 0).toString(16)).slice(-8);
  }

  function canonicalArchiveLinkId(value) {
    var match = /^\s*L?0*(\d+)\s*$/i.exec(String(value || ''));
    if (!match) return '';
    var sequence = Number(match[1]);
    if (!Number.isSafeInteger(sequence) || sequence < 1) return '';
    return 'L' + String(sequence).padStart(3, '0');
  }

  function archiveLinkIds(values) {
    var seen = Object.create(null);
    return (Array.isArray(values) ? values : [values]).map(canonicalArchiveLinkId).filter(function (id) {
      if (!id || seen[id]) return false;
      seen[id] = true;
      return true;
    }).sort(function (a, b) { return Number(a.slice(1)) - Number(b.slice(1)); });
  }

  function archiveLinkRangeLabel(values) {
    var ids = archiveLinkIds(values);
    if (!ids.length) return '';
    var ranges = [];
    var start = ids[0];
    var previous = ids[0];
    function pushRange() { ranges.push(start === previous ? start : (start + '–' + previous)); }
    for (var i = 1; i < ids.length; i++) {
      if (Number(ids[i].slice(1)) === Number(previous.slice(1)) + 1) {
        previous = ids[i];
        continue;
      }
      pushRange();
      start = previous = ids[i];
    }
    pushRange();
    return ranges.join('、');
  }

  function numberedLinkSurface(asset) {
    return !!(asset && (asset.surfaceMode === 'main' || asset.surfaceMode === 'detail') && canonicalArchiveLinkId(asset.linkId));
  }

  function allowedMime(value) {
    value = text(value, 80).toLowerCase().split(';')[0];
    if (value === 'image/jpg') value = 'image/jpeg';
    return /^(image\/png|image\/jpeg|image\/webp|image\/gif)$/.test(value) ? value : '';
  }

  function dataUrlToBlob(dataUrl) {
    var match = /^data:(image\/[a-z0-9.+-]+);base64,([\s\S]+)$/i.exec(String(dataUrl || ''));
    if (!match) return Promise.reject(new Error('不是可留档的图片数据'));
    var mime = allowedMime(match[1]);
    if (!mime) return Promise.reject(new Error('不支持的图片格式'));
    try {
      var binary = root.atob ? root.atob(match[2].replace(/\s+/g, '')) : Buffer.from(match[2], 'base64').toString('binary');
      if (binary.length > MAX_IMAGE_BYTES) return Promise.reject(new Error('单张留档图片不能超过40MB'));
      var bytes = new Uint8Array(binary.length);
      for (var i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      return Promise.resolve(new Blob([bytes], { type: mime }));
    } catch (error) {
      return Promise.reject(new Error('图片数据解码失败'));
    }
  }

  function validBlob(blob) {
    return !!(blob && typeof blob.size === 'number' && blob.size > 0 && blob.size <= MAX_IMAGE_BYTES && allowedMime(blob.type));
  }

  function sourceToBlob(source, fetcher) {
    if (validBlob(source)) return Promise.resolve(source);
    var value = String(source || '');
    if (/^data:image\//i.test(value)) return dataUrlToBlob(value);
    if (!/^(https?:|blob:)/i.test(value)) return Promise.reject(new Error('没有可留档的本机图片来源'));
    fetcher = fetcher || root.fetch;
    if (typeof fetcher !== 'function') return Promise.reject(new Error('当前环境无法读取图片文件'));
    return fetcher(value, { credentials: 'omit', referrerPolicy: 'no-referrer' }).then(function (response) {
      if (!response || !response.ok) throw new Error('图片文件读取失败');
      var declared = Number(response.headers && response.headers.get && response.headers.get('content-length')) || 0;
      if (declared > MAX_IMAGE_BYTES) throw new Error('单张留档图片不能超过40MB');
      return response.blob();
    }).then(function (blob) {
      if (!validBlob(blob)) throw new Error('返回内容不是有效图片或超过40MB');
      return blob;
    });
  }

  function openDb() {
    return new Promise(function (resolve, reject) {
      if (!root.indexedDB) { reject(new Error('当前环境不支持本机图片档案')); return; }
      var request = root.indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = function () {
        var db = request.result;
        var batches = db.objectStoreNames.contains(BATCH_STORE)
          ? request.transaction.objectStore(BATCH_STORE)
          : db.createObjectStore(BATCH_STORE, { keyPath: 'archiveBatchId' });
        if (!batches.indexNames.contains('accountKey')) batches.createIndex('accountKey', 'accountKey', { unique: false });
        if (!batches.indexNames.contains('updatedAt')) batches.createIndex('updatedAt', 'updatedAt', { unique: false });
        var assets = db.objectStoreNames.contains(ASSET_STORE)
          ? request.transaction.objectStore(ASSET_STORE)
          : db.createObjectStore(ASSET_STORE, { keyPath: 'archiveAssetId' });
        if (!assets.indexNames.contains('accountKey')) assets.createIndex('accountKey', 'accountKey', { unique: false });
        if (!assets.indexNames.contains('archiveBatchId')) assets.createIndex('archiveBatchId', 'archiveBatchId', { unique: false });
        if (!assets.indexNames.contains('purgeAt')) assets.createIndex('purgeAt', 'purgeAt', { unique: false });
      };
      request.onsuccess = function () { resolve(request.result); };
      request.onerror = function () { reject(request.error || new Error('无法打开本机图片档案')); };
    });
  }

  function transaction(storeNames, mode, task) {
    return openDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(storeNames, mode);
        var stores = {};
        storeNames.forEach(function (name) { stores[name] = tx.objectStore(name); });
        var result;
        var failed = false;
        function fail(error) {
          if (failed) return;
          failed = true;
          try { tx.abort(); } catch (_) {}
          reject(error || new Error('本机图片档案事务失败'));
        }
        try { result = task(stores, fail); }
        catch (error) { fail(error); }
        tx.oncomplete = function () { db.close(); if (!failed) resolve(typeof result === 'function' ? result() : result); };
        tx.onerror = function () { db.close(); fail(tx.error || new Error('本机图片档案事务失败')); };
        tx.onabort = function () { db.close(); if (!failed) fail(tx.error || new Error('本机图片档案事务已取消')); };
      });
    });
  }

  function sanitizeArchiveInput(raw) {
    raw = raw || {};
    var accountKey = normalizeAccountKey(raw.accountKey);
    var surfaceMode = ['main', 'detail', 'sku', 'viral'].indexOf(raw.surfaceMode) >= 0 ? raw.surfaceMode : 'main';
    var sourceBatchId = text(raw.sourceBatchId || raw.batchId || raw.jobId || raw.resultId, 220) || ('local_' + Date.now());
    var archiveBatchId = text(raw.archiveBatchId, 260) || ('archive_batch_' + hashText(accountKey + '|' + surfaceMode + '|' + sourceBatchId));
    var resultId = text(raw.resultId || raw.jobId, 260) || ('result_' + Date.now() + '_' + Math.random().toString(16).slice(2));
    var archiveAssetId = text(raw.archiveAssetId, 260) || ('archive_asset_' + hashText(accountKey + '|' + archiveBatchId + '|' + resultId));
    return {
      accountKey: accountKey,
      surfaceMode: surfaceMode,
      creativeRoute: text(raw.creativeRoute, 80),
      detailMode: text(raw.detailMode, 80),
      sourceBatchId: sourceBatchId,
      technicalSourceBatchId: text(raw.technicalSourceBatchId, 260),
      archiveBatchId: archiveBatchId,
      archiveProjectId: text(raw.archiveProjectId, 260),
      archiveAssetId: archiveAssetId,
      resultId: resultId,
      batchTitle: text(raw.batchTitle, 160) || '本机生图档案',
      businessBatchTitle: text(raw.businessBatchTitle, 180),
      businessType: text(raw.businessType, 60),
      productName: text(raw.productName, 180),
      styleName: text(raw.styleName, 100),
      strengthName: text(raw.strengthName, 80),
      copyModeName: text(raw.copyModeName, 80),
      businessRoleKey: text(raw.businessRoleKey, 180),
      businessRoleName: text(raw.businessRoleName, 180),
      businessSummary: text(raw.businessSummary, 800),
      businessTags: textList(raw.businessTags, 8, 40),
      generationKind: text(raw.generationKind, 40),
      linkId: text(raw.linkId, 40),
      skuId: text(raw.skuId, 120),
      skuCode: text(raw.skuCode, 80),
      variant: text(raw.variant, 100),
      variantName: text(raw.variantName, 180),
      imageIndex: Math.max(1, Number(raw.imageIndex) || 1),
      ratio: text(raw.ratio, 20),
      resolution: text(raw.resolution, 20),
      provider: text(raw.provider, 80),
      imageModel: text(raw.imageModel, 120),
      prompt: text(raw.prompt, 30000),
      negativePrompt: text(raw.negativePrompt, 8000),
      promptBatchId: text(raw.promptBatchId, 260),
      parentResultId: text(raw.parentResultId, 260),
      parentBatchId: text(raw.parentBatchId, 260),
      guideOriginBatchId: text(raw.guideOriginBatchId, 260),
      taskId: text(raw.taskId, 180),
      createdAt: Math.max(1, Number(raw.createdAt) || Date.now())
    };
  }

  function saveResult(raw, options) {
    options = options || {};
    var safe = sanitizeArchiveInput(raw);
    return sourceToBlob(raw && (raw.blob || raw.url), options.fetch).then(function (blob) {
      return transaction([BATCH_STORE, ASSET_STORE], 'readwrite', function (stores, fail) {
        var batchRequest = stores[BATCH_STORE].get(safe.archiveBatchId);
        batchRequest.onerror = function () { fail(batchRequest.error || new Error('读取档案批次失败')); };
        batchRequest.onsuccess = function () {
          var existing = batchRequest.result || {};
          stores[BATCH_STORE].put({
            archiveBatchId: safe.archiveBatchId,
            accountKey: safe.accountKey,
            surfaceMode: safe.surfaceMode,
            creativeRoute: safe.creativeRoute,
            detailMode: safe.detailMode,
            sourceBatchId: safe.sourceBatchId,
            technicalSourceBatchId: existing.technicalSourceBatchId || safe.technicalSourceBatchId,
            archiveProjectId: safe.archiveProjectId || existing.archiveProjectId || '',
            batchTitle: safe.businessBatchTitle || existing.businessBatchTitle || existing.batchTitle || safe.batchTitle,
            businessBatchTitle: safe.businessBatchTitle || existing.businessBatchTitle || '',
            businessType: safe.businessType || existing.businessType || '',
            productName: safe.productName || existing.productName || '',
            styleName: safe.styleName || existing.styleName || '',
            strengthName: safe.strengthName || existing.strengthName || '',
            copyModeName: safe.copyModeName || existing.copyModeName || '',
            linkId: existing.linkId || safe.linkId,
            skuId: existing.skuId || safe.skuId,
            provider: existing.provider || safe.provider,
            imageModel: existing.imageModel || safe.imageModel,
            ratio: existing.ratio || safe.ratio,
            resolution: existing.resolution || safe.resolution,
            createdAt: Number(existing.createdAt) || safe.createdAt,
            updatedAt: Date.now()
          });
          stores[ASSET_STORE].put(Object.assign({}, safe, {
            blob: blob,
            mimeType: allowedMime(blob.type),
            size: Number(blob.size) || 0,
            deletedAt: 0,
            purgeAt: 0,
            updatedAt: Date.now()
          }));
        };
        return function () { return Object.assign({}, safe, { size: blob.size, mimeType: blob.type }); };
      });
    });
  }

  function recordsForAccount(accountKey) {
    var output = { batches: [], assets: [] };
    return transaction([BATCH_STORE, ASSET_STORE], 'readonly', function (stores, fail) {
      var batchRequest = stores[BATCH_STORE].index('accountKey').getAll(accountKey);
      var assetRequest = stores[ASSET_STORE].index('accountKey').getAll(accountKey);
      batchRequest.onsuccess = function () { output.batches = batchRequest.result || []; };
      assetRequest.onsuccess = function () { output.assets = assetRequest.result || []; };
      batchRequest.onerror = function () { fail(batchRequest.error || new Error('读取档案批次失败')); };
      assetRequest.onerror = function () { fail(assetRequest.error || new Error('读取档案图片失败')); };
      return function () { return output; };
    });
  }

  function permanentlyRemove(accountKey, assetIds) {
    accountKey = normalizeAccountKey(accountKey);
    var selected = {};
    (assetIds || []).forEach(function (id) { if (id) selected[String(id)] = true; });
    if (!Object.keys(selected).length) return Promise.resolve({ removed: 0 });
    var removed = 0;
    return transaction([ASSET_STORE], 'readwrite', function (stores, fail) {
      Object.keys(selected).forEach(function (id) {
        var request = stores[ASSET_STORE].get(id);
        request.onerror = function () { fail(request.error || new Error('读取待删除档案失败')); };
        request.onsuccess = function () {
          var record = request.result;
          if (!record || normalizeAccountKey(record.accountKey) !== accountKey) return;
          stores[ASSET_STORE].delete(id);
          removed++;
        };
      });
      return function () { return { removed: removed }; };
    }).then(function (result) {
      return removeEmptyBatches(accountKey).then(function () { return result; });
    });
  }

  function removeEmptyBatches(accountKey) {
    accountKey = normalizeAccountKey(accountKey);
    return recordsForAccount(accountKey).then(function (records) {
      var occupied = {};
      records.assets.forEach(function (asset) { occupied[asset.archiveBatchId] = true; });
      var empty = records.batches.filter(function (batch) { return !occupied[batch.archiveBatchId]; });
      if (!empty.length) return { removed: 0 };
      return transaction([BATCH_STORE], 'readwrite', function (stores) {
        empty.forEach(function (batch) { stores[BATCH_STORE].delete(batch.archiveBatchId); });
        return { removed: empty.length };
      });
    });
  }

  function mutateTrash(accountKey, assetIds, deleted) {
    accountKey = normalizeAccountKey(accountKey);
    var selected = {};
    (assetIds || []).forEach(function (id) { if (id) selected[String(id)] = true; });
    var changed = 0;
    var now = Date.now();
    return transaction([ASSET_STORE], 'readwrite', function (stores, fail) {
      Object.keys(selected).forEach(function (id) {
        var request = stores[ASSET_STORE].get(id);
        request.onerror = function () { fail(request.error || new Error('读取回收站档案失败')); };
        request.onsuccess = function () {
          var record = request.result;
          if (!record || normalizeAccountKey(record.accountKey) !== accountKey) return;
          record.deletedAt = deleted ? now : 0;
          record.purgeAt = deleted ? (now + RETENTION_MS) : 0;
          record.updatedAt = now;
          stores[ASSET_STORE].put(record);
          changed++;
        };
      });
      return function () { return { changed: changed, deleted: !!deleted, purgeAt: deleted ? now + RETENTION_MS : 0 }; };
    });
  }

  function moveToTrash(accountKey, assetIds) { return mutateTrash(accountKey, assetIds, true); }
  function restore(accountKey, assetIds) { return mutateTrash(accountKey, assetIds, false); }

  function purgeExpired(accountKey, now) {
    accountKey = normalizeAccountKey(accountKey);
    now = Number(now) || Date.now();
    return recordsForAccount(accountKey).then(function (records) {
      var expired = records.assets.filter(function (asset) {
        return Number(asset.deletedAt) > 0 && Number(asset.purgeAt) > 0 && Number(asset.purgeAt) <= now;
      }).map(function (asset) { return asset.archiveAssetId; });
      return permanentlyRemove(accountKey, expired).then(function () { return { removed: expired.length }; });
    });
  }

  function purgeAllExpired(now) {
    now = Number(now) || Date.now();
    var accountKeys = {};
    var removed = 0;
    return transaction([ASSET_STORE], 'readwrite', function (stores, fail) {
      var request = stores[ASSET_STORE].getAll();
      request.onerror = function () { fail(request.error || new Error('读取超期档案失败')); };
      request.onsuccess = function () {
        (request.result || []).forEach(function (asset) {
          if (!(Number(asset.deletedAt) > 0 && Number(asset.purgeAt) > 0 && Number(asset.purgeAt) <= now)) return;
          stores[ASSET_STORE].delete(asset.archiveAssetId);
          accountKeys[normalizeAccountKey(asset.accountKey)] = true;
          removed++;
        });
      };
      return function () { return { removed: removed, accountKeys: Object.keys(accountKeys) }; };
    }).then(function (result) {
      return Promise.all(result.accountKeys.map(removeEmptyBatches)).then(function () { return { removed: result.removed }; });
    });
  }

  function styleMetaFromLegacyPrompt(asset) {
    if (!asset || asset.creativeRoute !== 'style-refresh') return {};
    var prompt = String(asset.prompt || '');
    var styleMatch = /所选风格[:：]\s*([^\/\n。]+)/.exec(prompt);
    var strengthMatch = /创意强度[:：]\s*([^，,\n。]+)/.exec(prompt);
    var planMatch = /Use this image-specific refresh plan exactly:\s*\n([\s\S]*?)\nSTYLE REFRESH CONTRACT/.exec(prompt);
    var lines = planMatch ? planMatch[1].split(/\r?\n/).map(function (line) { return line.trim(); }).filter(Boolean) : [];
    var task = lines[3] || '';
    var colon = task.search(/[:：]/);
    var productName = colon > 0 && colon <= 40 ? text(task.slice(0, colon), 180) : '';
    var direction = text(lines[0], 180);
    var styleName = text(styleMatch && styleMatch[1], 100) || (lines[1] && text(lines[1].split(/[:：]/)[0], 100));
    var strengthName = text(strengthMatch && strengthMatch[1], 80) || text(lines[2], 80);
    var copyModeName = /用户选择不要文案/.test(prompt) ? '不要文案' : (/用户选择修改已有文案/.test(prompt) ? '修改已有文案' : (/用户选择生成新文案/.test(prompt) ? '生成新文案' : ''));
    return {
      productName: productName,
      styleName: styleName,
      strengthName: strengthName,
      copyModeName: copyModeName,
      businessSummary: [direction, task].filter(Boolean).join(' · ')
    };
  }

  function projectArchiveRecords(records, options) {
    records = records || {};
    options = options || {};
    var missing = [];
    var batchById = {};
    var resultById = {};
    var validAssets = [];
    (records.batches || []).forEach(function (batch) {
      if (batch && batch.archiveBatchId) batchById[batch.archiveBatchId] = batch;
    });
    (records.assets || []).forEach(function (asset) {
      if (!validBlob(asset && asset.blob)) {
        if (asset && asset.archiveAssetId) missing.push(asset.archiveAssetId);
        return;
      }
      validAssets.push(asset);
      if (asset.resultId) resultById[asset.resultId] = asset;
    });

    function rootAsset(asset) {
      var current = asset;
      var seen = {};
      while (current && current.parentResultId && resultById[current.parentResultId] && !seen[current.parentResultId]) {
        seen[current.parentResultId] = true;
        current = resultById[current.parentResultId];
      }
      return current || asset;
    }

    var roleVersions = {};
    validAssets.slice().sort(function (a, b) {
      return Number(a.createdAt) - Number(b.createdAt) || String(a.archiveAssetId || '').localeCompare(String(b.archiveAssetId || ''));
    }).forEach(function (asset) {
      var root = rootAsset(asset);
      var legacy = styleMetaFromLegacyPrompt(root);
      var legacyProjectId = legacy.productName && legacy.styleName
        ? ('legacy_style_project_' + hashText([legacy.productName, legacy.styleName, legacy.strengthName, legacy.copyModeName].join('|')))
        : '';
      var numberedProjectSeed = numberedLinkSurface(root)
        ? (root.technicalSourceBatchId || root.promptBatchId || root.sourceBatchId || root.archiveProjectId || root.archiveBatchId)
        : '';
      // 旧版可能把同一次 L001-L030 批量生产显示成“主图 · L001”。读取时使用
      // 原始生成批次重新投影，不改写 Blob，也不把不同生成批次混在一起。
      var explicitNumberedProjectId = /^numbered_link_project_/.test(String(asset.archiveProjectId || ''))
        ? asset.archiveProjectId
        : (/^numbered_link_project_/.test(String(root.archiveProjectId || '')) ? root.archiveProjectId : '');
      var numberedProjectId = explicitNumberedProjectId || (numberedProjectSeed
        ? ('numbered_link_project_' + hashText([root.accountKey || '', root.surfaceMode || '', numberedProjectSeed].join('|')))
        : '');
      var projectId = numberedProjectId || asset.archiveProjectId || root.archiveProjectId || legacyProjectId || root.archiveBatchId || asset.archiveBatchId;
      var roleName = text(asset.businessRoleName || asset.variantName || asset.skuCode || '生成图', 180).replace(/\s*引导重生.*$/, '') || '生成图';
      var roleKey = asset.businessRoleKey || ((Number(asset.imageIndex) || 1) + '|' + roleName);
      var linkId = canonicalArchiveLinkId(root.linkId || asset.linkId);
      if (numberedProjectId && linkId) roleKey = linkId + '|' + (Number(asset.imageIndex) || 1) + '|' + roleName;
      var versionKey = projectId + '|' + roleKey;
      roleVersions[versionKey] = (roleVersions[versionKey] || 0) + 1;
      asset._archiveProjection = {
        projectId: projectId,
        rootBatchId: root.archiveBatchId || asset.archiveBatchId,
        roleName: roleName,
        roleKey: roleKey,
        versionIndex: roleVersions[versionKey]
      };
    });

    var groups = {};
    validAssets.forEach(function (sourceAsset) {
      var trashed = Number(sourceAsset.deletedAt) > 0;
      if (!!options.trash !== trashed) return;
      var projection = sourceAsset._archiveProjection || {};
      var groupKey = '$' + (projection.projectId || sourceAsset.archiveBatchId);
      if (!groups[groupKey]) {
        var sourceBatch = batchById[projection.rootBatchId] || batchById[sourceAsset.archiveBatchId] || {};
        groups[groupKey] = Object.assign({}, sourceBatch, {
          archiveBatchId: sourceBatch.archiveBatchId || projection.rootBatchId || sourceAsset.archiveBatchId,
          archiveProjectId: projection.projectId || sourceAsset.archiveProjectId || '',
          assets: []
        });
      }
      var asset = Object.assign({}, sourceAsset, {
        archiveProjectId: projection.projectId || sourceAsset.archiveProjectId || '',
        businessRoleKey: projection.roleKey || sourceAsset.businessRoleKey || '',
        businessRoleName: sourceAsset.businessRoleName || projection.roleName || sourceAsset.variantName || '',
        versionIndex: projection.versionIndex || 1,
        generationKind: sourceAsset.generationKind || (sourceAsset.parentResultId ? 'guide' : 'original')
      });
      var displayLinkId = canonicalArchiveLinkId(asset.linkId);
      asset.businessDisplayName = (displayLinkId ? (displayLinkId + (asset.businessRoleName && asset.businessRoleName !== displayLinkId ? ' · ' + asset.businessRoleName : '')) : asset.businessRoleName) + ' · V' + asset.versionIndex;
      groups[groupKey].assets.push(asset);
    });
    validAssets.forEach(function (asset) { try { delete asset._archiveProjection; } catch (_) {} });

    var batches = Object.keys(groups).map(function (key) {
      var batch = groups[key];
      batch.assets.sort(function (a, b) {
        var aLink = canonicalArchiveLinkId(a.linkId);
        var bLink = canonicalArchiveLinkId(b.linkId);
        return Number(aLink && aLink.slice(1)) - Number(bLink && bLink.slice(1)) ||
          Number(a.imageIndex) - Number(b.imageIndex) || Number(a.versionIndex) - Number(b.versionIndex) || Number(a.createdAt) - Number(b.createdAt);
      });
      var businessAsset = batch.assets.find(function (asset) { return asset.businessBatchTitle || asset.productName || asset.styleName; }) || batch.assets[0] || {};
      var inferred = styleMetaFromLegacyPrompt(businessAsset);
      batch.businessType = batch.businessType || businessAsset.businessType || '';
      batch.productName = batch.productName || businessAsset.productName || inferred.productName || '';
      batch.styleName = batch.styleName || businessAsset.styleName || inferred.styleName || '';
      batch.strengthName = batch.strengthName || businessAsset.strengthName || inferred.strengthName || '';
      batch.copyModeName = batch.copyModeName || businessAsset.copyModeName || inferred.copyModeName || '';
      batch.businessBatchTitle = batch.businessBatchTitle || businessAsset.businessBatchTitle || '';
      var numberedIds = archiveLinkIds(batch.assets.filter(numberedLinkSurface).map(function (asset) { return asset.linkId; }));
      if (numberedIds.length && (batch.surfaceMode === 'main' || batch.surfaceMode === 'detail')) {
        batch.linkIds = numberedIds;
        batch.linkRange = archiveLinkRangeLabel(numberedIds);
        batch.businessBatchTitle = (batch.surfaceMode === 'detail' ? '详情页' : '主图') + ' · ' + batch.linkRange;
      }
      if (!batch.businessBatchTitle && batch.creativeRoute === 'style-refresh') {
        batch.businessBatchTitle = ['风格焕新', batch.productName, batch.styleName].filter(Boolean).join(' · ') || '风格焕新 · 共创方案';
      }
      batch.batchTitle = batch.businessBatchTitle || batch.batchTitle || '本机生图档案';
      batch.assets.forEach(function (asset) {
        var assetInferred = styleMetaFromLegacyPrompt(asset);
        if (!asset.businessSummary && assetInferred.businessSummary && asset.creativeRoute === 'style-refresh') asset.businessSummary = assetInferred.businessSummary;
      });
      var roles = {};
      batch.assets.forEach(function (asset) { roles[asset.businessRoleKey || ((asset.imageIndex || 1) + '|' + asset.businessRoleName)] = true; });
      batch.screenCount = Object.keys(roles).length;
      batch.assetCount = batch.assets.length;
      batch.versionCount = batch.assets.length;
      batch.totalBytes = batch.assets.reduce(function (sum, asset) { return sum + (Number(asset.size) || 0); }, 0);
      batch.updatedAt = Math.max(Number(batch.updatedAt) || 0, batch.assets.reduce(function (latest, asset) { return Math.max(latest, Number(asset.updatedAt) || Number(asset.createdAt) || 0); }, 0));
      return batch;
    });
    batches.sort(function (a, b) { return Number(b.updatedAt) - Number(a.updatedAt); });
    return { batches: batches, missing: missing };
  }

  function list(accountKey, options) {
    accountKey = normalizeAccountKey(accountKey);
    options = options || {};
    var ready = options.skipPurge ? Promise.resolve({ removed: 0 }) : purgeExpired(accountKey, options.now);
    return ready.then(function () {
      return recordsForAccount(accountKey);
    }).then(function (records) {
      var projected = projectArchiveRecords(records, options);
      var cleanup = projected.missing.length ? permanentlyRemove(accountKey, projected.missing) : Promise.resolve({ removed: 0 });
      return cleanup.then(function () { return projected.batches; });
    });
  }

  function summary(accountKey) {
    return Promise.all([list(accountKey, { trash: false }), list(accountKey, { trash: true })]).then(function (parts) {
      var active = parts[0], trash = parts[1];
      return {
        activeBatches: active.length,
        activeAssets: active.reduce(function (sum, batch) { return sum + batch.assets.length; }, 0),
        trashAssets: trash.reduce(function (sum, batch) { return sum + batch.assets.length; }, 0),
        bytes: active.concat(trash).reduce(function (sum, batch) { return sum + batch.totalBytes; }, 0)
      };
    });
  }

  return Object.freeze({
    DB_NAME: DB_NAME,
    RETENTION_MS: RETENTION_MS,
    normalizeAccountKey: normalizeAccountKey,
    sanitizeArchiveInput: sanitizeArchiveInput,
    projectArchiveRecords: projectArchiveRecords,
    dataUrlToBlob: dataUrlToBlob,
    sourceToBlob: sourceToBlob,
    saveResult: saveResult,
    list: list,
    summary: summary,
    moveToTrash: moveToTrash,
    restore: restore,
    permanentlyRemove: permanentlyRemove,
    purgeExpired: purgeExpired,
    purgeAllExpired: purgeAllExpired
  });
});
