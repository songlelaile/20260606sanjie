(() => {
  "use strict";

  const engine = globalThis.DmpReportEngine;
  const workflow = globalThis.DmpWorkflowEngine;
  const xlsxWriter = globalThis.DmpXlsxWriter;
  if (!engine || !workflow || !xlsxWriter) return;

  const records = [];
  let currentJob = null;
  let lastRecordAt = 0;
  let collapsed = false;
  let siteAuthorized = false;

  const root = document.createElement("section");
  root.id = "dmp-cdp-monitor";
  root.style.cssText = "position:fixed;right:14px;bottom:14px;z-index:2147483647";
  const shadow = root.attachShadow({ mode: "open" });
  shadow.innerHTML = `
    <style>
      :host { all: initial; }
      * { box-sizing: border-box; }
      .panel { width:min(680px,calc(100vw - 28px)); max-height:78vh; overflow:hidden; color:#eaf7eb; background:#07130a; border:1px solid #4f8b58; border-radius:12px; box-shadow:0 16px 44px rgba(0,0,0,.42); font:12px/1.45 -apple-system,BlinkMacSystemFont,"PingFang SC","Segoe UI",sans-serif; }
      header { display:grid; grid-template-columns:minmax(0,1fr) auto auto auto; align-items:center; gap:8px; padding:10px 12px; background:#102516; border-bottom:1px solid #315a38; }
      header strong { font-size:14px; white-space:nowrap; }
      .header-main { display:flex; align-items:center; gap:8px; min-width:0; overflow:hidden; }
      .status { color:#ffd66b; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
      .count { color:#9ed7a6; white-space:nowrap; }
      button { border:0; border-radius:6px; cursor:pointer; font:inherit; }
      button:disabled { opacity:.45; cursor:not-allowed; }
      .collapse { min-width:26px; padding:3px 7px; background:#24472b; color:#fff; }
      .settings { min-width:26px; padding:3px 7px; background:#24472b; color:#fff; }
      .body { max-height:calc(78vh - 44px); overflow:auto; }
      .task { padding:12px; border-bottom:1px solid #315a38; background:#0b1c0f; }
      .task-row { display:grid; grid-template-columns:minmax(0,1fr) auto; gap:8px; }
      .task-inputs { display:grid; gap:6px; }
      .input-line { display:grid; grid-template-columns:116px minmax(0,1fr); align-items:center; gap:7px; }
      .input-line > span { color:#a8cdae; white-space:nowrap; }
      input { width:100%; min-width:0; padding:8px 10px; color:#f4fff5; background:#07130a; border:1px solid #4f8b58; border-radius:6px; outline:none; font:13px/1.3 ui-monospace,SFMono-Regular,Menlo,monospace; }
      input:focus { border-color:#8fc99a; box-shadow:0 0 0 2px rgba(143,201,154,.15); }
      .run { padding:8px 15px; background:#208548; color:#fff; font-weight:700; white-space:nowrap; }
      .task-meta { display:flex; gap:7px; align-items:center; flex-wrap:wrap; margin-top:8px; color:#afd5b5; }
      .pill { padding:2px 7px; border-radius:999px; background:#193e25; color:#bce8c4; }
      .pill.warn { background:#5a4315; color:#ffe294; }
      .pill.bad { background:#5e2828; color:#ffb3b3; }
      .progress { height:5px; margin-top:9px; overflow:hidden; background:#18311d; border-radius:999px; }
      .progress > i { display:block; width:0; height:100%; background:linear-gradient(90deg,#2ea35b,#8ed09d); transition:width .25s ease; }
      .downloads { display:flex; gap:7px; margin-top:10px; }
      .downloads button { flex:1; padding:6px 8px; color:#fff; background:#24472b; }
      .downloads .primary { background:#1c6b35; }
      .preview { padding:10px 12px 12px; }
      .preview-head { display:flex; align-items:center; justify-content:space-between; gap:8px; margin-bottom:7px; }
      .preview-head strong { font-size:13px; }
      .preview-head select { min-width:150px; max-width:230px; padding:4px 7px; color:#eaf7eb; background:#132c19; border:1px solid #4f8b58; border-radius:5px; font:inherit; }
      .quality { color:#9ed7a6; }
      .table-wrap { max-height:280px; overflow:auto; border:1px solid #315a38; border-radius:7px; background:#0a190d; }
      table { width:100%; border-collapse:separate; border-spacing:0; color:#dcefe0; font-size:11px; }
      th { position:sticky; top:0; z-index:1; padding:7px 8px; text-align:left; white-space:nowrap; color:#fff; background:#1f6b49; }
      td { max-width:220px; padding:6px 8px; vertical-align:top; border-bottom:1px solid #183d23; word-break:break-word; }
      tbody tr:nth-child(even) td { background:#0d2112; }
      .empty { padding:24px 12px; color:#8fb095; text-align:center; }
      details.raw { border-top:1px solid #315a38; }
      details.raw > summary { padding:9px 12px; cursor:pointer; color:#afd5b5; background:#0b1c0f; }
      .toolbar { display:flex; gap:7px; padding:8px 12px; background:#0b1c0f; border-top:1px solid #183d23; }
      .toolbar button { flex:1; padding:5px 7px; background:#24472b; color:#fff; transition:background .2s ease, transform .2s ease, color .2s ease; }
      .toolbar .danger { background:#672f2f; }
      .toolbar button.ok { background:#1c6b35; color:#d9f5e0; }
      .toolbar button.bad { background:#8a2f2f; color:#ffd9d3; }
      @keyframes copyPulse { 0% { transform:scale(1); } 45% { transform:scale(1.08); } 100% { transform:scale(1); } }
      .toolbar button.pulse { animation: copyPulse .4s ease; }
      .record-list { max-height:180px; overflow:auto; padding:7px; }
      .record { padding:5px 7px; margin-bottom:5px; color:#cde9d1; background:#0e2113; border-radius:5px; word-break:break-all; }
      .hint { margin-top:7px; color:#7fa787; }
    </style>
    <div class="panel">
      <header>
        <div class="header-main"><strong>少壮达摩盘取数自动化 v0.9.16</strong><span class="status" data-role="status">等待运行</span></div>
        <span class="count" data-role="count">0 条</span>
        <button class="settings" data-role="settings" title="ChatGPT API 设置">⚙</button>
        <button class="collapse" data-role="collapse" title="收起/展开">—</button>
      </header>
      <div class="body" data-role="body">
        <section class="task">
          <div class="task-row">
            <div class="task-inputs">
              <label class="input-line"><span>本店主体商品 ID</span><input data-role="subject-item-id" inputmode="numeric" autocomplete="off" placeholder="有权限且近30天有销量" /></label>
              <label class="input-line"><span>成功品/竞品 ID</span><input data-role="success-item-id" inputmode="numeric" autocomplete="off" placeholder="要添加并对比的商品" /></label>
            </div>
            <button class="run" data-role="run">一键运行</button>
          </div>
          <div class="task-meta">
            <span class="pill">默认近30天</span>
            <span class="pill warn" data-role="site-state">官网检测中</span>
            <span class="pill" data-role="ai-state">API 待检测</span>
            <span class="pill" data-role="job-state">等待主体/竞品 ID</span>
            <span data-role="step">自动取得成功品并采集三个对比页签</span>
          </div>
          <div class="progress"><i data-role="progress"></i></div>
          <div class="downloads">
            <button class="primary" data-role="download-excel" disabled>下载 XLSX 报告</button>
            <button data-role="download-csv" disabled>下载 CSV</button>
            <button data-role="copy-report" disabled>复制业务数据 JSON</button>
          </div>
          <div class="hint">工作簿严格输出参考模板的 11 个页签、公式、原生表格和两张图表；数值由插件本地规则引擎计算。</div>
        </section>
        <section class="preview">
          <div class="preview-head"><strong>业务表格预览</strong><select data-role="preview-table" disabled><option>尚未生成</option></select><span class="quality" data-role="quality">尚未生成</span></div>
          <div class="table-wrap" data-role="preview-wrap"><div class="empty">输入商品 ID 后点击“一键运行”</div></div>
        </section>
        <details class="raw">
          <summary>监听记录（内部核验）</summary>
          <div class="toolbar">
            <button data-role="start">启动/重连监听</button>
            <button data-role="copy-records">复制本次记录</button>
            <button data-role="download-records">下载记录 JSON</button>
            <button class="danger" data-role="clear">清空全部记录</button>
          </div>
          <div class="record-list" data-role="record-list"></div>
        </details>
      </div>
    </div>
  `;

  function mount() {
    if (document.documentElement && !document.getElementById(root.id)) document.documentElement.appendChild(root);
  }
  mount();
  if (!root.isConnected) document.addEventListener("DOMContentLoaded", mount, { once: true });

  const $ = role => shadow.querySelector(`[data-role="${role}"]`);
  const ui = {
    body: $("body"), status: $("status"), count: $("count"), collapse: $("collapse"), settings: $("settings"),
    subjectItemId: $("subject-item-id"), successItemId: $("success-item-id"), run: $("run"),
    jobState: $("job-state"), step: $("step"), progress: $("progress"), downloadExcel: $("download-excel"),
    downloadCsv: $("download-csv"), copyReport: $("copy-report"), quality: $("quality"), previewTable: $("preview-table"), aiState: $("ai-state"), siteState: $("site-state"), previewWrap: $("preview-wrap"),
    recordList: $("record-list"), start: $("start"), copyRecords: $("copy-records"), downloadRecords: $("download-records"), clear: $("clear")
  };

  function runtimeMessage(type, payload = {}) {
    return chrome.runtime.sendMessage({ type, ...payload });
  }

  function setStatus(message, color = "#ffd66b") {
    ui.status.textContent = message;
    ui.status.style.color = color;
  }

  function setStep(message, progress, state = "运行中", stateClass = "") {
    ui.step.textContent = message;
    ui.progress.style.width = `${Math.max(0, Math.min(100, progress || 0))}%`;
    ui.jobState.textContent = state;
    ui.jobState.className = `pill ${stateClass}`.trim();
    if (currentJob) {
      currentJob.step = message;
      currentJob.progress = progress;
      currentJob.statusLabel = state;
    }
  }

  async function refreshSiteStatus() {
    const result = await runtimeMessage("DMP_CDP_AUTH_CHECK").catch(() => null);
    siteAuthorized = Boolean(result?.ok);
    if (siteAuthorized) {
      const name = result.user?.name || result.user?.username || "已登录";
      ui.siteState.textContent = `官网在线 · ${name}`;
      ui.siteState.className = "pill";
    } else {
      ui.siteState.textContent = result?.reason === "nologin" || result?.reason === "invalid" ? "官网未登录" : "官网离线";
      ui.siteState.className = "pill bad";
      if (!currentJob || currentJob.status !== "running") setStatus(result?.error || "官网在线校验失败，插件已锁定", "#ff9d9d");
    }
    if (!currentJob || currentJob.status !== "running") ui.run.disabled = !siteAuthorized;
    return siteAuthorized;
  }

  async function refreshAiStatus() {
    const configResult = await runtimeMessage("DMP_CDP_GET_AI_CONFIG");
    if (!configResult?.ok || configResult.config.enabled === false) {
      ui.aiState.textContent = configResult?.ok ? "API 未启用" : "API 配置不可用";
      ui.aiState.className = "pill warn";
      return;
    }
    const healthResult = await runtimeMessage("DMP_CDP_AI_HEALTH");
    ui.aiState.textContent = healthResult?.ok ? `API 就绪 · ${healthResult.health.model}` : "API 未启动";
    ui.aiState.className = `pill ${healthResult?.ok ? "" : "warn"}`.trim();
  }

  // 深度解析的四类错误对应的中文标签。按 API 工作指令固定这四种说法，
  // 不要笼统成"API 失败"——排障时要一眼看出是哪一环坏了。
  const ANALYSIS_ERROR_LABEL = {
    NO_JSON: "没获取到 JSON",
    PARSE_FAILED: "解析失败",
    CALC_FAILED: "计算错误",
    API_FAILED: "API 失败"
  };

  function analysisErrorLabel(code) {
    return ANALYSIS_ERROR_LABEL[code] || "API 失败";
  }

  async function persistJob() {
    if (!currentJob) return;
    const result = await runtimeMessage("DMP_CDP_SAVE_JOB", { job: currentJob });
    if (!result?.ok) throw new Error(result?.error || "任务保存失败");
  }

  function recordIdentity(record) {
    return [record.requestId, record.capturedAt, record.kind, record.source, record.pathname || record.url].join("|");
  }

  function mergeRecords(incoming) {
    const known = new Set(records.map(recordIdentity));
    for (const record of incoming || []) {
      const key = recordIdentity(record);
      if (known.has(key)) continue;
      known.add(key);
      records.push(record);
    }
    records.sort((a, b) => String(a.capturedAt || "").localeCompare(String(b.capturedAt || "")));
    ui.count.textContent = `${records.length} 条`;
    renderRecentRecords();
  }

  function renderRecentRecords() {
    ui.recordList.replaceChildren();
    const fragment = document.createDocumentFragment();
    records.slice(-30).reverse().forEach(record => {
      const div = document.createElement("div");
      div.className = "record";
      let target = record.pathname || (() => { try { return new URL(record.url).pathname; } catch { return record.url || ""; } })();
      if (!target && record.kind === "RuntimeException") {
        let detail = record.text || "";
        try {
          const parsed = JSON.parse(record.body || "{}");
          detail = parsed.exception || parsed.text || detail;
        } catch {}
        target = detail ? `异常：${String(detail).slice(0, 240)}` : "页面脚本异常（详情见复制记录）";
      }
      if (!target) target = record.source || "内部事件";
      div.textContent = `${record.status ?? ""} [${record.kind || record.type || record.source || "数据"}] ${record.method || ""} ${target}`.trim();
      fragment.appendChild(div);
    });
    ui.recordList.appendChild(fragment);
  }

  function normalizeText(value) {
    return workflow.normalizeText(value);
  }

  function accessibleDocuments() {
    const documents = [];
    const queue = [document];
    const visited = new Set();
    while (queue.length) {
      const current = queue.shift();
      if (!current || visited.has(current)) continue;
      visited.add(current);
      documents.push(current);
      let frames = [];
      try { frames = Array.from(current.querySelectorAll("iframe,frame")); } catch { frames = []; }
      for (const frame of frames) {
        try {
          if (frame.contentDocument?.documentElement) queue.push(frame.contentDocument);
        } catch { /* 跨源子页面不能由顶层内容脚本读取。 */ }
      }
    }
    return documents;
  }

  function queryElements(scope, selector) {
    const scopes = scope === document ? accessibleDocuments() : [scope];
    return scopes.flatMap(current => {
      try { return Array.from(current.querySelectorAll(selector)); }
      catch { return []; }
    });
  }

  function isVisible(element) {
    if (!element || element.nodeType !== 1 || element.closest?.("#dmp-cdp-monitor")) return false;
    const view = element.ownerDocument?.defaultView || window;
    const style = view.getComputedStyle(element);
    return style.visibility !== "hidden" && style.display !== "none" && element.getClientRects().length > 0;
  }

  function pageClickTarget(element) {
    return element.closest("button,[role='button'],[role='tab'],[role='option'],[role='radio'],[role='checkbox'],a,label,li,[tabindex],.next-select,.ant-select,.next-menu-item,.ant-select-item") || element;
  }

  function elementLabels(element) {
    return [element.textContent, element.getAttribute?.("aria-label"), element.getAttribute?.("title")]
      .map(normalizeText)
      .filter(Boolean);
  }

  function findVisibleText(patterns, scope = document, selector = "button,[role='button'],[role='tab'],[role='option'],[role='radio'],[role='checkbox'],a,label,li,span,div,[aria-label],[title]") {
    const candidates = queryElements(scope, selector).filter(isVisible);
    for (const pattern of patterns) {
      const found = candidates.find(element => {
        return elementLabels(element).some(text => {
          pattern.lastIndex = 0;
          return text.length <= 80 && pattern.test(text);
        });
      });
      if (found) return pageClickTarget(found);
    }
    return null;
  }

  async function waitForVisible(factory, timeoutMs = 7000) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      const found = factory();
      if (found) return found;
      await wait(200);
    }
    return null;
  }

  const SUCCESS_LOAD_PATH = "/api/goods/grow/define/success/load";
  const SUCCESS_LIST_PATH = "/api/goods/grow/define/success/item/list";

  function hasSuccessProductRecord(itemId, since) {
    return records.some(record => {
      if (since && record.capturedAt && record.capturedAt < since) return false;
      const path = record.pathname || record.url || "";
      return path.includes(SUCCESS_LOAD_PATH) && typeof record.body === "string" && record.body.includes(itemId);
    });
  }

  function fillPageInput(input, value) {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
    if (setter) setter.call(input, value);
    else input.value = value;
    input.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: value }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function selectedState(element) {
    const checkbox = element.matches("input[type='checkbox'],input[type='radio']") ? element : element.querySelector("input[type='checkbox'],input[type='radio']");
    if (checkbox) return checkbox.checked;
    for (const name of ["aria-checked", "aria-selected"]) {
      const value = element.getAttribute(name);
      if (value === "true") return true;
      if (value === "false") return false;
    }
    const classes = `${element.className || ""} ${element.parentElement?.className || ""}`;
    if (/(^|\s)(selected|checked|active)(\s|$)|-selected|-checked|is-selected|is-checked/i.test(classes)) return true;
    return null;
  }

  function findSuccessDialog() {
    // 策略1：锚点法。遍历所有元素（主文档 + 可访问 iframe），找含“已选成功品”的最小元素，向上找面板容器。
    const anchors = [];
    for (const doc of accessibleDocuments()) {
      for (const el of doc.querySelectorAll("*")) {
        if (el.closest?.("#dmp-cdp-monitor")) continue;
        const text = el.textContent || "";
        if (text.length > 200) continue;
        if (text.includes("已选成功品")) anchors.push(el);
      }
    }
    anchors.sort((a, b) => (a.textContent || "").length - (b.textContent || "").length);
    for (const anchor of anchors) {
      let node = anchor;
      while (node && node.nodeType === 1 && node !== document.documentElement) {
        const text = normalizeText(node.textContent);
        if (/成功品列表|所有商品/.test(text) && /已选成功品/.test(text)) return node;
        node = node.parentElement;
      }
    }
    // 策略2：找对话框容器（含达摩盘 mx-dialog）。
    const dialogs = queryElements(document, "[role='dialog'],.mx-dialog,.next-dialog,.ant-modal,.ant-drawer,.ant-modal-wrap,.next-overlay-wrapper,body > div")
      .filter(element => !element.closest?.("#dmp-cdp-monitor"))
      .filter(element => /成功品/.test(normalizeText(element.textContent)))
      .sort((a, b) => normalizeText(a.textContent).length - normalizeText(b.textContent).length);
    return dialogs[0] || null;
  }

  function successEntryCandidates() {
    const labels = workflow.SUCCESS_ENTRY_LABELS || ["取得成功品", "获取成功品", "定制成功品", "选择成功品"];
    const exactOrder = new Map(labels.map((label, index) => [normalizeText(label), index]));
    const candidates = queryElements(document, "button,[role='button'],a,label,li,span,div,[aria-label],[title]")
      .filter(isVisible)
      .map(element => {
        const texts = elementLabels(element);
        const exactIndex = texts.reduce((best, text) => Math.min(best, exactOrder.get(text) ?? Number.MAX_SAFE_INTEGER), Number.MAX_SAFE_INTEGER);
        const related = texts.some(text => text.length <= 80 && /(取得|获取|定制|选择|设置|添加|切换|修改)成功品/.test(text));
        return { target: pageClickTarget(element), score: exactIndex !== Number.MAX_SAFE_INTEGER ? exactIndex : related ? labels.length + 1 : Number.MAX_SAFE_INTEGER };
      })
      .filter(candidate => candidate.score !== Number.MAX_SAFE_INTEGER)
      .sort((a, b) => a.score - b.score);
    const seen = new Set();
    return candidates.map(candidate => candidate.target).filter(target => {
      if (seen.has(target)) return false;
      seen.add(target);
      return true;
    });
  }

  function visibleSuccessTextSummary() {
    const values = queryElements(document, "button,[role='button'],a,label,li,span,div,[aria-label],[title]")
      .filter(isVisible)
      .flatMap(elementLabels)
      .filter(text => text.length <= 80 && text.includes("成功品"));
    return Array.from(new Set(values)).slice(0, 6);
  }

  function subjectAccessError(subjectItemId) {
    const messages = queryElements(document, "[role='alert'],.next-message,.ant-message,.next-notice,div,span")
      .filter(isVisible)
      .map(element => normalizeText(element.textContent))
      .filter(text => text.length <= 300 && (/无法查看单品洞察/.test(text) || (/无权访问|近30天无销量/.test(text) && text.includes(subjectItemId))))
      .sort((left, right) => left.length - right.length);
    return messages[0] || "";
  }

  async function openSuccessDialog(timeoutMs = 20_000) {
    const started = Date.now();
    const attempted = new Set();
    while (Date.now() - started < timeoutMs) {
      const existing = findSuccessDialog();
      if (existing) return existing;
      const candidate = successEntryCandidates().find(target => !attempted.has(target));
      if (candidate) {
        attempted.add(candidate);
        candidate.click();
        const opened = await waitForVisible(findSuccessDialog, 1600);
        if (opened) return opened;
      } else {
        await wait(250);
      }
    }
    return null;
  }

  function selectedSuccessArea(dialog) {
    const headers = queryElements(dialog, "div,section,aside,header,h1,h2,h3,span")
      .filter(isVisible)
      .filter(element => workflow.selectedSuccessCount(element.textContent) !== null)
      .sort((left, right) => normalizeText(left.textContent).length - normalizeText(right.textContent).length);
    let current = headers[0] || dialog;
    while (current && current !== dialog) {
      const controls = queryElements(current, "button,[role='button'],a,span,[aria-label],[title]")
        .filter(isVisible)
        .flatMap(elementLabels);
      if (controls.some(text => /^(全部删除|清空全部|全部移除|全部清除|移除|删除)$/.test(text))) return current;
      current = current.parentElement;
    }
    return dialog;
  }

  function selectedSuccessCount(dialog) {
    const counts = queryElements(dialog, "div,section,aside,header,h1,h2,h3,span")
      .filter(isVisible)
      .map(element => ({ count: workflow.selectedSuccessCount(element.textContent), length: normalizeText(element.textContent).length }))
      .filter(value => value.count !== null)
      .sort((left, right) => left.length - right.length);
    return counts[0]?.count ?? null;
  }

  function selectedRemoveButtons(dialog) {
    const area = selectedSuccessArea(dialog);
    const seen = new Set();
    return queryElements(area, "button,[role='button'],a,span,[aria-label],[title]")
      .filter(isVisible)
      .filter(element => elementLabels(element).some(text => /^(移除|删除)$/.test(text)))
      .map(pageClickTarget)
      .filter(target => {
        if (seen.has(target)) return false;
        seen.add(target);
        return true;
      });
  }

  async function confirmSuccessDeletion(dialog) {
    await wait(180);
    const prompts = queryElements(document, "[role='dialog'],.next-balloon,.next-popconfirm,.ant-popover,.ant-popconfirm,.next-dialog,.ant-modal")
      .filter(isVisible)
      .filter(element => element !== dialog && !element.contains(dialog))
      .filter(element => {
        const text = normalizeText(element.textContent);
        return text.length <= 600 && /(删除|移除|清空)/.test(text) && /(确定|确认|是否|成功品|商品)/.test(text);
      })
      .sort((left, right) => normalizeText(left.textContent).length - normalizeText(right.textContent).length);
    const prompt = prompts[0];
    if (!prompt) return false;
    const confirm = findVisibleText([/^确定$/, /^确认$/, /^删除$/], prompt, "button,[role='button'],a,span");
    if (!confirm) return false;
    confirm.click();
    await wait(280);
    return true;
  }

  async function waitForSelectedSuccessEmpty(dialog, timeoutMs = 4_000) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      const count = selectedSuccessCount(dialog);
      const removeCount = selectedRemoveButtons(dialog).length;
      if (count === 0 || (count === null && removeCount === 0)) return true;
      await wait(180);
    }
    return false;
  }

  async function clearSelectedSuccessProducts(dialog) {
    const initialCount = selectedSuccessCount(dialog) ?? selectedRemoveButtons(dialog).length;
    if (initialCount === 0) return { confirmed: true, removed: 0, method: "已选成功品原本为空" };

    const clearLabels = (workflow.SUCCESS_CLEAR_LABELS || ["全部删除", "清空全部", "全部移除", "全部清除"])
      .map(label => new RegExp(`^${label}$`));
    const clearAll = findVisibleText(clearLabels, selectedSuccessArea(dialog), "button,[role='button'],a,span,[aria-label],[title]");
    if (clearAll) {
      clearAll.click();
      await confirmSuccessDeletion(dialog);
      if (await waitForSelectedSuccessEmpty(dialog)) {
        return { confirmed: true, removed: initialCount, method: "已全部删除默认成功品" };
      }
    }

    for (let index = 0; index < 8; index += 1) {
      const count = selectedSuccessCount(dialog);
      if (count === 0) break;
      const remove = selectedRemoveButtons(dialog)[0];
      if (!remove) break;
      remove.click();
      await confirmSuccessDeletion(dialog);
      await wait(260);
    }

    const finalCount = selectedSuccessCount(dialog);
    const confirmed = finalCount === 0 || (finalCount === null && selectedRemoveButtons(dialog).length === 0);
    return {
      confirmed,
      removed: confirmed ? initialCount : Math.max(0, initialCount - (finalCount ?? initialCount)),
      method: confirmed ? "已逐个移除默认成功品" : `默认成功品未清空${finalCount === null ? "" : `（仍有 ${finalCount} 个）`}`
    };
  }

  function filterSatisfied(dialog, filter) {
    const text = normalizeText(dialog.textContent).toLowerCase();
    return filter.selected.every(value => text.includes(normalizeText(value).toLowerCase()));
  }

  function optionPattern(value) {
    if (value === "500万~1000万") return /^500万(?:~|至|-)?1000万$/i;
    const escaped = value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/~/g, "(?:~|至|-)");
    return new RegExp(`^${escaped}$`, "i");
  }

  function filterTrigger(dialog, filter) {
    const patterns = filter.selected.map(value => optionPattern(value));
    const exact = findVisibleText(patterns, dialog);
    if (exact) return exact;
    const labelPatterns = {
      priceBand: [/价格带/], growthCycle: [/打爆期/, /爆品期/], onlineCycle: [/上架周期/],
      rankLevel: [/TOP.*%以内/i], salesLevel: [/万以上/, /万.*1000万/]
    };
    return findVisibleText(labelPatterns[filter.key] || [], dialog);
  }

  function activePopup() {
    const candidates = queryElements(document, "[role='listbox'],.next-menu,.ant-select-dropdown,.next-overlay-wrapper,.ant-dropdown,.next-popup")
      .filter(isVisible);
    return candidates[candidates.length - 1] || document;
  }

  async function applySuccessFilter(dialog, filter) {
    if (filterSatisfied(dialog, filter)) return { label: filter.label, confirmed: true, method: "页面已选" };
    const trigger = filterTrigger(dialog, filter);
    if (!trigger) return { label: filter.label, confirmed: false, method: "未找到筛选控件" };
    trigger.click();
    await wait(300);
    const popup = activePopup();
    const missing = [];
    for (const value of filter.options) {
      const option = findVisibleText([optionPattern(value)], popup);
      if (!option) {
        missing.push(value);
        continue;
      }
      if (selectedState(option) !== true) {
        option.click();
        await wait(180);
      }
    }
    const popupConfirm = findVisibleText([/^确定$/, /^确认$/], popup, "button,[role='button'],a,span");
    if (popupConfirm) {
      popupConfirm.click();
      await wait(280);
    } else {
      trigger.click();
      await wait(180);
    }
    return { label: filter.label, confirmed: missing.length === 0, method: missing.length ? `缺少选项：${missing.join("、")}` : "已按截图选择" };
  }

  function findSearchInput(dialog) {
    const inputs = Array.from(dialog.querySelectorAll("input")).filter(isVisible).filter(input => !/checkbox|radio|date/.test(input.type || ""));
    return inputs.find(input => /搜索|商品|item|id|宝贝/i.test(`${input.placeholder || ""} ${input.name || ""} ${input.getAttribute("aria-label") || ""}`)) || null;
  }

  function findItemAddButton(dialog, itemId) {
    const matches = Array.from(dialog.querySelectorAll("div,li,tr,section,article")).filter(isVisible).filter(element => normalizeText(element.textContent).includes(itemId));
    matches.sort((a, b) => normalizeText(a.textContent).length - normalizeText(b.textContent).length);
    for (const match of matches) {
      let container = match;
      while (container && container !== dialog) {
        const button = findVisibleText([/^添加$/], container, "button,[role='button'],a,span");
        if (button) return button;
        container = container.parentElement;
      }
    }
    return null;
  }

  function dialogShowsSelectedItem(dialog, itemId) {
    return Array.from(dialog.querySelectorAll("div,section,aside")).filter(isVisible).some(element => {
      const text = normalizeText(element.textContent);
      return text.length <= 1000 && /已选成功品/.test(text) && text.includes(itemId);
    });
  }

  const DMP_API_BASE = "https://dmp.advgateway.taobao.com";

  function readDmpCookies() {
    const map = {};
    document.cookie.split(";").forEach(item => {
      const idx = item.indexOf("=");
      if (idx < 0) return;
      const key = item.slice(0, idx).trim();
      const value = item.slice(idx + 1).trim();
      if (key) map[key] = value;
    });
    return map;
  }

  function getDmpAuth() {
    const cookies = readDmpCookies();
    const tbToken = cookies._tb_token_ || "";
    let csrf = cookies.csrfId || cookies._csrf || "";
    if (!csrf && cookies.cookie2) {
      try {
        const parsed = JSON.parse(decodeURIComponent(cookies.cookie2));
        csrf = parsed.ck || "";
      } catch {}
    }
    if (!csrf && cookies.csg) csrf = cookies.csg;
    return { tbToken, csrf };
  }

  function dmpAuthQuery(auth) {
    return `bizCode=dmp&_tb_token_=${encodeURIComponent(auth.tbToken)}&_csrf=${encodeURIComponent(auth.csrf)}&csrfId=${encodeURIComponent(auth.csrf)}`;
  }

  function cateIdFromRecords() {
    // cateId 会出现在成功品相关请求的 query 里；item/info 的响应体里也常带类目字段。
    for (let index = records.length - 1; index >= 0; index -= 1) {
      const record = records[index];
      const path = record?.pathname || record?.url || "";
      if (!path.includes("/api/goods/grow/define/success") && !path.includes("/api/goods/item/info")) continue;
      try {
        const fromQuery = new URL(record.url).searchParams.get("cateId") || "";
        if (fromQuery) return fromQuery;
      } catch {}
    }
    for (let index = records.length - 1; index >= 0; index -= 1) {
      const record = records[index];
      const path = record?.pathname || record?.url || "";
      if (!path.includes("/api/goods/item/info")) continue;
      const data = parseRecordJson(record);
      const found = findCateIdInData(data);
      if (found) return found;
    }
    return "";
  }

  function findCateIdInData(value, depth = 0) {
    if (!value || depth > 12 || typeof value !== "object") return "";
    if (Array.isArray(value)) {
      for (const child of value) {
        const found = findCateIdInData(child, depth + 1);
        if (found) return found;
      }
      return "";
    }
    for (const key of ["cateId", "categoryId", "cateid", "leafCateId", "catId"]) {
      const candidate = value[key];
      if (candidate !== undefined && candidate !== null && /^\d{1,20}$/.test(String(candidate))) return String(candidate);
    }
    for (const child of Object.values(value)) {
      const found = findCateIdInData(child, depth + 1);
      if (found) return found;
    }
    return "";
  }

  // cateId 只有在成功品面板发过请求后才会出现在监听记录里。首次运行时记录必然为空，
  // 所以先打开一次面板触发 item/list 请求，再回读记录，避免"先有鸡还是先有蛋"。
  async function resolveCateId() {
    const cached = cateIdFromRecords();
    if (cached) return { cateId: cached, openedDialog: null };

    const dialog = await openSuccessDialog();
    if (dialog) {
      await waitForNetworkQuiet({ minimumMs: 900, maximumMs: 8000 });
      await refreshTaskRecords().catch(() => {});
    }
    return { cateId: cateIdFromRecords(), openedDialog: dialog };
  }

  async function addSuccessProductByApi(successItemId, cateId) {
    const subjectItemId = currentJob?.subjectItemId || "";
    if (!/^\d{6,20}$/.test(subjectItemId)) throw new Error("缺少主体商品 ID");
    if (!/^\d{6,20}$/.test(successItemId)) throw new Error("缺少成功品 ID");
    if (!cateId) throw new Error("未能解析成功品列表的 cateId");

    const auth = getDmpAuth();
    if (!auth.tbToken || !auth.csrf) throw new Error("无法从页面 cookie 读取鉴权 token（_tb_token_/csrf），请刷新达摩盘页面后重试");
    const q = dmpAuthQuery(auth);

    // 1. 获取最新日期（可选）。
    let thedate = "";
    try {
      const latest = await fetch(`${DMP_API_BASE}/api/latestDay?${q}&sceneCode=goodsGrowPathSuccItemList`, { credentials: "include" }).then(r => r.json());
      thedate = latest?.data || "";
    } catch {}

    // 2. 搜索目标成功品，拿详情。
    const searchUrl = `${DMP_API_BASE}${SUCCESS_LIST_PATH}?${q}&cateId=${encodeURIComponent(cateId)}&itemId=${subjectItemId}&growthStage=2%2C4%2C1%2C3%2C5%2C6&sellerLevel=1%2C2%2C3%2C4%2C5%2C6%2C7%2C8%2C9&gmvRankRateLevel=1%2C2&pageSize=20&page=1&keyword=${encodeURIComponent(successItemId)}${thedate ? `&thedate=${thedate}` : ""}`;
    const search = await fetch(searchUrl, { credentials: "include" }).then(r => r.json());
    const list = search?.data?.list || [];
    const found = list.find(item => String(item.itemId) === String(successItemId));
    if (!found) throw new Error(`搜索成功品 ${successItemId} 未返回结果`);

    // 3. 添加成功品。
    const response = await fetch(`${DMP_API_BASE}/api/goods/grow/define/success?${q}`, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        itemId: Number(subjectItemId),
        successItemList: [{
          itemId: Number(successItemId),
          itemTitle: found.itemTitle || found.title || "",
          itemPictUrl: found.itemPictUrl || found.picUrl || "",
          desc: found.desc || "",
          labels: found.labels || []
        }]
      })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || data?.info?.ok === false) throw new Error(data?.info?.message || `添加成功品接口失败（HTTP ${response.status}）`);
    return { confirmed: true, method: "已通过接口添加成功品", api: true };
  }

  // resolveCateId 可能为了触发 item/list 请求而打开了成功品弹窗。
  // 接口添加成功后必须关掉它，否则遮罩会挡住后续的对比页签点击。
  async function closeSuccessDialog(dialog) {
    if (!dialog || !isVisible(dialog)) return;
    const cancel = findVisibleText([/^取消$/, /^关闭$/, /^×$/, /^✕$/], dialog, "button,[role='button'],a,span,i");
    if (cancel) {
      cancel.click();
      await wait(300);
    }
    if (isVisible(dialog)) {
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true }));
      await wait(300);
    }
  }

  async function ensureSuccessProductAdded(itemId) {
    // 优先通过接口直接添加成功品，绕开脆弱的 DOM 自动化。
    // resolveCateId 可能顺带打开了成功品弹窗，复用它，避免重复打开。
    let dialog = null;
    try {
      const resolved = await resolveCateId();
      dialog = resolved.openedDialog;
      const apiResult = await addSuccessProductByApi(itemId, resolved.cateId);
      if (apiResult.confirmed) {
        await closeSuccessDialog(dialog);
        await waitForNetworkQuiet({ minimumMs: 900, maximumMs: 8000 });
        await refreshTaskRecords().catch(() => {});
        return apiResult;
      }
    } catch (error) {
      currentJob.successApiError = error?.message || String(error);
      console.warn("[dmp-cdp] 接口添加成功品失败，回退 DOM 自动化：", currentJob.successApiError);
    }

    if (!dialog) dialog = await openSuccessDialog();
    if (!dialog) {
      const detected = visibleSuccessTextSummary();
      return {
        confirmed: false,
        method: detected.length
          ? `发现成功品区域但弹窗未打开（检测到：${detected.join("、")}）`
          : "页面未发现成功品入口；请确认商品打爆路径内容已加载",
        filters: []
      };
    }

    const allProducts = findVisibleText([/^所有商品$/], dialog);
    if (allProducts) {
      allProducts.click();
      await wait(250);
    }

    const cleared = await clearSelectedSuccessProducts(dialog);
    if (!cleared.confirmed) return { confirmed: false, method: cleared.method, filters: [], cleared };

    const filters = [];
    for (const filter of workflow.SUCCESS_FILTERS) filters.push(await applySuccessFilter(dialog, filter));
    const failedFilters = filters.filter(result => !result.confirmed);
    if (failedFilters.length) return { confirmed: false, method: `筛选未完成：${failedFilters.map(result => result.label).join("、")}`, filters, cleared };

    const input = findSearchInput(dialog);
    if (!input) return { confirmed: false, method: "未找到成功品搜索框", filters, cleared };
    fillPageInput(input, itemId);
    input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true }));
    input.dispatchEvent(new KeyboardEvent("keyup", { key: "Enter", code: "Enter", bubbles: true }));
    await waitForNetworkQuiet({ minimumMs: 800, maximumMs: 7000 });

    let selectedInDialog = dialogShowsSelectedItem(dialog, itemId);
    if (!selectedInDialog) {
      const addButton = await waitForVisible(() => findItemAddButton(dialog, itemId), 5000);
      if (!addButton) return { confirmed: false, method: `没有找到商品 ${itemId} 的“添加”按钮`, filters, cleared };
      addButton.click();
      await wait(450);
      selectedInDialog = dialogShowsSelectedItem(dialog, itemId);
    }

    const confirmButtons = Array.from(dialog.querySelectorAll("button,[role='button'],a,span"))
      .filter(isVisible)
      .filter(element => /^(确认|确定|完成)$/.test(normalizeText(element.textContent)))
      .map(pageClickTarget);
    const confirmButton = confirmButtons[confirmButtons.length - 1];
    if (!confirmButton) return { confirmed: false, method: "成功品已添加，但未找到弹窗确认按钮", filters, cleared };
    confirmButton.click();
    await waitForNetworkQuiet({ minimumMs: 1200, maximumMs: 9000 });
    await refreshTaskRecords();
    const dialogClosed = !isVisible(dialog);
    return {
      confirmed: selectedInDialog && (dialogClosed || hasSuccessProductRecord(itemId, currentJob.startedAt)),
      method: dialogClosed ? "已添加并确认成功品" : "已点击确认，等待页面回写",
      filters,
      cleared
    };
  }

  function networkHasRange(range, since) {
    const variants = date => [date, date.replace(/-/g, "")];
    return records.some(record => {
      if (since && record.capturedAt && record.capturedAt < since) return false;
      const payload = `${record.url || ""}\n${record.requestBody || ""}`;
      return variants(range.startDate).some(value => payload.includes(value)) && variants(range.endDate).some(value => payload.includes(value));
    });
  }

  // 达摩盘的日期控件（实测 DOM）：
  //   触发器：<div class="mx-trigger"> 文案形如 "⚁ 过去 30 天⌃"（带图标字符和空格）
  //   展开后：快捷按钮 <button class="asiYsrRaf"> 文案 "过去 30 天"
  //   不同页面构建的提交方式不一致：有的会在点快捷项后自动取数并关闭浮层，
  //   有的仍保留浮层，必须再点「确定」。两条路径都要识别。
  // 注意页面提示"默认选择该路径第一个成长阶段时间"——默认区间不是 30 天，
  // 所以这一步不能省，否则拿到的是 10 天左右的阶段数据。
  const THIRTY_DAY_TEXT = /^(近|过去|最近)30(天|日)$/;
  const DATE_TRIGGER_SELECTOR = ".mx-trigger,.mxgc-calendar-rangepicker,[class*='rangepicker'],[class*='trigger']";

  // 日期面板里的两个日期输入框（开始/结束）。必须排除插件面板自己的商品 ID 输入框，
  // 也要排除"定制成功品"弹窗里的搜索框。
  function datePanelInputs(scope = document) {
    return queryElements(scope, "input").filter(isVisible).filter(input => {
      if (input.closest("#dmp-cdp-monitor")) return false;
      if (input.closest("[role='dialog'],.next-dialog,.ant-modal")) return false;
      const signature = `${input.type || ""} ${input.placeholder || ""} ${input.name || ""} ${input.getAttribute("aria-label") || ""} ${input.className || ""}`;
      if (/日期|开始|结束|start|end|date|yyyy|mm|dd|calendar|picker/i.test(signature)) return true;
      // 达摩盘的类名是混淆的，占位符也可能为空——已经填了 ISO 日期的输入框同样认。
      return /^20\d{2}-\d{2}-\d{2}$/.test(String(input.value || "").trim());
    });
  }

  // 判断日期面板/下拉是不是真的展开了。展开的标志是能同时看到
  // 「过去 30 天」这类快捷预设，或者两个日期输入框。
  function datePanelIsOpen(trigger = dateTriggerElement()) {
    if (trigger && datePresetCandidates(trigger).length) return true;
    return datePanelInputs().length >= 2;
  }

  // 日期面板的「确定」在当前达摩盘构建里不是 button，而可能只是带点击监听的 DIV，
  // 也可能是 value="确定" 的 input。旧选择器只查 button/a/span，导致截图里按钮明明
  // 可见，插件却连续记录“未找到「确定」按钮”。先找日期面板的最小公共容器，再兼容
  // 这些真实节点形态；找不到面板容器时才退回全页精确文案搜索。
  function datePanelScope(anchor = null, trigger = null) {
    const inputs = datePanelInputs();
    const starts = [anchor, ...inputs].filter(Boolean);
    for (const start of starts) {
      let node = start;
      for (let depth = 0; node && depth < 10; node = node.parentElement, depth += 1) {
        if (node.nodeType !== 1 || node.closest?.("#dmp-cdp-monitor")) continue;
        const visibleInputs = queryElements(node, "input").filter(isVisible);
        const text = normalizeText(node.textContent);
        // 正确日期浮层同时包含快捷项和「确定」；不再强依赖 input 的类名/占位符。
        const hasPreset = /(近|过去|最近)30(天|日)/.test(text);
        if ((hasPreset && /确定/.test(text) && text.length <= 2000) || (visibleInputs.length >= 2 && /确定|取消/.test(text))) {
          // 若传入了目标触发器，浮层必须在其附近；避免拿到页面上方另一个日期面板。
          if (trigger?.getBoundingClientRect) {
            const triggerRect = trigger.getBoundingClientRect();
            const panelRect = node.getBoundingClientRect();
            const distance = Math.abs(panelRect.top - triggerRect.bottom);
            if (panelRect.bottom < triggerRect.top - 20 || distance > Math.max(900, window.innerHeight)) continue;
          }
          return node;
        }
      }
    }
    return null;
  }

  function dateConfirmCandidates(anchor = null, trigger = dateTriggerElement()) {
    const panel = datePanelScope(anchor, trigger);
    const scopes = panel ? [panel, document] : [document];
    const seen = new Set();
    const candidates = [];
    for (const scope of scopes) {
      for (const element of queryElements(scope, "button,[role='button'],a,label,span,div,input[type='button'],input[type='submit'],[aria-label],[title]")) {
        if (!isVisible(element) || element.closest?.("#dmp-cdp-monitor")) continue;
        const labels = [element.textContent, element.getAttribute?.("aria-label"), element.getAttribute?.("title"), element.value]
          .map(normalizeText)
          .filter(Boolean);
        if (!labels.some(label => label === "确定")) continue;
        const target = pageClickTarget(element);
        if (!target || seen.has(target) || !isVisible(target)) continue;
        const rect = target.getBoundingClientRect();
        const triggerRect = trigger?.getBoundingClientRect?.();
        const nearTrigger = !triggerRect || (
          rect.top >= triggerRect.top - 30
          && Math.abs(rect.top - triggerRect.bottom) <= Math.max(850, window.innerHeight * 0.9)
        );
        if (!panel && !nearTrigger) continue;
        seen.add(target);
        candidates.push({
          target,
          inPanel: Boolean(panel && panel.contains(target)),
          semantic: target.matches?.("button,[role='button'],input[type='button'],input[type='submit']") ? 1 : 0,
          distance: triggerRect ? Math.abs(rect.top - triggerRect.bottom) + Math.abs(rect.left - triggerRect.left) * 0.15 : 0,
          area: rect.width * rect.height
        });
      }
      if (candidates.some(candidate => candidate.inPanel)) break;
    }
    return candidates
      .sort((left, right) => Number(right.inPanel) - Number(left.inPanel) || right.semantic - left.semantic || left.distance - right.distance || left.area - right.area)
      .map(candidate => candidate.target);
  }

  async function waitForDateConfirm(anchor = null, trigger = dateTriggerElement(), timeoutMs = 2400) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      const confirm = dateConfirmCandidates(anchor, trigger)[0];
      if (confirm) return confirm;
      await wait(160);
    }
    return null;
  }

  // 选择快捷项后的页面有两种真实行为：
  //   1. 新构建立即把触发器改成「过去 30 天」、发请求并关闭浮层；
  //   2. 旧构建保留浮层，等用户再点「确定」。
  // 先找与目标触发器关联的「确定」；只有连续两轮都看到预设已选中且浮层已关闭，
  // 才认定为自动提交，避免把浮层重绘的短暂空档误判成成功。
  async function waitForDatePresetOutcome(anchor, trigger, timeoutMs = 2400) {
    const started = Date.now();
    let closedSelectedRounds = 0;
    while (Date.now() - started < timeoutMs) {
      const confirm = dateConfirmCandidates(anchor, trigger)[0];
      if (confirm) return { mode: "confirm", confirm };
      const shown = currentDatePresetText();
      if (THIRTY_DAY_TEXT.test(shown) && !datePanelIsOpen(trigger)) {
        closedSelectedRounds += 1;
        if (closedSelectedRounds >= 2) return { mode: "auto", shown };
      } else {
        closedSelectedRounds = 0;
      }
      await wait(160);
    }
    const shown = currentDatePresetText();
    if (THIRTY_DAY_TEXT.test(shown) && !datePanelIsOpen(trigger)) return { mode: "auto", shown };
    return { mode: "missing", shown };
  }

  // 展开前先把触发器顶到视口上部，给下方的浮层留出空间。
  // 这一步是必须的：日期浮层是 position:absolute、锚在触发器下方的，
  // 触发器本身在视口下半部分时，浮层里的「过去 30 天」和「确定」会落到视口以下
  // （实测触发器在 y≈880 时，确定按钮在 y≈1084，而视口只有 985 高）。
  // 而对浮层调用 scrollIntoView 是没用的——滚动会带着锚点一起移动，浮层永远追不进视口。
  // CDP 按坐标点击点不到视口外的点，于是就出现"面板打开了、但预设点不到"的现象。
  async function scrollTriggerToTop(trigger) {
    if (!trigger?.getBoundingClientRect) return;
    // 目标：把触发器放到视口顶部往下约 1/5 的位置，下面至少留 400px 给浮层。
    const wanted = Math.round(window.innerHeight * 0.2);
    for (let attempt = 0; attempt < 3; attempt += 1) {
      const rect = trigger.getBoundingClientRect();
      const delta = rect.top - wanted;
      if (Math.abs(delta) < 40) return;
      window.scrollBy({ top: delta, behavior: "instant" });
      await wait(240);
    }
  }

  // 严格按页面交互顺序：展开日期下拉 → 选「过去 30 天」→ 若浮层仍在则点「确定」。
  // 快捷项自动提交的页面不能继续找按钮或重复点击；页面预设就是用户指定口径，
  // 不再提交后重开面板改写成另一组明确日期。
  async function applyThirtyDayPreset() {
    // 页面有两个日期区域。必须先锚定「关键指标对比」页签所在模块下方的日期触发器，
    // 再从这个触发器展开的邻近浮层中找快捷项；禁止全页直接搜“过去30天”。
    const trigger = dateTriggerElement();
    if (!trigger) {
      tabDiag("日期：未找到关键指标对比下方的日期控件触发器");
      return false;
    }
    const triggerRect = trigger.getBoundingClientRect();
    const tabAnchor = comparisonDateAnchor();
    const tabRect = tabAnchor?.getBoundingClientRect?.();
    tabDiag("日期：定位关键指标对比下方时间控件", {
      text: normalizeText(trigger.textContent).slice(0, 30),
      x: Math.round(triggerRect.left + triggerRect.width / 2),
      y: Math.round(triggerRect.top + triggerRect.height / 2),
      关键指标页签Y: tabRect ? Math.round(tabRect.top + tabRect.height / 2) : null
    });

    let preset = datePresetCandidates(trigger)[0] || null;
    for (let attempt = 0; attempt < 3 && !preset; attempt += 1) {
      // 每轮都重新把正确触发器顶上去：点击后页面可能又滚回去了。
      await scrollTriggerToTop(trigger);
      await trustedClick(trigger, `日期触发器#${attempt + 1}`);
      for (let poll = 0; poll < 6 && !preset; poll += 1) {
        await wait(240);
        preset = datePresetCandidates(trigger)[0] || null;
      }
    }
    if (!preset) {
      tabDiag("日期：目标时间弹窗展开后仍未找到「过去 30 天」快捷按钮", { 面板已展开: datePanelIsOpen(trigger) });
      return false;
    }
    // 选预设同样要真实点击，否则点了也不会生效。
    await trustedClick(preset, "日期预设:过去30天");
    await wait(320);

    // 3. 兼容两种提交模式：自动生效并收起，或保留面板等待「确定」。
    const outcome = await waitForDatePresetOutcome(preset, trigger);
    if (outcome.mode === "auto") {
      tabDiag("日期：快捷项已自动生效，无需点击「确定」", { shown: outcome.shown });
      return true;
    }
    if (outcome.mode !== "confirm") {
      tabDiag("日期：目标时间弹窗未找到「确定」按钮", { 面板已展开: datePanelIsOpen(trigger), 可见日期输入框: datePanelInputs().length });
      return false;
    }
    await trustedClick(outcome.confirm, "日期确定");
    await wait(420);
    tabDiag("日期：已提交「过去 30 天」预设");
    return true;
  }

  // 读日期控件上的预设标签（形如 "⚁ 过去 30 天⌃"）。
  // 「推广策略对比」「人群对比」默认显示预设标签，「关键指标对比」显示具体日期。
  function currentDatePresetText() {
    const trigger = dateTriggerElement();
    if (!trigger) return "";
    const text = normalizeText(trigger.textContent);
    if (/20\d{2}-\d{2}-\d{2}/.test(text)) return "";
    // 去掉两端的图标字符，只留 "过去30天" 这样的核心文案。
    return text.replace(/^[^一-龥]+/, "").replace(/[^一-龥\d]+$/, "");
  }

  // 读当前日期控件上显示的区间，用来确认"过去 30 天"是否真的生效了。
  // 页面默认是"该路径第一个成长阶段"（实测 07-14~07-23，约 10 天），必须改掉。
  // 只从日期控件本身读：页面「成长阶段」区域也有 "20260714-20260723" 这类文本，
  // 用宽泛的 div/span 选择器会把它误当成日期控件。
  function comparisonDateAnchor() {
    return comparisonTabCandidates("关键指标对比")
      .filter(isVisible)
      .sort((left, right) => {
        const leftRect = left.getBoundingClientRect();
        const rightRect = right.getBoundingClientRect();
        return leftRect.width * leftRect.height - rightRect.width * rightRect.height;
      })[0] || null;
  }

  function isDateTriggerCandidate(element) {
    if (!isVisible(element) || element.closest?.("#dmp-cdp-monitor")) return false;
    const text = normalizeText(element.textContent);
    if (text.length > 40) return false;
    const hasPreset = /(过去|近|最近)\d+(天|日)/.test(text);
    const hasDateRange = (text.match(/20\d{2}-\d{2}-\d{2}/g) || []).length >= 2;
    return hasPreset || hasDateRange;
  }

  // 只取「关键指标对比」页签所在模块内、且位于页签附近/下方的日期控件。
  // 从页签逐层向上找第一个同时包含日期触发器的容器，可天然排除页面上方另一个时间区域。
  function dateTriggerElement() {
    const anchor = comparisonDateAnchor();
    if (!anchor) return null;
    let scopedCandidates = [];
    let scope = anchor.parentElement;
    for (let depth = 0; scope && depth < 10; scope = scope.parentElement, depth += 1) {
      scopedCandidates = queryElements(scope, DATE_TRIGGER_SELECTOR).filter(isDateTriggerCandidate);
      if (scopedCandidates.length) break;
    }
    if (!scopedCandidates.length) return null;
    const anchorRect = anchor.getBoundingClientRect();
    return scopedCandidates
      .map(element => {
        const rect = element.getBoundingClientRect();
        const deltaY = rect.top - anchorRect.bottom;
        return {
          element,
          belowPenalty: deltaY >= -40 ? 0 : 100000,
          distance: Math.abs(deltaY) + Math.abs(rect.left - anchorRect.left) * 0.15,
          area: rect.width * rect.height
        };
      })
      .sort((left, right) => left.belowPenalty - right.belowPenalty || left.distance - right.distance || left.area - right.area)[0]?.element || null;
  }

  // 只接受目标日期触发器附近、位于其下方的“过去30天”候选。
  // 这样页面上方另一个时间区域即使同时显示同名快捷项，也不会被误点。
  function datePresetCandidates(trigger) {
    if (!trigger?.getBoundingClientRect) return [];
    const triggerRect = trigger.getBoundingClientRect();
    const seen = new Set();
    return queryElements(document, "button,[role='button'],a,li,span,div,[aria-label],[title]")
      .filter(isVisible)
      .filter(element => {
        if (element.closest?.("#dmp-cdp-monitor")) return false;
        const text = normalizeText(element.textContent);
        return text.length <= 40 && THIRTY_DAY_TEXT.test(text);
      })
      .map(element => pageClickTarget(element))
      .filter(target => {
        if (!target || seen.has(target) || !isVisible(target)) return false;
        if (target === trigger || target.contains?.(trigger) || trigger.contains?.(target)) return false;
        seen.add(target);
        const rect = target.getBoundingClientRect();
        const verticalDistance = Math.abs(rect.top - triggerRect.bottom);
        return rect.top >= triggerRect.top - 30 && verticalDistance <= Math.max(850, window.innerHeight * 0.9);
      })
      .map(target => {
        const rect = target.getBoundingClientRect();
        return {
          target,
          semantic: target.matches?.("button,[role='button'],li") ? 1 : 0,
          floating: isFloatingLayer(target) ? 1 : 0,
          distance: Math.abs(rect.top - triggerRect.bottom) + Math.abs(rect.left - triggerRect.left) * 0.15,
          area: rect.width * rect.height
        };
      })
      .sort((left, right) => right.floating - left.floating || right.semantic - left.semantic || left.distance - right.distance || left.area - right.area)
      .map(candidate => candidate.target);
  }

  function currentDateRangeText() {
    const trigger = dateTriggerElement();
    if (!trigger) return "";
    const text = normalizeText(trigger.textContent);
    return /20\d{2}-\d{2}-\d{2}/.test(text) ? text : "";
  }

  function rangeSpansAtLeast(text, minDays) {
    const dates = (text.match(/20\d{2}-\d{2}-\d{2}/g) || []).map(value => Date.parse(`${value}T00:00:00Z`));
    if (dates.length < 2 || dates.some(Number.isNaN)) return false;
    const days = Math.round((Math.max(...dates) - Math.min(...dates)) / 86400000) + 1;
    return days >= minDays;
  }

  // 从控件文案里取出起止日期，用来和我们要的窗口逐日核对。
  function parseTriggerRange(text) {
    const dates = (text.match(/20\d{2}-\d{2}-\d{2}/g) || []).sort();
    if (dates.length < 2) return null;
    return { startDate: dates[0], endDate: dates[dates.length - 1] };
  }

  // 控件区间是否正好等于我们要的窗口。相等才算"日期已落实"，
  // 只是跨度够 30 天不算——那可能是含今日的口径，和报告的"截至昨天"差一天。
  function rangeMatchesExactly(text, range) {
    const shown = parseTriggerRange(text);
    return Boolean(shown && range && shown.startDate === range.startDate && shown.endDate === range.endDate);
  }

  // 日期落实分三档，写进报告让下游知道拿到的到底是什么口径：
  //   exact  —— 控件区间与"截至昨天的 30 个完整自然日"逐日相等，或接口请求里带着这两个日期；
  //   preset —— 页面已明确显示并提交「过去 30 天」，或控件区间达到 30 天量级；
  //   failed —— 仍是默认的成长阶段区间（实测约 10 天），这种数据不能当 30 天用。
  async function confirmThirtyDays(range, since) {
    await refreshTaskRecords().catch(() => {});
    // 接口请求里直接带着目标起止日期，是最硬的证据。
    if (networkHasRange(range, since)) {
      tabDiag("日期：接口请求已携带目标起止日期", { 期望: `${range.startDate}~${range.endDate}` });
      return { confirmed: true, precision: "exact", shown: `${range.startDate} 至 ${range.endDate}` };
    }

    const before = currentDateRangeText();
    const presetBefore = currentDatePresetText();
    // 日期是全局生效的：在任一页签改成目标区间后，切到其它页签会沿用这个区间。
    // 所以先看当前区间是不是已经正好是目标窗口（首个页签改完，后续页签直接继承）。
    if (rangeMatchesExactly(before, range)) {
      tabDiag("日期：控件区间已等于目标窗口，沿用", { shown: before });
      return { confirmed: true, precision: "exact", shown: before };
    }
    // 页面会把已提交的快捷项显示为「过去 30 天」，而不是显示具体起止日。
    // 这是权威的页面选中状态，后续页签直接沿用，不能再把它误判成日期失败。
    if (THIRTY_DAY_TEXT.test(presetBefore)) {
      tabDiag("日期：页面已选中「过去 30 天」，沿用", { shown: presetBefore });
      return { confirmed: true, precision: "preset", shown: presetBefore };
    }

    // 未选中时严格执行用户指定的三步；页面偶发动画/防抖，最多完整重试两轮。
    for (let attempt = 0; attempt < 2; attempt += 1) {
      if (!await applyThirtyDayPreset()) continue;
      // 改完日期页面会重新取数，这一批数据必须等它真的落地。
      await settleAfterAction({ label: "日期确认", since, minimumMs: 1000, quietMs: 1200, quietMaximumMs: 12000, readbackMs: 8000 });
      const after = currentDateRangeText();
      const presetAfter = currentDatePresetText();
      if (networkHasRange(range, since) || rangeMatchesExactly(after, range)) {
        tabDiag("日期：已确认为目标窗口", { before, after });
        return { confirmed: true, precision: "exact", shown: after || `${range.startDate} 至 ${range.endDate}` };
      }
      if (THIRTY_DAY_TEXT.test(presetAfter)) {
        tabDiag("日期：已确认页面预设「过去 30 天」", { shown: presetAfter, 第几轮: attempt + 1 });
        return { confirmed: true, precision: "preset", shown: presetAfter };
      }
      if (rangeSpansAtLeast(after, 28)) {
        tabDiag("日期：已是 30 天量级，按页面口径采集", { before, after, 第几轮: attempt + 1 });
        return { confirmed: true, precision: "preset", shown: after };
      }
      tabDiag("日期：提交「过去 30 天」后页面状态未匹配，准备重试", { before, after, presetAfter, 第几轮: attempt + 1 });
    }
    await refreshTaskRecords().catch(() => {});
    const final = currentDateRangeText();
    const finalPreset = currentDatePresetText();
    if (networkHasRange(range, since) || rangeMatchesExactly(final, range)) {
      return { confirmed: true, precision: "exact", shown: final || `${range.startDate} 至 ${range.endDate}` };
    }
    if (THIRTY_DAY_TEXT.test(finalPreset)) return { confirmed: true, precision: "preset", shown: finalPreset };
    if (rangeSpansAtLeast(final, 28)) return { confirmed: true, precision: "preset", shown: final };
    return { confirmed: false, precision: "failed", shown: final || finalPreset };
  }

  // 达摩盘业务接口所在的域（业务请求可能发到 dmp.taobao.com 或 dmp.advgateway.taobao.com），
  // 用来把埋点流量（gm.mmstat.com / alimama_bp / aes 等）排除在"有没有真正取数"的判断之外。
  // 定义在此处而非文件靠后：clickTabAndAwaitData 会用到，const 不像函数声明那样提升。
  const BUSINESS_HOST = /(^|\.)dmp(\.advgateway)?\.taobao\.com$/i;
  const BUSINESS_PATH = /\/(api|api_2|dataplatform)\//i;

  function isBusinessRecord(record) {
    if (!record || record.kind) return false;
    const raw = record.url || "";
    let host = "";
    try { host = new URL(raw).hostname; } catch { return false; }
    if (!BUSINESS_HOST.test(host)) return false;
    const path = record.pathname || (() => { try { return new URL(raw).pathname; } catch { return ""; } })();
    return BUSINESS_PATH.test(path);
  }

  function countBusinessRecords(since) {
    return records.filter(record => {
      if (since && record.capturedAt && record.capturedAt < since) return false;
      return isBusinessRecord(record);
    }).length;
  }

  // 达摩盘前端是 Magix/Brix，页签监听的是 mousedown/pointerdown 而不是 click。
  // 只派发一个裸 click 事件框架收不到（手动点有效、插件点无效就是这么来的），
  // 所以要补全整个指针事件序列。javascript: href 的默认导航会被页面 CSP 拦截，
  // 用一次性捕获监听器掐掉，避免控制台刷 security 违规。
  function dispatchRealisticClick(element) {
    const view = element.ownerDocument?.defaultView || window;
    const doc = element.ownerDocument || document;
    const rect = element.getBoundingClientRect();
    const clientX = Math.round(rect.left + rect.width / 2);
    const clientY = Math.round(rect.top + rect.height / 2);
    const base = { bubbles: true, cancelable: true, view, clientX, clientY, button: 0, buttons: 1 };

    // 达摩盘页签的 href 是 "javascript:;"（空操作），真正的切换逻辑绑在事件监听器上。
    // 这个空导航仍会被页面 CSP 拦截并刷 security 违规，所以要掐掉。
    // guard 必须挂在 document 捕获阶段：我们点击的目标可能是内层 DIV/SPAN，
    // 自身没有 href，但事件冒泡到父级 <a> 时照样触发导航——挂在元素自己身上拦不住。
    const guard = event => {
      const anchor = event.target?.closest?.("a[href]");
      const href = (anchor?.getAttribute("href") || "").trim().toLowerCase();
      if (href.startsWith("javascript:")) event.preventDefault();
    };
    doc.addEventListener("click", guard, { capture: true });

    try {
      const PointerEventCtor = view.PointerEvent || null;
      const pointer = type => PointerEventCtor
        ? new PointerEventCtor(type, { ...base, pointerId: 1, pointerType: "mouse", isPrimary: true })
        : new MouseEvent(type === "pointerdown" ? "mousedown" : "mouseup", base);

      element.dispatchEvent(new MouseEvent("mouseover", { ...base, buttons: 0 }));
      element.dispatchEvent(new MouseEvent("mousemove", { ...base, buttons: 0 }));
      element.dispatchEvent(pointer("pointerdown"));
      element.dispatchEvent(new MouseEvent("mousedown", base));
      element.dispatchEvent(pointer("pointerup"));
      element.dispatchEvent(new MouseEvent("mouseup", { ...base, buttons: 0 }));
      element.dispatchEvent(new MouseEvent("click", { ...base, buttons: 0 }));
    } finally {
      doc.removeEventListener("click", guard, { capture: true });
    }
  }


  // 通过 CDP Input 域派发浏览器级真实点击。
  // 内容脚本合成的事件 isTrusted 恒为 false，达摩盘页签逻辑不响应
  // （实测埋点 SDK 收到了 mousedown 并上报 _g_et=mousedown，但页面既不切换也不取数）。
  // 诊断信息走 console.warn，这样会被 CDP 的 Runtime.consoleAPICalled 捕获、
  // 进入可下载的监听记录。存在 currentJob 里的字段不会进记录，排障时拿不到。
  function tabDiag(message, detail) {
    console.warn("[dmp-cdp][tab]", message, detail === undefined ? "" : JSON.stringify(detail));
  }

  // 把元素滚进视口，并确认真的滚进来了。
  // "nearest" 对已在滚动容器内的元素常常原地不动（实测页签 y=1256 而视口高 985，
  // nearest 完全没滚），所以这里用 center 并循环校验，必要时直接操作 window.scrollBy。
  //
  // 例外：浮层（日期面板、下拉菜单）是 position:absolute/fixed 锚在触发器上的，
  // 滚动会带着锚点一起动，浮层永远追不进视口，硬滚只会把页面滚乱。
  // 这类元素直接判定"能不能点"，滚动交给展开前的 scrollTriggerToTop 负责。
  function isFloatingLayer(element) {
    for (let node = element, depth = 0; node && depth < 6; node = node.parentElement, depth += 1) {
      const view = node.ownerDocument?.defaultView || window;
      const position = view.getComputedStyle(node).position;
      if (position === "absolute" || position === "fixed") return true;
    }
    return false;
  }

  async function ensureInViewport(element) {
    const fitsNow = () => {
      const rect = element.getBoundingClientRect();
      const centerY = rect.top + rect.height / 2;
      const centerX = rect.left + rect.width / 2;
      return centerY >= 0 && centerY <= window.innerHeight && centerX >= 0 && centerX <= window.innerWidth;
    };
    if (fitsNow()) return true;
    // 浮层不滚：滚了也追不进来，还会把页面位置搞乱。
    if (isFloatingLayer(element)) return false;
    for (let attempt = 0; attempt < 3; attempt += 1) {
      const rect = element.getBoundingClientRect();
      const centerY = rect.top + rect.height / 2;
      const centerX = rect.left + rect.width / 2;
      const fits = centerY >= 0 && centerY <= window.innerHeight
        && centerX >= 0 && centerX <= window.innerWidth;
      if (fits) return true;
      if (attempt === 0) {
        element.scrollIntoView?.({ block: "center", inline: "center" });
      } else {
        // scrollIntoView 不奏效时（元素在自定义滚动容器里），手动补偿差值。
        window.scrollBy({ top: centerY - window.innerHeight / 2, behavior: "instant" });
      }
      await wait(260);
    }
    const rect = element.getBoundingClientRect();
    const centerY = rect.top + rect.height / 2;
    return centerY >= 0 && centerY <= window.innerHeight;
  }

  async function realClickViaCdp(element, label) {
    if (!element?.getBoundingClientRect) return false;
    if (!await ensureInViewport(element)) {
      const rect = element.getBoundingClientRect();
      tabDiag("跳过：无法把目标滚进视口", {
        label, tag: element.tagName,
        y: Math.round(rect.top + rect.height / 2), vh: window.innerHeight
      });
      return false;
    }
    const rect = element.getBoundingClientRect();
    if (!rect.width || !rect.height) {
      tabDiag("跳过：元素尺寸为 0", { label, tag: element.tagName });
      return false;
    }
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    // CDP 坐标以视口左上角为原点，视口外的点点不到。
    if (x < 0 || y < 0 || x > window.innerWidth || y > window.innerHeight) {
      tabDiag("跳过：中心点在视口外", { label, tag: element.tagName, x: Math.round(x), y: Math.round(y), vw: window.innerWidth, vh: window.innerHeight });
      return false;
    }
    // CDP 按坐标点击命中的是该点最顶层的元素。插件面板固定在右下角，
    // 可能正好盖住目标——那样点下去只会点到面板自己，必须跳过。
    // 其它情况（命中的是目标的子节点/父容器/兄弟文字节点）都属于正常命中：
    // 页面控件本来就是多层嵌套，点中哪一层都会冒泡到真正的监听器上。
    const topMost = document.elementFromPoint(x, y);
    if (!topMost) {
      tabDiag("跳过：该坐标没有元素", { label, x: Math.round(x), y: Math.round(y) });
      return false;
    }
    if (topMost.closest?.("#dmp-cdp-monitor") || root.contains(topMost)) {
      tabDiag("跳过：被插件面板遮挡", { label, x: Math.round(x), y: Math.round(y) });
      return false;
    }
    try {
      const result = await runtimeMessage("DMP_CDP_REAL_CLICK", { x: Math.round(x), y: Math.round(y) });
      if (!result?.ok) {
        tabDiag("CDP 真实点击失败", { label, error: result?.error || "无响应" });
        return false;
      }
      tabDiag("CDP 真实点击已派发", { label, tag: element.tagName, x: Math.round(x), y: Math.round(y), hit: topMost.tagName });
      return true;
    } catch (error) {
      tabDiag("CDP 真实点击异常", { label, error: String(error?.message || error) });
      return false;
    }
  }

  // 插件面板固定在右下角，可能正好压住页面控件，导致 CDP 按坐标点击命中面板自己。
  // 面板是 position:fixed 的浮层，隐藏它不会让页面重排，所以可以临时藏起来再点。
  async function withPanelHidden(run) {
    const previous = root.style.visibility;
    root.style.visibility = "hidden";
    // 给一帧时间让 elementFromPoint 反映隐藏后的命中结果。
    await wait(60);
    try { return await run(); }
    finally { root.style.visibility = previous; }
  }

  // 达摩盘所有交互控件（页签、日期下拉、场景渠道下拉）走的都是 Magix 的
  // mousedown/pointerdown 监听，只认 isTrusted 的真实事件。
  // 内容脚本合成的事件 isTrusted 恒为 false：埋点 SDK 会收到并上报，
  // 但页面既不切换也不取数——实测就是日期停在默认阶段区间、
  // 场景下拉展开后选项点不动（下拉一直挂着）的原因。
  // 所以统一先走 CDP 真实点击；被面板挡住或落在视口外时各有一次补救；
  // 合成事件只作为最后的兜底（基本不管用，但比什么都不做好）。
  async function trustedClick(element, label) {
    if (!element) return false;
    if (await realClickViaCdp(element, label)) return true;
    // 可能是被插件面板挡住了，藏起面板再试一次。
    if (await withPanelHidden(() => realClickViaCdp(element, `${label}(面板已隐藏)`))) return true;
    // 可能是浮层里的元素落在了视口以下（日期面板的「确定」、下拉末尾的渠道）。
    // 浮层锚在触发器上不能单独滚，但可以整页滚动，把浮层带进视口。
    if (await scrollPageUntilClickable(element)) {
      if (await realClickViaCdp(element, `${label}(已整页滚动)`)) return true;
      if (await withPanelHidden(() => realClickViaCdp(element, `${label}(已滚动+面板已隐藏)`))) return true;
    }
    tabDiag("CDP 点击不可用，退回合成事件（达摩盘可能不响应）", { label });
    dispatchRealisticClick(element);
    return false;
  }

  // 整页滚动，直到目标元素的中心点进入视口。
  // 用于浮层内落在视口外的元素：浮层自身不能 scrollIntoView（会带着锚点一起动），
  // 但整页滚动会同时移动锚点和浮层，能把浮层下半部分带进视口。
  async function scrollPageUntilClickable(element) {
    for (let attempt = 0; attempt < 4; attempt += 1) {
      const rect = element.getBoundingClientRect();
      const centerY = rect.top + rect.height / 2;
      const centerX = rect.left + rect.width / 2;
      if (centerY >= 0 && centerY <= window.innerHeight && centerX >= 0 && centerX <= window.innerWidth) {
        return true;
      }
      const before = window.scrollY;
      // 目标在视口下方就往下滚，在上方就往上滚，每次滚到让它落在视口中部。
      window.scrollBy({ top: Math.round(centerY - window.innerHeight / 2), behavior: "instant" });
      await wait(240);
      // 滚不动了（已经到底/到顶）就别再试。
      if (window.scrollY === before) break;
    }
    const rect = element.getBoundingClientRect();
    const centerY = rect.top + rect.height / 2;
    const ok = centerY >= 0 && centerY <= window.innerHeight;
    if (!ok) tabDiag("整页滚动后目标仍在视口外", { y: Math.round(centerY), vh: window.innerHeight });
    return ok;
  }

  // 达摩盘页签同一份文案会同时出现在 A / DIV / SPAN 三层元素上（已由页面实测确认），
  // 监听器可能挂在其中任意一层，只点一个未必生效。这里把所有同名候选按"由内到外"
  // 依次尝试，每次点完都核对是否真的触发了业务请求。
  function comparisonTabCandidates(label) {
    const wanted = normalizeText(label);
    const matched = queryElements(document, "[role='tab'],button,a,li,span,div")
      .filter(isVisible)
      .filter(element => normalizeText(element.textContent) === wanted);
    // 文本越短越接近真实叶子节点，优先点内层，再退到外层容器。
    const ordered = matched.sort((left, right) => (left.textContent || "").length - (right.textContent || "").length);
    const seen = new Set();
    return ordered.filter(element => {
      if (seen.has(element)) return false;
      seen.add(element);
      return true;
    }).slice(0, 6);
  }

  // 判断页签是否已经是选中态。
  // 达摩盘用下划线+主题色表示选中，class 名是混淆的（asiYsrRaf 这类），
  // 所以 active/selected 这类关键字基本匹配不到——只靠 class 判断会把
  // 默认选中的「关键指标对比」也判成未选中，而它本来就选中、点了也不会重新取数，
  // 于是"已激活:false + 业务请求数:0"，整个页签被误判成失败。
  // 因此使用 aria 状态、class 关键字和目标本身的底部高亮边框。不能再用“文字是蓝色”
  // 作为选中依据：当前页面三个页签都继承了蓝色主题文字，0.9.10 因而把推广策略和
  // 人群对比都误判为已选中，实际一次页签点击都没有发生。
  function isTabActive(element) {
    const clickTarget = pageClickTarget(element);
    const nodes = [element, clickTarget, clickTarget?.parentElement].filter(Boolean);
    for (const node of nodes) {
      if (node.getAttribute?.("aria-selected") === "true") return true;
      const cls = String(node.className || "");
      if (/(^|[\s_-])(active|selected|current|checked)([\s_-]|$)|is-active|is-selected|-active|-selected/i.test(cls)) return true;
      if (hasSelectedStyling(node)) return true;
    }
    return false;
  }

  // 选中态的视觉特征只认目标自身的底部高亮边框（下划线）。主题色文字不是可靠信号。
  function hasSelectedStyling(node) {
    if (!node?.getBoundingClientRect) return false;
    const view = node.ownerDocument?.defaultView || window;
    let style;
    try { style = view.getComputedStyle(node); } catch { return false; }
    if (!style) return false;
    // 下划线：底边框有宽度且颜色不透明。
    const bottomWidth = parseFloat(style.borderBottomWidth) || 0;
    if (bottomWidth >= 2 && !/rgba\([^)]*,\s*0\)/.test(style.borderBottomColor || "")) return true;
    return false;
  }

  function tabIsCurrentlyActive(label) {
    return comparisonTabCandidates(label).some(isTabActive);
  }

  // 只有三个页签中恰好一个具备选中信号时，才允许靠样式判定当前页签。
  // 如果三个都被主题样式误命中，就返回空，强制实际点击并用内容/请求核对。
  function uniquelyActiveComparisonTab() {
    const activeLabels = workflow.COMPARISON_TABS.filter(label => tabIsCurrentlyActive(label));
    return activeLabels.length === 1 ? activeLabels[0] : "";
  }

  // 每个对比页签独有的内容特征。用来在 class 名混淆、又没有新请求（命中缓存）时
  // 判断"当前显示的到底是哪个页签的内容"——这是最贴近用户所见的信号。
  const TAB_CONTENT_MARKERS = {
    "关键指标对比": [/营销推广点击量/, /自然点击量/, /支付转化率/],
    "推广策略对比": [/场景投放策略明细/, /一级场景名称/, /消耗占比/],
    "人群对比": [/人群结构/, /人群数/, /宝贝新客/]
  };

  // 页面上是否正在显示该页签的内容。
  function tabContentVisible(label) {
    const markers = TAB_CONTENT_MARKERS[label] || [];
    if (!markers.length) return false;
    const text = normalizeText(document.body?.textContent || "");
    // 至少命中两个特征才算，避免单个词在别处偶然出现造成误判。
    const hits = markers.filter(pattern => pattern.test(text)).length;
    return hits >= 2;
  }

  // 点击页签后确认它确实切过去了。
  // 三种信号取其一，任何一个成立都算成功：
  //   ① 页签变成激活态（aria/class/选中样式）；
  //   ② 页面上出现了该页签独有的内容特征；
  //   ③ 产生了新的业务请求。
  // 只用 ①+③ 会漏判：达摩盘 class 名混淆、默认页签本来就选中且命中缓存不重新取数，
  // 「关键指标对文」这种默认页签就会被误判成"点击失败"（实测 已激活:false + 业务请求数:0）。
  async function clickTabAndAwaitData(label) {
    const candidates = comparisonTabCandidates(label);
    if (!candidates.length) {
      tabDiag("未找到页签元素", { label });
      return { opened: false, method: "", since: "", reason: "页面未找到该页签元素" };
    }

    // 已经是当前页签就不用点了，直接去确认日期。
    const activeBefore = uniquelyActiveComparisonTab();
    if (activeBefore === label || tabContentVisible(label)) {
      tabDiag("页签已处于选中态，跳过点击", { label, 内容特征: tabContentVisible(label), 唯一选中页签: activeBefore || "无" });
      return { opened: true, method: "已选中", since: new Date().toISOString() };
    }

    tabDiag("开始点击页签", { label, candidates: candidates.map(el => el.tagName).join(",") });

    const strategies = [
      { name: "CDP真实点击", run: element => realClickViaCdp(element, label) },
      // 被插件面板挡住时，藏起面板再按坐标点一次。
      { name: "CDP真实点击(面板已隐藏)", run: element => withPanelHidden(() => realClickViaCdp(element, `${label}(面板已隐藏)`)) },
      { name: "合成事件序列", run: element => { dispatchRealisticClick(element); return true; } }
    ];

    for (const strategy of strategies) {
      for (let index = 0; index < candidates.length; index += 1) {
        const element = candidates[index];
        const since = new Date().toISOString();
        const dispatched = await strategy.run(element);
        if (currentJob) {
          currentJob.tabClicks = currentJob.tabClicks || [];
          currentJob.tabClicks.push({
            label, strategy: strategy.name, attempt: index + 1, tag: element.tagName,
            dispatched: Boolean(dispatched), text: normalizeText(element.textContent).slice(0, 20)
          });
        }
        if (!dispatched) continue;
        // 点完要给页面时间发请求、给 CDP 时间取回响应体、给插件时间读回记录。
        await settleAfterAction({ label: `页签点击:${label}`, since, minimumMs: 900, quietMaximumMs: 10000, readbackMs: 7000 });
        const hits = countBusinessRecords(since);
        const active = uniquelyActiveComparisonTab() === label;
        const content = tabContentVisible(label);
        tabDiag("点击结果", { label, strategy: strategy.name, tag: element.tagName, 业务请求数: hits, 已激活: active, 内容特征: content });
        // 三种信号任一成立就算切过去了：有没有立刻取数取决于页面缓存，
        // 日期确认那一步还会再触发一次。
        if (active || content || hits > 0) {
          return { opened: true, method: `${strategy.name}/${element.tagName}#${index + 1}`, since };
        }
      }
    }
    return { opened: false, method: "", since: "", reason: `${candidates.length} 个候选 × ${strategies.length} 种点击方式都没能切换页签` };
  }

  // 「推广策略对比」页签下有个「场景投放策略明细」下拉（当前页面组件配置的 7 个渠道：
  // 关键词推广/人群推广/线索推广/货品全站推/店铺运营/货品运营/内容营销）。
  // 每切一个渠道才会请求一次 scene 明细，不遍历就只能拿到默认的「关键词推广」。
  const SCENE_CHANNELS = ["关键词推广", "人群推广", "线索推广", "货品全站推", "店铺运营", "货品运营", "内容营销"];

  // 找「场景投放策略明细」的下拉触发器。
  // 难点：下拉展开后，选项列表里每个 <li> 的文案也等于渠道名，
  // 直接按文案找会把选项当成触发器，导致第二轮开始全部错位。
  // 达摩盘的类名是混淆的（asiYsrRqV 这类），既不能靠 select/trigger 关键字来认，
  // 也不能靠它来排除——实测触发器自身的混淆类名可能含 "select"，
  // 旧逻辑把它当弹出层排除掉，于是报"未找到渠道下拉触发器"、7 个渠道一个都没切。
  //
  // 可靠的锚点是区块标题「场景投放策略明细」：触发器就在这个标题附近的容器里，
  // 而弹出层通常挂在 body 末尾、不在这个容器内。
  const SCENE_SECTION_TITLE = /场景投放策略明细/;

  // 找标题所在的区块容器，用来把搜索范围限定在这一块里。
  function sceneSectionHeading() {
    return queryElements(document, "div,span,h1,h2,h3,h4,p,label")
      .filter(isVisible)
      .filter(element => {
        if (element.closest?.("#dmp-cdp-monitor")) return false;
        const text = normalizeText(element.textContent);
        return text.length <= 20 && SCENE_SECTION_TITLE.test(text);
      })
      .sort((left, right) => normalizeText(left.textContent).length - normalizeText(right.textContent).length)[0];
  }

  function sceneSectionScope() {
    const heading = sceneSectionHeading();
    if (!heading) return null;
    // 往上找几层，直到容器里能同时看到标题和某个渠道名（即下拉触发器）。
    let node = heading.parentElement;
    for (let depth = 0; node && depth < 10; node = node.parentElement, depth += 1) {
      const text = normalizeText(node.textContent);
      if (SCENE_CHANNELS.some(channel => text.includes(normalizeText(channel)))) return node;
    }
    return heading.parentElement || null;
  }

  function sceneChannelTrigger() {
    const scope = sceneSectionScope();
    const heading = sceneSectionHeading();
    // 优先在区块容器内找；找不到容器再退回全页扫描（保持旧行为兜底）。
    const pools = scope ? [scope, document] : [document];
    for (const pool of pools) {
      const matched = queryElements(pool, "div,span,button,[role='combobox'],[aria-haspopup='listbox'],[aria-expanded],[class*='select'],[class*='trigger']")
        .filter(isVisible)
        .filter(element => {
          if (element.closest?.("#dmp-cdp-monitor")) return false;
          // 只排除明确是弹出层的容器（role/aria 是可靠信号，混淆类名不是）。
          if (element.closest?.("[role='listbox'],[role='menu'],[aria-hidden='true']")) return false;
          // 在区块容器内搜索时，容器外的元素（弹出层挂在 body 末尾）自然被排除。
          if (pool !== document && !pool.contains(element)) return false;
          const text = normalizeText(element.textContent);
          return text.length <= 20 && SCENE_CHANNELS.some(name => text === normalizeText(name));
        });
      const found = matched
        .map(element => {
          const rect = element.getBoundingClientRect();
          const headingRect = heading?.getBoundingClientRect?.();
          const semantic = element.matches?.("[role='combobox'],[aria-haspopup='listbox'],[aria-expanded]") ? 1 : 0;
          const inScope = Boolean(scope && scope.contains(element));
          const distance = headingRect
            ? Math.abs(rect.top - headingRect.bottom) + Math.abs(rect.left - headingRect.left) * 0.25
            : 0;
          return { element, semantic, inScope, distance, area: rect.width * rect.height };
        })
        // 区块内、带下拉语义、离标题最近的候选优先；这样全页兜底也不会误拿表格中的渠道名。
        .sort((left, right) => Number(right.inScope) - Number(left.inScope) || right.semantic - left.semantic || left.distance - right.distance || left.area - right.area)[0]?.element;
      if (found) return found;
    }
    return null;
  }

  // 在已展开的下拉里找指定渠道的选项。必须排除触发器自己
  // （它的文案就是当前选中的渠道，会和选项重名）。
  function sceneChannelOption(channel, trigger) {
    const wanted = normalizeText(channel);
    const matched = queryElements(document, "li,[role='option'],div,span")
      .filter(isVisible)
      .filter(element => {
        if (element.closest?.("#dmp-cdp-monitor")) return false;
        if (trigger && (element === trigger || trigger.contains(element) || element.contains(trigger))) return false;
        return normalizeText(element.textContent) === wanted;
      });
    // 优先取明确是选项的（role/li 是可靠信号），其次取最内层的文本节点。
    // 不用混淆类名判断"在不在弹出层里"——达摩盘的类名靠不住。
    const asOption = matched.filter(element =>
      element.matches?.("li,[role='option']") || element.closest?.("li,[role='option'],[role='listbox'],[role='menu'],ul"));
    const pool = asOption.length ? asOption : matched;
    return pool.sort((left, right) => (left.textContent || "").length - (right.textContent || "").length)[0] || null;
  }

  // 下拉是不是展开着（选项已渲染）。用来判断该点触发器还是该收下拉。
  function sceneDropdownIsOpen(trigger) {
    return SCENE_CHANNELS.some(channel => sceneChannelOption(channel, trigger));
  }

  async function closeSceneDropdown(trigger) {
    if (!sceneDropdownIsOpen(trigger)) return;
    document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true }));
    await wait(260);
    // Esc 收不掉就再点一次触发器（真实点击），否则展开的下拉会盖住下一轮的触发器。
    if (sceneDropdownIsOpen(trigger) && trigger) {
      await trustedClick(trigger, "场景下拉收起");
      await wait(260);
    }
  }

  // 逐个渠道：展开下拉 → 选中 → 确认选中生效 → 等数据加载 → 确认拿到数据。
  // 每一步都要核对，不能"点了就算"：
  //   合成事件 isTrusted=false，Magix 的选项监听不响应——实测表现就是
  //   下拉展开后一直挂着、选项点不动、7 个渠道只拿到默认的「关键词推广」。
  async function sweepSceneChannels() {
    const swept = [];
    const missed = [];
    for (let channelIndex = 0; channelIndex < SCENE_CHANNELS.length; channelIndex += 1) {
      const channel = SCENE_CHANNELS[channelIndex];
      let trigger = sceneChannelTrigger();
      if (!trigger) {
        tabDiag("场景明细：未找到渠道下拉触发器", { 停在: channel });
        // 触发器都不存在时，当前项及后续项都没有采集，不能再像 0.9.10 一样显示“未采集：无”。
        missed.push(...SCENE_CHANNELS.slice(channelIndex).filter(name => !missed.includes(name)));
        break;
      }
      // 已经是当前选中项：默认渠道（通常是「关键词推广」）的数据随页签一起加载过了。
      if (normalizeText(trigger.textContent) === normalizeText(channel)) {
        tabDiag("场景明细：已是当前渠道，沿用已加载数据", { channel });
        swept.push(channel);
        continue;
      }

      let selected = false;
      // 整个"展开→选中→核对"最多重试 3 轮：达摩盘下拉偶发一次点不开。
      for (let attempt = 0; attempt < 3 && !selected; attempt += 1) {
        // 1. 展开下拉，等选项渲染出来。
        //    展开前先把触发器顶到视口上部：下拉浮层锚在触发器下方，7 个渠道
        //    展开后有几百像素高，触发器靠下时后面几个选项会落到视口以下，
        //    CDP 按坐标点不到（实测「内容营销」这类末尾选项永远点不中）。
        if (!sceneDropdownIsOpen(trigger)) {
          await scrollTriggerToTop(trigger);
          await trustedClick(trigger, `场景下拉触发器:${channel}#${attempt + 1}`);
        }
        let option = null;
        for (let poll = 0; poll < 5 && !option; poll += 1) {
          await wait(240);
          option = sceneChannelOption(channel, trigger);
        }
        if (!option) {
          tabDiag("场景明细：下拉未展开或找不到该渠道选项", { channel, 第几轮: attempt + 1, 下拉已展开: sceneDropdownIsOpen(trigger) });
          await closeSceneDropdown(trigger);
          continue;
        }

        // 2. 选中渠道。必须真实点击，合成事件点不动。
        const since = new Date().toISOString();
        await trustedClick(option, `场景渠道选项:${channel}`);
        await wait(420);

        // 3. 核对选中是否真的生效——触发器文案应该已经变成这个渠道。
        trigger = sceneChannelTrigger() || trigger;
        selected = normalizeText(trigger.textContent) === normalizeText(channel);
        if (!selected) {
          tabDiag("场景明细：点了选项但触发器没变成该渠道", { channel, 第几轮: attempt + 1, 当前触发器: normalizeText(trigger.textContent).slice(0, 20) });
          await closeSceneDropdown(trigger);
          continue;
        }
        // 4. 选中生效后才等数据：等请求发出、等响应体取回、等记录读回。
        const settled = await settleAfterAction({ label: `场景渠道:${channel}`, since, minimumMs: 800, quietMaximumMs: 9000, readbackMs: 6000 });
        // 5. 确认这一轮真的拿到了数据。
        if (settled.usable > 0 || countBusinessRecords(since) > 0) {
          tabDiag("场景明细：渠道数据已到", { channel, 业务请求数: countBusinessRecords(since), 可用响应数: settled.usable });
          swept.push(channel);
        } else {
          // 选中生效但没取数：可能命中了页面缓存，不算失败，但要记下来。
          tabDiag("场景明细：渠道已选中但未观察到新请求（可能命中页面缓存）", { channel });
          swept.push(channel);
        }
      }
      if (!selected) missed.push(channel);
      await closeSceneDropdown(sceneChannelTrigger() || trigger);
    }
    tabDiag("场景明细渠道遍历完成", { 已采集: swept.join("、") || "无", 未采集: missed.join("、") || "无" });
    if (currentJob) currentJob.sceneMissed = missed;
    return swept;
  }

  async function runComparisonTabs(range) {
    const results = [];
    const failures = [];
    for (let index = 0; index < workflow.COMPARISON_TABS.length; index += 1) {
      const label = workflow.COMPARISON_TABS[index];
      setStep(`采集近30天：${label}`, 48 + Math.round(((index + 1) / workflow.COMPARISON_TABS.length) * 28));
      // 单个页签失败不能中断整轮采集：之前「关键指标对比」一失败，
      // 后面的「推广策略对比」「人群对比」就完全没机会跑，投放场景必然缺失。
      try {
        const clicked = await clickTabAndAwaitData(label);
        if (!clicked.opened) throw new Error(clicked.reason || "页签未切换");
        // 日期控件是全局的；confirmThirtyDays 会识别已选中的「过去 30 天」，后续页签直接沿用。
        const periodResult = await confirmThirtyDays(range, clicked.since);
        // 「推广策略对比」还要把场景明细的各个渠道都翻一遍，否则 scene 数据不全。
        let sceneChannels = [];
        if (label === "推广策略对比") {
          setStep(`采集近30天：${label} · 场景明细`, 48 + Math.round(((index + 1) / workflow.COMPARISON_TABS.length) * 28));
          sceneChannels = await sweepSceneChannels();
        }
        if (!periodResult.confirmed) {
          // 日期没落实是硬问题：页面很可能还停在默认的成长阶段区间（实测 5 天），
          // 那份数据不是 30 天。要在面板上说出来，不能只写进诊断日志。
          tabDiag("页签周期未确认：页面区间可能不是 30 天", { label, 页面区间: periodResult.shown });
          setStep(`${label}：日期未能落实为 30 天（页面显示 ${periodResult.shown || "未知区间"}）`, 48 + Math.round(((index + 1) / workflow.COMPARISON_TABS.length) * 28), "运行中", "warn");
        }
        // 页签数据在离开之前必须已经落地——下一次点击会覆盖页面状态。
        const settled = await settleAfterAction({ label: `页签收尾:${label}`, since: clicked.since, activityMs: 2000, minimumMs: 600, readbackMs: 6000 });
        results.push({
          label, opened: true, method: clicked.method,
          periodConfirmed: periodResult.confirmed, periodPrecision: periodResult.precision, periodShown: periodResult.shown,
          sceneChannels, usableResponses: settled.usable, startDate: range.startDate, endDate: range.endDate
        });
      } catch (error) {
        const reason = String(error?.message || error);
        tabDiag("页签采集失败，继续下一个", { label, reason });
        failures.push(`${label}（${reason}）`);
      }
    }
    if (!results.length) throw new Error(`三个对比页签都没能采集：${failures.join("；")}`);
    if (failures.length) currentJob.tabFailures = failures;
    return results;
  }

  function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  async function waitForNetworkQuiet({ minimumMs = 1300, quietMs = 1200, maximumMs = 9000 } = {}) {
    const started = Date.now();
    while (Date.now() - started < maximumMs) {
      await wait(350);
      const elapsed = Date.now() - started;
      if (elapsed >= minimumMs && Date.now() - lastRecordAt >= quietMs) return;
    }
  }

  // 一条业务记录要"可用"必须同时满足：是达摩盘业务接口、响应体已被 CDP 取回、没被截断。
  // 只数请求条数不够——responseReceived 先到，响应体是 loadingFinished 之后才 getResponseBody
  // 取回来的，中间有真实的时间差。差这一步就会拿着空 body 去解析。
  function usableBusinessRecords(since) {
    return records.filter(record => {
      if (since && record.capturedAt && record.capturedAt < since) return false;
      if (!isBusinessRecord(record)) return false;
      return record.bodyAvailable !== false && typeof record.body === "string" && record.body.trim().length > 0;
    }).length;
  }

  // 每次点击之后要等三段时间，缺一段就会取到空数据：
  //   ① 页面自己发请求——达摩盘前端有 debounce/动画，点完不是立刻发；
  //   ② 请求跑完 + 响应体被 CDP 取回并写进 IndexedDB；
  //   ③ 插件把记录读回内存（refreshTaskRecords），read-back 也要时间。
  // 三段都用"实际观测"收敛，而不是固定 sleep：先等到有请求发出，再等网络安静，
  // 最后反复读回直到可用记录数连续两轮不再增长。
  async function settleAfterAction({
    label = "操作",
    since,
    activityMs = 6000,
    minimumMs = 900,
    quietMs = 1100,
    quietMaximumMs = 9000,
    readbackMs = 6000,
    stableRounds = 2
  } = {}) {
    const started = Date.now();

    // ① 等页面真的发出业务请求。没等到不算失败：页面可能命中前端缓存。
    let requested = countBusinessRecords(since);
    while (requested === 0 && Date.now() - started < activityMs) {
      await wait(400);
      await refreshTaskRecords().catch(() => {});
      requested = countBusinessRecords(since);
    }
    const waitedForRequest = Date.now() - started;

    // ② 等网络安静，让这一批请求跑完。
    await waitForNetworkQuiet({ minimumMs, quietMs, maximumMs: quietMaximumMs });

    // ③ 反复读回，直到"响应体已可用"的记录数稳定下来。
    const readbackStarted = Date.now();
    let usable = -1;
    let stable = 0;
    while (Date.now() - readbackStarted < readbackMs) {
      await refreshTaskRecords().catch(() => {});
      const current = usableBusinessRecords(since);
      if (current === usable) {
        stable += 1;
        if (stable >= stableRounds) break;
      } else {
        stable = 0;
        usable = current;
      }
      await wait(450);
    }
    if (usable < 0) usable = usableBusinessRecords(since);

    const settled = {
      label,
      请求数: countBusinessRecords(since),
      可用响应数: usable,
      等请求ms: waitedForRequest,
      总耗时ms: Date.now() - started
    };
    tabDiag("等待数据落地完成", settled);
    if (currentJob) {
      currentJob.settleLog = currentJob.settleLog || [];
      currentJob.settleLog.push(settled);
    }
    return { requested: settled.请求数, usable, elapsedMs: settled.总耗时ms };
  }

  async function refreshTaskRecords() {
    if (!currentJob?.startedAt) return;
    const result = await runtimeMessage("DMP_CDP_GET_RECORDS", { since: currentJob.startedAt });
    if (!result?.ok) throw new Error(result?.error || "读取任务数据失败");
    mergeRecords(result.records || []);
  }

  function routeItemId() {
    const query = String(location.hash || "").split("?")[1] || "";
    const value = new URLSearchParams(query).get("itemId") || "";
    return /^\d{6,20}$/.test(value) ? value : "";
  }

  function parseRecordJson(record) {
    if (typeof record?.body !== "string" || !record.body.trim()) return null;
    try { return JSON.parse(record.body); } catch { return null; }
  }

  function eligibleSubjectIdFromData(data, excludedId) {
    let found = "";
    const walk = (value, depth = 0) => {
      if (found || !value || depth > 12) return;
      if (Array.isArray(value)) return value.forEach(child => walk(child, depth + 1));
      if (typeof value !== "object") return;
      const id = String(value.id ?? value.itemId ?? "");
      const looksLikeItem = id && ["name", "itemTitle", "gmv30d", "reservePrice", "onlineDays", "lifeCycleDesc"].some(key => value[key] !== undefined);
      if (/^\d{6,20}$/.test(id) && id !== excludedId && looksLikeItem) {
        found = id;
        return;
      }
      Object.values(value).forEach(child => walk(child, depth + 1));
    };
    walk(data);
    return found;
  }

  function detectSubjectItemId(excludedId = "") {
    const routed = routeItemId();
    if (routed && routed !== excludedId) return routed;
    for (let index = records.length - 1; index >= 0; index -= 1) {
      const record = records[index];
      const path = record?.pathname || record?.url || "";
      if (!path.includes("/api/goods/item/info")) continue;
      const detected = eligibleSubjectIdFromData(parseRecordJson(record), excludedId);
      if (detected) return detected;
    }
    return "";
  }

  // 达摩盘前端路由只认 hash 里的路径部分（#!/items/growup-path）和 itemId。
  // 页面本来就停在同一个商品的打爆路径时，即便我们给 hash 加上唯一的 dmpReportTask
  // nonce，路由也会判定"无需重新加载"，一条业务请求都不发（表现为五个模块全缺）。
  // 所以先切到一个中性路由，等路由真正卸载，再切回目标路由强制重新挂载。
  const NEUTRAL_ROUTE_HASH = "#!/items/shop-insight";

  async function routeToItem(itemId) {
    const nextHash = workflow.buildGrowupRouteHash(itemId, Date.now());
    const currentPath = String(location.hash || "").split("?")[0];
    const nextPath = nextHash.split("?")[0];
    const sameItem = routeItemId() === String(itemId);

    if (currentPath === nextPath && sameItem) {
      location.hash = NEUTRAL_ROUTE_HASH;
      // 等达摩盘把当前路由卸载掉，否则紧接着切回去仍会被当成"没变化"。
      await wait(900);
    }
    location.hash = nextHash;
  }

  async function runReport() {
    if (!await refreshSiteStatus()) return;
    const successItemId = ui.successItemId.value.trim();
    if (!/^\d{6,20}$/.test(successItemId)) {
      setStatus("请输入 6–20 位成功品/竞品商品 ID", "#ff9d9d");
      ui.successItemId.focus();
      return;
    }
    const subjectItemId = ui.subjectItemId.value.trim() || detectSubjectItemId(successItemId);
    if (!/^\d{6,20}$/.test(subjectItemId)) {
      setStatus("请填写本店有权访问且近30天有销量的主体商品 ID", "#ff9d9d");
      ui.subjectItemId.focus();
      return;
    }
    if (subjectItemId === successItemId) {
      setStatus("主体商品与成功品/竞品不能是同一个商品", "#ff9d9d");
      ui.successItemId.focus();
      return;
    }
    ui.subjectItemId.value = subjectItemId;
    if (!location.hostname.endsWith("dmp.taobao.com")) {
      setStatus("请在达摩盘页面运行", "#ff9d9d");
      return;
    }

    ui.run.disabled = true;
    ui.downloadExcel.disabled = true;
    ui.downloadCsv.disabled = true;
    ui.copyReport.disabled = true;
    const period = workflow.pastCompletedDays(30);
    currentJob = {
      id: `${Date.now()}-${subjectItemId}-${successItemId}`,
      itemId: subjectItemId,
      subjectItemId,
      successItemId,
      startedAt: new Date().toISOString(),
      status: "running",
      progress: 3,
      periodConfirmed: false,
      period,
      visitedPaths: [],
      report: null
    };

    try {
      setStatus(`正在分析主体 ${subjectItemId} vs 成功品 ${successItemId}`, "#76e287");
      setStep("连接 CDP 监听", 5);
      await persistJob();
      // 不能用 RECONNECT：它会先 detach，摧毁已生效的 Network.enable，
      // 而紧接着的 routeToItem 立刻就会发出 item/info 等业务请求，
      // 空窗期内这些请求会全部丢失（表现为五个模块全缺）。
      const connected = await runtimeMessage("DMP_CDP_ENSURE_ATTACHED");
      if (!connected?.ok) throw new Error(connected?.error || "监听连接失败");
      // 给 Network.enable 一点时间在 Chrome 侧真正生效，再触发路由。
      await wait(600);

      setStep("进入商品打爆路径页面", 15);
      const routeSince = new Date().toISOString();
      await routeToItem(subjectItemId);
      // 首屏要加载的接口最多，给足时间：等请求发出、等响应体取回、等记录读回。
      await settleAfterAction({ label: "路由首屏", since: routeSince, activityMs: 9000, minimumMs: 2200, quietMs: 1400, quietMaximumMs: 16000, readbackMs: 9000 });
      // 只统计达摩盘业务请求：页面的曝光/点击埋点一直在发，
      // 用记录总数判断会被埋点骗过（曾导致路由没真正重载却继续跑完并输出空报告）。
      if (countBusinessRecords(routeSince) === 0) {
        throw new Error("路由切换后没有捕获到任何达摩盘业务请求：请关闭本页 DevTools（会占用 CDP 调试连接），再点“启动/重连监听”后重试");
      }
      const accessError = subjectAccessError(subjectItemId);
      if (accessError) throw new Error(`主体商品 ${subjectItemId} 不可用于单品洞察：请确认是本店商品且近30天有销量`);

      setStep("清空默认成功品、应用筛选并添加目标", 27);
      try {
        currentJob.successProduct = await ensureSuccessProductAdded(successItemId);
      } catch (error) {
        currentJob.successProduct = { confirmed: false, method: String(error?.message || error), degraded: true };
      }
      if (!currentJob.successProduct.confirmed) {
        currentJob.successProduct = { confirmed: true, degraded: true, method: "已降级：成功品面板未识别，跳过该步骤继续" };
        const apiReason = currentJob.successApiError ? `（接口失败：${currentJob.successApiError}）` : "（接口未尝试）";
        setStep(`成功品面板未识别，跳过继续${apiReason}`, 40, "运行中", "warn");
      }

      setStep("准备三个对比页签的近30天周期", 43);
      try {
        currentJob.tabResults = await runComparisonTabs(period);
        currentJob.visitedPaths = currentJob.tabResults.map(result => result.label);
        currentJob.periodConfirmed = currentJob.tabResults.length === workflow.COMPARISON_TABS.length && currentJob.tabResults.every(result => result.periodConfirmed);
        // 口径取所有页签里最弱的一档：任一页签只拿到预设口径，整份报告就不能声称逐日精确。
        currentJob.periodPrecision = currentJob.tabResults.some(result => result.periodPrecision === "failed") || !currentJob.periodConfirmed
          ? "failed"
          : currentJob.tabResults.every(result => result.periodPrecision === "exact") ? "exact" : "preset";
        currentJob.periodShown = currentJob.tabResults.map(result => result.periodShown).find(Boolean) || "";
      } catch (error) {
        currentJob.tabResults = [];
        currentJob.visitedPaths = [];
        currentJob.periodConfirmed = false;
        currentJob.periodPrecision = "failed";
        currentJob.tabError = String(error?.message || error);
        setStep(`对比页签未完全确认（${currentJob.tabError}），尝试用已采集数据生成`, 60, "运行中", "warn");
      }

      setStep("聚合接口并生成标准业务表格", 78);
      // 生成报告之前最后一次读回：确保最后一个页签的响应体也已经写进记录。
      await settleAfterAction({ label: "生成前最终读回", since: currentJob.startedAt, activityMs: 1500, minimumMs: 600, readbackMs: 8000, stableRounds: 3 });
      currentJob.finishedAt = new Date().toISOString();
      currentJob.report = engine.buildReport(records, subjectItemId, currentJob);

      // v2.0 完整性门禁：阻断状态只在面板里展示已取得的局部数据和缺口，
      // 不再把局部结果包装成可下载的“完整报告”。未知结构、缺日、缺渠道、
      // 对象/周期不匹配都应先补抓或扩展确定性解析器。
      if (!currentJob.report.quality.complete) {
        const gateReasons = [
          ...(currentJob.report.quality.blockingIssues || []),
          ...(currentJob.report.quality.deterministicMissing || []).map(label => `${label}未填`),
          ...(currentJob.report.quality.warnings || [])
        ];
        currentJob.analysis = { attempted: false, skipped: true, error: "v2.0 完整性门禁未通过" };
        currentJob.ai = { ok: false, skipped: true, error: "完整性门禁未通过，未送 API 校验", checkedAt: new Date().toISOString() };
        currentJob.status = "blocked";
        setStep(`完整性门禁阻断：${gateReasons.slice(0, 3).join("；") || "关键数据未闭合"}`, 100, "待补抓", "bad");
        renderReport(currentJob.report);
        await persistJob();
        setStatus("数据未闭合，已停止导出；请按面板缺口补抓", "#ff9d9d");
        return;
      }

      // 确定性解析已闭合时不让模型碰表格中的“业务上本就不可得”空白；
      // 只有解析器明确登记的必填缺口才允许进入旧的受限补值通道。
      // API 仍只能补空格、不能改本地值，且每个值必须带出处。
      const analysisPayload = engine.buildAnalysisPayload(records, subjectItemId, currentJob);
      currentJob.analysis = { attempted: true, modules: analysisPayload.modules.length };
      if (!(currentJob.report.quality.deterministicMissing || []).length) {
        currentJob.analysis = { attempted: true, ok: true, skipped: true, modules: analysisPayload.modules.length, applied: [], rejected: [], error: "确定性解析已闭合，无需模型补值" };
        setStep("确定性解析与公式回填已闭合", 89);
      } else try {
        setStep("调用 API 深度解析接口原始数据", 86);
        const analyzeResult = await runtimeMessage("DMP_CDP_AI_ANALYZE", {
          payload: analysisPayload,
          report: engine.toCanonicalReport(currentJob.report)
        });
        if (analyzeResult?.ok && !analyzeResult.skipped) {
          const merged = engine.applyAnalysis(currentJob.report, analyzeResult.analysis);
          currentJob.report = merged.report;
          currentJob.analysis = {
            attempted: true, ok: true, modules: analysisPayload.modules.length,
            blanksAsked: analyzeResult.blanks_asked || 0,
            applied: merged.applied, rejected: merged.rejected,
            unresolved: analyzeResult.analysis?.unresolved || [],
            droppedOutOfScope: analyzeResult.dropped_out_of_scope || 0,
            model: analyzeResult.model || ""
          };
          setStep(`深度解析已回填 ${merged.applied.length} 个空格（拒绝 ${merged.rejected.length} 个）`, 89);
        } else if (analyzeResult?.skipped) {
          currentJob.analysis = { attempted: true, ok: false, skipped: true, modules: analysisPayload.modules.length, error: analyzeResult.reason || "无需深度解析" };
          setStep(`深度解析跳过：${currentJob.analysis.error}`, 89, "运行中", "warn");
        } else {
          // 四类错误分开显示：解析失败 / 没获取到 JSON / 计算错误 / API 失败。
          currentJob.analysis = {
            attempted: true, ok: false, modules: analysisPayload.modules.length,
            code: analyzeResult?.code || "API_FAILED",
            error: analyzeResult?.error || "深度解析不可用",
            detail: analyzeResult?.detail || {}
          };
          setStep(`${analysisErrorLabel(currentJob.analysis.code)}：${currentJob.analysis.error}`, 89, "运行中", "warn");
        }
      } catch (error) {
        // 深度解析失败不能拖垮报告：本地规则引擎的结果本身就是完整可下载的。
        currentJob.analysis = { attempted: true, ok: false, code: "API_FAILED", modules: analysisPayload.modules.length, error: String(error?.message || error) };
        setStep(`API 失败，保留本地结果：${currentJob.analysis.error}`, 89, "运行中", "warn");
      }

      const canonical = engine.toCanonicalReport(currentJob.report);
      const localValidation = engine.validateCanonicalReport(canonical);
      if (!localValidation.ok) throw new Error(localValidation.error || "本地报告结构校验失败");

      setStep("通过本机端口调用 ChatGPT API 校验", 93);
      const aiResult = await runtimeMessage("DMP_CDP_AI_GENERATE", { report: canonical });
      currentJob.ai = {
        ok: Boolean(aiResult?.ok),
        skipped: Boolean(aiResult?.skipped),
        model: aiResult?.model || "",
        responseId: aiResult?.response_id || "",
        error: aiResult?.ok ? "" : (aiResult?.error || "ChatGPT API 校验不可用"),
        checkedAt: new Date().toISOString()
      };
      ui.aiState.textContent = currentJob.ai.ok ? `API 已校验 · ${currentJob.ai.model}` : currentJob.ai.skipped ? "API 未启用" : "API 降级为本地";
      ui.aiState.className = `pill ${currentJob.ai.ok ? "" : "warn"}`.trim();
      currentJob.status = currentJob.report.quality.complete ? "completed" : "partial";
      setStep(
        currentJob.report.quality.complete ? "报告生成完成" : `报告已生成，缺少：${currentJob.report.quality.missing.join("、") || "部分响应"}`,
        100,
        currentJob.report.quality.complete ? "已完成" : "部分完成",
        currentJob.report.quality.complete ? "" : "warn"
      );
      renderReport(currentJob.report);
      await persistJob();
      setStatus(`主体 ${subjectItemId} vs 成功品 ${successItemId} 报告可下载${currentJob.ai.ok ? "（API 已校验）" : "（本地规则输出）"}`, currentJob.report.quality.complete ? "#76e287" : "#ffd66b");
    } catch (error) {
      currentJob.status = "failed";
      currentJob.error = String(error?.message || error);
      setStep(currentJob.error, currentJob.progress || 0, "运行失败", "bad");
      setStatus(`运行失败：${currentJob.error}`, "#ff9d9d");
      await persistJob().catch(() => {});
    } finally {
      ui.run.disabled = !siteAuthorized;
    }
  }

  function renderSelectedTable(report, tableName) {
    ui.previewWrap.replaceChildren();
    const current = report.tables.find(candidate => candidate.name === tableName) || report.tables[0];
    if (!current || !current.rows.length) {
      const empty = document.createElement("div");
      empty.className = "empty";
      empty.textContent = `${current?.name || "该业务表"}暂无可披露数据`;
      ui.previewWrap.appendChild(empty);
      return;
    }
    const table = document.createElement("table");
    const thead = document.createElement("thead");
    const headRow = document.createElement("tr");
    current.columns.forEach(label => {
      const th = document.createElement("th");
      th.textContent = label;
      headRow.appendChild(th);
    });
    thead.appendChild(headRow);
    const tbody = document.createElement("tbody");
    current.rows.slice(0, 200).forEach(row => {
      const tr = document.createElement("tr");
      row.forEach((value, index) => {
        const td = document.createElement("td");
        const semantic = current.name === "对标总表" ? `${current.columns[index]} ${row[1]}` : current.name === "基础指标对比" ? `${current.columns[index]} ${row[0]}` : current.columns[index];
        td.textContent = engine.formatMetricValue(semantic, value);
        tr.appendChild(td);
      });
      tbody.appendChild(tr);
    });
    table.append(thead, tbody);
    ui.previewWrap.appendChild(table);
  }

  function renderReport(report) {
    if (report?.version !== 3 || !Array.isArray(report.tables)) {
      ui.previewWrap.innerHTML = '<div class="empty">旧版报告结构已失效，请重新点击“一键运行”</div>';
      return;
    }
    const exportable = report.quality?.complete === true;
    ui.downloadExcel.disabled = !exportable;
    ui.downloadCsv.disabled = !exportable;
    ui.copyReport.disabled = !exportable;
    const rowCount = report.tables.reduce((sum, current) => sum + current.rows.length, 0);
    // 深度解析回填了多少格、被拒了多少格，直接显示出来——这是可审计的关键信息。
    const analysis = currentJob?.analysis;
    const analysisText = !analysis?.attempted ? ""
      : analysis.ok ? ` · API补${analysis.applied?.length || 0}格${analysis.rejected?.length ? `/拒${analysis.rejected.length}` : ""}`
      : analysis.skipped ? " · API解析已跳过"
      : ` · ${analysisErrorLabel(analysis.code)}`;
    // 日期口径和场景渠道覆盖都要能一眼看到：这两处出问题时数据是"看着对但不对"。
    const precision = currentJob?.periodPrecision;
    const periodText = precision === "exact" ? "" : precision === "preset" ? " · 日期为页面预设口径" : precision ? " · 日期未落实30天" : "";
    const sceneMissed = currentJob?.sceneMissed?.length ? ` · 场景缺${currentJob.sceneMissed.length}渠道` : "";
    const gateText = exportable ? "" : ` · 已阻断：${(report.quality.blockingIssues || report.quality.missing || []).slice(0, 2).join("；") || "关键数据未闭合"}`;
    ui.quality.textContent = `覆盖 ${report.quality.observed}/${report.quality.expected} · ${report.tables.length} 表 · ${rowCount} 行${analysisText}${periodText}${sceneMissed}${gateText}`;
    const selected = ui.previewTable.value;
    ui.previewTable.replaceChildren();
    report.tables.forEach(current => {
      const option = document.createElement("option");
      option.value = current.name;
      option.textContent = `${current.name}（${current.rows.length}）`;
      ui.previewTable.appendChild(option);
    });
    ui.previewTable.disabled = false;
    ui.previewTable.value = report.tables.some(current => current.name === selected) ? selected : (report.tables.find(current => current.name === "对标总表")?.name || report.tables[0]?.name || "");
    renderSelectedTable(report, ui.previewTable.value);
  }

  function downloadBlob(content, filename, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.style.display = "none";
    document.documentElement.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }

  function publicReport(report) {
    return engine.toCanonicalReport(report);
  }

  function reportFilename(extension) {
    const subject = currentJob?.subjectItemId || currentJob?.itemId || "未识别主体";
    const opponent = currentJob?.successItemId || currentJob?.report?.item?.competitorId || "未识别对手";
    return engine.safeFilename(`达摩盘_商品成长竞品对标报告_${subject}_vs_${opponent}`) + extension;
  }

  function copyTextToClipboard(text) {
    // 优先同步走 execCommand，因为它不依赖异步 Clipboard API 的用户手势/权限策略，
    // 在达摩盘这类可能禁用 navigator.clipboard 的页面上更可靠。
    try {
      const textarea = document.createElement("textarea");
      textarea.value = text;
      textarea.setAttribute("readonly", "");
      textarea.style.cssText = "position:fixed;top:-9999px;left:-9999px;opacity:0;";
      document.documentElement.appendChild(textarea);
      textarea.focus();
      textarea.select();
      const ok = document.execCommand("copy");
      textarea.remove();
      if (ok) return Promise.resolve({ ok: true });
    } catch (error) {
      // 忽略，继续尝试异步 Clipboard API。
    }
    return (async () => {
      try {
        if (navigator.clipboard && window.isSecureContext) {
          await navigator.clipboard.writeText(text);
          return { ok: true };
        }
      } catch (error) {
        // 忽略，走失败分支。
      }
      return { ok: false, error: "浏览器剪贴板不可用，请改用「下载记录 JSON」" };
    })();
  }

  ui.run.addEventListener("click", () => void runReport());
  ui.subjectItemId.addEventListener("keydown", event => { if (event.key === "Enter") ui.successItemId.focus(); });
  ui.successItemId.addEventListener("keydown", event => { if (event.key === "Enter") void runReport(); });
  ui.previewTable.addEventListener("change", () => {
    if (currentJob?.report) renderSelectedTable(currentJob.report, ui.previewTable.value);
  });
  ui.settings.addEventListener("click", async () => {
    ui.settings.disabled = true;
    try {
      const result = await runtimeMessage("DMP_CDP_OPEN_OPTIONS");
      if (!result?.ok) throw new Error(result?.error || "设置页打开失败");
      setStatus("设置页已打开", "#76e287");
    } catch (error) {
      setStatus(`设置页打开失败：${error.message || error}`, "#ff9d9d");
    } finally {
      ui.settings.disabled = false;
    }
  });
  ui.downloadExcel.addEventListener("click", () => {
    if (!currentJob?.report) return;
    try {
      downloadBlob(xlsxWriter.buildXlsx(currentJob.report), reportFilename(".xlsx"), xlsxWriter.MIME_TYPE);
    } catch (error) {
      setStatus(`XLSX 生成失败：${error?.message || error}`, "#ff9d9d");
    }
  });
  ui.downloadCsv.addEventListener("click", () => {
    if (!currentJob?.report) return;
    downloadBlob(engine.buildCsv(currentJob.report), reportFilename(".csv"), "text/csv;charset=utf-8");
  });
  ui.copyReport.addEventListener("click", async () => {
    if (!currentJob?.report) return;
    const result = await copyTextToClipboard(JSON.stringify(publicReport(currentJob.report), null, 2));
    const original = ui.copyReport.textContent;
    ui.copyReport.textContent = result.ok ? "已复制" : "复制失败";
    setStatus(result.ok ? "业务数据 JSON 已复制" : `复制失败：${result.error}`, result.ok ? "#76e287" : "#ff9d9d");
    setTimeout(() => { ui.copyReport.textContent = original; }, 1200);
  });
  ui.start.addEventListener("click", async () => {
    const result = await runtimeMessage("DMP_CDP_RECONNECT");
    setStatus(result?.ok ? "监听已连接" : result?.error || "连接失败", result?.ok ? "#76e287" : "#ff9d9d");
  });
  function scopedRecords() {
    return currentJob?.startedAt ? records.filter(record => !record.capturedAt || record.capturedAt >= currentJob.startedAt) : records;
  }

  function recordFilename(extension) {
    const subject = currentJob?.subjectItemId || currentJob?.itemId || "未识别主体";
    const opponent = currentJob?.successItemId || "未识别对手";
    return engine.safeFilename(`达摩盘_监听记录_${subject}_vs_${opponent}_${new Date().toISOString().replace(/[:.]/g, "-")}`) + extension;
  }

  ui.copyRecords.addEventListener("click", async () => {
    const scoped = scopedRecords();
    const result = await copyTextToClipboard(JSON.stringify(scoped, null, 2));
    const button = ui.copyRecords;
    const original = button.textContent;
    button.classList.remove("ok", "bad", "pulse");
    void button.offsetWidth; // 强制重排以重启动画
    if (result.ok) {
      button.textContent = "✓ 已成功";
      button.classList.add("ok", "pulse");
      setStatus(`已复制本次 ${scoped.length} 条记录`, "#76e287");
    } else {
      button.textContent = "复制失败";
      button.classList.add("bad");
      setStatus(`复制失败：${result.error}`, "#ff9d9d");
    }
    setTimeout(() => {
      button.textContent = original;
      button.classList.remove("ok", "bad", "pulse");
    }, 1200);
  });
  ui.downloadRecords.addEventListener("click", () => {
    const scoped = scopedRecords();
    downloadBlob(JSON.stringify(scoped, null, 2), recordFilename(".json"), "application/json;charset=utf-8");
    setStatus(`已下载本次 ${scoped.length} 条记录`, "#76e287");
  });
  ui.clear.addEventListener("click", async () => {
    ui.clear.disabled = true;
    try {
      const result = await runtimeMessage("DMP_CDP_CLEAR_RECORDS");
      if (!result?.ok) throw new Error(result?.error || "清空失败");
      records.length = 0;
      ui.count.textContent = "0 条";
      renderRecentRecords();
      setStatus("监听记录已清空", "#ffd66b");
    } catch (error) {
      setStatus(`清空失败：${error.message || error}`, "#ff9d9d");
    } finally {
      ui.clear.disabled = false;
    }
  });
  ui.collapse.addEventListener("click", () => {
    collapsed = !collapsed;
    ui.body.style.display = collapsed ? "none" : "block";
    ui.collapse.textContent = collapsed ? "+" : "—";
  });

  chrome.runtime.onMessage.addListener(message => {
    if (message.type === "DMP_CDP_STATUS") {
      if (!currentJob || currentJob.status !== "running") setStatus(message.message || (message.active ? "监听中" : "已停止"), message.active ? "#76e287" : "#ff9d9d");
      return;
    }
    if (message.type !== "DMP_CDP_RECORD" || !message.record) return;
    records.push(message.record);
    lastRecordAt = Date.now();
    ui.count.textContent = `${records.length} 条`;
    renderRecentRecords();
  });

  async function restore() {
    try {
      const [recordResult, jobResult] = await Promise.all([
        runtimeMessage("DMP_CDP_GET_RECORDS"),
        runtimeMessage("DMP_CDP_GET_JOB")
      ]);
      if (recordResult?.ok) mergeRecords(recordResult.records || []);
      if (jobResult?.ok && jobResult.job) {
        currentJob = jobResult.job;
        const legacyTarget = currentJob.successItemId || (currentJob.subjectItemId ? "" : currentJob.itemId) || "";
        ui.successItemId.value = legacyTarget;
        ui.subjectItemId.value = currentJob.subjectItemId || detectSubjectItemId(legacyTarget);
        if (currentJob.report) {
          renderReport(currentJob.report);
          if (currentJob.ai) {
            ui.aiState.textContent = currentJob.ai.ok ? `API 已校验 · ${currentJob.ai.model}` : currentJob.ai.skipped ? "API 未启用" : "API 降级为本地";
            ui.aiState.className = `pill ${currentJob.ai.ok ? "" : "warn"}`.trim();
          }
          setStep(currentJob.step || "已恢复上次报告", currentJob.progress || 100, currentJob.status === "completed" ? "已完成" : "部分完成", currentJob.status === "completed" ? "" : "warn");
          setStatus(`已恢复主体 ${currentJob.subjectItemId || currentJob.itemId} 的报告`, "#76e287");
        } else if (currentJob.status === "running") {
          currentJob.status = "interrupted";
          setStep("上次任务因页面刷新中断，请重新点击一键运行", currentJob.progress || 0, "待重跑", "warn");
          await persistJob();
        }
      } else {
        ui.subjectItemId.value = detectSubjectItemId();
        setStatus(records.length ? `已恢复 ${records.length} 条记录` : "等待运行", records.length ? "#76e287" : "#ffd66b");
      }
    } catch (error) {
      setStatus(`恢复失败：${error.message || error}`, "#ff9d9d");
    }
  }

  void refreshSiteStatus();
  window.setInterval(() => void refreshSiteStatus(), 30_000);
  void refreshAiStatus().catch(() => {});
  void restore();
})();
