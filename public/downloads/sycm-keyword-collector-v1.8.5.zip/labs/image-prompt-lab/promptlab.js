'use strict';

var DEFAULT_CFG = {
  provider: 'openai-compatible',
  imageAdapter: 'generic-json',
  visionBaseUrl: 'https://sub.shaozhuangai.com/v1',
  visionModel: 'chatGPT5.5',
  textModel: 'chatGPT5.5',
  imageEndpoint: 'https://sub.shaozhuangai.com/v1/images/generations',
  imageModel: 'image2',
  apiKey: ''
};
var VOLC_SEEDREAM_DEFAULT = 'doubao-seedream-5-0-260128';
var LINKMATRIX_JSON_KEY = 'sycm_linkmatrix_json';
var DETAIL_DEFAULT_SCREEN_COUNT = 10;
var PRESETS = {
  dashscope: {
    provider: 'dashscope',
    imageAdapter: 'dashscope-wan',
    visionBaseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
    visionModel: 'qwen-vl-plus',
    textModel: 'qwen-plus',
    imageEndpoint: 'https://dashscope.aliyuncs.com/api/v1/services/aigc/image-generation/generation',
    imageModel: 'wan2.7-image'
  },
  'deepseek-v4': {
    provider: 'deepseek-v4',
    imageAdapter: 'none',
    visionBaseUrl: 'https://api.deepseek.com',
    visionModel: '',
    textModel: 'deepseek-v4-flash',
    imageEndpoint: '',
    imageModel: ''
  },
  minimax: {
    provider: 'minimax',
    imageAdapter: 'minimax-image',
    visionBaseUrl: 'https://api.minimax.io/v1',
    visionModel: 'MiniMax-M2.1',
    textModel: 'MiniMax-M2.1',
    imageEndpoint: 'https://api.minimax.io/v1/image_generation',
    imageModel: 'image-01'
  },
  zhipu: {
    provider: 'zhipu',
    imageAdapter: 'zhipu-cogview',
    visionBaseUrl: 'https://open.bigmodel.cn/api/paas/v4',
    visionModel: 'glm-4v-plus',
    textModel: 'glm-4-plus',
    imageEndpoint: 'https://open.bigmodel.cn/api/paas/v4/images/generations',
    imageModel: 'cogview-4-250304'
  },
  doubao: {
    provider: 'doubao',
    imageAdapter: 'doubao-image',
    visionBaseUrl: 'https://ark.cn-beijing.volces.com/api/v3',
    visionModel: 'doubao-seed-evolving',
    textModel: 'doubao-seed-evolving',
    imageEndpoint: 'https://ark.cn-beijing.volces.com/api/v3/images/generations',
    imageModel: VOLC_SEEDREAM_DEFAULT
  },
  openai: {
    provider: 'openai',
    imageAdapter: 'openai-images',
    visionBaseUrl: 'https://api.openai.com/v1',
    visionModel: 'gpt-5-mini',
    textModel: 'gpt-5-mini',
    imageEndpoint: 'https://api.openai.com/v1/images/generations',
    imageModel: 'gpt-image-2'
  },
  'nano-banana': {
    provider: 'nano-banana',
    imageAdapter: 'nano-banana',
    visionBaseUrl: 'https://generativelanguage.googleapis.com/v1beta',
    visionModel: 'gemini-2.5-flash-image-preview',
    textModel: 'gemini-2.5-flash',
    imageEndpoint: 'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent',
    imageModel: 'gemini-2.5-flash-image-preview'
  },
  'openai-compatible': {
    provider: 'openai-compatible',
    imageAdapter: 'generic-json',
    visionBaseUrl: 'https://sub.shaozhuangai.com/v1',
    visionModel: 'chatGPT5.5',
    textModel: 'chatGPT5.5',
    imageEndpoint: 'https://sub.shaozhuangai.com/v1/images/generations',
    imageModel: 'image2'
  }
};
var sampleLink = {
  "链接编号": "L001",
  "链接分组": "差异化链接",
  "链接定位": "家庭厨房鲜味升级",
  "主推关键词": "蚝油｜鲜味｜家常炒菜｜厨房调味",
  "主标题": "鲜味蚝油厨房炒菜拌馅提鲜家用大瓶装",
  "核心场景": "家常炒菜、拌馅、烧菜",
  "风格定位": "红金高识别度、食欲感、商超爆品",
  "目标人群": "家庭厨房、做饭人群",
  "核心功能": "提鲜、增香、挂汁",
  "差异化壁垒": "突出一勺提鲜和真实菜品食欲感，不复刻竞品包装",
  "主图核心文案": "一勺爆鲜，家常菜更香"
};
var sampleDetailLink = {
  "链接编号": "L001",
  "链接定位": "儿童床边同睡更安心",
  "主推关键词": "拼接床｜儿童床｜床边加宽｜无缝拼接",
  "主标题": "儿童软艺拼接床加宽床边神器可调节同睡床",
  "产品特性": "拼接床加宽床边铁艺，儿童床大人可睡，床拼接大床床加宽拼接神器，无缝拼接，高度可调节",
  "核心卖点": "大床贴合对比，拼接大床，婴儿拼接床，床边同睡更安心",
  "差异化壁垒": "突出稳定承托、贴合大床、可调节和安全感，不夸张承诺",
  "主图核心文案": "床边同睡，更安心"
};

var $ = function (id) { return document.getElementById(id); };
var PRODUCT_ANGLES = {
  front: { preview: 'productFrontPreview', file: 'productFrontFile', url: 'productFrontUrl', label: '正视图' },
  side: { preview: 'productSidePreview', file: 'productSideFile', url: 'productSideUrl', label: '侧视图' },
  back: { preview: 'productBackPreview', file: 'productBackFile', url: 'productBackUrl', label: '背视图' }
};
var MODEL_ANGLES = {
  front: { preview: 'modelFrontPreview', file: 'modelFrontFile', url: 'modelFrontUrl', label: '模特正视图' },
  side: { preview: 'modelSidePreview', file: 'modelSideFile', url: 'modelSideUrl', label: '模特侧视图' },
  back: { preview: 'modelBackPreview', file: 'modelBackFile', url: 'modelBackUrl', label: '模特背视图' }
};
var state = {
  refImage: '',
  productImage: '',
  productImages: { front: '', side: '', back: '' },
  modelImages: { front: '', side: '', back: '' },
  results: [],
  linkList: [],
  lastLink: null,
  analysis: null,
  activeJobId: '',
  cancelledJobs: {},
  stopRequested: false,
  detailMode: 'reference',
  actionItem: null,
  guideItem: null,
  contextItem: null,
  contextAuto: false,
  skuProducts: [],
  skuTemplate: '',
  skuResults: [],
  skuActive: false
};

function currentLabMode() {
  if (document.body && document.body.classList.contains('sku-lab-mode')) return 'sku';
  return document.body && document.body.classList.contains('detail-lab-mode') ? 'detail' : 'main';
}

function setupLabMode(mode, detailMode) {
  var isDetail = mode === 'detail';
  var isSku = mode === 'sku';
  if (document.body) {
    document.body.classList.toggle('detail-lab-mode', isDetail);
    document.body.classList.toggle('sku-lab-mode', isSku);
    document.body.classList.toggle('main-lab-mode', !isDetail && !isSku);
  }
  document.title = isSku ? '少壮AI批量SKU工作台' : (isDetail ? '少壮AI详情页生成实验室' : '少壮AI主图生成实验室');
  if ($('labHeroEyebrow')) $('labHeroEyebrow').textContent = isSku ? 'BATCH SKU LAB' : (isDetail ? 'DETAIL PROMPT LAB' : 'IMAGE PROMPT LAB');
  if ($('labHeroTitle')) $('labHeroTitle').textContent = isSku ? '批量SKU工作台' : (isDetail ? '详情页生成实验室' : '主图生成实验室');
  if ($('labHeroSubtitle')) {
    $('labHeroSubtitle').textContent = isSku
      ? '产品图批量、SKU 模板复刻、属性文本匹配和批量下载。'
      : (isDetail
        ? '参考图拆解、链接规划和产品主体图，生成详情页分屏提示词。'
        : '参考图提词、链接清单主图方向、参考图/主体图生图和批量下载。');
  }
  if ($('loadSampleBtn')) $('loadSampleBtn').textContent = isSku ? '载入SKU模板' : (isDetail ? '载入详情示例' : '载入示例');
  if (isDetail) {
    setDetailMode(detailMode || 'reference');
    setPill('detailState', '详情工作台', '');
    setPill('contextState', '可上传详情参考图', '');
    setPill('linkState', '可粘贴详情链接 JSON', '');
  }
  if (isSku) setPill('skuState', 'SKU 工作台', '');
  syncGenerationModeLabels(isDetail);
}

function applySkuQueryParams(params) {
  if (!params) return;
  var resolution = params.get('skuResolution');
  var ratio = params.get('skuRatio');
  if (resolution && $('skuResolution')) $('skuResolution').value = resolution;
  if (ratio && $('skuRatio')) $('skuRatio').value = ratio;
}

function send(type, payload) {
  return new Promise(function (resolve) {
    try {
      chrome.runtime.sendMessage(Object.assign({ type: type }, payload || {}), function (resp) {
        var err = chrome.runtime.lastError;
        if (err) resolve({ ok: false, error: err.message });
        else resolve(resp || { ok: false, error: '无响应' });
      });
    } catch (e) { resolve({ ok: false, error: (e && e.message) || e }); }
  });
}

function setPill(id, text, kind) {
  var el = $(id);
  if (!el) return;
  el.textContent = text;
  el.className = 'pill' + (kind ? ' ' + kind : '');
}

function setText(id, text) {
  var el = $(id);
  if (el) el.textContent = text;
}

function scrollToPanel(id, block) {
  var el = $(id);
  if (el && el.scrollIntoView) el.scrollIntoView({ behavior: 'smooth', block: block || 'start' });
}

function generationIdleText() {
  return currentLabMode() === 'detail' ? '待生详情图' : '未生成';
}

function syncGenerationModeLabels(isDetail) {
  setText('generationTitle', isDetail ? '详情生图结果' : '生图参数');
  setText('generateBtn', isDetail ? '按详情提示词生图' : '参考图生图');
  setText('linkNumberGenerateBtn', '链接编号生图');
  setText('resultsTitle', isDetail ? '详情图结果' : '生成结果');
  setText('resultsHint', isDetail ? '结果卡片 / 下载全部 / 引导重生 / 勾选拼接长详情' : '结果素材');
  setPill('generateState', generationIdleText(), '');
  syncGenerationParamSummary();
}

function providerLabel(provider) {
  var map = {
    dashscope: '千问 / DashScope',
    'deepseek-v4': 'DeepSeek V4',
    minimax: 'MiniMax',
    zhipu: '智谱 GLM / CogView',
    doubao: '集梦 / 豆包 / 火山方舟',
    openai: 'ChatGPT / GPT Image 2',
    'nano-banana': 'Nano Banana / Gemini',
    'openai-compatible': '少壮托管 / Auto Mode'
  };
  return map[provider] || provider || '未选择';
}

function maskKey(key) {
  if (!key) return '未填写 API Key';
  if (key.length <= 8) return '已填写 API Key';
  return 'Key ' + key.slice(0, 4) + '...' + key.slice(-4);
}

function updateProviderRail(provider) {
  var rail = $('providerRail');
  if (!rail) return;
  Array.prototype.forEach.call(rail.querySelectorAll('[data-provider-pick]'), function (btn) {
    btn.classList.toggle('active', btn.getAttribute('data-provider-pick') === provider);
  });
}

function updateConfigSummary(cfg) {
  if (!cfg) cfg = cfgFromForm();
  var providerName = providerLabel(cfg.provider);
  var title = $('configProviderName');
  var sub = $('configSummaryText');
  var chips = $('configModelChips');
  if (title) title.textContent = providerName;
  if (sub) {
    sub.textContent = [
      maskKey(cfg.apiKey),
      cfg.imageAdapter === 'none' ? '仅文本提词' : '生图：' + (cfg.imageModel || '未设定'),
      '文本：' + (cfg.textModel || cfg.visionModel || '未设定')
    ].join(' · ');
  }
  if (chips) {
    chips.innerHTML = '';
    [
      ['提词', cfg.visionModel || cfg.textModel || '未设定'],
      ['文本', cfg.textModel || '未设定'],
      ['生图', cfg.imageModel || (cfg.imageAdapter === 'none' ? '不启用' : '未设定')]
    ].forEach(function (item) {
      var chip = document.createElement('span');
      chip.textContent = item[0] + '：' + item[1];
      chips.appendChild(chip);
    });
  }
  updateProviderRail(cfg.provider);
}

function cfgFromForm() {
  var provider = $('provider').value || DEFAULT_CFG.provider;
  var preset = presetForProvider(provider);
  return normalizeCfg({
    provider: provider,
    imageAdapter: $('imageAdapter').value || preset.imageAdapter,
    apiKey: $('apiKey').value.trim(),
    visionBaseUrl: $('visionBaseUrl').value.trim() || preset.visionBaseUrl || DEFAULT_CFG.visionBaseUrl,
    visionModel: $('visionModel').value.trim() || preset.visionModel || DEFAULT_CFG.visionModel,
    textModel: $('textModel').value.trim() || preset.textModel || DEFAULT_CFG.textModel,
    imageEndpoint: $('imageEndpoint').value.trim() || preset.imageEndpoint || DEFAULT_CFG.imageEndpoint,
    imageModel: $('imageModel').value.trim() || preset.imageModel || DEFAULT_CFG.imageModel
  });
}

function normalizeCfg(cfg) {
  var incoming = Object.assign({}, cfg || {});
  var provider = incoming.provider || DEFAULT_CFG.provider;
  var preset = PRESETS[provider] || {};
  cfg = Object.assign({}, DEFAULT_CFG, preset, incoming);
  if (cfg.provider === 'jimeng') cfg.provider = 'doubao';
  if (cfg.imageAdapter === 'jimeng-image') cfg.imageAdapter = 'doubao-image';
  preset = PRESETS[cfg.provider] || preset || {};
  ['imageAdapter', 'visionBaseUrl', 'visionModel', 'textModel', 'imageEndpoint', 'imageModel'].forEach(function (field) {
    if (!cfg[field] && preset[field]) cfg[field] = preset[field];
  });
  if (cfg.provider === 'openai-compatible') {
    if (!cfg.visionBaseUrl || cfg.visionBaseUrl === 'https://api.example.com/v1') cfg.visionBaseUrl = PRESETS['openai-compatible'].visionBaseUrl;
    if (!cfg.imageEndpoint || cfg.imageEndpoint === 'https://api.example.com/v1/images/generations') cfg.imageEndpoint = PRESETS['openai-compatible'].imageEndpoint;
    if (!cfg.visionModel || cfg.visionModel === 'vision-model' || cfg.visionModel === 'chat-model') cfg.visionModel = PRESETS['openai-compatible'].visionModel;
    if (!cfg.textModel || cfg.textModel === 'chat-model' || cfg.textModel === 'vision-model') cfg.textModel = PRESETS['openai-compatible'].textModel;
    if (!cfg.imageModel || cfg.imageModel === 'image-model') cfg.imageModel = PRESETS['openai-compatible'].imageModel;
  }
  var isVolc = cfg.provider === 'doubao' || /^https:\/\/ark\.cn-beijing\.volces\.com/.test(cfg.visionBaseUrl || '');
  if (isVolc) {
    if (!cfg.visionModel || /^doubao-1\.5/.test(cfg.visionModel)) cfg.visionModel = 'doubao-seed-evolving';
    if (!cfg.textModel || /^doubao-1\.5/.test(cfg.textModel)) cfg.textModel = 'doubao-seed-evolving';
    if (!cfg.imageEndpoint) cfg.imageEndpoint = PRESETS.doubao.imageEndpoint;
    if (!cfg.imageModel || /^doubao-seedream-3-0/i.test(cfg.imageModel)) cfg.imageModel = VOLC_SEEDREAM_DEFAULT;
  }
  return cfg;
}

function applyCfg(cfg) {
  cfg = normalizeCfg(cfg);
  $('provider').value = cfg.provider || 'dashscope';
  $('imageAdapter').value = cfg.imageAdapter || 'dashscope-wan';
  $('apiKey').value = cfg.apiKey || '';
  $('visionBaseUrl').value = cfg.visionBaseUrl || DEFAULT_CFG.visionBaseUrl;
  $('visionModel').value = cfg.visionModel || DEFAULT_CFG.visionModel;
  $('textModel').value = cfg.textModel || DEFAULT_CFG.textModel;
  $('imageEndpoint').value = cfg.imageEndpoint || DEFAULT_CFG.imageEndpoint;
  $('imageModel').value = cfg.imageModel || DEFAULT_CFG.imageModel;
  setPill('configState', cfg.apiKey ? '已配置' : '未配置', cfg.apiKey ? 'ok' : 'warn');
  updateConfigSummary(cfg);
  return cfg;
}

function presetForProvider(provider) {
  return normalizeCfg(Object.assign({ apiKey: '' }, PRESETS[provider] || PRESETS.dashscope));
}

function applyProviderPreset(provider) {
  return applyCfg(presetForProvider(provider));
}

var providerLoadSeq = 0;
function loadProviderProfile(provider) {
  var seq = ++providerLoadSeq;
  setPill('configState', '正在载入已保存配置...', '');
  send('GET_CONFIG_PROFILE', { provider: provider }).then(function (r) {
    if (seq !== providerLoadSeq) return;
    if (r && r.ok && r.config) {
      applyCfg(r.config);
      send('SET_ACTIVE_PROVIDER', { provider: provider });
      setPill('configState', r.saved ? '已载入账号配置' : '已载入服务商预设', r.saved ? 'ok' : '');
      return;
    }
    applyProviderPreset(provider);
    send('SET_ACTIVE_PROVIDER', { provider: provider });
    setPill('configState', '新服务商预设，保存后生效', '');
  });
}

function saveCfg() {
  var cfg = cfgFromForm();
  send('SAVE_CONFIG', { config: cfg }).then(function (r) {
    setPill('configState', r && r.ok ? '已保存到账号配置' : '保存失败', r && r.ok ? 'ok' : 'warn');
    if (r && r.ok) setTimeout(closeConfigModal, 180);
  });
}

function openConfigModal() {
  var modal = $('configModal');
  if (modal) modal.hidden = false;
  updateConfigSummary(cfgFromForm());
  if ($('provider')) $('provider').focus();
}

function closeConfigModal() {
  var modal = $('configModal');
  if (modal) modal.hidden = true;
}

function fileToDataUrl(file) {
  return new Promise(function (resolve, reject) {
    var rd = new FileReader();
    rd.onload = function () { resolve(rd.result); };
    rd.onerror = function () { reject(rd.error); };
    rd.readAsDataURL(file);
  });
}

function imageToOptimizedDataUrl(src, maxSide, quality) {
  maxSide = maxSide || 1280;
  quality = quality || 0.86;
  return new Promise(function (resolve) {
    var img = new Image();
    img.onload = function () {
      var w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
      if (!w || !h) { resolve(src); return; }
      var scale = Math.min(1, maxSide / Math.max(w, h));
      var cw = Math.max(1, Math.round(w * scale));
      var ch = Math.max(1, Math.round(h * scale));
      var canvas = document.createElement('canvas');
      canvas.width = cw; canvas.height = ch;
      var ctx = canvas.getContext('2d');
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, cw, ch);
      ctx.drawImage(img, 0, 0, cw, ch);
      resolve(canvas.toDataURL('image/jpeg', quality));
    };
    img.onerror = function () { resolve(src); };
    img.src = src;
  });
}

function fileToOptimizedDataUrl(file) {
  return fileToDataUrl(file).then(function (url) { return imageToOptimizedDataUrl(url, 1280, 0.86); });
}

function renderPreview(id, src, label) {
  var box = $(id);
  if (!box) return;
  var compact = box.classList.contains('compact-preview');
  if (!src) {
    box.className = compact ? 'preview empty compact-preview' : 'preview empty';
    box.textContent = label;
    return;
  }
  box.className = compact ? 'preview compact-preview' : 'preview';
  box.innerHTML = '';
  var img = document.createElement('img');
  img.src = src;
  img.alt = label;
  box.appendChild(img);
}

function setRefImage(src, urlText) {
  state.refImage = src || '';
  if (urlText != null) $('refUrl').value = urlText;
  renderPreview('refPreview', state.refImage, '上传、粘贴 URL / 图片，或右键网页图片导入');
  setPill('contextState', state.refImage ? '已载入参考图' : '等待图片', state.refImage ? 'ok' : '');
}

function productPlaceholder(kind) {
  if (kind === 'side') return '上传侧面厚度、结构或规格角度';
  if (kind === 'back') return '上传背面信息、开盒或反面角度';
  return '上传正面包装或主展示面';
}

function syncPrimaryProductImage() {
  state.productImage = state.productImages.front || state.productImages.side || state.productImages.back || '';
}

function setProductAngle(kind, src, urlText) {
  var meta = PRODUCT_ANGLES[kind];
  if (!meta) return;
  state.productImages[kind] = src || '';
  if (urlText != null && $(meta.url)) $(meta.url).value = urlText;
  syncPrimaryProductImage();
  renderPreview(meta.preview, state.productImages[kind], productPlaceholder(kind));
  var count = productImageList().length;
  setPill('contextState', count ? ('已载入主体图 ' + count + ' 张') : (state.refImage ? '已载入参考图' : '等待图片'), count ? 'ok' : (state.refImage ? 'ok' : ''));
}

function setProductImage(src, urlText) {
  setProductAngle('front', src, urlText);
}

function productImageList() {
  var out = [];
  ['front', 'side', 'back'].forEach(function (kind) {
    var meta = PRODUCT_ANGLES[kind];
    var img = state.productImages[kind] || (meta && $(meta.url) ? normalizeImageUrl($(meta.url).value) : '');
    if (img && out.indexOf(img) < 0) out.push(img);
  });
  return out;
}

function modelPlaceholder(kind) {
  if (kind === 'side') return '上传侧面姿势、身形比例或动作';
  if (kind === 'back') return '上传背面轮廓、发型或服饰细节';
  return '上传正面人物、姿态或穿搭';
}

function modelImageList() {
  var out = [];
  ['front', 'side', 'back'].forEach(function (kind) {
    var meta = MODEL_ANGLES[kind];
    var img = state.modelImages[kind] || (meta && $(meta.url) ? normalizeImageUrl($(meta.url).value) : '');
    if (img && out.indexOf(img) < 0) out.push(img);
  });
  return out;
}

function setModelAngle(kind, src, urlText) {
  var meta = MODEL_ANGLES[kind];
  if (!meta) return;
  state.modelImages[kind] = src || '';
  if (urlText != null && $(meta.url)) $(meta.url).value = urlText;
  renderPreview(meta.preview, state.modelImages[kind], modelPlaceholder(kind));
  var count = modelImageList().length;
  setPill('contextState', count ? ('已载入模特图 ' + count + ' 张') : (state.refImage ? '已载入参考图' : '等待图片'), count ? 'ok' : (state.refImage ? 'ok' : ''));
}

function primaryProductImage() {
  var imgs = productImageList();
  return imgs[0] || '';
}

function normalizeImageUrl(input) {
  var v = (input || '').trim();
  if (!v) return '';
  if (/^data:image\//.test(v)) return v;
  if (/^https?:\/\//.test(v)) return v;
  return '';
}

function plainObject(value) {
  return value && typeof value === 'object' && !Array.isArray(value);
}

function hasRowValue(row) {
  if (!plainObject(row)) return false;
  return Object.keys(row).some(function (k) {
    var v = row[k];
    return v != null && ('' + v).trim() !== '';
  });
}

function normalizeLinkRows(value) {
  var source = value;
  if (plainObject(source)) {
    if (Array.isArray(source.rows)) source = source.rows;
    else if (Array.isArray(source.linksJson)) source = source.linksJson;
    else if (Array.isArray(source.linkRows)) source = source.linkRows;
    else if (Array.isArray(source.data)) source = source.data;
    else if (Array.isArray(source.links)) source = source.links;
    else source = [source];
  }
  if (!Array.isArray(source)) return [];
  return source.filter(plainObject).map(function (row) { return Object.assign({}, row); }).filter(hasRowValue);
}

function splitDelimitedLine(line, delimiter) {
  if (delimiter === '\t') return line.split('\t');
  var out = [], cur = '', quote = false;
  for (var i = 0; i < line.length; i++) {
    var ch = line.charAt(i);
    if (ch === '"') {
      if (quote && line.charAt(i + 1) === '"') { cur += '"'; i++; }
      else quote = !quote;
    } else if (ch === delimiter && !quote) {
      out.push(cur); cur = '';
    } else {
      cur += ch;
    }
  }
  out.push(cur);
  return out;
}

function parseDelimitedLinks(raw) {
  var lines = (raw || '').split(/\r?\n/).filter(function (line) { return line.trim(); });
  if (lines.length < 2) return [];
  var delimiter = raw.indexOf('\t') >= 0 ? '\t' : (raw.indexOf(',') >= 0 ? ',' : '');
  if (!delimiter) return [];
  var headers = splitDelimitedLine(lines[0], delimiter).map(function (h) { return h.trim(); });
  if (!headers.length || headers.every(function (h) { return !h; })) return [];
  return lines.slice(1).map(function (line) {
    var cols = splitDelimitedLine(line, delimiter);
    var row = {};
    headers.forEach(function (h, i) {
      if (!h) return;
      row[h] = (cols[i] == null ? '' : cols[i]).trim();
    });
    return row;
  }).filter(hasRowValue);
}

function parseNdjsonLinks(raw) {
  var rows = [];
  var lines = (raw || '').split(/\r?\n/).map(function (line) { return line.trim(); }).filter(Boolean);
  if (lines.length < 2) return [];
  for (var i = 0; i < lines.length; i++) {
    if (!/^\{/.test(lines[i])) return [];
    rows.push(JSON.parse(lines[i]));
  }
  return normalizeLinkRows(rows);
}

function parseLinkListInput() {
  var raw = $('linkJson').value.trim();
  if (!raw) return [];
  try {
    var parsed = JSON.parse(raw);
    var rows = normalizeLinkRows(parsed);
    if (rows.length) return rows;
    throw new Error('JSON 中没有可用链接行');
  } catch (jsonErr) {
    try {
      var ndRows = parseNdjsonLinks(raw);
      if (ndRows.length) return ndRows;
    } catch (e) {}
    var tableRows = parseDelimitedLinks(raw);
    if (tableRows.length) return tableRows;
    throw new Error('链接清单解析失败：请粘贴单条 JSON、数组 JSON、{"rows":[...]}，或带表头的表格。原始错误：' + jsonErr.message);
  }
}

function parseLinkJson() {
  var rows = parseLinkListInput();
  var obj = rows.length ? Object.assign({}, rows[0]) : {};
  var pos = $('positioning').value.trim();
  var copy = $('imageCopy').value.trim();
  if (pos) obj['链接定位'] = pos;
  if (copy) obj['主图核心文案'] = copy;
  if (obj['链接定位'] && !obj['详情页定位']) obj['详情页定位'] = obj['链接定位'];
  if (obj['主图核心文案'] && !obj['详情页文案']) obj['详情页文案'] = obj['主图核心文案'];
  if (!Object.keys(obj).length) throw new Error('请粘贴链接清单 JSON，或至少填写链接定位');
  if (rows.length) rows[0] = Object.assign({}, rows[0], obj);
  state.linkList = rows.length ? rows : [obj];
  state.lastLink = obj;
  return obj;
}

function applyLinkToFields(value, keepRawText) {
  var rows = normalizeLinkRows(value);
  if (!rows.length) return;
  var obj = rows[0];
  state.linkList = rows;
  state.lastLink = obj;
  if (!keepRawText) $('linkJson').value = JSON.stringify(rows.length === 1 ? obj : rows, null, 2);
  $('positioning').value = obj['详情页定位'] || obj['链接定位'] || obj.positioning || '';
  $('imageCopy').value = obj['详情页文案'] || obj['主图核心文案'] || obj.imageCopy || '';
  syncBatchRangeDefaults(rows, !keepRawText);
  setPill('linkState', rows.length > 1 ? ('已载入 ' + rows.length + ' 条链接') : '已载入链接', 'ok');
}

function loadDetailSample() {
  applyLinkToFields(sampleDetailLink);
  if ($('detailProductName')) $('detailProductName').value = '儿童软艺拼接床';
  if ($('detailProductFeatures')) $('detailProductFeatures').value = sampleDetailLink['产品特性'];
  if ($('detailSellingPoints')) $('detailSellingPoints').value = sampleDetailLink['核心卖点'];
  if ($('detailPlatform')) $('detailPlatform').value = '淘宝';
  if ($('detailPageType')) $('detailPageType').value = '详情页';
  if ($('detailLanguage')) $('detailLanguage').value = '中文';
  if ($('detailScreenCount')) $('detailScreenCount').value = '' + DETAIL_DEFAULT_SCREEN_COUNT;
  if ($('detailRatio')) $('detailRatio').value = '3:4';
  if ($('detailResolution')) $('detailResolution').value = '2K';
  if ($('detailGenerateStyle')) $('detailGenerateStyle').value = '分段提示词';
  setDetailMode('link');
  setPill('detailState', '已载入详情示例', 'ok');
}

function loadSkuSample() {
  if ($('skuPrompt')) $('skuPrompt').value = skuDefaultPrompt();
  if ($('skuAttrText')) {
    $('skuAttrText').value = [
      '红色款｜礼盒装｜保留文字排版',
      '金色款｜节庆礼盒｜突出高级质感',
      '蓝色款｜日常送礼｜包装结构不变'
    ].join('\n');
  }
  setPill('skuState', '已载入 SKU 提示词模板', 'ok');
  renderSkuWorkspace();
}

function showAnalysis(data) {
  data = data || {};
  state.analysis = data;
  $('cnPrompt').value = ensurePromptSubjectRule(data['中文提示词'] || data.cnPrompt || '', 'zh');
  if ($('enPrompt')) $('enPrompt').value = ensurePromptSubjectRule(data['English Prompt'] || data.englishPrompt || data.enPrompt || '', 'en');
  $('negativePrompt').value = mergeNegativePrompts(data['负面提示词'] || data.negativePrompt || $('negativePrompt').value, replacementNegativePrompt());
  $('analysisJson').textContent = JSON.stringify(data, null, 2);
}

function mergeNegativePrompts() {
  var seen = {};
  var parts = [];
  Array.prototype.slice.call(arguments).forEach(function (text) {
    ('' + (text || '')).split(/[,，]/).forEach(function (part) {
      part = part.trim();
      if (!part) return;
      var key = part.toLowerCase();
      if (seen[key]) return;
      seen[key] = true;
      parts.push(part);
    });
  });
  return parts.join(', ');
}

function textValue(value) {
  if (value == null) return '';
  if (Array.isArray(value)) return value.map(textValue).filter(Boolean).join('，');
  if (typeof value === 'object') return JSON.stringify(value);
  return String(value).trim();
}

function firstValue(obj, keys) {
  obj = obj || {};
  for (var i = 0; i < keys.length; i++) {
    var v = textValue(obj[keys[i]]);
    if (v) return v;
  }
  return '';
}

function currentLinkForDetail() {
  try { return parseLinkJson(); } catch (e) {}
  return state.lastLink || {};
}

function detailScreenBounds(mode) {
  return mode === 'reference'
    ? { min: 5, max: 10, fallback: DETAIL_DEFAULT_SCREEN_COUNT, label: '参考图：默认10屏' }
    : { min: 5, max: 16, fallback: DETAIL_DEFAULT_SCREEN_COUNT, label: '链接详情：默认10屏' };
}

function syncDetailModeControls() {
  var mode = state.detailMode || 'reference';
  var bounds = detailScreenBounds(mode);
  var el = $('detailScreenCount');
  if (el) {
    Array.prototype.forEach.call(el.options, function (opt) {
      var n = Number(opt.value);
      opt.disabled = mode === 'reference' && n > bounds.max;
    });
    if (!el.dataset.userTouched) el.value = '' + DETAIL_DEFAULT_SCREEN_COUNT;
    var current = clampInt(el.value, bounds.min, bounds.max, bounds.fallback);
    el.value = '' + current;
  }
  syncDetailGenerationCount();
  syncGenerationParamSummary();
  if ($('detailModeHint')) {
    var items = mode === 'reference'
      ? ['默认10屏，可改5-10屏', '统一字体字号', '严格参考图风格', '主体/模特按证据引用']
      : ['默认10屏，可改5-16屏', '至少1张商品主体图', '每条链接默认1套图', '统一风格排版'];
    $('detailModeHint').innerHTML = items.map(function (item) { return '<span>' + item + '</span>'; }).join('');
  }
}

function syncDetailModeDefaultsAfterRestore() {
  [0, 120, 500].forEach(function (delay) {
    window.setTimeout(syncDetailModeControls, delay);
  });
}

function syncDetailGenerationCount(force) {
  var countEl = $('imageCount');
  var screenEl = $('detailScreenCount');
  if (!countEl || !screenEl || currentLabMode() !== 'detail') return;
  if (force) delete countEl.dataset.userTouched;
  countEl.value = '' + clampInt(screenEl.value, 5, 20, DETAIL_DEFAULT_SCREEN_COUNT);
  syncGenerationParamSummary();
}

function setDetailMode(mode) {
  state.detailMode = mode === 'link' ? 'link' : 'reference';
  if ($('detailRefModeBtn')) $('detailRefModeBtn').classList.toggle('active', state.detailMode === 'reference');
  if ($('detailLinkModeBtn')) $('detailLinkModeBtn').classList.toggle('active', state.detailMode === 'link');
  syncDetailModeControls();
}

function fillDetailFieldsFromContext() {
  var link = currentLinkForDetail();
  var analysis = state.analysis || {};
  var productName = firstValue(link, ['商品名称', '产品名称', '主标题', '标题', '详情页定位', '链接定位', '主推关键词']);
  var features = [
    firstValue(link, ['产品特性', '商品特性', '详情页定位', '核心功能', '核心场景', '规格卖点', '材质卖点', '规格', '材质', '属性']),
    firstValue(analysis, ['主体', '品类', '材质'])
  ].filter(Boolean).join('；');
  var selling = [
    firstValue(link, ['卖点', '核心卖点', '详情页文案', '差异化壁垒', '主图核心文案', '核心痛点', '主推关键词']),
    firstValue(analysis, ['可借鉴点', '风格'])
  ].filter(Boolean).join('；');
  if ($('detailProductName') && !$('detailProductName').value.trim()) $('detailProductName').value = productName;
  if ($('detailProductFeatures') && !$('detailProductFeatures').value.trim()) $('detailProductFeatures').value = features;
  if ($('detailSellingPoints') && !$('detailSellingPoints').value.trim()) $('detailSellingPoints').value = selling;
  setPill('detailState', (productName || features || selling) ? '已补齐详情信息' : '请补充产品信息', (productName || features || selling) ? 'ok' : 'warn');
}

function buildModelThreeViewPrompt() {
  fillDetailFieldsFromContext();
  var link = currentLinkForDetail();
  var productName = ($('detailProductName') && $('detailProductName').value.trim()) || firstValue(link, ['主标题', '详情页定位', '链接定位']) || '当前商品';
  var selling = ($('detailSellingPoints') && $('detailSellingPoints').value.trim()) || firstValue(link, ['详情页文案', '核心卖点', '主图核心文案']) || '突出商品核心利益点';
  var prompt = [
    '生成详情页人物模特三视图参考图：正视图、侧视图、背视图保持同一人物身份、年龄段、发型、服饰和体型一致。',
    '人物只作为“' + productName + '”详情页的场景辅助，不能遮挡商品主体，不能抢占主视觉。',
    '风格：真实电商详情页，干净自然光，动作生活化，表情自然，服装简洁，背景可抠图或浅色棚拍。',
    '使用场景：' + selling + '；人物姿态需要能服务产品卖点展示、尺寸对比、使用动作和情绪氛围。',
    '输出：三张独立参考图，分别为正面站姿/半身、侧面使用动作、背面或转身轮廓；无品牌、无文字、无水印。'
  ].join('\n');
  if ($('detailModelPrompt')) $('detailModelPrompt').value = prompt;
  setPill('contextState', '已生成模特三视图提示词', 'ok');
  setPill('detailState', '模特三视图提示词已生成', 'ok');
  return prompt;
}

function collectDetailPayload(mode) {
  mode = mode || state.detailMode || 'reference';
  var link = currentLinkForDetail();
  var screenBounds = detailScreenBounds(mode);
  return {
    mode: mode,
    link: link,
    referenceImage: state.refImage || normalizeImageUrl($('refUrl').value),
    productImages: productImageList(),
    modelImages: modelImageList(),
    modelPrompt: ($('detailModelPrompt') && $('detailModelPrompt').value.trim()) || '',
    productName: ($('detailProductName') && $('detailProductName').value.trim()) || firstValue(link, ['商品名称', '产品名称', '主标题', '标题', '详情页定位', '链接定位']),
    productFeatures: ($('detailProductFeatures') && $('detailProductFeatures').value.trim()) || firstValue(link, ['产品特性', '商品特性', '详情页定位', '核心功能', '核心场景', '规格卖点', '材质卖点', '规格', '材质', '属性']),
    sellingPoints: ($('detailSellingPoints') && $('detailSellingPoints').value.trim()) || firstValue(link, ['卖点', '核心卖点', '详情页文案', '差异化壁垒', '主图核心文案', '核心痛点', '主推关键词']),
    detailPositioning: firstValue(link, ['详情页定位', '链接定位', '核心场景', '风格定位']),
    detailCopy: firstValue(link, ['详情页文案', '主图核心文案', '差异化壁垒', '核心痛点']),
    platform: ($('detailPlatform') && $('detailPlatform').value) || '淘宝',
    pageType: ($('detailPageType') && $('detailPageType').value) || '详情页',
    language: ($('detailLanguage') && $('detailLanguage').value) || '中文',
    screenCount: clampInt($('detailScreenCount') && $('detailScreenCount').value, screenBounds.min, screenBounds.max, screenBounds.fallback),
    ratio: normalizeRatioValue(($('detailRatio') && $('detailRatio').value) || '3:4'),
    resolution: ($('detailResolution') && $('detailResolution').value) || '2K',
    generateStyle: ($('detailGenerateStyle') && $('detailGenerateStyle').value) || '分段提示词',
    imagesPerLink: generationImageCount(),
    currentMainPrompt: ($('cnPrompt') && $('cnPrompt').value.trim()) || '',
    currentEnglishPrompt: '',
    negativePrompt: ($('negativePrompt') && $('negativePrompt').value.trim()) || '',
    analysis: state.analysis || null
  };
}

function detailSectionNames(count) {
  var base = [
    '首屏场景钩子',
    '痛点爆发',
    '解决方案入场',
    '核心功能演示',
    '真实使用场景',
    '材质工艺特写',
    '结构规格证明',
    '差异化对比',
    '安装使用与QA',
    '多场景收尾',
    '安全保障',
    '人群适配',
    '细节延展',
    '组合套装',
    '服务口碑',
    '转化收尾'
  ];
  var out = base.slice(0, Math.max(5, Math.min(16, count)));
  if (out.length < count) {
    while (out.length < count) out.push('扩展卖点 ' + (out.length + 1));
  }
  return out;
}

function detailCommercialNegativePrompt() {
  return '十宫格信息图、把10屏合成一张、整页长图一次性输出、多行编号拼版、01-10大编号导航、画面左侧大序号、屏幕序号徽章、目录编号、密集参数表、图标墙、表格堆满、文字过多、左右分栏过碎、画面像PPT目录、商品被文字遮挡、商品被参考图旧主体替代、竞品品牌、商标、真实 logo、不可读文字、低清晰度、比例变形、错误产品类别、虚假材质、重复元素';
}

function detailCommercialCopyBrief(name, index, payload, detailCopy) {
  var n = index + 1;
  var map = [
    '一句话打出核心利益和场景心智，标题短而有冲击，副标题只补充1个购买理由。',
    '把用户痛点说清楚，不铺陈长段文字，用1句主标题加1-2条短说明。',
    '说明目标商品如何解决痛点，文案从“旧问题”切到“新方案”。',
    '聚焦一个核心功能或核心卖点，用短标题和少量标注解释画面。',
    '强调真实使用场景、人物尺度或环境适配，让用户想象自己正在使用。',
    '用材质、工艺、细节质感建立信任，文字只做短注释。',
    '参数和结构只保留关键尺寸/规格，避免表格堆满，像详情页证据屏。',
    '做差异化对比或竞品避坑，但不要直接复制竞品，不出现竞品品牌。',
    '讲清安装、使用、保养或QA注意事项，信息要有秩序但不拥挤。',
    '多场景适用或收尾转化，形成购买理由闭环。'
  ];
  var copy = map[Math.min(index, map.length - 1)] || '延展当前详情页卖点，保持短句、少字、强画面。';
  if (n === 1 && detailCopy) copy += ' 首屏可优先融合详情页文案：' + detailCopy;
  if (payload.sellingPoints && n <= 4) copy += ' 核心卖点参考：' + payload.sellingPoints;
  return copy;
}

function detailCommercialScreenBrief(name, index, total, payload, productText, detailPositioning, shouldUseModel) {
  var n = index + 1;
  var product = productText || '目标商品';
  var common = '只生成内部第' + n + '个单独详情画面，不生成整张长详情，不拼接其他屏。不要在画面中出现第' + n + '屏、0' + n + '、01-10、序号徽章或目录编号，顺序由下载文件名和工作台管理。画面要像成熟电商详情页单屏：一个主视觉，一个主卖点，留白清楚，标题层级统一。';
  var briefs = [
    '首屏用强商业主视觉建立心智：目标商品大面积清晰入镜，背景服务于' + (detailPositioning || '核心场景') + '，用灯光、景深和空间层次制造高级感。',
    '痛点屏先给用户问题：用真实使用环境或局部场景表现“不够安全、不够省心、不够方便”等痛点，再让目标商品作为解决前的期待对象出现。',
    '解决方案屏让' + product + '正式入场：把旧问题转成新方案，商品居中或前景清晰，画面有功能指向但不堆文字。',
    '功能演示屏只讲一个关键功能：用动作、光效、局部箭头或简洁标注说明功能发生过程，商品结构和核心部位要清晰。',
    '场景屏表现真实使用：在合适环境中展示商品被使用、摆放或携带的状态，让用户理解适用空间和使用尺度。',
    '细节屏做材质工艺特写：近景拍摄商品纹理、边角、接口、开合、手感或包装细节，背景干净，质感强。',
    '规格屏用正面、侧面、背面或结构图证明尺寸和参数：只保留关键规格，画面像商业证据页，不做密集表格。',
    '差异屏做简洁对比：左侧可弱化旧痛点或普通方案，右侧突出目标商品带来的更好体验，避免出现竞品商标。',
    'QA/步骤屏讲使用路径：用1-3步小场景或关键动作说明安装、使用、保养或注意事项，排版克制。',
    '收尾屏做多场景和转化：把核心场景串起来，商品保持主角地位，形成购买理由闭环。'
  ];
  var brief = briefs[Math.min(index, briefs.length - 1)] || ('围绕' + product + '延展第' + n + '屏卖点，保持商业单屏视觉。');
  var modelRule = shouldUseModel
    ? '本屏可自然引用模特/手部/人物侧影辅助使用动作、尺度或情绪，但商品必须更清晰、更靠前，人物不能抢主体。'
    : '本屏不主动安排完整人物，优先商品、场景、局部手部或功能特写，避免模特干扰主体识别。';
  if (n === total) brief += ' 这是整套详情页的收尾屏，需要有购买理由闭环和统一视觉收束。';
  return common + ' ' + brief + ' ' + modelRule;
}

function detailProductRequiredMessage() {
  return productSubjectRequiredMessage('detail');
}

function productSubjectRequiredMessage(mode) {
  if (mode === 'sku') return '请先上传至少 1 张 SKU 产品图，生图必须以产品图作为目标商品主体。';
  if (mode === 'detail') return '请先上传至少 1 张产品主体图，详情页生图必须以主体图作为目标商品依据。';
  return '请先上传至少 1 张产品主体图，所有生图必须以主体图作为目标商品主体。';
}

function productSubjectStateId(mode) {
  if (mode === 'sku') return 'skuState';
  if (mode === 'detail') return 'detailState';
  return 'generateState';
}

function closeProductSubjectModal() {
  var modal = $('productSubjectModal');
  if (modal) modal.hidden = true;
}

function focusProductSubjectUpload(mode) {
  mode = mode || state.productSubjectFocusMode || currentLabMode();
  var isSku = mode === 'sku';
  var target = isSku ? $('skuProductFiles') : $('productFrontFile');
  var anchor = isSku
    ? ($('skuProductPreview') || $('skuProductUrls') || target)
    : ($('productFrontPreview') || $('productFrontUrl') || target);
  closeProductSubjectModal();
  if (anchor && anchor.scrollIntoView) anchor.scrollIntoView({ behavior: 'smooth', block: 'center' });
  setTimeout(function () {
    try { if (target) target.focus(); } catch (e) {}
  }, 160);
}

function showProductSubjectRequired(mode, customMessage) {
  mode = mode || currentLabMode();
  var msg = customMessage || productSubjectRequiredMessage(mode);
  var stateId = productSubjectStateId(mode);
  setPill(stateId, msg, 'warn');
  if (stateId !== 'generateState') setPill('generateState', msg, 'warn');
  state.productSubjectFocusMode = mode;
  if ($('productSubjectText')) {
    $('productSubjectText').textContent = msg + ' 参考图、链接定位、模板图只用于风格、构图、光影和排版，不能作为最终商品主体。';
  }
  var modal = $('productSubjectModal');
  if (modal) {
    modal.hidden = false;
    setTimeout(function () { if ($('productSubjectFocusBtn')) $('productSubjectFocusBtn').focus(); }, 0);
  }
  return false;
}

function detailSectionCanUseModel(name) {
  return /首屏|痛点|入场|功能|使用|场景|适配|口碑|收尾|转化/.test(name || '');
}

function buildLocalDetailData(payload, note) {
  payload = payload || collectDetailPayload();
  var bounds = detailScreenBounds(payload.mode);
  var count = clampInt(payload.screenCount, bounds.min, bounds.max, bounds.fallback);
  var names = detailSectionNames(count);
  var productCount = payload.productImages && payload.productImages.length ? payload.productImages.length : 0;
  var modelCount = payload.modelImages && payload.modelImages.length ? payload.modelImages.length : 0;
  var hasModelGuide = !!(modelCount || payload.modelPrompt);
  var sourceText = payload.mode === 'link'
    ? '以链接清单定位为策略来源，以产品主体图为最高商品证据；正视图/侧视图/背视图用于校准结构、比例、包装信息。'
    : '以参考图/竞品图为视觉节奏来源，只借鉴构图、光线、材质和详情页叙事；产品主体图仍是最终商品身份依据，不复刻竞品品牌与包装。';
  var productText = payload.productName || firstValue(payload.link, ['主标题', '链接定位', '主推关键词']) || '当前商品';
  var positioning = firstValue(payload.link, ['链接定位', '风格定位', '核心场景']);
  var subjectRule = '硬性规则：至少 1 张商品主体图才可执行详情页生图；主体图为最高商品身份依据；参考图、竞品图、链接定位、历史结果和旧提示词里的商品主体都必须被替换为主体图中的目标商品；人物模特图为可选辅助，有则只在合适屏幕用于场景、尺度、动作和情绪，不得替代、遮挡或改写商品。';
  var productEvidence = productCount
    ? '商品主体图证据：已提供 ' + productCount + ' 张，商品外观、包装结构、颜色、比例、开盒或背面信息必须优先遵循主体图。'
    : '商品主体图证据：未提供；根据规则不得执行详情页生图。';
  var modelEvidence = modelCount
    ? '人物模特三视图证据：已提供 ' + modelCount + ' 张，仅在适合人物入镜的详情屏中辅助姿态、身形比例、使用动作和场景情绪，不能抢商品主体。'
    : '人物模特证据：未提供；仍可仅使用商品主体图生成详情页，必要时只使用环境道具或局部手部辅助，不编造固定模特身份。';
  var modelPrompt = payload.modelPrompt ? '人物模特设定：' + payload.modelPrompt : '';
  var linkBatchText = payload.mode === 'link'
    ? '链接详情生产规则：默认 ' + count + ' 屏；每条链接生成 ' + (payload.imagesPerLink || 1) + ' 套详情图；至少使用 1 张商品主体图作为商品识别依据。'
    : '';
  var styleName = '商业竖版详情页风格（单屏一卖点）';
  var detailPositioning = payload.detailPositioning || firstValue(payload.link, ['详情页定位', '链接定位', '核心场景', '风格定位']);
  var detailCopy = payload.detailCopy || firstValue(payload.link, ['详情页文案', '主图核心文案', '差异化壁垒', '核心痛点']);
  var fontStyle = '严格提取并沿用参考图字体样式；保持大标题、副标题、说明文字、参数/注释文字的字体家族、粗细、字距、行高和对齐方式一致，但每屏只保留必要文案，避免信息墙。';
  var fontSpec = {
    大标题: '按参考图大标题视觉比例统一，建议约 44-56px 或同等层级',
    副标题: '按参考图副标题视觉比例统一，建议约 28-36px 或同等层级',
    说明文字: '按参考图正文说明视觉比例统一，建议约 20-26px 或同等层级',
    注释文字: '按参考图参数/注释视觉比例统一，建议约 16-20px 或同等层级'
  };
  var styleRule = '详情生图规则：默认输出 10 屏；如果用户修改生成选项，则以用户当前选项优先，本次严格输出 ' + count + ' 屏。' +
    count + ' 屏 = ' + count + ' 张独立详情页单屏图片，绝不是一张包含多段编号的长海报；每次生图请求只生成当前屏。' +
    '商业应用目标：参考成熟电商详情页的竖向分镜逻辑，每屏一个主视觉、一个主卖点、少量短文案，形成“首屏冲击-痛点-解决方案-功能演示-真实场景-细节证明-参数/QA-收尾转化”的连续叙事。' +
    '每屏必须指定同一风格名称、同一字体样式、同一字号规范、同一排版秩序；参考图主要作为风格、字体、字号、版式、光影和节奏依据，产品主体图负责商品身份，多角度主体图负责正面/侧面/背面结构校准，模特图仅在适合屏幕自然引用。' +
    '任何与主体图冲突的链接商品、参考图商品、模板商品、旧包装和旧品牌都只保留策略或风格信息，最终画面必须替换成产品主体图商品。禁止输出十宫格、编号拼图、密集参数表或把所有屏合成一张图。';
  var sections = names.map(function (name, idx) {
    var n = idx + 1;
    var shouldUseModel = hasModelGuide && detailSectionCanUseModel(name);
    var visualBrief = detailCommercialScreenBrief(name, idx, count, payload, productText, detailPositioning, shouldUseModel);
    var copyBrief = detailCommercialCopyBrief(name, idx, payload, detailCopy);
    var modelSectionRule = hasModelGuide
      ? (shouldUseModel
        ? ' 本屏如适合人物入镜，可引用模特三视图/模特设定辅助演示使用动作、尺度关系或情绪氛围，但商品必须更清晰、更靠前。'
        : ' 本屏以商品结构、参数或细节为主，通常不引入模特，避免人物干扰商品识别。')
      : ' 无模特图时保持商品独立展示，可用场景、道具、局部手部或图示辅助。';
    return {
      屏幕: n,
      名称: name,
      承接关系: n === 1 ? '建立详情页首屏心智' : '承接上一屏卖点，推进到“' + name + '”',
      参考图风格对齐: styleName + '；沿用参考图的字体层级、字号比例、版式留白、色彩质感、构图节奏和视觉氛围。',
      字体样式: fontStyle,
      字号规范: fontSpec,
      主体图使用: productCount
        ? '必须使用商品主体图校准真实外观、包装结构、颜色、比例和关键细节；如有正视图/侧视图/背视图，本屏按画面需要选择最匹配角度。'
        : '未提供商品主体图，不应执行详情页生图。',
      模特使用: hasModelGuide
        ? (shouldUseModel ? '可引用模特三视图辅助动作、尺度和情绪，但商品主体更清晰、更靠前。' : '本屏通常不使用模特，避免人物干扰商品结构或参数识别。')
        : '未提供模特图；仅用商品主体、场景道具或局部手部辅助。',
      商业分镜: visualBrief,
      画面方向: '围绕“' + productText + '”做' + name + '。' + visualBrief + modelSectionRule,
      文案方向: copyBrief + ' 文案只做画面辅助，不把提示词、规格清单或长段说明直接塞进画面。',
      生图提示词: [
        '第' + n + '屏单独详情图，不是长图拼接，不是十宫格，不包含其他屏幕',
        '统一风格：' + styleName,
        '商业镜头：一个主视觉，一个主卖点，画面像成熟电商详情页单屏，强产品展示、强场景质感、少字留白',
        '画面分镜：' + visualBrief,
        '文案方向：' + copyBrief,
        '字体样式：' + fontStyle,
        '字号规范：大标题' + fontSpec.大标题 + '，副标题' + fontSpec.副标题 + '，说明文字' + fontSpec.说明文字 + '，注释文字' + fontSpec.注释文字,
        payload.platform + '电商' + payload.pageType,
        payload.ratio,
        payload.resolution,
        name,
        productEvidence,
        modelEvidence,
        modelPrompt,
        shouldUseModel ? '本屏允许自然引用模特辅助使用场景，但商品主体权重最高' : '本屏优先商品本体，不让人物或道具抢占主体',
        payload.productName ? '产品名称：' + payload.productName : '',
        payload.productFeatures ? '产品特性：' + payload.productFeatures : '',
        payload.sellingPoints ? '核心卖点：' + payload.sellingPoints : '',
        detailPositioning ? '详情页定位：' + detailPositioning : '',
        detailCopy ? '详情页文案：' + detailCopy : '',
        positioning ? '链接定位：' + positioning : '',
        '真实商品结构，高清细节，干净商业版式，自然光影，适合详情页分屏',
        '禁止：' + detailCommercialNegativePrompt()
      ].filter(Boolean).join('，')
    };
  });
  var prompt = [
    '【详情页生成任务】',
    '来源模式：' + (payload.mode === 'link' ? '链接规划生成提示词 + 产品主体图' : '参考图生成提示词'),
    '执行原则：' + sourceText,
    styleRule,
    subjectRule,
    '平台/类型：' + payload.platform + ' / ' + payload.pageType,
    '输出规格：默认 10 屏，当前按用户选项输出 ' + count + ' 屏，' + payload.ratio + '，' + payload.resolution + '，' + payload.language + '，' + payload.generateStyle,
    '统一视觉风格：' + styleName,
    '统一字体样式：' + fontStyle,
    '统一字号规范：大标题=' + fontSpec.大标题 + '；副标题=' + fontSpec.副标题 + '；说明文字=' + fontSpec.说明文字 + '；注释文字=' + fontSpec.注释文字,
    linkBatchText,
    productEvidence,
    modelEvidence,
    modelPrompt,
    payload.productName ? '产品名称：' + payload.productName : '',
    payload.productFeatures ? '产品特性：' + payload.productFeatures : '',
    payload.sellingPoints ? '核心卖点：' + payload.sellingPoints : '',
    detailPositioning ? '详情页定位：' + detailPositioning : '',
    detailCopy ? '详情页文案：' + detailCopy : '',
    positioning ? '链接定位：' + positioning : '',
    payload.currentMainPrompt ? '可参考主图提示词：' + payload.currentMainPrompt : '',
    '',
    '【分屏规划】',
    sections.map(function (s) {
      return s.屏幕 + '. ' + s.名称 + '\n商业分镜：' + s.商业分镜 + '\n画面：' + s.画面方向 + '\n文案：' + s.文案方向 + '\n提示词：' + s.生图提示词;
    }).join('\n\n'),
    '',
    '【负面提示词】',
    detailCommercialNegativePrompt(),
    note ? '\n【备注】' + note : ''
  ].filter(function (line) { return line !== ''; }).join('\n');
  return {
    '详情页方向': sourceText,
    '产品名称': productText,
    '详情页规格': {
      平台: payload.platform,
      页面类型: payload.pageType,
      屏数: count,
      比例: payload.ratio,
      分辨率: payload.resolution,
      语言: payload.language
    },
    '统一视觉规范': {
      风格名称: styleName,
      参考图风格提取: '从参考图提取字体样式、字号大小、版式层级、构图节奏、光线、色彩、材质和页面叙事；所有屏保持一致。',
      字体样式: fontStyle,
      字号规范: fontSpec,
      排版规范: '每一屏沿用参考图的标题层级、留白比例、图文关系和对齐方式，但按商业详情页单屏输出；10屏是10张独立图片，最终由工作台纵向合并预览，不在单张图内做十段拼版。'
    },
    '中文详情提示词': prompt,
    '负面提示词': 'ten-panel collage, all screens in one image, long infographic, dense table layout, oversized 01-10 numbers, competitor brand, trademark logo, unreadable text, cluttered layout, low resolution, distorted product, wrong product category, hidden product, over-filtered image, fake material',
    '屏幕规划': sections
  };
}

function renderDetailResult(data, fallbackNote) {
  data = data || {};
  var prompt = data['中文详情提示词'] || data.detailPrompt || data.prompt || '';
  if (!prompt) prompt = buildLocalDetailData(collectDetailPayload(), fallbackNote)['中文详情提示词'];
  if ($('detailPrompt')) $('detailPrompt').value = prompt;
  if ($('detailJson')) $('detailJson').textContent = JSON.stringify(data, null, 2);
  if ($('detailEmpty')) $('detailEmpty').classList.add('has-result');
}

function setDetailBusy(on) {
  ['detailSmartFillBtn', 'detailRefGenerateBtn', 'detailLinkGenerateBtn', 'detailModelGenerateBtn'].forEach(function (id) {
    if ($(id)) $(id).disabled = !!on;
  });
}

function generateDetailPrompt(mode) {
  setDetailMode(mode);
  fillDetailFieldsFromContext();
  var payload = collectDetailPayload(mode);
  if (!payload.productImages.length) {
    showProductSubjectRequired('detail', detailProductRequiredMessage());
    return;
  }
  if (mode === 'reference' && !payload.referenceImage) {
    setPill('detailState', '请先上传参考图', 'warn');
    return;
  }
  if (mode === 'link' && !Object.keys(payload.link || {}).length) {
    setPill('detailState', '请先粘贴链接清单 JSON', 'warn');
    return;
  }
  setDetailBusy(true);
  setPill('detailState', '详情页提词中...', '');
  send('BUILD_DETAIL_PROMPT', { config: cfgFromForm(), payload: payload }).then(function (resp) {
    setDetailBusy(false);
    if (resp && resp.ok) {
      renderDetailResult(resp.data || {});
      setPill('detailState', '详情页提示词完成', 'ok');
      syncDetailGenerationCount();
      window.setTimeout(function () { scrollToPanel('generationPanel'); }, 80);
      return;
    }
    var fallback = buildLocalDetailData(payload, (resp && resp.error) ? ('模型接口失败，已使用本地结构兜底：' + resp.error) : '模型接口失败，已使用本地结构兜底');
    renderDetailResult(fallback);
    setPill('detailState', '模型失败，已生成本地兜底', 'warn');
    syncDetailGenerationCount();
    window.setTimeout(function () { scrollToPanel('generationPanel'); }, 80);
  });
}

function analyzeCurrentImage() {
  var image = state.refImage || normalizeImageUrl($('refUrl').value);
  if (!image) { setPill('runState', '缺少参考图', 'warn'); return Promise.resolve({ ok: false, error: '缺少参考图' }); }
  var cfg = cfgFromForm();
  var linkHint = $('positioning').value.trim();
  setPill('runState', '图片提词中...', '');
  $('analyzeBtn').disabled = true;
  return send('ANALYZE_IMAGE', { config: cfg, payload: { image: image, linkHint: linkHint } }).then(function (resp) {
    $('analyzeBtn').disabled = false;
    if (resp && resp.ok) {
      showAnalysis(resp.data);
      setPill('runState', '提词完成', 'ok');
    } else {
      setPill('runState', (resp && resp.error) || '提词失败', 'warn');
    }
    return resp;
  });
}

function linkRowLabel(link, idx) {
  link = link || {};
  var id = link['链接编号'] || link.linkId || ('L' + ('00' + ((idx || 0) + 1)).slice(-3));
  var text = link['链接定位'] || link['主推关键词'] || link['主标题'] || link.keyword || '';
  text = ('' + text).replace(/\s+/g, ' ').slice(0, 18);
  return text ? (id + ' ' + text) : id;
}

function linkSequenceNumber(link, idx) {
  link = link || {};
  var raw = link['链接编号'] || link.linkId || link.link_id || '';
  if (!raw) return (idx || 0) + 1;
  var text = String(raw).trim();
  var match = text.match(/L\s*0*(\d+)/i) || text.match(/^0*(\d+)$/);
  var n = match ? parseInt(match[1], 10) : NaN;
  return isFinite(n) && n > 0 ? n : ((idx || 0) + 1);
}

function formatLinkRangeCode(num) {
  num = parseInt(num, 10);
  return 'L' + (isFinite(num) && num > 0 ? num : 1);
}

function parseLinkRangeText(value) {
  var text = (value || '').trim();
  if (!text) return {};
  var nums = [];
  text.replace(/[Ll]\s*0*(\d+)|\b0*(\d+)\b/g, function (_, a, b) {
    var n = parseInt(a || b, 10);
    if (isFinite(n) && n > 0) nums.push(n);
    return _;
  });
  return {
    start: nums.length ? nums[0] : 0,
    end: nums.length > 1 ? nums[1] : 0
  };
}

function firstLinkSequence(rows) {
  return rows && rows.length ? linkSequenceNumber(rows[0], 0) : 1;
}

function defaultBatchEndSequence(rows, start) {
  if (!rows || !rows.length) return start || 1;
  var targetIndex = Math.min(2, rows.length - 1);
  var target = linkSequenceNumber(rows[targetIndex], targetIndex);
  return Math.max(start || 1, target);
}

function isDefaultBatchRangeValue(startValue, endValue) {
  var start = parseLinkRangeText(startValue);
  var end = parseLinkRangeText(endValue);
  var startNum = start.start || 0;
  var endNum = end.end || end.start || start.end || 0;
  return (!startValue && !endValue) || (startNum === 1 && (!endNum || endNum === 3));
}

function syncBatchRangeDefaults(rows, force) {
  if (!rows || !rows.length) return;
  var startEl = $('batchLinkStart');
  var endEl = $('batchLinkEnd');
  if (!startEl || !endEl) return;
  var start = firstLinkSequence(rows);
  var end = defaultBatchEndSequence(rows, start);
  var canRefresh = force || isDefaultBatchRangeValue(startEl.value.trim(), endEl.value.trim());
  if (canRefresh || !startEl.value.trim()) startEl.value = formatLinkRangeCode(start);
  if (canRefresh || !endEl.value.trim()) endEl.value = formatLinkRangeCode(end);
}

function getBatchRange(rows) {
  rows = rows || [];
  var fallbackStart = firstLinkSequence(rows);
  var fallbackEnd = defaultBatchEndSequence(rows, fallbackStart);
  var startText = $('batchLinkStart') ? $('batchLinkStart').value : '';
  var endText = $('batchLinkEnd') ? $('batchLinkEnd').value : '';
  var startParsed = parseLinkRangeText(startText);
  var endParsed = parseLinkRangeText(endText);
  var start = startParsed.start || fallbackStart;
  var end = endParsed.end || endParsed.start || startParsed.end || fallbackEnd;
  if (start > end) {
    var tmp = start;
    start = end;
    end = tmp;
  }
  return { start: start, end: end, label: formatLinkRangeCode(start) + '-' + formatLinkRangeCode(end) };
}

function selectRowsByLinkRange(rows) {
  var range = getBatchRange(rows);
  var selected = rows.filter(function (row, idx) {
    var seq = linkSequenceNumber(row, idx);
    return seq >= range.start && seq <= range.end;
  });
  return Object.assign(range, { rows: selected });
}

function syncLinkFields(link) {
  link = link || {};
  state.lastLink = link;
  $('positioning').value = link['详情页定位'] || link['链接定位'] || link.positioning || '';
  $('imageCopy').value = link['详情页文案'] || link['主图核心文案'] || link.imageCopy || '';
}

function buildPromptForLink(link, label, options) {
  options = options || {};
  link = Object.assign({}, link || {});
  syncLinkFields(link);
  if (!Object.keys(link).length) return Promise.resolve({ ok: false, error: '链接清单 JSON 无效' });
  setPill('runState', '链接提词中' + (label ? '：' + label : '') + '...', '');
  if (!options.silent) $('buildPromptBtn').disabled = true;
  return send('BUILD_LINK_PROMPT', { config: cfgFromForm(), payload: { link: link } }).then(function (resp) {
    if (!options.silent) $('buildPromptBtn').disabled = false;
    if (resp && resp.ok) {
      var data = resp.data || {};
      showAnalysis(data);
      $('imageCopy').value = data['主图文案'] || $('imageCopy').value;
      setPill('runState', '主图提示词完成' + (label ? '：' + label : ''), 'ok');
    } else {
      setPill('runState', (resp && resp.error) || '生成失败', 'warn');
    }
    return resp;
  });
}

function buildLinkPrompt() {
  var link;
  try { link = parseLinkJson(); } catch (e) { setPill('runState', e.message, 'warn'); return Promise.resolve({ ok: false, error: e.message }); }
  return buildPromptForLink(link, '', { silent: false });
}

function promptText(value) {
  if (!value) return '';
  if (Array.isArray(value)) return value.join(', ');
  if (typeof value === 'object') return JSON.stringify(value);
  return '' + value;
}

function firstAnalysisValue(data, keys) {
  data = data || {};
  for (var i = 0; i < keys.length; i++) {
    var v = data[keys[i]];
    if (v) return promptText(v);
  }
  return '';
}

function referenceStyleNotes(data) {
  data = data || {};
  var rows = [
    ['Composition/layout', ['构图', '画面布局', '版式结构', 'layout']],
    ['Camera/view', ['镜头', 'camera']],
    ['Lighting', ['光线', 'lighting']],
    ['Color palette', ['色彩', 'color_palette', '色彩系统']],
    ['Background/mood', ['背景', 'background']],
    ['Material/texture', ['材质', 'texture']],
    ['Visual style', ['风格', 'style', 'style_tags']],
    ['Commercial direction', ['主图方向', '风格定位']]
  ].map(function (item) {
    var v = firstAnalysisValue(data, item[1]);
    return v ? item[0] + ': ' + v : '';
  }).filter(Boolean);
  return rows.join('\n');
}

function ensurePromptSubjectRule(text, lang) {
  text = (text || '').trim();
  if (!text) return '';
  if (/产品主体图|uploaded product-subject|target product subject|only hero product/i.test(text)) return text;
  if (lang === 'en') {
    return [
      'Highest priority subject replacement rule: the final product subject must be the uploaded product-subject image. The reference image, competitor image, link notes, previous result and editable prompt only provide style, composition, lighting, layout, typography hierarchy, scene and copy direction. Replace every old product/package/brand/SKU from those lower-priority sources with the uploaded target product.',
      text
    ].join('\n');
  }
  return [
    '【主体替换最高优先级】最终商品主体必须以当前上传的产品主体图为准；参考图/竞品图/链接清单/历史结果/旧提示词只提供风格、构图、光影、版式、字体层级、场景和文案方向，里面出现的旧商品、旧包装、旧品牌、旧 SKU 必须替换成产品主体图里的目标商品。',
    text
  ].join('\n');
}

function subjectReplacementPrompt(productImages) {
  productImages = Array.isArray(productImages) ? productImages : (productImages ? [productImages] : []);
  if (!productImages.length) return '';
  var angleText = productImages.length > 1
    ? 'Use the first three product-subject inputs as front view, side view and back/detail view evidence.'
    : 'Use the first product-subject input as the new product identity evidence.';
  return [
    'SUBJECT REPLACEMENT MODE:',
    angleText,
    'Target subject = the uploaded product-subject images. These product-subject images define the ONLY hero product in the final ad.',
    'This is the highest visual identity rule and it overrides reference-image subjects, link-list product wording, previous generated results, template products and editable prompt text when they conflict.',
    'Any product, package, gift box, category, SKU, brand mark, text layout, bottle, bag, food, cosmetic, appliance, model-held item, or prop identity from the reference image, link notes, previous result, or editable prompt is lower priority and must be replaced when it conflicts with the uploaded product subject.',
    'Recreate the product from the product evidence: package shape, SKU count, front-facing structure, side thickness, back/detail information, main colors, label hierarchy, visible logo/text placement and realistic proportions.',
    'The reference/competitor image is only for composition, camera angle, lighting, color mood, background depth, commercial layout, font hierarchy, typography rhythm and prop atmosphere.',
    'Replace every old product or package from the reference image and from any reference notes. Do not generate the competitor subject, competitor logo, competitor packaging, old gift contents, old bottles, old boxes, old snacks, old toiletries, old model-held item or old props as the main product.',
    'If the lower-priority prompt describes a different product subject, keep only its useful style/layout words and rewrite the visible product as the uploaded target product.',
    'Final image requirement: the new product is large, clear, commercially centered, properly lit, with natural shadow and no subject confusion.'
  ].join('\n');
}

function replacementNegativePrompt() {
  return 'old reference product, old template product, competitor product, competitor packaging, competitor brand logo, original reference subject, unchanged reference subject, wrong product category, wrong SKU, old model-held item, product hidden, product cropped, product replaced by props, mixed old and new products, distorted package, unreadable fake text';
}

function guidePriorityLayer(guide, hasProductImage) {
  if (!guide) return '';
  return [
    'HIGHEST PRIORITY SEMANTIC GUIDE LAYER:',
    'User guide: ' + guide,
    'Conflict rule: if this guide conflicts with the reference image, editable prompt notes, link prompt, previous generated result, product props, or any lower-priority description, this guide wins semantically.',
    'Implementation rule: do not render the guide as visible text. Translate it into natural visual decisions: subject selection, prop replacement, container choice, crop, occlusion, spatial layout, camera angle, material choice, and background simplification.',
    'Integration rule: keep the image commercially believable and visually integrated. Do not force an awkward literal object unless it naturally belongs in the product scene.',
    hasProductImage ? 'Product authority: the uploaded product subject image still has the highest visual identity authority for the final product; the guide controls what must be changed around it and which conflicting reference elements must disappear or be softened.' : '',
    'If the guide says an element should be replaced or removed, remove the conflicting old element from the scene and replace it with a visually compatible e-commerce display solution.'
  ].filter(Boolean).join('\n');
}

function activeGenerationBasePrompt() {
  if (currentLabMode() === 'detail') {
    return (($('detailPrompt') && $('detailPrompt').value.trim()) || ($('cnPrompt') && $('cnPrompt').value.trim()) || '');
  }
  return (($('cnPrompt') && $('cnPrompt').value.trim()) || '');
}

function detailVariantPrefix(variant) {
  var map = {
    single: 'Generate one polished standalone e-commerce detail-page screen based on the detail-page prompt. ',
    guide: 'Regenerate the selected standalone detail-page screen with the guide as the highest semantic priority. ',
    main: 'Product opening detail screen, clear hero identity and conversion headline, without visible screen number. ',
    scene: 'Detail screen for usage scenario, pain-point context and realistic product fit. ',
    hook: 'Detail screen for key benefit proof, memorable visual hook and simple evidence layout. ',
    diff: 'Detail screen for differentiated advantage, competitor-avoidance and trust-building proof. '
  };
  return map[variant] || map.single;
}

function detailScreenSequenceLayer(index, total) {
  if (currentLabMode() !== 'detail' || total <= 1) return '';
  var sections = detailSectionNames(total);
  var sectionName = sections[index - 1] || ('详情页第' + index + '屏');
  return [
    'HIGHEST PRIORITY DETAIL SCREEN SEQUENCE LAYER:',
    'Generate ONLY screen ' + index + ' of ' + total + ': ' + sectionName + '.',
    'This sequence text is internal planning only. Do NOT render visible 01/02/03 numbers, screen labels, ranking badges, page indexes or directory numbers inside the image.',
    'Do not render the full long detail page in one image. Do not merge multiple screens into one image. The workstation will stitch images later only when the user checks the long-preview option.',
    'Make this a complete standalone commercial detail screen with one primary selling point or usage story, not a sliced strip, not a collage, not an index page.',
    'This screen must continue the same visual system as the other screens: same font family style, headline size, subtitle size, body-copy size, margin rhythm, color palette, lighting, product identity and page layout grammar.',
    'Use the uploaded product subject image(s) as the final product identity for this screen. Reference images and previous generated images only provide style, composition and typography rhythm.'
  ].join('\n');
}

function detailGenerationPrompt(variant, base, guide, productImages) {
  var modelImages = modelImageList();
  return [
    guidePriorityLayer(guide, true),
    'DETAIL PAGE IMAGE GENERATION MODE:',
    detailVariantPrefix(variant),
    'Use the detail-page prompt as the source of screen planning, visual hierarchy, product selling points and copy direction.',
    subjectReplacementPrompt(productImages),
    modelImages.length ? 'Optional model references are available: use them only when the selected detail screen naturally needs a person for scale, usage, emotion, fit, or trust. The model must not replace, hide, or rewrite the product subject.' : '',
    state.refImage ? 'Reference image is only for non-subject visual rhythm: composition, lighting, page storytelling, background, typography hierarchy, font-size rhythm and commercial mood.' : '',
    'Do not place visible screen numbers, 01-10 index labels, page badges or ordering marks in the generated detail image. File download order is handled by the plugin, not by the image design.',
    'Detail prompt:\n' + base,
    'Negative prompt additions: ' + detailCommercialNegativePrompt(),
    'Avoid copying competitor brands, visible trademarks, old packaging text, old products, fake unreadable tiny text, over-crowded layouts, or hiding the product.'
  ].filter(Boolean).join('\n');
}

function validateGenerationReady() {
  var mode = currentLabMode();
  if (!productImageList().length) return showProductSubjectRequired(mode);
  if (mode === 'detail' && !activeGenerationBasePrompt()) {
    setPill('detailState', '请先生成详情页提示词', 'warn');
    setPill('generateState', '请先生成详情页提示词', 'warn');
    return false;
  }
  if (mode !== 'detail' && !activeGenerationBasePrompt()) {
    setPill('generateState', '请先生成或填写提示词', 'warn');
    return false;
  }
  return true;
}

function normalizeRatioValue(value) {
  var text = String(value || '').trim();
  var match = text.match(/(\d+)\s*:\s*(\d+)/);
  return match ? (match[1] + ':' + match[2]) : text;
}

function detailScreenCountForGeneration() {
  var screenEl = $('detailScreenCount');
  var mode = state.detailMode || 'reference';
  var bounds = detailScreenBounds(mode);
  return clampInt(screenEl && screenEl.value, bounds.min, bounds.max, bounds.fallback);
}

function syncGenerationParamSummary() {
  var el = $('generationParamSummary');
  if (!el) return;
  if (currentLabMode() !== 'detail') return;
  var count = detailScreenCountForGeneration();
  el.textContent = '详情生图沿用上方参数：' + count + ' 屏 = ' + count + ' 张独立图片；比例 ' + generationRatio() + '，清晰度 ' + generationResolution() + '；生成后可手动勾选拼接成长详情预览。';
}

function generationRatio() {
  if (currentLabMode() === 'detail') {
    return normalizeRatioValue(($('detailRatio') && $('detailRatio').value) || '3:4') || '3:4';
  }
  return (($('imageRatio') && $('imageRatio').value) || '1:1').trim();
}

function generationResolution() {
  if (currentLabMode() === 'detail') {
    return (($('detailResolution') && $('detailResolution').value) || '2K').toUpperCase();
  }
  return (($('imageResolution') && $('imageResolution').value) || '1K').toUpperCase();
}

function generationImageCount(value) {
  if (!value && currentLabMode() === 'detail') {
    return detailScreenCountForGeneration();
  }
  return clampInt(value || ($('imageCount') && $('imageCount').value), 1, 20, 1);
}

function generationResolutionScale(resolution) {
  resolution = (resolution || '1K').toUpperCase();
  if (resolution === '4K') return 4;
  if (resolution === '2K') return 2;
  return 1;
}

function generationSizeFromSettings() {
  var base = {
    '1:1': [1024, 1024],
    '3:4': [768, 1024],
    '16:9': [1792, 1024],
    '9:16': [1024, 1792],
    '21:9': [2048, 878]
  }[generationRatio()] || [1024, 1024];
  var scale = generationResolutionScale(generationResolution());
  return Math.round(base[0] * scale) + '*' + Math.round(base[1] * scale);
}

function generationParamPromptLayer(count) {
  count = generationImageCount(count);
  return [
    'HIGHEST PRIORITY GENERATION PARAMETER LAYER:',
    'Image ratio must be exactly ' + generationRatio() + '.',
    'Target resolution and clarity level must be exactly ' + generationResolution() + '.',
    'Workflow target count is ' + count + ' image(s). If this workflow is split into screen-by-screen requests, each request generates only its assigned screen while preserving the total workflow count.',
    'These three user-selected generation parameters override any older size, clarity, resolution, watermark, batch direction, quantity, or aspect-ratio instructions in reference prompts, link JSON, detail prompts, SKU prompts, previous generated prompts, or model analysis.',
    'Do not add watermark. Do not follow old batch-direction logic. Keep only the selected image ratio, selected clarity/resolution level, and selected image count.'
  ].join('\n');
}

function requestCountChunks(total) {
  var chunks = [];
  var left = generationImageCount(total);
  while (left > 0) {
    chunks.push(Math.min(4, left));
    left -= 4;
  }
  return chunks;
}

function generationPrompt(variant) {
  var base = activeGenerationBasePrompt();
  var guide = (variant === 'guide' && $('guidePrompt')) ? $('guidePrompt').value.trim() : '';
  var pos = $('positioning').value.trim();
  var copy = $('imageCopy').value.trim();
  var link = state.lastLink || {};
  var productImages = productImageList();
  var productImage = productImages[0] || '';
  var styleNotes = referenceStyleNotes(state.analysis);
  var prefix = '';
  if (currentLabMode() === 'detail') return detailGenerationPrompt(variant, base, guide, productImages);
  if (variant === 'main') prefix = 'E-commerce hero main image, strong conversion focus. ';
  if (variant === 'scene') prefix = 'Lifestyle scenario image for e-commerce, natural product usage scene. ';
  if (variant === 'hook') prefix = 'Visual hook image, memorable key visual, clear product benefit. ';
  if (variant === 'diff') prefix = 'Differentiated competitor-avoidance e-commerce image, original layout. ';
  if (!productImage) return '';
  return [
    guidePriorityLayer(guide, true),
    prefix + 'Create a new e-commerce ad image with product subject replacement.',
    subjectReplacementPrompt(productImages),
    styleNotes ? 'Reference style/layout notes to borrow, excluding its product/category:\n' + styleNotes : 'Use the reference image only for non-subject style: composition, camera, lighting, color mood, background and commercial layout.',
    pos ? 'Link positioning: ' + pos : '',
    copy ? 'Main visual copy direction: ' + copy : '',
    link['主推关键词'] ? 'New product keywords/context: ' + link['主推关键词'] : '',
    link['主标题'] ? 'New product title direction: ' + link['主标题'] : '',
    link['核心场景'] ? 'Core scene: ' + link['核心场景'] : '',
    link['目标人群'] ? 'Target audience: ' + link['目标人群'] : '',
    link['风格定位'] ? 'Style: ' + link['风格定位'] : '',
    'Do not use the reference image subject as the product. Keep only its visual grammar.',
    base ? 'LOWER PRIORITY editable prompt notes. Use only the parts that do not conflict with the highest priority guide or product subject:\n' + base : '',
    'Avoid using real brand logos, trademarked packaging layouts, unreadable text, or copying competitor design.'
  ].filter(Boolean).join('\n');
}

function detailPreviewResults() {
  if (currentLabMode() !== 'detail') return [];
  return state.results.filter(function (item) {
    return item && item.url && item.labMode === 'detail';
  }).slice().sort(function (a, b) {
    return (a.detailScreenIndex || 0) - (b.detailScreenIndex || 0);
  });
}

function detailScreenHoverPrompt(index, total, item) {
  var prompt = item && item.prompt ? item.prompt : (($('detailPrompt') && $('detailPrompt').value.trim()) || '');
  var layer = detailScreenSequenceLayer(index, total);
  return [layer, prompt].filter(Boolean).join('\n\n').trim() || ('第 ' + index + ' 屏提示词将在生成后显示');
}

function compactDetailTitle(text, fallback) {
  text = textValue(text)
    .replace(/HIGHEST PRIORITY DETAIL SCREEN SEQUENCE LAYER[\s\S]*?Use the uploaded product subject image\(s\).*?\n?/g, '')
    .replace(/第\s*\d+\s*屏单独详情图/g, '')
    .replace(/不是长图拼接|不是十宫格|不包含其他屏幕/g, '')
    .replace(/^(商业分镜|画面方向|画面|文案方向|文案|提示词|生图提示词|名称|标题)\s*[:：]/, '')
    .replace(/围绕“[^”]+”做/g, '')
    .replace(/详情页|详情图|商业|成熟电商|单屏|画面|镜头/g, '')
    .replace(/[【】"'“”]/g, '')
    .trim();
  var first = text.split(/[。；;，,\n]/).map(function (part) { return part.trim(); }).filter(Boolean)[0] || '';
  first = first
    .replace(/^(一个|一张|通过|展示|突出|强调|建立|承接|推进到|聚焦|围绕)/, '')
    .replace(/\s+/g, '')
    .trim();
  if (!first) first = fallback || '详情纲要';
  return first.length > 10 ? first.slice(0, 10) : first;
}

function detailJsonScreenPlan() {
  var raw = $('detailJson') && $('detailJson').textContent;
  if (!raw || !raw.trim()) return [];
  try {
    var data = JSON.parse(raw);
    return Array.isArray(data['屏幕规划']) ? data['屏幕规划'] : [];
  } catch (e) {
    return [];
  }
}

function detailPromptSectionText(index) {
  var prompt = ($('detailPrompt') && $('detailPrompt').value.trim()) || '';
  if (!prompt) return '';
  var escaped = String(index).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  var next = String(index + 1).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  var re = new RegExp('(?:^|\\n)\\s*(?:' + escaped + '|0?' + escaped + '|第\\s*' + escaped + '\\s*屏|Screen\\s*' + escaped + ')[\\.、:：\\s][\\s\\S]*?(?=\\n\\s*(?:' + next + '|0?' + next + '|第\\s*' + next + '\\s*屏|Screen\\s*' + next + ')[\\.、:：\\s]|\\n【负面提示词】|$)', 'i');
  var m = prompt.match(re);
  return m ? m[0] : '';
}

function detailSlotTitle(index, total, item) {
  var fallback = detailSectionNames(total)[index - 1] || '详情纲要';
  var plan = detailJsonScreenPlan();
  var section = plan[index - 1] || {};
  var source = item && item.prompt
    ? item.prompt
    : (section['商业分镜'] || section['画面方向'] || section['文案方向'] || section['生图提示词'] || detailPromptSectionText(index) || section['名称'] || fallback);
  return padDownloadSeq(index) + ' ' + compactDetailTitle(source, fallback);
}

function createDetailResultSlot(index, total, item) {
  var card = document.createElement('div');
  card.className = 'result-card detail-result-card' + (item && item.url ? ' has-image' : ' is-placeholder');
  card.title = detailScreenHoverPrompt(index, total, item);

  var preview = document.createElement('div');
  preview.className = 'detail-screen-preview';
  if (item && item.url) {
    var img = document.createElement('img');
    img.src = item.url;
    img.alt = item.variantName || ('详情页第 ' + index + ' 屏');
    preview.appendChild(img);
  } else {
    var slot = document.createElement('div');
    slot.className = 'detail-screen-placeholder';
    slot.innerHTML = '<strong>' + padDownloadSeq(index) + '</strong><span>待生成</span>';
    preview.appendChild(slot);
  }

  var meta = document.createElement('div');
  meta.className = 'result-meta';
  var strong = document.createElement('strong');
  strong.textContent = detailSlotTitle(index, total, item);
  var urlLine = document.createElement('div');
  urlLine.className = 'result-url';
  urlLine.textContent = item && item.url ? '悬停查看该屏提示词' : '生成后在此预览图片';
  meta.appendChild(strong);
  meta.appendChild(urlLine);

  if (item && item.url) {
    var row = document.createElement('div');
    row.className = 'result-actions';
    var copyImg = document.createElement('button');
    copyImg.className = 'btn ghost';
    copyImg.type = 'button';
    copyImg.textContent = '复制图片';
    copyImg.addEventListener('click', function () { openImageActionModal(item); });
    var guideBtn = document.createElement('button');
    guideBtn.className = 'btn ghost';
    guideBtn.type = 'button';
    guideBtn.textContent = '引导重生';
    guideBtn.addEventListener('click', function () { openGuideRegenerateModal(item); });
    var dl = document.createElement('button');
    dl.className = 'btn ghost';
    dl.type = 'button';
    dl.textContent = '下载';
    dl.addEventListener('click', function () {
      send('DOWNLOAD_ALL', { items: buildDownloadItems([item], currentLabMode()) });
    });
    row.appendChild(copyImg);
    row.appendChild(guideBtn);
    row.appendChild(dl);
    meta.appendChild(row);
  }

  card.appendChild(preview);
  card.appendChild(meta);
  return card;
}

function padDownloadSeq(num) {
  num = Number(num) || 0;
  return (num < 10 ? '0' : '') + num;
}

function sanitizeDownloadNamePart(text) {
  return String(text || '')
    .replace(/[\\/:*?"<>|#\u0000-\u001f]/g, '')
    .replace(/\s+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 48) || '生成图';
}

function downloadBaseDir(mode) {
  if (mode === 'detail') return '少壮AI详情页';
  if (mode === 'sku') return '少壮AI批量SKU';
  return '少壮AI主图生成实验室';
}

function buildDownloadItems(items, mode) {
  var labMode = mode || currentLabMode();
  var prefix = labMode === 'detail' ? 'detail' : (labMode === 'sku' ? 'sku' : 'image');
  var dir = downloadBaseDir(labMode);
  return (items || []).filter(function (item) {
    return item && item.url;
  }).map(function (item, idx) {
    var seq = item.detailScreenIndex || item.sourceIndex + 1 || idx + 1;
    var name = sanitizeDownloadNamePart(item.variantName || item.variant || '生成图');
    return {
      url: item.url,
      filename: dir + '/' + prefix + '_' + padDownloadSeq(seq) + '_' + name + '.png'
    };
  });
}

function renderDetailLongPreview() {
  var wrap = $('detailLongPreviewWrap');
  var strip = $('detailLongPreview');
  if (!wrap || !strip) return;
  var items = detailPreviewResults();
  var toggle = $('detailStitchToggle');
  var shouldStitch = !!(toggle && toggle.checked);
  wrap.hidden = currentLabMode() !== 'detail' || !items.length || !shouldStitch;
  strip.innerHTML = '';
  if (!items.length) {
    setText('detailLongPreviewHint', '生成后可勾选拼接成长详情预览');
    return;
  }
  if (!shouldStitch) {
    setText('detailLongPreviewHint', '勾选后按生成顺序合并预览');
    return;
  }
  items.forEach(function (item) {
    var img = document.createElement('img');
    img.src = item.url;
    img.alt = item.variantName || '详情页画面';
    strip.appendChild(img);
  });
  setText('detailLongPreviewHint', '已合并 ' + items.length + ' 屏，可逐张下载或下载全部');
}

function stitchDetailLongImage() {
  if (currentLabMode() !== 'detail') return;
  var items = detailPreviewResults();
  if (!items.length) {
    if ($('detailStitchToggle')) $('detailStitchToggle').checked = false;
    renderDetailLongPreview();
    setPill('generateState', '未找到拼接对象', 'warn');
    return;
  }
  if ($('detailStitchToggle')) $('detailStitchToggle').checked = true;
  renderDetailLongPreview();
  setPill('generateState', '已打开长图预览', 'ok');
  var target = $('detailLongPreviewWrap') || $('resultGrid');
  if (target && target.scrollIntoView) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function renderResults() {
  var grid = $('resultGrid');
  grid.innerHTML = '';
  var isDetail = currentLabMode() === 'detail';
  var items = isDetail ? detailPreviewResults() : state.results;
  if (isDetail) {
    var total = detailScreenCountForGeneration();
    var byIndex = {};
    items.forEach(function (item, idx) {
      byIndex[item.detailScreenIndex || (idx + 1)] = item;
    });
    for (var i = 1; i <= total; i++) {
      grid.appendChild(createDetailResultSlot(i, total, byIndex[i]));
    }
    renderDetailLongPreview();
    return;
  }
  if (!items.length) {
    var empty = document.createElement('div');
    empty.className = 'empty-result';
    empty.textContent = '还没有生成结果';
    grid.appendChild(empty);
    renderDetailLongPreview();
    return;
  }
  items.forEach(function (item, idx) {
    var card = document.createElement('div');
    card.className = 'result-card';
    var img = document.createElement('img');
    img.src = item.url;
    img.alt = item.variant || 'generated image';
    var meta = document.createElement('div');
    meta.className = 'result-meta';
    var strong = document.createElement('strong');
    strong.textContent = currentLabMode() === 'detail'
      ? (item.variantName || item.variant || '详情图')
      : ((idx + 1) + '. ' + (item.variantName || item.variant || '生成图'));
    var urlLine = document.createElement('div');
    urlLine.className = 'result-url';
    urlLine.title = item.url;
    urlLine.textContent = item.url ? '图片链接已生成' : '无图片链接';
    var row = document.createElement('div');
    row.className = 'result-actions';
    var copyImg = document.createElement('button');
    copyImg.className = 'btn ghost';
    copyImg.type = 'button';
    copyImg.textContent = '复制图片';
    copyImg.addEventListener('click', function () { openImageActionModal(item); });
    var guideBtn = document.createElement('button');
    guideBtn.className = 'btn ghost';
    guideBtn.type = 'button';
    guideBtn.textContent = '引导重生';
    guideBtn.addEventListener('click', function () { openGuideRegenerateModal(item); });
    var dl = document.createElement('button');
    dl.className = 'btn ghost';
    dl.type = 'button';
    dl.textContent = '下载';
    dl.addEventListener('click', function () {
      send('DOWNLOAD_ALL', { items: buildDownloadItems([item], currentLabMode()) });
    });
    row.appendChild(copyImg);
    row.appendChild(guideBtn);
    row.appendChild(dl);
    meta.appendChild(strong);
    meta.appendChild(urlLine);
    meta.appendChild(row);
    card.appendChild(img);
    card.appendChild(meta);
    grid.appendChild(card);
  });
  renderDetailLongPreview();
}

function resultGuidePrompt(item) {
  item = item || {};
  return [
    '【最高权重引导词，可编辑】',
    '这张结果图只作为视觉参考，不作为商品主体锁定。参考图：' + (item.url || ''),
    '优先保留：构图关系、镜头角度、光影方向、色彩氛围、背景层次、商业版式、产品摆位、画面质感。',
    '语义覆盖：如果原提示词、参考图或结果图里仍包含旧商品、旧包装、旧容器、旧配件、旧品牌、旧文案，以这里填写的引导为准，冲突内容自动降权。',
    '融合落地：把引导要求转化为自然画面调整，例如替换容器、改变陈列方式、弱化/移除冲突道具、调整遮挡关系、改变摆放空间、重排局部构图；不要把引导词当成画面文字。',
    '主体规则：最终商品主体以当前上传的产品主体图为准，结果图/参考图只能提供风格和版式。',
    item.variantName ? '结果方向：' + item.variantName : '',
    item.prompt ? '低权重历史提示词，仅作风格记忆，不得覆盖以上引导：\n' + item.prompt : ''
  ].filter(Boolean).join('\n\n');
}

function blobToPngBlob(blob) {
  if (blob && blob.type === 'image/png') return Promise.resolve(blob);
  if (!blob || !window.createImageBitmap) return Promise.reject(new Error('浏览器不支持图片转码'));
  return createImageBitmap(blob).then(function (bitmap) {
    var canvas = document.createElement('canvas');
    canvas.width = bitmap.width;
    canvas.height = bitmap.height;
    var ctx = canvas.getContext('2d');
    ctx.drawImage(bitmap, 0, 0);
    if (bitmap.close) bitmap.close();
    return new Promise(function (resolve, reject) {
      canvas.toBlob(function (pngBlob) {
        if (pngBlob) resolve(pngBlob);
        else reject(new Error('图片转码失败'));
      }, 'image/png');
    });
  });
}

function openImageActionModal(item) {
  state.actionItem = item || null;
  var modal = $('imageActionModal');
  if (!modal) {
    copyImageToClipboard(item && item.url);
    return;
  }
  modal.hidden = false;
  var first = $('copyOriginalImageBtn');
  if (first) first.focus();
}

function closeImageActionModal() {
  state.actionItem = null;
  var modal = $('imageActionModal');
  if (modal) modal.hidden = true;
}

function applyContextImage(ctx, autoAnalyze) {
  ctx = ctx || {};
  if (!ctx.imageUrl) return Promise.resolve({ ok: false, error: '缺少右键图片' });
  setPill('contextState', '右键图片导入中...', '');
  $('refUrl').value = ctx.imageUrl;
  setRefImage(ctx.imageUrl, ctx.imageUrl);
  if (autoAnalyze && ($('apiKey') && $('apiKey').value.trim())) return analyzeCurrentImage();
  return Promise.resolve({ ok: true });
}

function openContextActionModal(ctx, autoAnalyze) {
  state.contextItem = ctx || null;
  state.contextAuto = !!autoAnalyze;
  var modal = $('contextActionModal');
  if (!modal) {
    applyContextImage(ctx, autoAnalyze);
    return;
  }
  modal.hidden = false;
  var first = $('contextImportBtn');
  if (first) first.focus();
}

function closeContextActionModal() {
  state.contextItem = null;
  var modal = $('contextActionModal');
  if (modal) modal.hidden = true;
}

function syncShareCardControls(source) {
  source = source || {};
  var values = {
    position: source.position,
    border: source.border,
    ratio: source.ratio
  };
  if (source.target && source.target.getAttribute) {
    values[source.target.getAttribute('data-share-card')] = source.target.value;
  }
  ['position', 'border', 'ratio'].forEach(function (key) {
    var controls = document.querySelectorAll('[data-share-card="' + key + '"]');
    var val = values[key];
    if (val == null && controls[0]) val = controls[0].value;
    controls.forEach(function (ctrl) {
      if (val != null) ctrl.value = val;
    });
  });
}

function shareCardValue(key, fallback) {
  var el = document.querySelector('[data-share-card="' + key + '"]');
  return (el && el.value) || fallback;
}

function shareCardConfig() {
  return {
    position: shareCardValue('position', 'top'),
    border: Math.max(0, Math.min(80, parseInt(shareCardValue('border', '36'), 10) || 36)),
    ratio: shareCardValue('ratio', '4:5')
  };
}

function shareCardSize(ratio) {
  if (ratio === '1:1') return { w: 1080, h: 1080 };
  if (ratio === '3:4') return { w: 1080, h: 1440 };
  return { w: 1080, h: 1350 };
}

function loadCanvasImage(url) {
  return fetch(url).then(function (r) {
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.blob();
  }).then(function (blob) {
    return new Promise(function (resolve, reject) {
      var objectUrl = URL.createObjectURL(blob);
      var img = new Image();
      img.onload = function () {
        URL.revokeObjectURL(objectUrl);
        resolve(img);
      };
      img.onerror = function () {
        URL.revokeObjectURL(objectUrl);
        reject(new Error('图片载入失败'));
      };
      img.src = objectUrl;
    });
  });
}

function roundRect(ctx, x, y, w, h, r) {
  r = Math.min(r || 0, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function drawImageFit(ctx, img, rect, mode) {
  var iw = img.naturalWidth || img.width;
  var ih = img.naturalHeight || img.height;
  var scale = mode === 'cover' ? Math.max(rect.w / iw, rect.h / ih) : Math.min(rect.w / iw, rect.h / ih);
  var sw = rect.w / scale;
  var sh = rect.h / scale;
  var sx = (iw - sw) / 2;
  var sy = (ih - sh) / 2;
  ctx.drawImage(img, sx, sy, sw, sh, rect.x, rect.y, rect.w, rect.h);
}

function wrapText(ctx, text, x, y, maxWidth, lineHeight, maxLines) {
  text = (text || '').replace(/\s+/g, ' ').trim();
  var line = '';
  var lines = 0;
  for (var i = 0; i < text.length; i++) {
    var test = line + text[i];
    if (ctx.measureText(test).width > maxWidth && line) {
      ctx.fillText(line, x, y);
      y += lineHeight;
      lines++;
      line = text[i];
      if (maxLines && lines >= maxLines - 1) break;
    } else {
      line = test;
    }
  }
  if (line && (!maxLines || lines < maxLines)) ctx.fillText(line, x, y);
}

function shareCardText(item) {
  var cn = ($('cnPrompt') && $('cnPrompt').value.trim()) || '';
  var prompt = cn || item.prompt || '高质感电商主图，主体清晰，背景克制，细节丰富。';
  return {
    title: item.variantName || item.variant || '提示词',
    prompt: prompt,
    negative: ($('negativePrompt') && $('negativePrompt').value.trim()) || ''
  };
}

function drawShareCopy(ctx, box, text, compact) {
  roundRect(ctx, box.x, box.y, box.w, box.h, 24);
  ctx.fillStyle = 'rgba(8, 15, 4, .92)';
  ctx.fill();
  ctx.fillStyle = '#f6c65f';
  ctx.font = compact ? '700 34px "PingFang SC", sans-serif' : '700 44px "PingFang SC", sans-serif';
  ctx.fillText(text.title || '提示词', box.x + 34, box.y + 52);
  ctx.fillStyle = '#f3edd7';
  ctx.font = compact ? '28px "PingFang SC", sans-serif' : '32px "PingFang SC", sans-serif';
  wrapText(ctx, text.prompt, box.x + 34, box.y + (compact ? 96 : 112), box.w - 68, compact ? 42 : 48, compact ? 7 : 9);
}

function buildShareCardBlob(item) {
  item = item || {};
  if (!item.url) return Promise.reject(new Error('没有图片可生成卡片'));
  var cfg = shareCardConfig();
  var size = shareCardSize(cfg.ratio);
  return loadCanvasImage(item.url).then(function (img) {
    var canvas = document.createElement('canvas');
    canvas.width = size.w;
    canvas.height = size.h;
    var ctx = canvas.getContext('2d');
    ctx.fillStyle = '#f5f1e7';
    ctx.fillRect(0, 0, size.w, size.h);
    var b = cfg.border;
    var inner = { x: b, y: b, w: size.w - b * 2, h: size.h - b * 2 };
    var text = shareCardText(item);
    if (cfg.position === 'left') {
      var mediaW = Math.round(inner.w * .56);
      roundRect(ctx, inner.x, inner.y, mediaW, inner.h, 28);
      ctx.save();
      ctx.clip();
      drawImageFit(ctx, img, { x: inner.x, y: inner.y, w: mediaW, h: inner.h }, 'cover');
      ctx.restore();
      drawShareCopy(ctx, { x: inner.x + mediaW + 20, y: inner.y, w: inner.w - mediaW - 20, h: inner.h }, text, true);
    } else if (cfg.position === 'full') {
      drawImageFit(ctx, img, { x: 0, y: 0, w: size.w, h: size.h }, 'cover');
      drawShareCopy(ctx, { x: b, y: size.h - Math.max(360, size.h * .32) - b, w: size.w - b * 2, h: Math.max(360, size.h * .32) }, text, true);
    } else {
      var mediaH = cfg.position === 'center' ? Math.round(inner.h * .68) : Math.round(inner.h * .58);
      roundRect(ctx, inner.x, inner.y, inner.w, mediaH, 28);
      ctx.save();
      ctx.clip();
      drawImageFit(ctx, img, { x: inner.x, y: inner.y, w: inner.w, h: mediaH }, cfg.position === 'center' ? 'contain' : 'cover');
      ctx.restore();
      var copyY = inner.y + mediaH + 20;
      drawShareCopy(ctx, { x: inner.x, y: copyY, w: inner.w, h: inner.y + inner.h - copyY }, text, false);
    }
    return new Promise(function (resolve, reject) {
      canvas.toBlob(function (blob) {
        if (blob) resolve(blob);
        else reject(new Error('卡片导出失败'));
      }, 'image/png');
    });
  });
}

function copyShareCardToClipboard(item) {
  if (!navigator.clipboard || !window.ClipboardItem) {
    setPill('generateState', '当前浏览器不支持复制卡片', 'warn');
    return;
  }
  setPill('generateState', '生成分享卡中...', '');
  buildShareCardBlob(item).then(function (blob) {
    return navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
  }).then(function () {
    setPill('generateState', '分享卡已复制', 'ok');
  }).catch(function (e) {
    setPill('generateState', '分享卡失败：' + ((e && e.message) || e), 'warn');
  });
}

function copyImageToClipboard(url) {
  if (!url) { setPill('generateState', '没有图片可复制', 'warn'); return; }
  if (!navigator.clipboard || !window.ClipboardItem) {
    setPill('generateState', '当前浏览器不支持复制图片', 'warn');
    return;
  }
  setPill('generateState', '复制图片中...', '');
  fetch(url).then(function (r) {
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.blob();
  }).then(blobToPngBlob).then(function (blob) {
    return navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
  }).then(function () {
    setPill('generateState', '图片已复制', 'ok');
  }).catch(function () {
    setPill('generateState', '复制图片失败', 'warn');
  });
}

function openGuideRegenerateModal(item) {
  item = item || {};
  if (!item.url) { setPill('generateState', '缺少引导图片', 'warn'); return; }
  state.guideItem = item;
  if ($('guidePrompt')) $('guidePrompt').value = resultGuidePrompt(item);
  if (item.negativePrompt) $('negativePrompt').value = item.negativePrompt;
  var modal = $('guideActionModal');
  if (modal) modal.hidden = false;
  if ($('guidePrompt')) $('guidePrompt').focus();
}

function closeGuideRegenerateModal() {
  state.guideItem = null;
  var modal = $('guideActionModal');
  if (modal) modal.hidden = true;
}

function runSkuGuideRegenerate(item) {
  var guide = ($('guidePrompt') && $('guidePrompt').value.trim()) || '';
  var product = item.skuProductImage || (state.skuProducts[item.sourceIndex] && state.skuProducts[item.sourceIndex].url) || '';
  if (!product) {
    showProductSubjectRequired('sku', '缺少 SKU 产品图，不能引导重生。请先上传当前 SKU 产品图。');
    return;
  }
  closeGuideRegenerateModal();
  state.stopRequested = false;
  setSkuBusy(true);
  setPill('skuState', 'SKU 引导重生中...', '');

  var jobId = newJobId();
  state.activeJobId = jobId;
  var negative = item.negativePrompt || replacementNegativePrompt();
  var prompt = [
    'SKU 引导重生任务。',
    guide ? '最高权重引导词：' + guide : '',
    '当前结果图只作为构图、光影、背景和版式参考，不能锁定旧商品。',
    '必须以当前 SKU 产品图为唯一商品主体，保持产品结构、颜色、包装比例和关键细节。',
    item.prompt ? '低权重历史提示词，仅保留不冲突的风格信息：\n' + item.prompt : ''
  ].filter(Boolean).join('\n');

  return send('GENERATE_IMAGE', {
    jobId: jobId,
    config: skuConfigForGeneration(),
    payload: {
      prompt: prompt,
      negativePrompt: negative,
      referenceImage: item.url,
      productImage: product,
      productImages: [product],
      modelImages: [],
      labMode: 'sku',
      detailMode: 'sku-guide',
      size: skuSizeFromSettings(),
      clarity: 'commercial',
      count: 1,
      watermark: 'false',
      _jobId: jobId
    }
  }).then(function (resp) {
    if (state.activeJobId === jobId) state.activeJobId = '';
    if (resp && resp.ok && resp.images && resp.images.length) {
      resp.images.forEach(function (url) {
        state.skuResults.push({
          url: url,
          variant: 'sku',
          variantName: (item.variantName || 'SKU') + ' 引导重生',
          sourceIndex: item.sourceIndex,
          taskId: resp.taskId || '',
          prompt: prompt,
          negativePrompt: negative,
          skuProductImage: product
        });
      });
      renderSkuWorkspace();
    }
    setSkuBusy(false);
    setPill('skuState', resp && resp.ok ? 'SKU 引导重生完成' : ((resp && resp.error) || 'SKU 引导重生失败'), resp && resp.ok ? 'ok' : 'warn');
    return resp;
  }).catch(function (err) {
    if (state.activeJobId === jobId) state.activeJobId = '';
    setSkuBusy(false);
    setPill('skuState', (err && err.message) || 'SKU 引导重生失败', 'warn');
    return { ok: false, error: err && err.message };
  });
}

function runGuideRegenerate() {
  var item = state.guideItem || {};
  if (!item.url) { setPill('generateState', '缺少引导图片', 'warn'); return; }
  if (item.variant === 'sku') {
    runSkuGuideRegenerate(item);
    return;
  }
  if (!validateGenerationReady()) return;
  setRefImage(item.url, item.url);
  if (item.negativePrompt) $('negativePrompt').value = item.negativePrompt;
  closeGuideRegenerateModal();
  state.stopRequested = false;
  setStopAvailable(true);
  setPill('generateState', '引导重生中...', '');
  generateOne('guide', '引导重生', 1).then(function (resp) {
    setStopAvailable(false);
    setPill('generateState', resp && resp.ok ? '引导重生完成' : ((resp && resp.error) || '引导重生失败'), resp && resp.ok ? 'ok' : 'warn');
  });
}

function setStopAvailable(on) {
  var btn = $('stopGenerateBtn');
  if (!btn) return;
  btn.hidden = !on;
  btn.disabled = !on;
}

function newJobId() {
  return 'job_' + Date.now() + '_' + Math.random().toString(16).slice(2);
}

function stopGeneration() {
  state.stopRequested = true;
  if (state.activeJobId) {
    state.cancelledJobs[state.activeJobId] = true;
    send('CANCEL_GENERATION', { jobId: state.activeJobId });
  }
  setStopAvailable(false);
  setPill('generateState', '已终止', 'warn');
}

function generateOne(variant, variantName, countOverride) {
  if (state.stopRequested) return Promise.resolve({ ok: false, error: '已终止' });
  var labMode = currentLabMode();
  var detailMode = state.detailMode;
  var productImages = productImageList();
  if (!productImages.length) {
    showProductSubjectRequired(labMode);
    return Promise.resolve({ ok: false, error: productSubjectRequiredMessage(labMode) });
  }
  var basePrompt = generationPrompt(variant);
  if (!basePrompt.trim()) return Promise.resolve({ ok: false, error: '缺少提示词' });
  var requestedCount = generationImageCount(countOverride);
  var prompt = [generationParamPromptLayer(requestedCount), basePrompt].filter(Boolean).join('\n\n');
  var jobId = newJobId();
  state.activeJobId = jobId;
  var productImage = productImages[0] || '';
  var negative = $('negativePrompt').value.trim();
  if (productImage) negative = [negative, replacementNegativePrompt()].filter(Boolean).join(', ');
  var payloadBase = {
    prompt: prompt,
    negativePrompt: negative,
    referenceImage: state.refImage || normalizeImageUrl($('refUrl').value),
    productImage: productImage,
    productImages: productImages,
    modelImages: labMode === 'detail' ? modelImageList() : [],
    labMode: labMode,
    detailMode: detailMode,
    size: generationSizeFromSettings(),
    ratio: generationRatio(),
    resolution: generationResolution(),
    clarity: generationResolution(),
    count: 1,
    watermark: 'false',
    _jobId: jobId
  };
  var chunks = labMode === 'detail'
    ? Array.apply(null, Array(requestedCount)).map(function () { return 1; })
    : requestCountChunks(requestedCount);
  var detailNames = labMode === 'detail' ? detailSectionNames(requestedCount) : [];
  var chunkIndex = 0;
  var collected = [];
  function appendImages(resp, effectivePrompt) {
    if (resp && resp.ok && resp.images && resp.images.length) {
      resp.images.forEach(function (url) {
        var seq = collected.length + 1;
        collected.push(url);
        state.results.push({
          url: url,
          variant: variant,
          variantName: labMode === 'detail'
            ? (detailNames[seq - 1] || '详情图画面')
            : (requestedCount > 1 ? (variantName + ' ' + seq + '/' + requestedCount) : variantName),
          taskId: resp.taskId || '',
          labMode: labMode,
          detailMode: detailMode,
          detailScreenIndex: labMode === 'detail' ? seq : undefined,
          detailScreenTotal: labMode === 'detail' ? requestedCount : undefined,
          ratio: generationRatio(),
          resolution: generationResolution(),
          prompt: effectivePrompt || prompt,
          negativePrompt: negative
        });
      });
      renderResults();
    }
  }
  function finish(resp) {
    if (state.activeJobId === jobId) state.activeJobId = '';
    return resp;
  }
  function nextChunk() {
    if (state.stopRequested || state.cancelledJobs[jobId]) {
      delete state.cancelledJobs[jobId];
      return finish({ ok: false, error: '已终止', images: collected });
    }
    if (chunkIndex >= chunks.length) {
      return finish({ ok: collected.length > 0, images: collected, error: collected.length ? '' : '未生成图片' });
    }
    var chunkCount = chunks[chunkIndex++];
    var screenIndex = labMode === 'detail' ? (collected.length + 1) : 0;
    var requestPrompt = [prompt, detailScreenSequenceLayer(screenIndex, requestedCount)].filter(Boolean).join('\n\n');
    var payload = Object.assign({}, payloadBase, {
      count: chunkCount,
      prompt: requestPrompt,
      detailScreenIndex: screenIndex || undefined,
      detailScreenTotal: labMode === 'detail' ? requestedCount : undefined
    });
    return send('GENERATE_IMAGE', { jobId: jobId, config: cfgFromForm(), payload: payload }).then(function (resp) {
      if (state.stopRequested || state.cancelledJobs[jobId]) {
        delete state.cancelledJobs[jobId];
        return finish({ ok: false, error: '已终止', images: collected });
      }
      appendImages(resp, requestPrompt);
      if (!resp || !resp.ok) {
        return finish(collected.length ? { ok: true, images: collected, warning: resp && resp.error } : resp);
      }
      return nextChunk();
    }).catch(function (err) {
      return finish(collected.length ? { ok: true, images: collected, warning: err && err.message } : { ok: false, error: (err && err.message) || '生图失败' });
    });
  }
  return nextChunk();
}

function generateCurrent() {
  if (!validateGenerationReady()) return;
  state.stopRequested = false;
  setStopAvailable(true);
  setPill('generateState', '生图中...', '');
  $('generateBtn').disabled = true;
  generateOne('single', currentLabMode() === 'detail' ? '详情提示词' : '参考图生图', generationImageCount()).then(function (resp) {
    $('generateBtn').disabled = false;
    setStopAvailable(false);
    setPill('generateState', resp && resp.ok ? '生成完成' : ((resp && resp.error) || '生成失败'), resp && resp.ok ? 'ok' : 'warn');
  });
}

function batchGenerate() {
  if (!validateGenerationReady()) return;
  var variants = [
    ['main', '主图转化版'],
    ['scene', '场景种草版'],
    ['hook', '视觉锤版'],
    ['diff', '竞品差异化版']
  ];
  if (currentLabMode() === 'detail') {
    variants = [
      ['main', '详情首屏'],
      ['scene', '场景说明屏'],
      ['hook', '卖点证明屏'],
      ['diff', '差异信任屏']
    ];
  }
  if ($('batchMode') && $('batchMode').value === 'single') variants = [['single', '当前提示词']];
  state.stopRequested = false;
  setStopAvailable(true);
  setPill('generateState', '批量生成中 0/' + variants.length, '');
  if ($('batchBtn')) $('batchBtn').disabled = true;
  var i = 0;
  function next() {
    if (state.stopRequested) {
      if ($('batchBtn')) $('batchBtn').disabled = false;
      setStopAvailable(false);
      setPill('generateState', '已终止', 'warn');
      return;
    }
    if (i >= variants.length) {
      if ($('batchBtn')) $('batchBtn').disabled = false;
      setStopAvailable(false);
      setPill('generateState', '批量完成，共 ' + state.results.length + ' 张', 'ok');
      return;
    }
    var v = variants[i++];
    setPill('generateState', '批量生成中 ' + (i - 1) + '/' + variants.length + '：' + v[1], '');
    generateOne(v[0], v[1], 1).then(function (resp) {
      if (!resp || !resp.ok) setPill('generateState', '部分失败：' + ((resp && resp.error) || '未知错误'), 'warn');
      next();
    });
  }
  next();
}

function clampInt(value, min, max, fallback) {
  var n = parseInt(value, 10);
  if (!isFinite(n)) n = fallback;
  return Math.max(min, Math.min(max, n));
}

function setBatchLinksBusy(on) {
  if ($('batchLinksBtn')) $('batchLinksBtn').disabled = !!on;
  if ($('linkNumberGenerateBtn')) $('linkNumberGenerateBtn').disabled = !!on;
  if ($('buildPromptBtn')) $('buildPromptBtn').disabled = !!on;
  if ($('generateBtn')) $('generateBtn').disabled = !!on;
  if ($('batchBtn')) $('batchBtn').disabled = !!on;
}

function readBatchLinkRows() {
  var rows = [];
  try { rows = parseLinkListInput(); } catch (e) { throw e; }
  if (!rows.length) {
    var single = parseLinkJson();
    rows = [single];
  }
  state.linkList = rows;
  return rows;
}

function batchLinksPromptAndGenerate() {
  var rows;
  try { rows = readBatchLinkRows(); } catch (e) { setPill('runState', e.message, 'warn'); return; }
  if (!rows.length) { setPill('runState', '没有可处理的链接清单', 'warn'); return; }
  var productImages = productImageList();
  if (!productImages.length) {
    showProductSubjectRequired('main');
    return;
  }
  syncPrimaryProductImage();
  var rangeSelection = selectRowsByLinkRange(rows);
  var selected = rangeSelection.rows;
  if (!selected.length) {
    setPill('linkState', '没有匹配 ' + rangeSelection.label + ' 的链接', 'warn');
    setPill('generateState', '请检查链接编号范围', 'warn');
    return;
  }
  var perLink = generationImageCount();
  var before = state.results.length;
  var index = 0;
  state.stopRequested = false;
  setStopAvailable(true);
  setBatchLinksBusy(true);
  setPill('linkState', '批量队列 ' + rangeSelection.label + '，共 ' + selected.length + ' 条', 'ok');
  setPill('generateState', '批量准备中...', '');

  function finish(text, kind) {
    setBatchLinksBusy(false);
    setStopAvailable(false);
    setPill('generateState', text, kind);
  }

  function next() {
    if (state.stopRequested) {
      finish('已终止，已生成 ' + Math.max(0, state.results.length - before) + ' 张', 'warn');
      return;
    }
    if (index >= selected.length) {
      finish('批量完成：' + rangeSelection.label + '，' + selected.length + ' 条链接，新增 ' + Math.max(0, state.results.length - before) + ' 张', 'ok');
      return;
    }
    var row = Object.assign({}, selected[index]);
    var label = linkRowLabel(row, index);
    index++;
    setPill('runState', '链接提词 ' + index + '/' + selected.length + '：' + label, '');
    buildPromptForLink(row, label, { silent: true }).then(function (resp) {
      if (state.stopRequested) { next(); return; }
      if (!resp || !resp.ok) {
        setPill('runState', '跳过 ' + label + '：' + ((resp && resp.error) || '提词失败'), 'warn');
        next();
        return;
      }
      setPill('generateState', '链接生图 ' + index + '/' + selected.length + '：' + label + '（' + perLink + ' 张）', '');
      generateOne('single', label, perLink).then(function (genResp) {
        if (!genResp || !genResp.ok) setPill('generateState', '部分失败：' + label + '，' + ((genResp && genResp.error) || '生图失败'), 'warn');
        next();
      });
    });
  }
  next();
}

function skuDefaultPrompt() {
  return '复刻图1图片的整体版式、光影、背景、文字排版位置和商业质感，产品主体替换为图2产品。注意保持图2产品结构、颜色、包装与细节一致，文字内容不变或按SKU属性文本替换，不要保留模板里的旧商品、旧品牌和旧包装。';
}

function skuResolutionScale(resolution) {
  if (resolution === '4K') return 4;
  if (resolution === '2K') return 2;
  return 1;
}

function skuSizeFromSettings() {
  var ratio = ($('skuRatio') && $('skuRatio').value) || '1:1';
  var scale = skuResolutionScale(($('skuResolution') && $('skuResolution').value) || '1K');
  var base = {
    '1:1': [1024, 1024],
    '2:3': [896, 1344],
    '3:2': [1344, 896],
    '3:4': [768, 1024],
    '4:3': [1024, 768],
    '4:5': [1024, 1280],
    '5:4': [1280, 1024],
    '9:16': [1024, 1792],
    '16:9': [1792, 1024],
    '21:9': [2048, 878]
  }[ratio] || [1024, 1024];
  if (scale === 1) return base[0] + '*' + base[1];
  return Math.round(base[0] * scale) + '*' + Math.round(base[1] * scale);
}

function skuAttributes() {
  var text = ($('skuAttrText') && $('skuAttrText').value) || '';
  return text.split(/\r?\n/).map(function (line) {
    return line.trim();
  }).filter(Boolean);
}

function updateSkuCounts() {
  if ($('skuProductCount')) $('skuProductCount').textContent = state.skuProducts.length + ' / 20';
  if ($('skuTemplateCount')) $('skuTemplateCount').textContent = state.skuTemplate ? '1 / 1' : '0 / 1';
  if ($('skuAttrCount')) $('skuAttrCount').textContent = skuAttributes().length + ' / ' + state.skuProducts.length;
  if ($('skuState')) {
    if (state.skuActive) return;
    setPill('skuState', state.skuProducts.length ? ('已载入产品图 ' + state.skuProducts.length + ' 张') : '等待素材', state.skuProducts.length ? 'ok' : '');
  }
}

function renderSkuTemplate() {
  var box = $('skuTemplatePreview');
  if (!box) return;
  box.innerHTML = '';
  if (!state.skuTemplate) {
    box.className = 'sku-template-preview empty';
    box.textContent = '模板预览';
    return;
  }
  box.className = 'sku-template-preview';
  var img = document.createElement('img');
  img.src = state.skuTemplate;
  img.alt = 'SKU 模板';
  box.appendChild(img);
}

function renderSkuProducts() {
  var grid = $('skuProductPreview');
  if (!grid) return;
  grid.innerHTML = '';
  state.skuProducts.forEach(function (item, idx) {
    var box = document.createElement('div');
    box.className = 'sku-thumb';
    var img = document.createElement('img');
    img.src = item.url;
    img.alt = item.name || ('SKU 产品图 ' + (idx + 1));
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = '×';
    btn.title = '移除';
    btn.addEventListener('click', function () {
      state.skuProducts.splice(idx, 1);
      renderSkuWorkspace();
    });
    box.appendChild(img);
    box.appendChild(btn);
    grid.appendChild(box);
  });
}

function renderSkuTasks() {
  var list = $('skuTaskList');
  var empty = $('skuEmpty');
  if (!list) return;
  list.innerHTML = '';
  if (empty) empty.classList.toggle('has-result', state.skuProducts.length || state.skuResults.length);
  var attrs = skuAttributes();
  state.skuProducts.forEach(function (item, idx) {
    var row = document.createElement('div');
    row.className = 'sku-task-row';
    var img = document.createElement('img');
    img.src = item.url;
    img.alt = item.name || ('SKU ' + (idx + 1));
    var body = document.createElement('div');
    var title = document.createElement('strong');
    title.textContent = 'SKU ' + String(idx + 1).padStart(2, '0') + ' · ' + (item.name || '产品图');
    var sub = document.createElement('span');
    sub.textContent = attrs[idx] ? ('属性：' + attrs[idx]) : '未填写属性文本，按产品图直接生成';
    var status = document.createElement('b');
    status.textContent = state.skuResults.some(function (r) { return r.sourceIndex === idx; }) ? '已生成' : '待生成';
    body.appendChild(title);
    body.appendChild(sub);
    row.appendChild(img);
    row.appendChild(body);
    row.appendChild(status);
    list.appendChild(row);
  });
}

function renderSkuResults() {
  var grid = $('skuResultGrid');
  if (!grid) return;
  grid.innerHTML = '';
  state.skuResults.forEach(function (item, idx) {
    var card = document.createElement('div');
    card.className = 'result-card';
    var img = document.createElement('img');
    img.src = item.url;
    img.alt = item.variantName || 'SKU 结果图';
    var meta = document.createElement('div');
    meta.className = 'result-meta';
    var strong = document.createElement('strong');
    strong.textContent = (idx + 1) + '. ' + (item.variantName || 'SKU 生成图');
    var urlLine = document.createElement('div');
    urlLine.className = 'result-url';
    urlLine.title = item.url;
    urlLine.textContent = item.url ? '图片链接已生成' : '无图片链接';
    var row = document.createElement('div');
    row.className = 'result-actions';
    var copyImg = document.createElement('button');
    copyImg.className = 'btn ghost';
    copyImg.type = 'button';
    copyImg.textContent = '复制图片';
    copyImg.addEventListener('click', function () { openImageActionModal(item); });
    var guideBtn = document.createElement('button');
    guideBtn.className = 'btn ghost';
    guideBtn.type = 'button';
    guideBtn.textContent = '引导重生';
    guideBtn.addEventListener('click', function () { openGuideRegenerateModal(item); });
    var dl = document.createElement('button');
    dl.className = 'btn ghost';
    dl.type = 'button';
    dl.textContent = '下载';
    dl.addEventListener('click', function () {
      send('DOWNLOAD_ALL', { items: buildDownloadItems([item], 'sku') });
    });
    row.appendChild(copyImg);
    row.appendChild(guideBtn);
    row.appendChild(dl);
    meta.appendChild(strong);
    meta.appendChild(urlLine);
    meta.appendChild(row);
    card.appendChild(img);
    card.appendChild(meta);
    grid.appendChild(card);
  });
}

function renderSkuWorkspace() {
  renderSkuProducts();
  renderSkuTemplate();
  renderSkuTasks();
  renderSkuResults();
  updateSkuCounts();
}

function addSkuProducts(items) {
  items = (items || []).filter(function (item) { return item && item.url; });
  items.forEach(function (item) {
    if (state.skuProducts.length >= 20) return;
    var exists = state.skuProducts.some(function (old) { return old.url === item.url; });
    if (!exists) state.skuProducts.push(item);
  });
  renderSkuWorkspace();
}

function parseSkuUrlLines() {
  var text = ($('skuProductUrls') && $('skuProductUrls').value) || '';
  return text.split(/\r?\n/).map(function (line) {
    return normalizeImageUrl(line.trim());
  }).filter(Boolean).slice(0, 20);
}

function readTextFile(file) {
  return new Promise(function (resolve, reject) {
    var rd = new FileReader();
    rd.onload = function () { resolve(rd.result || ''); };
    rd.onerror = function () { reject(rd.error); };
    rd.readAsText(file);
  });
}

function skuPromptFor(item, idx, attr) {
  var userPrompt = (($('skuPrompt') && $('skuPrompt').value.trim()) || skuDefaultPrompt());
  var parts = [
    '批量 SKU 生成任务，第 ' + (idx + 1) + ' 张。',
    state.skuTemplate
      ? '图1是 SKU 模板：只参考它的构图、背景、光影、文字区域、卖点布局、材质质感和商业风格；不要复制模板里的旧商品、旧包装、旧品牌、旧文案。'
      : '没有 SKU 模板：根据下方提示词建立清爽统一的电商 SKU 视觉版式。',
    '图2/当前 SKU 产品图是唯一目标商品主体：必须保持它的外观结构、颜色、包装比例、关键细节和可识别品类，不要变成模板商品、旧商品或参考图商品。',
    '如果用户提示词、模板图或历史结果描述了其他商品主体，只保留版式与风格信息，最终商品必须替换为当前 SKU 产品图。',
    attr ? '本张 SKU 属性文本：' + attr : '',
    '用户提示词：' + userPrompt,
    '输出要求：生成一张可用于 SKU 展示的电商商品图，主体清楚、排版稳定、文字区域克制，风格统一但每张产品保持自身差异。',
    '禁止：旧品牌、旧 logo、旧商品、复制模板商标、错换品类、主体被遮挡、文字乱码、夸张畸形结构。'
  ];
  return parts.filter(Boolean).join('\n');
}

function skuConfigForGeneration() {
  var cfg = cfgFromForm();
  var model = ($('skuImageModel') && $('skuImageModel').value) || 'current';
  if (model && model !== 'current') cfg.imageModel = model;
  return cfg;
}

function setSkuBusy(on) {
  state.skuActive = !!on;
  ['skuGenerateBtn', 'skuClearBtn', 'skuDownloadAllBtn'].forEach(function (id) {
    if ($(id)) $(id).disabled = !!on;
  });
  if ($('skuStopBtn')) {
    $('skuStopBtn').hidden = !on;
    $('skuStopBtn').disabled = !on;
  }
}

function stopSkuGeneration() {
  state.stopRequested = true;
  if (state.activeJobId) {
    state.cancelledJobs[state.activeJobId] = true;
    send('CANCEL_GENERATION', { jobId: state.activeJobId });
  }
  setSkuBusy(false);
  setPill('skuState', '已终止', 'warn');
}

function generateSkuOne(item, idx, attr) {
  if (!item || !item.url) {
    showProductSubjectRequired('sku');
    return Promise.resolve({ ok: false, error: productSubjectRequiredMessage('sku') });
  }
  var jobId = newJobId();
  state.activeJobId = jobId;
  var prompt = skuPromptFor(item, idx, attr);
  var negative = replacementNegativePrompt();
  var payload = {
    prompt: prompt,
    negativePrompt: negative,
    referenceImage: state.skuTemplate || '',
    productImage: item.url,
    productImages: [item.url],
    modelImages: [],
    labMode: 'sku',
    detailMode: 'sku',
    size: skuSizeFromSettings(),
    clarity: 'commercial',
    count: 1,
    watermark: 'false',
    _jobId: jobId
  };
  return send('GENERATE_IMAGE', { jobId: jobId, config: skuConfigForGeneration(), payload: payload }).then(function (resp) {
    if (state.activeJobId === jobId) state.activeJobId = '';
    if (state.stopRequested || state.cancelledJobs[jobId]) {
      delete state.cancelledJobs[jobId];
      return { ok: false, error: '已终止' };
    }
    if (resp && resp.ok && resp.images && resp.images.length) {
      resp.images.forEach(function (url) {
        state.skuResults.push({
          url: url,
          variant: 'sku',
          variantName: 'SKU ' + String(idx + 1).padStart(2, '0'),
          sourceIndex: idx,
          taskId: resp.taskId || '',
          prompt: prompt,
          negativePrompt: negative,
          skuProductImage: item.url
        });
      });
      renderSkuWorkspace();
    }
    return resp;
  });
}

function generateSkuBatch() {
  if (!state.skuProducts.length) {
    showProductSubjectRequired('sku');
    return;
  }
  state.stopRequested = false;
  state.skuResults = [];
  renderSkuWorkspace();
  setSkuBusy(true);
  setPill('skuState', 'SKU 生成中 0/' + state.skuProducts.length, '');
  var attrs = skuAttributes();
  var index = 0;
  function finish(text, kind) {
    setSkuBusy(false);
    setPill('skuState', text, kind);
    renderSkuWorkspace();
  }
  function next() {
    if (state.stopRequested) {
      finish('已终止，已生成 ' + state.skuResults.length + ' 张', 'warn');
      return;
    }
    if (index >= state.skuProducts.length) {
      finish('SKU 批量完成，共 ' + state.skuResults.length + ' 张', 'ok');
      return;
    }
    var item = state.skuProducts[index];
    var attr = attrs[index] || '';
    setPill('skuState', 'SKU 生成中 ' + index + '/' + state.skuProducts.length + '：SKU ' + String(index + 1).padStart(2, '0'), '');
    generateSkuOne(item, index, attr).then(function (resp) {
      if (!resp || !resp.ok) setPill('skuState', '部分失败：SKU ' + String(index + 1).padStart(2, '0') + '，' + ((resp && resp.error) || '生图失败'), 'warn');
      index++;
      next();
    });
  }
  next();
}

function copyText(text, stateId) {
  navigator.clipboard.writeText(text || '').then(function () {
    setPill(stateId || 'runState', '已复制', 'ok');
  }).catch(function () {
    setPill(stateId || 'runState', '复制失败', 'warn');
  });
}

function loadStoredLinks() {
  return new Promise(function (resolve) {
    try {
      chrome.storage.local.get([LINKMATRIX_JSON_KEY], function (r) {
        var saved = r && r[LINKMATRIX_JSON_KEY];
        var rows = normalizeLinkRows(saved);
        if (!rows.length) {
          setPill('linkState', '暂无缓存链接', 'warn');
          resolve({ ok: false, error: '暂无缓存链接' });
          return;
        }
        $('linkJson').value = JSON.stringify(rows, null, 2);
        applyLinkToFields(rows, true);
        syncBatchRangeDefaults(rows, false);
        setPill('linkState', '已载入 ' + rows.length + ' 条链接', 'ok');
        resolve({ ok: true, rows: rows });
      });
    } catch (e) {
      setPill('linkState', '载入失败', 'warn');
      resolve({ ok: false, error: (e && e.message) || e });
    }
  });
}

function loadContext(auto) {
  send('GET_CONTEXT').then(function (r) {
    if (!r || !r.ok) return;
    var normalized = applyCfg(r.config);
    if (JSON.stringify(normalized) !== JSON.stringify(Object.assign({}, DEFAULT_CFG, r.config || {}))) {
      send('SAVE_CONFIG', { config: normalized });
      setPill('configState', '已自动迁移旧模型配置', 'ok');
    }
    if (r.context && r.context.imageUrl) {
      var params = new URLSearchParams(location.search);
      if (params.get('source') === 'context') {
        openContextActionModal(r.context, auto && (r.config && r.config.apiKey));
        return;
      }
      setPill('contextState', '右键图片导入中...', '');
      $('refUrl').value = r.context.imageUrl;
      setRefImage(r.context.imageUrl, r.context.imageUrl);
      if (auto && (r.config && r.config.apiKey)) analyzeCurrentImage();
    }
  });
}

function bind() {
  if ($('openConfigBtn')) $('openConfigBtn').addEventListener('click', openConfigModal);
  $('saveConfigBtn').addEventListener('click', saveCfg);
  if ($('configCloseBtn')) $('configCloseBtn').addEventListener('click', closeConfigModal);
  if ($('configCancelBtn')) $('configCancelBtn').addEventListener('click', closeConfigModal);
  if ($('configModal')) $('configModal').addEventListener('click', function (ev) {
    if (ev.target === $('configModal')) closeConfigModal();
  });
  $('loadSampleBtn').addEventListener('click', function () {
    if (currentLabMode() === 'sku') loadSkuSample();
    else if (currentLabMode() === 'detail') loadDetailSample();
    else applyLinkToFields(sampleLink);
  });
  $('provider').addEventListener('change', function () {
    loadProviderProfile($('provider').value);
  });
  if ($('providerRail')) $('providerRail').addEventListener('click', function (ev) {
    var btn = ev.target.closest && ev.target.closest('[data-provider-pick]');
    if (!btn) return;
    var provider = btn.getAttribute('data-provider-pick');
    if (!provider || !$('provider')) return;
    $('provider').value = provider;
    loadProviderProfile(provider);
  });
  ['apiKey', 'imageAdapter', 'visionModel', 'textModel', 'imageModel', 'visionBaseUrl', 'imageEndpoint'].forEach(function (id) {
    var el = $(id);
    if (!el) return;
    var eventName = el.tagName === 'SELECT' ? 'change' : 'input';
    el.addEventListener(eventName, function () {
      updateConfigSummary(cfgFromForm());
      setPill('configState', el.id === 'apiKey' && !el.value ? '未配置' : '待保存', el.id === 'apiKey' && !el.value ? 'warn' : '');
    });
  });
  $('refFile').addEventListener('change', function (ev) {
    var f = ev.target.files && ev.target.files[0];
    if (!f) return;
    setPill('contextState', '压缩参考图中...', '');
    fileToOptimizedDataUrl(f).then(function (url) { setRefImage(url, ''); });
  });
  Object.keys(PRODUCT_ANGLES).forEach(function (kind) {
    var meta = PRODUCT_ANGLES[kind];
    if ($(meta.file)) $(meta.file).addEventListener('change', function (ev) {
      var f = ev.target.files && ev.target.files[0];
      if (!f) return;
      setPill('contextState', '压缩' + meta.label + '中...', '');
      fileToOptimizedDataUrl(f).then(function (url) { setProductAngle(kind, url, ''); });
    });
    if ($(meta.url)) $(meta.url).addEventListener('change', function () {
      setProductAngle(kind, normalizeImageUrl($(meta.url).value), $(meta.url).value);
    });
    var clearBtn = $('clearProduct' + kind.charAt(0).toUpperCase() + kind.slice(1) + 'Btn');
    if (clearBtn) clearBtn.addEventListener('click', function () {
      setProductAngle(kind, '', '');
      if ($(meta.file)) $(meta.file).value = '';
    });
  });
  Object.keys(MODEL_ANGLES).forEach(function (kind) {
    var meta = MODEL_ANGLES[kind];
    if ($(meta.file)) $(meta.file).addEventListener('change', function (ev) {
      var f = ev.target.files && ev.target.files[0];
      if (!f) return;
      setPill('contextState', '压缩' + meta.label + '中...', '');
      fileToOptimizedDataUrl(f).then(function (url) { setModelAngle(kind, url, ''); });
    });
    if ($(meta.url)) $(meta.url).addEventListener('change', function () {
      setModelAngle(kind, normalizeImageUrl($(meta.url).value), $(meta.url).value);
    });
    var clearBtn = $('clearModel' + kind.charAt(0).toUpperCase() + kind.slice(1) + 'Btn');
    if (clearBtn) clearBtn.addEventListener('click', function () {
      setModelAngle(kind, '', '');
      if ($(meta.file)) $(meta.file).value = '';
    });
  });
  $('refUrl').addEventListener('change', function () { setRefImage(normalizeImageUrl($('refUrl').value), $('refUrl').value); });
  $('clearRefBtn').addEventListener('click', function () { setRefImage('', ''); $('refFile').value = ''; });
  $('analyzeBtn').addEventListener('click', analyzeCurrentImage);
  $('buildPromptBtn').addEventListener('click', buildLinkPrompt);
  if ($('batchLinksBtn')) $('batchLinksBtn').addEventListener('click', batchLinksPromptAndGenerate);
  if ($('loadStoredLinksBtn')) $('loadStoredLinksBtn').addEventListener('click', loadStoredLinks);
  if ($('detailRefModeBtn')) $('detailRefModeBtn').addEventListener('click', function () { setDetailMode('reference'); });
  if ($('detailLinkModeBtn')) $('detailLinkModeBtn').addEventListener('click', function () { setDetailMode('link'); });
  if ($('detailScreenCount')) $('detailScreenCount').addEventListener('change', function () {
    $('detailScreenCount').dataset.userTouched = '1';
    syncDetailModeControls();
    syncDetailGenerationCount(true);
  });
  ['detailRatio', 'detailResolution'].forEach(function (id) {
    var el = $(id);
    if (!el) return;
    el.addEventListener('change', syncGenerationParamSummary);
  });
  if ($('detailStitchToggle')) $('detailStitchToggle').addEventListener('change', renderDetailLongPreview);
  if ($('detailSmartFillBtn')) $('detailSmartFillBtn').addEventListener('click', fillDetailFieldsFromContext);
  if ($('detailModelGenerateBtn')) $('detailModelGenerateBtn').addEventListener('click', buildModelThreeViewPrompt);
  if ($('detailRefGenerateBtn')) $('detailRefGenerateBtn').addEventListener('click', function () { generateDetailPrompt('reference'); });
  if ($('detailLinkGenerateBtn')) $('detailLinkGenerateBtn').addEventListener('click', function () { generateDetailPrompt('link'); });
  if ($('copyDetailPromptBtn')) $('copyDetailPromptBtn').addEventListener('click', function () { copyText($('detailPrompt') ? $('detailPrompt').value : '', 'detailState'); });
  if ($('skuProductFiles')) $('skuProductFiles').addEventListener('change', function (ev) {
    var files = Array.prototype.slice.call((ev.target && ev.target.files) || []).slice(0, Math.max(0, 20 - state.skuProducts.length));
    if (!files.length) return;
    setPill('skuState', '压缩 SKU 产品图中...', '');
    Promise.all(files.map(function (file) {
      return fileToOptimizedDataUrl(file).then(function (url) {
        return { url: url, name: file.name || '产品图' };
      });
    })).then(function (items) {
      addSkuProducts(items);
      setPill('skuState', '已载入产品图 ' + state.skuProducts.length + ' 张', 'ok');
    });
  });
  function syncSkuProductUrls() {
    addSkuProducts(parseSkuUrlLines().map(function (url, idx) {
      return { url: url, name: 'URL 产品图 ' + (idx + 1) };
    }));
  }
  if ($('skuProductUrls')) {
    $('skuProductUrls').addEventListener('input', syncSkuProductUrls);
    $('skuProductUrls').addEventListener('change', syncSkuProductUrls);
  }
  if ($('skuTemplateFile')) $('skuTemplateFile').addEventListener('change', function (ev) {
    var f = ev.target.files && ev.target.files[0];
    if (!f) return;
    setPill('skuState', '压缩 SKU 模板中...', '');
    fileToOptimizedDataUrl(f).then(function (url) {
      state.skuTemplate = url;
      renderSkuWorkspace();
      setPill('skuState', '已载入 SKU 模板', 'ok');
    });
  });
  function syncSkuTemplateUrl() {
    state.skuTemplate = normalizeImageUrl($('skuTemplateUrl').value);
    renderSkuWorkspace();
  }
  if ($('skuTemplateUrl')) {
    $('skuTemplateUrl').addEventListener('input', syncSkuTemplateUrl);
    $('skuTemplateUrl').addEventListener('change', syncSkuTemplateUrl);
  }
  if ($('skuAttrText')) $('skuAttrText').addEventListener('input', renderSkuWorkspace);
  if ($('skuAttrFile')) $('skuAttrFile').addEventListener('change', function (ev) {
    var f = ev.target.files && ev.target.files[0];
    if (!f) return;
    readTextFile(f).then(function (text) {
      $('skuAttrText').value = text;
      renderSkuWorkspace();
      setPill('skuState', '已载入 SKU 属性文本', 'ok');
    }).catch(function () {
      setPill('skuState', 'SKU 属性文本读取失败', 'warn');
    });
  });
  if ($('skuPromptTemplateBtn')) $('skuPromptTemplateBtn').addEventListener('click', function () {
    $('skuPrompt').value = skuDefaultPrompt();
    setPill('skuState', '已载入提示词模板', 'ok');
  });
  if ($('skuGenerateBtn')) $('skuGenerateBtn').addEventListener('click', generateSkuBatch);
  if ($('skuStopBtn')) $('skuStopBtn').addEventListener('click', stopSkuGeneration);
  if ($('skuDownloadAllBtn')) $('skuDownloadAllBtn').addEventListener('click', function () {
    send('DOWNLOAD_ALL', { items: buildDownloadItems(state.skuResults, 'sku') }).then(function (r) {
      setPill('skuState', r && r.ok ? ('开始下载 ' + r.count + ' 张') : ((r && r.error) || '下载失败'), r && r.ok ? 'ok' : 'warn');
    });
  });
  if ($('skuClearBtn')) $('skuClearBtn').addEventListener('click', function () {
    state.skuProducts = [];
    state.skuTemplate = '';
    state.skuResults = [];
    if ($('skuProductFiles')) $('skuProductFiles').value = '';
    if ($('skuProductUrls')) $('skuProductUrls').value = '';
    if ($('skuTemplateFile')) $('skuTemplateFile').value = '';
    if ($('skuTemplateUrl')) $('skuTemplateUrl').value = '';
    if ($('skuAttrFile')) $('skuAttrFile').value = '';
    if ($('skuAttrText')) $('skuAttrText').value = '';
    renderSkuWorkspace();
  });
  if ($('generateBtn')) $('generateBtn').addEventListener('click', generateCurrent);
  if ($('linkNumberGenerateBtn')) $('linkNumberGenerateBtn').addEventListener('click', batchLinksPromptAndGenerate);
  if ($('batchBtn')) $('batchBtn').addEventListener('click', batchGenerate);
  if ($('stopGenerateBtn')) $('stopGenerateBtn').addEventListener('click', stopGeneration);
  if ($('imageCount')) $('imageCount').addEventListener('input', function () {
    $('imageCount').dataset.userTouched = '1';
    $('imageCount').value = '' + generationImageCount();
  });
  if ($('copyCnBtn')) $('copyCnBtn').addEventListener('click', function () { copyText($('cnPrompt').value); });
  if ($('copyEnBtn')) $('copyEnBtn').addEventListener('click', function () { copyText($('enPrompt').value); });
  if ($('copyAllPromptBtn')) $('copyAllPromptBtn').addEventListener('click', function () {
    copyText(['中文提示词：', $('cnPrompt').value, '', '负面提示词：', $('negativePrompt').value].join('\n'));
  });
  $('downloadAllBtn').addEventListener('click', function () {
    var items = currentLabMode() === 'detail' ? detailPreviewResults() : state.results;
    send('DOWNLOAD_ALL', { items: buildDownloadItems(items, currentLabMode()) }).then(function (r) {
      setPill('generateState', r && r.ok ? ('开始下载 ' + r.count + ' 张') : ((r && r.error) || '下载失败'), r && r.ok ? 'ok' : 'warn');
    });
  });
  $('clearResultsBtn').addEventListener('click', function () {
    state.results = [];
    if ($('detailStitchToggle')) $('detailStitchToggle').checked = false;
    renderResults();
    setPill('generateState', generationIdleText(), '');
  });
  if ($('detailStitchBtn')) $('detailStitchBtn').addEventListener('click', stitchDetailLongImage);
  if ($('copyOriginalImageBtn')) $('copyOriginalImageBtn').addEventListener('click', function () {
    var item = state.actionItem;
    closeImageActionModal();
    copyImageToClipboard(item && item.url);
  });
  if ($('copyShareCardBtn')) $('copyShareCardBtn').addEventListener('click', function () {
    var item = state.actionItem;
    closeImageActionModal();
    copyShareCardToClipboard(item);
  });
  if ($('imageActionClose')) $('imageActionClose').addEventListener('click', closeImageActionModal);
  if ($('imageActionModal')) $('imageActionModal').addEventListener('click', function (ev) {
    if (ev.target === $('imageActionModal')) closeImageActionModal();
  });
  if ($('guideRunBtn')) $('guideRunBtn').addEventListener('click', runGuideRegenerate);
  if ($('guideCancelBtn')) $('guideCancelBtn').addEventListener('click', closeGuideRegenerateModal);
  if ($('guideActionClose')) $('guideActionClose').addEventListener('click', closeGuideRegenerateModal);
  if ($('guideActionModal')) $('guideActionModal').addEventListener('click', function (ev) {
    if (ev.target === $('guideActionModal')) closeGuideRegenerateModal();
  });
  if ($('productSubjectFocusBtn')) $('productSubjectFocusBtn').addEventListener('click', function () {
    focusProductSubjectUpload();
  });
  if ($('productSubjectCancelBtn')) $('productSubjectCancelBtn').addEventListener('click', closeProductSubjectModal);
  if ($('productSubjectClose')) $('productSubjectClose').addEventListener('click', closeProductSubjectModal);
  if ($('productSubjectModal')) $('productSubjectModal').addEventListener('click', function (ev) {
    if (ev.target === $('productSubjectModal')) closeProductSubjectModal();
  });
  if ($('contextImportBtn')) $('contextImportBtn').addEventListener('click', function () {
    var ctx = state.contextItem;
    var auto = state.contextAuto;
    closeContextActionModal();
    applyContextImage(ctx, auto);
  });
  if ($('contextShareCardBtn')) $('contextShareCardBtn').addEventListener('click', function () {
    var ctx = state.contextItem;
    closeContextActionModal();
    if (!$('apiKey') || !$('apiKey').value.trim()) {
      setPill('runState', '生成分享卡前需要先配置 API Key', 'warn');
      return;
    }
    applyContextImage(ctx, true).then(function (resp) {
      if (resp && resp.ok) {
        copyShareCardToClipboard({ url: ctx && ctx.imageUrl, variantName: '提示词分享卡', prompt: $('cnPrompt').value || $('enPrompt').value });
      }
    });
  });
  if ($('contextActionClose')) $('contextActionClose').addEventListener('click', closeContextActionModal);
  if ($('contextActionModal')) $('contextActionModal').addEventListener('click', function (ev) {
    if (ev.target === $('contextActionModal')) closeContextActionModal();
  });
  document.querySelectorAll('[data-share-card]').forEach(function (ctrl) {
    ctrl.addEventListener('change', function (ev) { syncShareCardControls(ev); });
    ctrl.addEventListener('input', function (ev) { syncShareCardControls(ev); });
  });
  syncShareCardControls({ position: 'top', border: '36', ratio: '4:5' });
  $('linkJson').addEventListener('change', function () {
    try { applyLinkToFields(parseLinkListInput(), true); } catch (e) { setPill('linkState', 'JSON 待修正', 'warn'); }
  });
  document.addEventListener('paste', function (ev) {
    var items = ev.clipboardData && ev.clipboardData.items;
    if (!items) return;
    for (var i = 0; i < items.length; i++) {
      if (items[i] && items[i].type && items[i].type.indexOf('image/') === 0) {
        ev.preventDefault();
        var file = items[i].getAsFile();
        if (!file) return;
        var activeId = document.activeElement && document.activeElement.id;
        setPill('contextState', '压缩粘贴图片中...', '');
        fileToOptimizedDataUrl(file).then(function (url) {
          if (activeId === 'skuProductUrls') {
            addSkuProducts([{ url: url, name: '粘贴产品图' }]);
            setPill('skuState', '已粘贴 SKU 产品图', 'ok');
            return;
          }
          if (activeId === 'skuTemplateUrl') {
            state.skuTemplate = url;
            if ($('skuTemplateUrl')) $('skuTemplateUrl').value = '';
            renderSkuWorkspace();
            setPill('skuState', '已粘贴 SKU 模板', 'ok');
            return;
          }
          var matched = '';
          Object.keys(PRODUCT_ANGLES).some(function (kind) {
            if (PRODUCT_ANGLES[kind].url === activeId) { matched = kind; return true; }
            return false;
          });
          if (matched) setProductAngle(matched, url, '');
          else {
            Object.keys(MODEL_ANGLES).some(function (kind) {
              if (MODEL_ANGLES[kind].url === activeId) { matched = 'model:' + kind; return true; }
              return false;
            });
            if (matched.indexOf('model:') === 0) setModelAngle(matched.split(':')[1], url, '');
            else setRefImage(url, '');
          }
        });
        return;
      }
    }
  });
}

document.addEventListener('DOMContentLoaded', function () {
  var params = new URLSearchParams(location.search);
  var source = params.get('source') || '';
  var detailMode = params.get('detailMode') || (source === 'linkmatrix' ? 'link' : 'reference');
  var requestedMode = params.get('mode') || params.get('surface') || 'main';
  var sourceRequestsDetail = source === 'detail-plugin' || source === 'detail-reference' || source === 'detail-batch';
  var labMode = requestedMode === 'sku' ? 'sku' : (requestedMode === 'detail' || sourceRequestsDetail ? 'detail' : 'main');
  setupLabMode(labMode, detailMode);
  if (labMode === 'sku') applySkuQueryParams(params);
  bind();
  if (labMode === 'detail') syncDetailModeDefaultsAfterRestore();
  renderResults();
  renderSkuWorkspace();
  loadContext(params.get('auto') === '1');
  if (labMode !== 'sku' && source === 'linkmatrix') loadStoredLinks();
});
