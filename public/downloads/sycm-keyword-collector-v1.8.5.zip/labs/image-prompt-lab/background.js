'use strict';

var CONFIG_KEY = 'sz_image_prompt_lab_config';
var CONFIG_PROFILES_KEY = 'sz_image_prompt_lab_config_profiles_v2';
var CONTEXT_KEY = 'sz_image_prompt_lab_context';
var LAB_PAGE = ((chrome.runtime.getManifest().name || '').indexOf('少壮AI自动化') >= 0)
  ? 'labs/image-prompt-lab/promptlab.html'
  : 'promptlab.html';
var CONTEXT_CARD_SCRIPT = ((chrome.runtime.getManifest().name || '').indexOf('少壮AI自动化') >= 0)
  ? 'labs/image-prompt-lab/context-card.js'
  : 'context-card.js';
var VOLC_SEEDREAM_DEFAULT = 'doubao-seedream-5-0-260128';
var DEFAULT_CFG = {
  provider: 'openai-compatible',
  imageAdapter: 'generic-json',
  visionBaseUrl: 'https://sub.shaozhuangai.com/v1',
  visionModel: 'chatGPT5.5',
  textModel: 'chatGPT5.5',
  imageEndpoint: 'https://sub.shaozhuangai.com/v1/images/generations',
  imageModel: 'image2',
  apiKey: ''
};
var PROVIDER_DEFAULTS = {
  dashscope: {
    provider: 'dashscope',
    imageAdapter: 'dashscope-wan',
    visionBaseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
    visionModel: 'qwen-vl-plus',
    textModel: 'qwen-plus',
    imageEndpoint: 'https://dashscope.aliyuncs.com/api/v1/services/aigc/image-generation/generation',
    imageModel: 'wan2.7-image'
  },
  'deepseek-v4': {
    provider: 'deepseek-v4',
    imageAdapter: 'none',
    visionBaseUrl: 'https://api.deepseek.com',
    visionModel: '',
    textModel: 'deepseek-v4-flash',
    imageEndpoint: '',
    imageModel: ''
  },
  minimax: {
    provider: 'minimax',
    imageAdapter: 'minimax-image',
    visionBaseUrl: 'https://api.minimax.io/v1',
    visionModel: 'MiniMax-M2.1',
    textModel: 'MiniMax-M2.1',
    imageEndpoint: 'https://api.minimax.io/v1/image_generation',
    imageModel: 'image-01'
  },
  zhipu: {
    provider: 'zhipu',
    imageAdapter: 'zhipu-cogview',
    visionBaseUrl: 'https://open.bigmodel.cn/api/paas/v4',
    visionModel: 'glm-4v-plus',
    textModel: 'glm-4-plus',
    imageEndpoint: 'https://open.bigmodel.cn/api/paas/v4/images/generations',
    imageModel: 'cogview-4-250304'
  },
  doubao: {
    provider: 'doubao',
    imageAdapter: 'doubao-image',
    visionBaseUrl: 'https://ark.cn-beijing.volces.com/api/v3',
    visionModel: 'doubao-seed-evolving',
    textModel: 'doubao-seed-evolving',
    imageEndpoint: 'https://ark.cn-beijing.volces.com/api/v3/images/generations',
    imageModel: VOLC_SEEDREAM_DEFAULT
  },
  openai: {
    provider: 'openai',
    imageAdapter: 'openai-images',
    visionBaseUrl: 'https://api.openai.com/v1',
    visionModel: 'gpt-5-mini',
    textModel: 'gpt-5-mini',
    imageEndpoint: 'https://api.openai.com/v1/images/generations',
    imageModel: 'gpt-image-2'
  },
  'nano-banana': {
    provider: 'nano-banana',
    imageAdapter: 'nano-banana',
    visionBaseUrl: 'https://generativelanguage.googleapis.com/v1beta',
    visionModel: 'gemini-2.5-flash-image-preview',
    textModel: 'gemini-2.5-flash',
    imageEndpoint: 'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent',
    imageModel: 'gemini-2.5-flash-image-preview'
  },
  'openai-compatible': {
    provider: 'openai-compatible',
    imageAdapter: 'generic-json',
    visionBaseUrl: 'https://sub.shaozhuangai.com/v1',
    visionModel: 'chatGPT5.5',
    textModel: 'chatGPT5.5',
    imageEndpoint: 'https://sub.shaozhuangai.com/v1/images/generations',
    imageModel: 'image2'
  }
};
var activeJobs = {};
var configAccountCache = { key: '', at: 0 };

function normalizeCfg(cfg) {
  var incoming = Object.assign({}, cfg || {});
  var provider = incoming.provider || DEFAULT_CFG.provider;
  var preset = PROVIDER_DEFAULTS[provider] || {};
  cfg = Object.assign({}, DEFAULT_CFG, preset, incoming);
  if (cfg.provider === 'jimeng') cfg.provider = 'doubao';
  if (cfg.imageAdapter === 'jimeng-image') cfg.imageAdapter = 'doubao-image';
  preset = PROVIDER_DEFAULTS[cfg.provider] || preset || {};
  ['imageAdapter', 'visionBaseUrl', 'visionModel', 'textModel', 'imageEndpoint', 'imageModel'].forEach(function (field) {
    if (!cfg[field] && preset[field]) cfg[field] = preset[field];
  });
  if (cfg.provider === 'openai-compatible') {
    if (!cfg.visionBaseUrl || cfg.visionBaseUrl === 'https://api.example.com/v1') cfg.visionBaseUrl = DEFAULT_CFG.visionBaseUrl;
    if (!cfg.imageEndpoint || cfg.imageEndpoint === 'https://api.example.com/v1/images/generations') cfg.imageEndpoint = DEFAULT_CFG.imageEndpoint;
    if (!cfg.visionModel || cfg.visionModel === 'vision-model' || cfg.visionModel === 'chat-model') cfg.visionModel = DEFAULT_CFG.visionModel;
    if (!cfg.textModel || cfg.textModel === 'chat-model' || cfg.textModel === 'vision-model') cfg.textModel = DEFAULT_CFG.textModel;
    if (!cfg.imageModel || cfg.imageModel === 'image-model') cfg.imageModel = DEFAULT_CFG.imageModel;
  }
  var isVolc = cfg.provider === 'doubao' || /^https:\/\/ark\.cn-beijing\.volces\.com/.test(cfg.visionBaseUrl || '');
  if (isVolc) {
    if (!cfg.visionModel || /^doubao-1\.5/.test(cfg.visionModel)) cfg.visionModel = 'doubao-seed-evolving';
    if (!cfg.textModel || /^doubao-1\.5/.test(cfg.textModel)) cfg.textModel = 'doubao-seed-evolving';
    if (!cfg.imageEndpoint) cfg.imageEndpoint = 'https://ark.cn-beijing.volces.com/api/v3/images/generations';
    if (!cfg.imageModel || /^doubao-seedream-3-0/i.test(cfg.imageModel)) cfg.imageModel = VOLC_SEEDREAM_DEFAULT;
  }
  return cfg;
}

function configAccountKeyFromAuth(auth) {
  var user = auth && auth.ok && auth.user ? auth.user : null;
  var raw = user && (user.id || user.userId || user.uid || user.email || user.username || user.name || user.mobile || user.phone);
  if (!raw) return 'local';
  return 'user:' + String(raw).replace(/[^\w@.+:-]/g, '_').slice(0, 120);
}

function resolveConfigAccountKey(cb) {
  var now = Date.now();
  if (configAccountCache.key && now - configAccountCache.at < 60000) {
    cb(configAccountCache.key);
    return;
  }
  if (typeof authCheck === 'function') {
    try {
      authCheck().then(function (auth) {
        var key = configAccountKeyFromAuth(auth);
        configAccountCache = { key: key, at: Date.now() };
        cb(key);
      }).catch(function () {
        configAccountCache = { key: 'local', at: Date.now() };
        cb('local');
      });
      return;
    } catch (e) {}
  }
  configAccountCache = { key: 'local', at: now };
  cb('local');
}

function normalizeProfileStore(raw) {
  var store = raw && typeof raw === 'object' ? raw : {};
  if (!store.accounts || typeof store.accounts !== 'object') store.accounts = {};
  if (!store.configs || typeof store.configs !== 'object') store.configs = {};
  store.version = 2;
  return store;
}

function profileAccount(store, accountKey) {
  if (!store.accounts[accountKey] || typeof store.accounts[accountKey] !== 'object') {
    store.accounts[accountKey] = { activeProvider: '', configs: {} };
  }
  if (!store.accounts[accountKey].configs || typeof store.accounts[accountKey].configs !== 'object') {
    store.accounts[accountKey].configs = {};
  }
  return store.accounts[accountKey];
}

function withConfigProfiles(cb) {
  resolveConfigAccountKey(function (accountKey) {
    chrome.storage.local.get([CONTEXT_KEY, CONFIG_KEY, CONFIG_PROFILES_KEY], function (r) {
      var store = normalizeProfileStore(r[CONFIG_PROFILES_KEY]);
      var account = profileAccount(store, accountKey);
      cb(accountKey, r || {}, store, account);
    });
  });
}

function readConfigProfile(provider, cb) {
  withConfigProfiles(function (accountKey, r, store, account) {
    var legacy = r[CONFIG_KEY] ? normalizeCfg(r[CONFIG_KEY]) : null;
    var changed = false;
    if (legacy && legacy.provider && !account.configs[legacy.provider]) {
      account.configs[legacy.provider] = legacy;
      changed = true;
    }
    if (legacy && !account.activeProvider) {
      account.activeProvider = legacy.provider;
      changed = true;
    }
    if (legacy && legacy.provider && !store.configs[legacy.provider]) {
      store.configs[legacy.provider] = legacy;
      changed = true;
    }
    if (legacy && !store.activeProvider) {
      store.activeProvider = legacy.provider;
      changed = true;
    }
    var targetProvider = provider || account.activeProvider || store.activeProvider || (legacy && legacy.provider) || DEFAULT_CFG.provider;
    var saved = !!(account.configs[targetProvider] || store.configs[targetProvider]);
    var cfg = account.configs[targetProvider] ? normalizeCfg(account.configs[targetProvider]) : null;
    if (!cfg && store.configs[targetProvider]) cfg = normalizeCfg(store.configs[targetProvider]);
    if (!cfg && legacy && (!provider || legacy.provider === targetProvider)) {
      cfg = legacy;
      saved = true;
    }
    if (!cfg) cfg = normalizeCfg({ provider: targetProvider });

    function finish() {
      cb({
        ok: true,
        accountKey: accountKey,
        saved: saved,
        activeProvider: targetProvider,
        context: r[CONTEXT_KEY] || null,
        config: cfg
      });
    }
    if (changed) {
      var o = {}; o[CONFIG_PROFILES_KEY] = store;
      chrome.storage.local.set(o, finish);
    } else {
      finish();
    }
  });
}

function saveConfigProfile(config, cb) {
  var cfg = normalizeCfg(config);
  withConfigProfiles(function (accountKey, r, store, account) {
    account.configs[cfg.provider] = cfg;
    account.activeProvider = cfg.provider;
    store.configs[cfg.provider] = cfg;
    store.activeAccount = accountKey;
    store.activeProvider = cfg.provider;
    var o = {};
    o[CONFIG_KEY] = cfg;
    o[CONFIG_PROFILES_KEY] = store;
    chrome.storage.local.set(o, function () {
      cb({ ok: true, accountKey: accountKey, provider: cfg.provider });
    });
  });
}

function setActiveConfigProvider(provider, cb) {
  provider = provider || DEFAULT_CFG.provider;
  withConfigProfiles(function (accountKey, r, store, account) {
    account.activeProvider = provider;
    store.activeAccount = accountKey;
    store.activeProvider = provider;
    var o = {}; o[CONFIG_PROFILES_KEY] = store;
    chrome.storage.local.set(o, function () {
      cb({ ok: true, accountKey: accountKey, provider: provider });
    });
  });
}

function signalForPayload(payload) {
  var jobId = payload && payload._jobId;
  return jobId && activeJobs[jobId] ? activeJobs[jobId].signal : null;
}

chrome.runtime.onInstalled.addListener(function () {
  chrome.contextMenus.removeAll(function () {
    chrome.contextMenus.create({
      id: 'sz-analyze-image',
      title: '少壮AI：用此图片生成提示词',
      contexts: ['image']
    });
  });
});

chrome.action.onClicked.addListener(function () {
  chrome.tabs.create({ url: chrome.runtime.getURL(LAB_PAGE) });
});

chrome.contextMenus.onClicked.addListener(function (info, tab) {
  if (info.menuItemId !== 'sz-analyze-image') return;
  var payload = {
    imageUrl: info.srcUrl || '',
    pageUrl: info.pageUrl || (tab && tab.url) || '',
    title: tab && tab.title || '',
    at: Date.now()
  };
  showInlineContextCard(tab && tab.id, payload);
});

function openContextWorkbench(payload) {
  var o = {}; o[CONTEXT_KEY] = payload;
  chrome.storage.local.set(o, function () {
    chrome.tabs.create({ url: chrome.runtime.getURL(LAB_PAGE) + '?source=context&auto=1' });
  });
}

function showInlineContextCard(tabId, payload) {
  if (tabId == null) {
    openContextWorkbench(payload);
    return;
  }
  try {
    chrome.scripting.executeScript({
      target: { tabId: tabId, allFrames: false },
      files: [CONTEXT_CARD_SCRIPT]
    }, function () {
      if (chrome.runtime.lastError) {
        console.warn('context card inject failed:', chrome.runtime.lastError.message);
        return;
      }
      chrome.tabs.sendMessage(tabId, { type: 'SZ_CONTEXT_IMAGE_ACTION', payload: payload }, function () {
        var _ = chrome.runtime.lastError;
      });
    });
  } catch (e) {
    console.warn('context card unavailable:', e && e.message ? e.message : e);
  }
}

function endpoint(baseURL, suffix) {
  var b = (baseURL || DEFAULT_CFG.visionBaseUrl).replace(/\/+$/, '');
  if (/\/chat\/completions$/.test(b)) return b;
  return b + suffix;
}

function subjectReplacementTextRule() {
  return [
    '主体替换最高优先级：最终生图的商品主体必须以用户上传的产品主体图为准。',
    '参考图、竞品图、链接清单、历史结果和模型生成的旧提示词只能提供风格、构图、光影、场景、版式、字体层级和文案方向；其中出现的旧商品、旧包装、旧品牌、旧 logo、旧 SKU、旧道具或旧人物手持物都不是最终主体。',
    '如果链接清单或参考图描述的商品与产品主体图冲突，必须保留链接定位/卖点/人群/场景，把画面中的主体改写成产品主体图里的目标商品。',
    '中文提示词必须明确写出：以产品主体图作为唯一目标商品主体，参考图主体被替换。'
  ].join('\n');
}

function textJsonPrompt(link) {
  return '你是资深天猫淘宝主图创意总监。根据链接清单 JSON，为这条链接生成电商主图提示词方案。\n' +
    subjectReplacementTextRule() + '\n' +
    '要求：1) 不照抄任何竞品品牌、商标、包装版式；2) 要服务链接定位和转化，不做泛泛的艺术图；3) 只输出中文提示词；4) 链接信息只作为定位、卖点、场景和文案方向，真实商品外观以后续产品主体图为准；5) 给出可直接用于生图模型的负面提示词。\n' +
    '只输出 JSON：{"主图方向":"","画面布局":"","中文提示词":"","负面提示词":"","主图文案":"","4方向":["主图转化版","场景种草版","视觉锤版","竞品差异化版"]}。\n' +
    '链接清单 JSON：' + JSON.stringify(link);
}

function analyzeImagePrompt(linkHint) {
  return '你是电商图片提示词分析器。分析输入图片，提取适合电商生图复用的视觉提示词，但禁止复刻品牌、商标、包装文字、人物肖像身份。\n' +
    subjectReplacementTextRule() + '\n' +
    '请重点识别：主体、品类、构图、镜头、光线、色彩、场景、材质、背景、文案区域、风格、可借鉴点、必须避让点。\n' +
    '注意：本次输入图片如果是参考图/竞品图，输出提示词必须把它的商品主体写成“待替换的参考主体”，不能把参考图商品当最终商品；最终商品主体以后续上传的产品主体图为准。\n' +
    '如果有链接定位，请把视觉表达向链接定位靠拢。链接定位：' + (linkHint || '无') + '\n' +
    '只输出 JSON：{"主体":"","品类":"","构图":"","镜头":"","光线":"","色彩":"","场景":"","材质":"","背景":"","风格":"","可借鉴点":"","避让点":"","中文提示词":"","负面提示词":""}。';
}

function detailPageJsonPrompt(payload, imageNote) {
  payload = payload || {};
  var maxCount = payload.mode === 'reference' ? 10 : 16;
  var count = Math.max(5, Math.min(maxCount, parseInt(payload.screenCount, 10) || 10));
  var modeText = payload.mode === 'link' ? '链接规划 + 产品主体图' : '参考图生成详情';
  return '你是资深淘宝/天猫电商详情页策划和生图提示词导演。请根据输入信息生成详情页分屏提示词。\n' +
    '任务模式：' + modeText + '。\n' +
    '核心要求：\n' +
    '1) 默认规则：详情页默认 10 屏；如果用户在生成选项里修改屏数，则以用户选项优先。本次必须严格输出 ' + count + ' 屏，屏幕编号从 1 到 ' + count + '，不得多屏或少屏；输出的是详情页/长图的分屏规划，不是单张主图。\n' +
    '2) 必须先从参考图中提取并命名统一视觉风格，包括整体风格、色彩、材质、构图节奏、留白、版式、字体风格、标题/副标题/说明文字层级；必须明确写出“风格名称”。\n' +
    '3) 必须严格参考图的风格样式、字体样式和字号大小。每一屏都要指定同一套字体样式与字号规范：大标题字号、副标题字号、说明文字字号、注释/参数字号；每一屏指定的字体大小与字号必须一致，无法精确识别时按参考图视觉比例给出近似 px 值。\n' +
    '4) 每一屏都必须沿用同一视觉风格、同一字体样式、同一字号层级、同一排版秩序和同一画面质感，确保生成的是一套有上下文关系、风格统一、排版连贯的详情页。\n' +
    '5) 参考图主要作为风格、字体、字号、版式、画面节奏和详情页叙事依据；不得复刻竞品品牌、logo、包装文字、人物身份。商品身份、包装结构、颜色、材质和关键细节必须以产品主体图为准。\n' +
    '5.1) 所有分屏提示词都必须把参考图/竞品图里的旧主体替换成产品主体图里的目标商品；链接定位和详情页文案只决定卖点顺序、场景和文案方向，不能覆盖产品主体图的商品身份。\n' +
    '6) 产品主体图是执行详情页生图的硬门槛和最终商品身份依据；没有主体图不得生成详情页。正视图、侧视图、背视图分别校准包装正面、厚度结构、背面信息、开盒或反面角度；如有多角度主体图，每一屏要说明使用哪个角度。\n' +
    '7) 如果提供人物模特三视图，只有在痛点场景、使用步骤、适配人群、真实场景、口碑信任等适合人物入镜的屏幕中自然引用，用于尺度、动作、情绪和场景辅助；模特不能替代、遮挡、改写商品主体。没有模特图时仍可仅用商品主体图生成详情页。\n' +
    '8) 链接清单是转化策略依据，要优先使用“详情页定位”和“详情页文案”；同时把链接定位、核心场景、目标人群、主推关键词、差异化壁垒融入详情页顺序。\n' +
    '9) 每一屏都要有画面方向、文案方向、字体样式、字号规范、主体图使用、模特使用和可直接用于生图的提示词；生图提示词必须包含屏幕编号、统一风格名、参考图字体/字号规范、主体图或模特图引用方式、画面内容、文案区域与排版位置。\n' +
    '10) 画面可有文案区域，但不要生成难以辨认的小字；提示词要利于后续逐屏生图。\n' +
    (imageNote ? ('图片输入说明：' + imageNote + '\n') : '') +
    '输出规格：平台=' + (payload.platform || '淘宝') + '；页面类型=' + (payload.pageType || '详情页') + '；比例=' + (payload.ratio || '3:4 纵向') + '；分辨率=' + (payload.resolution || '2K') + '；语言=' + (payload.language || '中文') + '；生成方式=' + (payload.generateStyle || '分段提示词') + '。\n' +
    '产品名称：' + (payload.productName || '') + '\n' +
    '产品特性：' + (payload.productFeatures || '') + '\n' +
    '核心卖点：' + (payload.sellingPoints || '') + '\n' +
    '详情页定位：' + (payload.detailPositioning || '') + '\n' +
    '详情页文案：' + (payload.detailCopy || '') + '\n' +
    '链接清单 JSON：' + JSON.stringify(payload.link || {}) + '\n' +
    '已有主图中文提示词：' + (payload.currentMainPrompt || '') + '\n' +
    '人物模特设定：' + (payload.modelPrompt || '') + '\n' +
    '参考图分析 JSON：' + JSON.stringify(payload.analysis || {}) + '\n' +
    '只输出合法 JSON，不要 markdown。JSON 格式：{"详情页方向":"","产品名称":"","详情页规格":{"平台":"","页面类型":"","屏数":' + count + ',"比例":"","分辨率":"","语言":""},"统一视觉规范":{"风格名称":"","参考图风格提取":"","字体样式":"","字号规范":{"大标题":"","副标题":"","说明文字":"","注释文字":""},"排版规范":""},"中文详情提示词":"","负面提示词":"","屏幕规划":[{"屏幕":1,"名称":"","承接关系":"","参考图风格对齐":"","字体样式":"","字号规范":{"大标题":"","副标题":"","说明文字":"","注释文字":""},"主体图使用":"","模特使用":"","画面方向":"","文案方向":"","生图提示词":"","避让点":""}]}。';
}

function buildVisionMessages(image, linkHint) {
  return [
    { role: 'system', content: '你只输出合法 JSON，不输出 markdown。' },
    {
      role: 'user',
      content: [
        { type: 'text', text: analyzeImagePrompt(linkHint) },
        { type: 'image_url', image_url: { url: image } }
      ]
    }
  ];
}

function buildDetailMessages(cfg, payload) {
  payload = payload || {};
  var canUseImages = cfg && cfg.provider !== 'deepseek-v4';
  var content = [];
  var imageNote = canUseImages ? '' : '当前文本模型不接收图片，已仅根据链接清单、产品文字和已有提示词生成。';
  content.push({ type: 'text', text: detailPageJsonPrompt(payload, imageNote) });
  if (canUseImages && payload.referenceImage) {
    content.push({ type: 'text', text: '下面这张是参考图/竞品图，只借鉴详情页视觉节奏和画面结构，不复制主体品牌。' });
    content.push({ type: 'image_url', image_url: { url: payload.referenceImage } });
  }
  if (canUseImages && Array.isArray(payload.productImages)) {
    payload.productImages.slice(0, 3).forEach(function (img, idx) {
      var label = idx === 0 ? '产品正视图' : (idx === 1 ? '产品侧视图' : '产品背视图/结构图');
      content.push({ type: 'text', text: '下面这张是' + label + '，作为最终商品主体身份和结构依据。' });
      content.push({ type: 'image_url', image_url: { url: img } });
    });
  }
  if (canUseImages && Array.isArray(payload.modelImages) && payload.modelImages.length) {
    content.push({ type: 'text', text: '下面的人物模特三视图是可选辅助证据，只在适合人物入镜的详情屏中参考姿态、身形比例、使用动作和情绪氛围；不得遮挡或替代商品主体。' });
    payload.modelImages.slice(0, 3).forEach(function (img, idx) {
      var label = idx === 0 ? '模特正视图' : (idx === 1 ? '模特侧视图' : '模特背视图');
      content.push({ type: 'text', text: label + '，仅作为人物一致性和动作参考。' });
      content.push({ type: 'image_url', image_url: { url: img } });
    });
  }
  return [
    { role: 'system', content: '你只输出合法 JSON，不输出 markdown。' },
    { role: 'user', content: content }
  ];
}

function cleanJson(content) {
  if (!content) return null;
  if (typeof content === 'object') return content;
  try { return JSON.parse(content); } catch (e) {}
  var m = ('' + content).match(/\{[\s\S]*\}/);
  if (m) { try { return JSON.parse(m[0]); } catch (e2) {} }
  return null;
}

function chatJson(cfg, messages, model, temperature, timeoutMs) {
  return new Promise(function (resolve) {
    cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
    if (cfg.provider === 'nano-banana' || cfg.imageAdapter === 'nano-banana' || cfg.imageAdapter === 'gemini-image') {
      geminiJson(cfg, messages, model, timeoutMs).then(resolve);
      return;
    }
    if (!cfg.apiKey) { resolve({ ok: false, error: '未配置 API Key' }); return; }
    var url = endpoint(cfg.visionBaseUrl, '/chat/completions');
    var body = {
      model: model || cfg.visionModel || DEFAULT_CFG.visionModel,
      messages: messages,
      temperature: temperature == null ? 0.2 : temperature
    };
    if (!/^https:\/\/ark\.cn-beijing\.volces\.com/.test(url)) {
      body.response_format = { type: 'json_object' };
    }
    var ctrl = new AbortController();
    var waitMs = timeoutMs || 180000;
    var to = setTimeout(function () { try { ctrl.abort(); } catch (e) {} }, waitMs);
    fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + cfg.apiKey },
      body: JSON.stringify(body),
      signal: ctrl.signal
    }).then(function (r) {
      return r.text().then(function (txt) { return { status: r.status, txt: txt }; });
    }).then(function (resp) {
      clearTimeout(to);
      if (resp.status < 200 || resp.status >= 300) {
        resolve({ ok: false, error: 'HTTP ' + resp.status + ': ' + (resp.txt || '').slice(0, 260) });
        return;
      }
      var data; try { data = JSON.parse(resp.txt); } catch (e) { resolve({ ok: false, error: '模型返回不是 JSON' }); return; }
      var content = data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
      var obj = cleanJson(content);
      if (!obj) { resolve({ ok: false, error: '解析模型 JSON 失败' }); return; }
      resolve({ ok: true, data: obj, raw: content });
    }).catch(function (e) {
      clearTimeout(to);
      resolve({ ok: false, error: (e && e.name === 'AbortError') ? ('请求超时（已等待 ' + Math.round(waitMs / 1000) + ' 秒）') : ('网络错误：' + ((e && e.message) || e)) });
    });
  });
}

function geminiPartsFromMessages(messages) {
  var parts = [];
  (messages || []).forEach(function (msg) {
    if (!msg || msg.role === 'system') return;
    if (typeof msg.content === 'string') {
      parts.push({ text: msg.content });
    } else if (Array.isArray(msg.content)) {
      msg.content.forEach(function (it) {
        if (!it) return;
        if (it.type === 'text') parts.push({ text: it.text || '' });
        if (it.type === 'image_url' && it.image_url && it.image_url.url) parts.push(imagePartForGemini(it.image_url.url));
      });
    }
  });
  parts.push({ text: '\n只输出合法 JSON，不要 markdown。' });
  return parts;
}

function geminiJson(cfg, messages, model, timeoutMs) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  if (!cfg.apiKey) return Promise.resolve({ ok: false, error: '未配置 API Key' });
  var oldModel = cfg.imageModel;
  cfg.imageModel = model || cfg.visionModel || cfg.textModel || cfg.imageModel || 'gemini-2.5-flash-image-preview';
  var body = { contents: [{ role: 'user', parts: geminiPartsFromMessages(messages) }] };
  var url = geminiUrl(cfg);
  cfg.imageModel = oldModel;
  return fetchJson(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }, timeoutMs || 120000)
    .then(function (res) {
      if (!res.ok) return annotateGeminiError(cfg, res);
      var text = '';
      try {
        var parts = (((res.data || {}).candidates || [])[0] || {}).content.parts || [];
        parts.forEach(function (p) { if (p.text) text += p.text; });
      } catch (e) {}
      var obj = cleanJson(text);
      return obj ? { ok: true, data: obj, raw: text || res.data } : { ok: false, error: '解析 Gemini JSON 失败', raw: res.data };
    });
}

function analyzeImage(cfg, payload) {
  if (!payload || !payload.image) return Promise.resolve({ ok: false, error: '缺少图片' });
  if (cfg && cfg.provider === 'deepseek-v4') return Promise.resolve({ ok: false, error: 'DeepSeek V4 当前作为文本提词模型接入，不支持图片反推。请切换到千问/豆包/智谱/OpenAI/Nano Banana 等视觉模型。' });
  return chatJson(cfg, buildVisionMessages(payload.image, payload.linkHint || ''), (cfg && cfg.visionModel) || DEFAULT_CFG.visionModel, 0.1, 300000);
}

function buildLinkPrompt(cfg, payload) {
  var link = payload && payload.link;
  if (!link || typeof link !== 'object') return Promise.resolve({ ok: false, error: '链接清单 JSON 无效' });
  var messages = [
    { role: 'system', content: '你只输出合法 JSON，不输出 markdown。' },
    { role: 'user', content: textJsonPrompt(link) }
  ];
  return chatJson(cfg, messages, (cfg && (cfg.textModel || cfg.visionModel)) || DEFAULT_CFG.textModel, 0.35, 240000);
}

function buildDetailPrompt(cfg, payload) {
  payload = payload || {};
  var hasProductImages = Array.isArray(payload.productImages) && payload.productImages.length;
  if (!hasProductImages) {
    return Promise.resolve({ ok: false, error: '请先上传至少 1 张商品主体图，详情页生成必须以主体图为商品依据' });
  }
  return chatJson(cfg, buildDetailMessages(cfg || {}, payload), (cfg && (cfg.visionModel || cfg.textModel)) || DEFAULT_CFG.visionModel, 0.25, 300000);
}

function claritySuffix(clarity) {
  clarity = String(clarity || '').toUpperCase();
  if (clarity === '4K') return ' ultra high resolution 4K commercial output, crisp product edges, readable design hierarchy, premium detail retention';
  if (clarity === '2K') return ' high resolution 2K commercial output, clean product details, sharp edges, premium lighting';
  if (clarity === '1K') return ' clean 1K commercial output, balanced lighting, clear product subject';
  if (clarity === 'COMMERCIAL') return ' commercial product photography, high clarity, clean details, sharp edges, premium studio lighting';
  if (clarity === 'HIGH') return ' high definition, crisp details, clean edges, realistic texture';
  return ' clean product image, balanced lighting';
}

function normalizeSize(size, sep) {
  var s = (size || '1024*1024').replace(/\s+/g, '');
  var m = s.match(/^(\d+)[x*](\d+)$/i);
  if (!m) return sep === 'x' ? '1024x1024' : '1024*1024';
  return m[1] + (sep || '*') + m[2];
}

function normalizeVolcSeedreamSize(size) {
  var s = (size || '2048x2048').replace(/\s+/g, '');
  if (/^(2K|3K)$/i.test(s)) return s.toUpperCase();
  var m = s.match(/^(\d+)[x*](\d+)$/i);
  var w = m ? parseInt(m[1], 10) : 2048;
  var h = m ? parseInt(m[2], 10) : 2048;
  var presets = [
    [2048, 2048], [2304, 1728], [1728, 2304], [2848, 1600],
    [1600, 2848], [2496, 1664], [1664, 2496], [3136, 1344],
    [3072, 3072], [3456, 2592], [2592, 3456], [4096, 2304],
    [2304, 4096], [2496, 3744], [3744, 2496], [4704, 2016]
  ];
  var ratio = w / h;
  var best = presets.slice().sort(function (a, b) {
    var da = Math.abs(Math.log(ratio / (a[0] / a[1])));
    var db = Math.abs(Math.log(ratio / (b[0] / b[1])));
    if (Math.abs(da - db) > 0.0001) return da - db;
    return (a[0] * a[1]) - (b[0] * b[1]);
  })[0];
  return best[0] + 'x' + best[1];
}

function isDataUrl(s) { return /^data:image\/[a-z0-9.+-]+;base64,/i.test('' + (s || '')); }
function dataUrlInfo(dataUrl) {
  var m = /^data:(image\/[a-z0-9.+-]+);base64,([\s\S]+)$/i.exec(dataUrl || '');
  return m ? { mime: m[1], base64: m[2] } : null;
}
function blobFromDataUrl(dataUrl) {
  var info = dataUrlInfo(dataUrl);
  if (!info) return null;
  var bin = atob(info.base64);
  var bytes = new Uint8Array(bin.length);
  for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type: info.mime });
}
function imagePartForGemini(image) {
  var info = dataUrlInfo(image);
  if (info) return { inline_data: { mime_type: info.mime, data: info.base64 } };
  return { file_data: { file_uri: image } };
}
function imageToProviderValue(image) {
  if (!image) return '';
  return image;
}

function productImagesFromPayload(payload) {
  payload = payload || {};
  var imgs = [];
  if (Array.isArray(payload.productImages)) imgs = imgs.concat(payload.productImages);
  if (payload.productImage) imgs.unshift(payload.productImage);
  return Array.from(new Set(imgs.filter(Boolean)));
}

function productSubjectRequiredError() {
  return '请先上传至少 1 张产品主体图。所有生图必须以产品主体图作为最终商品身份，参考图/链接/模板只用于风格、构图和排版。';
}

function modelImagesFromPayload(payload) {
  payload = payload || {};
  return Array.from(new Set((Array.isArray(payload.modelImages) ? payload.modelImages : []).filter(Boolean)));
}

function inputImagesFromPayload(payload) {
  payload = payload || {};
  var imgs = productImagesFromPayload(payload);
  imgs = imgs.concat(modelImagesFromPayload(payload));
  if (payload.referenceImage) imgs.push(payload.referenceImage);
  return Array.from(new Set(imgs.filter(Boolean)));
}

function generationPayload(cfg, payload) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  payload = payload || {};
  var prompt = (payload.prompt || '').trim();
  if (payload.negativePrompt) prompt += '\nNegative prompt: ' + payload.negativePrompt;
  prompt += claritySuffix(payload.clarity || 'standard');
  var content = [];
  productImagesFromPayload(payload).forEach(function (img) { content.push({ image: img }); });
  modelImagesFromPayload(payload).forEach(function (img) { content.push({ image: img }); });
  if (payload.referenceImage) content.push({ image: payload.referenceImage });
  content.push({ text: prompt });
  return {
    model: cfg.imageModel || DEFAULT_CFG.imageModel,
    input: { messages: [{ role: 'user', content: content }] },
    parameters: {
      size: payload.size || '1024*1024',
      n: Math.max(1, Math.min(4, parseInt(payload.count, 10) || 1)),
      watermark: payload.watermark === true || payload.watermark === 'true',
      prompt_extend: true
    }
  };
}

function taskUrlFrom(endpointUrl, taskId) {
  try {
    var u = new URL(endpointUrl || DEFAULT_CFG.imageEndpoint);
    return u.origin + '/api/v1/tasks/' + encodeURIComponent(taskId);
  } catch (e) {
    return 'https://dashscope.aliyuncs.com/api/v1/tasks/' + encodeURIComponent(taskId);
  }
}

function deepFindImages(value, out) {
  out = out || [];
  if (!value) return out;
  if (typeof value === 'string') {
    if (/^https?:\/\//.test(value) && /\.(png|jpe?g|webp|gif)(\?|$)/i.test(value)) out.push(value);
    return out;
  }
  if (Array.isArray(value)) {
    value.forEach(function (v) { deepFindImages(v, out); });
    return out;
  }
  if (typeof value === 'object') {
    ['url', 'image', 'image_url', 'orig_url', 'actual_image_url'].forEach(function (k) {
      if (typeof value[k] === 'string' && /^https?:\/\//.test(value[k])) out.push(value[k]);
    });
    Object.keys(value).forEach(function (k) { deepFindImages(value[k], out); });
  }
  return Array.from(new Set(out));
}

function deepFindBase64Images(value, out) {
  out = out || [];
  if (!value) return out;
  if (Array.isArray(value)) {
    value.forEach(function (v) { deepFindBase64Images(v, out); });
    return out;
  }
  if (typeof value === 'object') {
    var mime = value.mime_type || value.mimeType || value.media_type || 'image/png';
    var data = value.b64_json || value.base64 || value.data;
    if (typeof data === 'string' && data.length > 200 && /^[A-Za-z0-9+/=\s]+$/.test(data)) {
      out.push('data:' + mime + ';base64,' + data.replace(/\s+/g, ''));
    }
    var inlineData = value.inlineData || value.inline_data;
    if (inlineData && inlineData.data) {
      out.push('data:' + (inlineData.mimeType || inlineData.mime_type || 'image/png') + ';base64,' + inlineData.data);
    }
    Object.keys(value).forEach(function (k) { deepFindBase64Images(value[k], out); });
  }
  return Array.from(new Set(out));
}

function parseImageResponse(data) {
  var imgs = [];
  if (data && Array.isArray(data.data)) {
    data.data.forEach(function (it) {
      if (it && it.url) imgs.push(it.url);
      if (it && it.b64_json) imgs.push('data:image/png;base64,' + it.b64_json);
    });
  }
  imgs = imgs.concat(deepFindImages(data), deepFindBase64Images(data));
  return Array.from(new Set(imgs));
}

function fetchJson(url, opt, timeoutMs) {
  return new Promise(function (resolve) {
    var ctrl = new AbortController();
    var externalSignal = opt && opt.signal;
    var abortedByExternal = false;
    if (externalSignal) {
      if (externalSignal.aborted) {
        resolve({ ok: false, error: '请求已终止' });
        return;
      }
      externalSignal.addEventListener('abort', function () {
        abortedByExternal = true;
        try { ctrl.abort(); } catch (e) {}
      }, { once: true });
    }
    var to = setTimeout(function () { try { ctrl.abort(); } catch (e) {} }, timeoutMs || 120000);
    opt = opt || {};
    opt.signal = ctrl.signal;
    fetch(url, opt).then(function (r) {
      return r.text().then(function (txt) { return { status: r.status, txt: txt }; });
    }).then(function (resp) {
      clearTimeout(to);
      if (resp.status < 200 || resp.status >= 300) {
        resolve({ ok: false, error: 'HTTP ' + resp.status + ': ' + (resp.txt || '').slice(0, 420) });
        return;
      }
      var data; try { data = JSON.parse(resp.txt); } catch (e) { resolve({ ok: false, error: '返回非 JSON' }); return; }
      resolve({ ok: true, data: data });
    }).catch(function (e) {
      clearTimeout(to);
      resolve({ ok: false, error: (e && e.name === 'AbortError') ? (abortedByExternal ? '请求已终止' : '请求超时') : ('网络错误：' + ((e && e.message) || e)) });
    });
  });
}

function createDashScopeImageTask(cfg, payload) {
  return new Promise(function (resolve) {
    cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
    if (!cfg.apiKey) { resolve({ ok: false, error: '未配置 API Key' }); return; }
    if (!payload || !payload.prompt) { resolve({ ok: false, error: '缺少生图提示词' }); return; }
    var url = cfg.imageEndpoint || DEFAULT_CFG.imageEndpoint;
    var body = generationPayload(cfg, payload);
    var ctrl = new AbortController();
    var externalSignal = signalForPayload(payload);
    var abortedByExternal = false;
    if (externalSignal) {
      if (externalSignal.aborted) { resolve({ ok: false, error: '请求已终止' }); return; }
      externalSignal.addEventListener('abort', function () {
        abortedByExternal = true;
        try { ctrl.abort(); } catch (e) {}
      }, { once: true });
    }
    var to = setTimeout(function () { try { ctrl.abort(); } catch (e) {} }, 60000);
    fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + cfg.apiKey,
        'X-DashScope-Async': 'enable'
      },
      body: JSON.stringify(body),
      signal: ctrl.signal
    }).then(function (r) {
      return r.text().then(function (txt) { return { status: r.status, txt: txt }; });
    }).then(function (resp) {
      clearTimeout(to);
      if (resp.status < 200 || resp.status >= 300) {
        resolve({ ok: false, error: 'HTTP ' + resp.status + ': ' + (resp.txt || '').slice(0, 320) });
        return;
      }
      var data; try { data = JSON.parse(resp.txt); } catch (e) { resolve({ ok: false, error: '创建任务返回非 JSON' }); return; }
      var taskId = data && data.output && data.output.task_id;
      if (!taskId) {
        var imgs = deepFindImages(data);
        if (imgs.length) resolve({ ok: true, taskId: '', images: imgs, raw: data });
        else resolve({ ok: false, error: '未拿到 task_id', raw: data });
        return;
      }
      pollImageTask(cfg, url, taskId, 0, externalSignal).then(function (res) { resolve(res); });
    }).catch(function (e) {
      clearTimeout(to);
      resolve({ ok: false, error: (e && e.name === 'AbortError') ? (abortedByExternal ? '请求已终止' : '创建任务超时') : ('网络错误：' + ((e && e.message) || e)) });
    });
  });
}

function createOpenAIImage(cfg, payload) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  payload = payload || {};
  if (!cfg.apiKey) return Promise.resolve({ ok: false, error: '未配置 API Key' });
  var prompt = ((payload.prompt || '') + claritySuffix(payload.clarity || 'standard')).trim();
  if (payload.negativePrompt) prompt += '\nAvoid: ' + payload.negativePrompt;
  var productImages = productImagesFromPayload(payload);
  var hasInputImage = !!(payload.referenceImage || productImages.length);
  var base = (cfg.imageEndpoint || 'https://api.openai.com/v1/images/generations').replace(/\/+$/, '');
  var url = hasInputImage ? base.replace(/\/images\/generations$/, '/images/edits') : base;
  if (hasInputImage) {
    var fd = new FormData();
    fd.append('model', cfg.imageModel || 'gpt-image-2');
    fd.append('prompt', prompt);
    fd.append('size', normalizeSize(payload.size, 'x'));
    fd.append('n', '' + Math.max(1, Math.min(4, parseInt(payload.count, 10) || 1)));
    var appended = 0;
    productImages.map(function (img, idx) {
      return { image: img, name: 'product-subject-' + (idx + 1) };
    }).concat(modelImagesFromPayload(payload).map(function (img, idx) {
      return { image: img, name: 'model-reference-' + (idx + 1) };
    })).concat(payload.referenceImage ? [{ image: payload.referenceImage, name: 'style-reference' }] : []).forEach(function (entry) {
      var blob = isDataUrl(entry.image) ? blobFromDataUrl(entry.image) : null;
      if (blob) {
        fd.append(appended === 0 ? 'image' : 'image[]', blob, entry.name + '.png');
        appended++;
      }
    });
    if (!appended) {
      return Promise.resolve({ ok: false, error: 'OpenAI 编辑接口需要本地上传图片或可转成 Blob 的 data URL；网页 URL 请先右键导入。' });
    }
    return fetchJson(url, { method: 'POST', headers: { 'Authorization': 'Bearer ' + cfg.apiKey }, body: fd, signal: signalForPayload(payload) }, 180000)
      .then(function (res) { if (!res.ok) return res; var imgs = parseImageResponse(res.data); return imgs.length ? { ok: true, images: imgs, raw: res.data } : { ok: false, error: '未解析到图片', raw: res.data }; });
  }
  var body = { model: cfg.imageModel || 'gpt-image-2', prompt: prompt, size: normalizeSize(payload.size, 'x'), n: Math.max(1, Math.min(4, parseInt(payload.count, 10) || 1)) };
  return fetchJson(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + cfg.apiKey }, body: JSON.stringify(body), signal: signalForPayload(payload) }, 180000)
    .then(function (res) { if (!res.ok) return res; var imgs = parseImageResponse(res.data); return imgs.length ? { ok: true, images: imgs, raw: res.data } : { ok: false, error: '未解析到图片', raw: res.data }; });
}

function createMiniMaxImage(cfg, payload) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  payload = payload || {};
  if (!cfg.apiKey) return Promise.resolve({ ok: false, error: '未配置 API Key' });
  var prompt = ((payload.prompt || '') + claritySuffix(payload.clarity || 'standard')).trim();
  if (payload.negativePrompt) prompt += '\nNegative prompt: ' + payload.negativePrompt;
  var refs = inputImagesFromPayload(payload).slice(0, 4).map(function (img) {
    return { type: 'general', image_file: imageToProviderValue(img) };
  });
  var body = {
    model: cfg.imageModel || 'image-01',
    prompt: prompt,
    n: Math.max(1, Math.min(4, parseInt(payload.count, 10) || 1)),
    response_format: 'url',
    prompt_optimizer: true
  };
  if (refs.length) body.subject_reference = refs;
  return fetchJson(cfg.imageEndpoint || 'https://api.minimax.io/v1/image_generation', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + cfg.apiKey },
    body: JSON.stringify(body),
    signal: signalForPayload(payload)
  }, 180000).then(function (res) {
    if (!res.ok) return res;
    var imgs = parseImageResponse(res.data);
    return imgs.length ? { ok: true, images: imgs, raw: res.data } : { ok: false, error: '未解析到 MiniMax 图片', raw: res.data };
  });
}

function createZhipuImage(cfg, payload) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  payload = payload || {};
  if (!cfg.apiKey) return Promise.resolve({ ok: false, error: '未配置 API Key' });
  var prompt = ((payload.prompt || '') + claritySuffix(payload.clarity || 'standard')).trim();
  if (payload.negativePrompt) prompt += '\n负面约束：' + payload.negativePrompt;
  var body = {
    model: cfg.imageModel || 'cogview-4-250304',
    prompt: prompt,
    size: normalizeSize(payload.size, 'x'),
    n: Math.max(1, Math.min(4, parseInt(payload.count, 10) || 1))
  };
  return fetchJson(cfg.imageEndpoint || 'https://open.bigmodel.cn/api/paas/v4/images/generations', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + cfg.apiKey },
    body: JSON.stringify(body),
    signal: signalForPayload(payload)
  }, 180000).then(function (res) {
    if (!res.ok) return res;
    var imgs = parseImageResponse(res.data);
    return imgs.length ? { ok: true, images: imgs, raw: res.data } : { ok: false, error: '未解析到智谱图片', raw: res.data };
  });
}

function createVolcengineImage(cfg, payload) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  payload = payload || {};
  if (!cfg.apiKey) return Promise.resolve({ ok: false, error: '未配置 API Key' });
  var prompt = ((payload.prompt || '') + claritySuffix(payload.clarity || 'standard')).trim();
  if (payload.negativePrompt) prompt += '\nNegative prompt: ' + payload.negativePrompt;
  var body = {
    model: cfg.imageModel || VOLC_SEEDREAM_DEFAULT,
    prompt: prompt,
    size: normalizeVolcSeedreamSize(payload.size),
    n: Math.max(1, Math.min(4, parseInt(payload.count, 10) || 1)),
    response_format: 'url'
  };
  var refs = inputImagesFromPayload(payload).map(imageToProviderValue);
  if (refs.length === 1) body.image = refs[0];
  else if (refs.length > 1) body.image = refs;
  return fetchJson(cfg.imageEndpoint || 'https://ark.cn-beijing.volces.com/api/v3/images/generations', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + cfg.apiKey },
    body: JSON.stringify(body),
    signal: signalForPayload(payload)
  }, 180000).then(function (res) {
    if (!res.ok) {
      if (/InvalidEndpointOrModel\.NotFound|does not exist|not have access/i.test(res.error || '')) {
        res.error += '\n火山/豆包生图模型未开通或模型名不对：请在火山方舟控制台复制已开通的 Seedream 模型 ID 或推理接入点 ID，填到“生图模型”输入框。';
      }
      if (/parameter `?size`?|image size must be at least|InvalidParameter/i.test(res.error || '')) {
        res.error += '\nSeedream 5.0-lite 需要 2K/3K 尺寸，本插件已将小尺寸自动映射到同构图比例的 2K 尺寸；请重新点击生图。';
      }
      return res;
    }
    var imgs = parseImageResponse(res.data);
    return imgs.length ? { ok: true, images: imgs, raw: res.data } : { ok: false, error: '未解析到火山/豆包图片', raw: res.data };
  });
}

function geminiUrl(cfg) {
  var model = cfg.imageModel || 'gemini-2.5-flash-image-preview';
  var ep = cfg.imageEndpoint || 'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent';
  ep = ep.replace('{model}', encodeURIComponent(model));
  return ep + (ep.indexOf('?') >= 0 ? '&' : '?') + 'key=' + encodeURIComponent(cfg.apiKey);
}

function annotateGeminiError(cfg, res) {
  if (!res || res.ok) return res;
  var error = res.error || '';
  var endpointUrl = (cfg && cfg.imageEndpoint) || '';
  if (/No available Gemini accounts|no available accounts/i.test(error)) {
    error += '\n当前请求已进入 Gemini 通道，但中转网关没有可用 Gemini 账号池。';
    if (/sub\.shaozhuangai\.com/i.test(endpointUrl)) {
      error += '\n你现在填的是少壮中转地址，不是 Google 官方 Gemini 地址；要直连 Gemini，请把 Base URL 改为 https://generativelanguage.googleapis.com/v1beta，把生图 Endpoint 改为 https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent，并填写 Google AI Studio API Key。';
    }
  }
  if (/API key not valid|INVALID_ARGUMENT|PERMISSION_DENIED/i.test(error) && /generativelanguage\.googleapis\.com/i.test(endpointUrl)) {
    error += '\n请确认这是 Google AI Studio 的 Gemini API Key，并且对应模型已在当前账号/地区可用。';
  }
  return Object.assign({}, res, { error: error });
}

function createGeminiImage(cfg, payload) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  payload = payload || {};
  if (!cfg.apiKey) return Promise.resolve({ ok: false, error: '未配置 API Key' });
  var prompt = ((payload.prompt || '') + claritySuffix(payload.clarity || 'standard')).trim();
  if (payload.negativePrompt) prompt += '\nAvoid: ' + payload.negativePrompt;
  var parts = [{ text: prompt }];
  inputImagesFromPayload(payload).forEach(function (img) { parts.push(imagePartForGemini(img)); });
  var body = { contents: [{ role: 'user', parts: parts }] };
  return fetchJson(geminiUrl(cfg), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: signalForPayload(payload) }, 180000)
    .then(function (res) {
      if (!res.ok) return annotateGeminiError(cfg, res);
      var imgs = parseImageResponse(res.data);
      return imgs.length ? { ok: true, images: imgs, raw: res.data } : { ok: false, error: '未解析到 Nano Banana/Gemini 图片', raw: res.data };
    });
}

function createGenericJsonImage(cfg, payload) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  payload = payload || {};
  if (!cfg.apiKey) return Promise.resolve({ ok: false, error: '未配置 API Key' });
  var body = {
    model: cfg.imageModel,
    prompt: payload.prompt,
    negative_prompt: payload.negativePrompt || '',
    size: normalizeSize(payload.size, 'x'),
    n: Math.max(1, Math.min(4, parseInt(payload.count, 10) || 1)),
    reference_image: payload.referenceImage || '',
    product_image: productImagesFromPayload(payload)[0] || '',
    product_images: productImagesFromPayload(payload),
    model_images: modelImagesFromPayload(payload)
  };
  return fetchJson(cfg.imageEndpoint, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + cfg.apiKey }, body: JSON.stringify(body), signal: signalForPayload(payload) }, 180000)
    .then(function (res) {
      if (!res.ok) return res;
      var imgs = parseImageResponse(res.data);
      return imgs.length ? { ok: true, images: imgs, raw: res.data } : { ok: false, error: '未解析到图片 URL/base64', raw: res.data };
    });
}

function createImageTask(cfg, payload) {
  payload = payload || {};
  if (!productImagesFromPayload(payload).length) {
    return Promise.resolve({ ok: false, error: productSubjectRequiredError() });
  }
  var adapter = (cfg && cfg.imageAdapter) || 'dashscope-wan';
  if (adapter === 'none') return Promise.resolve({ ok: false, error: '当前服务商只支持文本提词，不支持生图。请选择生图适配器。' });
  if (adapter === 'openai-images') return createOpenAIImage(cfg, payload);
  if (adapter === 'minimax-image') return createMiniMaxImage(cfg, payload);
  if (adapter === 'zhipu-cogview') return createZhipuImage(cfg, payload);
  if (adapter === 'volcengine-image' || adapter === 'doubao-image') return createVolcengineImage(cfg, payload);
  if (adapter === 'gemini-image' || adapter === 'nano-banana') return createGeminiImage(cfg, payload);
  if (adapter === 'generic-json') return createGenericJsonImage(cfg, payload);
  return createDashScopeImageTask(cfg, payload);
}

function pollImageTask(cfg, endpointUrl, taskId, round, signal) {
  return new Promise(function (resolve) {
    if (signal && signal.aborted) { resolve({ ok: false, error: '请求已终止', taskId: taskId }); return; }
    if (round > 90) { resolve({ ok: false, error: '生图任务超时', taskId: taskId }); return; }
    setTimeout(function () {
      if (signal && signal.aborted) { resolve({ ok: false, error: '请求已终止', taskId: taskId }); return; }
      fetch(taskUrlFrom(endpointUrl, taskId), {
        method: 'GET',
        headers: { 'Authorization': 'Bearer ' + cfg.apiKey },
        signal: signal || undefined
      }).then(function (r) {
        return r.text().then(function (txt) { return { status: r.status, txt: txt }; });
      }).then(function (resp) {
        if (resp.status < 200 || resp.status >= 300) {
          resolve({ ok: false, error: '轮询失败 HTTP ' + resp.status + ': ' + (resp.txt || '').slice(0, 240), taskId: taskId });
          return;
        }
        var data; try { data = JSON.parse(resp.txt); } catch (e) { resolve({ ok: false, error: '轮询返回非 JSON', taskId: taskId }); return; }
        var status = data && data.output && data.output.task_status;
        if (status === 'SUCCEEDED') {
          resolve({ ok: true, taskId: taskId, images: deepFindImages(data), raw: data });
        } else if (status === 'FAILED' || status === 'CANCELED' || status === 'UNKNOWN') {
          resolve({ ok: false, error: '任务失败：' + status, taskId: taskId, raw: data });
        } else {
          pollImageTask(cfg, endpointUrl, taskId, round + 1, signal).then(function (r) { resolve(r); });
        }
      }).catch(function (e) {
        resolve({ ok: false, error: (e && e.name === 'AbortError') ? '请求已终止' : ('轮询网络错误：' + ((e && e.message) || e)), taskId: taskId });
      });
    }, round < 3 ? 1800 : 3000);
  });
}

function arrayBufferToDataUrl(buffer, contentType) {
  var bytes = new Uint8Array(buffer);
  var chunk = 0x8000;
  var parts = [];
  for (var i = 0; i < bytes.length; i += chunk) {
    parts.push(String.fromCharCode.apply(null, bytes.subarray(i, i + chunk)));
  }
  return 'data:' + (contentType || 'image/jpeg') + ';base64,' + btoa(parts.join(''));
}

function fetchAsDataUrl(url) {
  return new Promise(function (resolve) {
    fetch(url).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      var type = r.headers.get('content-type') || 'image/jpeg';
      return r.arrayBuffer().then(function (buf) { return { buf: buf, type: type }; });
    }).then(function (x) {
      resolve({ ok: true, dataUrl: arrayBufferToDataUrl(x.buf, x.type) });
    }).catch(function (e) {
      resolve({ ok: false, error: ((e && e.message) || e) });
    });
  });
}

function sanitizeDownloadFilename(filename) {
  return String(filename || '')
    .replace(/[\\:*?"<>|\u0000-\u001f]/g, '')
    .replace(/\/+/g, '/')
    .replace(/^\/+/, '')
    .slice(0, 180);
}

function imageExtFromUrl(url) {
  var text = String(url || '');
  var match = text.match(/\.(png|jpe?g|webp|gif)(?:[?#]|$)/i);
  if (match) return '.' + match[1].toLowerCase().replace('jpeg', 'jpg');
  if (/^data:image\/jpe?g/i.test(text)) return '.jpg';
  if (/^data:image\/webp/i.test(text)) return '.webp';
  if (/^data:image\/gif/i.test(text)) return '.gif';
  return '.png';
}

function normalizeDownloadItems(input) {
  var raw = Array.isArray(input) ? input : [];
  return raw.map(function (item, idx) {
    if (typeof item === 'string') item = { url: item };
    item = item || {};
    var url = item.url || '';
    if (!url) return null;
    var filename = sanitizeDownloadFilename(item.filename || '');
    if (!filename) {
      var seq = idx + 1;
      filename = '少壮AI主图实验室/image_' + Date.now() + '_' + (seq < 10 ? '0' : '') + seq + imageExtFromUrl(url);
    }
    return { url: url, filename: filename };
  }).filter(Boolean);
}

function downloadAll(items) {
  items = normalizeDownloadItems(items);
  if (!items.length) return Promise.resolve({ ok: false, error: '没有可下载图片' });
  items.forEach(function (item) {
    chrome.downloads.download({
      url: item.url,
      filename: item.filename,
      conflictAction: 'uniquify',
      saveAs: false
    });
  });
  return Promise.resolve({ ok: true, count: items.length });
}

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || !msg.type) return;
  if (msg.type === 'OPEN_CONTEXT_WORKBENCH') {
    openContextWorkbench(msg.payload || {});
    sendResponse({ ok: true });
    return;
  }
  if (msg.type === 'GET_CONTEXT') {
    readConfigProfile('', function (r) { sendResponse(r); });
    return true;
  }
  if (msg.type === 'GET_CONFIG_PROFILE') {
    readConfigProfile(msg.provider || '', function (r) { sendResponse(r); });
    return true;
  }
  if (msg.type === 'SAVE_CONFIG') {
    saveConfigProfile(msg.config, function (r) { sendResponse(r); });
    return true;
  }
  if (msg.type === 'SET_ACTIVE_PROVIDER') {
    setActiveConfigProvider(msg.provider || '', function (r) { sendResponse(r); });
    return true;
  }
  if (msg.type === 'FETCH_IMAGE') { fetchAsDataUrl(msg.url).then(sendResponse); return true; }
  if (msg.type === 'ANALYZE_IMAGE') { analyzeImage(msg.config, msg.payload).then(sendResponse); return true; }
  if (msg.type === 'BUILD_LINK_PROMPT') { buildLinkPrompt(msg.config, msg.payload).then(sendResponse); return true; }
  if (msg.type === 'BUILD_DETAIL_PROMPT') { buildDetailPrompt(msg.config, msg.payload).then(sendResponse); return true; }
  if (msg.type === 'GENERATE_IMAGE') {
    var jobId = msg.jobId || (msg.payload && msg.payload._jobId) || '';
    if (jobId) {
      activeJobs[jobId] = new AbortController();
      msg.payload = Object.assign({}, msg.payload || {}, { _jobId: jobId });
    }
    createImageTask(msg.config, msg.payload).then(function (res) {
      if (jobId) delete activeJobs[jobId];
      sendResponse(res);
    });
    return true;
  }
  if (msg.type === 'CANCEL_GENERATION') {
    if (msg.jobId && activeJobs[msg.jobId]) {
      try { activeJobs[msg.jobId].abort(); } catch (e) {}
      delete activeJobs[msg.jobId];
      sendResponse({ ok: true, cancelled: true });
    } else {
      sendResponse({ ok: true, cancelled: false });
    }
    return true;
  }
  if (msg.type === 'DOWNLOAD_ALL') { downloadAll(msg.items || msg.urls).then(sendResponse); return true; }
});
