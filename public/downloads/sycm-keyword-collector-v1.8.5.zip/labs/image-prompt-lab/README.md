# 少壮AI主图提示词实验室

独立 MV3 本地测试插件，用来先跑通：

- 上传一张图，反推中文提示词和 English Prompt。
- 粘贴一条链接清单 JSON，生成主图提示词。
- 参考图 + 产品主体图（三角度：正视图/侧视图/背视图）+ 链接定位，按尺寸、清晰度、数量生成图片。
- 右键网页竞品图，打开工作台并自动导入参考图。
- 链接清单批量生图按链接编号范围执行，例如 `L1` 到 `L1000`，不是模糊的“一次处理 N 条”。
- 同一条链接批量生成 4 个方向，并一键下载。
- 结果卡片支持复制图片、弹窗填写最高权重视觉引导词并重新生成、单张下载。
- 生图参数区支持终止当前生图/批量生图等待；API 配置、引导重生和分享卡设置都放在二级弹窗。
- 详情生成独立成页：支持参考图生成详情、链接规划结合产品主体图生成详情，默认 10 屏；如果用户修改生成选项，则以用户选项优先。参考图模式可扩展 5-10 屏，链接详情可扩展 5-16 屏；主体图至少 1 张，有模特图时按页面合适场景引用。
- 批量 SKU 独立成页：最多 20 张产品图，每张生成一个 SKU 任务；SKU 模板只统一风格和排版，不替代产品主体，属性文本按行逐条合入提示词。

## 本地加载

1. 打开 `chrome://extensions/`。
2. 开启「开发者模式」。
3. 点「加载已解压的扩展程序」。
4. 选择本目录：`labs/image-prompt-lab`。
5. 点扩展图标打开工作台。

## 接入的服务商预设

页面里的「服务商」会自动填入常用 endpoint / model / 生图适配器；API Key 只保存在本机 `chrome.storage.local`，不会写入源码。

已内置预设：

- 千问 / DashScope：`qwen-vl-plus` 提词，`wan2.7-image` 生图。
- DeepSeek V4：文本/链接清单提词；不做图片反推和生图。
- MiniMax：OpenAI-compatible 文本/视觉入口 + `image-01` 生图适配器。
- 智谱：GLM 视觉/文本 + CogView 生图适配器。
- 豆包 / 火山方舟：`doubao-seed-evolving` 提词 + Seedream 生图适配器，默认生图模型为 `doubao-seedream-5-0-260128`。
- ChatGPT / GPT Image 2：OpenAI chat/vision + `gpt-image-2` Images API。
- Nano Banana / Gemini：Gemini 图片模型 `generateContent` 适配器。
- 少壮 AI 网关 / OpenAI 兼容：默认走 `https://sub.shaozhuangai.com/v1`，文本模型 `chatGPT5.5`，生图模型 `image2`，也可手动切换为其它 OpenAI-compatible 模型。

默认按少壮 AI 网关配置：

- 视觉/提词：`https://sub.shaozhuangai.com/v1`
- 提词模型：`chatGPT5.5`
- 文本模型：`chatGPT5.5`
- 生图 Endpoint：`https://sub.shaozhuangai.com/v1/images/generations`
- 生图模型：`image2`

模型配置弹窗里保留可输入的备选清单：文本/视觉包含 `chatGPT5.5`、`gpt-5.5`、`gpt-5-mini`、`gpt-4o-mini`、`doubao-seed-evolving`、`deepseek-chat`、`deepseek-reasoner`、`deepseek-v4-flash`、`qwen-vl-plus`、`glm-4v-plus`、`MiniMax-M2.1`；生图包含 `image2`、`gpt-image-2`、`gpt-image-1.5`、`gpt-image-1`、`doubao-seedream-5-0-260128`、`cogview-4-250304`、`image-01`、`wan2.7-image`、`nanobanana-2`。

部分平台的模型 ID 会随账号区域、白名单或版本调整。预设只是起点，实际以控制台开通的模型名为准；页面里可以直接修改。

火山 Seedream 5.0-lite 需要 2K/3K 级别尺寸。实验室里保留了旧的 1024/768 测试尺寸，但通过火山生图时会自动映射为同构图比例的 2K 尺寸，例如 `768*1024` 会转为 `1728x2304`。

主体替换逻辑：如果同时提供「参考图 / 竞品图」和「产品主体图」，生图时会自动进入主体替换模式。产品主体图支持正视图、侧视图、背视图三张证据图，三张图共同定义最终商品主角；参考图只借用构图、镜头、光线、色彩、背景和商业版式，不再把参考图里的旧产品作为最终主体。

最高权重引导词不是简单追加到提示词最前面，而是作为提示词工程里的语义裁决层：当它和参考图、旧结果图、链接提词或历史提示词冲突时，引导词语义优先；落地方式要求模型把它转译为自然画面调整，例如替换容器、弱化冲突道具、重排空间、调整遮挡关系，而不是把引导词硬贴进画面。

## 合并到 1.8.4 的接点

跑通后建议并入主插件时复用这些概念：

- `AI_IMAGE_ANALYZE`
- `AI_LINK_VISUAL_PROMPT`
- `AI_IMAGE_GENERATE`
- `sycm_lm_last`
- `sycm_img_config`
- `sycm_img_jobs`
