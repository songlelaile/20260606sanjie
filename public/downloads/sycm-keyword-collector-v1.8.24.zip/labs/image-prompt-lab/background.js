'use strict';

var CONFIG_KEY = 'sz_image_prompt_lab_config';
var CONFIG_PROFILES_KEY = 'sz_image_prompt_lab_config_profiles_v2';
var CONTEXT_KEY = 'sz_image_prompt_lab_context';
var IS_BUNDLED_PLUGIN = !!(chrome.runtime.getManifest().action && chrome.runtime.getManifest().action.default_popup);
var LAB_PAGE = IS_BUNDLED_PLUGIN
  ? 'labs/image-prompt-lab/promptlab.html'
  : 'promptlab.html';
var CONTEXT_CARD_SCRIPT = IS_BUNDLED_PLUGIN
  ? 'labs/image-prompt-lab/context-card.js'
  : 'context-card.js';
var CONFIG_UI_LABEL = IS_BUNDLED_PLUGIN ? '插件启动界面的“统一 API 设置”' : '当前页的“独立版 API 配置”';
var VOLC_SEEDREAM_DEFAULT = 'doubao-seedream-5-0-260128';
var DEFAULT_CFG = {
  provider: 'openai-compatible',
  imageAdapter: 'generic-json',
  visionBaseUrl: 'https://sub.shaozhuangai.com/v1',
  visionModel: 'chatGPT5.5',
  textModel: 'chatGPT5.5',
  imageEndpoint: 'https://sub.shaozhuangai.com/v1/images/generations',
  imageModel: 'image2',
  apiKey: ''
};
var PROVIDER_DEFAULTS = {
  dashscope: {
    provider: 'dashscope',
    imageAdapter: 'dashscope-wan',
    visionBaseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
    visionModel: 'qwen-vl-plus',
    textModel: 'qwen-plus',
    imageEndpoint: 'https://dashscope.aliyuncs.com/api/v1/services/aigc/image-generation/generation',
    imageModel: 'wan2.7-image'
  },
  'deepseek-v4': {
    provider: 'deepseek-v4',
    imageAdapter: 'none',
    visionBaseUrl: 'https://api.deepseek.com',
    visionModel: '',
    textModel: 'deepseek-v4-flash',
    imageEndpoint: '',
    imageModel: ''
  },
  minimax: {
    provider: 'minimax',
    imageAdapter: 'none',
    visionBaseUrl: 'https://api.minimax.io/v1',
    visionModel: 'MiniMax-M2.1',
    textModel: 'MiniMax-M2.1',
    imageEndpoint: '',
    imageModel: ''
  },
  zhipu: {
    provider: 'zhipu',
    imageAdapter: 'zhipu-cogview',
    visionBaseUrl: 'https://open.bigmodel.cn/api/paas/v4',
    visionModel: 'glm-4v-plus',
    textModel: 'glm-4-plus',
    imageEndpoint: 'https://open.bigmodel.cn/api/paas/v4/images/generations',
    imageModel: 'cogview-4-250304'
  },
  doubao: {
    provider: 'doubao',
    imageAdapter: 'doubao-image',
    visionBaseUrl: 'https://ark.cn-beijing.volces.com/api/v3',
    visionModel: 'doubao-seed-evolving',
    textModel: 'doubao-seed-evolving',
    imageEndpoint: 'https://ark.cn-beijing.volces.com/api/v3/images/generations',
    imageModel: VOLC_SEEDREAM_DEFAULT
  },
  openai: {
    provider: 'openai',
    imageAdapter: 'openai-images',
    visionBaseUrl: 'https://api.openai.com/v1',
    visionModel: 'gpt-5-mini',
    textModel: 'gpt-5-mini',
    imageEndpoint: 'https://api.openai.com/v1/images/generations',
    imageModel: 'gpt-image-2'
  },
  'nano-banana': {
    provider: 'nano-banana',
    imageAdapter: 'nano-banana',
    visionBaseUrl: 'https://generativelanguage.googleapis.com/v1beta',
    visionModel: 'gemini-2.5-flash-image-preview',
    textModel: 'gemini-2.5-flash',
    imageEndpoint: 'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent',
    imageModel: 'gemini-2.5-flash-image-preview'
  },
  'openai-compatible': {
    provider: 'openai-compatible',
    imageAdapter: 'generic-json',
    visionBaseUrl: 'https://sub.shaozhuangai.com/v1',
    visionModel: 'chatGPT5.5',
    textModel: 'chatGPT5.5',
    imageEndpoint: 'https://sub.shaozhuangai.com/v1/images/generations',
    imageModel: 'image2'
  }
};
var HOSTED_TEXT_MODEL_MIGRATIONS = {
  'chatgpt5.6': 'chatGPT5.5',
  'gpt-5.5': 'chatGPT5.5'
};
var HOSTED_IMAGE_MODEL_MIGRATIONS = {
  'gpt-image-2': 'image2'
};
var PROVIDER_CATALOG = [
  { provider: 'openai-compatible', label: '少壮托管 / Auto Mode', capability: { text: true, vision: true, image: true } },
  { provider: 'openai', label: 'ChatGPT / GPT Image 2', capability: { text: true, vision: true, image: true } },
  { provider: 'nano-banana', label: 'Nano Banana / Gemini', capability: { text: true, vision: true, image: true } },
  { provider: 'doubao', label: '集梦 / 豆包 / 火山方舟', capability: { text: true, vision: true, image: true } },
  { provider: 'deepseek-v4', label: 'DeepSeek V4', capability: { text: true, vision: false, image: false } },
  { provider: 'minimax', label: 'MiniMax', capability: { text: true, vision: false, image: false } },
  { provider: 'zhipu', label: '智谱 GLM / CogView', capability: { text: true, vision: true, image: true } },
  { provider: 'dashscope', label: '千问 / DashScope', capability: { text: true, vision: true, image: true } }
];
var activeJobs = {};

function isShaozhuangHostedEndpoint(provider, url, fallbackUrl) {
  return !!(provider === 'openai-compatible' && /(^|\.)sub\.shaozhuangai\.com$/i.test((function () {
    try { return new URL(url || fallbackUrl).hostname; }
    catch (e) { return ''; }
  })()));
}

function isShaozhuangHostedConfig(cfg) {
  return !!(cfg && isShaozhuangHostedEndpoint(cfg.provider, cfg.visionBaseUrl, DEFAULT_CFG.visionBaseUrl));
}

function isShaozhuangHostedImageConfig(cfg) {
  return !!(cfg && isShaozhuangHostedEndpoint(cfg.provider, cfg.imageEndpoint, DEFAULT_CFG.imageEndpoint));
}

function normalizeHostedTextModel(cfg, model) {
  var value = String(model || '').trim();
  if (!value || !isShaozhuangHostedConfig(cfg)) return value;
  return HOSTED_TEXT_MODEL_MIGRATIONS[value.toLowerCase()] || value;
}

function normalizeHostedImageModel(cfg, model) {
  var value = String(model || '').trim();
  if (!value || !isShaozhuangHostedImageConfig(cfg)) return value;
  return HOSTED_IMAGE_MODEL_MIGRATIONS[value.toLowerCase()] || value;
}

function normalizeCfg(cfg) {
  var incoming = Object.assign({}, cfg || {});
  ['provider', 'imageAdapter', 'visionBaseUrl', 'visionModel', 'textModel', 'imageEndpoint', 'imageModel', 'apiKey'].forEach(function (field) {
    if (typeof incoming[field] === 'string') incoming[field] = incoming[field].trim();
  });
  var provider = incoming.provider || DEFAULT_CFG.provider;
  var preset = PROVIDER_DEFAULTS[provider] || {};
  cfg = Object.assign({}, DEFAULT_CFG, preset, incoming);
  if (cfg.provider === 'jimeng') cfg.provider = 'doubao';
  if (cfg.imageAdapter === 'jimeng-image') cfg.imageAdapter = 'doubao-image';
  if (cfg.imageAdapter === 'volcengine-image') cfg.imageAdapter = 'doubao-image';
  if (cfg.imageAdapter === 'gemini-image') cfg.imageAdapter = 'nano-banana';
  if (cfg.provider === 'minimax' && cfg.imageAdapter === 'minimax-image') cfg.imageAdapter = 'none';
  preset = PROVIDER_DEFAULTS[cfg.provider] || preset || {};
  ['imageAdapter', 'visionBaseUrl', 'visionModel', 'textModel', 'imageEndpoint', 'imageModel'].forEach(function (field) {
    if (!cfg[field] && preset[field]) cfg[field] = preset[field];
  });
  if (cfg.provider === 'openai-compatible') {
    if (!cfg.visionBaseUrl || cfg.visionBaseUrl === 'https://api.example.com/v1') cfg.visionBaseUrl = DEFAULT_CFG.visionBaseUrl;
    if (!cfg.imageEndpoint || cfg.imageEndpoint === 'https://api.example.com/v1/images/generations') cfg.imageEndpoint = DEFAULT_CFG.imageEndpoint;
    if (!cfg.visionModel || cfg.visionModel === 'vision-model' || cfg.visionModel === 'chat-model') cfg.visionModel = DEFAULT_CFG.visionModel;
    if (!cfg.textModel || cfg.textModel === 'chat-model' || cfg.textModel === 'vision-model') cfg.textModel = DEFAULT_CFG.textModel;
    if (!cfg.imageModel || cfg.imageModel === 'image-model') cfg.imageModel = DEFAULT_CFG.imageModel;
    cfg.visionModel = normalizeHostedTextModel(cfg, cfg.visionModel);
    cfg.textModel = normalizeHostedTextModel(cfg, cfg.textModel);
    cfg.imageModel = normalizeHostedImageModel(cfg, cfg.imageModel);
  }
  var isVolc = cfg.provider === 'doubao' || /^https:\/\/ark\.cn-beijing\.volces\.com/.test(cfg.visionBaseUrl || '');
  if (isVolc) {
    if (!cfg.visionModel || /^doubao-1\.5/.test(cfg.visionModel)) cfg.visionModel = 'doubao-seed-evolving';
    if (!cfg.textModel || /^doubao-1\.5/.test(cfg.textModel)) cfg.textModel = 'doubao-seed-evolving';
    if (!cfg.imageEndpoint) cfg.imageEndpoint = 'https://ark.cn-beijing.volces.com/api/v3/images/generations';
    if (!cfg.imageModel || /^doubao-seedream-3-0/i.test(cfg.imageModel)) cfg.imageModel = VOLC_SEEDREAM_DEFAULT;
  }
  return cfg;
}

function configAccountKeyFromAuth(auth) {
  var user = auth && auth.ok && auth.user ? auth.user : null;
  var raw = user && (user.id || user.userId || user.uid || user.email || user.username || user.name || user.mobile || user.phone);
  if (!raw) return 'local';
  return 'user:' + String(raw).replace(/[^\w@.+:-]/g, '_').slice(0, 120);
}

function resolveConfigAccountKey(cb) {
  // 账号可能在插件页面存活期内切换。每次配置读写都重新确认身份，
  // 不缓存上一个账号，避免 60 秒窗口内把 Key 写到错账号。
  if (typeof authCheck === 'function') {
    try {
      authCheck().then(function (auth) {
        cb(configAccountKeyFromAuth(auth));
      }).catch(function () {
        cb('local');
      });
      return;
    } catch (e) {}
  }
  cb('local');
}

function businessKnowledgeEngine() {
  return (typeof globalThis !== 'undefined' && globalThis.SZBusinessKnowledge) || null;
}

function readBusinessKnowledgeProfile(callback) {
  var engine = businessKnowledgeEngine();
  if (!engine) { callback({ ok: false, error: '业务知识库组件未加载' }); return; }
  resolveConfigAccountKey(function (accountKey) {
    chrome.storage.local.get([engine.KEY], function (result) {
      var error = chrome.runtime.lastError;
      if (error) { callback({ ok: false, error: error.message || '业务知识库读取失败' }); return; }
      var knowledge = engine.forAccount(result && result[engine.KEY], accountKey);
      callback({ ok: true, accountKey: accountKey, knowledge: knowledge, summary: engine.summary(knowledge) });
    });
  });
}

function saveBusinessKnowledgeProfile(value, callback) {
  var engine = businessKnowledgeEngine();
  if (!engine) { callback({ ok: false, error: '业务知识库组件未加载' }); return; }
  resolveConfigAccountKey(function (accountKey) {
    chrome.storage.local.get([engine.KEY], function (result) {
      var readError = chrome.runtime.lastError;
      if (readError) { callback({ ok: false, error: readError.message || '业务知识库读取失败' }); return; }
      var knowledge = engine.normalize(Object.assign({}, value || {}, { updatedAt: Number(value && value.updatedAt) || Date.now() }));
      var store = engine.setForAccount(result && result[engine.KEY], accountKey, knowledge);
      var patch = {}; patch[engine.KEY] = store;
      chrome.storage.local.set(patch, function () {
        var writeError = chrome.runtime.lastError;
        if (writeError) { callback({ ok: false, error: writeError.message || '业务知识库保存失败' }); return; }
        callback({ ok: true, accountKey: accountKey, knowledge: knowledge, summary: engine.summary(knowledge) });
      });
    });
  });
}

function clearBusinessKnowledgeProfile(callback) {
  var engine = businessKnowledgeEngine();
  if (!engine) { callback({ ok: false, error: '业务知识库组件未加载' }); return; }
  resolveConfigAccountKey(function (accountKey) {
    chrome.storage.local.get([engine.KEY], function (result) {
      var readError = chrome.runtime.lastError;
      if (readError) { callback({ ok: false, error: readError.message || '业务知识库读取失败' }); return; }
      var store = engine.normalizeStore(result && result[engine.KEY]);
      delete store.accounts[accountKey];
      var patch = {}; patch[engine.KEY] = store;
      chrome.storage.local.set(patch, function () {
        var writeError = chrome.runtime.lastError;
        if (writeError) { callback({ ok: false, error: writeError.message || '业务知识库清空失败' }); return; }
        callback({ ok: true, accountKey: accountKey, knowledge: engine.normalize({}), summary: engine.summary({}) });
      });
    });
  });
}

function attachBusinessKnowledge(payload, scope) {
  payload = Object.assign({}, payload || {});
  if (Object.prototype.hasOwnProperty.call(payload, 'businessKnowledgeContext')) return Promise.resolve(payload);
  return new Promise(function (resolve) {
    readBusinessKnowledgeProfile(function (result) {
      var engine = businessKnowledgeEngine();
      payload.businessKnowledgeContext = result && result.ok && engine
        ? engine.contextForScope(result.knowledge, scope, scope === 'detail' ? 6000 : 5000)
        : '';
      payload.businessKnowledgeMeta = result && result.ok ? result.summary : null;
      resolve(payload);
    });
  });
}

function normalizeProfileStore(raw) {
  var store = raw && typeof raw === 'object' ? raw : {};
  if (!store.accounts || typeof store.accounts !== 'object') store.accounts = {};
  if (!store.configs || typeof store.configs !== 'object') store.configs = {};
  if (!store.legacyConfigImports || typeof store.legacyConfigImports !== 'object') store.legacyConfigImports = {};
  store.version = 2;
  return store;
}

function profileAccount(store, accountKey) {
  if (!store.accounts[accountKey] || typeof store.accounts[accountKey] !== 'object') {
    store.accounts[accountKey] = { activeProvider: '', configs: {} };
  }
  if (!store.accounts[accountKey].configs || typeof store.accounts[accountKey].configs !== 'object') {
    store.accounts[accountKey].configs = {};
  }
  return store.accounts[accountKey];
}

function migrateStoredConfigMap(configs) {
  var changed = false;
  Object.keys(configs || {}).forEach(function (provider) {
    var raw = configs[provider];
    if (!raw || typeof raw !== 'object') return;
    var normalized = normalizeCfg(Object.assign({ provider: provider }, raw));
    if (JSON.stringify(normalized) !== JSON.stringify(raw)) {
      configs[provider] = normalized;
      changed = true;
    }
  });
  return changed;
}

function migrateSharedConfigMap(configs) {
  var changed = false;
  Object.keys(configs || {}).forEach(function (provider) {
    var raw = configs[provider];
    if (!raw || typeof raw !== 'object') return;
    var normalized = normalizeCfg(Object.assign({ provider: provider }, raw));
    // shared configs 只保留无密钥的端点/模型预设，绝不作为账号凭据回退。
    delete normalized.apiKey;
    if (JSON.stringify(normalized) !== JSON.stringify(raw)) {
      configs[provider] = normalized;
      changed = true;
    }
  });
  return changed;
}

function migrateAllStoredProfiles(store) {
  var changed = migrateSharedConfigMap(store && store.configs);
  Object.keys((store && store.accounts) || {}).forEach(function (accountKey) {
    var account = store.accounts[accountKey];
    if (account && migrateStoredConfigMap(account.configs)) changed = true;
  });
  return changed;
}

function configSignature(cfg) {
  var text = JSON.stringify(normalizeCfg(cfg || {}));
  var hash = 2166136261;
  for (var i = 0; i < text.length; i++) {
    hash ^= text.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return 'v1:' + (hash >>> 0).toString(16);
}

function matchingLegacyOwner(store, legacy) {
  if (!legacy) return '';
  var signature = configSignature(legacy);
  var savedOwner = store.legacyConfigImports[signature];
  if (savedOwner) return savedOwner;
  var matches = [];
  Object.keys(store.accounts || {}).forEach(function (accountKey) {
    var account = store.accounts[accountKey];
    var cfg = account && account.configs && account.configs[legacy.provider];
    if (cfg && configSignature(cfg) === signature) matches.push(accountKey);
  });
  if (store.activeAccount && matches.indexOf(store.activeAccount) >= 0) return store.activeAccount;
  return matches[0] || '';
}

function claimLegacyConfig(store, legacy, accountKey) {
  if (!legacy) return { owner: '', changed: false };
  var signature = configSignature(legacy);
  var owner = store.legacyConfigImports[signature] || matchingLegacyOwner(store, legacy);
  if (!owner) {
    // 旧版只有一份全局配置：优先归属旧 store 记录的活动账号，
    // 否则由首次读取它的当前账号认领。同一指纹之后不会再迁移给新账号。
    owner = store.activeAccount || accountKey;
  }
  var changed = store.legacyConfigImports[signature] !== owner;
  store.legacyConfigImports[signature] = owner;
  return { owner: owner, changed: changed };
}

function markLegacyOwner(store, cfg, accountKey) {
  if (!cfg) return;
  store.legacyConfigImports[configSignature(cfg)] = accountKey;
}

function configCatalog() {
  return PROVIDER_CATALOG.map(function (item) {
    var preset = normalizeCfg({ provider: item.provider });
    delete preset.apiKey;
    return {
      provider: item.provider,
      id: item.provider,
      label: item.label,
      capability: Object.assign({}, item.capability),
      capabilities: Object.assign({}, item.capability),
      preset: preset
    };
  });
}

function sameModelName(a, b) {
  return String(a || '').trim().toLowerCase() === String(b || '').trim().toLowerCase();
}

function replaceUnavailableHostedTextModel(cfg, failedModel, fallbackModel) {
  if (!cfg || typeof cfg !== 'object') return false;
  var scope = Object.assign({}, DEFAULT_CFG, cfg);
  if (!isShaozhuangHostedConfig(scope)) return false;
  var changed = false;
  ['visionModel', 'textModel'].forEach(function (field) {
    if (sameModelName(cfg[field], failedModel)) {
      cfg[field] = fallbackModel;
      changed = true;
    }
  });
  return changed;
}

function persistHostedTextModelFallback(requestCfg, failedModel, fallbackModel, cb) {
  withConfigProfiles(function (accountKey, _r, store, account) {
    if (requestCfg && requestCfg._accountKey && requestCfg._accountKey !== accountKey) { cb(false); return; }
    var provider = (requestCfg && requestCfg.provider) || DEFAULT_CFG.provider;
    var current = Object.assign({}, requestCfg || account.configs[provider] || {});
    delete current._accountKey;
    if (!replaceUnavailableHostedTextModel(current, failedModel, fallbackModel)) { cb(false); return; }

    // model_not_found 是当前账号组的运行时结果，只修复当前账号；其他账号可能已开通该模型。
    account.configs[provider] = current;
    account.activeProvider = provider;
    store.activeAccount = accountKey;
    store.activeProvider = provider;
    migrateAllStoredProfiles(store);

    var out = {}; out[CONFIG_PROFILES_KEY] = store;
    // legacy 始终写入这次已成功重试的当前配置，避免复活旧账号的端点或凭据。
    markLegacyOwner(store, current, accountKey);
    out[CONFIG_KEY] = current;
    chrome.storage.local.set(out, function () { cb(true); });
  });
}

function withConfigProfiles(cb) {
  resolveConfigAccountKey(function (accountKey) {
    chrome.storage.local.get([CONTEXT_KEY, CONFIG_KEY, CONFIG_PROFILES_KEY], function (r) {
      var store = normalizeProfileStore(r[CONFIG_PROFILES_KEY]);
      var account = profileAccount(store, accountKey);
      cb(accountKey, r || {}, store, account);
    });
  });
}

function readConfigProfile(provider, cb) {
  withConfigProfiles(function (accountKey, r, store, account) {
    var legacyRaw = r[CONFIG_KEY] && typeof r[CONFIG_KEY] === 'object' ? r[CONFIG_KEY] : null;
    var legacy = legacyRaw ? normalizeCfg(legacyRaw) : null;
    var legacyNormalized = !!(legacyRaw && JSON.stringify(legacy) !== JSON.stringify(legacyRaw));
    var legacyClaim = claimLegacyConfig(store, legacy, accountKey);
    var profileStoreMigrated = migrateAllStoredProfiles(store);
    var changed = profileStoreMigrated || legacyClaim.changed;
    var migrated = profileStoreMigrated || legacyNormalized;
    var legacyBelongsToAccount = !!(legacy && legacyClaim.owner === accountKey);
    if (legacyBelongsToAccount && legacy.provider && !account.configs[legacy.provider]) {
      account.configs[legacy.provider] = legacy;
      changed = true;
      migrated = true;
    }
    if (legacyBelongsToAccount && !account.activeProvider) {
      account.activeProvider = legacy.provider;
      changed = true;
    }
    var targetProvider = provider || account.activeProvider || (legacyBelongsToAccount && legacy.provider) || DEFAULT_CFG.provider;
    var accountRaw = account.configs[targetProvider];
    var saved = !!accountRaw;
    var cfg = accountRaw ? normalizeCfg(Object.assign({ provider: targetProvider }, accountRaw)) : null;
    if (accountRaw && JSON.stringify(cfg) !== JSON.stringify(accountRaw)) {
      account.configs[targetProvider] = cfg;
      changed = true;
      migrated = true;
    }
    if (!cfg && legacyBelongsToAccount && legacy && (!provider || legacy.provider === targetProvider)) {
      cfg = legacy;
      saved = true;
    }
    if (!cfg) cfg = normalizeCfg({ provider: targetProvider });

    function finish() {
      cb({
        ok: true,
        accountKey: accountKey,
        saved: saved,
        migrated: migrated,
        activeProvider: targetProvider,
        context: r[CONTEXT_KEY] || null,
        config: cfg
      });
    }
    if (changed || migrated) {
      var o = {}; o[CONFIG_PROFILES_KEY] = store;
      // legacy 只在自身需要模型别名迁移时回写；不再用其他账号的当前 cfg 覆盖它。
      if (legacyNormalized) o[CONFIG_KEY] = legacy;
      chrome.storage.local.set(o, finish);
    } else {
      finish();
    }
  });
}

function saveConfigProfile(config, cb) {
  var cfg = normalizeCfg(config);
  withConfigProfiles(function (accountKey, r, store, account) {
    var legacy = r[CONFIG_KEY] && typeof r[CONFIG_KEY] === 'object' ? normalizeCfg(r[CONFIG_KEY]) : null;
    claimLegacyConfig(store, legacy, accountKey);
    migrateAllStoredProfiles(store);
    account.configs[cfg.provider] = cfg;
    account.activeProvider = cfg.provider;
    store.activeAccount = accountKey;
    store.activeProvider = cfg.provider;
    var o = {};
    o[CONFIG_PROFILES_KEY] = store;
    chrome.storage.local.set(o, function () {
      cb({ ok: true, accountKey: accountKey, provider: cfg.provider, config: cfg });
    });
  });
}

function setActiveConfigProvider(provider, cb) {
  provider = provider || DEFAULT_CFG.provider;
  withConfigProfiles(function (accountKey, r, store, account) {
    var legacy = r[CONFIG_KEY] && typeof r[CONFIG_KEY] === 'object' ? normalizeCfg(r[CONFIG_KEY]) : null;
    claimLegacyConfig(store, legacy, accountKey);
    migrateAllStoredProfiles(store);
    account.activeProvider = provider;
    store.activeAccount = accountKey;
    store.activeProvider = provider;
    var o = {}; o[CONFIG_PROFILES_KEY] = store;
    chrome.storage.local.set(o, function () {
      cb({ ok: true, accountKey: accountKey, provider: provider });
    });
  });
}

function resolveUnifiedConfigReference(ref) {
  ref = ref || {};
  return new Promise(function (resolve) {
    resolveConfigAccountKey(function (currentAccountKey) {
      if (ref.accountKey && ref.accountKey !== currentAccountKey) {
        resolve({
          ok: false,
          code: 'account_changed',
          accountKey: currentAccountKey,
          error: '账号已切换，请回到插件启动界面重新确认 API 配置后再试。'
        });
        return;
      }
      chrome.storage.local.get([CONFIG_PROFILES_KEY], function (r) {
        var store = normalizeProfileStore(r[CONFIG_PROFILES_KEY]);
        var before = JSON.stringify(store);
        migrateAllStoredProfiles(store);
        var account = store.accounts[currentAccountKey];
        var provider = ref.provider || (account && account.activeProvider) || DEFAULT_CFG.provider;
        var raw = account && account.configs && account.configs[provider];
        if (!raw || typeof raw !== 'object') {
          var missing = {
              ok: false,
              code: 'config_not_found',
              accountKey: currentAccountKey,
              provider: provider,
              error: '当前账号尚未保存该服务商 API 配置，请先在插件启动界面保存。'
            };
          if (JSON.stringify(store) !== before) {
            var sanitized = {}; sanitized[CONFIG_PROFILES_KEY] = store;
            chrome.storage.local.set(sanitized, function () { resolve(missing); });
          } else {
            resolve(missing);
          }
          return;
        }
        account = store.accounts[currentAccountKey];
        var cfg = normalizeCfg(Object.assign({ provider: provider }, account.configs[provider]));
        account.configs[provider] = cfg;
        function finish() {
          resolve({ ok: true, accountKey: currentAccountKey, provider: provider, config: cfg });
        }
        if (JSON.stringify(store) !== before) {
          var out = {}; out[CONFIG_PROFILES_KEY] = store;
          chrome.storage.local.set(out, finish);
        } else {
          finish();
        }
      });
    });
  });
}

function openUnifiedApiSettings(cb) {
  if (!IS_BUNDLED_PLUGIN) {
    cb({ ok: false, unavailable: true, error: '独立实验室不包含插件启动界面，请使用当前页的模型配置。' });
    return;
  }
  var url = chrome.runtime.getURL('src/popup.html?settings=1');
  chrome.tabs.create({ url: url }, function () {
    var lastError = chrome.runtime.lastError;
    if (lastError) {
      cb({ ok: false, error: lastError.message || '无法打开插件启动界面' });
      return;
    }
    cb({ ok: true, opened: true, url: url });
  });
}

function signalForPayload(payload) {
  var jobId = payload && payload._jobId;
  return jobId && activeJobs[jobId] ? activeJobs[jobId].signal : null;
}

chrome.runtime.onInstalled.addListener(function () {
  chrome.contextMenus.removeAll(function () {
    chrome.contextMenus.create({
      id: 'sz-local-link-analyze-image',
      title: '本地合成版：用此图片生成提示词',
      contexts: ['image']
    });
  });
});

chrome.action.onClicked.addListener(function () {
  chrome.tabs.create({ url: chrome.runtime.getURL(LAB_PAGE) });
});

chrome.contextMenus.onClicked.addListener(function (info, tab) {
  if (info.menuItemId !== 'sz-local-link-analyze-image') return;
  var payload = {
    imageUrl: info.srcUrl || '',
    pageUrl: info.pageUrl || (tab && tab.url) || '',
    title: tab && tab.title || '',
    at: Date.now()
  };
  showInlineContextCard(tab && tab.id, payload);
});

function openContextWorkbench(payload) {
  var o = {}; o[CONTEXT_KEY] = payload;
  chrome.storage.local.set(o, function () {
    chrome.tabs.create({ url: chrome.runtime.getURL(LAB_PAGE) + '?source=context&auto=1' });
  });
}

function showInlineContextCard(tabId, payload) {
  if (tabId == null) {
    openContextWorkbench(payload);
    return;
  }
  var fallbackOpened = false;
  function openFallback(reason) {
    if (fallbackOpened) return;
    fallbackOpened = true;
    if (reason) console.warn('context card unavailable, opening workbench:', reason);
    openContextWorkbench(payload);
  }
  try {
    chrome.scripting.executeScript({
      target: { tabId: tabId, allFrames: false },
      files: [CONTEXT_CARD_SCRIPT]
    }, function () {
      if (chrome.runtime.lastError) {
        openFallback(chrome.runtime.lastError.message || '页面不允许注入');
        return;
      }
      chrome.tabs.sendMessage(tabId, { type: 'SZ_CONTEXT_IMAGE_ACTION', payload: payload }, function () {
        var sendError = chrome.runtime.lastError;
        if (sendError) openFallback(sendError.message || '页面无法接收图片操作');
      });
    });
  } catch (e) {
    openFallback(e && e.message ? e.message : e);
  }
}

function endpoint(baseURL, suffix) {
  var b = (baseURL || DEFAULT_CFG.visionBaseUrl).replace(/\/+$/, '');
  if (/\/chat\/completions$/.test(b)) return b;
  return b + suffix;
}

function subjectReplacementTextRule() {
  return [
    '主体替换与商品一致性是最高优先级：最终生图的商品主体必须以用户上传的产品主体多角度图为唯一身份依据。',
    '正视图、侧视图、背视图/结构图共同描述同一个 SKU，必须交叉校准商品轮廓、长宽厚比例、包装结构、边缘与开口、部件数量和位置、颜色、材质、纹理、图案、可见标识与文字位置；不得把不同角度误当成不同商品。',
    '严禁拉伸、压扁、弯折、变形、重设计、改色、换材质、增删部件、改变数量、改变包装结构或凭空补造不可见细节；透视和遮挡也不得破坏商品的真实几何比例。',
    '参考图、竞品图、链接清单、历史结果和模型生成的旧提示词只能提供风格、构图、光影、场景、版式、字体层级和文案方向；其中出现的旧商品、旧包装、旧品牌、旧 logo、旧 SKU、旧道具或旧人物手持物都不是最终主体。',
    '如果链接清单或参考图描述的商品与产品主体图冲突，必须保留链接定位/卖点/人群/场景，把画面中的主体改写成产品主体图里的目标商品。',
    '中文提示词必须明确写出：以产品主体多角度图作为唯一目标商品主体，参考图主体被替换，并说明本画面由哪些角度共同校准商品一致性。'
  ].join('\n');
}

function nestedFieldEntry(root, names, requireNonEmpty) {
  var wanted = {};
  (names || []).forEach(function (name) { wanted[String(name)] = true; });
  var queue = [root];
  var seen = [];
  while (queue.length) {
    var current = queue.shift();
    if (!current || typeof current !== 'object') continue;
    if (seen.indexOf(current) >= 0) continue;
    seen.push(current);
    var keys = Object.keys(current);
    for (var i = 0; i < keys.length; i++) {
      if (wanted[keys[i]] && (!requireNonEmpty || nonEmptyProtocolValue(current[keys[i]]))) {
        return { found: true, value: current[keys[i]], key: keys[i] };
      }
    }
    for (var j = 0; j < keys.length; j++) {
      var child = current[keys[j]];
      if (child && typeof child === 'object') queue.push(child);
    }
  }
  return { found: false, value: undefined, key: '' };
}

function nonEmptyProtocolValue(value) {
  if (value === undefined || value === null) return false;
  if (typeof value === 'string') return !!value.trim();
  if (Array.isArray(value)) return value.length > 0;
  if (typeof value === 'object') return Object.keys(value).length > 0;
  return true;
}

function nestedText(root, names) {
  var wanted = {};
  (names || []).forEach(function (name) { wanted[String(name)] = true; });
  var queue = [root];
  var seen = [];
  while (queue.length) {
    var current = queue.shift();
    if (!current || typeof current !== 'object') continue;
    if (seen.indexOf(current) >= 0) continue;
    seen.push(current);
    var keys = Object.keys(current);
    for (var i = 0; i < keys.length; i++) {
      if (!wanted[keys[i]]) continue;
      var value = current[keys[i]];
      if (typeof value === 'string' && value.trim()) return value.trim();
      if (typeof value === 'number' || typeof value === 'boolean') return String(value);
    }
    for (var j = 0; j < keys.length; j++) {
      var child = current[keys[j]];
      if (child && typeof child === 'object') queue.push(child);
    }
  }
  return '';
}

function normalizeLinkId(value) {
  var text = String(value === undefined || value === null ? '' : value).trim();
  var match = text.match(/^L\s*0*(\d+)$/i);
  if (!match) return '';
  var number = parseInt(match[1], 10);
  if (!number || number < 1) return '';
  var digits = String(number);
  while (digits.length < 3) digits = '0' + digits;
  return 'L' + digits;
}

function linkField(link, names, fallback) {
  var value = nestedText(link || {}, names);
  return value || fallback || '';
}

// 链接工作台只向模型暴露“链接上架清单”的固定 20 字段。这样旧版本 JSON
// 即使还带有诊断字段或已废弃的风格/人群口径，也不会重新进入提词链路。
var LINK_RECORD_CONTRACT_FIELDS = [
  '链接编号', '生成方式', '链接分组', '链接定位', '主推关键词', '用户场景需求', '来源关键词',
  '竞品未覆盖词根', '差异化定位逻辑',
  '标题结构', '标题定位词路', '商品标题', '标题冲突处理', '主图核心文案', '详情页定位', '详情页文案', '详情文案逻辑',
  '优先级分数', '优先级', '数据状态'
];

function contractLinkRecord(link) {
  link = link && typeof link === 'object' ? link : {};
  return LINK_RECORD_CONTRACT_FIELDS.reduce(function (out, key) {
    if (Object.prototype.hasOwnProperty.call(link, key)) out[key] = link[key];
    return out;
  }, {});
}

function productEvidenceItems(payload) {
  payload = payload || {};
  var fallbackLabels = ['产品正视图', '产品侧视图', '产品背视图/结构图'];
  var source = Array.isArray(payload.productImageEvidence) ? payload.productImageEvidence : [];
  var out = [];
  source.forEach(function (item, idx) {
    var image = typeof item === 'string' ? item : (item && (item.image || item.url || item.dataUrl));
    if (!image) return;
    var label = item && typeof item === 'object' && (item.label || item.name || item.angleLabel);
    var angle = item && typeof item === 'object' && item.angle;
    out.push({ image: image, label: label || angle || fallbackLabels[idx] || ('产品角度图 ' + (idx + 1)) });
  });
  if (!out.length && Array.isArray(payload.productImages)) {
    payload.productImages.forEach(function (image, idx) {
      if (image) out.push({ image: image, label: fallbackLabels[idx] || ('产品角度图 ' + (idx + 1)) });
    });
  }
  return out.slice(0, 3);
}

function productEvidenceNote(evidence) {
  if (!evidence || !evidence.length) return '本次未附商品图片证据，提示词仍须预留“以用户随后上传的商品主体多角度图为唯一主体”的强约束。';
  return '本次已附 ' + evidence.length + ' 张同一商品的多角度证据（' + evidence.map(function (item) { return item.label; }).join('、') + '），必须共同校准同一 SKU 的外观与几何结构。';
}

function referenceImagesFromPayload(payload) {
  payload = payload || {};
  var out = [];
  (Array.isArray(payload.referenceImages) ? payload.referenceImages : [])
    .concat(Array.isArray(payload.images) ? payload.images : [])
    .concat(payload.referenceImage || '')
    .concat(payload.image || '')
    .forEach(function (image) {
      if (image && out.indexOf(image) < 0 && out.length < 6) out.push(image);
    });
  return out;
}

function referenceEvidenceNote(images) {
  images = images || [];
  return '已提供 ' + images.length + ' 张参考页，必须按上传顺序 1→' + images.length + ' 分析整套页面的故事推进和视觉承接，不得将其当成互不相关的单图。';
}

function modelEvidenceItems(payload) {
  payload = payload || {};
  var fallbackLabels = ['模特正视图', '模特侧视图', '模特背视图'];
  var source = Array.isArray(payload.modelImageEvidence) ? payload.modelImageEvidence : [];
  var out = [];
  source.forEach(function (item, idx) {
    var image = typeof item === 'string' ? item : (item && (item.image || item.url || item.dataUrl));
    if (!image) return;
    out.push({ image: image, label: (item && typeof item === 'object' && (item.label || item.angleLabel || item.angle)) || fallbackLabels[idx] || ('模特角度图 ' + (idx + 1)) });
  });
  if (!out.length && Array.isArray(payload.modelImages)) {
    payload.modelImages.forEach(function (image, idx) {
      if (image) out.push({ image: image, label: fallbackLabels[idx] || ('模特角度图 ' + (idx + 1)) });
    });
  }
  return out.slice(0, 3);
}

function businessKnowledgePrompt(context, scope) {
  context = String(context || '').trim();
  if (!context) return '';
  var label = scope === 'detail' ? '详情页提示词' : (scope === 'main' ? '主图提示词' : '链接定位');
  return '\n业务知识库（用于' + label + '）：\n' + context + '\n' +
    '知识库优先级：只用于补充业务事实、用户语境、品牌语气、视觉偏好与合规边界；不得改变当前 L 编号，不得覆盖链接 JSON 的逐条定位，不得覆盖商品主体图片身份，也不得替代参考图路线与链接路线的隔离规则。\n';
}

function textJsonPrompt(link, evidenceNote, businessContext) {
  link = contractLinkRecord(link);
  var linkId = linkField(link, ['链接编号', 'linkId', '编号', 'ID', 'id'], '未编号');
  var linkPositioning = linkField(link, ['链接定位', '定位'], '');
  var keywords = linkField(link, ['主推关键词'], '');
  var sceneNeed = linkField(link, ['用户场景需求'], '');
  var differentiationLogic = linkField(link, ['差异化定位逻辑'], '');
  var coreCopy = linkField(link, ['主图核心文案'], '');
  var titleRoute = linkField(link, ['标题定位词路'], '');
  var productTitle = linkField(link, ['商品标题'], '');
  return '你是资深天猫淘宝主图创意总监。根据链接清单，为指定链接生成可直接执行的电商主图提示词方案。\n' +
    subjectReplacementTextRule() + '\n' +
    '当前链接编号：' + linkId + '\n' +
    '链接定位：' + (linkPositioning || '未填写') + '\n' +
    '主推关键词：' + (keywords || '未填写') + '\n' +
    '用户场景需求：' + (sceneNeed || '未填写') + '\n' +
    '差异化定位逻辑：' + (differentiationLogic || '未填写') + '\n' +
    '标题定位词路：' + (titleRoute || '未填写') + '\n' +
    '商品标题：' + (productTitle || '未填写') + '\n' +
    '主图核心文案：' + (coreCopy || '未填写') + '\n' +
    '商品证据：' + (evidenceNote || '') + '\n' +
    businessKnowledgePrompt(businessContext, 'main') +
    '要求：1) “链接编号”必须原样回填当前链接编号 ' + linkId + '，不得改号、猜号或串用相邻链接的规划；2) 只使用本条 20 字段链接记录，不得要求或补造“风格定位、目标人群、差异化壁垒”等旧口径；3) “生图逻辑”必须解释链接定位如何决定主画面任务、主推关键词如何锁定品类表达、用户场景需求如何决定场景和使用线索、差异化定位逻辑如何形成视觉证据、主图核心文案如何形成文字层级与留白；4) 标题定位词路和商品标题只用于校准商品表达，不得覆盖主体图中的真实商品身份；5) 不照抄任何竞品品牌、商标、包装版式；6) 要服务链接定位和转化，不做泛泛的艺术图；7) 只输出中文提示词；8) 真实商品外观严格以产品主体多角度图为准；9) 给出可直接用于生图模型的负面提示词。\n' +
    '只输出 JSON：{"链接编号":"","链接定位":"","主图方向":"","生图逻辑":"","画面布局":"","中文提示词":"","负面提示词":"","主图文案":"","4方向":["主图转化版","场景种草版","视觉锤版","差异化表达版"]}。\n' +
    '链接清单 JSON：' + JSON.stringify(link);
}

function analyzeImagePrompt(linkHint, evidenceNote, referenceCount, businessContext) {
  referenceCount = Math.max(1, Math.min(6, Number(referenceCount) || 1));
  return '你是电商详情页故事与视觉系统分析器。输入包含按用户上传顺序排列的 ' + referenceCount + ' 张参考页，以及后续用户商品主体多角度图。禁止复刻竞品品牌、商标、包装文字或人物肖像身份。\n' +
    subjectReplacementTextRule() + '\n' +
    '必须按参考页 1→' + referenceCount + ' 的顺序学习整套页面，分析：1) 故事逻辑与每页承接；2) 文案语气、标题短句结构、字体风格、字体家族/粗细/字距/行高/对齐和字号层级；3) 背景与道具元素；4) 光源方向、软硬、明暗、景深与焦点层次、焦点迁移；5) 页面布局结构、留白、图文比例和视觉节奏。\n' +
    '每张参考页都必须单独识别其旧商品、旧包装、旧品牌/logo、旧 SKU、旧人物手持物和与之绑定的类目道具，形成“旧主体识别与替换表”。这些旧主体不得进入最终画面。\n' +
    '最终方案必须把用户上传的产品主体图作为唯一新商品身份，用正/侧/背等多角度交叉校准结构、比例、包装、颜色、材质和部件，再自然融入参考页的故事位置、光影、景深、背景元素和版式占位；禁止变形、拉伸、重设计或混合新旧主体。\n' +
    '商品主体证据：' + (evidenceNote || '') + '\n' +
    '如果有链接定位，只用它调整表达重点，不得覆盖新主体。链接定位：' + (linkHint || '无') + '\n' +
    businessKnowledgePrompt(businessContext, 'main') +
    '只输出 JSON：{"参考页数":' + referenceCount + ',"参考页面故事逻辑":{"总叙事":"","页面顺序":[{"页码":1,"页面任务":"","承接关系":""}]},"逐页分析":[{"页码":1,"文案风格":"","字体与字号":"","背景元素":"","光影与景深":"","页面布局结构":"","旧主体":"","新主体融入位置":""}],"旧主体识别与替换表":[{"页码":1,"待替换旧主体":"","保留视觉关系":"","新主体融入方式":""}],"主体":"待替换的参考主体","品类":"","构图":"","镜头":"","景深":"","光线":"","色彩":"","场景":"","材质":"","背景":"","背景元素":"","背景层次":{"前景":"","中景":"","远景":""},"页面布局结构":"","文案风格":"","风格":"","字体":"","字号与文字层级":{"大标题":"","副标题":"","说明文字":"","注释文字":""},"模特设定":"","旧主体识别":"","新主体融入逻辑":"","可借鉴点":"","避让点":"","生图逻辑":"","中文提示词":"","负面提示词":""}。';
}

function detailPageJsonPrompt(payload, imageNote) {
  payload = payload || {};
  var isLinkMode = payload.mode === 'link';
  var maxCount = isLinkMode ? 16 : 10;
  var count = Math.max(5, Math.min(maxCount, parseInt(payload.screenCount, 10) || 10));
  var modeText = isLinkMode ? '链接清单详情规划 + 产品主体多角度图' : '参考图视觉反推 + 产品主体多角度图';
  // 两条详情路线的信息源必须隔离：参考图路线不读取任何链接字段，链接路线只读取当前选中链接。
  var link = isLinkMode ? contractLinkRecord(payload.link) : {};
  var detailPositioning = isLinkMode ? linkField(link, ['详情页定位', '链接定位'], '') : '';
  var detailCopy = isLinkMode ? linkField(link, ['详情页文案', '主图核心文案'], '') : '';
  var detailLogic = isLinkMode
    ? linkField(link, ['详情文案逻辑', '详情页逻辑', '详情逻辑'], '痛点 -> 场景 -> 功能 -> 差异证明 -> 使用教程 -> 信任收口')
    : '';
  var sourceRules = isLinkMode ? [
    '2) 本模式只以链接清单、商品主体多角度图和人物模特图为信息源，不使用参考图、参考图分析或已有主图提示词；即使请求载荷中残留这些字段也必须忽略，避免参考分析污染当前链接。',
    '3) 输出的“链接编号”必须与当前输入编号完全对应，不得改号、跳号或串用其他链接的详情规划。',
    '4) 必须显式调用“详情页定位”“详情页文案”“详情文案逻辑”三项：详情页定位决定整套页面的说服目标，详情页文案决定逐屏核心表达，详情文案逻辑决定屏幕先后与承接关系；三项都要写入“生图逻辑”和分屏规划。',
    '5) 统一视觉风格必须从链接定位、主推关键词、用户场景需求、差异化定位逻辑、主图核心文案和详情三字段中推导，不得要求或补造“风格定位、目标人群、差异化壁垒”等旧口径，也不得声称来自参考图；字体、字号、色彩、背景和画面节奏要围绕当前链接的转化定位形成一致规范。'
  ].join('\n') : [
    '2) 必须按用户上传的 1-6 张参考页顺序分析整套页面故事：每页任务、上下承接、卖点递进和收尾逻辑；不得打乱顺序或将多页当成互不相关的单图。',
    '3) 逐页提取文案语气与短句结构、字体家族/粗细/字距/行高/对齐、标题/副标题/说明/注释字号层级、背景与道具元素、光源软硬与明暗、景深焦点、留白、图文比例和页面布局结构；从全部参考页命名一套统一视觉风格。',
    '4) 对每张参考页建立“旧主体识别与替换表”：旧商品、旧包装、旧品牌/logo、旧 SKU和旧手持物一律不保留；只保留它们在构图中的占位、尺度、透视、光影和与人/场景的关系，再用用户产品主体图中的新商品自然替换。'
  ].join('\n');
  var sourceData = isLinkMode ? [
    '链接编号：' + linkField(link, ['链接编号', 'linkId', '编号', 'ID', 'id'], '未编号'),
    '链接定位：' + linkField(link, ['链接定位', '定位'], ''),
    '主推关键词：' + linkField(link, ['主推关键词'], ''),
    '用户场景需求：' + linkField(link, ['用户场景需求'], ''),
    '差异化定位逻辑：' + linkField(link, ['差异化定位逻辑'], ''),
    '标题定位词路：' + linkField(link, ['标题定位词路'], ''),
    '商品标题：' + linkField(link, ['商品标题'], ''),
    '主图核心文案：' + linkField(link, ['主图核心文案'], ''),
    '详情页定位：' + detailPositioning,
    '详情页文案：' + detailCopy,
    '详情文案逻辑：' + detailLogic,
    '链接清单 JSON：' + JSON.stringify(link)
  ].join('\n') : [
    '参考页数：' + referenceImagesFromPayload(payload).length + '（按上传顺序学习）',
    '参考页路线已有视觉提示词（可选）：' + (payload.currentMainPrompt || ''),
    '参考图分析 JSON：' + JSON.stringify(payload.analysis || {})
  ].join('\n');
  var outputSchema = isLinkMode
    ? '{"链接编号":"","详情页方向":"","产品名称":"","详情页定位":"","详情页文案":"","详情文案逻辑":"","生图逻辑":"","详情页规格":{"平台":"","页面类型":"","屏数":' + count + ',"比例":"","分辨率":"","语言":""},"统一视觉规范":{"风格名称":"","视觉来源":"链接清单推导","链接风格推导":"","字体样式":"","字号规范":{"大标题":"","副标题":"","说明文字":"","注释文字":""},"排版规范":""},"中文详情提示词":"","负面提示词":"","屏幕规划":[{"屏幕":1,"名称":"","承接关系":"","视觉风格对齐":"","字体样式":"","字号规范":{"大标题":"","副标题":"","说明文字":"","注释文字":""},"主体图使用":"","模特使用":"","画面方向":"","文案方向":"","生图提示词":"","避让点":""}]}'
    : '{"详情页方向":"","产品名称":"","参考页面故事逻辑":"","旧主体识别与替换表":[{"参考页":1,"旧主体":"","保留视觉关系":"","新主体融入方式":""}],"详情页定位":"","详情页文案":"","详情文案逻辑":"","生图逻辑":"","详情页规格":{"平台":"","页面类型":"","屏数":' + count + ',"比例":"","分辨率":"","语言":""},"统一视觉规范":{"风格名称":"","视觉来源":"1-6张参考页按顺序提取","参考页风格提取":"","文案风格":"","背景元素":"","光影与景深":"","页面布局结构":"","字体样式":"","字号规范":{"大标题":"","副标题":"","说明文字":"","注释文字":""},"排版规范":""},"中文详情提示词":"","负面提示词":"","屏幕规划":[{"屏幕":1,"名称":"","承接关系":"","对应参考页":"","参考页风格对齐":"","字体样式":"","字号规范":{"大标题":"","副标题":"","说明文字":"","注释文字":""},"主体图使用":"","旧主体替换":"","模特使用":"","画面方向":"","文案方向":"","生图提示词":"","避让点":""}]}';
  var sourceIdentityRule = isLinkMode
    ? '7) 链接定位和详情文案只能决定卖点顺序、场景、情绪和版式，不能覆盖商品主体图的身份与几何结构。'
    : '7) 参考图视觉分析只能决定风格、场景、情绪、版式和叙事节奏，不能引入链接清单定位，也不能覆盖商品主体图的身份与几何结构。';
  return '你是资深淘宝/天猫电商详情页策划和生图提示词导演。请根据输入信息生成详情页分屏提示词。\n' +
    '任务模式：' + modeText + '。\n' +
    '核心要求：\n' +
    '1) 默认规则：详情页默认 10 屏；如果用户在生成选项里修改屏数，则以用户选项优先。本次必须严格输出 ' + count + ' 屏，屏幕编号从 1 到 ' + count + '，不得多屏或少屏；输出的是详情页/长图的分屏规划，不是单张主图。\n' +
    sourceRules + '\n' +
    '5) 每一屏都必须沿用同一视觉风格、同一字体样式、同一字号层级、同一排版秩序和同一画面质感，确保生成的是一套有上下文关系、风格统一、排版连贯的详情页。\n' +
    '6) 产品主体多角度图是执行详情页生图的硬门槛和最终商品身份依据。正视图、侧视图、背视图/结构图必须共同校准同一个 SKU 的轮廓、长宽厚比例、包装结构、颜色、材质、纹理、部件与可见标识；每一屏说明主用角度及辅助校准角度，严禁商品变形、改色、换材质、增删部件、改变数量或重设计包装。\n' +
    sourceIdentityRule + '\n' +
    '8) 如果提供人物模特三视图，只有在痛点场景、使用步骤、适配人群、真实场景、口碑信任等适合人物入镜的屏幕中自然引用，用于人物身份一致性、尺度、动作、情绪和场景辅助；模特不能替代、遮挡、改写商品主体。没有模特图时仍可仅用商品主体图生成详情页。\n' +
    '9) 每一屏都要有承接关系、画面方向、文案方向、字体样式、字号规范、主体图使用、模特使用和可直接用于生图的提示词；生图提示词必须包含屏幕编号、统一风格名、字体/字号规范、主体图主用与校准角度、模特引用方式、画面内容、文案区域与排版位置。\n' +
    '10) “生图逻辑”必须解释整套详情如何从信息源推导、详情文案逻辑如何映射到逐屏顺序、商品多角度和模特分别承担什么证据角色；画面可有文案区域，但不要生成难以辨认的小字。\n' +
    (imageNote ? ('图片输入说明：' + imageNote + '\n') : '') +
    businessKnowledgePrompt(payload.businessKnowledgeContext, 'detail') +
    '输出规格：平台=' + (payload.platform || '淘宝') + '；页面类型=' + (payload.pageType || '详情页') + '；比例=' + (payload.ratio || '3:4 纵向') + '；分辨率=' + (payload.resolution || '2K') + '；语言=' + (payload.language || '中文') + '；生成方式=' + (payload.generateStyle || '分段提示词') + '。\n' +
    '产品名称：' + (payload.productName || '') + '\n' +
    '产品特性：' + (payload.productFeatures || '') + '\n' +
    '核心卖点：' + (payload.sellingPoints || '') + '\n' +
    '人物模特设定：' + (payload.modelPrompt || '') + '\n' +
    sourceData + '\n' +
    '只输出合法 JSON，不要 markdown。JSON 格式：' + outputSchema + '。';
}

function buildVisionMessages(payload) {
  payload = payload || {};
  var evidence = productEvidenceItems(payload);
  var references = referenceImagesFromPayload(payload);
  var content = [
    { type: 'text', text: analyzeImagePrompt(payload.linkHint || '', productEvidenceNote(evidence), references.length, payload.businessKnowledgeContext) },
    { type: 'text', text: referenceEvidenceNote(references) }
  ];
  references.forEach(function (image, idx) {
    content.push({ type: 'text', text: '下面是第 ' + (idx + 1) + ' / ' + references.length + ' 张参考页。严格保留它在整套故事中的顺序与承接角色；识别本页旧商品/旧包装/旧品牌但只记录为待替换主体，学习故事任务、文案字体、背景元素、光影景深和布局结构。' });
    content.push({ type: 'image_url', image_url: { url: image } });
  });
  evidence.forEach(function (item) {
    content.push({ type: 'text', text: '参考页序列已结束。下面是' + item.label + '，属于用户最终商品主体的身份图；必须与其他角度交叉校准同一 SKU，并替换前面所有参考页中的旧主体，不得变形或重设计。' });
    content.push({ type: 'image_url', image_url: { url: item.image } });
  });
  return [
    { role: 'system', content: '你只输出合法 JSON，不输出 markdown。' },
    { role: 'user', content: content }
  ];
}

function buildLinkMessages(cfg, payload) {
  payload = payload || {};
  var evidence = productEvidenceItems(payload);
  var canUseImages = !cfg || cfg.provider !== 'deepseek-v4';
  var promptText = textJsonPrompt(payload.link || {}, productEvidenceNote(evidence), payload.businessKnowledgeContext);
  if (!canUseImages) {
    return [
      { role: 'system', content: '你只输出合法 JSON，不输出 markdown。' },
      { role: 'user', content: promptText + '\n当前模型为纯文本模型，无法读取随请求上传的图片像素；提示词仍必须明确要求后续生图严格绑定商品主体多角度图，不得根据链接文字臆造商品外观。' }
    ];
  }
  var content = [{ type: 'text', text: promptText }];
  if (canUseImages) {
    evidence.forEach(function (item) {
      content.push({ type: 'text', text: '下面是' + item.label + '，是当前链接最终商品主体的硬证据；与其他角度共同保持轮廓、比例、结构、颜色、材质和部件完全一致。' });
      content.push({ type: 'image_url', image_url: { url: item.image } });
    });
  }
  return [
    { role: 'system', content: '你只输出合法 JSON，不输出 markdown。' },
    { role: 'user', content: content }
  ];
}

function buildDetailMessages(cfg, payload) {
  payload = payload || {};
  var isLinkMode = payload.mode === 'link';
  var scopedPayload = Object.assign({}, payload);
  if (isLinkMode) {
    // 链接路线忽略任何残留的参考图与反推结果。
    delete scopedPayload.referenceImage;
    delete scopedPayload.referenceImages;
    delete scopedPayload.images;
    delete scopedPayload.image;
    delete scopedPayload.analysis;
    delete scopedPayload.currentMainPrompt;
  } else {
    // 参考图路线不携带链接 JSON 或链接定位。
    scopedPayload.link = {};
    delete scopedPayload.detailPositioning;
    delete scopedPayload.detailCopy;
    delete scopedPayload.detailLogic;
    delete scopedPayload.detailCopyLogic;
  }
  var canUseImages = !cfg || cfg.provider !== 'deepseek-v4';
  var evidence = productEvidenceItems(scopedPayload);
  var modelEvidence = modelEvidenceItems(scopedPayload);
  var referenceEvidence = isLinkMode ? [] : referenceImagesFromPayload(scopedPayload);
  var content = [];
  var imageNote = canUseImages
    ? productEvidenceNote(evidence)
    : (isLinkMode
      ? '当前文本模型不接收图片像素，只能根据当前链接 JSON 和产品文字生成；后续生图仍须严格绑定用户商品主体多角度图。'
      : '当前文本模型不接收图片像素，只能根据已有参考图视觉分析和产品文字生成；后续生图仍须严格绑定用户商品主体多角度图。');
  var detailText = detailPageJsonPrompt(scopedPayload, imageNote);
  if (!canUseImages) {
    return [
      { role: 'system', content: '你只输出合法 JSON，不输出 markdown。' },
      { role: 'user', content: detailText }
    ];
  }
  content.push({ type: 'text', text: detailText });
  if (canUseImages && !isLinkMode && referenceEvidence.length) {
    content.push({ type: 'text', text: referenceEvidenceNote(referenceEvidence) + '请先完成整套参考页故事、文案字体、背景元素、光影景深和页面布局结构学习，再输出详情分屏。' });
    referenceEvidence.forEach(function (image, idx) {
      content.push({ type: 'text', text: '第 ' + (idx + 1) + ' / ' + referenceEvidence.length + ' 张参考页：保留本页在故事链中的任务、文案/字体层级、背景元素、光影/景深、布局占位与承接逻辑；识别其旧商品、旧包装和旧品牌为待替换主体。' });
      content.push({ type: 'image_url', image_url: { url: image } });
    });
  }
  if (canUseImages) {
    evidence.forEach(function (item) {
      content.push({ type: 'text', text: '下面这张是' + item.label + '，作为最终商品主体身份、真实比例和结构依据；须与其他角度交叉校准，任何分屏都不得改变商品。' });
      content.push({ type: 'image_url', image_url: { url: item.image } });
    });
  }
  if (canUseImages && modelEvidence.length) {
    content.push({ type: 'text', text: '下面的人物模特三视图是可选辅助证据，只在适合人物入镜的详情屏中参考姿态、身形比例、使用动作和情绪氛围；不得遮挡或替代商品主体。' });
    modelEvidence.forEach(function (item) {
      content.push({ type: 'text', text: item.label + '，仅作为人物一致性和动作参考。' });
      content.push({ type: 'image_url', image_url: { url: item.image } });
    });
  }
  return [
    { role: 'system', content: '你只输出合法 JSON，不输出 markdown。' },
    { role: 'user', content: content }
  ];
}

function cleanJson(content) {
  if (!content) return null;
  if (typeof content === 'object') return content;
  try { return JSON.parse(content); } catch (e) {}
  var m = ('' + content).match(/\{[\s\S]*\}/);
  if (m) { try { return JSON.parse(m[0]); } catch (e2) {} }
  return null;
}

function protocolResult(error) {
  return error ? { ok: false, error: error } : { ok: true };
}

function expectedPayloadLinkId(payload) {
  payload = payload || {};
  var source = payload.link && typeof payload.link === 'object' ? payload.link : payload;
  return normalizeLinkId(linkField(source, ['链接编号', 'linkId', '编号', 'ID', 'id'], ''));
}

function validateResponseLinkId(data, payload) {
  var expected = expectedPayloadLinkId(payload);
  if (!expected) return protocolResult('输入链接缺少有效链接编号（例如 L001）');
  var rawId = nestedText(data, ['链接编号', 'linkId', '编号', 'ID']);
  if (!rawId) {
    return protocolResult('模型返回缺少链接编号，应为 ' + expected);
  }
  var actual = normalizeLinkId(rawId);
  if (!actual) return protocolResult('模型返回的链接编号无效：' + rawId);
  if (actual !== expected) {
    return protocolResult('模型返回的链接编号与当前任务不一致：期望 ' + expected + '，实际 ' + actual);
  }
  return protocolResult('');
}

function validateLinkPromptProtocol(data, payload) {
  var idCheck = validateResponseLinkId(data, payload);
  if (!idCheck.ok) return idCheck;
  var link = (payload && payload.link) || {};
  var inputPositioning = linkField(link, ['链接定位', '定位'], '');
  if (inputPositioning && !nestedText(data, ['链接定位', 'linkPositioning'])) {
    return protocolResult('模型返回缺少链接定位（输入链接已提供该字段）');
  }
  return protocolResult('');
}

function screenNumberValue(screen) {
  var entry = nestedFieldEntry(screen, ['屏幕', '屏号', 'screen', 'screenIndex', 'index']);
  if (!entry.found) return null;
  var text = String(entry.value === undefined || entry.value === null ? '' : entry.value).trim();
  if (!/^\d+$/.test(text)) return null;
  return parseInt(text, 10);
}

function validateDetailScreens(data, expectedScreens) {
  var plansEntry = nestedFieldEntry(data, ['屏幕规划', '分屏规划', 'screenPlan', 'screens'], true);
  var plans = plansEntry.value;
  if (!Array.isArray(plans) || plans.length !== expectedScreens) {
    return protocolResult('模型返回屏幕规划数量不正确：需要 ' + expectedScreens + ' 屏，实际 ' + (Array.isArray(plans) ? plans.length : 0) + ' 屏');
  }
  var requiredFields = [
    { label: '承接关系', names: ['承接关系', 'continuity', 'transition'] },
    { label: '画面方向', names: ['画面方向', 'visualDirection', 'imageDirection'] },
    { label: '生图提示词', names: ['生图提示词', 'imagePrompt', 'generationPrompt'] },
    { label: '主体图使用', names: ['主体图使用', 'productImageUse', 'subjectImageUse'] }
  ];
  for (var i = 0; i < plans.length; i++) {
    var expectedNumber = i + 1;
    var actualNumber = screenNumberValue(plans[i]);
    if (actualNumber !== expectedNumber) {
      return protocolResult('模型返回的屏幕规划顺序错误：第 ' + expectedNumber + ' 项应为屏号 ' + expectedNumber + '，实际为 ' + (actualNumber === null ? '缺失或无效' : actualNumber));
    }
    for (var j = 0; j < requiredFields.length; j++) {
      if (!nestedText(plans[i], requiredFields[j].names)) {
        return protocolResult('模型返回的第 ' + expectedNumber + ' 屏缺少' + requiredFields[j].label);
      }
    }
    var modelUse = nestedFieldEntry(plans[i], ['模特使用', 'modelUse', 'modelUsage']);
    if (!modelUse.found) {
      return protocolResult('模型返回的第 ' + expectedNumber + ' 屏缺少模特使用字段（无模特时也应写明不使用策略）');
    }
  }
  return protocolResult('');
}

function validateReferencePageLearning(data, payload, requirePerPageAnalysis) {
  var referenceCount = referenceImagesFromPayload(payload).length;
  if (referenceCount <= 1) return protocolResult('');
  var story = nestedFieldEntry(data, ['参考页面故事逻辑', '页面故事逻辑', 'storySequence'], true);
  if (!story.found) return protocolResult('模型未返回参考页面故事逻辑，不能确认已按顺序学习 ' + referenceCount + ' 张参考页');
  var replacements = nestedFieldEntry(data, ['旧主体识别与替换表', '旧主体替换表', 'subjectReplacementMap'], true).value;
  if (!Array.isArray(replacements) || replacements.length !== referenceCount) {
    return protocolResult('模型返回的旧主体替换表数量不正确：需要 ' + referenceCount + ' 页，实际 ' + (Array.isArray(replacements) ? replacements.length : 0) + ' 页');
  }
  if (requirePerPageAnalysis) {
    var pages = nestedFieldEntry(data, ['逐页分析', '参考页分析', 'pageAnalysis'], true).value;
    if (!Array.isArray(pages) || pages.length !== referenceCount) {
      return protocolResult('模型返回的逐页分析数量不正确：需要 ' + referenceCount + ' 页，实际 ' + (Array.isArray(pages) ? pages.length : 0) + ' 页');
    }
  }
  var visualFields = [
    { label: '文案风格', names: ['文案风格', '文案语气', 'copyStyle'] },
    { label: '背景元素', names: ['背景元素', '场景元素', 'backgroundElements'] },
    { label: '光影与景深', names: ['光影与景深', '光线', '景深', 'lightingAndDepth'] },
    { label: '页面布局结构', names: ['页面布局结构', '版式结构', '构图', 'pageLayout'] }
  ];
  for (var i = 0; i < visualFields.length; i++) {
    if (!nestedText(data, visualFields[i].names)) return protocolResult('模型的多参考页分析缺少' + visualFields[i].label);
  }
  return protocolResult('');
}

function validateDetailPromptProtocol(data, payload, expectedScreens) {
  payload = payload || {};
  if (payload.mode === 'link') {
    var idCheck = validateResponseLinkId(data, payload);
    if (!idCheck.ok) return idCheck;
    var required = [
      { label: '详情页定位', names: ['详情页定位', 'detailPositioning'] },
      { label: '详情页文案', names: ['详情页文案', 'detailCopy'] },
      { label: '详情文案逻辑', names: ['详情文案逻辑', '详情页文案逻辑', 'detailLogic'] }
    ];
    for (var i = 0; i < required.length; i++) {
      if (!nestedText(data, required[i].names)) return protocolResult('模型返回缺少' + required[i].label);
    }
  } else {
    var referenceCheck = validateReferencePageLearning(data, payload, false);
    if (!referenceCheck.ok) return referenceCheck;
  }
  return validateDetailScreens(data, expectedScreens);
}

function validatePromptResponse(resp, mode, expectedScreens, protocol, payload) {
  if (!resp || !resp.ok) return resp;
  var data = resp.data;
  if (!data || typeof data !== 'object') return { ok: false, error: '模型返回 JSON 不是对象', raw: resp.raw };
  var prompt = mode === 'detail'
    ? nestedText(data, ['中文详情提示词', 'detailPrompt', 'prompt'])
    : nestedText(data, ['中文提示词', 'cnPrompt', 'prompt']);
  if (!prompt) return { ok: false, error: '模型返回缺少可用中文提示词', raw: resp.raw };
  if (!nestedText(data, ['生图逻辑', 'generationLogic'])) return { ok: false, error: '模型返回缺少生图逻辑', raw: resp.raw };
  if (mode === 'detail' && !nestedText(data, ['详情文案逻辑', '详情页文案逻辑', 'detailLogic'])) {
    return { ok: false, error: '模型返回缺少详情文案逻辑', raw: resp.raw };
  }
  var checked = protocol === 'link-main'
    ? validateLinkPromptProtocol(data, payload || {})
    : (mode === 'detail' ? validateDetailPromptProtocol(data, payload || {}, expectedScreens) : protocolResult(''));
  if (!checked.ok) return { ok: false, error: checked.error, raw: resp.raw };
  return resp;
}

function chatJson(cfg, messages, model, temperature, timeoutMs) {
  return new Promise(function (resolve) {
    cfg = normalizeCfg(cfg);
    if (cfg.provider === 'nano-banana' || cfg.imageAdapter === 'nano-banana' || cfg.imageAdapter === 'gemini-image') {
      geminiJson(cfg, messages, model, timeoutMs).then(resolve);
      return;
    }
    if (!cfg.apiKey) { resolve({ ok: false, error: '未配置 API Key' }); return; }
    var url = endpoint(cfg.visionBaseUrl, '/chat/completions');
    var body = {
      model: normalizeHostedTextModel(cfg, model || cfg.visionModel || DEFAULT_CFG.visionModel),
      messages: messages,
      temperature: temperature == null ? 0.2 : temperature
    };
    if (!/^https:\/\/ark\.cn-beijing\.volces\.com/.test(url)) {
      body.response_format = { type: 'json_object' };
    }
    var ctrl = new AbortController();
    var waitMs = timeoutMs || 180000;
    var to = setTimeout(function () { try { ctrl.abort(); } catch (e) {} }, waitMs);
    fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + cfg.apiKey },
      body: JSON.stringify(body),
      signal: ctrl.signal
    }).then(function (r) {
      return r.text().then(function (txt) { return { status: r.status, txt: txt }; });
    }).then(function (resp) {
      clearTimeout(to);
      if (resp.status < 200 || resp.status >= 300) {
        var rawError = (resp.txt || '').slice(0, 260);
        var modelMissing = /model_not_found|model[^\n]{0,100}not supported|not supported by any configured account/i.test(rawError);
        if (modelMissing) {
          var fallbackModel = DEFAULT_CFG.textModel;
          if (isShaozhuangHostedConfig(cfg) && !sameModelName(body.model, fallbackModel)) {
            chatJson(cfg, messages, fallbackModel, temperature, timeoutMs).then(function (fallbackResp) {
              if (fallbackResp && fallbackResp.ok) {
                persistHostedTextModelFallback(cfg, body.model, fallbackModel, function (persisted) {
                  fallbackResp.modelFallback = { from: body.model, to: fallbackModel, persisted: persisted };
                  fallbackResp.warning = '模型“' + body.model + '”未开通，已自动切换为 ' + fallbackModel + '。';
                  resolve(fallbackResp);
                });
                return;
              }
              resolve({
                ok: false,
                code: 'model_not_found',
                model: body.model,
                fallbackModel: fallbackModel,
                error: '模型“' + body.model + '”当前账号不可用；已尝试默认模型 ' + fallbackModel + '，但仍失败：' + ((fallbackResp && fallbackResp.error) || '未知错误')
              });
            });
            return;
          }
          var hostedHint = isShaozhuangHostedConfig(cfg)
            ? '请打开' + CONFIG_UI_LABEL + '，使用少壮托管默认模型 ' + DEFAULT_CFG.textModel + '，或填写当前账号组实际开通的模型名。'
            : '请打开' + CONFIG_UI_LABEL + '，填写当前 API 账号实际开通的模型名。';
          resolve({
            ok: false,
            code: 'model_not_found',
            model: body.model,
            error: '模型“' + body.model + '”当前账号不可用。' + hostedHint
          });
          return;
        }
        resolve({ ok: false, error: 'HTTP ' + resp.status + ': ' + rawError });
        return;
      }
      var data; try { data = JSON.parse(resp.txt); } catch (e) { resolve({ ok: false, error: '模型返回不是 JSON' }); return; }
      var content = data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
      var obj = cleanJson(content);
      if (!obj) { resolve({ ok: false, error: '解析模型 JSON 失败' }); return; }
      resolve({ ok: true, data: obj, raw: content });
    }).catch(function (e) {
      clearTimeout(to);
      resolve({ ok: false, error: (e && e.name === 'AbortError') ? ('请求超时（已等待 ' + Math.round(waitMs / 1000) + ' 秒）') : ('网络错误：' + ((e && e.message) || e)) });
    });
  });
}

function geminiPartsFromMessages(messages) {
  var parts = [];
  (messages || []).forEach(function (msg) {
    if (!msg || msg.role === 'system') return;
    if (typeof msg.content === 'string') {
      parts.push({ text: msg.content });
    } else if (Array.isArray(msg.content)) {
      msg.content.forEach(function (it) {
        if (!it) return;
        if (it.type === 'text') parts.push({ text: it.text || '' });
        if (it.type === 'image_url' && it.image_url && it.image_url.url) parts.push(imagePartForGemini(it.image_url.url));
      });
    }
  });
  parts.push({ text: '\n只输出合法 JSON，不要 markdown。' });
  return parts;
}

function geminiJson(cfg, messages, model, timeoutMs) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  if (!cfg.apiKey) return Promise.resolve({ ok: false, error: '未配置 API Key' });
  var oldModel = cfg.imageModel;
  cfg.imageModel = model || cfg.visionModel || cfg.textModel || cfg.imageModel || 'gemini-2.5-flash-image-preview';
  var body = { contents: [{ role: 'user', parts: geminiPartsFromMessages(messages) }] };
  var url = geminiUrl(cfg);
  cfg.imageModel = oldModel;
  return fetchJson(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }, timeoutMs || 120000)
    .then(function (res) {
      if (!res.ok) return annotateGeminiError(cfg, res);
      var text = '';
      try {
        var parts = (((res.data || {}).candidates || [])[0] || {}).content.parts || [];
        parts.forEach(function (p) { if (p.text) text += p.text; });
      } catch (e) {}
      var obj = cleanJson(text);
      return obj ? { ok: true, data: obj, raw: text || res.data } : { ok: false, error: '解析 Gemini JSON 失败', raw: res.data };
    });
}

function testConfigProfile(cfg, timeoutMs) {
  cfg = normalizeCfg(cfg);
  var model = cfg.textModel || cfg.visionModel || DEFAULT_CFG.textModel;
  var messages = [
    { role: 'system', content: '你是 API 连接测试器，只输出合法 JSON。' },
    { role: 'user', content: '请只返回 {"ok":true,"message":"connected"}，不要输出其他内容。' }
  ];
  return chatJson(cfg, messages, model, 0, timeoutMs || 30000).then(function (result) {
    if (!result || !result.ok) {
      return {
        ok: false,
        provider: cfg.provider,
        model: model,
        error: (result && result.error) || 'API 连接测试失败',
        code: result && result.code
      };
    }
    return {
      ok: true,
      provider: cfg.provider,
      model: model,
      message: 'API 连接成功',
      data: result.data
    };
  });
}

function analyzeImage(cfg, payload) {
  return attachBusinessKnowledge(payload, 'main').then(function (scopedPayload) {
    if (!referenceImagesFromPayload(scopedPayload).length) return { ok: false, error: '缺少参考图片' };
    if (cfg && cfg.provider === 'deepseek-v4') return { ok: false, error: 'DeepSeek V4 当前作为文本提词模型接入，不支持图片反推。请切换到千问/豆包/智谱/OpenAI/Nano Banana 等视觉模型。' };
    return chatJson(cfg, buildVisionMessages(scopedPayload), (cfg && cfg.visionModel) || DEFAULT_CFG.visionModel, 0.1, 300000)
      .then(function (resp) {
        resp = validatePromptResponse(resp, 'main', 0);
        if (!resp || !resp.ok) return resp;
        var learningCheck = validateReferencePageLearning(resp.data || {}, scopedPayload, true);
        return learningCheck.ok ? resp : { ok: false, error: learningCheck.error, raw: resp.raw };
      });
  });
}

function buildLinkPrompt(cfg, payload) {
  return attachBusinessKnowledge(payload, 'main').then(function (scopedPayload) {
    var link = scopedPayload && scopedPayload.link;
    if (!link || typeof link !== 'object') return { ok: false, error: '链接清单 JSON 无效' };
    if (!expectedPayloadLinkId(scopedPayload)) return { ok: false, error: '链接清单缺少有效链接编号（例如 L001）' };
    var hasProductImages = productEvidenceItems(scopedPayload).length;
    if (!hasProductImages) return { ok: false, error: '请先上传至少 1 张商品主体图，主图提示词必须以主体图为商品依据' };
    var hasVisualEvidence = hasProductImages && (!cfg || cfg.provider !== 'deepseek-v4');
    var model = hasVisualEvidence
      ? ((cfg && (cfg.visionModel || cfg.textModel)) || DEFAULT_CFG.visionModel)
      : ((cfg && (cfg.textModel || cfg.visionModel)) || DEFAULT_CFG.textModel);
    return chatJson(cfg, buildLinkMessages(cfg || {}, scopedPayload), model, 0.35, 240000)
      .then(function (resp) { return validatePromptResponse(resp, 'main', 0, 'link-main', scopedPayload); });
  });
}

function buildDetailPrompt(cfg, payload) {
  return attachBusinessKnowledge(payload, 'detail').then(function (scopedPayload) {
    scopedPayload = scopedPayload || {};
    if (scopedPayload.mode === 'link' && !expectedPayloadLinkId(scopedPayload)) return { ok: false, error: '链接清单缺少有效链接编号（例如 L001）' };
    var hasProductImages = productEvidenceItems(scopedPayload).length;
    if (!hasProductImages) return { ok: false, error: '请先上传至少 1 张商品主体图，详情页生成必须以主体图为商品依据' };
    if (scopedPayload.mode !== 'link' && !referenceImagesFromPayload(scopedPayload).length) return { ok: false, error: '请先上传 1-6 张参考页，详情参考路线必须学习真实页面像素' };
    if (scopedPayload.mode !== 'link' && cfg && cfg.provider === 'deepseek-v4' && !scopedPayload.analysis) return { ok: false, error: 'DeepSeek V4 不能读取参考页图片。请先使用视觉模型完成参考页分析，或切换到支持图片的模型。' };
    var maxCount = scopedPayload.mode === 'link' ? 16 : 10;
    var count = Math.max(5, Math.min(maxCount, parseInt(scopedPayload.screenCount, 10) || 10));
    return chatJson(cfg, buildDetailMessages(cfg || {}, scopedPayload), (cfg && (cfg.visionModel || cfg.textModel)) || DEFAULT_CFG.visionModel, 0.25, 300000)
      .then(function (resp) { return validatePromptResponse(resp, 'detail', count, scopedPayload.mode === 'link' ? 'detail-link' : 'detail-reference', scopedPayload); });
  });
}

function claritySuffix(clarity) {
  clarity = String(clarity || '').toUpperCase();
  if (clarity === '4K') return ' ultra high resolution 4K commercial output, crisp product edges, readable design hierarchy, premium detail retention';
  if (clarity === '2K') return ' high resolution 2K commercial output, clean product details, sharp edges, premium lighting';
  if (clarity === '1K') return ' clean 1K commercial output, balanced lighting, clear product subject';
  if (clarity === 'COMMERCIAL') return ' commercial product photography, high clarity, clean details, sharp edges, premium studio lighting';
  if (clarity === 'HIGH') return ' high definition, crisp details, clean edges, realistic texture';
  return ' clean product image, balanced lighting';
}

function normalizeSize(size, sep) {
  var s = (size || '1024*1024').replace(/\s+/g, '');
  var m = s.match(/^(\d+)[x*](\d+)$/i);
  if (!m) return sep === 'x' ? '1024x1024' : '1024*1024';
  return m[1] + (sep || '*') + m[2];
}

function normalizeVolcSeedreamSize(size) {
  var s = (size || '2048x2048').replace(/\s+/g, '');
  if (/^(2K|3K)$/i.test(s)) return s.toUpperCase();
  var m = s.match(/^(\d+)[x*](\d+)$/i);
  var w = m ? parseInt(m[1], 10) : 2048;
  var h = m ? parseInt(m[2], 10) : 2048;
  var presets = [
    [2048, 2048], [2304, 1728], [1728, 2304], [2848, 1600],
    [1600, 2848], [2496, 1664], [1664, 2496], [3136, 1344],
    [3072, 3072], [3456, 2592], [2592, 3456], [4096, 2304],
    [2304, 4096], [2496, 3744], [3744, 2496], [4704, 2016]
  ];
  var ratio = w / h;
  var best = presets.slice().sort(function (a, b) {
    var da = Math.abs(Math.log(ratio / (a[0] / a[1])));
    var db = Math.abs(Math.log(ratio / (b[0] / b[1])));
    if (Math.abs(da - db) > 0.0001) return da - db;
    return (a[0] * a[1]) - (b[0] * b[1]);
  })[0];
  return best[0] + 'x' + best[1];
}

function isDataUrl(s) { return /^data:image\/[a-z0-9.+-]+;base64,/i.test('' + (s || '')); }
function dataUrlInfo(dataUrl) {
  var m = /^data:(image\/[a-z0-9.+-]+);base64,([\s\S]+)$/i.exec(dataUrl || '');
  return m ? { mime: m[1], base64: m[2] } : null;
}
function blobFromDataUrl(dataUrl) {
  var info = dataUrlInfo(dataUrl);
  if (!info) return null;
  var bin = atob(info.base64);
  var bytes = new Uint8Array(bin.length);
  for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type: info.mime });
}
function imagePartForGemini(image) {
  var info = dataUrlInfo(image);
  if (info) return { inline_data: { mime_type: info.mime, data: info.base64 } };
  return { file_data: { file_uri: image } };
}
function imageToProviderValue(image) {
  if (!image) return '';
  return image;
}

function productImagesFromPayload(payload) {
  payload = payload || {};
  var imgs = [];
  if (Array.isArray(payload.productImages)) imgs = imgs.concat(payload.productImages);
  if (payload.productImage) imgs.unshift(payload.productImage);
  return Array.from(new Set(imgs.filter(Boolean)));
}

function productSubjectRequiredError() {
  return '请先上传至少 1 张产品主体图。所有生图必须以产品主体图作为最终商品身份，参考图/链接/模板只用于风格、构图和排版。';
}

function modelImagesFromPayload(payload) {
  payload = payload || {};
  return Array.from(new Set((Array.isArray(payload.modelImages) ? payload.modelImages : []).filter(Boolean)));
}

function inputImagesFromPayload(payload) {
  payload = payload || {};
  var imgs = productImagesFromPayload(payload);
  imgs = imgs.concat(modelImagesFromPayload(payload));
  imgs = imgs.concat(referenceImagesFromPayload(payload));
  return Array.from(new Set(imgs.filter(Boolean)));
}

function generationPayload(cfg, payload) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  payload = payload || {};
  var prompt = (payload.prompt || '').trim();
  if (payload.negativePrompt) prompt += '\nNegative prompt: ' + payload.negativePrompt;
  prompt += claritySuffix(payload.clarity || 'standard');
  var content = [];
  productImagesFromPayload(payload).forEach(function (img) { content.push({ image: img }); });
  modelImagesFromPayload(payload).forEach(function (img) { content.push({ image: img }); });
  referenceImagesFromPayload(payload).forEach(function (img) { content.push({ image: img }); });
  content.push({ text: prompt });
  return {
    model: cfg.imageModel || DEFAULT_CFG.imageModel,
    input: { messages: [{ role: 'user', content: content }] },
    parameters: {
      size: payload.size || '1024*1024',
      n: Math.max(1, Math.min(4, parseInt(payload.count, 10) || 1)),
      watermark: payload.watermark === true || payload.watermark === 'true',
      prompt_extend: true
    }
  };
}

function taskUrlFrom(endpointUrl, taskId) {
  try {
    var u = new URL(endpointUrl || DEFAULT_CFG.imageEndpoint);
    return u.origin + '/api/v1/tasks/' + encodeURIComponent(taskId);
  } catch (e) {
    return 'https://dashscope.aliyuncs.com/api/v1/tasks/' + encodeURIComponent(taskId);
  }
}

function deepFindImages(value, out) {
  out = out || [];
  if (!value) return out;
  if (typeof value === 'string') {
    if (/^https?:\/\//.test(value) && /\.(png|jpe?g|webp|gif)(\?|$)/i.test(value)) out.push(value);
    return out;
  }
  if (Array.isArray(value)) {
    value.forEach(function (v) { deepFindImages(v, out); });
    return out;
  }
  if (typeof value === 'object') {
    ['url', 'image', 'image_url', 'orig_url', 'actual_image_url'].forEach(function (k) {
      if (typeof value[k] === 'string' && /^https?:\/\//.test(value[k])) out.push(value[k]);
    });
    Object.keys(value).forEach(function (k) { deepFindImages(value[k], out); });
  }
  return Array.from(new Set(out));
}

function deepFindBase64Images(value, out) {
  out = out || [];
  if (!value) return out;
  if (Array.isArray(value)) {
    value.forEach(function (v) { deepFindBase64Images(v, out); });
    return out;
  }
  if (typeof value === 'object') {
    var mime = value.mime_type || value.mimeType || value.media_type || 'image/png';
    var data = value.b64_json || value.base64 || value.data;
    if (typeof data === 'string' && data.length > 200 && /^[A-Za-z0-9+/=\s]+$/.test(data)) {
      out.push('data:' + mime + ';base64,' + data.replace(/\s+/g, ''));
    }
    var inlineData = value.inlineData || value.inline_data;
    if (inlineData && inlineData.data) {
      out.push('data:' + (inlineData.mimeType || inlineData.mime_type || 'image/png') + ';base64,' + inlineData.data);
    }
    Object.keys(value).forEach(function (k) { deepFindBase64Images(value[k], out); });
  }
  return Array.from(new Set(out));
}

function parseImageResponse(data) {
  var imgs = [];
  if (data && Array.isArray(data.data)) {
    data.data.forEach(function (it) {
      if (it && it.url) imgs.push(it.url);
      if (it && it.b64_json) imgs.push('data:image/png;base64,' + it.b64_json);
    });
  }
  imgs = imgs.concat(deepFindImages(data), deepFindBase64Images(data));
  return Array.from(new Set(imgs));
}

function fetchJson(url, opt, timeoutMs) {
  return new Promise(function (resolve) {
    var ctrl = new AbortController();
    var externalSignal = opt && opt.signal;
    var abortedByExternal = false;
    if (externalSignal) {
      if (externalSignal.aborted) {
        resolve({ ok: false, error: '请求已终止' });
        return;
      }
      externalSignal.addEventListener('abort', function () {
        abortedByExternal = true;
        try { ctrl.abort(); } catch (e) {}
      }, { once: true });
    }
    var to = setTimeout(function () { try { ctrl.abort(); } catch (e) {} }, timeoutMs || 120000);
    opt = opt || {};
    opt.signal = ctrl.signal;
    fetch(url, opt).then(function (r) {
      return r.text().then(function (txt) { return { status: r.status, txt: txt }; });
    }).then(function (resp) {
      clearTimeout(to);
      if (resp.status < 200 || resp.status >= 300) {
        resolve({ ok: false, error: 'HTTP ' + resp.status + ': ' + (resp.txt || '').slice(0, 420) });
        return;
      }
      var data; try { data = JSON.parse(resp.txt); } catch (e) { resolve({ ok: false, error: '返回非 JSON' }); return; }
      resolve({ ok: true, data: data });
    }).catch(function (e) {
      clearTimeout(to);
      resolve({ ok: false, error: (e && e.name === 'AbortError') ? (abortedByExternal ? '请求已终止' : '请求超时') : ('网络错误：' + ((e && e.message) || e)) });
    });
  });
}

function createDashScopeImageTask(cfg, payload) {
  return new Promise(function (resolve) {
    cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
    if (!cfg.apiKey) { resolve({ ok: false, error: '未配置 API Key' }); return; }
    if (!payload || !payload.prompt) { resolve({ ok: false, error: '缺少生图提示词' }); return; }
    var url = cfg.imageEndpoint || DEFAULT_CFG.imageEndpoint;
    var body = generationPayload(cfg, payload);
    var ctrl = new AbortController();
    var externalSignal = signalForPayload(payload);
    var abortedByExternal = false;
    if (externalSignal) {
      if (externalSignal.aborted) { resolve({ ok: false, error: '请求已终止' }); return; }
      externalSignal.addEventListener('abort', function () {
        abortedByExternal = true;
        try { ctrl.abort(); } catch (e) {}
      }, { once: true });
    }
    var to = setTimeout(function () { try { ctrl.abort(); } catch (e) {} }, 60000);
    fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + cfg.apiKey,
        'X-DashScope-Async': 'enable'
      },
      body: JSON.stringify(body),
      signal: ctrl.signal
    }).then(function (r) {
      return r.text().then(function (txt) { return { status: r.status, txt: txt }; });
    }).then(function (resp) {
      clearTimeout(to);
      if (resp.status < 200 || resp.status >= 300) {
        resolve({ ok: false, error: 'HTTP ' + resp.status + ': ' + (resp.txt || '').slice(0, 320) });
        return;
      }
      var data; try { data = JSON.parse(resp.txt); } catch (e) { resolve({ ok: false, error: '创建任务返回非 JSON' }); return; }
      var taskId = data && data.output && data.output.task_id;
      if (!taskId) {
        var imgs = deepFindImages(data);
        if (imgs.length) resolve({ ok: true, taskId: '', images: imgs, raw: data });
        else resolve({ ok: false, error: '未拿到 task_id', raw: data });
        return;
      }
      pollImageTask(cfg, url, taskId, 0, externalSignal).then(function (res) { resolve(res); });
    }).catch(function (e) {
      clearTimeout(to);
      resolve({ ok: false, error: (e && e.name === 'AbortError') ? (abortedByExternal ? '请求已终止' : '创建任务超时') : ('网络错误：' + ((e && e.message) || e)) });
    });
  });
}

function createOpenAIImage(cfg, payload) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  payload = payload || {};
  if (!cfg.apiKey) return Promise.resolve({ ok: false, error: '未配置 API Key' });
  var prompt = ((payload.prompt || '') + claritySuffix(payload.clarity || 'standard')).trim();
  if (payload.negativePrompt) prompt += '\nAvoid: ' + payload.negativePrompt;
  var productImages = productImagesFromPayload(payload);
  var referenceImages = referenceImagesFromPayload(payload);
  var hasInputImage = !!(referenceImages.length || productImages.length);
  var base = (cfg.imageEndpoint || 'https://api.openai.com/v1/images/generations').replace(/\/+$/, '');
  var url = hasInputImage ? base.replace(/\/images\/generations$/, '/images/edits') : base;
  if (hasInputImage) {
    var fd = new FormData();
    fd.append('model', cfg.imageModel || 'gpt-image-2');
    fd.append('prompt', prompt);
    fd.append('size', normalizeSize(payload.size, 'x'));
    fd.append('n', '' + Math.max(1, Math.min(4, parseInt(payload.count, 10) || 1)));
    fd.append('input_fidelity', 'high');
    var intendedEntries = productImages.map(function (img, idx) {
      return { image: img, name: 'product-subject-' + (idx + 1) };
    }).concat(modelImagesFromPayload(payload).map(function (img, idx) {
      return { image: img, name: 'model-reference-' + (idx + 1) };
    })).concat(referenceImages.map(function (image, idx) {
      return { image: image, name: 'style-reference-page-' + (idx + 1) };
    }));
    var uploadEntries = intendedEntries.map(function (entry) {
      var blob = isDataUrl(entry.image) ? blobFromDataUrl(entry.image) : null;
      return blob ? { blob: blob, name: entry.name } : null;
    }).filter(Boolean);
    if (uploadEntries.length !== intendedEntries.length) {
      return Promise.resolve({ ok: false, error: 'OpenAI 编辑接口需要全部参考页、主体图和模特图都是本地上传图片/data URL。为避免静默丢失部分页面证据，已阻止本次生图；请用文件上传或右键导入图片。' });
    }
    var imageField = uploadEntries.length > 1 ? 'image[]' : 'image';
    uploadEntries.forEach(function (entry) {
      fd.append(imageField, entry.blob, entry.name + '.png');
    });
    if (!uploadEntries.length) {
      return Promise.resolve({ ok: false, error: 'OpenAI 编辑接口需要本地上传图片或可转成 Blob 的 data URL；网页 URL 请先右键导入。' });
    }
    return fetchJson(url, { method: 'POST', headers: { 'Authorization': 'Bearer ' + cfg.apiKey }, body: fd, signal: signalForPayload(payload) }, 180000)
      .then(function (res) { if (!res.ok) return res; var imgs = parseImageResponse(res.data); return imgs.length ? { ok: true, images: imgs, raw: res.data } : { ok: false, error: '未解析到图片', raw: res.data }; });
  }
  var body = { model: cfg.imageModel || 'gpt-image-2', prompt: prompt, size: normalizeSize(payload.size, 'x'), n: Math.max(1, Math.min(4, parseInt(payload.count, 10) || 1)) };
  return fetchJson(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + cfg.apiKey }, body: JSON.stringify(body), signal: signalForPayload(payload) }, 180000)
    .then(function (res) { if (!res.ok) return res; var imgs = parseImageResponse(res.data); return imgs.length ? { ok: true, images: imgs, raw: res.data } : { ok: false, error: '未解析到图片', raw: res.data }; });
}

function createMiniMaxImage(cfg, payload) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  payload = payload || {};
  if (!cfg.apiKey) return Promise.resolve({ ok: false, error: '未配置 API Key' });
  var prompt = ((payload.prompt || '') + claritySuffix(payload.clarity || 'standard')).trim();
  if (payload.negativePrompt) prompt += '\nNegative prompt: ' + payload.negativePrompt;
  var prioritized = productImagesFromPayload(payload);
  prioritized = prioritized.concat(referenceImagesFromPayload(payload));
  prioritized = prioritized.concat(modelImagesFromPayload(payload));
  prioritized = Array.from(new Set(prioritized.filter(Boolean)));
  if (prioritized.length > 4) {
    return Promise.resolve({ ok: false, error: 'MiniMax 当前最多接收 4 张参考图，本任务需要同时使用全部商品多角度图、参考图和模特图。为避免丢失主体/风格证据，已阻止截断；请减少非必要模特图，或切换到支持更多图片输入的生图适配器。' });
  }
  var refs = prioritized.map(function (img) {
    return { type: 'general', image_file: imageToProviderValue(img) };
  });
  var body = {
    model: cfg.imageModel || 'image-01',
    prompt: prompt,
    n: Math.max(1, Math.min(4, parseInt(payload.count, 10) || 1)),
    response_format: 'url',
    prompt_optimizer: true
  };
  if (refs.length) body.subject_reference = refs;
  return fetchJson(cfg.imageEndpoint || 'https://api.minimax.io/v1/image_generation', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + cfg.apiKey },
    body: JSON.stringify(body),
    signal: signalForPayload(payload)
  }, 180000).then(function (res) {
    if (!res.ok) return res;
    var imgs = parseImageResponse(res.data);
    return imgs.length ? { ok: true, images: imgs, raw: res.data } : { ok: false, error: '未解析到 MiniMax 图片', raw: res.data };
  });
}

function createZhipuImage(cfg, payload) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  payload = payload || {};
  if (!cfg.apiKey) return Promise.resolve({ ok: false, error: '未配置 API Key' });
  var prompt = ((payload.prompt || '') + claritySuffix(payload.clarity || 'standard')).trim();
  if (payload.negativePrompt) prompt += '\n负面约束：' + payload.negativePrompt;
  var body = {
    model: cfg.imageModel || 'cogview-4-250304',
    prompt: prompt,
    size: normalizeSize(payload.size, 'x'),
    n: Math.max(1, Math.min(4, parseInt(payload.count, 10) || 1))
  };
  return fetchJson(cfg.imageEndpoint || 'https://open.bigmodel.cn/api/paas/v4/images/generations', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + cfg.apiKey },
    body: JSON.stringify(body),
    signal: signalForPayload(payload)
  }, 180000).then(function (res) {
    if (!res.ok) return res;
    var imgs = parseImageResponse(res.data);
    return imgs.length ? { ok: true, images: imgs, raw: res.data } : { ok: false, error: '未解析到智谱图片', raw: res.data };
  });
}

function createVolcengineImage(cfg, payload) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  payload = payload || {};
  if (!cfg.apiKey) return Promise.resolve({ ok: false, error: '未配置 API Key' });
  var prompt = ((payload.prompt || '') + claritySuffix(payload.clarity || 'standard')).trim();
  if (payload.negativePrompt) prompt += '\nNegative prompt: ' + payload.negativePrompt;
  var body = {
    model: cfg.imageModel || VOLC_SEEDREAM_DEFAULT,
    prompt: prompt,
    size: normalizeVolcSeedreamSize(payload.size),
    n: Math.max(1, Math.min(4, parseInt(payload.count, 10) || 1)),
    response_format: 'url'
  };
  var refs = inputImagesFromPayload(payload).map(imageToProviderValue);
  if (refs.length === 1) body.image = refs[0];
  else if (refs.length > 1) body.image = refs;
  return fetchJson(cfg.imageEndpoint || 'https://ark.cn-beijing.volces.com/api/v3/images/generations', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + cfg.apiKey },
    body: JSON.stringify(body),
    signal: signalForPayload(payload)
  }, 180000).then(function (res) {
    if (!res.ok) {
      if (/InvalidEndpointOrModel\.NotFound|does not exist|not have access/i.test(res.error || '')) {
        res.error += '\n火山/豆包生图模型未开通或模型名不对：请在火山方舟控制台复制已开通的 Seedream 模型 ID 或推理接入点 ID，填到“生图模型”输入框。';
      }
      if (/parameter `?size`?|image size must be at least|InvalidParameter/i.test(res.error || '')) {
        res.error += '\nSeedream 5.0-lite 需要 2K/3K 尺寸，本插件已将小尺寸自动映射到同构图比例的 2K 尺寸；请重新点击生图。';
      }
      return res;
    }
    var imgs = parseImageResponse(res.data);
    return imgs.length ? { ok: true, images: imgs, raw: res.data } : { ok: false, error: '未解析到火山/豆包图片', raw: res.data };
  });
}

function geminiUrl(cfg) {
  var model = cfg.imageModel || 'gemini-2.5-flash-image-preview';
  var ep = cfg.imageEndpoint || 'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent';
  ep = ep.replace('{model}', encodeURIComponent(model));
  return ep + (ep.indexOf('?') >= 0 ? '&' : '?') + 'key=' + encodeURIComponent(cfg.apiKey);
}

function annotateGeminiError(cfg, res) {
  if (!res || res.ok) return res;
  var error = res.error || '';
  var endpointUrl = (cfg && cfg.imageEndpoint) || '';
  if (/No available Gemini accounts|no available accounts/i.test(error)) {
    error += '\n当前请求已进入 Gemini 通道，但中转网关没有可用 Gemini 账号池。';
    if (/sub\.shaozhuangai\.com/i.test(endpointUrl)) {
      error += '\n你现在填的是少壮中转地址，不是 Google 官方 Gemini 地址；要直连 Gemini，请把 Base URL 改为 https://generativelanguage.googleapis.com/v1beta，把生图 Endpoint 改为 https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent，并填写 Google AI Studio API Key。';
    }
  }
  if (/API key not valid|INVALID_ARGUMENT|PERMISSION_DENIED/i.test(error) && /generativelanguage\.googleapis\.com/i.test(endpointUrl)) {
    error += '\n请确认这是 Google AI Studio 的 Gemini API Key，并且对应模型已在当前账号/地区可用。';
  }
  return Object.assign({}, res, { error: error });
}

function createGeminiImage(cfg, payload) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  payload = payload || {};
  if (!cfg.apiKey) return Promise.resolve({ ok: false, error: '未配置 API Key' });
  var prompt = ((payload.prompt || '') + claritySuffix(payload.clarity || 'standard')).trim();
  if (payload.negativePrompt) prompt += '\nAvoid: ' + payload.negativePrompt;
  var parts = [{ text: prompt }];
  inputImagesFromPayload(payload).forEach(function (img) { parts.push(imagePartForGemini(img)); });
  var body = { contents: [{ role: 'user', parts: parts }] };
  return fetchJson(geminiUrl(cfg), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: signalForPayload(payload) }, 180000)
    .then(function (res) {
      if (!res.ok) return annotateGeminiError(cfg, res);
      var imgs = parseImageResponse(res.data);
      return imgs.length ? { ok: true, images: imgs, raw: res.data } : { ok: false, error: '未解析到 Nano Banana/Gemini 图片', raw: res.data };
    });
}

function createGenericJsonImage(cfg, payload) {
  cfg = normalizeCfg(cfg);
  payload = payload || {};
  if (!cfg.apiKey) return Promise.resolve({ ok: false, error: '未配置 API Key' });
  var referenceImages = referenceImagesFromPayload(payload);
  var body = {
    model: cfg.imageModel,
    prompt: payload.prompt,
    negative_prompt: payload.negativePrompt || '',
    size: normalizeSize(payload.size, 'x'),
    n: Math.max(1, Math.min(4, parseInt(payload.count, 10) || 1)),
    reference_image: referenceImages[0] || '',
    reference_images: referenceImages,
    product_image: productImagesFromPayload(payload)[0] || '',
    product_images: productImagesFromPayload(payload),
    model_images: modelImagesFromPayload(payload)
  };
  return fetchJson(cfg.imageEndpoint, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + cfg.apiKey }, body: JSON.stringify(body), signal: signalForPayload(payload) }, 180000)
    .then(function (res) {
      if (!res.ok) {
        var rawError = String(res.error || '');
        if (/model_not_found|model[^\n]{0,100}not supported|not supported by any configured account/i.test(rawError)) {
          return {
            ok: false,
            code: 'image_model_not_found',
            modelKind: 'image',
            model: cfg.imageModel,
            error: '生图模型“' + cfg.imageModel + '”当前账号不可用。请打开' + CONFIG_UI_LABEL + '，填写当前账号组实际开通的生图模型名；不会回退到文本模型。'
          };
        }
        return res;
      }
      var imgs = parseImageResponse(res.data);
      return imgs.length ? { ok: true, images: imgs, raw: res.data } : { ok: false, error: '未解析到图片 URL/base64', raw: res.data };
    });
}

function createImageTask(cfg, payload) {
  payload = payload || {};
  cfg = normalizeCfg(cfg);
  if (!productImagesFromPayload(payload).length) {
    return Promise.resolve({ ok: false, error: productSubjectRequiredError() });
  }
  var adapter = (cfg && cfg.imageAdapter) || 'dashscope-wan';
  if (adapter === 'none') return Promise.resolve({ ok: false, error: '当前服务商只支持文本提词，不支持生图。请选择生图适配器。' });
  if (adapter === 'openai-images') return createOpenAIImage(cfg, payload);
  if (adapter === 'minimax-image') return Promise.resolve({ ok: false, error: 'MiniMax 当前图像主体参考接口只适用于人物角色一致性，不能可靠承载商品多角度图与竞品风格图；为避免商品串款或请求失败，本工作流已停用该生图适配器。请切换到支持商品多图编辑的服务商。' });
  if (adapter === 'zhipu-cogview') return Promise.resolve({ ok: false, error: '当前智谱 CogView 接入只发送文字，无法读取商品主体多角度图；为避免商品变形或串款，本工作流已阻止降级生图。请切换到支持图片参考的生图适配器。' });
  if (adapter === 'volcengine-image' || adapter === 'doubao-image') return createVolcengineImage(cfg, payload);
  if (adapter === 'gemini-image' || adapter === 'nano-banana') return createGeminiImage(cfg, payload);
  if (adapter === 'generic-json') return createGenericJsonImage(cfg, payload);
  return createDashScopeImageTask(cfg, payload);
}

function pollImageTask(cfg, endpointUrl, taskId, round, signal) {
  return new Promise(function (resolve) {
    if (signal && signal.aborted) { resolve({ ok: false, error: '请求已终止', taskId: taskId }); return; }
    if (round > 90) { resolve({ ok: false, error: '生图任务超时', taskId: taskId }); return; }
    setTimeout(function () {
      if (signal && signal.aborted) { resolve({ ok: false, error: '请求已终止', taskId: taskId }); return; }
      fetch(taskUrlFrom(endpointUrl, taskId), {
        method: 'GET',
        headers: { 'Authorization': 'Bearer ' + cfg.apiKey },
        signal: signal || undefined
      }).then(function (r) {
        return r.text().then(function (txt) { return { status: r.status, txt: txt }; });
      }).then(function (resp) {
        if (resp.status < 200 || resp.status >= 300) {
          resolve({ ok: false, error: '轮询失败 HTTP ' + resp.status + ': ' + (resp.txt || '').slice(0, 240), taskId: taskId });
          return;
        }
        var data; try { data = JSON.parse(resp.txt); } catch (e) { resolve({ ok: false, error: '轮询返回非 JSON', taskId: taskId }); return; }
        var status = data && data.output && data.output.task_status;
        if (status === 'SUCCEEDED') {
          resolve({ ok: true, taskId: taskId, images: deepFindImages(data), raw: data });
        } else if (status === 'FAILED' || status === 'CANCELED' || status === 'UNKNOWN') {
          resolve({ ok: false, error: '任务失败：' + status, taskId: taskId, raw: data });
        } else {
          pollImageTask(cfg, endpointUrl, taskId, round + 1, signal).then(function (r) { resolve(r); });
        }
      }).catch(function (e) {
        resolve({ ok: false, error: (e && e.name === 'AbortError') ? '请求已终止' : ('轮询网络错误：' + ((e && e.message) || e)), taskId: taskId });
      });
    }, round < 3 ? 1800 : 3000);
  });
}

function arrayBufferToDataUrl(buffer, contentType) {
  var bytes = new Uint8Array(buffer);
  var chunk = 0x8000;
  var parts = [];
  for (var i = 0; i < bytes.length; i += chunk) {
    parts.push(String.fromCharCode.apply(null, bytes.subarray(i, i + chunk)));
  }
  return 'data:' + (contentType || 'image/jpeg') + ';base64,' + btoa(parts.join(''));
}

function fetchAsDataUrl(url) {
  return new Promise(function (resolve) {
    fetch(url).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      var type = r.headers.get('content-type') || 'image/jpeg';
      return r.arrayBuffer().then(function (buf) { return { buf: buf, type: type }; });
    }).then(function (x) {
      resolve({ ok: true, dataUrl: arrayBufferToDataUrl(x.buf, x.type) });
    }).catch(function (e) {
      resolve({ ok: false, error: ((e && e.message) || e) });
    });
  });
}

function sanitizeDownloadFilename(filename) {
  return String(filename || '')
    .replace(/[\\:*?"<>|\u0000-\u001f]/g, '')
    .replace(/\/+/g, '/')
    .replace(/^\/+/, '')
    .slice(0, 180);
}

function imageExtFromUrl(url) {
  var text = String(url || '');
  var match = text.match(/\.(png|jpe?g|webp|gif)(?:[?#]|$)/i);
  if (match) return '.' + match[1].toLowerCase().replace('jpeg', 'jpg');
  if (/^data:image\/jpe?g/i.test(text)) return '.jpg';
  if (/^data:image\/webp/i.test(text)) return '.webp';
  if (/^data:image\/gif/i.test(text)) return '.gif';
  return '.png';
}

function normalizeDownloadItems(input) {
  var raw = Array.isArray(input) ? input : [];
  return raw.map(function (item, idx) {
    if (typeof item === 'string') item = { url: item };
    item = item || {};
    var url = item.url || '';
    if (!url) return null;
    var filename = sanitizeDownloadFilename(item.filename || '');
    if (!filename) {
      var seq = idx + 1;
      filename = '少壮AI主图实验室/image_' + Date.now() + '_' + (seq < 10 ? '0' : '') + seq + imageExtFromUrl(url);
    }
    return { url: url, filename: filename };
  }).filter(Boolean);
}

function downloadAll(items) {
  items = normalizeDownloadItems(items);
  if (!items.length) return Promise.resolve({ ok: false, error: '没有可下载图片' });
  items.forEach(function (item) {
    chrome.downloads.download({
      url: item.url,
      filename: item.filename,
      conflictAction: 'uniquify',
      saveAs: false
    });
  });
  return Promise.resolve({ ok: true, count: items.length });
}

if (typeof globalThis !== 'undefined') {
  globalThis.resolveUnifiedConfigReference = resolveUnifiedConfigReference;
}

if (typeof globalThis !== 'undefined' && globalThis.__SZ_PROMPTLAB_BACKGROUND_TEST_MODE__) {
  globalThis.__SZ_PROMPTLAB_BACKGROUND_TEST_API__ = {
    normalizeCfg: normalizeCfg,
    normalizeHostedTextModel: normalizeHostedTextModel,
    normalizeHostedImageModel: normalizeHostedImageModel,
    chatJson: chatJson,
    createGenericJsonImage: createGenericJsonImage,
    configCatalog: configCatalog,
    resolveUnifiedConfigReference: resolveUnifiedConfigReference,
    testConfigProfile: testConfigProfile,
    normalizeLinkId: normalizeLinkId,
    nestedFieldEntry: nestedFieldEntry,
    contractLinkRecord: contractLinkRecord,
    textJsonPrompt: textJsonPrompt,
    detailPageJsonPrompt: detailPageJsonPrompt,
    validatePromptResponse: validatePromptResponse,
    validateLinkPromptProtocol: validateLinkPromptProtocol,
    validateDetailPromptProtocol: validateDetailPromptProtocol
  };
}

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || !msg.type) return;
  if (msg.type === 'OPEN_CONTEXT_WORKBENCH') {
    openContextWorkbench(msg.payload || {});
    sendResponse({ ok: true });
    return;
  }
  if (msg.type === 'GET_CONTEXT') {
    readConfigProfile('', function (r) { sendResponse(r); });
    return true;
  }
  if (msg.type === 'CONSUME_CONTEXT') {
    chrome.storage.local.remove(CONTEXT_KEY, function () {
      var removeError = chrome.runtime.lastError;
      if (removeError) {
        sendResponse({ ok: false, error: removeError.message || '无法清除右键图片上下文' });
        return;
      }
      sendResponse({ ok: true, consumed: true });
    });
    return true;
  }
  if (msg.type === 'GET_CONFIG_CATALOG') {
    var catalog = configCatalog();
    sendResponse({ ok: true, catalog: catalog, providers: catalog });
    return;
  }
  if (msg.type === 'GET_CONFIG_PROFILE') {
    readConfigProfile(msg.provider || '', function (r) { sendResponse(r); });
    return true;
  }
  if (msg.type === 'SAVE_CONFIG') {
    saveConfigProfile(msg.config, function (r) { sendResponse(r); });
    return true;
  }
  if (msg.type === 'SET_ACTIVE_PROVIDER') {
    setActiveConfigProvider(msg.provider || '', function (r) { sendResponse(r); });
    return true;
  }
  if (msg.type === 'RESOLVE_CONFIG_PROFILE') {
    resolveUnifiedConfigReference(msg.ref || msg).then(sendResponse);
    return true;
  }
  if (msg.type === 'TEST_CONFIG_PROFILE') {
    if (msg.config && typeof msg.config === 'object') {
      resolveConfigAccountKey(function (accountKey) {
        testConfigProfile(Object.assign({}, msg.config, { _accountKey: accountKey }), msg.timeoutMs).then(sendResponse);
      });
      return true;
    }
    readConfigProfile(msg.provider || '', function (profile) {
      if (!profile || !profile.ok || !profile.config) { sendResponse(profile || { ok: false, error: '无法读取 API 配置' }); return; }
      testConfigProfile(Object.assign({}, profile.config, { _accountKey: profile.accountKey }), msg.timeoutMs).then(sendResponse);
    });
    return true;
  }
  if (msg.type === 'OPEN_UNIFIED_API_SETTINGS') {
    openUnifiedApiSettings(sendResponse);
    return true;
  }
  if (msg.type === 'GET_BUSINESS_KNOWLEDGE') {
    readBusinessKnowledgeProfile(sendResponse);
    return true;
  }
  if (msg.type === 'SAVE_BUSINESS_KNOWLEDGE') {
    saveBusinessKnowledgeProfile(msg.knowledge || {}, sendResponse);
    return true;
  }
  if (msg.type === 'CLEAR_BUSINESS_KNOWLEDGE') {
    clearBusinessKnowledgeProfile(sendResponse);
    return true;
  }
  if (msg.type === 'FETCH_IMAGE') { fetchAsDataUrl(msg.url).then(sendResponse); return true; }
  if (msg.type === 'ANALYZE_IMAGE') { analyzeImage(msg.config, msg.payload).then(sendResponse); return true; }
  if (msg.type === 'BUILD_LINK_PROMPT') { buildLinkPrompt(msg.config, msg.payload).then(sendResponse); return true; }
  if (msg.type === 'BUILD_DETAIL_PROMPT') { buildDetailPrompt(msg.config, msg.payload).then(sendResponse); return true; }
  if (msg.type === 'GENERATE_IMAGE') {
    var jobId = msg.jobId || (msg.payload && msg.payload._jobId) || '';
    if (jobId) {
      activeJobs[jobId] = new AbortController();
      msg.payload = Object.assign({}, msg.payload || {}, { _jobId: jobId });
    }
    createImageTask(msg.config, msg.payload).then(function (res) {
      if (jobId) delete activeJobs[jobId];
      sendResponse(res);
    });
    return true;
  }
  if (msg.type === 'CANCEL_GENERATION') {
    if (msg.jobId && activeJobs[msg.jobId]) {
      try { activeJobs[msg.jobId].abort(); } catch (e) {}
      delete activeJobs[msg.jobId];
      sendResponse({ ok: true, cancelled: true });
    } else {
      sendResponse({ ok: true, cancelled: false });
    }
    return true;
  }
  if (msg.type === 'DOWNLOAD_ALL') { downloadAll(msg.items || msg.urls).then(sendResponse); return true; }
});
