'use strict';

var DEFAULT_CFG = {
  provider: 'openai-compatible',
  imageAdapter: 'generic-json',
  visionBaseUrl: 'https://sub.shaozhuangai.com/v1',
  visionModel: 'chatGPT5.5',
  textModel: 'chatGPT5.5',
  imageEndpoint: 'https://sub.shaozhuangai.com/v1/images/generations',
  imageModel: 'image2',
  apiKey: ''
};
var VOLC_SEEDREAM_DEFAULT = 'doubao-seedream-5-0-260128';
var LINKMATRIX_JSON_KEY = 'sycm_linkmatrix_json';
var DETAIL_DEFAULT_SCREEN_COUNT = 10;
var promptLabTestSend = null;
var sourceFingerprintCache = [];
var PRESETS = {
  dashscope: {
    provider: 'dashscope',
    imageAdapter: 'dashscope-wan',
    visionBaseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
    visionModel: 'qwen-vl-plus',
    textModel: 'qwen-plus',
    imageEndpoint: 'https://dashscope.aliyuncs.com/api/v1/services/aigc/image-generation/generation',
    imageModel: 'wan2.7-image'
  },
  'deepseek-v4': {
    provider: 'deepseek-v4',
    imageAdapter: 'none',
    visionBaseUrl: 'https://api.deepseek.com',
    visionModel: '',
    textModel: 'deepseek-v4-flash',
    imageEndpoint: '',
    imageModel: ''
  },
  minimax: {
    provider: 'minimax',
    imageAdapter: 'none',
    visionBaseUrl: 'https://api.minimax.io/v1',
    visionModel: 'MiniMax-M2.1',
    textModel: 'MiniMax-M2.1',
    imageEndpoint: '',
    imageModel: ''
  },
  zhipu: {
    provider: 'zhipu',
    imageAdapter: 'zhipu-cogview',
    visionBaseUrl: 'https://open.bigmodel.cn/api/paas/v4',
    visionModel: 'glm-4v-plus',
    textModel: 'glm-4-plus',
    imageEndpoint: 'https://open.bigmodel.cn/api/paas/v4/images/generations',
    imageModel: 'cogview-4-250304'
  },
  doubao: {
    provider: 'doubao',
    imageAdapter: 'doubao-image',
    visionBaseUrl: 'https://ark.cn-beijing.volces.com/api/v3',
    visionModel: 'doubao-seed-evolving',
    textModel: 'doubao-seed-evolving',
    imageEndpoint: 'https://ark.cn-beijing.volces.com/api/v3/images/generations',
    imageModel: VOLC_SEEDREAM_DEFAULT
  },
  openai: {
    provider: 'openai',
    imageAdapter: 'openai-images',
    visionBaseUrl: 'https://api.openai.com/v1',
    visionModel: 'gpt-5-mini',
    textModel: 'gpt-5-mini',
    imageEndpoint: 'https://api.openai.com/v1/images/generations',
    imageModel: 'gpt-image-2'
  },
  'nano-banana': {
    provider: 'nano-banana',
    imageAdapter: 'nano-banana',
    visionBaseUrl: 'https://generativelanguage.googleapis.com/v1beta',
    visionModel: 'gemini-2.5-flash-image-preview',
    textModel: 'gemini-2.5-flash',
    imageEndpoint: 'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent',
    imageModel: 'gemini-2.5-flash-image-preview'
  },
  'openai-compatible': {
    provider: 'openai-compatible',
    imageAdapter: 'generic-json',
    visionBaseUrl: 'https://sub.shaozhuangai.com/v1',
    visionModel: 'chatGPT5.5',
    textModel: 'chatGPT5.5',
    imageEndpoint: 'https://sub.shaozhuangai.com/v1/images/generations',
    imageModel: 'image2'
  }
};
var HOSTED_TEXT_MODEL_MIGRATIONS = {
  'chatgpt5.6': 'chatGPT5.5',
  'gpt-5.5': 'chatGPT5.5'
};
var HOSTED_IMAGE_MODEL_MIGRATIONS = {
  'gpt-image-2': 'image2'
};
var sampleLink = {
  "链接编号": "L001",
  "链接分组": "差异化链接",
  "链接定位": "家庭厨房鲜味升级",
  "主推关键词": "蚝油｜鲜味｜家常炒菜｜厨房调味",
  "用户场景需求": "家庭做饭人群在家常炒菜、拌馅和烧菜时需要稳定提鲜增香",
  "差异化定位逻辑": "用真实菜品挂汁效果证明一勺提鲜，不复刻竞品包装",
  "标题结构": "定位词路 + 核心人群 + 核心功能 + 场景",
  "标题定位词路": "鲜味蚝油 + 家庭厨房 + 炒菜拌馅",
  "商品标题": "鲜味蚝油家用炒菜拌馅提鲜增香厨房调味大瓶装",
  "主图核心文案": "一勺爆鲜，家常菜更香",
  "详情页定位": "用真实菜品效果建立家庭提鲜信任",
  "详情页文案": "一勺挂汁提鲜，炒菜拌馅都适用",
  "详情文案逻辑": "家庭痛点 -> 烹饪场景 -> 挂汁证明 -> 使用方法 -> 信任收口"
};
var sampleDetailLink = {
  "链接编号": "L001",
  "链接定位": "儿童床边同睡更安心",
  "主推关键词": "拼接床｜儿童床｜床边加宽｜无缝拼接",
  "用户场景需求": "亲子家庭需要贴合大床、稳定承托且高度可调的床边同睡空间",
  "差异化定位逻辑": "用贴合对比和结构细节证明稳定承托与可调节，不夸张安全承诺",
  "标题结构": "定位词路 + 核心人群 + 核心功能 + 场景",
  "标题定位词路": "儿童拼接床 + 亲子家庭 + 床边加宽",
  "商品标题": "儿童软艺拼接床加宽床边可调节无缝同睡床",
  "主图核心文案": "床边同睡，更安心",
  "详情页定位": "用贴合大床与结构证明建立亲子同睡信任",
  "详情页文案": "稳定承托，高度可调，床边同睡更从容",
  "详情文案逻辑": "同睡痛点 -> 贴合场景 -> 结构证明 -> 调节步骤 -> 信任收口"
};

var $ = function (id) { return document.getElementById(id); };
var PRODUCT_ANGLES = {
  front: { preview: 'productFrontPreview', file: 'productFrontFile', url: 'productFrontUrl', label: '正视图' },
  side: { preview: 'productSidePreview', file: 'productSideFile', url: 'productSideUrl', label: '侧视图' },
  back: { preview: 'productBackPreview', file: 'productBackFile', url: 'productBackUrl', label: '背视图' }
};
var MODEL_ANGLES = {
  front: { preview: 'modelFrontPreview', file: 'modelFrontFile', url: 'modelFrontUrl', label: '模特正视图' },
  side: { preview: 'modelSidePreview', file: 'modelSideFile', url: 'modelSideUrl', label: '模特侧视图' },
  back: { preview: 'modelBackPreview', file: 'modelBackFile', url: 'modelBackUrl', label: '模特背视图' }
};
var state = {
  refImage: '',
  refImages: [],
  productImage: '',
  productImages: { front: '', side: '', back: '' },
  modelImages: { front: '', side: '', back: '' },
  results: [],
  linkList: [],
  lastLink: null,
  analysis: null,
  referenceAnalysis: null,
  referencePrompts: { main: null, detail: null },
  linkPrompts: { main: {}, detail: {} },
  linkPromptOrder: { main: [], detail: [] },
  activePromptRecord: null,
  activeJobId: '',
  activeJobIds: {},
  batchPromptToken: 0,
  batchGenerationToken: 0,
  cancelledJobs: {},
  stopRequested: false,
  detailMode: 'reference',
  actionItem: null,
  guideItem: null,
  contextItem: null,
  contextAuto: false,
  imagePreviewPreviousFocus: null,
  detailStitchSelectionOrder: [],
  skuProducts: [],
  skuTemplate: '',
  skuResults: [],
  skuActive: false,
  skuMax: 20,
  skuProductSeq: 0,
  skuSelections: {},
  skuTaskStatus: {},
  skuActiveJobIds: {},
  skuBatchToken: 0,
  awaitingUnifiedConfigRefresh: false
};

function currentLabMode() {
  if (document.body && document.body.classList.contains('sku-lab-mode')) return 'sku';
  return document.body && document.body.classList.contains('detail-lab-mode') ? 'detail' : 'main';
}

function setupLabMode(mode, detailMode) {
  var isDetail = mode === 'detail';
  var isSku = mode === 'sku';
  if (document.body) {
    document.body.classList.toggle('detail-lab-mode', isDetail);
    document.body.classList.toggle('sku-lab-mode', isSku);
    document.body.classList.toggle('main-lab-mode', !isDetail && !isSku);
  }
  document.title = isSku ? '少壮AI批量SKU共创工作台' : (isDetail ? '少壮AI详情页生成实验室' : '少壮AI主图生成实验室');
  if ($('labHeroEyebrow')) $('labHeroEyebrow').textContent = isSku ? 'BATCH SKU LAB' : (isDetail ? 'DETAIL PROMPT LAB' : 'IMAGE PROMPT LAB');
  if ($('labHeroTitle')) $('labHeroTitle').textContent = isSku ? '批量 SKU 共创工作台' : (isDetail ? '详情页生成实验室' : '主图生成实验室');
  if ($('labHeroSubtitle')) {
    $('labHeroSubtitle').textContent = isSku
      ? '素材组织、稳定编号、逐项映射、生成预检、有限并发和失败重试。'
      : (isDetail
        ? '四步完成：选择参考图或链接定位 JSON → 上传必填产品主体图（模特可选）→ 严格提词 → 按提示词类型生成详情。'
        : '参考图提词、链接清单主图方向、参考图/主体图生图和批量下载。');
  }
  if ($('loadSampleBtn')) $('loadSampleBtn').textContent = isSku ? '载入SKU模板' : (isDetail ? '载入详情示例' : '载入示例');
  setText('positioningLabel', isDetail ? '详情页定位' : '链接定位');
  setText('imageCopyLabel', isDetail ? '详情页文案方向' : '主图文案方向');
  if ($('positioning')) $('positioning').placeholder = isDetail ? '例如：从痛点到解决方案的详情叙事' : '例如：家庭厨房鲜味升级';
  if ($('imageCopy')) $('imageCopy').placeholder = isDetail ? '例如：首屏利益点与逐屏承接文案' : '例如：一勺爆鲜，家常菜提味';
  if (!isDetail && $('buildPromptBtn')) $('buildPromptBtn').textContent = '生成当前链接提示词';
  if (isDetail) {
    setDetailMode(detailMode || 'reference');
    setPill('detailState', '详情工作台', '');
    setPill('contextState', '可上传详情参考图', '');
    setPill('linkState', '可粘贴详情链接 JSON', '');
  }
  if (isSku) setPill('skuState', 'SKU 工作台', '');
  syncGenerationModeLabels(isDetail);
}

function applySkuQueryParams(params) {
  if (!params) return;
  var max = parseInt(params.get('skuMax'), 10);
  var resolution = params.get('skuResolution');
  var ratio = params.get('skuRatio');
  if (max === 5 || max === 10 || max === 20) state.skuMax = max;
  if (resolution && $('skuResolution')) $('skuResolution').value = resolution;
  if (ratio && $('skuRatio')) $('skuRatio').value = ratio;
}

function send(type, payload) {
  function finish(resp) {
    resp = resp || { ok: false, error: '无响应' };
    applyModelFallbackFromResponse(resp);
    return resp;
  }
  if (promptLabTestSend) {
    try { return Promise.resolve(promptLabTestSend(type, payload || {})).then(finish); }
    catch (e) { return Promise.resolve({ ok: false, error: (e && e.message) || e }); }
  }
  return new Promise(function (resolve) {
    try {
      chrome.runtime.sendMessage(Object.assign({ type: type }, payload || {}), function (resp) {
        var err = chrome.runtime.lastError;
        if (err) resolve({ ok: false, error: err.message });
        else resolve(finish(resp));
      });
    } catch (e) { resolve({ ok: false, error: (e && e.message) || e }); }
  });
}

function openBusinessKnowledge() {
  try {
    if (chrome && chrome.tabs && chrome.tabs.create && chrome.runtime && chrome.runtime.getURL) {
      chrome.tabs.create({ url: chrome.runtime.getURL('labs/business-knowledge/knowledge.html') });
      return;
    }
  } catch (error) {}
  try { window.open('../business-knowledge/knowledge.html', '_blank'); } catch (error2) {}
}

function refreshBusinessKnowledgeStatus() {
  var button = $('openKnowledgeBtn');
  if (!button) return Promise.resolve(null);
  if (typeof chrome === 'undefined' || !chrome.runtime) {
    button.textContent = '知识库 · 未导入';
    button.classList.remove('warn');
    return Promise.resolve({ ok: true, preview: true });
  }
  return send('GET_BUSINESS_KNOWLEDGE').then(function (resp) {
    var summary = resp && resp.ok && resp.summary;
    button.classList.toggle('ready', !!(summary && summary.ready));
    button.classList.toggle('warn', !!(resp && !resp.ok));
    button.textContent = summary && summary.ready
      ? ('知识库 · ' + summary.sourceCount + '份')
      : '知识库 · 未导入';
    if ($('skuKnowledgeState')) {
      $('skuKnowledgeState').textContent = summary && summary.ready
        ? ('业务知识库已关联：' + summary.sourceCount + ' 份资料、' + summary.fieldCount + ' 项规则。SKU 仅引用品牌、文案、视觉与合规边界，不会臆造款式属性。')
        : '业务知识库尚未导入：当前 SKU 只按主体图、视觉模板、属性文本和全局设计策略生成。';
      $('skuKnowledgeState').classList.toggle('ready', !!(summary && summary.ready));
    }
    return resp;
  });
}

function applyModelFallbackFromResponse(resp) {
  var fallback = resp && resp.modelFallback;
  if (!fallback || !fallback.to) return;
  ['visionModel', 'textModel'].forEach(function (id) {
    var input = $(id);
    if (input && sameModelValue(input.value, fallback.from)) input.value = fallback.to;
  });
  updateConfigSummary(cfgFromForm());
  setPill('configState', '已自动切换到 ' + fallback.to, 'ok');
}

function sameModelValue(a, b) {
  return String(a || '').trim().toLowerCase() === String(b || '').trim().toLowerCase();
}

function setPill(id, text, kind) {
  var el = $(id);
  if (!el) return;
  el.textContent = text;
  el.className = 'pill' + (kind ? ' ' + kind : '');
}

function setText(id, text) {
  var el = $(id);
  if (el) el.textContent = text;
}

function scrollToPanel(id, block) {
  var el = $(id);
  if (el && el.scrollIntoView) el.scrollIntoView({ behavior: 'smooth', block: block || 'start' });
}

function generationIdleText() {
  return currentLabMode() === 'detail' ? '待生详情图' : '未生成';
}

function syncGenerationModeLabels(isDetail) {
  setText('generationTitle', isDetail ? '详情生图结果' : '生图参数');
  setText('generateBtn', '参考图反推覆盖提示词并生图');
  setText('linkNumberGenerateBtn', '按编号并发生图');
  setText('resultsTitle', isDetail ? '详情图结果' : '生成结果');
  setText('resultsHint', isDetail ? '结果卡片 / 下载全部 / 引导重生 / 勾选拼接长详情' : '结果素材');
  setPill('generateState', generationIdleText(), '');
  syncGenerationParamSummary();
  if (isDetail) syncDetailWorkflowUi();
}

function providerLabel(provider) {
  var map = {
    dashscope: '千问 / DashScope',
    'deepseek-v4': 'DeepSeek V4',
    minimax: 'MiniMax',
    zhipu: '智谱 GLM / CogView',
    doubao: '集梦 / 豆包 / 火山方舟',
    openai: 'ChatGPT / GPT Image 2',
    'nano-banana': 'Nano Banana / Gemini',
    'openai-compatible': '少壮托管 / Auto Mode'
  };
  return map[provider] || provider || '未选择';
}

function maskKey(key) {
  if (!key) return '未填写 API Key';
  if (key.length <= 8) return '已填写 API Key';
  return 'Key ' + key.slice(0, 4) + '...' + key.slice(-4);
}

function updateProviderRail(provider) {
  var rail = $('providerRail');
  if (!rail) return;
  Array.prototype.forEach.call(rail.querySelectorAll('[data-provider-pick]'), function (btn) {
    btn.classList.toggle('active', btn.getAttribute('data-provider-pick') === provider);
  });
}

function syncModelDatalistTargets(cfg) {
  cfg = cfg || cfgFromForm();
  var hostedText = isShaozhuangHostedConfig(cfg);
  var hostedImage = isShaozhuangHostedImageConfig(cfg);
  if ($('visionModel')) $('visionModel').setAttribute('list', hostedText ? 'hostedVisionModelOptions' : 'visionModelOptions');
  if ($('textModel')) $('textModel').setAttribute('list', hostedText ? 'hostedTextModelOptions' : 'textModelOptions');
  if ($('imageModel')) $('imageModel').setAttribute('list', hostedImage ? 'hostedImageModelOptions' : 'imageModelOptions');
  setText(
    'advancedModelHint',
    (hostedText || hostedImage)
      ? '少壮托管请使用网关别名；gpt-* 模型请切换 ChatGPT 直连'
      : '需要直连或排查接口时再展开'
  );
}

function updateConfigSummary(cfg) {
  if (!cfg) cfg = cfgFromForm();
  var providerName = providerLabel(cfg.provider);
  var title = $('configProviderName');
  var sub = $('configSummaryText');
  var chips = $('configModelChips');
  if (title) title.textContent = providerName;
  if (sub) {
    sub.textContent = [
      maskKey(cfg.apiKey),
      cfg.imageAdapter === 'none' ? '仅文本提词' : '生图：' + (cfg.imageModel || '未设定'),
      '文本：' + (cfg.textModel || cfg.visionModel || '未设定')
    ].join(' · ');
  }
  if (chips) {
    chips.innerHTML = '';
    [
      ['提词', cfg.visionModel || cfg.textModel || '未设定'],
      ['文本', cfg.textModel || '未设定'],
      ['生图', cfg.imageModel || (cfg.imageAdapter === 'none' ? '不启用' : '未设定')]
    ].forEach(function (item) {
      var chip = document.createElement('span');
      chip.textContent = item[0] + '：' + item[1];
      chips.appendChild(chip);
    });
  }
  updateProviderRail(cfg.provider);
  syncModelDatalistTargets(cfg);
}

function cfgFromForm() {
  var provider = $('provider').value || DEFAULT_CFG.provider;
  var preset = presetForProvider(provider);
  return normalizeCfg({
    provider: provider,
    imageAdapter: $('imageAdapter').value || preset.imageAdapter,
    apiKey: $('apiKey').value.trim(),
    visionBaseUrl: $('visionBaseUrl').value.trim() || preset.visionBaseUrl || DEFAULT_CFG.visionBaseUrl,
    visionModel: $('visionModel').value.trim() || preset.visionModel || DEFAULT_CFG.visionModel,
    textModel: $('textModel').value.trim() || preset.textModel || DEFAULT_CFG.textModel,
    imageEndpoint: $('imageEndpoint').value.trim() || preset.imageEndpoint || DEFAULT_CFG.imageEndpoint,
    imageModel: $('imageModel').value.trim() || preset.imageModel || DEFAULT_CFG.imageModel
  });
}

function isShaozhuangHostedEndpoint(provider, url, fallbackUrl) {
  return !!(provider === 'openai-compatible' && /(^|\.)sub\.shaozhuangai\.com$/i.test((function () {
    try { return new URL(url || fallbackUrl).hostname; }
    catch (e) { return ''; }
  })()));
}

function isShaozhuangHostedConfig(cfg) {
  return !!(cfg && isShaozhuangHostedEndpoint(cfg.provider, cfg.visionBaseUrl, DEFAULT_CFG.visionBaseUrl));
}

function isShaozhuangHostedImageConfig(cfg) {
  return !!(cfg && isShaozhuangHostedEndpoint(cfg.provider, cfg.imageEndpoint, DEFAULT_CFG.imageEndpoint));
}

function normalizeHostedTextModel(cfg, model) {
  var value = String(model || '').trim();
  if (!value || !isShaozhuangHostedConfig(cfg)) return value;
  return HOSTED_TEXT_MODEL_MIGRATIONS[value.toLowerCase()] || value;
}

function normalizeHostedImageModel(cfg, model) {
  var value = String(model || '').trim();
  if (!value || !isShaozhuangHostedImageConfig(cfg)) return value;
  return HOSTED_IMAGE_MODEL_MIGRATIONS[value.toLowerCase()] || value;
}

function normalizeCfg(cfg) {
  var incoming = Object.assign({}, cfg || {});
  ['provider', 'imageAdapter', 'visionBaseUrl', 'visionModel', 'textModel', 'imageEndpoint', 'imageModel', 'apiKey'].forEach(function (field) {
    if (typeof incoming[field] === 'string') incoming[field] = incoming[field].trim();
  });
  var provider = incoming.provider || DEFAULT_CFG.provider;
  var preset = PRESETS[provider] || {};
  cfg = Object.assign({}, DEFAULT_CFG, preset, incoming);
  if (cfg.provider === 'jimeng') cfg.provider = 'doubao';
  if (cfg.imageAdapter === 'jimeng-image') cfg.imageAdapter = 'doubao-image';
  if (cfg.imageAdapter === 'volcengine-image') cfg.imageAdapter = 'doubao-image';
  if (cfg.imageAdapter === 'gemini-image') cfg.imageAdapter = 'nano-banana';
  if (cfg.provider === 'minimax' && cfg.imageAdapter === 'minimax-image') cfg.imageAdapter = 'none';
  preset = PRESETS[cfg.provider] || preset || {};
  ['imageAdapter', 'visionBaseUrl', 'visionModel', 'textModel', 'imageEndpoint', 'imageModel'].forEach(function (field) {
    if (!cfg[field] && preset[field]) cfg[field] = preset[field];
  });
  if (cfg.provider === 'openai-compatible') {
    if (!cfg.visionBaseUrl || cfg.visionBaseUrl === 'https://api.example.com/v1') cfg.visionBaseUrl = PRESETS['openai-compatible'].visionBaseUrl;
    if (!cfg.imageEndpoint || cfg.imageEndpoint === 'https://api.example.com/v1/images/generations') cfg.imageEndpoint = PRESETS['openai-compatible'].imageEndpoint;
    if (!cfg.visionModel || cfg.visionModel === 'vision-model' || cfg.visionModel === 'chat-model') cfg.visionModel = PRESETS['openai-compatible'].visionModel;
    if (!cfg.textModel || cfg.textModel === 'chat-model' || cfg.textModel === 'vision-model') cfg.textModel = PRESETS['openai-compatible'].textModel;
    if (!cfg.imageModel || cfg.imageModel === 'image-model') cfg.imageModel = PRESETS['openai-compatible'].imageModel;
    cfg.visionModel = normalizeHostedTextModel(cfg, cfg.visionModel);
    cfg.textModel = normalizeHostedTextModel(cfg, cfg.textModel);
    cfg.imageModel = normalizeHostedImageModel(cfg, cfg.imageModel);
  }
  var isVolc = cfg.provider === 'doubao' || /^https:\/\/ark\.cn-beijing\.volces\.com/.test(cfg.visionBaseUrl || '');
  if (isVolc) {
    if (!cfg.visionModel || /^doubao-1\.5/.test(cfg.visionModel)) cfg.visionModel = 'doubao-seed-evolving';
    if (!cfg.textModel || /^doubao-1\.5/.test(cfg.textModel)) cfg.textModel = 'doubao-seed-evolving';
    if (!cfg.imageEndpoint) cfg.imageEndpoint = PRESETS.doubao.imageEndpoint;
    if (!cfg.imageModel || /^doubao-seedream-3-0/i.test(cfg.imageModel)) cfg.imageModel = VOLC_SEEDREAM_DEFAULT;
  }
  return cfg;
}

function applyCfg(cfg) {
  cfg = normalizeCfg(cfg);
  $('provider').value = cfg.provider || 'dashscope';
  $('imageAdapter').value = cfg.imageAdapter || 'dashscope-wan';
  $('apiKey').value = cfg.apiKey || '';
  $('visionBaseUrl').value = cfg.visionBaseUrl || DEFAULT_CFG.visionBaseUrl;
  $('visionModel').value = cfg.visionModel || DEFAULT_CFG.visionModel;
  $('textModel').value = cfg.textModel || DEFAULT_CFG.textModel;
  $('imageEndpoint').value = cfg.imageEndpoint || DEFAULT_CFG.imageEndpoint;
  $('imageModel').value = cfg.imageModel || DEFAULT_CFG.imageModel;
  setPill('configState', cfg.apiKey ? '已配置' : '未配置', cfg.apiKey ? 'ok' : 'warn');
  updateConfigSummary(cfg);
  return cfg;
}

function presetForProvider(provider) {
  return normalizeCfg(Object.assign({ apiKey: '' }, PRESETS[provider] || PRESETS.dashscope));
}

function applyProviderPreset(provider) {
  return applyCfg(presetForProvider(provider));
}

var providerLoadSeq = 0;
function loadProviderProfile(provider) {
  var seq = ++providerLoadSeq;
  setPill('configState', '正在载入已保存配置...', '');
  send('GET_CONFIG_PROFILE', { provider: provider }).then(function (r) {
    if (seq !== providerLoadSeq) return;
    if (r && r.ok && r.config) {
      applyCfg(r.config);
      send('SET_ACTIVE_PROVIDER', { provider: provider });
      setPill(
        'configState',
        r.migrated ? '已自动修复旧模型配置' : (r.saved ? '已载入账号配置' : '已载入服务商预设'),
        (r.saved || r.migrated) ? 'ok' : ''
      );
      return;
    }
    applyProviderPreset(provider);
    send('SET_ACTIVE_PROVIDER', { provider: provider });
    setPill('configState', '新服务商预设，保存后生效', '');
  });
}

function saveCfg() {
  var cfg = cfgFromForm();
  // 保存前立即把官方托管别名回显到表单，避免界面仍显示直连 OpenAI 模型名。
  applyCfg(cfg);
  send('SAVE_CONFIG', { config: cfg }).then(function (r) {
    setPill('configState', r && r.ok ? '已保存到账号配置' : '保存失败', r && r.ok ? 'ok' : 'warn');
    if (r && r.ok) setTimeout(closeConfigModal, 180);
  });
}

function openConfigModal() {
  var modal = $('configModal');
  if (modal) modal.hidden = false;
  updateConfigSummary(cfgFromForm());
  if ($('provider')) $('provider').focus();
}

function unifiedApiSettingsUnavailable(resp) {
  if (!resp) return false;
  var code = String(resp.code || resp.errorCode || '').toLowerCase();
  return resp.unavailable === true || code === 'unavailable';
}

function openUnifiedApiSettings() {
  setPill('runState', '正在打开插件启动界面的统一 API 设置...', '');
  return send('OPEN_UNIFIED_API_SETTINGS', { source: 'promptlab' }).then(function (resp) {
    if (resp && resp.ok) {
      state.awaitingUnifiedConfigRefresh = true;
      setPill('runState', '已打开插件启动界面的统一 API 设置', 'ok');
      return { ok: true, centralized: true, response: resp };
    }
    // 独立实验室没有主插件启动页，后台明确标记 unavailable 时才回退到原配置弹窗。
    // 其他通信故障不开启第二套配置，避免主插件出现两个配置入口。
    if (unifiedApiSettingsUnavailable(resp)) {
      openConfigModal();
      setPill('configState', '独立版本地配置', '');
      setPill('runState', '独立实验室使用当前 API 配置弹窗', '');
      return { ok: true, centralized: false, fallback: true, response: resp };
    }
    var error = (resp && resp.error) || '后台未响应';
    setPill('runState', '统一 API 设置打开失败：' + error, 'warn');
    return { ok: false, centralized: true, error: error, response: resp };
  });
}

function closeConfigModal() {
  var modal = $('configModal');
  if (modal) modal.hidden = true;
}

function fileToDataUrl(file) {
  return new Promise(function (resolve, reject) {
    var rd = new FileReader();
    rd.onload = function () { resolve(rd.result); };
    rd.onerror = function () { reject(rd.error); };
    rd.readAsDataURL(file);
  });
}

function imageToOptimizedDataUrl(src, maxSide, quality) {
  maxSide = maxSide || 1280;
  quality = quality || 0.86;
  return new Promise(function (resolve) {
    var img = new Image();
    img.onload = function () {
      var w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
      if (!w || !h) { resolve(src); return; }
      var scale = Math.min(1, maxSide / Math.max(w, h));
      var cw = Math.max(1, Math.round(w * scale));
      var ch = Math.max(1, Math.round(h * scale));
      var canvas = document.createElement('canvas');
      canvas.width = cw; canvas.height = ch;
      var ctx = canvas.getContext('2d');
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, cw, ch);
      ctx.drawImage(img, 0, 0, cw, ch);
      resolve(canvas.toDataURL('image/jpeg', quality));
    };
    img.onerror = function () { resolve(src); };
    img.src = src;
  });
}

function fileToOptimizedDataUrl(file) {
  return fileToDataUrl(file).then(function (url) { return imageToOptimizedDataUrl(url, 1280, 0.86); });
}

function renderPreview(id, src, label) {
  var box = $(id);
  if (!box) return;
  var compact = box.classList.contains('compact-preview');
  if (!src) {
    box.className = compact ? 'preview empty compact-preview' : 'preview empty';
    box.textContent = label;
    return;
  }
  box.className = compact ? 'preview compact-preview' : 'preview';
  box.innerHTML = '';
  var img = document.createElement('img');
  img.src = src;
  img.alt = label;
  box.appendChild(img);
}

function parseReferenceUrls(input) {
  var text = String(input || '').trim();
  if (!text) return [];
  var matches = text.match(/data:image\/[a-zA-Z0-9.+-]+;base64,[A-Za-z0-9+/=]+|https?:\/\/[^\s，,]+/g) || [];
  return matches.map(normalizeImageUrl).filter(Boolean).slice(0, 6);
}

function referenceImageList() {
  var out = [];
  (state.refImages || []).concat(state.refImage || '').concat(parseReferenceUrls($('refUrl') ? $('refUrl').value : '')).forEach(function (image) {
    image = normalizeImageUrl(image);
    if (image && out.indexOf(image) < 0 && out.length < 6) out.push(image);
  });
  return out;
}

function renderReferencePreviews() {
  var box = $('refPreview');
  if (!box) return;
  var images = referenceImageList();
  if ($('refImageCount')) $('refImageCount').textContent = images.length + ' / 6';
  box.innerHTML = '';
  if (!images.length) {
    box.className = 'preview reference-preview-grid empty';
    box.textContent = '上传 1-6 张页面图，按顺序学习故事与版式';
    return;
  }
  box.className = 'preview reference-preview-grid';
  images.forEach(function (src, idx) {
    var item = document.createElement('div');
    item.className = 'reference-preview-item';
    var img = document.createElement('img');
    img.src = src;
    img.alt = '参考页第 ' + (idx + 1) + ' 张';
    var order = document.createElement('span');
    order.className = 'reference-preview-order';
    order.textContent = '第' + (idx + 1) + '页';
    var remove = document.createElement('button');
    remove.className = 'reference-preview-remove';
    remove.type = 'button';
    remove.title = '移除第 ' + (idx + 1) + ' 张参考图';
    remove.setAttribute('aria-label', remove.title);
    remove.textContent = '×';
    remove.addEventListener('click', function () {
      var next = referenceImageList().filter(function (_, imageIndex) { return imageIndex !== idx; });
      var urlText = next.filter(function (value) { return /^https?:\/\//.test(value); }).join(' ');
      setRefImages(next, urlText);
    });
    item.appendChild(img);
    item.appendChild(order);
    item.appendChild(remove);
    box.appendChild(item);
  });
}

function setRefImages(images, urlText) {
  var next = [];
  (images || []).forEach(function (image) {
    image = normalizeImageUrl(image);
    if (image && next.indexOf(image) < 0 && next.length < 6) next.push(image);
  });
  var previousKey = (state.refImages || []).join('|');
  var changed = previousKey !== next.join('|');
  state.refImages = next;
  state.refImage = next[0] || '';
  if (changed) {
    state.referenceAnalysis = null;
    state.analysis = null;
    state.referencePrompts.main = null;
    state.referencePrompts.detail = null;
    if (state.activePromptRecord && state.activePromptRecord.source === 'reference') state.activePromptRecord = null;
  }
  if (urlText != null) $('refUrl').value = urlText;
  renderReferencePreviews();
  setPill('contextState', next.length ? ('已载入参考页 ' + next.length + ' / 6') : '等待图片', next.length ? 'ok' : '');
  syncDetailWorkflowUi();
}

function setRefImage(src, urlText) {
  setRefImages(src ? [src] : [], urlText);
}

function addRefImages(images) {
  var combined = referenceImageList().concat(images || []);
  setRefImages(combined, $('refUrl') ? $('refUrl').value : null);
  return referenceImageList();
}

function productPlaceholder(kind) {
  if (kind === 'side') return '上传侧面厚度、结构或规格角度';
  if (kind === 'back') return '上传背面信息、开盒或反面角度';
  return '上传正面包装或主展示面';
}

function syncPrimaryProductImage() {
  state.productImage = state.productImages.front || state.productImages.side || state.productImages.back || '';
}

function setProductAngle(kind, src, urlText) {
  var meta = PRODUCT_ANGLES[kind];
  if (!meta) return;
  var changed = state.productImages[kind] !== (src || '');
  state.productImages[kind] = src || '';
  if (changed) invalidateProductBoundPrompts();
  if (urlText != null && $(meta.url)) $(meta.url).value = urlText;
  syncPrimaryProductImage();
  renderPreview(meta.preview, state.productImages[kind], productPlaceholder(kind));
  var count = productImageList().length;
  var referenceCount = referenceImageList().length;
  setPill('contextState', count ? ('已载入主体图 ' + count + ' 张') : (referenceCount ? ('已载入参考页 ' + referenceCount + ' / 6') : '等待图片'), count ? 'ok' : (referenceCount ? 'ok' : ''));
  syncDetailWorkflowUi();
}

function setProductImage(src, urlText) {
  setProductAngle('front', src, urlText);
}

function productImageList() {
  var out = [];
  ['front', 'side', 'back'].forEach(function (kind) {
    var meta = PRODUCT_ANGLES[kind];
    var img = state.productImages[kind] || (meta && $(meta.url) ? normalizeImageUrl($(meta.url).value) : '');
    if (img && out.indexOf(img) < 0) out.push(img);
  });
  return out;
}

function productImageEvidence() {
  var out = [];
  ['front', 'side', 'back'].forEach(function (kind) {
    var meta = PRODUCT_ANGLES[kind];
    var image = state.productImages[kind] || (meta && $(meta.url) ? normalizeImageUrl($(meta.url).value) : '');
    if (!image || out.some(function (item) { return item.image === image; })) return;
    out.push({ angle: kind, label: meta.label, image: image });
  });
  return out;
}

function modelImageEvidence() {
  var out = [];
  ['front', 'side', 'back'].forEach(function (kind) {
    var meta = MODEL_ANGLES[kind];
    var image = state.modelImages[kind] || (meta && $(meta.url) ? normalizeImageUrl($(meta.url).value) : '');
    if (!image || out.some(function (item) { return item.image === image; })) return;
    out.push({ angle: kind, label: meta.label, image: image });
  });
  return out;
}

function sourceFingerprint(value) {
  value = String(value || '');
  if (!value) return '';
  for (var c = 0; c < sourceFingerprintCache.length; c++) {
    if (sourceFingerprintCache[c].value === value) return sourceFingerprintCache[c].fingerprint;
  }
  var hash = 2166136261;
  for (var i = 0; i < value.length; i++) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  var fingerprint = value.length + ':' + (hash >>> 0).toString(16);
  sourceFingerprintCache.unshift({ value: value, fingerprint: fingerprint });
  if (sourceFingerprintCache.length > 16) sourceFingerprintCache.length = 16;
  return fingerprint;
}

function evidenceFingerprint(items) {
  return (items || []).map(function (item) {
    return (item.angle || '') + ':' + sourceFingerprint(item.image || item);
  }).join('|');
}

function currentProductFingerprint() {
  return evidenceFingerprint(productImageEvidence());
}

function currentReferenceFingerprint() {
  return evidenceFingerprint(referenceImageList().map(function (image, idx) {
    return { angle: 'page-' + (idx + 1), image: image };
  }));
}

function linkSemanticFingerprint(link) {
  link = link || {};
  return JSON.stringify(Object.keys(link).filter(function (key) {
    return key.indexOf('__') !== 0;
  }).sort().map(function (key) { return [key, link[key]]; }));
}

function detailRuleDataFromPayload(payload) {
  payload = payload || {};
  return {
    mode: payload.mode || 'reference',
    productName: payload.productName || '',
    productFeatures: payload.productFeatures || '',
    sellingPoints: payload.sellingPoints || '',
    detailPositioning: payload.detailPositioning || '',
    detailCopy: payload.detailCopy || '',
    detailLogic: payload.detailLogic || '',
    platform: payload.platform || '',
    pageType: payload.pageType || '',
    language: payload.language || '',
    screenCount: Number(payload.screenCount) || 0,
    ratio: payload.ratio || '',
    resolution: payload.resolution || '',
    generateStyle: payload.generateStyle || '',
    imagesPerLink: Number(payload.imagesPerLink) || 1,
    modelPrompt: payload.modelPrompt || '',
    analysisFingerprint: sourceFingerprint(JSON.stringify(payload.analysis || null)),
    currentMainPromptFingerprint: sourceFingerprint(payload.currentMainPrompt || '')
  };
}

function detailRuleFingerprint(payload) {
  return sourceFingerprint(JSON.stringify(detailRuleDataFromPayload(payload)));
}

function currentDetailRuleFingerprint(source, link) {
  var mode = source === 'link' ? 'link' : 'reference';
  return detailRuleFingerprint(collectDetailPayload(mode, source === 'link' ? (link || {}) : null));
}

function capturePromptInputSnapshot(source, mode, link, payload) {
  return {
    source: source,
    mode: mode,
    productFingerprint: currentProductFingerprint(),
    modelFingerprint: mode === 'detail' ? evidenceFingerprint(modelImageEvidence()) : '',
    referenceFingerprint: source === 'reference' ? currentReferenceFingerprint() : '',
    linkFingerprint: source === 'link' ? linkSemanticFingerprint(link || {}) : '',
    ruleFingerprint: mode === 'detail' ? detailRuleFingerprint(payload || collectDetailPayload(source === 'link' ? 'link' : 'reference', source === 'link' ? (link || {}) : null)) : ''
  };
}

function promptInputSnapshotIsCurrent(snapshot, link) {
  if (!snapshot || snapshot.productFingerprint !== currentProductFingerprint()) return false;
  if (snapshot.mode === 'detail' && snapshot.modelFingerprint !== evidenceFingerprint(modelImageEvidence())) return false;
  if (snapshot.source === 'reference' && snapshot.referenceFingerprint !== currentReferenceFingerprint()) return false;
  if (snapshot.source === 'link' && snapshot.linkFingerprint !== linkSemanticFingerprint(link || {})) return false;
  if (snapshot.mode === 'detail' && snapshot.ruleFingerprint !== currentDetailRuleFingerprint(snapshot.source, link || {})) return false;
  return true;
}

function stalePromptResponse(source) {
  var message = '提词期间素材或链接内容已变化，本次旧响应已丢弃，请重新生成提示词。';
  setPill(source === 'detail' ? 'detailState' : 'runState', message, 'warn');
  return { ok: false, stale: true, error: message };
}

function invalidateProductBoundPrompts() {
  state.referenceAnalysis = null;
  state.analysis = null;
  state.referencePrompts.main = null;
  state.referencePrompts.detail = null;
  state.linkPrompts.main = {};
  state.linkPrompts.detail = {};
  state.linkPromptOrder.main = [];
  state.linkPromptOrder.detail = [];
  state.activePromptRecord = null;
}

function modelPlaceholder(kind) {
  if (kind === 'side') return '上传侧面姿势、身形比例或动作';
  if (kind === 'back') return '上传背面轮廓、发型或服饰细节';
  return '上传正面人物、姿态或穿搭';
}

function modelImageList() {
  var out = [];
  ['front', 'side', 'back'].forEach(function (kind) {
    var meta = MODEL_ANGLES[kind];
    var img = state.modelImages[kind] || (meta && $(meta.url) ? normalizeImageUrl($(meta.url).value) : '');
    if (img && out.indexOf(img) < 0) out.push(img);
  });
  return out;
}

function setModelAngle(kind, src, urlText) {
  var meta = MODEL_ANGLES[kind];
  if (!meta) return;
  var changed = state.modelImages[kind] !== (src || '');
  state.modelImages[kind] = src || '';
  if (changed) {
    state.referencePrompts.detail = null;
    state.linkPrompts.detail = {};
    state.linkPromptOrder.detail = [];
    if (state.activePromptRecord && state.activePromptRecord.mode === 'detail') state.activePromptRecord = null;
  }
  if (urlText != null && $(meta.url)) $(meta.url).value = urlText;
  renderPreview(meta.preview, state.modelImages[kind], modelPlaceholder(kind));
  var count = modelImageList().length;
  var referenceCount = referenceImageList().length;
  setPill('contextState', count ? ('已载入模特图 ' + count + ' 张') : (referenceCount ? ('已载入参考页 ' + referenceCount + ' / 6') : '等待图片'), count ? 'ok' : (referenceCount ? 'ok' : ''));
  syncDetailWorkflowUi();
}

function primaryProductImage() {
  var imgs = productImageList();
  return imgs[0] || '';
}

function normalizeImageUrl(input) {
  var v = (input || '').trim();
  if (!v) return '';
  if (/^data:image\//.test(v)) return v;
  if (/^https?:\/\//.test(v)) return v;
  return '';
}

function plainObject(value) {
  return value && typeof value === 'object' && !Array.isArray(value);
}

function hasRowValue(row) {
  if (!plainObject(row)) return false;
  return Object.keys(row).some(function (k) {
    var v = row[k];
    return v != null && ('' + v).trim() !== '';
  });
}

function normalizeLinkRows(value) {
  var source = value;
  if (plainObject(source)) {
    if (Array.isArray(source.rows)) source = source.rows;
    else if (Array.isArray(source.linksJson)) source = source.linksJson;
    else if (Array.isArray(source.linkRows)) source = source.linkRows;
    else if (Array.isArray(source.data)) source = source.data;
    else if (Array.isArray(source.links)) source = source.links;
    else source = [source];
  }
  if (!Array.isArray(source)) return [];
  return source.filter(plainObject).map(function (row) { return Object.assign({}, row); }).filter(hasRowValue);
}

function splitDelimitedLine(line, delimiter) {
  if (delimiter === '\t') return line.split('\t');
  var out = [], cur = '', quote = false;
  for (var i = 0; i < line.length; i++) {
    var ch = line.charAt(i);
    if (ch === '"') {
      if (quote && line.charAt(i + 1) === '"') { cur += '"'; i++; }
      else quote = !quote;
    } else if (ch === delimiter && !quote) {
      out.push(cur); cur = '';
    } else {
      cur += ch;
    }
  }
  out.push(cur);
  return out;
}

function parseDelimitedLinks(raw) {
  var lines = (raw || '').split(/\r?\n/).filter(function (line) { return line.trim(); });
  if (lines.length < 2) return [];
  var delimiter = raw.indexOf('\t') >= 0 ? '\t' : (raw.indexOf(',') >= 0 ? ',' : '');
  if (!delimiter) return [];
  var headers = splitDelimitedLine(lines[0], delimiter).map(function (h) { return h.trim(); });
  if (!headers.length || headers.every(function (h) { return !h; })) return [];
  return lines.slice(1).map(function (line) {
    var cols = splitDelimitedLine(line, delimiter);
    var row = {};
    headers.forEach(function (h, i) {
      if (!h) return;
      row[h] = (cols[i] == null ? '' : cols[i]).trim();
    });
    return row;
  }).filter(hasRowValue);
}

function parseNdjsonLinks(raw) {
  var rows = [];
  var lines = (raw || '').split(/\r?\n/).map(function (line) { return line.trim(); }).filter(Boolean);
  if (lines.length < 2) return [];
  for (var i = 0; i < lines.length; i++) {
    if (!/^\{/.test(lines[i])) return [];
    rows.push(JSON.parse(lines[i]));
  }
  return normalizeLinkRows(rows);
}

function parseLinkListInput() {
  var raw = $('linkJson').value.trim();
  if (!raw) return [];
  try {
    var parsed = JSON.parse(raw);
    var rows = normalizeLinkRows(parsed);
    if (rows.length) return rows;
    throw new Error('JSON 中没有可用链接行');
  } catch (jsonErr) {
    try {
      var ndRows = parseNdjsonLinks(raw);
      if (ndRows.length) return ndRows;
    } catch (e) {}
    var tableRows = parseDelimitedLinks(raw);
    if (tableRows.length) return tableRows;
    throw new Error('链接清单解析失败：请粘贴单条 JSON、数组 JSON、{"rows":[...]}，或带表头的表格。原始错误：' + jsonErr.message);
  }
}

function parseLinkJson() {
  var rows = parseLinkListInput();
  var obj = rows.length ? Object.assign({}, rows[0]) : {};
  var pos = $('positioning').value.trim();
  var copy = $('imageCopy').value.trim();
  if (currentLabMode() === 'detail') {
    if (pos) obj['详情页定位'] = pos;
    if (copy) obj['详情页文案'] = copy;
  } else {
    if (pos) obj['链接定位'] = pos;
    if (copy) obj['主图核心文案'] = copy;
  }
  if (obj['链接定位'] && !obj['详情页定位']) obj['详情页定位'] = obj['链接定位'];
  if (obj['主图核心文案'] && !obj['详情页文案']) obj['详情页文案'] = obj['主图核心文案'];
  if (!Object.keys(obj).length) throw new Error('请粘贴链接清单 JSON，或至少填写链接定位');
  if (rows.length) rows[0] = Object.assign({}, rows[0], obj);
  state.linkList = rows.length ? rows : [obj];
  state.lastLink = obj;
  return obj;
}

function applyLinkToFields(value, keepRawText) {
  var rows = normalizeLinkRowsForBatch(normalizeLinkRows(value), false);
  if (!rows.length) return;
  var obj = rows[0];
  state.linkList = rows;
  state.lastLink = obj;
  if (!keepRawText) $('linkJson').value = JSON.stringify(rows.length === 1 ? obj : rows, null, 2);
  syncLinkFields(obj);
  if (currentLabMode() === 'detail') fillDetailFieldsFromContext(obj, true);
  syncBatchRangeDefaults(rows, !keepRawText);
  setPill('linkState', rows.length > 1 ? ('已载入 ' + rows.length + ' 条链接') : '已载入链接', 'ok');
  syncDetailWorkflowUi();
}

function loadDetailSample() {
  applyLinkToFields(sampleDetailLink);
  if ($('detailProductName')) $('detailProductName').value = sampleDetailLink['商品标题'];
  if ($('detailProductFeatures')) $('detailProductFeatures').value = sampleDetailLink['主推关键词'];
  if ($('detailSellingPoints')) $('detailSellingPoints').value = sampleDetailLink['详情页文案'];
  if ($('detailPlatform')) $('detailPlatform').value = '淘宝';
  if ($('detailPageType')) $('detailPageType').value = '详情页';
  if ($('detailLanguage')) $('detailLanguage').value = '中文';
  if ($('detailScreenCount')) $('detailScreenCount').value = '' + DETAIL_DEFAULT_SCREEN_COUNT;
  if ($('detailRatio')) $('detailRatio').value = '3:4';
  if ($('detailResolution')) $('detailResolution').value = '2K';
  if ($('detailGenerateStyle')) $('detailGenerateStyle').value = '分段提示词';
  setDetailMode('link');
  setPill('detailState', '已载入详情示例', 'ok');
}

function loadSkuSample() {
  if ($('skuPrompt')) $('skuPrompt').value = skuDefaultPrompt();
  if ($('skuAttrText')) {
    $('skuAttrText').value = [
      '红色款｜礼盒装｜保留文字排版',
      '金色款｜节庆礼盒｜突出高级质感',
      '蓝色款｜日常送礼｜包装结构不变'
    ].join('\n');
  }
  setPill('skuState', '已载入 SKU 提示词模板', 'ok');
  renderSkuWorkspace();
}

function showAnalysis(data, options) {
  data = data || {};
  options = options || {};
  if (options.source !== 'link') state.analysis = data;
  $('cnPrompt').value = ensurePromptSubjectRule(data['中文提示词'] || data.cnPrompt || '', 'zh');
  if ($('enPrompt')) $('enPrompt').value = ensurePromptSubjectRule(data['English Prompt'] || data.englishPrompt || data.enPrompt || '', 'en');
  $('negativePrompt').value = mergeNegativePrompts(data['负面提示词'] || data.negativePrompt || $('negativePrompt').value, replacementNegativePrompt());
  $('analysisJson').textContent = JSON.stringify(data, null, 2);
}

function promptValueFromData(data, mode) {
  data = data || {};
  if (mode === 'detail') return data['中文详情提示词'] || data.detailPrompt || data.prompt || '';
  return data['中文提示词'] || data.cnPrompt || data.prompt || '';
}

function makePromptRecord(source, mode, link, data, linkIndex, metadata) {
  metadata = metadata || {};
  mode = mode === 'detail' ? 'detail' : 'main';
  link = link ? Object.assign({}, link) : null;
  data = Object.assign({}, data || {});
  var linkId = link ? canonicalLinkId(link['链接编号'] || link.linkId || link.link_id, linkIndex) : '';
  if (link) link['链接编号'] = linkId;
  var prompt = promptValueFromData(data, mode);
  if (mode === 'main') prompt = ensurePromptSubjectRule(prompt, 'zh');
  return Object.freeze({
    id: 'prompt_' + Date.now() + '_' + Math.random().toString(16).slice(2),
    source: source,
    mode: mode,
    linkId: linkId,
    linkIndex: Number(linkIndex) || 0,
    link: link ? Object.freeze(link) : null,
    linkFingerprint: link ? linkSemanticFingerprint(link) : '',
    data: Object.freeze(data),
    prompt: prompt,
    negativePrompt: mergeNegativePrompts((data && (data['负面提示词'] || data.negativePrompt)) || '', replacementNegativePrompt()),
    productFingerprint: currentProductFingerprint(),
    modelFingerprint: evidenceFingerprint(modelImageEvidence()),
    referenceFingerprint: source === 'reference' ? currentReferenceFingerprint() : '',
    ruleFingerprint: metadata.ruleFingerprint || '',
    requestId: metadata.requestId || '',
    promptBatchId: metadata.promptBatchId || '',
    createdAt: Date.now()
  });
}

function promptRecordIsCurrent(record, mode, link) {
  if (!record || record.mode !== (mode === 'detail' ? 'detail' : 'main')) return false;
  if (!record.prompt || record.productFingerprint !== currentProductFingerprint()) return false;
  if (record.mode === 'detail' && record.modelFingerprint !== evidenceFingerprint(modelImageEvidence())) return false;
  if (record.source === 'reference' && record.referenceFingerprint !== currentReferenceFingerprint()) return false;
  if (record.source === 'link' && link && record.linkFingerprint !== linkSemanticFingerprint(link)) return false;
  if (record.mode === 'detail' && record.ruleFingerprint !== currentDetailRuleFingerprint(record.source, link || record.link || {})) return false;
  return true;
}

function rememberPromptRecord(record) {
  if (!record) return record;
  if (record.source === 'reference') {
    state.referencePrompts[record.mode] = record;
  } else if (record.source === 'link') {
    state.linkPrompts[record.mode][record.linkId] = record;
    state.linkPromptOrder[record.mode] = state.linkPromptOrder[record.mode].filter(function (id) { return id !== record.linkId; });
    state.linkPromptOrder[record.mode].push(record.linkId);
  }
  return record;
}

function displayPromptRecord(record) {
  if (!record) return;
  state.activePromptRecord = record;
  if (record.mode === 'detail') {
    renderDetailResult(record.data || {});
    if ($('negativePrompt')) $('negativePrompt').value = record.negativePrompt;
  } else {
    showAnalysis(record.data || {}, { source: record.source });
    if ($('cnPrompt')) $('cnPrompt').value = record.prompt;
    if ($('negativePrompt')) $('negativePrompt').value = record.negativePrompt;
  }
  if (record.link) syncLinkFields(record.link);
}

function displayBatchPromptRecords(records, mode) {
  records = (records || []).filter(Boolean);
  if (!records.length) return;
  mode = mode === 'detail' ? 'detail' : 'main';
  var combined = records.map(function (record) {
    return '【' + record.linkId + '】\n' + record.prompt;
  }).join('\n\n');
  var data = records.map(function (record) {
    return { 链接编号: record.linkId, 来源: record.source, 提示词: record.prompt, 数据: record.data };
  });
  state.activePromptRecord = Object.freeze({
    source: 'link-batch',
    mode: mode,
    records: records.slice(),
    linkIds: records.map(function (record) { return record.linkId; }),
    displayedPrompt: combined,
    negativePrompt: records.map(function (record) { return record.negativePrompt; }).filter(Boolean).join(', '),
    promptBatchId: records[0] && records[0].promptBatchId || '',
    productFingerprint: currentProductFingerprint()
  });
  if (mode === 'detail') {
    if ($('detailPrompt')) $('detailPrompt').value = combined;
    if ($('detailJson')) $('detailJson').textContent = JSON.stringify(data, null, 2);
    if ($('detailEmpty')) $('detailEmpty').classList.add('has-result');
  } else {
    if ($('cnPrompt')) $('cnPrompt').value = combined;
    if ($('analysisJson')) $('analysisJson').textContent = JSON.stringify(data, null, 2);
  }
  if ($('negativePrompt')) $('negativePrompt').value = mergeNegativePrompts.apply(null, records.map(function (record) { return record.negativePrompt; }));
  syncDetailWorkflowUi();
}

function mergeNegativePrompts() {
  var seen = {};
  var parts = [];
  Array.prototype.slice.call(arguments).forEach(function (text) {
    ('' + (text || '')).split(/[,，]/).forEach(function (part) {
      part = part.trim();
      if (!part) return;
      var key = part.toLowerCase();
      if (seen[key]) return;
      seen[key] = true;
      parts.push(part);
    });
  });
  return parts.join(', ');
}

function textValue(value) {
  if (value == null) return '';
  if (Array.isArray(value)) return value.map(textValue).filter(Boolean).join('，');
  if (typeof value === 'object') return JSON.stringify(value);
  return String(value).trim();
}

function firstValue(obj, keys) {
  obj = obj || {};
  for (var i = 0; i < keys.length; i++) {
    var v = textValue(obj[keys[i]]);
    if (v) return v;
  }
  return '';
}

function currentLinkForDetail() {
  try { return parseLinkJson(); } catch (e) {}
  return state.lastLink || {};
}

function detailScreenBounds(mode) {
  return mode === 'reference'
    ? { min: 5, max: 10, fallback: DETAIL_DEFAULT_SCREEN_COUNT, label: '参考图：默认10屏' }
    : { min: 5, max: 16, fallback: DETAIL_DEFAULT_SCREEN_COUNT, label: '链接详情：默认10屏' };
}

function syncDetailModeControls() {
  var mode = state.detailMode || 'reference';
  var bounds = detailScreenBounds(mode);
  var el = $('detailScreenCount');
  if (el) {
    Array.prototype.forEach.call(el.options, function (opt) {
      var n = Number(opt.value);
      opt.disabled = mode === 'reference' && n > bounds.max;
    });
    if (!el.dataset.userTouched) el.value = '' + DETAIL_DEFAULT_SCREEN_COUNT;
    var current = clampInt(el.value, bounds.min, bounds.max, bounds.fallback);
    el.value = '' + current;
  }
  syncDetailGenerationCount();
  syncGenerationParamSummary();
  if ($('detailModeHint')) {
    var items = mode === 'reference'
      ? ['参考图与链接 JSON 不混用', '产品主体图至少1张', '模特图可选', '默认10屏，可改5-10屏']
      : ['链接路线不读取参考图', '产品主体图至少1张', '模特图可选', 'L 编号逐条提词并绑定生图'];
    $('detailModeHint').innerHTML = items.map(function (item) { return '<span>' + item + '</span>'; }).join('');
  }
}

function syncDetailModeDefaultsAfterRestore() {
  [0, 120, 500].forEach(function (delay) {
    window.setTimeout(syncDetailModeControls, delay);
  });
}

function syncDetailGenerationCount(force) {
  var countEl = $('imageCount');
  var screenEl = $('detailScreenCount');
  if (!countEl || !screenEl || currentLabMode() !== 'detail') return;
  if (force) delete countEl.dataset.userTouched;
  countEl.value = '' + clampInt(screenEl.value, 5, 20, DETAIL_DEFAULT_SCREEN_COUNT);
  syncGenerationParamSummary();
}

function detailLinkRowsForWorkflowState() {
  var rows = normalizeLinkRows(state.linkList || []);
  if ($('linkJson') && $('linkJson').value.trim()) {
    try { rows = parseLinkListInput(); } catch (e) {}
  }
  return rows;
}

function syncDetailWorkflowUi() {
  if (currentLabMode() !== 'detail') return;
  var mode = state.detailMode === 'link' ? 'link' : 'reference';
  var productCount = productImageList().length;
  var modelCount = modelImageList().length;
  var referenceCount = referenceImageList().length;
  var refReady = referenceCount > 0;
  var linkRows = detailLinkRowsForWorkflowState();
  var sourceReady = mode === 'reference' ? refReady : linkRows.length > 0;
  var sourceText;
  if (mode === 'reference') {
    sourceText = refReady ? ('参考页已就绪：' + referenceCount + ' / 6') : '请上传 1-6 张参考页';
  } else if (linkRows.length) {
    var firstId = canonicalLinkId(linkRows[0] && (linkRows[0]['链接编号'] || linkRows[0].linkId || linkRows[0].link_id), 0);
    var lastId = canonicalLinkId(linkRows[linkRows.length - 1] && (linkRows[linkRows.length - 1]['链接编号'] || linkRows[linkRows.length - 1].linkId || linkRows[linkRows.length - 1].link_id), linkRows.length - 1);
    sourceText = '已载入 ' + linkRows.length + ' 条' + (linkRows.length > 1 ? '（' + firstId + '–' + lastId + '）' : '（' + firstId + '）');
  } else {
    sourceText = '请载入链接定位 JSON';
  }
  setPill('detailSourceState', sourceText, sourceReady ? 'ok' : 'warn');
  setPill(
    'detailSubjectState',
    productCount
      ? ('产品 ' + productCount + ' 张 · 模特 ' + modelCount + ' 张（可选）')
      : ('缺少产品主体图 · 模特 ' + modelCount + ' 张（不能替代产品）'),
    productCount ? 'ok' : 'warn'
  );

  var refPanel = $('referenceSourcePanel');
  var linkPanel = $('linkSourcePanel');
  if (refPanel) refPanel.classList.toggle('route-inactive', mode !== 'reference');
  if (linkPanel) linkPanel.classList.toggle('route-inactive', mode !== 'link');

  setText(
    'detailRefGenerateBtn',
    mode === 'reference'
      ? '按参考页故事 + 产品主体生成详情提示词'
      : '按 L 编号 + 产品主体批量生成详情提示词'
  );

  var referenceGenerate = $('generateBtn');
  var linkGenerate = $('linkNumberGenerateBtn');
  if (referenceGenerate) {
    referenceGenerate.hidden = mode !== 'reference';
    referenceGenerate.textContent = '按参考图/参考页提示词 + 产品主体生成详情';
    referenceGenerate.title = '使用 1-6 张参考页学习故事、版式和视觉系统；旧主体必须换成产品主体图，模特图可选';
  }
  if (linkGenerate) {
    linkGenerate.hidden = mode !== 'link';
    linkGenerate.textContent = '按 L 编号提示词 + 产品主体并发生成详情';
    linkGenerate.title = '每个 L 编号只使用自己的提示词与同一组产品主体图；模特图可选';
  }
  setText(
    'detailGenerationRoute',
    mode === 'reference'
      ? '当前路线：1-6 张参考页故事/版式 + 必填产品主体图；旧主体自动替换，模特图可选，链接 JSON 不参与。'
      : '当前路线：各 L 编号自己的链接定位提示词 + 必填产品主体图；模特图可选，参考图不参与。'
  );
}

function setDetailMode(mode) {
  var previousMode = state.detailMode || 'reference';
  state.detailMode = mode === 'link' ? 'link' : 'reference';
  if ($('detailRefModeBtn')) $('detailRefModeBtn').classList.toggle('active', state.detailMode === 'reference');
  if ($('detailLinkModeBtn')) $('detailLinkModeBtn').classList.toggle('active', state.detailMode === 'link');
  if ($('buildPromptBtn')) $('buildPromptBtn').textContent = '生成当前/选定范围详情提示词';
  if (currentLabMode() === 'detail' && previousMode !== state.detailMode) {
    state.activePromptRecord = null;
    if ($('detailPrompt')) $('detailPrompt').value = '';
    if ($('detailJson')) $('detailJson').textContent = '';
    if ($('detailEmpty')) $('detailEmpty').classList.remove('has-result');
    // 参考路线只清理仍属于上一条链接的自动填充值；用户手填的产品信息继续保留。
    // 链接路线在 fillDetailFieldsFromContext 内仍会按当前 L 编号强制换成该行自己的字段。
    fillDetailFieldsFromContext(null, false);
    setPill('detailState', '路线已切换，请按当前定位重新生成提示词', '');
    setPill('generateState', '请先生成当前路线提示词', '');
  }
  syncDetailModeControls();
  syncDetailWorkflowUi();
}

function detailFieldContextKey(link) {
  return sourceFingerprint(linkSemanticFingerprint(link || {}));
}

function fillDetailContextField(id, value, contextKey, replaceOnContextSwitch) {
  var el = $(id);
  if (!el) return;
  value = textValue(value);
  var current = (el.value || '').trim();
  var previousKey = el.dataset.detailContextKey || '';
  var previousValue = el.dataset.detailContextValue || '';
  var contextChanged = !!previousKey && previousKey !== contextKey;
  var stillAutoFilled = !!previousValue && current === previousValue;
  if (!current || stillAutoFilled || (replaceOnContextSwitch && contextChanged)) {
    el.value = value;
    el.dataset.detailContextValue = value;
  } else if (contextChanged) {
    el.dataset.detailContextValue = '';
  }
  el.dataset.detailContextKey = contextKey;
}

function fillDetailFieldsFromContext(linkOverride, replaceOnContextSwitch) {
  var link = state.detailMode === 'link'
    ? (linkOverride ? Object.assign({}, linkOverride) : currentLinkForDetail())
    : {};
  var analysis = state.detailMode === 'reference' ? (state.referenceAnalysis && state.referenceAnalysis.data) || state.analysis || {} : {};
  var productName = firstValue(link, ['商品标题', '标题定位词路', '主推关键词', '详情页定位', '链接定位']);
  var features = [
    firstValue(link, ['主推关键词', '用户场景需求', '差异化定位逻辑', '详情页定位']),
    firstValue(analysis, ['主体', '品类', '材质'])
  ].filter(Boolean).join('；');
  var selling = [
    firstValue(link, ['详情页文案', '主图核心文案', '差异化定位逻辑', '用户场景需求', '主推关键词']),
    firstValue(analysis, ['可借鉴点', '风格'])
  ].filter(Boolean).join('；');
  var contextKey = detailFieldContextKey(link);
  var replaceOnSwitch = !!replaceOnContextSwitch || state.detailMode === 'link';
  fillDetailContextField('detailProductName', productName, contextKey, replaceOnSwitch);
  fillDetailContextField('detailProductFeatures', features, contextKey, replaceOnSwitch);
  fillDetailContextField('detailSellingPoints', selling, contextKey, replaceOnSwitch);
  setPill('detailState', (productName || features || selling) ? '已补齐详情信息' : '请补充产品信息', (productName || features || selling) ? 'ok' : 'warn');
}

function buildModelThreeViewPrompt() {
  fillDetailFieldsFromContext();
  var link = state.detailMode === 'link' ? currentLinkForDetail() : {};
  var productName = ($('detailProductName') && $('detailProductName').value.trim()) || firstValue(link, ['商品标题', '标题定位词路', '主推关键词', '详情页定位', '链接定位']) || '当前商品';
  var selling = ($('detailSellingPoints') && $('detailSellingPoints').value.trim()) || firstValue(link, ['详情页文案', '主图核心文案', '用户场景需求', '差异化定位逻辑']) || '突出商品核心利益点';
  var prompt = [
    '生成详情页人物模特三视图参考图：正视图、侧视图、背视图保持同一人物身份、年龄段、发型、服饰和体型一致。',
    '人物只作为“' + productName + '”详情页的场景辅助，不能遮挡商品主体，不能抢占主视觉。',
    '风格：真实电商详情页，干净自然光，动作生活化，表情自然，服装简洁，背景可抠图或浅色棚拍。',
    '使用场景：' + selling + '；人物姿态需要能服务产品卖点展示、尺寸对比、使用动作和情绪氛围。',
    '输出：三张独立参考图，分别为正面站姿/半身、侧面使用动作、背面或转身轮廓；无品牌、无文字、无水印。'
  ].join('\n');
  if ($('detailModelPrompt')) $('detailModelPrompt').value = prompt;
  setPill('contextState', '已生成模特三视图提示词', 'ok');
  setPill('detailState', '模特三视图提示词已生成', 'ok');
  return prompt;
}

function collectDetailPayload(mode, linkOverride) {
  mode = mode || state.detailMode || 'reference';
  var link = mode === 'link'
    ? (linkOverride ? Object.assign({}, linkOverride) : currentLinkForDetail())
    : {};
  var preferLink = mode === 'link' && !!linkOverride;
  var screenBounds = detailScreenBounds(mode);
  var referenceImages = mode === 'reference' ? referenceImageList() : [];
  var referenceImage = referenceImages[0] || '';
  function detailContextValue(id, keys) {
    var fromForm = ($(id) && $(id).value.trim()) || '';
    var fromLink = firstValue(link, keys);
    return preferLink ? (fromLink || fromForm) : (fromForm || fromLink);
  }
  return {
    mode: mode,
    link: link,
    referenceImage: referenceImage,
    referenceImages: referenceImages,
    productImages: productImageList(),
    productImageEvidence: productImageEvidence(),
    modelImages: modelImageList(),
    modelImageEvidence: modelImageEvidence(),
    modelPrompt: ($('detailModelPrompt') && $('detailModelPrompt').value.trim()) || '',
    productName: detailContextValue('detailProductName', ['商品标题', '标题定位词路', '主推关键词', '详情页定位', '链接定位']),
    productFeatures: detailContextValue('detailProductFeatures', ['主推关键词', '用户场景需求', '差异化定位逻辑', '详情页定位']),
    sellingPoints: detailContextValue('detailSellingPoints', ['详情页文案', '主图核心文案', '差异化定位逻辑', '用户场景需求', '主推关键词']),
    detailPositioning: firstValue(link, ['详情页定位', '链接定位']),
    detailCopy: firstValue(link, ['详情页文案', '主图核心文案']),
    detailLogic: firstValue(link, ['详情文案逻辑', '详情页逻辑', '详情逻辑']) || '痛点 -> 场景 -> 功能 -> 对比 -> 使用教程',
    platform: ($('detailPlatform') && $('detailPlatform').value) || '淘宝',
    pageType: ($('detailPageType') && $('detailPageType').value) || '详情页',
    language: ($('detailLanguage') && $('detailLanguage').value) || '中文',
    screenCount: clampInt($('detailScreenCount') && $('detailScreenCount').value, screenBounds.min, screenBounds.max, screenBounds.fallback),
    ratio: normalizeRatioValue(($('detailRatio') && $('detailRatio').value) || '3:4'),
    resolution: ($('detailResolution') && $('detailResolution').value) || '2K',
    generateStyle: ($('detailGenerateStyle') && $('detailGenerateStyle').value) || '分段提示词',
    imagesPerLink: 1,
    currentMainPrompt: mode === 'reference' && promptRecordIsCurrent(state.referencePrompts.main, 'main')
      ? state.referencePrompts.main.prompt
      : '',
    currentEnglishPrompt: '',
    negativePrompt: ($('negativePrompt') && $('negativePrompt').value.trim()) || '',
    analysis: mode === 'reference' ? ((state.referenceAnalysis && state.referenceAnalysis.data) || state.analysis || null) : null
  };
}

function detailPromptRuleLayer(payload) {
  payload = payload || {};
  var link = payload.link || {};
  var linkId = payload.mode === 'link' ? canonicalLinkId(link['链接编号'] || link.linkId || link.link_id, 0) : '参考图模式';
  var referenceCount = payload.referenceImages && payload.referenceImages.length ? payload.referenceImages.length : (payload.referenceImage ? 1 : 0);
  var sourceRule = payload.mode === 'link'
    ? '本提示词只属于当前编号，禁止混用其他 L 编号、参考图分析或旧批次提示词。'
    : '本提示词严格绑定当前 ' + referenceCount + ' 张参考页的上传顺序和当前产品主体图；必须学习整套故事承接、文案与字体风格、背景元素、光影与景深、页面布局结构，同时识别并排除所有旧商品/旧包装/旧品牌，用新主体自然融入原占位与光影关系。';
  return [
    '【用户详情规则锁定｜' + linkId + '】',
    sourceRule,
    '详情页定位：' + (payload.detailPositioning || '未填写'),
    '详情页文案：' + (payload.detailCopy || '未填写'),
    '详情文案逻辑：' + (payload.detailLogic || '未填写'),
    '用户选择：平台=' + (payload.platform || '淘宝') + '；页面类型=' + (payload.pageType || '详情页') + '；屏数=' + (payload.screenCount || DETAIL_DEFAULT_SCREEN_COUNT) + '；比例=' + (payload.ratio || '3:4') + '；分辨率=' + (payload.resolution || '2K') + '；语言=' + (payload.language || '中文') + '；生成方式=' + (payload.generateStyle || '分段提示词') + '。',
    '执行顺序：严格按屏幕规划 1→' + (payload.screenCount || DETAIL_DEFAULT_SCREEN_COUNT) + ' 逐屏生成；每屏只使用本编号的定位、文案与承接逻辑；商品身份严格锁定用户上传的主体多角度图。'
  ].join('\n');
}

function enforceDetailPromptRules(data, payload) {
  data = Object.assign({}, data || {});
  payload = payload || {};
  var prompt = promptValueFromData(data, 'detail');
  var layer = detailPromptRuleLayer(payload);
  if (prompt.indexOf('【用户详情规则锁定｜') !== 0) prompt = layer + '\n\n' + prompt;
  data['中文详情提示词'] = prompt;
  data['详情页规格'] = Object.assign({}, data['详情页规格'] || {}, {
    平台: payload.platform || '淘宝',
    页面类型: payload.pageType || '详情页',
    屏数: Number(payload.screenCount) || DETAIL_DEFAULT_SCREEN_COUNT,
    比例: payload.ratio || '3:4',
    分辨率: payload.resolution || '2K',
    语言: payload.language || '中文',
    生成方式: payload.generateStyle || '分段提示词'
  });
  if (payload.mode === 'link') {
    data['链接编号'] = canonicalLinkId((payload.link || {})['链接编号'] || (payload.link || {}).linkId || (payload.link || {}).link_id, 0);
    data['详情页定位'] = payload.detailPositioning || '';
    data['详情页文案'] = payload.detailCopy || '';
    data['详情文案逻辑'] = payload.detailLogic || '';
  } else {
    var analysis = payload.analysis || {};
    var referenceCount = payload.referenceImages && payload.referenceImages.length ? payload.referenceImages.length : (payload.referenceImage ? 1 : 0);
    data['参考页面故事逻辑'] = data['参考页面故事逻辑'] || analysis['参考页面故事逻辑'] || analysis['页面故事逻辑'] || ('严格按 ' + referenceCount + ' 张参考页的上传顺序提取页面任务、卖点推进和上下承接。');
    data['旧主体识别与替换表'] = data['旧主体识别与替换表'] || analysis['旧主体识别与替换表'] || Array.apply(null, Array(referenceCount)).map(function (_, idx) {
      return {
        参考页: idx + 1,
        旧主体: '识别并排除本页旧商品、旧包装、旧品牌/logo和旧手持物',
        保留视觉关系: '只保留占位、比例、透视、接触阴影、遮挡和与场景的关系',
        新主体融入方式: '以当前产品主体多角度图校准后替换，不混合新旧主体'
      };
    });
    data['统一视觉规范'] = Object.assign({}, data['统一视觉规范'] || {}, {
      文案风格: firstAnalysisValue(analysis, ['文案风格', '文案语气']) || '延续参考页的短句节奏与语气',
      背景元素: firstAnalysisValue(analysis, ['背景元素', '场景元素', '背景']) || '按逐页分析延续背景层次与道具关系',
      光影与景深: firstAnalysisValue(analysis, ['光影与景深', '光线', '景深']) || '延续参考页的光源方向、明暗和焦点层次',
      页面布局结构: firstAnalysisValue(analysis, ['页面布局结构', '版式结构', '构图']) || '延续参考页的留白、图文比例与页面节奏'
    });
    if (Array.isArray(data['屏幕规划'])) data['屏幕规划'].forEach(function (screen, idx) {
      if (!screen || typeof screen !== 'object') return;
      if (!screen['对应参考页']) screen['对应参考页'] = referenceCount ? ('参考第 ' + ((idx % referenceCount) + 1) + ' 页的叙事任务与版式，按整套顺序承接') : '';
      if (!screen['旧主体替换']) screen['旧主体替换'] = '识别对应参考页的旧主体，保留光影/占位/透视关系，用产品主体图中的新商品严格替换。';
    });
  }
  return data;
}

function detailSectionNames(count) {
  var base = [
    '首屏场景钩子',
    '痛点爆发',
    '解决方案入场',
    '核心功能演示',
    '真实使用场景',
    '材质工艺特写',
    '结构规格证明',
    '差异化对比',
    '安装使用与QA',
    '多场景收尾',
    '安全保障',
    '人群适配',
    '细节延展',
    '组合套装',
    '服务口碑',
    '转化收尾'
  ];
  var out = base.slice(0, Math.max(5, Math.min(16, count)));
  if (out.length < count) {
    while (out.length < count) out.push('扩展卖点 ' + (out.length + 1));
  }
  return out;
}

function detailCommercialNegativePrompt() {
  return '十宫格信息图、把10屏合成一张、整页长图一次性输出、多行编号拼版、01-10大编号导航、画面左侧大序号、屏幕序号徽章、目录编号、密集参数表、图标墙、表格堆满、文字过多、左右分栏过碎、画面像PPT目录、商品被文字遮挡、商品被参考图旧主体替代、竞品品牌、商标、真实 logo、不可读文字、低清晰度、比例变形、错误产品类别、虚假材质、重复元素';
}

function detailCommercialCopyBrief(name, index, payload, detailCopy) {
  var n = index + 1;
  var map = [
    '一句话打出核心利益和场景心智，标题短而有冲击，副标题只补充1个购买理由。',
    '把用户痛点说清楚，不铺陈长段文字，用1句主标题加1-2条短说明。',
    '说明目标商品如何解决痛点，文案从“旧问题”切到“新方案”。',
    '聚焦一个核心功能或核心卖点，用短标题和少量标注解释画面。',
    '强调真实使用场景、人物尺度或环境适配，让用户想象自己正在使用。',
    '用材质、工艺、细节质感建立信任，文字只做短注释。',
    '参数和结构只保留关键尺寸/规格，避免表格堆满，像详情页证据屏。',
    '做差异化对比或竞品避坑，但不要直接复制竞品，不出现竞品品牌。',
    '讲清安装、使用、保养或QA注意事项，信息要有秩序但不拥挤。',
    '多场景适用或收尾转化，形成购买理由闭环。'
  ];
  var copy = map[Math.min(index, map.length - 1)] || '延展当前详情页卖点，保持短句、少字、强画面。';
  if (n === 1 && detailCopy) copy += ' 首屏可优先融合详情页文案：' + detailCopy;
  if (payload.sellingPoints && n <= 4) copy += ' 核心卖点参考：' + payload.sellingPoints;
  return copy;
}

function detailCommercialScreenBrief(name, index, total, payload, productText, detailPositioning, shouldUseModel) {
  var n = index + 1;
  var product = productText || '目标商品';
  var common = '只生成内部第' + n + '个单独详情画面，不生成整张长详情，不拼接其他屏。不要在画面中出现第' + n + '屏、0' + n + '、01-10、序号徽章或目录编号，顺序由下载文件名和工作台管理。画面要像成熟电商详情页单屏：一个主视觉，一个主卖点，留白清楚，标题层级统一。';
  var briefs = [
    '首屏用强商业主视觉建立心智：目标商品大面积清晰入镜，背景服务于' + (detailPositioning || '核心场景') + '，用灯光、景深和空间层次制造高级感。',
    '痛点屏先给用户问题：用真实使用环境或局部场景表现“不够安全、不够省心、不够方便”等痛点，再让目标商品作为解决前的期待对象出现。',
    '解决方案屏让' + product + '正式入场：把旧问题转成新方案，商品居中或前景清晰，画面有功能指向但不堆文字。',
    '功能演示屏只讲一个关键功能：用动作、光效、局部箭头或简洁标注说明功能发生过程，商品结构和核心部位要清晰。',
    '场景屏表现真实使用：在合适环境中展示商品被使用、摆放或携带的状态，让用户理解适用空间和使用尺度。',
    '细节屏做材质工艺特写：近景拍摄商品纹理、边角、接口、开合、手感或包装细节，背景干净，质感强。',
    '规格屏用正面、侧面、背面或结构图证明尺寸和参数：只保留关键规格，画面像商业证据页，不做密集表格。',
    '差异屏做简洁对比：左侧可弱化旧痛点或普通方案，右侧突出目标商品带来的更好体验，避免出现竞品商标。',
    'QA/步骤屏讲使用路径：用1-3步小场景或关键动作说明安装、使用、保养或注意事项，排版克制。',
    '收尾屏做多场景和转化：把核心场景串起来，商品保持主角地位，形成购买理由闭环。'
  ];
  var brief = briefs[Math.min(index, briefs.length - 1)] || ('围绕' + product + '延展第' + n + '屏卖点，保持商业单屏视觉。');
  var modelRule = shouldUseModel
    ? '本屏可自然引用模特/手部/人物侧影辅助使用动作、尺度或情绪，但商品必须更清晰、更靠前，人物不能抢主体。'
    : '本屏不主动安排完整人物，优先商品、场景、局部手部或功能特写，避免模特干扰主体识别。';
  if (n === total) brief += ' 这是整套详情页的收尾屏，需要有购买理由闭环和统一视觉收束。';
  return common + ' ' + brief + ' ' + modelRule;
}

function detailProductRequiredMessage() {
  return productSubjectRequiredMessage('detail');
}

function productSubjectRequiredMessage(mode) {
  if (mode === 'sku') return '请先上传至少 1 张 SKU 产品图，生图必须以产品图作为目标商品主体。';
  if (mode === 'detail') return '请先上传至少 1 张产品主体图，详情页生图必须以主体图作为目标商品依据。';
  return '请先上传至少 1 张产品主体图，所有生图必须以主体图作为目标商品主体。';
}

function productSubjectStateId(mode) {
  if (mode === 'sku') return 'skuState';
  if (mode === 'detail') return 'detailState';
  return 'generateState';
}

function closeProductSubjectModal() {
  var modal = $('productSubjectModal');
  if (modal) modal.hidden = true;
}

function focusProductSubjectUpload(mode) {
  mode = mode || state.productSubjectFocusMode || currentLabMode();
  var isSku = mode === 'sku';
  var target = isSku ? $('skuProductFiles') : $('productFrontFile');
  var anchor = isSku
    ? ($('skuProductPreview') || $('skuProductUrls') || target)
    : ($('productFrontPreview') || $('productFrontUrl') || target);
  closeProductSubjectModal();
  if (anchor && anchor.scrollIntoView) anchor.scrollIntoView({ behavior: 'smooth', block: 'center' });
  setTimeout(function () {
    try { if (target) target.focus(); } catch (e) {}
  }, 160);
}

function showProductSubjectRequired(mode, customMessage) {
  mode = mode || currentLabMode();
  var msg = customMessage || productSubjectRequiredMessage(mode);
  var stateId = productSubjectStateId(mode);
  setPill(stateId, msg, 'warn');
  if (stateId !== 'generateState') setPill('generateState', msg, 'warn');
  state.productSubjectFocusMode = mode;
  if ($('productSubjectText')) {
    $('productSubjectText').textContent = msg + ' 参考图、链接定位、模板图只用于风格、构图、光影和排版，不能作为最终商品主体。';
  }
  var modal = $('productSubjectModal');
  if (modal) {
    modal.hidden = false;
    setTimeout(function () { if ($('productSubjectFocusBtn')) $('productSubjectFocusBtn').focus(); }, 0);
  }
  return false;
}

function detailSectionCanUseModel(name) {
  return /首屏|痛点|入场|功能|使用|场景|适配|口碑|收尾|转化/.test(name || '');
}

function buildLocalDetailData(payload, note) {
  payload = payload || collectDetailPayload();
  var bounds = detailScreenBounds(payload.mode);
  var count = clampInt(payload.screenCount, bounds.min, bounds.max, bounds.fallback);
  var names = detailSectionNames(count);
  var productCount = payload.productImages && payload.productImages.length ? payload.productImages.length : 0;
  var modelCount = payload.modelImages && payload.modelImages.length ? payload.modelImages.length : 0;
  var referenceCount = payload.referenceImages && payload.referenceImages.length ? payload.referenceImages.length : (payload.referenceImage ? 1 : 0);
  var referenceStory = firstAnalysisValue(payload.analysis || {}, ['参考页面故事逻辑', '页面故事逻辑', '叙事顺序']);
  var hasModelGuide = !!(modelCount || payload.modelPrompt);
  var sourceText = payload.mode === 'link'
    ? '以链接清单定位为策略来源，以产品主体图为最高商品证据；正视图/侧视图/背视图用于校准结构、比例、包装信息。'
    : '以按上传顺序排列的 ' + referenceCount + ' 张参考页/竞品图为整套叙事与视觉系统来源，学习故事逻辑、文案字体、背景元素、光影景深和布局结构；识别后排除其旧商品主体，以产品主体图作为唯一最终商品身份。' + (referenceStory ? (' 参考叙事：' + referenceStory) : '');
  var productText = payload.productName || firstValue(payload.link, ['商品标题', '标题定位词路', '主推关键词', '链接定位']) || '当前商品';
  var positioning = firstValue(payload.link, ['链接定位', '用户场景需求']);
  var subjectRule = '硬性规则：至少 1 张商品主体图才可执行详情页生图；主体图为最高商品身份依据；参考图、竞品图、链接定位、历史结果和旧提示词里的商品主体都必须被替换为主体图中的目标商品；人物模特图为可选辅助，有则只在合适屏幕用于场景、尺度、动作和情绪，不得替代、遮挡或改写商品。';
  var productEvidence = productCount
    ? '商品主体图证据：已提供 ' + productCount + ' 张，商品外观、包装结构、颜色、比例、开盒或背面信息必须优先遵循主体图。'
    : '商品主体图证据：未提供；根据规则不得执行详情页生图。';
  var modelEvidence = modelCount
    ? '人物模特三视图证据：已提供 ' + modelCount + ' 张，仅在适合人物入镜的详情屏中辅助姿态、身形比例、使用动作和场景情绪，不能抢商品主体。'
    : '人物模特证据：未提供；仍可仅使用商品主体图生成详情页，必要时只使用环境道具或局部手部辅助，不编造固定模特身份。';
  var modelPrompt = payload.modelPrompt ? '人物模特设定：' + payload.modelPrompt : '';
  var linkBatchText = payload.mode === 'link'
    ? '链接详情生产规则：默认 ' + count + ' 屏；每条链接生成 ' + (payload.imagesPerLink || 1) + ' 套详情图；至少使用 1 张商品主体图作为商品识别依据。'
    : '';
  var styleName = '商业竖版详情页风格（单屏一卖点）';
  var detailPositioning = payload.detailPositioning || firstValue(payload.link, ['详情页定位', '链接定位']);
  var detailCopy = payload.detailCopy || firstValue(payload.link, ['详情页文案', '主图核心文案']);
  var detailLogic = payload.detailLogic || firstValue(payload.link, ['详情文案逻辑', '详情页逻辑']) || '痛点 -> 场景 -> 功能 -> 对比 -> 使用教程';
  var fontStyle = payload.mode === 'link'
    ? '根据链接定位建立统一电商字体系统；大标题醒目、副标题承接利益点、说明文字清晰克制，统一字体家族、粗细、字距、行高和对齐方式，每屏只保留必要文案。'
    : '严格提取并沿用参考图字体样式；保持大标题、副标题、说明文字、参数/注释文字的字体家族、粗细、字距、行高和对齐方式一致，但每屏只保留必要文案，避免信息墙。';
  var fontSpec = {
    大标题: (payload.mode === 'link' ? '电商强转化大标题统一，建议约 ' : '按参考图大标题视觉比例统一，建议约 ') + '44-56px 或同等层级',
    副标题: (payload.mode === 'link' ? '利益点副标题统一，建议约 ' : '按参考图副标题视觉比例统一，建议约 ') + '28-36px 或同等层级',
    说明文字: (payload.mode === 'link' ? '正文说明清晰统一，建议约 ' : '按参考图正文说明视觉比例统一，建议约 ') + '20-26px 或同等层级',
    注释文字: (payload.mode === 'link' ? '参数/注释克制统一，建议约 ' : '按参考图参数/注释视觉比例统一，建议约 ') + '16-20px 或同等层级'
  };
  var styleRule = '详情生图规则：默认输出 10 屏；如果用户修改生成选项，则以用户当前选项优先，本次严格输出 ' + count + ' 屏。' +
    count + ' 屏 = ' + count + ' 张独立详情页单屏图片，绝不是一张包含多段编号的长海报；每次生图请求只生成当前屏。' +
    '商业应用目标：参考成熟电商详情页的竖向分镜逻辑，每屏一个主视觉、一个主卖点、少量短文案，形成“首屏冲击-痛点-解决方案-功能演示-真实场景-细节证明-参数/QA-收尾转化”的连续叙事。' +
    '每屏必须指定同一风格名称、同一字体样式、同一字号规范、同一排版秩序；' + (payload.mode === 'link' ? '链接定位与详情文案逻辑负责视觉和叙事方向，' : '参考图主要作为风格、字体、字号、版式、光影和节奏依据，') + '产品主体图负责商品身份，多角度主体图负责正面/侧面/背面结构校准，模特图仅在适合屏幕自然引用。' +
    '任何与主体图冲突的链接商品、参考图商品、模板商品、旧包装和旧品牌都只保留策略或风格信息，最终画面必须替换成产品主体图商品。禁止输出十宫格、编号拼图、密集参数表或把所有屏合成一张图。';
  var sections = names.map(function (name, idx) {
    var n = idx + 1;
    var shouldUseModel = hasModelGuide && detailSectionCanUseModel(name);
    var visualBrief = detailCommercialScreenBrief(name, idx, count, payload, productText, detailPositioning, shouldUseModel);
    var copyBrief = detailCommercialCopyBrief(name, idx, payload, detailCopy);
    var modelSectionRule = hasModelGuide
      ? (shouldUseModel
        ? ' 本屏如适合人物入镜，可引用模特三视图/模特设定辅助演示使用动作、尺度关系或情绪氛围，但商品必须更清晰、更靠前。'
        : ' 本屏以商品结构、参数或细节为主，通常不引入模特，避免人物干扰商品识别。')
      : ' 无模特图时保持商品独立展示，可用场景、道具、局部手部或图示辅助。';
    return {
      屏幕: n,
      名称: name,
      承接关系: n === 1 ? '建立详情页首屏心智' : '承接上一屏卖点，推进到“' + name + '”',
      视觉风格对齐: payload.mode === 'link'
        ? styleName + '；由链接详情定位建立字体层级、字号比例、版式留白、色彩质感、构图节奏和视觉氛围。'
        : styleName + '；沿用参考图的字体层级、字号比例、版式留白、色彩质感、构图节奏和视觉氛围。',
      字体样式: fontStyle,
      字号规范: fontSpec,
      主体图使用: productCount
        ? '必须使用商品主体图校准真实外观、包装结构、颜色、比例和关键细节；如有正视图/侧视图/背视图，本屏按画面需要选择最匹配角度。'
        : '未提供商品主体图，不应执行详情页生图。',
      模特使用: hasModelGuide
        ? (shouldUseModel ? '可引用模特三视图辅助动作、尺度和情绪，但商品主体更清晰、更靠前。' : '本屏通常不使用模特，避免人物干扰商品结构或参数识别。')
        : '未提供模特图；仅用商品主体、场景道具或局部手部辅助。',
      商业分镜: visualBrief,
      画面方向: '围绕“' + productText + '”做' + name + '。' + visualBrief + modelSectionRule,
      文案方向: copyBrief + ' 文案只做画面辅助，不把提示词、规格清单或长段说明直接塞进画面。',
      生图提示词: [
        '第' + n + '屏单独详情图，不是长图拼接，不是十宫格，不包含其他屏幕',
        '统一风格：' + styleName,
        '商业镜头：一个主视觉，一个主卖点，画面像成熟电商详情页单屏，强产品展示、强场景质感、少字留白',
        '画面分镜：' + visualBrief,
        '文案方向：' + copyBrief,
        '字体样式：' + fontStyle,
        '字号规范：大标题' + fontSpec.大标题 + '，副标题' + fontSpec.副标题 + '，说明文字' + fontSpec.说明文字 + '，注释文字' + fontSpec.注释文字,
        payload.platform + '电商' + payload.pageType,
        payload.ratio,
        payload.resolution,
        name,
        productEvidence,
        modelEvidence,
        modelPrompt,
        shouldUseModel ? '本屏允许自然引用模特辅助使用场景，但商品主体权重最高' : '本屏优先商品本体，不让人物或道具抢占主体',
        payload.productName ? '产品名称：' + payload.productName : '',
        payload.productFeatures ? '产品特性：' + payload.productFeatures : '',
        payload.sellingPoints ? '核心卖点：' + payload.sellingPoints : '',
        detailPositioning ? '详情页定位：' + detailPositioning : '',
        detailCopy ? '详情页文案：' + detailCopy : '',
        detailLogic ? '详情文案逻辑：' + detailLogic : '',
        positioning ? '链接定位：' + positioning : '',
        '真实商品结构，高清细节，干净商业版式，自然光影，适合详情页分屏',
        '禁止：' + detailCommercialNegativePrompt()
      ].filter(Boolean).join('，')
    };
  });
  var prompt = [
    '【详情页生成任务】',
    '来源模式：' + (payload.mode === 'link' ? '链接规划生成提示词 + 产品主体图' : '参考图生成提示词'),
    '执行原则：' + sourceText,
    styleRule,
    subjectRule,
    '平台/类型：' + payload.platform + ' / ' + payload.pageType,
    '输出规格：默认 10 屏，当前按用户选项输出 ' + count + ' 屏，' + payload.ratio + '，' + payload.resolution + '，' + payload.language + '，' + payload.generateStyle,
    '统一视觉风格：' + styleName,
    '统一字体样式：' + fontStyle,
    '统一字号规范：大标题=' + fontSpec.大标题 + '；副标题=' + fontSpec.副标题 + '；说明文字=' + fontSpec.说明文字 + '；注释文字=' + fontSpec.注释文字,
    linkBatchText,
    productEvidence,
    modelEvidence,
    modelPrompt,
    payload.productName ? '产品名称：' + payload.productName : '',
    payload.productFeatures ? '产品特性：' + payload.productFeatures : '',
    payload.sellingPoints ? '核心卖点：' + payload.sellingPoints : '',
    detailPositioning ? '详情页定位：' + detailPositioning : '',
    detailCopy ? '详情页文案：' + detailCopy : '',
    detailLogic ? '详情文案逻辑：' + detailLogic : '',
    positioning ? '链接定位：' + positioning : '',
    payload.currentMainPrompt ? '可参考主图提示词：' + payload.currentMainPrompt : '',
    '',
    '【分屏规划】',
    sections.map(function (s) {
      return s.屏幕 + '. ' + s.名称 + '\n商业分镜：' + s.商业分镜 + '\n画面：' + s.画面方向 + '\n文案：' + s.文案方向 + '\n提示词：' + s.生图提示词;
    }).join('\n\n'),
    '',
    '【负面提示词】',
    detailCommercialNegativePrompt(),
    note ? '\n【备注】' + note : ''
  ].filter(function (line) { return line !== ''; }).join('\n');
  return {
    '详情页方向': sourceText,
    '产品名称': productText,
    '详情页规格': {
      平台: payload.platform,
      页面类型: payload.pageType,
      屏数: count,
      比例: payload.ratio,
      分辨率: payload.resolution,
      语言: payload.language
    },
    '统一视觉规范': {
      风格名称: styleName,
      视觉风格来源: payload.mode === 'link'
        ? '由链接定位、主推关键词、用户场景需求、差异化定位逻辑、主图核心文案和详情三字段建立统一字体、字号、版式、构图、光线与页面叙事。'
        : '从参考图提取字体样式、字号大小、版式层级、构图节奏、光线、色彩、材质和页面叙事；所有屏保持一致。',
      字体样式: fontStyle,
      字号规范: fontSpec,
      排版规范: '每一屏沿用参考图的标题层级、留白比例、图文关系和对齐方式，但按商业详情页单屏输出；10屏是10张独立图片，最终由工作台纵向合并预览，不在单张图内做十段拼版。'
    },
    '中文详情提示词': prompt,
    '负面提示词': 'ten-panel collage, all screens in one image, long infographic, dense table layout, oversized 01-10 numbers, competitor brand, trademark logo, unreadable text, cluttered layout, low resolution, distorted product, wrong product category, hidden product, over-filtered image, fake material',
    '屏幕规划': sections
  };
}

function renderDetailResult(data, fallbackNote) {
  data = data || {};
  var prompt = data['中文详情提示词'] || data.detailPrompt || data.prompt || '';
  if (!prompt) prompt = buildLocalDetailData(collectDetailPayload(), fallbackNote)['中文详情提示词'];
  if ($('detailPrompt')) $('detailPrompt').value = prompt;
  if ($('detailJson')) $('detailJson').textContent = JSON.stringify(data, null, 2);
  if ($('detailEmpty')) $('detailEmpty').classList.add('has-result');
  syncDetailWorkflowUi();
}

function setDetailBusy(on) {
  ['detailSmartFillBtn', 'detailRefGenerateBtn', 'detailLinkGenerateBtn', 'detailModelGenerateBtn'].forEach(function (id) {
    if ($(id)) $(id).disabled = !!on;
  });
}

function generateDetailPrompt(mode, linkOverride, options) {
  options = options || {};
  setDetailMode(mode);
  if (linkOverride) syncLinkFields(linkOverride);
  if (!linkOverride || !options.silent) fillDetailFieldsFromContext();
  var payload = collectDetailPayload(mode, linkOverride);
  if (!payload.productImages.length) {
    showProductSubjectRequired('detail', detailProductRequiredMessage());
    return Promise.resolve({ ok: false, error: detailProductRequiredMessage() });
  }
  if (mode === 'reference' && (!payload.referenceImages || !payload.referenceImages.length)) {
    setPill('detailState', '请先上传 1-6 张参考页', 'warn');
    return Promise.resolve({ ok: false, error: '请先上传 1-6 张参考页' });
  }
  if (mode === 'link' && !Object.keys(payload.link || {}).length) {
    setPill('detailState', '请先粘贴链接清单 JSON', 'warn');
    return Promise.resolve({ ok: false, error: '请先粘贴链接清单 JSON' });
  }
  if (!options.silent) setDetailBusy(true);
  setPill('detailState', '详情页提词中...', '');
  var requestId = 'detail_prompt_' + Date.now() + '_' + Math.random().toString(16).slice(2);
  payload.requestId = requestId;
  payload.promptSource = mode === 'link' ? 'link' : 'reference';
  payload.linkId = mode === 'link' ? canonicalLinkId((payload.link || {})['链接编号'] || (payload.link || {}).linkId || (payload.link || {}).link_id, options.linkIndex) : '';
  payload.linkIndex = Number(options.linkIndex) || 0;
  var inputSnapshot = capturePromptInputSnapshot(mode === 'reference' ? 'reference' : 'link', 'detail', mode === 'link' ? payload.link : null, payload);
  return send('BUILD_DETAIL_PROMPT', { config: cfgFromForm(), payload: payload }).then(function (resp) {
    if (!options.silent) setDetailBusy(false);
    if (options.batchToken != null && options.batchToken !== state.batchPromptToken) return { ok: false, stale: true, error: '已被新的提词批次取代' };
    if (!promptInputSnapshotIsCurrent(inputSnapshot, mode === 'link' ? payload.link : null)) return stalePromptResponse('detail');
    var data;
    if (resp && resp.ok && mode === 'link') {
      var returnedLinkId = firstValue(resp.data || {}, ['链接编号', 'linkId', '编号', 'ID']);
      var normalizedReturnedId = returnedLinkId ? canonicalLinkId(returnedLinkId, options.linkIndex) : '';
      if (normalizedReturnedId && normalizedReturnedId !== payload.linkId) {
        resp = {
          ok: false,
          error: '模型返回的链接编号与当前任务不一致：期望 ' + payload.linkId + '，实际 ' + normalizedReturnedId
        };
      }
    }
    if (resp && resp.ok && !promptValueFromData(resp.data || {}, 'detail').trim()) {
      resp = { ok: false, error: '模型返回缺少中文详情提示词' };
    }
    if (resp && resp.ok) {
      data = enforceDetailPromptRules(resp.data || {}, payload);
      var record = rememberPromptRecord(makePromptRecord(mode === 'reference' ? 'reference' : 'link', 'detail', mode === 'link' ? payload.link : null, data, options.linkIndex, {
        ruleFingerprint: inputSnapshot.ruleFingerprint,
        requestId: requestId,
        promptBatchId: options.promptBatchId || ''
      }));
      if (!options.deferDisplay) displayPromptRecord(record);
      setPill('detailState', '详情页提示词完成', 'ok');
      syncDetailGenerationCount();
      if (!options.silent) window.setTimeout(function () { scrollToPanel('generationPanel'); }, 80);
      resp.promptRecord = record;
      return resp;
    }
    if (options.strictAi) {
      setPill('detailState', (resp && resp.error) || '详情页大模型提词失败', 'warn');
      return resp && typeof resp === 'object' ? resp : { ok: false, error: '详情页大模型提词失败' };
    }
    data = buildLocalDetailData(payload, (resp && resp.error) ? ('模型接口失败，已使用本地结构兜底：' + resp.error) : '模型接口失败，已使用本地结构兜底');
    data = enforceDetailPromptRules(data, payload);
    var fallbackRecord = rememberPromptRecord(makePromptRecord(mode === 'reference' ? 'reference' : 'link', 'detail', mode === 'link' ? payload.link : null, data, options.linkIndex, {
      ruleFingerprint: inputSnapshot.ruleFingerprint,
      requestId: requestId,
      promptBatchId: options.promptBatchId || ''
    }));
    if (!options.deferDisplay) displayPromptRecord(fallbackRecord);
    setPill('detailState', '模型失败，已生成本地兜底', 'warn');
    syncDetailGenerationCount();
    if (!options.silent) window.setTimeout(function () { scrollToPanel('generationPanel'); }, 80);
    return { ok: true, data: data, promptRecord: fallbackRecord, warning: (resp && resp.error) || '模型接口失败，已使用本地结构兜底' };
  });
}

function analyzeCurrentImage() {
  var images = referenceImageList();
  var image = images[0] || '';
  if (!image) { setPill('runState', '缺少参考页', 'warn'); return Promise.resolve({ ok: false, error: '缺少参考页' }); }
  var productImages = productImageList();
  if (!productImages.length) {
    showProductSubjectRequired(currentLabMode(), '请先上传至少 1 张商品主体图，再用参考图反推提示词；主体图用于锁定商品结构与比例。');
    return Promise.resolve({ ok: false, error: '缺少商品主体图' });
  }
  var cfg = cfgFromForm();
  var linkHint = '';
  setPill('runState', '正在按顺序分析 ' + images.length + ' 张参考页...', '');
  $('analyzeBtn').disabled = true;
  var inputSnapshot = capturePromptInputSnapshot('reference', 'main', null);
  return send('ANALYZE_IMAGE', { config: cfg, payload: {
    image: image,
    images: images,
    referenceImages: images,
    linkHint: linkHint,
    productImages: productImages,
    productImageEvidence: productImageEvidence()
  } }).then(function (resp) {
    $('analyzeBtn').disabled = false;
    if (!promptInputSnapshotIsCurrent(inputSnapshot, null)) return stalePromptResponse('main');
    if (resp && resp.ok && !promptValueFromData(resp.data || {}, 'main').trim()) resp = { ok: false, error: '模型返回缺少中文提示词' };
    if (resp && resp.ok) {
      state.referenceAnalysis = {
        imageFingerprint: currentReferenceFingerprint(),
        imageCount: images.length,
        productFingerprint: currentProductFingerprint(),
        data: resp.data || {},
        generatedAt: Date.now()
      };
      var record = rememberPromptRecord(makePromptRecord('reference', 'main', null, resp.data || {}, 0));
      displayPromptRecord(record);
      resp.promptRecord = record;
      setPill('runState', '提词完成', 'ok');
    } else {
      setPill('runState', (resp && resp.error) || '提词失败', 'warn');
    }
    return resp;
  });
}

function linkRowLabel(link, idx) {
  link = link || {};
  var id = canonicalLinkId(link['链接编号'] || link.linkId || link.link_id, idx);
  var text = link['链接定位'] || link['主推关键词'] || link['商品标题'] || link.keyword || '';
  text = ('' + text).replace(/\s+/g, ' ').slice(0, 18);
  return text ? (id + ' ' + text) : id;
}

function linkSequenceNumber(link, idx) {
  link = link || {};
  var raw = link['链接编号'] || link.linkId || link.link_id || '';
  if (!raw) return (idx || 0) + 1;
  var n = parseExplicitLinkSequence(raw);
  return isFinite(n) && n > 0 ? n : ((idx || 0) + 1);
}

function parseExplicitLinkSequence(raw) {
  var text = String(raw == null ? '' : raw).trim();
  if (!text) return NaN;
  var match = text.match(/^[Ll]\s*0*(\d+)$/) || text.match(/^0*(\d+)$/);
  var n = match ? parseInt(match[1], 10) : NaN;
  return isFinite(n) && n > 0 ? n : NaN;
}

function canonicalLinkId(raw, idx) {
  var n = parseExplicitLinkSequence(raw);
  if (!isFinite(n)) n = (idx || 0) + 1;
  if (!isFinite(n) || n < 1) n = (idx || 0) + 1;
  return formatLinkRangeCode(n);
}

function normalizeLinkRowsForBatch(rows, strict) {
  var seen = {};
  return (rows || []).map(function (raw, idx) {
    var row = Object.assign({}, raw || {});
    var explicit = row['链接编号'] || row.linkId || row.link_id;
    var sequence = parseExplicitLinkSequence(explicit);
    if (strict !== false && !isFinite(sequence)) {
      throw new Error('第 ' + (idx + 1) + ' 条链接缺少有效编号；请使用 L001 这样的完整编号。');
    }
    var id = formatLinkRangeCode(isFinite(sequence) ? sequence : (idx + 1));
    if (seen[id]) {
      if (strict !== false) throw new Error('链接编号重复：' + id + '。请先为每条链接设置唯一编号。');
      var seq = idx + 1;
      while (seen[formatLinkRangeCode(seq)]) seq++;
      id = formatLinkRangeCode(seq);
    }
    seen[id] = true;
    row['链接编号'] = id;
    return row;
  });
}

function formatLinkRangeCode(num) {
  num = parseInt(num, 10);
  num = isFinite(num) && num > 0 ? num : 1;
  return 'L' + (num < 1000 ? String(num).padStart(3, '0') : String(num));
}

function parseLinkRangeText(value) {
  var text = (value || '').trim();
  if (!text) return {};
  var nums = [];
  text.replace(/[Ll]\s*0*(\d+)|\b0*(\d+)\b/g, function (_, a, b) {
    var n = parseInt(a || b, 10);
    if (isFinite(n) && n > 0) nums.push(n);
    return _;
  });
  return {
    start: nums.length ? nums[0] : 0,
    end: nums.length > 1 ? nums[1] : 0
  };
}

function firstLinkSequence(rows) {
  if (!rows || !rows.length) return 1;
  return rows.map(function (row, idx) { return linkSequenceNumber(row, idx); }).sort(function (a, b) { return a - b; })[0] || 1;
}

function defaultBatchEndSequence(rows, start) {
  if (!rows || !rows.length) return start || 1;
  var sequences = rows.map(function (row, idx) { return linkSequenceNumber(row, idx); }).sort(function (a, b) { return a - b; });
  var target = sequences[Math.min(2, sequences.length - 1)];
  return Math.max(start || 1, target);
}

function isDefaultBatchRangeValue(startValue, endValue) {
  var start = parseLinkRangeText(startValue);
  var end = parseLinkRangeText(endValue);
  var startNum = start.start || 0;
  var endNum = end.end || end.start || start.end || 0;
  return (!startValue && !endValue) || (startNum === 1 && (!endNum || endNum === 3));
}

function syncBatchRangeDefaults(rows, force) {
  if (!rows || !rows.length) return;
  var startEl = $('batchLinkStart');
  var endEl = $('batchLinkEnd');
  if (!startEl || !endEl) return;
  var start = firstLinkSequence(rows);
  var end = defaultBatchEndSequence(rows, start);
  var canRefresh = force || isDefaultBatchRangeValue(startEl.value.trim(), endEl.value.trim());
  if (canRefresh || !startEl.value.trim()) startEl.value = formatLinkRangeCode(start);
  if (canRefresh || !endEl.value.trim()) endEl.value = formatLinkRangeCode(end);
}

function getBatchRange(rows) {
  rows = rows || [];
  var fallbackStart = firstLinkSequence(rows);
  var fallbackEnd = defaultBatchEndSequence(rows, fallbackStart);
  var startText = $('batchLinkStart') ? $('batchLinkStart').value : '';
  var endText = $('batchLinkEnd') ? $('batchLinkEnd').value : '';
  var startParsed = parseLinkRangeText(startText);
  var endParsed = parseLinkRangeText(endText);
  var explicitStart = startText.trim() ? parseExplicitLinkSequence(startText) : NaN;
  var explicitEnd = endText.trim() ? parseExplicitLinkSequence(endText) : NaN;
  if (startText.trim() && !isFinite(explicitStart)) throw new Error('起始链接编号无效，请填写如 L001。');
  if (endText.trim() && !isFinite(explicitEnd)) throw new Error('结束链接编号无效，请填写如 L003。');
  var start = isFinite(explicitStart) ? explicitStart : (startParsed.start || fallbackStart);
  var end = isFinite(explicitEnd) ? explicitEnd : (endParsed.end || endParsed.start || startParsed.end || fallbackEnd);
  if (start > end) {
    throw new Error('起始链接编号不能大于结束链接编号。');
  }
  return { start: start, end: end, label: formatLinkRangeCode(start) + '-' + formatLinkRangeCode(end) };
}

function selectRowsByLinkRange(rows) {
  var range = getBatchRange(rows);
  var selected = rows.map(function (row, idx) {
    return { row: row, seq: linkSequenceNumber(row, idx), sourceIndex: idx };
  }).filter(function (item) {
    return item.seq >= range.start && item.seq <= range.end;
  }).sort(function (a, b) {
    return a.seq - b.seq || a.sourceIndex - b.sourceIndex;
  }).map(function (item) { return item.row; });
  var present = {};
  selected.forEach(function (row, idx) { present[linkSequenceNumber(row, idx)] = true; });
  var missing = [];
  for (var seq = range.start; seq <= range.end; seq++) {
    if (!present[seq]) missing.push(formatLinkRangeCode(seq));
    if (missing.length >= 50) break;
  }
  return Object.assign(range, { rows: selected, missing: missing });
}

function syncLinkFields(link) {
  link = link || {};
  state.lastLink = link;
  var detail = currentLabMode() === 'detail';
  $('positioning').value = detail
    ? (link['详情页定位'] || link['链接定位'] || link.positioning || '')
    : (link['链接定位'] || link.positioning || '');
  $('imageCopy').value = detail
    ? (link['详情页文案'] || link['主图核心文案'] || link.imageCopy || '')
    : (link['主图核心文案'] || link.imageCopy || '');
}

function mainLinkPromptRuleLayer(link) {
  link = link || {};
  var id = canonicalLinkId(link['链接编号'] || link.linkId || link.link_id, 0);
  return [
    '【用户主图规则锁定｜' + id + '】',
    '本提示词只属于 ' + id + '，禁止混用其他 L 编号、旧批次提示词或参考图中的竞品主体。',
    '链接定位：' + (link['链接定位'] || '未填写'),
    '主推关键词：' + (link['主推关键词'] || '未填写'),
    '用户场景需求：' + (link['用户场景需求'] || '未填写'),
    '差异化定位逻辑：' + (link['差异化定位逻辑'] || '未填写'),
    '标题定位词路：' + (link['标题定位词路'] || '未填写'),
    '商品标题：' + (link['商品标题'] || '未填写'),
    '主图核心文案：' + (link['主图核心文案'] || '未填写'),
    '生图逻辑：先用用户上传的商品主体多角度图锁定唯一商品身份与结构比例，再将链接定位转为主画面任务、主推关键词转为品类与产品表达、用户场景需求转为使用线索、差异化定位逻辑转为可见证据、主图核心文案转为简洁的字体层级；标题定位词路与商品标题仅校准表达，不覆盖主体图真实商品；不得改形、拉伸、改色、增减部件或替换包装。'
  ].join('\n');
}

function enforceMainLinkPromptRules(data, link) {
  data = Object.assign({}, data || {});
  var prompt = promptValueFromData(data, 'main');
  var layer = mainLinkPromptRuleLayer(link);
  if (prompt.indexOf('【用户主图规则锁定｜') !== 0) prompt = layer + '\n\n' + prompt;
  data['中文提示词'] = prompt;
  data['链接编号'] = canonicalLinkId((link || {})['链接编号'] || (link || {}).linkId || (link || {}).link_id, 0);
  data['链接定位'] = (link || {})['链接定位'] || data['链接定位'] || '';
  return data;
}

function buildPromptForLink(link, label, options) {
  options = options || {};
  link = Object.assign({}, link || {});
  link['链接编号'] = canonicalLinkId(link['链接编号'] || link.linkId || link.link_id, options.linkIndex);
  syncLinkFields(link);
  if (!Object.keys(link).length) return Promise.resolve({ ok: false, error: '链接清单 JSON 无效' });
  if (!productImageList().length) {
    showProductSubjectRequired(currentLabMode());
    return Promise.resolve({ ok: false, error: productSubjectRequiredMessage(currentLabMode()) });
  }
  setPill('runState', '链接提词中' + (label ? '：' + label : '') + '...', '');
  if (!options.silent) $('buildPromptBtn').disabled = true;
  var requestId = 'main_prompt_' + Date.now() + '_' + Math.random().toString(16).slice(2);
  var inputSnapshot = capturePromptInputSnapshot('link', 'main', link);
  return send('BUILD_LINK_PROMPT', { config: cfgFromForm(), payload: {
    requestId: requestId,
    promptSource: 'link',
    linkId: link['链接编号'],
    linkIndex: Number(options.linkIndex) || 0,
    link: link,
    productImages: productImageList(),
    productImageEvidence: productImageEvidence()
  } }).then(function (resp) {
    if (!options.silent) $('buildPromptBtn').disabled = false;
    if (options.batchToken != null && options.batchToken !== state.batchPromptToken) return { ok: false, stale: true, error: '已被新的提词批次取代' };
    if (!promptInputSnapshotIsCurrent(inputSnapshot, link)) return stalePromptResponse('main');
    if (resp && resp.ok && !promptValueFromData(resp.data || {}, 'main').trim()) resp = { ok: false, error: '模型返回缺少中文提示词' };
    if (resp && resp.ok) {
      var data = enforceMainLinkPromptRules(resp.data || {}, link);
      var record = rememberPromptRecord(makePromptRecord('link', 'main', link, data, options.linkIndex, {
        requestId: requestId,
        promptBatchId: options.promptBatchId || ''
      }));
      if (!options.deferDisplay) displayPromptRecord(record);
      $('imageCopy').value = data['主图文案'] || $('imageCopy').value;
      setPill('runState', '主图提示词完成' + (label ? '：' + label : ''), 'ok');
      resp.promptRecord = record;
    } else {
      setPill('runState', (resp && resp.error) || '生成失败', 'warn');
    }
    return resp;
  });
}

function buildLinkPrompt() {
  var link;
  var linkIndex = 0;
  try {
    var rawRows = parseLinkListInput();
    // 多条链接时必须尊重上方起止编号。过去这里固定取 rows[0]，即使用户填写
    // L001-L003，点击主按钮也只会生成 L001，直到生图时才提示 L002/L003 缺失。
    if (rawRows.length > 1) {
      var normalizedRows = normalizeLinkRowsForBatch(rawRows, true);
      var rangeSelection = selectRowsByLinkRange(normalizedRows);
      if (rangeSelection.missing && rangeSelection.missing.length) {
        throw new Error('所选范围缺少链接编号：' + rangeSelection.missing.join('、') + '。请补齐后再提词。');
      }
      if (!rangeSelection.rows.length) throw new Error('当前编号范围没有匹配的链接。');
      // 多行链接清单一律复用严格批次流程；即使范围只选 L002-L002，也要生成
      // 非空 promptBatchId，保证下一步“按编号并发生图”能够识别为完整批次。
      return generateSelectedLinkPrompts();
    } else {
      link = parseLinkJson();
      linkIndex = Math.max(0, linkSequenceNumber(link, 0) - 1);
    }
  } catch (e) {
    setPill('runState', e.message, 'warn');
    return Promise.resolve({ ok: false, error: e.message });
  }
  if (currentLabMode() === 'detail') return generateDetailPrompt('link', link, { silent: false, linkIndex: linkIndex });
  return buildPromptForLink(link, '', { silent: false, linkIndex: linkIndex });
}

function generateDetailPromptFromPrimaryAction() {
  // 详情面板的主按钮过去在“按链接规划”模式下直接调用 generateDetailPrompt('link')，
  // 只保存一条没有完整批次号的提示词，完全绕过 L001-L003 起止范围。详情按编号
  // 生图随后按严格批次检查，就会把其余编号判为缺失。链接模式统一复用严格范围流程。
  if ((state.detailMode || 'reference') === 'link') return generateSelectedLinkPrompts();
  return generateDetailPrompt('reference');
}

function promptText(value) {
  if (!value) return '';
  if (Array.isArray(value)) return value.join(', ');
  if (typeof value === 'object') return JSON.stringify(value);
  return '' + value;
}

function firstAnalysisValue(data, keys) {
  data = data || {};
  for (var i = 0; i < keys.length; i++) {
    var v = data[keys[i]];
    if (v) return promptText(v);
  }
  return '';
}

function referenceStyleNotes(data) {
  data = data || {};
  var rows = [
    ['Page story sequence', ['参考页面故事逻辑', '页面故事逻辑', '叙事顺序', 'story_sequence']],
    ['Copywriting style', ['文案风格', '文案语气', 'copy_style']],
    ['Composition/layout', ['构图', '画面布局', '版式结构', 'layout']],
    ['Page layout system', ['页面布局结构', '页面结构', '版式节奏', 'page_layout']],
    ['Camera/view', ['镜头', 'camera']],
    ['Depth of field', ['景深', 'depth_of_field', '背景层次']],
    ['Lighting', ['光线', 'lighting']],
    ['Color palette', ['色彩', 'color_palette', '色彩系统']],
    ['Background/mood', ['背景', 'background']],
    ['Background elements', ['背景元素', '场景元素', 'background_elements']],
    ['Material/texture', ['材质', 'texture']],
    ['Visual style', ['风格', 'style', 'style_tags']],
    ['Typography/font', ['字体', '字体样式', 'font', 'typography']],
    ['Font-size hierarchy', ['字号', '字号层级', '字号与文字层级', '文字层级', 'font_size']],
    ['Model/person setup', ['模特', '模特设定', '人物设定', 'model_setup']],
    ['Old subject to replace', ['旧主体识别', '参考主体', 'old_subjects']],
    ['New subject integration', ['新主体融入逻辑', '主体替换逻辑', 'subject_integration']],
    ['Commercial direction', ['主图方向', '风格定位']]
  ].map(function (item) {
    var v = firstAnalysisValue(data, item[1]);
    return v ? item[0] + ': ' + v : '';
  }).filter(Boolean);
  return rows.join('\n');
}

function ensurePromptSubjectRule(text, lang) {
  text = (text || '').trim();
  if (!text) return '';
  if (/产品主体图|uploaded product-subject|target product subject|only hero product/i.test(text)) return text;
  if (lang === 'en') {
    return [
      'Highest priority subject replacement rule: the final product subject must be the uploaded multi-angle product-subject images. Preserve exact geometry, proportions, package structure, colors, materials and key parts; never stretch, deform, redesign or merge the product. The reference image, competitor image, link notes, previous result and editable prompt only provide style, composition, lighting, layout, typography hierarchy, scene and copy direction. Replace every old product/package/brand/SKU from those lower-priority sources with the uploaded target product.',
      text
    ].join('\n');
  }
  return [
    '【主体替换最高优先级】最终商品主体必须严格以当前上传的多角度产品主体图为准；保持真实几何形态、长宽厚比例、包装结构、颜色、材质、部件和文字位置一致，禁止拉伸、变形、重绘结构、增减部件或混合不同角度。参考图/竞品图/链接清单/历史结果/旧提示词只提供风格、构图、光影、版式、字体层级、场景和文案方向，里面出现的旧商品、旧包装、旧品牌、旧 SKU 必须替换成产品主体图里的目标商品。',
    text
  ].join('\n');
}

function subjectReplacementPrompt(productImages) {
  productImages = Array.isArray(productImages) ? productImages : (productImages ? [productImages] : []);
  if (!productImages.length) return '';
  var labels = productImages.map(function (item, idx) {
    return item && typeof item === 'object' ? (item.label || item.angle || ('view ' + (idx + 1))) : ('view ' + (idx + 1));
  });
  var angleText = productImages.length > 1
    ? 'Use all uploaded product-subject inputs as cross-view identity evidence (' + labels.join(', ') + '). Resolve every visible surface against the matching view.'
    : 'Use the uploaded product-subject input as the new product identity evidence.';
  return [
    'SUBJECT REPLACEMENT MODE:',
    angleText,
    'Target subject = the uploaded product-subject images. These product-subject images define the ONLY hero product in the final ad.',
    'This is the highest visual identity rule and it overrides reference-image subjects, link-list product wording, previous generated results, template products and editable prompt text when they conflict.',
    'Any product, package, gift box, category, SKU, brand mark, text layout, bottle, bag, food, cosmetic, appliance, model-held item, or prop identity from the reference image, link notes, previous result, or editable prompt is lower priority and must be replaced when it conflicts with the uploaded product subject.',
    'Recreate the product from all product evidence with cross-view consistency: exact package shape, SKU count, front-facing structure, side thickness, back/detail information, main colors, materials, key parts, label hierarchy, visible logo/text placement and realistic proportions. Never stretch, deform, redesign, add or remove parts, or blend incompatible angles.',
    'The reference/competitor image is only for composition, camera angle, lighting, color mood, background depth, commercial layout, font hierarchy, typography rhythm and prop atmosphere.',
    'Replace every old product or package from the reference image and from any reference notes. Do not generate the competitor subject, competitor logo, competitor packaging, old gift contents, old bottles, old boxes, old snacks, old toiletries, old model-held item or old props as the main product.',
    'If the lower-priority prompt describes a different product subject, keep only its useful style/layout words and rewrite the visible product as the uploaded target product.',
    'Final image requirement: the new product is large, clear, commercially centered, properly lit, with natural shadow and no subject confusion.'
  ].join('\n');
}

function replacementNegativePrompt() {
  return 'old reference product, old template product, competitor product, competitor packaging, competitor brand logo, original reference subject, unchanged reference subject, wrong product category, wrong SKU, old model-held item, product hidden, product cropped, product replaced by props, mixed old and new products, distorted package, unreadable fake text';
}

function guidePriorityLayer(guide, hasProductImage) {
  if (!guide) return '';
  return [
    'HIGHEST PRIORITY SEMANTIC GUIDE LAYER:',
    'User guide: ' + guide,
    'Conflict rule: if this guide conflicts with the reference image, editable prompt notes, link prompt, previous generated result, product props, or any lower-priority description, this guide wins semantically.',
    'Implementation rule: do not render the guide as visible text. Translate it into natural visual decisions: subject selection, prop replacement, container choice, crop, occlusion, spatial layout, camera angle, material choice, and background simplification.',
    'Integration rule: keep the image commercially believable and visually integrated. Do not force an awkward literal object unless it naturally belongs in the product scene.',
    hasProductImage ? 'Product authority: the uploaded product subject image still has the highest visual identity authority for the final product; the guide controls what must be changed around it and which conflicting reference elements must disappear or be softened.' : '',
    'If the guide says an element should be replaced or removed, remove the conflicting old element from the scene and replace it with a visually compatible e-commerce display solution.'
  ].filter(Boolean).join('\n');
}

function activeGenerationBasePrompt() {
  if (currentLabMode() === 'detail') {
    return (($('detailPrompt') && $('detailPrompt').value.trim()) || ($('cnPrompt') && $('cnPrompt').value.trim()) || '');
  }
  return (($('cnPrompt') && $('cnPrompt').value.trim()) || '');
}

function detailVariantPrefix(variant) {
  var map = {
    single: 'Generate one polished standalone e-commerce detail-page screen based on the detail-page prompt. ',
    guide: 'Regenerate the selected standalone detail-page screen with the guide as the highest semantic priority. ',
    main: 'Product opening detail screen, clear hero identity and conversion headline, without visible screen number. ',
    scene: 'Detail screen for usage scenario, pain-point context and realistic product fit. ',
    hook: 'Detail screen for key benefit proof, memorable visual hook and simple evidence layout. ',
    diff: 'Detail screen for differentiated advantage, competitor-avoidance and trust-building proof. '
  };
  return map[variant] || map.single;
}

function detailScreenSequenceLayer(index, total, planSource) {
  if (currentLabMode() !== 'detail' || total <= 1) return '';
  var sections = detailSectionNames(total);
  var plans = planSource && planSource.data && Array.isArray(planSource.data['屏幕规划']) ? planSource.data['屏幕规划'] : [];
  var plan = plans[index - 1] || (planSource && planSource.detailScreenPlan) || {};
  var sectionName = firstValue(plan, ['名称', '标题', '屏幕名称']) || sections[index - 1] || ('详情页第' + index + '屏');
  var planDirection = [
    firstValue(plan, ['承接关系']),
    firstValue(plan, ['画面方向', '商业分镜']),
    firstValue(plan, ['文案方向']),
    firstValue(plan, ['主体图使用']),
    firstValue(plan, ['模特使用']),
    firstValue(plan, ['生图提示词'])
  ].filter(Boolean).join('\n');
  return [
    'HIGHEST PRIORITY DETAIL SCREEN SEQUENCE LAYER:',
    'Generate ONLY screen ' + index + ' of ' + total + ': ' + sectionName + '.',
    planDirection ? 'Use this L-number specific screen plan exactly:\n' + planDirection : '',
    'This sequence text is internal planning only. Do NOT render visible 01/02/03 numbers, screen labels, ranking badges, page indexes or directory numbers inside the image.',
    'Do not render the full long detail page in one image. Do not merge multiple screens into one image. The workstation will stitch images later only when the user checks the long-preview option.',
    'Make this a complete standalone commercial detail screen with one primary selling point or usage story, not a sliced strip, not a collage, not an index page.',
    'This screen must continue the same visual system as the other screens: same font family style, headline size, subtitle size, body-copy size, margin rhythm, color palette, lighting, product identity and page layout grammar.',
    'Use the uploaded product subject image(s) as the final product identity for this screen. Reference images and previous generated images only provide style, composition and typography rhythm.'
  ].join('\n');
}

function detailGenerationPrompt(variant, base, guide, productImages, promptRecord, modelImages, referenceImages) {
  modelImages = modelImages || [];
  referenceImages = Array.isArray(referenceImages) ? referenceImages : (referenceImages ? [referenceImages] : []);
  var isLinkPrompt = promptRecord && promptRecord.source === 'link';
  return [
    guidePriorityLayer(guide, true),
    'DETAIL PAGE IMAGE GENERATION MODE:',
    detailVariantPrefix(variant),
    'Use the detail-page prompt as the source of screen planning, visual hierarchy, product selling points and copy direction.',
    subjectReplacementPrompt(productImages),
    isLinkPrompt ? detailLinkPlanningLayer(promptRecord.link || {}) : '',
    modelImages.length ? 'Optional model references are available: use them only when the selected detail screen naturally needs a person for scale, usage, emotion, fit, or trust. The model must not replace, hide, or rewrite the product subject.' : '',
    !isLinkPrompt && referenceImages.length ? ('Use all ' + referenceImages.length + ' reference pages in their uploaded order to learn the full page story sequence, copywriting tone, font hierarchy, background elements, light/depth system and layout grammar. Detect every old product/packaging subject across those pages and replace it with the uploaded target product; never blend old and new subjects.') : '',
    isLinkPrompt ? 'Link-detail source: use detail positioning, detail copy and detail-copy logic from this L-number record. Do not reuse the current reference-image analysis or another link prompt.' : '',
    'Do not place visible screen numbers, 01-10 index labels, page badges or ordering marks in the generated detail image. File download order is handled by the plugin, not by the image design.',
    'Detail prompt:\n' + base,
    'Negative prompt additions: ' + detailCommercialNegativePrompt(),
    'Avoid copying competitor brands, visible trademarks, old packaging text, old products, fake unreadable tiny text, over-crowded layouts, or hiding the product.'
  ].filter(Boolean).join('\n');
}

function detailLinkPlanningLayer(link) {
  link = link || {};
  var id = canonicalLinkId(link['链接编号'] || link.linkId || link.link_id, 0);
  return [
    'DETAIL LINK RULE LOCK — ' + id + ':',
    'This screen belongs only to ' + id + '; never mix another L-number, an old batch prompt, or reference-image analysis.',
    'Link positioning: ' + (firstValue(link, ['链接定位']) || '未填写'),
    'Primary keywords: ' + (firstValue(link, ['主推关键词']) || '未填写'),
    'User scenario need: ' + (firstValue(link, ['用户场景需求']) || '未填写'),
    'Differentiation logic: ' + (firstValue(link, ['差异化定位逻辑']) || '未填写'),
    'Detail positioning: ' + (firstValue(link, ['详情页定位', '链接定位']) || '未填写'),
    'Detail copy: ' + (firstValue(link, ['详情页文案', '主图核心文案']) || '未填写'),
    'Detail copy logic: ' + (firstValue(link, ['详情文案逻辑', '详情页逻辑', '详情逻辑']) || '痛点 -> 场景 -> 功能 -> 对比 -> 使用教程'),
    link['标题定位词路'] ? 'Title positioning route: ' + link['标题定位词路'] : '',
    link['商品标题'] ? 'Product title: ' + link['商品标题'] : '',
    link['主图核心文案'] ? 'Main-image core copy: ' + link['主图核心文案'] : '',
    'Follow the numbered screen plan in exact order while preserving the uploaded multi-angle product as the only immutable product identity.'
  ].filter(Boolean).join('\n');
}

function mainLinkPlanningLayer(link) {
  link = link || {};
  var id = canonicalLinkId(link['链接编号'] || link.linkId || link.link_id, 0);
  return [
    'MAIN IMAGE PLANNING LAYER — ' + id + ':',
    link['链接定位'] ? 'Link positioning: ' + link['链接定位'] : '',
    link['主推关键词'] ? 'Primary keywords: ' + link['主推关键词'] : '',
    link['用户场景需求'] ? 'User scenario need: ' + link['用户场景需求'] : '',
    link['差异化定位逻辑'] ? 'Differentiation logic: ' + link['差异化定位逻辑'] : '',
    link['标题定位词路'] ? 'Title positioning route: ' + link['标题定位词路'] : '',
    link['商品标题'] ? 'Product title: ' + link['商品标题'] : '',
    link['主图核心文案'] ? 'Main-image core copy: ' + link['主图核心文案'] : '',
    'Generation logic: first lock the uploaded product identity from its multi-angle evidence; then translate the link positioning into the main visual task, primary keywords into category/product cues, the user scenario need into usage cues, differentiation logic into visible proof, and the core copy into a concise typography hierarchy. Title route and product title calibrate expression only. Never trade product accuracy for style.'
  ].filter(Boolean).join('\n');
}

function validateGenerationReady() {
  var mode = currentLabMode();
  if (!productImageList().length) return showProductSubjectRequired(mode);
  if (mode === 'detail' && !activeGenerationBasePrompt()) {
    setPill('detailState', '请先生成详情页提示词', 'warn');
    setPill('generateState', '请先生成详情页提示词', 'warn');
    return false;
  }
  if (mode !== 'detail' && !activeGenerationBasePrompt()) {
    setPill('generateState', '请先生成或填写提示词', 'warn');
    return false;
  }
  return true;
}

function normalizeRatioValue(value) {
  var text = String(value || '').trim();
  var match = text.match(/(\d+)\s*:\s*(\d+)/);
  return match ? (match[1] + ':' + match[2]) : text;
}

function detailScreenCountForGeneration() {
  var screenEl = $('detailScreenCount');
  var mode = state.detailMode || 'reference';
  var bounds = detailScreenBounds(mode);
  return clampInt(screenEl && screenEl.value, bounds.min, bounds.max, bounds.fallback);
}

function syncGenerationParamSummary() {
  var el = $('generationParamSummary');
  if (!el) return;
  if (currentLabMode() !== 'detail') return;
  var count = detailScreenCountForGeneration();
  el.textContent = '详情生图沿用上方参数：' + count + ' 屏 = ' + count + ' 张独立图片；比例 ' + generationRatio() + '，清晰度 ' + generationResolution() + '；生成后可手动勾选拼接成长详情预览。';
}

function generationRatio() {
  if (currentLabMode() === 'detail') {
    return normalizeRatioValue(($('detailRatio') && $('detailRatio').value) || '3:4') || '3:4';
  }
  return (($('imageRatio') && $('imageRatio').value) || '1:1').trim();
}

function generationResolution() {
  if (currentLabMode() === 'detail') {
    return (($('detailResolution') && $('detailResolution').value) || '2K').toUpperCase();
  }
  return (($('imageResolution') && $('imageResolution').value) || '1K').toUpperCase();
}

function generationImageCount(value) {
  if (!value && currentLabMode() === 'detail') {
    return detailScreenCountForGeneration();
  }
  return clampInt(value || ($('imageCount') && $('imageCount').value), 1, 20, 1);
}

function generationResolutionScale(resolution) {
  resolution = (resolution || '1K').toUpperCase();
  if (resolution === '4K') return 4;
  if (resolution === '2K') return 2;
  return 1;
}

function generationSizeFromSettings(settings) {
  settings = settings || {};
  var ratio = settings.ratio || generationRatio();
  var resolution = settings.resolution || generationResolution();
  var base = {
    '1:1': [1024, 1024],
    '3:4': [768, 1024],
    '16:9': [1792, 1024],
    '9:16': [1024, 1792],
    '21:9': [2048, 878]
  }[ratio] || [1024, 1024];
  var scale = generationResolutionScale(resolution);
  return Math.round(base[0] * scale) + '*' + Math.round(base[1] * scale);
}

function captureGenerationSettings(labMode, detailMode, countOverride) {
  labMode = labMode || currentLabMode();
  detailMode = detailMode || state.detailMode || 'reference';
  var ratio;
  var resolution;
  var count;
  if (labMode === 'detail') {
    var bounds = detailScreenBounds(detailMode);
    ratio = normalizeRatioValue(($('detailRatio') && $('detailRatio').value) || '3:4') || '3:4';
    resolution = (($('detailResolution') && $('detailResolution').value) || '2K').toUpperCase();
    count = clampInt(countOverride || ($('detailScreenCount') && $('detailScreenCount').value), bounds.min, bounds.max, bounds.fallback);
  } else {
    ratio = (($('imageRatio') && $('imageRatio').value) || '1:1').trim();
    resolution = (($('imageResolution') && $('imageResolution').value) || '1K').toUpperCase();
    count = clampInt(countOverride || ($('imageCount') && $('imageCount').value), 1, 20, 1);
  }
  var settings = { labMode: labMode, detailMode: detailMode, ratio: ratio, resolution: resolution, count: count };
  settings.size = generationSizeFromSettings(settings);
  return Object.freeze(settings);
}

function generationParamPromptLayer(count, settings) {
  settings = settings || captureGenerationSettings(currentLabMode(), state.detailMode, count);
  count = Number(settings.count) || generationImageCount(count);
  return [
    'HIGHEST PRIORITY GENERATION PARAMETER LAYER:',
    'Image ratio must be exactly ' + settings.ratio + '.',
    'Target resolution and clarity level must be exactly ' + settings.resolution + '.',
    'Workflow target count is ' + count + ' image(s). If this workflow is split into screen-by-screen requests, each request generates only its assigned screen while preserving the total workflow count.',
    'These three user-selected generation parameters override any older size, clarity, resolution, watermark, batch direction, quantity, or aspect-ratio instructions in reference prompts, link JSON, detail prompts, SKU prompts, previous generated prompts, or model analysis.',
    'Do not add watermark. Do not follow old batch-direction logic. Keep only the selected image ratio, selected clarity/resolution level, and selected image count.'
  ].join('\n');
}

function requestCountChunks(total) {
  var chunks = [];
  var left = clampInt(total, 1, 20, 1);
  while (left > 0) {
    chunks.push(Math.min(4, left));
    left -= 4;
  }
  return chunks;
}

function generationPrompt(variant, promptRecord, generationOptions) {
  generationOptions = generationOptions || {};
  var base = promptRecord && promptRecord.prompt ? promptRecord.prompt : activeGenerationBasePrompt();
  var guide = (variant === 'guide' && $('guidePrompt')) ? $('guidePrompt').value.trim() : '';
  var source = promptRecord && promptRecord.source;
  var link = promptRecord ? (promptRecord.link || {}) : (state.lastLink || {});
  var pos = source === 'reference' ? '' : (source === 'link' ? (link['链接定位'] || '') : (link['链接定位'] || ($('positioning') ? $('positioning').value.trim() : '')));
  var copy = source === 'reference' ? '' : (source === 'link' ? (link['主图核心文案'] || '') : (link['主图核心文案'] || ($('imageCopy') ? $('imageCopy').value.trim() : '')));
  var productImages = generationOptions.productImages || productImageList();
  var productEvidence = generationOptions.productImageEvidence || productImageEvidence();
  if (!productEvidence.length && productImages.length) {
    productEvidence = productImages.map(function (image, idx) { return { image: image, label: '商品角度图 ' + (idx + 1) }; });
  }
  var productImage = productImages[0] || '';
  var styleNotes = referenceStyleNotes(source === 'reference' ? promptRecord.data : state.referenceAnalysis && state.referenceAnalysis.data);
  var prefix = '';
  if (currentLabMode() === 'detail') return detailGenerationPrompt(
    variant,
    base,
    guide,
    productEvidence,
    promptRecord,
    generationOptions.modelImages || modelImageList(),
    generationOptions.referenceImages != null
      ? generationOptions.referenceImages
      : (generationOptions.referenceImage != null ? [generationOptions.referenceImage] : referenceImageList())
  );
  if (variant === 'main') prefix = 'E-commerce hero main image, strong conversion focus. ';
  if (variant === 'scene') prefix = 'Lifestyle scenario image for e-commerce, natural product usage scene. ';
  if (variant === 'hook') prefix = 'Visual hook image, memorable key visual, clear product benefit. ';
  if (variant === 'diff') prefix = 'Differentiated competitor-avoidance e-commerce image, original layout. ';
  if (!productImage) return '';
  return [
    guidePriorityLayer(guide, true),
    prefix + 'Create a new e-commerce ad image with product subject replacement.',
    subjectReplacementPrompt(productEvidence),
    source === 'link' ? mainLinkPlanningLayer(link) : '',
    source !== 'link' && styleNotes ? 'Reference style/layout notes to borrow, excluding its product/category:\n' + styleNotes : '',
    pos ? 'Link positioning: ' + pos : '',
    copy ? 'Main visual copy direction: ' + copy : '',
    link['主推关键词'] ? 'New product keywords/context: ' + link['主推关键词'] : '',
    link['用户场景需求'] ? 'User scenario need: ' + link['用户场景需求'] : '',
    link['差异化定位逻辑'] ? 'Differentiation logic: ' + link['差异化定位逻辑'] : '',
    link['标题定位词路'] ? 'Title positioning route: ' + link['标题定位词路'] : '',
    link['商品标题'] ? 'New product title direction: ' + link['商品标题'] : '',
    source !== 'link' ? 'Do not use the reference image subject as the product. Keep only its visual grammar.' : 'This link prompt does not authorize borrowing any competitor subject or packaging.',
    base ? 'LOWER PRIORITY editable prompt notes. Use only the parts that do not conflict with the highest priority guide or product subject:\n' + base : '',
    'Avoid using real brand logos, trademarked packaging layouts, unreadable text, or copying competitor design.'
  ].filter(Boolean).join('\n');
}

function detailPreviewResults() {
  if (currentLabMode() !== 'detail') return [];
  return state.results.filter(function (item) {
    return item && item.url && item.labMode === 'detail';
  }).slice().sort(function (a, b) {
    var ai = Number(a.linkIndex) || 0;
    var bi = Number(b.linkIndex) || 0;
    if (ai !== bi) return ai - bi;
    var aid = a.linkId || '';
    var bid = b.linkId || '';
    if (aid !== bid) return aid.localeCompare(bid);
    return (a.detailScreenIndex || 0) - (b.detailScreenIndex || 0);
  });
}

function detailScreenHoverPrompt(index, total, item) {
  var prompt = item && item.prompt ? item.prompt : (($('detailPrompt') && $('detailPrompt').value.trim()) || '');
  var layer = detailScreenSequenceLayer(index, total, item);
  return [layer, prompt].filter(Boolean).join('\n\n').trim() || ('第 ' + index + ' 屏提示词将在生成后显示');
}

function compactDetailTitle(text, fallback) {
  text = textValue(text)
    .replace(/HIGHEST PRIORITY DETAIL SCREEN SEQUENCE LAYER[\s\S]*?Use the uploaded product subject image\(s\).*?\n?/g, '')
    .replace(/第\s*\d+\s*屏单独详情图/g, '')
    .replace(/不是长图拼接|不是十宫格|不包含其他屏幕/g, '')
    .replace(/^(商业分镜|画面方向|画面|文案方向|文案|提示词|生图提示词|名称|标题)\s*[:：]/, '')
    .replace(/围绕“[^”]+”做/g, '')
    .replace(/详情页|详情图|商业|成熟电商|单屏|画面|镜头/g, '')
    .replace(/[【】"'“”]/g, '')
    .trim();
  var first = text.split(/[。；;，,\n]/).map(function (part) { return part.trim(); }).filter(Boolean)[0] || '';
  first = first
    .replace(/^(一个|一张|通过|展示|突出|强调|建立|承接|推进到|聚焦|围绕)/, '')
    .replace(/\s+/g, '')
    .trim();
  if (!first) first = fallback || '详情纲要';
  return first.length > 10 ? first.slice(0, 10) : first;
}

function detailJsonScreenPlan() {
  var raw = $('detailJson') && $('detailJson').textContent;
  if (!raw || !raw.trim()) return [];
  try {
    var data = JSON.parse(raw);
    return Array.isArray(data['屏幕规划']) ? data['屏幕规划'] : [];
  } catch (e) {
    return [];
  }
}

function detailPromptSectionText(index) {
  var prompt = ($('detailPrompt') && $('detailPrompt').value.trim()) || '';
  if (!prompt) return '';
  var escaped = String(index).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  var next = String(index + 1).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  var re = new RegExp('(?:^|\\n)\\s*(?:' + escaped + '|0?' + escaped + '|第\\s*' + escaped + '\\s*屏|Screen\\s*' + escaped + ')[\\.、:：\\s][\\s\\S]*?(?=\\n\\s*(?:' + next + '|0?' + next + '|第\\s*' + next + '\\s*屏|Screen\\s*' + next + ')[\\.、:：\\s]|\\n【负面提示词】|$)', 'i');
  var m = prompt.match(re);
  return m ? m[0] : '';
}

function detailSlotTitle(index, total, item) {
  var fallback = detailSectionNames(total)[index - 1] || '详情纲要';
  var plan = detailJsonScreenPlan();
  var section = (item && item.detailScreenPlan) || plan[index - 1] || {};
  var source = section['名称'] || section['商业分镜'] || section['画面方向'] || section['文案方向'] || section['生图提示词'] ||
    (item && item.variantName) || detailPromptSectionText(index) || (item && item.prompt) || fallback;
  return (item && item.linkId ? (item.linkId + ' · ') : '') + padDownloadSeq(index) + ' ' + compactDetailTitle(source, fallback);
}

function generatedImagePreviewCaption(item, fallback) {
  item = item || {};
  return textValue(item.variantName || item.variant || item.linkId || fallback || '生成图预览');
}

function openGeneratedImagePreview(item, fallbackCaption) {
  item = typeof item === 'string' ? { url: item } : (item || {});
  var url = item.url || item.src || '';
  var modal = $('generatedImagePreviewModal');
  var image = $('generatedImagePreviewImg');
  if (!url || !modal || !image) return { ok: false, error: '缺少可预览图片' };
  var caption = generatedImagePreviewCaption(item, fallbackCaption);
  state.imagePreviewPreviousFocus = document.activeElement || null;
  image.src = url;
  image.alt = caption || '生成图大图预览';
  if ($('generatedImagePreviewCaption')) $('generatedImagePreviewCaption').textContent = caption;
  modal.hidden = false;
  if (document.body) document.body.classList.add('generated-image-preview-open');
  if ($('generatedImagePreviewClose')) $('generatedImagePreviewClose').focus();
  return { ok: true, url: url };
}

function closeGeneratedImagePreview() {
  var modal = $('generatedImagePreviewModal');
  if (modal) modal.hidden = true;
  if ($('generatedImagePreviewImg')) {
    $('generatedImagePreviewImg').src = '';
    $('generatedImagePreviewImg').alt = '生成图大图预览';
  }
  if ($('generatedImagePreviewCaption')) $('generatedImagePreviewCaption').textContent = '';
  if (document.body) document.body.classList.remove('generated-image-preview-open');
  var previous = state.imagePreviewPreviousFocus;
  state.imagePreviewPreviousFocus = null;
  try { if (previous && previous.focus) previous.focus(); } catch (e) {}
}

function makeGeneratedImagePreviewable(img, item, fallbackCaption) {
  if (!img || !item || !item.url) return img;
  img.classList.add('generated-image-previewable');
  img.tabIndex = 0;
  img.setAttribute('role', 'button');
  img.setAttribute('aria-label', '查看大图：' + generatedImagePreviewCaption(item, fallbackCaption));
  img.title = '单击查看居中大图';
  img.addEventListener('click', function (ev) {
    if (ev && typeof ev.button === 'number' && ev.button !== 0) return;
    openGeneratedImagePreview(item, fallbackCaption);
  });
  img.addEventListener('keydown', function (ev) {
    if (!ev || (ev.key !== 'Enter' && ev.key !== ' ')) return;
    if (ev.preventDefault) ev.preventDefault();
    openGeneratedImagePreview(item, fallbackCaption);
  });
  return img;
}

function detailStitchItemKey(item) {
  item = item || {};
  return [
    item.batchId || item.promptBatchId || item.promptId || 'single',
    item.linkId || 'reference',
    item.detailScreenIndex || item.linkImageIndex || item.sourceIndex || 0,
    sourceFingerprint(item.url || '')
  ].join('|');
}

function detailStitchSelectedItems() {
  var byKey = {};
  detailPreviewResults().forEach(function (item) { byKey[detailStitchItemKey(item)] = item; });
  state.detailStitchSelectionOrder = (state.detailStitchSelectionOrder || []).filter(function (key) { return !!byKey[key]; });
  return state.detailStitchSelectionOrder.map(function (key) { return byKey[key]; }).filter(Boolean).slice(0, 20);
}

function syncDetailStitchSelectionUi() {
  var order = state.detailStitchSelectionOrder || [];
  if ($('detailStitchSelectedCount')) $('detailStitchSelectedCount').textContent = '拼接所选长图（' + order.length + ' / 20）';
  var grid = $('resultGrid');
  if (!grid || !grid.querySelectorAll) return;
  Array.prototype.slice.call(grid.querySelectorAll('.detail-stitch-item-toggle') || []).forEach(function (control) {
    var key = control.dataset && control.dataset.stitchKey || '';
    var position = order.indexOf(key);
    var checkbox = control.querySelector ? control.querySelector('input') : null;
    var marker = control.querySelector ? control.querySelector('.detail-stitch-item-order') : null;
    if (checkbox) checkbox.checked = position >= 0;
    control.classList.toggle('is-selected', position >= 0);
    if (marker) {
      marker.hidden = position < 0;
      marker.textContent = position >= 0 ? padDownloadSeq(position + 1) : '';
    }
  });
}

function updateDetailStitchSelection(item, checked, checkbox) {
  var key = detailStitchItemKey(item);
  var order = state.detailStitchSelectionOrder || (state.detailStitchSelectionOrder = []);
  var current = order.indexOf(key);
  if (checked && current < 0) {
    if (order.length >= 20) {
      if (checkbox) checkbox.checked = false;
      var message = '一次最多勾选 20 张详情图拼接；请先取消一张再选。';
      setPill('generateState', message, 'warn');
      if (window.alert) window.alert(message);
      syncDetailStitchSelectionUi();
      renderDetailLongPreview();
      return false;
    }
    order.push(key);
  } else if (!checked && current >= 0) {
    order.splice(current, 1);
  }
  if (checked && $('detailStitchToggle')) $('detailStitchToggle').checked = true;
  syncDetailStitchSelectionUi();
  renderDetailLongPreview();
  return true;
}

function addDetailStitchSelectionControl(card, item) {
  if (!card || !item || !item.url) return;
  var key = detailStitchItemKey(item);
  var label = document.createElement('label');
  label.className = 'detail-stitch-item-toggle';
  label.dataset.stitchKey = key;
  var checkbox = document.createElement('input');
  checkbox.type = 'checkbox';
  checkbox.setAttribute('aria-label', '选入长图：' + generatedImagePreviewCaption(item, '详情图'));
  var text = document.createElement('span');
  text.textContent = '选入长图';
  var marker = document.createElement('b');
  marker.className = 'detail-stitch-item-order';
  marker.hidden = true;
  checkbox.addEventListener('change', function () {
    updateDetailStitchSelection(item, !!checkbox.checked, checkbox);
  });
  label.appendChild(checkbox);
  label.appendChild(text);
  label.appendChild(marker);
  card.appendChild(label);
}

function createDetailResultSlot(index, total, item) {
  var card = document.createElement('div');
  card.className = 'result-card detail-result-card' + (item && item.url ? ' has-image' : ' is-placeholder');
  card.title = detailScreenHoverPrompt(index, total, item);

  var preview = document.createElement('div');
  preview.className = 'detail-screen-preview';
  if (item && item.url) {
    var img = document.createElement('img');
    img.src = item.url;
    img.alt = item.variantName || ('详情页第 ' + index + ' 屏');
    makeGeneratedImagePreviewable(img, item, detailSlotTitle(index, total, item));
    preview.appendChild(img);
  } else {
    var slot = document.createElement('div');
    slot.className = 'detail-screen-placeholder';
    slot.innerHTML = '<strong>' + padDownloadSeq(index) + '</strong><span>待生成</span>';
    preview.appendChild(slot);
  }

  var meta = document.createElement('div');
  meta.className = 'result-meta';
  var strong = document.createElement('strong');
  strong.textContent = detailSlotTitle(index, total, item);
  var urlLine = document.createElement('div');
  urlLine.className = 'result-url';
  urlLine.textContent = item && item.url ? '悬停查看该屏提示词' : '生成后在此预览图片';
  meta.appendChild(strong);
  meta.appendChild(urlLine);

  if (item && item.url) {
    var row = document.createElement('div');
    row.className = 'result-actions';
    var copyImg = document.createElement('button');
    copyImg.className = 'btn ghost';
    copyImg.type = 'button';
    copyImg.textContent = '复制图片';
    copyImg.addEventListener('click', function () { openImageActionModal(item); });
    var guideBtn = document.createElement('button');
    guideBtn.className = 'btn ghost';
    guideBtn.type = 'button';
    guideBtn.textContent = '引导重生';
    guideBtn.addEventListener('click', function () { openGuideRegenerateModal(item); });
    var dl = document.createElement('button');
    dl.className = 'btn ghost';
    dl.type = 'button';
    dl.textContent = '下载';
    dl.addEventListener('click', function () {
      send('DOWNLOAD_ALL', { items: buildDownloadItems([item], currentLabMode()) });
    });
    row.appendChild(copyImg);
    row.appendChild(guideBtn);
    row.appendChild(dl);
    meta.appendChild(row);
  }

  card.appendChild(preview);
  if (item && item.url) addDetailStitchSelectionControl(card, item);
  card.appendChild(meta);
  return card;
}

function padDownloadSeq(num) {
  num = Number(num) || 0;
  return (num < 10 ? '0' : '') + num;
}

function sanitizeDownloadNamePart(text) {
  return String(text || '')
    .replace(/[\\/:*?"<>|#\u0000-\u001f]/g, '')
    .replace(/\s+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 48) || '生成图';
}

function downloadBaseDir(mode) {
  if (mode === 'detail') return '少壮AI详情页';
  if (mode === 'sku') return '少壮AI批量SKU';
  return '少壮AI主图生成实验室';
}

function buildDownloadItems(items, mode) {
  var labMode = mode || currentLabMode();
  var prefix = labMode === 'detail' ? 'detail' : (labMode === 'sku' ? 'sku' : 'image');
  var dir = downloadBaseDir(labMode);
  var orderedItems = labMode === 'sku' ? orderedSkuResults(items || []) : orderedGenerationResults(items || []);
  return orderedItems.filter(function (item) {
    return item && item.url;
  }).map(function (item, idx) {
    var seq = item.detailScreenIndex || item.linkImageIndex;
    if (!seq && labMode === 'sku' && item.skuCode) {
      var skuSeq = String(item.skuCode).match(/(\d+)$/);
      if (skuSeq) seq = parseInt(skuSeq[1], 10);
    }
    if (!seq) seq = item.sourceIndex != null ? (Number(item.sourceIndex) + 1) : (idx + 1);
    var name = sanitizeDownloadNamePart(item.variantName || item.variant || '生成图');
    var linkPart = item.linkId ? (sanitizeDownloadNamePart(item.linkId) + '_') : '';
    return {
      url: item.url,
      filename: dir + '/' + prefix + '_' + linkPart + padDownloadSeq(seq) + '_' + name + '.png'
    };
  });
}

function orderedGenerationResults(items) {
  var groupOrder = {};
  var nextGroup = 0;
  return (items || []).map(function (item, index) {
    var groupKey = item && item.batchId ? ('batch:' + item.batchId) : ('single:' + index);
    if (groupOrder[groupKey] == null) groupOrder[groupKey] = nextGroup++;
    return { item: item, index: index, group: groupOrder[groupKey] };
  }).sort(function (a, b) {
    if (a.group !== b.group) return a.group - b.group;
    var ai = Number(a.item && a.item.linkBatchOrder);
    var bi = Number(b.item && b.item.linkBatchOrder);
    if (!isFinite(ai)) ai = Number(a.item && a.item.linkIndex) || 0;
    if (!isFinite(bi)) bi = Number(b.item && b.item.linkIndex) || 0;
    if (ai !== bi) return ai - bi;
    var aid = a.item && a.item.linkId || '';
    var bid = b.item && b.item.linkId || '';
    if (aid !== bid) return aid.localeCompare(bid);
    var ap = Number(a.item && (a.item.detailScreenIndex || a.item.linkImageIndex)) || 0;
    var bp = Number(b.item && (b.item.detailScreenIndex || b.item.linkImageIndex)) || 0;
    return ap - bp || a.index - b.index;
  }).map(function (entry) { return entry.item; });
}

function detailResultGroups(items) {
  var map = {};
  var groups = [];
  (items || []).forEach(function (item) {
    var key = item.linkId
      ? ('link:' + (item.batchId || item.promptId || 'single') + ':' + item.linkId)
      : ('reference:' + (item.batchId || item.promptId || 'single'));
    if (!map[key]) {
      map[key] = { key: key, linkId: item.linkId || '', batchId: item.batchId || '', items: [] };
      groups.push(map[key]);
    }
    map[key].items.push(item);
  });
  return groups;
}

function renderDetailLongPreview() {
  var wrap = $('detailLongPreviewWrap');
  var strip = $('detailLongPreview');
  if (!wrap || !strip) return;
  var available = detailPreviewResults();
  var items = detailStitchSelectedItems();
  var toggle = $('detailStitchToggle');
  var shouldStitch = !!(toggle && toggle.checked);
  wrap.hidden = currentLabMode() !== 'detail' || !items.length || !shouldStitch;
  strip.innerHTML = '';
  syncDetailStitchSelectionUi();
  if (!available.length) {
    setText('detailLongPreviewHint', '生成后可跨链接勾选最多 20 张，按勾选先后拼接');
    return;
  }
  if (!shouldStitch) {
    setText('detailLongPreviewHint', '已保留 ' + items.length + ' 张的勾选顺序；开启“拼接所选长图”后预览');
    return;
  }
  if (!items.length) {
    setText('detailLongPreviewHint', '请在每张详情图右上角按需勾选；可跨 L 编号，最多 20 张，顺序以勾选先后为准');
    return;
  }
  items.forEach(function (item, idx) {
    var img = document.createElement('img');
    img.src = item.url;
    img.alt = item.variantName || '详情页画面';
    makeGeneratedImagePreviewable(img, item, '长图第 ' + (idx + 1) + ' 张');
    strip.appendChild(img);
  });
  setText('detailLongPreviewHint', '已按勾选先后拼接 ' + items.length + ' / 20 张，可跨链接编号');
}

function stitchDetailLongImage() {
  if (currentLabMode() !== 'detail') return;
  if (!detailPreviewResults().length) {
    if ($('detailStitchToggle')) $('detailStitchToggle').checked = false;
    renderDetailLongPreview();
    setPill('generateState', '未找到拼接对象', 'warn');
    return;
  }
  if ($('detailStitchToggle')) $('detailStitchToggle').checked = true;
  renderDetailLongPreview();
  var selected = detailStitchSelectedItems();
  setPill('generateState', selected.length ? ('已按勾选顺序打开长图预览：' + selected.length + ' / 20') : '请先勾选要拼接的详情图（最多20张）', selected.length ? 'ok' : 'warn');
  var target = selected.length ? ($('detailLongPreviewWrap') || $('resultGrid')) : $('resultGrid');
  if (target && target.scrollIntoView) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function renderResults() {
  var grid = $('resultGrid');
  grid.innerHTML = '';
  var isDetail = currentLabMode() === 'detail';
  var items = isDetail ? detailPreviewResults() : orderedGenerationResults(state.results);
  if (isDetail) {
    var resultGroups = detailResultGroups(items);
    var needsGrouping = resultGroups.length > 1 || resultGroups.some(function (group) { return !!group.linkId; });
    if (needsGrouping) {
      var linkBatchCount = {};
      resultGroups.forEach(function (group) {
        if (group.linkId) linkBatchCount[group.linkId] = (linkBatchCount[group.linkId] || 0) + 1;
        var batchOrdinal = group.linkId ? linkBatchCount[group.linkId] : 0;
        var heading = document.createElement('div');
        heading.className = 'detail-link-result-heading';
        heading.textContent = group.linkId
          ? (group.linkId + (batchOrdinal > 1 ? (' · 批次 ' + batchOrdinal) : '') + ' · 独立详情图结果')
          : '参考图 / 单条详情结果';
        grid.appendChild(heading);
        var groupTotal = group.items.reduce(function (max, item) {
          return Math.max(max, Number(item.detailScreenTotal) || 0);
        }, 0) || detailScreenCountForGeneration();
        var groupByIndex = {};
        group.items.forEach(function (item, idx) { groupByIndex[item.detailScreenIndex || (idx + 1)] = item; });
        for (var screen = 1; screen <= groupTotal; screen++) {
          grid.appendChild(createDetailResultSlot(screen, groupTotal, groupByIndex[screen]));
        }
      });
      renderDetailLongPreview();
      return;
    }
    var total = detailScreenCountForGeneration();
    var byIndex = {};
    items.forEach(function (item, idx) {
      byIndex[item.detailScreenIndex || (idx + 1)] = item;
    });
    for (var i = 1; i <= total; i++) {
      grid.appendChild(createDetailResultSlot(i, total, byIndex[i]));
    }
    renderDetailLongPreview();
    return;
  }
  if (!items.length) {
    var empty = document.createElement('div');
    empty.className = 'empty-result';
    empty.textContent = '还没有生成结果';
    grid.appendChild(empty);
    renderDetailLongPreview();
    return;
  }
  items.forEach(function (item, idx) {
    var card = document.createElement('div');
    card.className = 'result-card';
    var img = document.createElement('img');
    img.src = item.url;
    img.alt = item.variant || 'generated image';
    makeGeneratedImagePreviewable(img, item, item.variantName || item.variant || ('生成图 ' + (idx + 1)));
    var meta = document.createElement('div');
    meta.className = 'result-meta';
    var strong = document.createElement('strong');
    strong.textContent = currentLabMode() === 'detail'
      ? (item.variantName || item.variant || '详情图')
      : ((idx + 1) + '. ' + (item.variantName || item.variant || '生成图'));
    var urlLine = document.createElement('div');
    urlLine.className = 'result-url';
    urlLine.title = item.url;
    urlLine.textContent = item.url ? '图片链接已生成' : '无图片链接';
    var row = document.createElement('div');
    row.className = 'result-actions';
    var copyImg = document.createElement('button');
    copyImg.className = 'btn ghost';
    copyImg.type = 'button';
    copyImg.textContent = '复制图片';
    copyImg.addEventListener('click', function () { openImageActionModal(item); });
    var guideBtn = document.createElement('button');
    guideBtn.className = 'btn ghost';
    guideBtn.type = 'button';
    guideBtn.textContent = '引导重生';
    guideBtn.addEventListener('click', function () { openGuideRegenerateModal(item); });
    var dl = document.createElement('button');
    dl.className = 'btn ghost';
    dl.type = 'button';
    dl.textContent = '下载';
    dl.addEventListener('click', function () {
      send('DOWNLOAD_ALL', { items: buildDownloadItems([item], currentLabMode()) });
    });
    row.appendChild(copyImg);
    row.appendChild(guideBtn);
    row.appendChild(dl);
    meta.appendChild(strong);
    meta.appendChild(urlLine);
    meta.appendChild(row);
    card.appendChild(img);
    card.appendChild(meta);
    grid.appendChild(card);
  });
  renderDetailLongPreview();
}

function resultGuidePrompt(item) {
  item = item || {};
  return [
    '【最高权重引导词，可编辑】',
    '这张结果图只作为视觉参考，不作为商品主体锁定。参考图：' + (item.url || ''),
    '优先保留：构图关系、镜头角度、光影方向、色彩氛围、背景层次、商业版式、产品摆位、画面质感。',
    '语义覆盖：如果原提示词、参考图或结果图里仍包含旧商品、旧包装、旧容器、旧配件、旧品牌、旧文案，以这里填写的引导为准，冲突内容自动降权。',
    '融合落地：把引导要求转化为自然画面调整，例如替换容器、改变陈列方式、弱化/移除冲突道具、调整遮挡关系、改变摆放空间、重排局部构图；不要把引导词当成画面文字。',
    '主体规则：最终商品主体以当前上传的产品主体图为准，结果图/参考图只能提供风格和版式。',
    item.variantName ? '结果方向：' + item.variantName : '',
    item.prompt ? '低权重历史提示词，仅作风格记忆，不得覆盖以上引导：\n' + item.prompt : ''
  ].filter(Boolean).join('\n\n');
}

function blobToPngBlob(blob) {
  if (blob && blob.type === 'image/png') return Promise.resolve(blob);
  if (!blob || !window.createImageBitmap) return Promise.reject(new Error('浏览器不支持图片转码'));
  return createImageBitmap(blob).then(function (bitmap) {
    var canvas = document.createElement('canvas');
    canvas.width = bitmap.width;
    canvas.height = bitmap.height;
    var ctx = canvas.getContext('2d');
    ctx.drawImage(bitmap, 0, 0);
    if (bitmap.close) bitmap.close();
    return new Promise(function (resolve, reject) {
      canvas.toBlob(function (pngBlob) {
        if (pngBlob) resolve(pngBlob);
        else reject(new Error('图片转码失败'));
      }, 'image/png');
    });
  });
}

function openImageActionModal(item) {
  state.actionItem = item || null;
  var modal = $('imageActionModal');
  if (!modal) {
    copyImageToClipboard(item && item.url);
    return;
  }
  modal.hidden = false;
  var first = $('copyOriginalImageBtn');
  if (first) first.focus();
}

function closeImageActionModal() {
  state.actionItem = null;
  var modal = $('imageActionModal');
  if (modal) modal.hidden = true;
}

function applyContextImage(ctx, autoAnalyze) {
  ctx = ctx || {};
  if (!ctx.imageUrl) return Promise.resolve({ ok: false, error: '缺少右键图片' });
  setPill('contextState', '右键图片导入中...', '');
  $('refUrl').value = ctx.imageUrl;
  setRefImage(ctx.imageUrl, ctx.imageUrl);
  if (autoAnalyze && ($('apiKey') && $('apiKey').value.trim())) return analyzeCurrentImage();
  return Promise.resolve({ ok: true });
}

function applyAndConsumeContextImage(ctx, autoAnalyze) {
  return applyContextImage(ctx, autoAnalyze).then(function (resp) {
    state.contextItem = null;
    return send('CONSUME_CONTEXT').then(function () { return resp; });
  });
}

function openContextActionModal(ctx, autoAnalyze) {
  state.contextItem = ctx || null;
  state.contextAuto = !!autoAnalyze;
  var modal = $('contextActionModal');
  if (!modal) {
    applyContextImage(ctx, autoAnalyze);
    return;
  }
  modal.hidden = false;
  var first = $('contextImportBtn');
  if (first) first.focus();
}

function closeContextActionModal() {
  state.contextItem = null;
  var modal = $('contextActionModal');
  if (modal) modal.hidden = true;
}

function syncShareCardControls(source) {
  source = source || {};
  var values = {
    position: source.position,
    border: source.border,
    ratio: source.ratio
  };
  if (source.target && source.target.getAttribute) {
    values[source.target.getAttribute('data-share-card')] = source.target.value;
  }
  ['position', 'border', 'ratio'].forEach(function (key) {
    var controls = document.querySelectorAll('[data-share-card="' + key + '"]');
    var val = values[key];
    if (val == null && controls[0]) val = controls[0].value;
    controls.forEach(function (ctrl) {
      if (val != null) ctrl.value = val;
    });
  });
}

function shareCardValue(key, fallback) {
  var el = document.querySelector('[data-share-card="' + key + '"]');
  return (el && el.value) || fallback;
}

function shareCardConfig() {
  return {
    position: shareCardValue('position', 'top'),
    border: Math.max(0, Math.min(80, parseInt(shareCardValue('border', '36'), 10) || 36)),
    ratio: shareCardValue('ratio', '4:5')
  };
}

function shareCardSize(ratio) {
  if (ratio === '1:1') return { w: 1080, h: 1080 };
  if (ratio === '3:4') return { w: 1080, h: 1440 };
  return { w: 1080, h: 1350 };
}

function loadCanvasImage(url) {
  return fetch(url).then(function (r) {
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.blob();
  }).then(function (blob) {
    return new Promise(function (resolve, reject) {
      var objectUrl = URL.createObjectURL(blob);
      var img = new Image();
      img.onload = function () {
        URL.revokeObjectURL(objectUrl);
        resolve(img);
      };
      img.onerror = function () {
        URL.revokeObjectURL(objectUrl);
        reject(new Error('图片载入失败'));
      };
      img.src = objectUrl;
    });
  });
}

function roundRect(ctx, x, y, w, h, r) {
  r = Math.min(r || 0, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function drawImageFit(ctx, img, rect, mode) {
  var iw = img.naturalWidth || img.width;
  var ih = img.naturalHeight || img.height;
  var scale = mode === 'cover' ? Math.max(rect.w / iw, rect.h / ih) : Math.min(rect.w / iw, rect.h / ih);
  var sw = rect.w / scale;
  var sh = rect.h / scale;
  var sx = (iw - sw) / 2;
  var sy = (ih - sh) / 2;
  ctx.drawImage(img, sx, sy, sw, sh, rect.x, rect.y, rect.w, rect.h);
}

function wrapText(ctx, text, x, y, maxWidth, lineHeight, maxLines) {
  text = (text || '').replace(/\s+/g, ' ').trim();
  var line = '';
  var lines = 0;
  for (var i = 0; i < text.length; i++) {
    var test = line + text[i];
    if (ctx.measureText(test).width > maxWidth && line) {
      ctx.fillText(line, x, y);
      y += lineHeight;
      lines++;
      line = text[i];
      if (maxLines && lines >= maxLines - 1) break;
    } else {
      line = test;
    }
  }
  if (line && (!maxLines || lines < maxLines)) ctx.fillText(line, x, y);
}

function shareCardText(item) {
  var cn = ($('cnPrompt') && $('cnPrompt').value.trim()) || '';
  var prompt = cn || item.prompt || '高质感电商主图，主体清晰，背景克制，细节丰富。';
  return {
    title: item.variantName || item.variant || '提示词',
    prompt: prompt,
    negative: ($('negativePrompt') && $('negativePrompt').value.trim()) || ''
  };
}

function drawShareCopy(ctx, box, text, compact) {
  roundRect(ctx, box.x, box.y, box.w, box.h, 24);
  ctx.fillStyle = 'rgba(8, 15, 4, .92)';
  ctx.fill();
  ctx.fillStyle = '#f6c65f';
  ctx.font = compact ? '700 34px "PingFang SC", sans-serif' : '700 44px "PingFang SC", sans-serif';
  ctx.fillText(text.title || '提示词', box.x + 34, box.y + 52);
  ctx.fillStyle = '#f3edd7';
  ctx.font = compact ? '28px "PingFang SC", sans-serif' : '32px "PingFang SC", sans-serif';
  wrapText(ctx, text.prompt, box.x + 34, box.y + (compact ? 96 : 112), box.w - 68, compact ? 42 : 48, compact ? 7 : 9);
}

function buildShareCardBlob(item) {
  item = item || {};
  if (!item.url) return Promise.reject(new Error('没有图片可生成卡片'));
  var cfg = shareCardConfig();
  var size = shareCardSize(cfg.ratio);
  return loadCanvasImage(item.url).then(function (img) {
    var canvas = document.createElement('canvas');
    canvas.width = size.w;
    canvas.height = size.h;
    var ctx = canvas.getContext('2d');
    ctx.fillStyle = '#f5f1e7';
    ctx.fillRect(0, 0, size.w, size.h);
    var b = cfg.border;
    var inner = { x: b, y: b, w: size.w - b * 2, h: size.h - b * 2 };
    var text = shareCardText(item);
    if (cfg.position === 'left') {
      var mediaW = Math.round(inner.w * .56);
      roundRect(ctx, inner.x, inner.y, mediaW, inner.h, 28);
      ctx.save();
      ctx.clip();
      drawImageFit(ctx, img, { x: inner.x, y: inner.y, w: mediaW, h: inner.h }, 'cover');
      ctx.restore();
      drawShareCopy(ctx, { x: inner.x + mediaW + 20, y: inner.y, w: inner.w - mediaW - 20, h: inner.h }, text, true);
    } else if (cfg.position === 'full') {
      drawImageFit(ctx, img, { x: 0, y: 0, w: size.w, h: size.h }, 'cover');
      drawShareCopy(ctx, { x: b, y: size.h - Math.max(360, size.h * .32) - b, w: size.w - b * 2, h: Math.max(360, size.h * .32) }, text, true);
    } else {
      var mediaH = cfg.position === 'center' ? Math.round(inner.h * .68) : Math.round(inner.h * .58);
      roundRect(ctx, inner.x, inner.y, inner.w, mediaH, 28);
      ctx.save();
      ctx.clip();
      drawImageFit(ctx, img, { x: inner.x, y: inner.y, w: inner.w, h: mediaH }, cfg.position === 'center' ? 'contain' : 'cover');
      ctx.restore();
      var copyY = inner.y + mediaH + 20;
      drawShareCopy(ctx, { x: inner.x, y: copyY, w: inner.w, h: inner.y + inner.h - copyY }, text, false);
    }
    return new Promise(function (resolve, reject) {
      canvas.toBlob(function (blob) {
        if (blob) resolve(blob);
        else reject(new Error('卡片导出失败'));
      }, 'image/png');
    });
  });
}

function copyShareCardToClipboard(item) {
  if (!navigator.clipboard || !window.ClipboardItem) {
    setPill('generateState', '当前浏览器不支持复制卡片', 'warn');
    return;
  }
  setPill('generateState', '生成分享卡中...', '');
  buildShareCardBlob(item).then(function (blob) {
    return navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
  }).then(function () {
    setPill('generateState', '分享卡已复制', 'ok');
  }).catch(function (e) {
    setPill('generateState', '分享卡失败：' + ((e && e.message) || e), 'warn');
  });
}

function copyImageToClipboard(url) {
  if (!url) { setPill('generateState', '没有图片可复制', 'warn'); return; }
  if (!navigator.clipboard || !window.ClipboardItem) {
    setPill('generateState', '当前浏览器不支持复制图片', 'warn');
    return;
  }
  setPill('generateState', '复制图片中...', '');
  fetch(url).then(function (r) {
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.blob();
  }).then(blobToPngBlob).then(function (blob) {
    return navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
  }).then(function () {
    setPill('generateState', '图片已复制', 'ok');
  }).catch(function () {
    setPill('generateState', '复制图片失败', 'warn');
  });
}

function openGuideRegenerateModal(item) {
  item = item || {};
  if (!item.url) { setPill('generateState', '缺少引导图片', 'warn'); return; }
  state.guideItem = item;
  if ($('guidePrompt')) $('guidePrompt').value = resultGuidePrompt(item);
  if (item.negativePrompt) $('negativePrompt').value = item.negativePrompt;
  var modal = $('guideActionModal');
  if (modal) modal.hidden = false;
  if ($('guidePrompt')) $('guidePrompt').focus();
}

function closeGuideRegenerateModal() {
  state.guideItem = null;
  var modal = $('guideActionModal');
  if (modal) modal.hidden = true;
}

function runSkuGuideRegenerate(item) {
  var guide = ($('guidePrompt') && $('guidePrompt').value.trim()) || '';
  var boundProduct = item.skuId && state.skuProducts.find(function (productItem) { return productItem.skuId === item.skuId; });
  var product = item.skuProductImage || (boundProduct && boundProduct.url) || (state.skuProducts[item.sourceIndex] && state.skuProducts[item.sourceIndex].url) || '';
  if (!product) {
    showProductSubjectRequired('sku', '缺少 SKU 产品图，不能引导重生。请先上传当前 SKU 产品图。');
    return;
  }
  closeGuideRegenerateModal();
  state.stopRequested = false;
  setSkuBusy(true);
  setPill('skuState', 'SKU 引导重生中...', '');

  var jobId = newJobId();
  state.activeJobId = jobId;
  state.skuActiveJobIds[jobId] = item.skuId || 'guide';
  var negative = item.negativePrompt || replacementNegativePrompt();
  var prompt = [
    'SKU 引导重生任务。',
    guide ? '最高权重引导词：' + guide : '',
    '当前结果图只作为构图、光影、背景和版式参考，不能锁定旧商品。',
    '必须以当前 SKU 产品图为唯一商品主体，保持产品结构、颜色、包装比例和关键细节。',
    item.prompt ? '低权重历史提示词，仅保留不冲突的风格信息：\n' + item.prompt : ''
  ].filter(Boolean).join('\n');

  return send('GENERATE_IMAGE', {
    jobId: jobId,
    config: skuConfigForGeneration(),
    payload: {
      prompt: prompt,
      negativePrompt: negative,
      referenceImage: item.url,
      productImage: product,
      productImages: [product],
      modelImages: [],
      labMode: 'sku',
      detailMode: 'sku-guide',
      size: skuSizeFromSettings(),
      clarity: 'commercial',
      count: 1,
      watermark: 'false',
      _jobId: jobId
    }
  }).then(function (resp) {
    if (state.activeJobId === jobId) state.activeJobId = '';
    delete state.skuActiveJobIds[jobId];
    if (state.stopRequested || state.cancelledJobs[jobId]) {
      delete state.cancelledJobs[jobId];
      setSkuBusy(false);
      setPill('skuState', 'SKU 引导重生已终止', 'warn');
      return { ok: false, error: '已终止' };
    }
    if (resp && resp.ok && resp.images && resp.images.length) {
      resp.images.forEach(function (url) {
        state.skuResults.push({
          url: url,
          variant: 'sku',
          variantName: (item.variantName || 'SKU') + ' 引导重生',
          skuId: item.skuId || '',
          skuCode: item.skuCode || '',
          skuAttribute: item.skuAttribute || '',
          sourceIndex: item.sourceIndex,
          taskId: resp.taskId || '',
          prompt: prompt,
          negativePrompt: negative,
          skuProductImage: product
        });
      });
      renderSkuWorkspace();
    }
    setSkuBusy(false);
    setPill('skuState', resp && resp.ok ? 'SKU 引导重生完成' : ((resp && resp.error) || 'SKU 引导重生失败'), resp && resp.ok ? 'ok' : 'warn');
    return resp;
  }).catch(function (err) {
    if (state.activeJobId === jobId) state.activeJobId = '';
    delete state.skuActiveJobIds[jobId];
    setSkuBusy(false);
    setPill('skuState', (err && err.message) || 'SKU 引导重生失败', 'warn');
    return { ok: false, error: err && err.message };
  });
}

function runGuideRegenerate() {
  var item = state.guideItem || {};
  if (!item.url) { setPill('generateState', '缺少引导图片', 'warn'); return; }
  if (item.variant === 'sku') {
    runSkuGuideRegenerate(item);
    return;
  }
  if (!validateGenerationReady()) return;
  setRefImage(item.url, item.url);
  if (item.negativePrompt) $('negativePrompt').value = item.negativePrompt;
  closeGuideRegenerateModal();
  state.stopRequested = false;
  setStopAvailable(true);
  setPill('generateState', '引导重生中...', '');
  generateOne('guide', '引导重生', 1, { batchId: 'guide_' + Date.now() + '_' + Math.random().toString(16).slice(2) }).then(function (resp) {
    setStopAvailable(false);
    setPill('generateState', resp && resp.ok ? '引导重生完成' : ((resp && resp.error) || '引导重生失败'), resp && resp.ok ? 'ok' : 'warn');
  });
}

function setStopAvailable(on) {
  var btn = $('stopGenerateBtn');
  if (!btn) return;
  btn.hidden = !on;
  btn.disabled = !on;
}

function newJobId() {
  return 'job_' + Date.now() + '_' + Math.random().toString(16).slice(2);
}

function registerGenerationJob(jobId) {
  if (!jobId) return;
  state.activeJobIds[jobId] = true;
  state.activeJobId = jobId;
}

function unregisterGenerationJob(jobId) {
  if (!jobId) return;
  delete state.activeJobIds[jobId];
  if (state.activeJobId === jobId) {
    var remaining = Object.keys(state.activeJobIds);
    state.activeJobId = remaining.length ? remaining[remaining.length - 1] : '';
  }
}

function stopGeneration() {
  state.stopRequested = true;
  state.batchPromptToken++;
  state.batchGenerationToken++;
  var ids = Object.keys(state.activeJobIds);
  if (state.activeJobId && ids.indexOf(state.activeJobId) < 0) ids.push(state.activeJobId);
  ids.forEach(function (jobId) {
    state.cancelledJobs[jobId] = true;
    send('CANCEL_GENERATION', { jobId: jobId });
  });
  state.activeJobIds = {};
  state.activeJobId = '';
  setStopAvailable(false);
  setPill('generateState', '已终止', 'warn');
}

function detailPlanUsesModel(plan) {
  var instruction = firstValue(plan || {}, ['模特使用', '人物使用', '模特', '人物']) || '';
  if (!instruction || /不使用|无需|不需|禁止|无模特|纯商品/.test(instruction)) return false;
  return /使用|需要|模特|人物|人像|手持|穿戴|演示/.test(instruction);
}

function generateOne(variant, variantName, countOverride, options) {
  options = options || {};
  if (state.stopRequested) return Promise.resolve({ ok: false, error: '已终止' });
  var labMode = options.labMode || currentLabMode();
  var isLinkDetail = labMode === 'detail' && options.promptRecord && options.promptRecord.source === 'link';
  var detailMode = options.detailMode || (isLinkDetail ? 'link' : (state.detailMode || 'reference'));
  var settings = options.generationSettings || captureGenerationSettings(labMode, detailMode, countOverride);
  var requestedCount = settings.count;
  var productImages = (options.productImages || productImageList()).slice();
  if (!productImages.length) {
    showProductSubjectRequired(labMode);
    return Promise.resolve({ ok: false, error: productSubjectRequiredMessage(labMode) });
  }
  var allModelImages = (options.modelImages || (labMode === 'detail' ? modelImageList() : [])).slice();
  var promptOptions = Object.assign({}, options, {
    labMode: labMode,
    productImages: productImages,
    productImageEvidence: options.productImageEvidence || productImageEvidence(),
    modelImages: allModelImages
  });
  var basePrompt = generationPrompt(variant, options.promptRecord, promptOptions);
  if (!basePrompt.trim()) return Promise.resolve({ ok: false, error: '缺少提示词' });
  var prompt = [generationParamPromptLayer(requestedCount, settings), basePrompt].filter(Boolean).join('\n\n');
  var jobId = newJobId();
  registerGenerationJob(jobId);
  var productImage = productImages[0] || '';
  var negative = options.negativePrompt != null ? options.negativePrompt : (($('negativePrompt') && $('negativePrompt').value.trim()) || '');
  if (productImage) negative = [negative, replacementNegativePrompt()].filter(Boolean).join(', ');
  var record = options.promptRecord || null;
  var payloadBase = {
    prompt: prompt,
    negativePrompt: negative,
    referenceImages: isLinkDetail ? [] : (options.referenceImages != null ? options.referenceImages.slice(0, 6) : (options.referenceImage != null ? [options.referenceImage] : referenceImageList())),
    referenceImage: '',
    productImage: productImage,
    productImages: productImages,
    modelImages: labMode === 'detail' ? allModelImages : [],
    labMode: labMode,
    detailMode: detailMode,
    size: settings.size,
    ratio: settings.ratio,
    resolution: settings.resolution,
    clarity: settings.resolution,
    count: 1,
    watermark: 'false',
    linkId: record && record.linkId || '',
    linkIndex: record && record.linkIndex,
    promptId: record && record.id || '',
    promptSource: record && record.source || '',
    promptBatchId: record && record.promptBatchId || '',
    promptRequestId: record && record.requestId || '',
    batchId: options.batchId || '',
    linkBatchOrder: Number(options.linkBatchOrder) || 0,
    _jobId: jobId
  };
  payloadBase.referenceImage = payloadBase.referenceImages[0] || '';
  var chunks = labMode === 'detail'
    ? Array.apply(null, Array(requestedCount)).map(function () { return 1; })
    : requestCountChunks(requestedCount);
  var detailNames = labMode === 'detail' ? detailSectionNames(requestedCount) : [];
  var chunkIndex = 0;
  var collected = [];
  function appendImages(resp, effectivePrompt, screenIndex, promptPlan, expectedCount) {
    if (options.generationToken != null && options.generationToken !== state.batchGenerationToken) return 0;
    var images = resp && resp.ok && Array.isArray(resp.images) ? resp.images.filter(Boolean) : [];
    images.slice(0, expectedCount).forEach(function (url, localIndex) {
      var seq = labMode === 'detail' ? screenIndex : (collected.length + 1);
      collected.push(url);
      state.results.push({
        url: url,
        variant: variant,
        variantName: labMode === 'detail'
          ? (firstValue(promptPlan || {}, ['名称', '标题', '屏幕名称']) || detailNames[seq - 1] || '详情图画面')
          : (requestedCount > 1 ? (variantName + ' ' + seq + '/' + requestedCount) : variantName),
        taskId: resp.taskId || '',
        labMode: labMode,
        detailMode: detailMode,
        detailScreenIndex: labMode === 'detail' ? screenIndex : undefined,
        detailScreenTotal: labMode === 'detail' ? requestedCount : undefined,
        detailScreenPlan: labMode === 'detail' ? promptPlan : undefined,
        linkImageIndex: labMode === 'detail' ? screenIndex : seq,
        linkBatchOrder: Number(options.linkBatchOrder) || 0,
        ratio: settings.ratio,
        resolution: settings.resolution,
        prompt: effectivePrompt || prompt,
        negativePrompt: negative,
        batchId: options.batchId || '',
        linkId: record && record.linkId || '',
        linkIndex: record && record.linkIndex,
        promptId: record && record.id || '',
        promptSource: record && record.source || '',
        promptBatchId: record && record.promptBatchId || '',
        jobId: jobId,
        promptRecord: record || undefined
      });
    });
    if (images.length) renderResults();
    return images.length;
  }
  function finish(resp) {
    unregisterGenerationJob(jobId);
    return resp;
  }
  function partialFailure(error, screenIndex) {
    return finish({ ok: false, partial: collected.length > 0, failedScreen: screenIndex || undefined, error: error || '生图失败', images: collected.slice() });
  }
  function nextChunk() {
    if (state.stopRequested || state.cancelledJobs[jobId] || (options.generationToken != null && options.generationToken !== state.batchGenerationToken)) {
      delete state.cancelledJobs[jobId];
      return finish({ ok: false, error: '已终止', images: collected.slice() });
    }
    if (chunkIndex >= chunks.length) {
      return finish({ ok: collected.length === requestedCount, images: collected.slice(), error: collected.length === requestedCount ? '' : ('图片数量不完整：期望 ' + requestedCount + '，实际 ' + collected.length) });
    }
    var requestIndex = chunkIndex++;
    var chunkCount = chunks[requestIndex];
    var screenIndex = labMode === 'detail' ? (requestIndex + 1) : 0;
    var promptPlan = labMode === 'detail' && record && record.data && Array.isArray(record.data['屏幕规划'])
      ? record.data['屏幕规划'][screenIndex - 1]
      : null;
    var requestPrompt = [prompt, detailScreenSequenceLayer(screenIndex, requestedCount, record)].filter(Boolean).join('\n\n');
    var payload = Object.assign({}, payloadBase, {
      count: chunkCount,
      prompt: requestPrompt,
      modelImages: labMode === 'detail' && detailPlanUsesModel(promptPlan) ? allModelImages : [],
      detailScreenIndex: screenIndex || undefined,
      detailScreenTotal: labMode === 'detail' ? requestedCount : undefined,
      detailScreenPlan: labMode === 'detail' ? promptPlan : undefined
    });
    return send('GENERATE_IMAGE', { jobId: jobId, config: cfgFromForm(), payload: payload }).then(function (resp) {
      if (state.stopRequested || state.cancelledJobs[jobId] || (options.generationToken != null && options.generationToken !== state.batchGenerationToken)) {
        delete state.cancelledJobs[jobId];
        return finish({ ok: false, error: '已终止', images: collected.slice() });
      }
      if (!resp || !resp.ok) return partialFailure((resp && resp.error) || '生图失败', screenIndex);
      var actualCount = Array.isArray(resp.images) ? resp.images.filter(Boolean).length : 0;
      appendImages(resp, requestPrompt, screenIndex, promptPlan, chunkCount);
      if (actualCount !== chunkCount) {
        return partialFailure('图片数量异常：本次期望 ' + chunkCount + '，实际 ' + actualCount, screenIndex);
      }
      return nextChunk();
    }).catch(function (err) {
      return partialFailure((err && err.message) || '生图失败', screenIndex);
    });
  }
  return nextChunk();
}

function ensureReferencePromptForGeneration() {
  var mode = currentLabMode() === 'detail' ? 'detail' : 'main';
  if (!productImageList().length) {
    showProductSubjectRequired(mode);
    return Promise.resolve({ ok: false, error: productSubjectRequiredMessage(mode) });
  }
  var images = referenceImageList();
  if (!images.length) {
    var missingMessage = '请先上传参考图/竞品页（1-6张），然后生成参考页提示词；结果会覆盖当前提示词，再结合商品主体图生图。';
    setPill('generateState', '请先上传并反推参考图', 'warn');
    if (window.alert) window.alert(missingMessage);
    scrollToPanel('contextPanel');
    return Promise.resolve({ ok: false, error: missingMessage });
  }
  var record = state.referencePrompts[mode];
  if (promptRecordIsCurrent(record, mode)) {
    displayPromptRecord(record);
    return Promise.resolve({ ok: true, promptRecord: record });
  }
  var notice = '当前参考图还没有与这组商品主体图对应的提示词，将先反推参考图并覆盖当前提示词。';
  if (window.alert) window.alert(notice);
  setPill('generateState', '先反推参考图并覆盖提示词...', '');
  if (mode === 'detail') {
    return generateDetailPrompt('reference', null, { silent: true }).then(function (resp) {
      return resp && resp.ok ? { ok: true, promptRecord: resp.promptRecord } : resp;
    });
  }
  return analyzeCurrentImage().then(function (resp) {
    return resp && resp.ok ? { ok: true, promptRecord: resp.promptRecord } : resp;
  });
}

function generateCurrent() {
  $('generateBtn').disabled = true;
  return ensureReferencePromptForGeneration().then(function (ready) {
    if (!ready || !ready.ok || !ready.promptRecord) return ready || { ok: false, error: '参考图提示词未就绪' };
    var record = ready.promptRecord;
    displayPromptRecord(record);
    state.stopRequested = false;
    setStopAvailable(true);
    setPill('generateState', '参考图提示词已覆盖，正在生图...', '');
    return generateOne('single', currentLabMode() === 'detail' ? '参考图详情' : '参考图生图', generationImageCount(), {
      promptRecord: record,
      referenceImages: referenceImageList(),
      negativePrompt: record.negativePrompt,
      batchId: 'reference_' + Date.now() + '_' + Math.random().toString(16).slice(2)
    });
  }).then(function (resp) {
    $('generateBtn').disabled = false;
    setStopAvailable(false);
    setPill('generateState', resp && resp.ok ? '参考图生成完成' : ((resp && resp.error) || '参考图生成失败'), resp && resp.ok ? 'ok' : 'warn');
    return resp;
  }).catch(function (err) {
    $('generateBtn').disabled = false;
    setStopAvailable(false);
    setPill('generateState', (err && err.message) || '参考图生成失败', 'warn');
    return { ok: false, error: (err && err.message) || '参考图生成失败' };
  });
}

function batchGenerate() {
  if (!validateGenerationReady()) return;
  var variants = [
    ['main', '主图转化版'],
    ['scene', '场景种草版'],
    ['hook', '视觉锤版'],
    ['diff', '竞品差异化版']
  ];
  if (currentLabMode() === 'detail') {
    variants = [
      ['main', '详情首屏'],
      ['scene', '场景说明屏'],
      ['hook', '卖点证明屏'],
      ['diff', '差异信任屏']
    ];
  }
  if ($('batchMode') && $('batchMode').value === 'single') variants = [['single', '当前提示词']];
  state.stopRequested = false;
  setStopAvailable(true);
  setPill('generateState', '批量生成中 0/' + variants.length, '');
  if ($('batchBtn')) $('batchBtn').disabled = true;
  var i = 0;
  function next() {
    if (state.stopRequested) {
      if ($('batchBtn')) $('batchBtn').disabled = false;
      setStopAvailable(false);
      setPill('generateState', '已终止', 'warn');
      return;
    }
    if (i >= variants.length) {
      if ($('batchBtn')) $('batchBtn').disabled = false;
      setStopAvailable(false);
      setPill('generateState', '批量完成，共 ' + state.results.length + ' 张', 'ok');
      return;
    }
    var v = variants[i++];
    setPill('generateState', '批量生成中 ' + (i - 1) + '/' + variants.length + '：' + v[1], '');
    generateOne(v[0], v[1], 1).then(function (resp) {
      if (!resp || !resp.ok) setPill('generateState', '部分失败：' + ((resp && resp.error) || '未知错误'), 'warn');
      next();
    });
  }
  next();
}

function clampInt(value, min, max, fallback) {
  var n = parseInt(value, 10);
  if (!isFinite(n)) n = fallback;
  return Math.max(min, Math.min(max, n));
}

function setBatchLinksBusy(on) {
  [
    'batchLinksBtn', 'linkNumberGenerateBtn', 'buildPromptBtn', 'generateBtn', 'batchBtn',
    'analyzeBtn',
    'linkJson', 'batchLinkStart', 'batchLinkEnd', 'positioning', 'imageCopy',
    'imageRatio', 'imageResolution', 'imageCount',
    'productFrontFile', 'productFrontUrl', 'clearProductFrontBtn',
    'productSideFile', 'productSideUrl', 'clearProductSideBtn',
    'productBackFile', 'productBackUrl', 'clearProductBackBtn',
    'modelFrontFile', 'modelFrontUrl', 'clearModelFrontBtn',
    'modelSideFile', 'modelSideUrl', 'clearModelSideBtn',
    'modelBackFile', 'modelBackUrl', 'clearModelBackBtn',
    'detailRefGenerateBtn', 'detailLinkGenerateBtn', 'detailSmartFillBtn', 'detailModelGenerateBtn',
    'detailRefModeBtn', 'detailLinkModeBtn', 'detailProductName', 'detailProductFeatures',
    'detailSellingPoints', 'detailPlatform', 'detailPageType', 'detailLanguage',
    'detailScreenCount', 'detailRatio', 'detailResolution', 'detailGenerateStyle', 'detailModelPrompt'
  ].forEach(function (id) {
    var el = $(id);
    if (!el) return;
    if (on) {
      if (el.__szBatchPrevDisabled == null) el.__szBatchPrevDisabled = !!el.disabled;
      el.disabled = true;
    } else {
      el.disabled = !!el.__szBatchPrevDisabled;
      delete el.__szBatchPrevDisabled;
    }
  });
}

function clearSelectedPromptRecords(mode, rows) {
  var selectedIds = {};
  (rows || []).forEach(function (row, idx) {
    var id = canonicalLinkId(row && (row['链接编号'] || row.linkId || row.link_id), idx);
    selectedIds[id] = true;
    delete state.linkPrompts[mode][id];
  });
  state.linkPromptOrder[mode] = state.linkPromptOrder[mode].filter(function (id) { return !selectedIds[id]; });
  if (state.activePromptRecord && (state.activePromptRecord.mode === mode || state.activePromptRecord.source === 'link-batch')) state.activePromptRecord = null;
}

function selectedLinkRuleError(rows, mode) {
  var requirements = mode === 'detail'
    ? [
      { label: '详情页定位/链接定位', keys: ['详情页定位', '链接定位'] },
      { label: '详情页文案/主图核心文案', keys: ['详情页文案', '主图核心文案'] },
      { label: '详情文案逻辑', keys: ['详情文案逻辑', '详情页逻辑', '详情逻辑'] }
    ]
    : [
      { label: '链接定位', keys: ['链接定位'] },
      { label: '主推关键词', keys: ['主推关键词'] },
      { label: '用户场景需求', keys: ['用户场景需求'] },
      { label: '差异化定位逻辑', keys: ['差异化定位逻辑'] },
      { label: '主图核心文案', keys: ['主图核心文案'] }
    ];
  var problems = [];
  (rows || []).forEach(function (row, idx) {
    var missing = requirements.filter(function (field) { return !firstValue(row || {}, field.keys); }).map(function (field) { return field.label; });
    if (missing.length) problems.push(canonicalLinkId(row && (row['链接编号'] || row.linkId || row.link_id), idx) + ' 缺少' + missing.join('、'));
  });
  return problems.length ? ('所选链接的' + (mode === 'detail' ? '详情规则' : '主图规划') + '不完整：' + problems.join('；') + '。') : '';
}

function parseBatchPromptSections(text) {
  text = String(text || '');
  var marker = /【\s*([Ll]\s*0*\d+)\s*】/g;
  var matches = [];
  var match;
  while ((match = marker.exec(text))) matches.push({ id: canonicalLinkId(match[1], 0), start: marker.lastIndex, markerStart: match.index });
  var sections = {};
  matches.forEach(function (entry, idx) {
    if (sections[entry.id] != null) throw new Error('批量提示词中编号重复：' + entry.id);
    sections[entry.id] = text.slice(entry.start, idx + 1 < matches.length ? matches[idx + 1].markerStart : text.length).trim();
  });
  return sections;
}

function applyBatchPromptEdits(records, mode) {
  records = (records || []).slice();
  var active = state.activePromptRecord;
  if (!active || active.source !== 'link-batch' || active.mode !== mode || !active.records) return records;
  var ids = records.map(function (record) { return record.linkId; });
  if (active.promptBatchId && records.some(function (record) { return record.promptBatchId !== active.promptBatchId; })) return records;
  var activeIds = (active.linkIds || []).slice();
  if (ids.join('|') !== activeIds.join('|')) return records;
  var editor = mode === 'detail' ? $('detailPrompt') : $('cnPrompt');
  var sections = parseBatchPromptSections(editor ? editor.value : active.displayedPrompt);
  var sectionIds = Object.keys(sections).sort();
  var expectedIds = ids.slice().sort();
  if (sectionIds.join('|') !== expectedIds.join('|')) {
    throw new Error('批量提示词编号必须与当前选择完全一致：' + ids.join('、'));
  }
  var sharedNegative = ($('negativePrompt') && $('negativePrompt').value.trim()) || '';
  return records.map(function (record) {
    var editedPrompt = sections[record.linkId];
    if (!editedPrompt) throw new Error(record.linkId + ' 的提示词为空');
    return Object.freeze(Object.assign({}, record, {
      id: record.id + '_edited_' + sourceFingerprint(editedPrompt + '\n' + sharedNegative),
      prompt: editedPrompt,
      negativePrompt: mergeNegativePrompts(sharedNegative, replacementNegativePrompt()),
      editedFromPromptId: record.id
    }));
  });
}

function readBatchLinkRows() {
  var rows = [];
  try { rows = parseLinkListInput(); } catch (e) { throw e; }
  if (!rows.length) {
    var single = parseLinkJson();
    rows = [single];
  }
  rows = normalizeLinkRowsForBatch(rows, true);
  state.linkList = rows;
  return rows;
}

function runSequential(items, worker, onProgress) {
  var results = [];
  var failed = false;
  return (items || []).reduce(function (chain, item, idx) {
    return chain.then(function () {
      if (failed) return;
      if (onProgress) onProgress(idx, item);
      return Promise.resolve(worker(item, idx)).then(function (value) {
        results.push({ status: 'fulfilled', value: value });
      }, function (error) {
        results.push({ status: 'rejected', reason: error });
        failed = true;
      });
    });
  }, Promise.resolve()).then(function () { return results; });
}

function runConcurrent(items, limit, worker) {
  items = items || [];
  limit = Math.max(1, Math.min(items.length || 1, parseInt(limit, 10) || 1));
  var next = 0;
  var results = new Array(items.length);
  function runner() {
    function step() {
      var idx = next++;
      if (idx >= items.length) return Promise.resolve();
      return Promise.resolve().then(function () { return worker(items[idx], idx); }).then(function (value) {
        results[idx] = { status: 'fulfilled', value: value };
      }, function (error) {
        results[idx] = { status: 'rejected', reason: error };
      }).then(step);
    }
    return step();
  }
  return Promise.all(Array.apply(null, Array(limit)).map(runner)).then(function () { return results; });
}

function buildPromptRecordForSelectedLink(row, idx, mode, batchContext) {
  batchContext = batchContext || {};
  var label = linkRowLabel(row, idx);
  if (mode === 'detail') {
    return generateDetailPrompt('link', row, {
      silent: true,
      deferDisplay: true,
      strictAi: true,
      linkIndex: idx,
      batchToken: batchContext.token,
      promptBatchId: batchContext.promptBatchId
    }).then(function (resp) {
      if (!resp || !resp.ok) throw new Error((resp && resp.error) || ('详情提词失败：' + label));
      return resp.promptRecord;
    });
  }
  return buildPromptForLink(row, label, {
    silent: true,
    deferDisplay: true,
    linkIndex: idx,
    batchToken: batchContext.token,
    promptBatchId: batchContext.promptBatchId
  }).then(function (resp) {
    if (!resp || !resp.ok) throw new Error((resp && resp.error) || ('主图提词失败：' + label));
    return resp.promptRecord;
  });
}

function generateSelectedLinkPrompts() {
  var rows;
  try { rows = readBatchLinkRows(); } catch (e) { setPill('runState', e.message, 'warn'); return Promise.resolve({ ok: false, error: e.message }); }
  if (!rows.length) { setPill('runState', '没有可处理的链接清单', 'warn'); return Promise.resolve({ ok: false, error: '没有可处理的链接清单' }); }
  var productImages = productImageList();
  if (!productImages.length) {
    showProductSubjectRequired(currentLabMode());
    return Promise.resolve({ ok: false, error: productSubjectRequiredMessage(currentLabMode()) });
  }
  syncPrimaryProductImage();
  var rangeSelection;
  try { rangeSelection = selectRowsByLinkRange(rows); } catch (rangeError) {
    setPill('runState', rangeError.message, 'warn');
    return Promise.resolve({ ok: false, error: rangeError.message });
  }
  var selected = rangeSelection.rows;
  if (!selected.length) {
    setPill('linkState', '没有匹配 ' + rangeSelection.label + ' 的链接', 'warn');
    setPill('generateState', '请检查链接编号范围', 'warn');
    return Promise.resolve({ ok: false, error: '没有匹配的链接编号' });
  }
  if (rangeSelection.missing && rangeSelection.missing.length) {
    var missingRangeMessage = '所选范围缺少链接编号：' + rangeSelection.missing.join('、') + '。请补齐后再按顺序提词。';
    setPill('runState', missingRangeMessage, 'warn');
    setPill('generateState', '链接编号不连续', 'warn');
    return Promise.resolve({ ok: false, error: missingRangeMessage, missing: rangeSelection.missing.slice() });
  }
  var mode = currentLabMode() === 'detail' ? 'detail' : 'main';
  var ruleError = selectedLinkRuleError(selected, mode);
  if (ruleError) {
    setPill('runState', ruleError, 'warn');
    setPill('generateState', '请先补齐所选编号的' + (mode === 'detail' ? '详情规划' : '主图规划'), 'warn');
    return Promise.resolve({ ok: false, error: ruleError });
  }
  var linkInputFingerprint = sourceFingerprint($('linkJson') ? $('linkJson').value : '');
  var token = ++state.batchPromptToken;
  var promptBatchId = 'prompt_batch_' + Date.now() + '_' + Math.random().toString(16).slice(2);
  clearSelectedPromptRecords(mode, selected);
  state.stopRequested = false;
  setStopAvailable(true);
  setBatchLinksBusy(true);
  setPill('linkState', '顺序提词 ' + rangeSelection.label + '，共 ' + selected.length + ' 条', 'ok');
  setPill('generateState', '仅生成提示词，不会开始生图', '');
  var records = [];
  return runSequential(selected, function (row, idx) {
    if (state.stopRequested || token !== state.batchPromptToken) throw new Error('已终止');
    if (linkInputFingerprint !== sourceFingerprint($('linkJson') ? $('linkJson').value : '')) throw new Error('链接清单已变化');
    var sequenceIndex = linkSequenceNumber(row, idx) - 1;
    return buildPromptRecordForSelectedLink(Object.assign({}, row), sequenceIndex, mode, {
      token: token,
      promptBatchId: promptBatchId
    }).then(function (record) {
      if (token !== state.batchPromptToken || !record || record.promptBatchId !== promptBatchId) throw new Error('提词批次已失效');
      records.push(record);
      return record;
    });
  }, function (idx, row) {
    setPill('runState', '链接提词 ' + (idx + 1) + '/' + selected.length + '：' + linkRowLabel(row, linkSequenceNumber(row, idx) - 1), '');
  }).then(function (settled) {
    setBatchLinksBusy(false);
    setStopAvailable(false);
    records = records.filter(function (record) {
      return record && record.promptBatchId === promptBatchId && promptRecordIsCurrent(record, mode, record.link);
    });
    var linkChanged = linkInputFingerprint !== sourceFingerprint($('linkJson') ? $('linkJson').value : '');
    if (records.length && !linkChanged) displayBatchPromptRecords(records, mode);
    var failed = settled.length - records.length;
    if (state.stopRequested) {
      setPill('runState', '提词已终止，已完成 ' + records.length + '/' + selected.length, 'warn');
      return { ok: false, stopped: true, records: records, settled: settled };
    }
    if (linkChanged) {
      setPill('runState', '链接清单在提词期间已变化，旧批次未展示；请重新生成', 'warn');
      return { ok: false, stale: true, records: [], settled: settled, error: '链接清单在提词期间已变化' };
    }
    setPill('runState', '提示词完成：' + records.length + '/' + selected.length + (failed ? '，失败 ' + failed + ' 条' : ''), failed ? 'warn' : 'ok');
    setPill('generateState', failed ? '本轮提词不完整，不能使用旧缓存生图；请重新提词' : '提示词已按 L 编号保存；点击“按编号并发生图”开始', failed ? 'warn' : 'ok');
    var firstFailure = settled.filter(function (item) { return item.status === 'rejected'; })[0];
    var firstError = firstFailure && firstFailure.reason && (firstFailure.reason.message || firstFailure.reason);
    return {
      ok: failed === 0 && records.length === selected.length,
      records: records,
      settled: settled,
      promptBatchId: promptBatchId,
      error: firstError ? String(firstError) : ''
    };
  });
}

function generateImagesForSelectedLinks() {
  var rows;
  try { rows = readBatchLinkRows(); } catch (e) { setPill('generateState', e.message, 'warn'); return Promise.resolve({ ok: false, error: e.message }); }
  if (!productImageList().length) {
    showProductSubjectRequired(currentLabMode());
    return Promise.resolve({ ok: false, error: productSubjectRequiredMessage(currentLabMode()) });
  }
  var rangeSelection;
  try { rangeSelection = selectRowsByLinkRange(rows); } catch (rangeError) {
    setPill('generateState', rangeError.message, 'warn');
    return Promise.resolve({ ok: false, error: rangeError.message });
  }
  if (!rangeSelection.rows.length) {
    setPill('generateState', '当前编号范围没有链接', 'warn');
    return Promise.resolve({ ok: false, error: '当前编号范围没有链接' });
  }
  if (rangeSelection.missing && rangeSelection.missing.length) {
    var missingRangeMessage = '所选范围缺少链接编号：' + rangeSelection.missing.join('、') + '。请补齐后再生图。';
    setPill('generateState', missingRangeMessage, 'warn');
    return Promise.resolve({ ok: false, error: missingRangeMessage, missing: rangeSelection.missing.slice() });
  }
  var mode = currentLabMode() === 'detail' ? 'detail' : 'main';
  var missing = [];
  var records = [];
  rangeSelection.rows.forEach(function (row, idx) {
    var id = canonicalLinkId(row['链接编号'], rows.indexOf(row));
    var record = state.linkPrompts[mode][id];
    if (!promptRecordIsCurrent(record, mode, row)) missing.push(id);
    else records.push(record);
  });
  if (missing.length) {
    var primaryPromptButton = mode === 'detail' ? '生成当前/选定范围详情提示词' : '生成当前/选定范围提示词';
    var message = '这些编号还没有当前主体图对应的提示词：' + missing.join('、') + '。请先点击“' + primaryPromptButton + '”或“按编号批量生成提示词”。';
    setPill('generateState', message, 'warn');
    if (window.alert) window.alert(message);
    return Promise.resolve({ ok: false, error: message });
  }
  var promptBatchIds = records.map(function (record) { return record.promptBatchId || ''; }).filter(Boolean);
  if (!promptBatchIds.length || promptBatchIds.some(function (id) { return id !== promptBatchIds[0]; })) {
    var batchMessage = '所选编号的提示词不属于同一个完整批次，请重新点击“按编号批量生成提示词”。';
    setPill('generateState', batchMessage, 'warn');
    return Promise.resolve({ ok: false, error: batchMessage });
  }
  try { records = applyBatchPromptEdits(records, mode); } catch (editError) {
    setPill('generateState', editError.message, 'warn');
    if (window.alert) window.alert(editError.message);
    return Promise.resolve({ ok: false, error: editError.message });
  }
  var productImages = productImageList().slice();
  var productEvidence = productImageEvidence().map(function (item) { return Object.assign({}, item); });
  var models = modelImageList().slice();
  var generationSettings = captureGenerationSettings(mode, mode === 'detail' ? 'link' : state.detailMode);
  var perLink = generationSettings.count;
  var batchId = 'batch_' + Date.now() + '_' + Math.random().toString(16).slice(2);
  var token = ++state.batchGenerationToken;
  var before = state.results.length;
  var completed = 0;
  state.stopRequested = false;
  setStopAvailable(true);
  setBatchLinksBusy(true);
  setPill('generateState', '按编号并发生图 0/' + records.length + '（并发上限 3）', '');
  return runConcurrent(records, 3, function (record, recordIndex) {
    if (state.stopRequested || token !== state.batchGenerationToken) return { ok: false, error: '已终止' };
    return generateOne('single', record.linkId, perLink, {
      promptRecord: record,
      productImages: productImages,
      productImageEvidence: productEvidence,
      modelImages: models,
      referenceImage: '',
      negativePrompt: record.negativePrompt,
      batchId: batchId,
      generationToken: token,
      labMode: mode,
      detailMode: mode === 'detail' ? 'link' : state.detailMode,
      generationSettings: generationSettings,
      linkBatchOrder: recordIndex
    }).then(function (resp) {
      completed++;
      if (!state.stopRequested && token === state.batchGenerationToken) setPill('generateState', '按编号并发生图 ' + completed + '/' + records.length + '：' + record.linkId, resp && resp.ok ? '' : 'warn');
      return resp;
    });
  }).then(function (settled) {
    setBatchLinksBusy(false);
    setStopAvailable(false);
    var orderedResults = orderedGenerationResults(state.results);
    state.results.splice.apply(state.results, [0, state.results.length].concat(orderedResults));
    renderResults();
    var added = Math.max(0, state.results.length - before);
    if (state.stopRequested || token !== state.batchGenerationToken) {
      setPill('generateState', '已终止；本批已返回 ' + added + ' 张', 'warn');
      return { ok: false, stopped: true, settled: settled, added: added };
    }
    var failures = settled.filter(function (item) { return item.status !== 'fulfilled' || !item.value || !item.value.ok; }).length;
    setPill('generateState', '编号并发完成：' + records.length + ' 条，新增 ' + added + ' 张' + (failures ? '，失败 ' + failures + ' 条' : ''), failures ? 'warn' : 'ok');
    return { ok: failures === 0 && added === records.length * perLink, settled: settled, added: added, batchId: batchId };
  });
}

function skuDefaultPrompt() {
  return '学习视觉模板的整体版式、光影、背景、文字区域和商业质感；把模板中的旧商品、旧品牌、旧包装全部替换为当前 SKU 产品主体。严格保持当前产品的结构、颜色、包装比例与关键细节，SKU 属性只改变用户明确填写的款式信息。';
}

function skuResolutionScale(resolution) {
  if (resolution === '4K') return 4;
  if (resolution === '2K') return 2;
  return 1;
}

function skuSizeFromSettings() {
  var ratio = ($('skuRatio') && $('skuRatio').value) || '1:1';
  var scale = skuResolutionScale(($('skuResolution') && $('skuResolution').value) || '1K');
  var base = {
    '1:1': [1024, 1024],
    '2:3': [896, 1344],
    '3:2': [1344, 896],
    '3:4': [768, 1024],
    '4:3': [1024, 768],
    '4:5': [1024, 1280],
    '5:4': [1280, 1024],
    '9:16': [1024, 1792],
    '16:9': [1792, 1024],
    '21:9': [2048, 878]
  }[ratio] || [1024, 1024];
  if (scale === 1) return base[0] + '*' + base[1];
  return Math.round(base[0] * scale) + '*' + Math.round(base[1] * scale);
}

function skuAttributes() {
  var text = ($('skuAttrText') && $('skuAttrText').value) || '';
  if (!text) return [];
  return text.replace(/^\ufeff/, '').split(/\r?\n/).map(function (line) {
    return line.trim();
  }).slice(0, state.skuMax);
}

function skuFilledAttributeCount() {
  return skuAttributes().filter(Boolean).length;
}

function skuNewIdentity() {
  state.skuProductSeq = Math.max(0, Number(state.skuProductSeq) || 0) + 1;
  return {
    skuId: 'sku_' + Date.now().toString(36) + '_' + state.skuProductSeq.toString(36),
    skuCode: 'SKU' + String(state.skuProductSeq).padStart(2, '0')
  };
}

function ensureSkuProductIdentity(item) {
  item = item || {};
  if (!item.skuId || !item.skuCode) {
    var identity = skuNewIdentity();
    item.skuId = item.skuId || identity.skuId;
    item.skuCode = item.skuCode || identity.skuCode;
  }
  if (!Object.prototype.hasOwnProperty.call(state.skuSelections, item.skuId)) state.skuSelections[item.skuId] = true;
  if (!state.skuTaskStatus[item.skuId]) state.skuTaskStatus[item.skuId] = { state: 'ready', error: '' };
  return item;
}

function skuTaskStatusFor(skuId) {
  if (!state.skuTaskStatus[skuId]) state.skuTaskStatus[skuId] = { state: 'ready', error: '' };
  return state.skuTaskStatus[skuId];
}

function skuStatusLabel(value) {
  return {
    ready: '待生成', queued: '排队中', running: '生成中', success: '已完成', failed: '失败', cancelled: '已终止', stale: '需重生'
  }[value] || '待生成';
}

function skuAttributeAt(index) {
  return skuAttributes()[index] || '';
}

function writeSkuAttributeAt(index, value) {
  var rows = skuAttributes();
  while (rows.length < state.skuProducts.length) rows.push('');
  rows[index] = String(value || '').trim();
  while (rows.length && !rows[rows.length - 1] && rows.length > state.skuProducts.length) rows.pop();
  if ($('skuAttrText')) $('skuAttrText').value = rows.join('\n');
}

function removeSkuAttributeAt(index) {
  var rows = skuAttributes();
  if (index >= 0 && index < rows.length) rows.splice(index, 1);
  if ($('skuAttrText')) $('skuAttrText').value = rows.join('\n');
}

function selectedSkuTasks(onlyFailed) {
  var attrs = skuAttributes();
  return state.skuProducts.map(function (item, index) {
    ensureSkuProductIdentity(item);
    return { item: item, index: index, skuId: item.skuId, skuCode: item.skuCode, attr: attrs[index] || '' };
  }).filter(function (task) {
    if (!state.skuSelections[task.skuId]) return false;
    return !onlyFailed || skuTaskStatusFor(task.skuId).state === 'failed';
  });
}

function updateSkuCounts() {
  state.skuProducts.forEach(ensureSkuProductIdentity);
  var selected = selectedSkuTasks(false);
  var failed = state.skuProducts.filter(function (item) { return skuTaskStatusFor(item.skuId).state === 'failed'; }).length;
  if ($('skuProductCount')) $('skuProductCount').textContent = state.skuProducts.length + ' / ' + state.skuMax;
  if ($('skuMaxHint')) $('skuMaxHint').textContent = '最多 ' + state.skuMax + ' 张，每张建立一个稳定 SKU 编号';
  if ($('skuTemplateCount')) $('skuTemplateCount').textContent = state.skuTemplate ? '1 / 1' : '0 / 1';
  if ($('skuAttrCount')) $('skuAttrCount').textContent = skuFilledAttributeCount() + ' / ' + state.skuProducts.length;
  if ($('skuTaskSummary')) $('skuTaskSummary').textContent = state.skuProducts.length + ' 条任务 · ' + selected.length + ' 条已选 · ' + failed + ' 条失败';
  if ($('skuGenerateBtn')) {
    $('skuGenerateBtn').textContent = '生成所选 SKU（' + selected.length + '）';
    $('skuGenerateBtn').disabled = state.skuActive || !selected.length;
  }
  if ($('skuRetryFailedBtn')) $('skuRetryFailedBtn').disabled = state.skuActive || !failed;
  if ($('skuDownloadAllBtn')) $('skuDownloadAllBtn').disabled = state.skuActive || !state.skuResults.length;
  if ($('skuClearBtn')) $('skuClearBtn').disabled = state.skuActive;
  if ($('skuPreflight')) {
    var missingAttrs = selected.filter(function (task) { return !task.attr; }).length;
    var text = !state.skuProducts.length
      ? '请先上传至少 1 张产品主体图。'
      : (!selected.length
        ? '当前没有选中任务，请在任务表中选择要生成的 SKU。'
        : ('预检通过：将生成 ' + selected.length + ' 张；并发 ' + ((($('skuConcurrency') && $('skuConcurrency').value) || '2')) + ' 路；' +
          (state.skuTemplate ? '已绑定视觉模板；' : '未使用模板，按全局策略生成；') +
          (missingAttrs ? missingAttrs + ' 条未填属性，将按主体图原样生成。' : '所有已选任务均有属性文本。')));
    $('skuPreflight').textContent = text;
    $('skuPreflight').className = 'sku-preflight ' + (state.skuProducts.length && selected.length ? 'ok' : 'warn');
  }
}

function renderSkuTemplate() {
  var box = $('skuTemplatePreview');
  if (!box) return;
  box.innerHTML = '';
  if (!state.skuTemplate) {
    box.className = 'sku-template-preview empty';
    box.textContent = '模板预览';
    return;
  }
  box.className = 'sku-template-preview';
  var img = document.createElement('img');
  img.src = state.skuTemplate;
  img.alt = 'SKU 模板';
  box.appendChild(img);
}

function renderSkuProducts() {
  var grid = $('skuProductPreview');
  if (!grid) return;
  grid.innerHTML = '';
  state.skuProducts.forEach(function (item, idx) {
    ensureSkuProductIdentity(item);
    var box = document.createElement('div');
    box.className = 'sku-thumb';
    var img = document.createElement('img');
    img.src = item.url;
    img.alt = item.name || ('SKU 产品图 ' + (idx + 1));
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = '×';
    btn.title = '移除';
    btn.addEventListener('click', function () {
      var removed = state.skuProducts[idx];
      state.skuProducts.splice(idx, 1);
      removeSkuAttributeAt(idx);
      if (removed) {
        delete state.skuSelections[removed.skuId];
        delete state.skuTaskStatus[removed.skuId];
        state.skuResults = state.skuResults.filter(function (result) { return result.skuId !== removed.skuId; });
      }
      renderSkuWorkspace();
    });
    box.appendChild(img);
    box.appendChild(btn);
    grid.appendChild(box);
  });
}

function renderSkuTasks() {
  var list = $('skuTaskList');
  var empty = $('skuEmpty');
  if (!list) return;
  list.innerHTML = '';
  if (empty) empty.classList.toggle('has-result', !!state.skuResults.length);
  var attrs = skuAttributes();
  state.skuProducts.forEach(function (item, idx) {
    ensureSkuProductIdentity(item);
    var row = document.createElement('div');
    row.className = 'sku-task-row';
    row.dataset.skuId = item.skuId;
    var selected = document.createElement('input');
    selected.type = 'checkbox';
    selected.className = 'sku-task-select';
    selected.checked = state.skuSelections[item.skuId] !== false;
    selected.setAttribute('aria-label', '选择 ' + item.skuCode);
    selected.addEventListener('change', function () {
      state.skuSelections[item.skuId] = !!selected.checked;
      updateSkuCounts();
    });
    var img = document.createElement('img');
    img.src = item.url;
    img.alt = item.name || ('SKU ' + (idx + 1));
    var body = document.createElement('div');
    body.className = 'sku-task-body';
    var title = document.createElement('strong');
    title.textContent = 'SKU ' + String(idx + 1).padStart(2, '0') + ' · ' + (item.name || '产品图');
    var attrInput = document.createElement('input');
    attrInput.type = 'text';
    attrInput.value = attrs[idx] || '';
    attrInput.placeholder = '填写当前 SKU 属性，例如：红色款｜加大号｜送礼袋';
    attrInput.setAttribute('aria-label', item.skuCode + ' 属性');
    attrInput.addEventListener('input', function () {
      writeSkuAttributeAt(idx, attrInput.value);
      var statusValue = skuTaskStatusFor(item.skuId);
      if (statusValue.state === 'success') statusValue.state = 'stale';
      updateSkuCounts();
    });
    attrInput.addEventListener('change', renderSkuWorkspace);
    var statusValue = skuTaskStatusFor(item.skuId);
    var status = document.createElement('b');
    status.className = 'sku-task-state ' + statusValue.state;
    status.title = statusValue.error || '';
    status.textContent = skuStatusLabel(statusValue.state);
    body.appendChild(title);
    body.appendChild(attrInput);
    row.appendChild(selected);
    row.appendChild(img);
    row.appendChild(body);
    row.appendChild(status);
    list.appendChild(row);
  });
}

function renderSkuResults() {
  var grid = $('skuResultGrid');
  if (!grid) return;
  grid.innerHTML = '';
  orderedSkuResults(state.skuResults).forEach(function (item, idx) {
    var card = document.createElement('div');
    card.className = 'result-card';
    var img = document.createElement('img');
    img.src = item.url;
    img.alt = item.variantName || 'SKU 结果图';
    makeGeneratedImagePreviewable(img, item, item.variantName || ('SKU 生成图 ' + (idx + 1)));
    var meta = document.createElement('div');
    meta.className = 'result-meta';
    var strong = document.createElement('strong');
    strong.textContent = (idx + 1) + '. ' + (item.variantName || 'SKU 生成图') + (item.skuAttribute ? ' · ' + item.skuAttribute : '');
    var urlLine = document.createElement('div');
    urlLine.className = 'result-url';
    urlLine.title = item.url;
    urlLine.textContent = item.url ? '图片链接已生成' : '无图片链接';
    var row = document.createElement('div');
    row.className = 'result-actions';
    var copyImg = document.createElement('button');
    copyImg.className = 'btn ghost';
    copyImg.type = 'button';
    copyImg.textContent = '复制图片';
    copyImg.addEventListener('click', function () { openImageActionModal(item); });
    var guideBtn = document.createElement('button');
    guideBtn.className = 'btn ghost';
    guideBtn.type = 'button';
    guideBtn.textContent = '引导重生';
    guideBtn.addEventListener('click', function () { openGuideRegenerateModal(item); });
    var dl = document.createElement('button');
    dl.className = 'btn ghost';
    dl.type = 'button';
    dl.textContent = '下载';
    dl.addEventListener('click', function () {
      send('DOWNLOAD_ALL', { items: buildDownloadItems([item], 'sku') });
    });
    row.appendChild(copyImg);
    row.appendChild(guideBtn);
    row.appendChild(dl);
    meta.appendChild(strong);
    meta.appendChild(urlLine);
    meta.appendChild(row);
    card.appendChild(img);
    card.appendChild(meta);
    grid.appendChild(card);
  });
}

function orderedSkuResults(items) {
  var order = {};
  state.skuProducts.forEach(function (item, index) { if (item && item.skuId) order[item.skuId] = index; });
  return (items || []).map(function (item, index) { return { item: item, index: index }; }).sort(function (a, b) {
    var ai = Object.prototype.hasOwnProperty.call(order, a.item && a.item.skuId) ? order[a.item.skuId] : Number(a.item && a.item.sourceIndex);
    var bi = Object.prototype.hasOwnProperty.call(order, b.item && b.item.skuId) ? order[b.item.skuId] : Number(b.item && b.item.sourceIndex);
    if (!isFinite(ai)) ai = 99999;
    if (!isFinite(bi)) bi = 99999;
    return ai - bi || a.index - b.index;
  }).map(function (entry) { return entry.item; });
}

function renderSkuWorkspace() {
  renderSkuProducts();
  renderSkuTemplate();
  renderSkuTasks();
  renderSkuResults();
  updateSkuCounts();
}

function addSkuProducts(items) {
  items = (items || []).filter(function (item) { return item && item.url; });
  var added = 0, duplicates = 0, overflow = 0;
  items.forEach(function (item) {
    if (state.skuProducts.length >= state.skuMax) { overflow++; return; }
    var exists = state.skuProducts.some(function (old) { return old.url === item.url; });
    if (exists) { duplicates++; return; }
    item.source = item.source || 'file';
    ensureSkuProductIdentity(item);
    state.skuProducts.push(item);
    added++;
  });
  renderSkuWorkspace();
  if (overflow) setPill('skuState', '最多 ' + state.skuMax + ' 张，已忽略超出的 ' + overflow + ' 张', 'warn');
  else if (duplicates) setPill('skuState', '已加入 ' + added + ' 张，跳过重复图片 ' + duplicates + ' 张', duplicates ? 'warn' : 'ok');
  return { added: added, duplicates: duplicates, overflow: overflow };
}

function allSkuUrlLines() {
  var text = ($('skuProductUrls') && $('skuProductUrls').value) || '';
  return text.split(/\r?\n/).map(function (line) {
    return normalizeImageUrl(line.trim());
  }).filter(Boolean);
}

function parseSkuUrlLines() {
  return allSkuUrlLines().slice(0, state.skuMax);
}

function readTextFile(file) {
  return new Promise(function (resolve, reject) {
    var rd = new FileReader();
    rd.onload = function () { resolve(rd.result || ''); };
    rd.onerror = function () { reject(rd.error); };
    rd.readAsText(file);
  });
}

function skuPromptFor(item, idx, attr) {
  var userPrompt = (($('skuPrompt') && $('skuPrompt').value.trim()) || skuDefaultPrompt());
  var parts = [
    '批量 SKU 生成任务：' + ((item && item.skuCode) || ('SKU' + String(idx + 1).padStart(2, '0'))) + '。',
    state.skuTemplate
      ? '视觉模板只提供构图、背景、光影、文字区域、卖点布局、材质质感和商业风格；不要复制模板里的旧商品、旧包装、旧品牌、旧文案。'
      : '本任务没有视觉模板：根据全局设计策略建立清爽统一的电商 SKU 视觉版式。',
    '当前 SKU 产品图是唯一目标商品主体：必须保持它的外观结构、颜色、包装比例、关键细节和可识别品类，不要变成模板商品、旧商品或参考图商品。',
    '如果用户提示词、模板图或历史结果描述了其他商品主体，只保留版式与风格信息，最终商品必须替换为当前 SKU 产品图。',
    attr ? '本张 SKU 属性文本：' + attr : '',
    '用户提示词：' + userPrompt,
    '输出要求：生成一张可用于 SKU 展示的电商商品图，主体清楚、排版稳定、文字区域克制，风格统一但每张产品保持自身差异。',
    '禁止：旧品牌、旧 logo、旧商品、复制模板商标、错换品类、主体被遮挡、文字乱码、夸张畸形结构。'
  ];
  return parts.filter(Boolean).join('\n');
}

function skuConfigForGeneration() {
  var cfg = cfgFromForm();
  var model = ($('skuImageModel') && $('skuImageModel').value) || 'current';
  if (model && model !== 'current') cfg.imageModel = model;
  return cfg;
}

function setSkuBusy(on) {
  state.skuActive = !!on;
  if ($('skuStopBtn')) {
    $('skuStopBtn').hidden = !on;
    $('skuStopBtn').disabled = !on;
  }
  updateSkuCounts();
}

function stopSkuGeneration() {
  if (!state.skuActive) return;
  state.stopRequested = true;
  state.skuBatchToken++;
  Object.keys(state.skuActiveJobIds).forEach(function (jobId) {
    state.cancelledJobs[jobId] = true;
    send('CANCEL_GENERATION', { jobId: jobId });
  });
  Object.keys(state.skuTaskStatus).forEach(function (skuId) {
    var status = state.skuTaskStatus[skuId];
    if (status.state === 'queued' || status.state === 'running') status.state = 'cancelled';
  });
  if ($('skuStopBtn')) $('skuStopBtn').disabled = true;
  setPill('skuState', '正在终止在途 SKU…', 'warn');
  renderSkuWorkspace();
}

function generateSkuOne(task, token) {
  var item = task && task.item;
  var idx = task && task.index;
  var attr = task && task.attr;
  if (!item || !item.url) {
    showProductSubjectRequired('sku');
    return Promise.resolve({ ok: false, error: productSubjectRequiredMessage('sku') });
  }
  var jobId = newJobId();
  state.skuActiveJobIds[jobId] = item.skuId;
  state.skuTaskStatus[item.skuId] = { state: 'running', error: '', jobId: jobId };
  renderSkuWorkspace();
  var prompt = skuPromptFor(item, idx, attr);
  var negative = replacementNegativePrompt();
  var payload = {
    prompt: prompt,
    negativePrompt: negative,
    referenceImage: state.skuTemplate || '',
    productImage: item.url,
    productImages: [item.url],
    modelImages: [],
    labMode: 'sku',
    detailMode: 'sku',
    size: skuSizeFromSettings(),
    clarity: 'commercial',
    count: 1,
    watermark: 'false',
    _jobId: jobId
  };
  return send('GENERATE_IMAGE', { jobId: jobId, config: skuConfigForGeneration(), payload: payload }).then(function (resp) {
    delete state.skuActiveJobIds[jobId];
    if (token !== state.skuBatchToken || state.stopRequested || state.cancelledJobs[jobId]) {
      delete state.cancelledJobs[jobId];
      state.skuTaskStatus[item.skuId] = { state: 'cancelled', error: '已终止' };
      return { ok: false, error: '已终止' };
    }
    if (resp && resp.ok && resp.images && resp.images.length) {
      resp.images.forEach(function (url) {
        state.skuResults.push({
          url: url,
          variant: 'sku',
          variantName: item.skuCode || ('SKU' + String(idx + 1).padStart(2, '0')),
          skuId: item.skuId,
          skuCode: item.skuCode,
          skuAttribute: attr || '',
          sourceIndex: idx,
          taskId: resp.taskId || '',
          prompt: prompt,
          negativePrompt: negative,
          skuProductImage: item.url
        });
      });
      state.skuTaskStatus[item.skuId] = { state: 'success', error: '' };
      renderSkuWorkspace();
    } else {
      state.skuTaskStatus[item.skuId] = { state: 'failed', error: (resp && resp.error) || '生图失败' };
      renderSkuWorkspace();
    }
    return resp;
  }).catch(function (error) {
    delete state.skuActiveJobIds[jobId];
    state.skuTaskStatus[item.skuId] = { state: 'failed', error: (error && error.message) || String(error) };
    renderSkuWorkspace();
    return { ok: false, error: (error && error.message) || String(error) };
  });
}

function generateSkuBatch(onlyFailed) {
  if (state.skuActive) return Promise.resolve({ ok: false, error: 'SKU 批次正在运行' });
  if (!state.skuProducts.length) {
    showProductSubjectRequired('sku');
    return Promise.resolve({ ok: false, error: productSubjectRequiredMessage('sku') });
  }
  var tasks = selectedSkuTasks(!!onlyFailed);
  if (!tasks.length) {
    setPill('skuState', onlyFailed ? '没有可重试的失败项' : '请先选择至少 1 条 SKU 任务', 'warn');
    return Promise.resolve({ ok: false, error: '没有选中的 SKU 任务' });
  }
  state.stopRequested = false;
  var token = ++state.skuBatchToken;
  var selectedIds = {};
  tasks.forEach(function (task) {
    selectedIds[task.skuId] = true;
    state.skuTaskStatus[task.skuId] = { state: 'queued', error: '' };
  });
  state.skuResults = state.skuResults.filter(function (result) { return !selectedIds[result.skuId]; });
  setSkuBusy(true);
  setPill('skuState', 'SKU 并发生成中 0/' + tasks.length, '');
  renderSkuWorkspace();
  var concurrency = Math.max(1, Math.min(3, parseInt(($('skuConcurrency') && $('skuConcurrency').value) || '2', 10) || 2));
  var cursor = 0, completed = 0;
  function worker() {
    if (state.stopRequested || token !== state.skuBatchToken) return Promise.resolve();
    var task = tasks[cursor++];
    if (!task) return Promise.resolve();
    return generateSkuOne(task, token).then(function (resp) {
      completed++;
      if (!state.stopRequested && token === state.skuBatchToken) {
        setPill('skuState', 'SKU 并发生成中 ' + completed + '/' + tasks.length + '：' + task.skuCode, resp && resp.ok ? '' : 'warn');
      }
      return worker();
    });
  }
  var workers = [];
  for (var i = 0; i < Math.min(concurrency, tasks.length); i++) workers.push(worker());
  return Promise.all(workers).then(function () {
    setSkuBusy(false);
    state.skuActiveJobIds = {};
    if (state.stopRequested || token !== state.skuBatchToken) {
      setPill('skuState', '已终止：完成 ' + state.skuResults.filter(function (result) { return selectedIds[result.skuId]; }).length + '/' + tasks.length, 'warn');
      renderSkuWorkspace();
      return { ok: false, stopped: true, total: tasks.length };
    }
    var failed = tasks.filter(function (task) { return skuTaskStatusFor(task.skuId).state === 'failed'; });
    var succeeded = tasks.length - failed.length;
    setPill('skuState', failed.length
      ? ('SKU 批次完成：成功 ' + succeeded + '，失败 ' + failed.length + '，可点击重试')
      : ('SKU 批次完成：成功 ' + succeeded + '/' + tasks.length), failed.length ? 'warn' : 'ok');
    renderSkuWorkspace();
    return { ok: failed.length === 0, total: tasks.length, succeeded: succeeded, failed: failed.length };
  });
}

function retryFailedSkuTasks() {
  Object.keys(state.skuSelections).forEach(function (skuId) { state.skuSelections[skuId] = false; });
  state.skuProducts.forEach(function (item) {
    if (skuTaskStatusFor(item.skuId).state === 'failed') state.skuSelections[item.skuId] = true;
  });
  renderSkuWorkspace();
  return generateSkuBatch(true);
}

function markSkuTasksStale() {
  state.skuProducts.forEach(function (item) {
    var status = skuTaskStatusFor(item.skuId);
    if (status.state === 'success') status.state = 'stale';
  });
  renderSkuWorkspace();
}

function setAllSkuSelections(selected) {
  state.skuProducts.forEach(function (item) {
    ensureSkuProductIdentity(item);
    state.skuSelections[item.skuId] = !!selected;
  });
  renderSkuWorkspace();
}

function copyText(text, stateId) {
  navigator.clipboard.writeText(text || '').then(function () {
    setPill(stateId || 'runState', '已复制', 'ok');
  }).catch(function () {
    setPill(stateId || 'runState', '复制失败', 'warn');
  });
}

function loadStoredLinks() {
  return new Promise(function (resolve) {
    try {
      chrome.storage.local.get([LINKMATRIX_JSON_KEY], function (r) {
        var saved = r && r[LINKMATRIX_JSON_KEY];
        var rows = normalizeLinkRows(saved);
        if (!rows.length) {
          setPill('linkState', '暂无缓存链接', 'warn');
          resolve({ ok: false, error: '暂无缓存链接' });
          return;
        }
        $('linkJson').value = JSON.stringify(rows, null, 2);
        applyLinkToFields(rows, true);
        syncBatchRangeDefaults(rows, false);
        setPill('linkState', '已载入 ' + rows.length + ' 条链接', 'ok');
        resolve({ ok: true, rows: rows });
      });
    } catch (e) {
      setPill('linkState', '载入失败', 'warn');
      resolve({ ok: false, error: (e && e.message) || e });
    }
  });
}

function loadContext(auto) {
  send('GET_CONTEXT').then(function (r) {
    if (!r || !r.ok) return;
    var normalized = applyCfg(r.config);
    if (r.migrated) {
      setPill('configState', '已自动修复旧模型配置', 'ok');
    } else if (JSON.stringify(normalized) !== JSON.stringify(Object.assign({}, DEFAULT_CFG, r.config || {}))) {
      send('SAVE_CONFIG', { config: normalized });
      setPill('configState', '已自动迁移旧模型配置', 'ok');
    }
    var params = new URLSearchParams(location.search);
    if (params.get('source') !== 'context') return;
    if (!r.context || !r.context.imageUrl) {
      setPill('contextState', '本次右键图片已使用或已失效，请重新右键采集', 'warn');
      return;
    }
    var shouldAnalyze = !!(auto && r.config && r.config.apiKey);
    if (auto) {
      applyAndConsumeContextImage(r.context, shouldAnalyze);
      return;
    }
    openContextActionModal(r.context, shouldAnalyze);
  });
}

function bind() {
  if ($('openKnowledgeBtn')) $('openKnowledgeBtn').addEventListener('click', openBusinessKnowledge);
  if ($('openConfigBtn')) $('openConfigBtn').addEventListener('click', openUnifiedApiSettings);
  if (window.addEventListener) window.addEventListener('focus', function () {
    if (!state.awaitingUnifiedConfigRefresh) return;
    state.awaitingUnifiedConfigRefresh = false;
    loadContext(false);
    setPill('configState', '已从统一 API 设置重新载入', 'ok');
  });
  $('saveConfigBtn').addEventListener('click', saveCfg);
  if ($('configCloseBtn')) $('configCloseBtn').addEventListener('click', closeConfigModal);
  if ($('configCancelBtn')) $('configCancelBtn').addEventListener('click', closeConfigModal);
  if ($('configModal')) $('configModal').addEventListener('click', function (ev) {
    if (ev.target === $('configModal')) closeConfigModal();
  });
  $('loadSampleBtn').addEventListener('click', function () {
    if (currentLabMode() === 'sku') loadSkuSample();
    else if (currentLabMode() === 'detail') loadDetailSample();
    else applyLinkToFields(sampleLink);
  });
  $('provider').addEventListener('change', function () {
    loadProviderProfile($('provider').value);
  });
  if ($('providerRail')) $('providerRail').addEventListener('click', function (ev) {
    var btn = ev.target.closest && ev.target.closest('[data-provider-pick]');
    if (!btn) return;
    var provider = btn.getAttribute('data-provider-pick');
    if (!provider || !$('provider')) return;
    $('provider').value = provider;
    loadProviderProfile(provider);
  });
  ['apiKey', 'imageAdapter', 'visionModel', 'textModel', 'imageModel', 'visionBaseUrl', 'imageEndpoint'].forEach(function (id) {
    var el = $(id);
    if (!el) return;
    var eventName = el.tagName === 'SELECT' ? 'change' : 'input';
    el.addEventListener(eventName, function () {
      updateConfigSummary(cfgFromForm());
      setPill('configState', el.id === 'apiKey' && !el.value ? '未配置' : '待保存', el.id === 'apiKey' && !el.value ? 'warn' : '');
    });
  });
  $('refFile').addEventListener('change', function (ev) {
    var remain = Math.max(0, 6 - referenceImageList().length);
    var selectedFiles = Array.prototype.slice.call((ev.target && ev.target.files) || []);
    var overflow = Math.max(0, selectedFiles.length - remain);
    var files = selectedFiles.slice(0, remain);
    if (!files.length) {
      if (referenceImageList().length >= 6) setPill('contextState', '参考页已达 6 张上限', 'warn');
      return;
    }
    setPill('contextState', '压缩参考页中 0/' + files.length + '...', '');
    var completed = 0;
    Promise.all(files.map(function (file) {
      return fileToOptimizedDataUrl(file).then(function (url) {
        completed++;
        setPill('contextState', '压缩参考页中 ' + completed + '/' + files.length + '...', '');
        return url;
      });
    })).then(function (urls) {
      var next = addRefImages(urls);
      setPill('contextState', '已载入参考页 ' + next.length + ' / 6' + (overflow ? ('；超出上限的 ' + overflow + ' 张未加入') : ''), overflow ? 'warn' : 'ok');
      ev.target.value = '';
    });
  });
  Object.keys(PRODUCT_ANGLES).forEach(function (kind) {
    var meta = PRODUCT_ANGLES[kind];
    if ($(meta.file)) $(meta.file).addEventListener('change', function (ev) {
      var f = ev.target.files && ev.target.files[0];
      if (!f) return;
      setPill('contextState', '压缩' + meta.label + '中...', '');
      fileToOptimizedDataUrl(f).then(function (url) { setProductAngle(kind, url, ''); });
    });
    if ($(meta.url)) $(meta.url).addEventListener('change', function () {
      setProductAngle(kind, normalizeImageUrl($(meta.url).value), $(meta.url).value);
    });
    var clearBtn = $('clearProduct' + kind.charAt(0).toUpperCase() + kind.slice(1) + 'Btn');
    if (clearBtn) clearBtn.addEventListener('click', function () {
      setProductAngle(kind, '', '');
      if ($(meta.file)) $(meta.file).value = '';
    });
  });
  Object.keys(MODEL_ANGLES).forEach(function (kind) {
    var meta = MODEL_ANGLES[kind];
    if ($(meta.file)) $(meta.file).addEventListener('change', function (ev) {
      var f = ev.target.files && ev.target.files[0];
      if (!f) return;
      setPill('contextState', '压缩' + meta.label + '中...', '');
      fileToOptimizedDataUrl(f).then(function (url) { setModelAngle(kind, url, ''); });
    });
    if ($(meta.url)) $(meta.url).addEventListener('change', function () {
      setModelAngle(kind, normalizeImageUrl($(meta.url).value), $(meta.url).value);
    });
    var clearBtn = $('clearModel' + kind.charAt(0).toUpperCase() + kind.slice(1) + 'Btn');
    if (clearBtn) clearBtn.addEventListener('click', function () {
      setModelAngle(kind, '', '');
      if ($(meta.file)) $(meta.file).value = '';
    });
  });
  $('refUrl').addEventListener('change', function () {
    var localUploads = (state.refImages || []).filter(function (image) { return /^data:image\//.test(image); });
    setRefImages(localUploads.concat(parseReferenceUrls($('refUrl').value)), $('refUrl').value);
  });
  $('clearRefBtn').addEventListener('click', function () { setRefImages([], ''); $('refFile').value = ''; });
  $('analyzeBtn').addEventListener('click', analyzeCurrentImage);
  $('buildPromptBtn').addEventListener('click', buildLinkPrompt);
  if ($('batchLinksBtn')) $('batchLinksBtn').addEventListener('click', generateSelectedLinkPrompts);
  if ($('loadStoredLinksBtn')) $('loadStoredLinksBtn').addEventListener('click', loadStoredLinks);
  if ($('detailRefModeBtn')) $('detailRefModeBtn').addEventListener('click', function () { setDetailMode('reference'); });
  if ($('detailLinkModeBtn')) $('detailLinkModeBtn').addEventListener('click', function () { setDetailMode('link'); });
  if ($('detailScreenCount')) $('detailScreenCount').addEventListener('change', function () {
    $('detailScreenCount').dataset.userTouched = '1';
    syncDetailModeControls();
    syncDetailGenerationCount(true);
  });
  ['detailRatio', 'detailResolution'].forEach(function (id) {
    var el = $(id);
    if (!el) return;
    el.addEventListener('change', syncGenerationParamSummary);
  });
  if ($('detailStitchToggle')) $('detailStitchToggle').addEventListener('change', renderDetailLongPreview);
  if ($('detailSmartFillBtn')) $('detailSmartFillBtn').addEventListener('click', fillDetailFieldsFromContext);
  if ($('detailModelGenerateBtn')) $('detailModelGenerateBtn').addEventListener('click', buildModelThreeViewPrompt);
  if ($('detailRefGenerateBtn')) $('detailRefGenerateBtn').addEventListener('click', generateDetailPromptFromPrimaryAction);
  if ($('detailLinkGenerateBtn')) $('detailLinkGenerateBtn').addEventListener('click', function () {
    setDetailMode('link');
    return generateDetailPromptFromPrimaryAction();
  });
  if ($('copyDetailPromptBtn')) $('copyDetailPromptBtn').addEventListener('click', function () { copyText($('detailPrompt') ? $('detailPrompt').value : '', 'detailState'); });
  if ($('skuProductFiles')) $('skuProductFiles').addEventListener('change', function (ev) {
    var selectedFiles = Array.prototype.slice.call((ev.target && ev.target.files) || []);
    var room = Math.max(0, state.skuMax - state.skuProducts.length);
    var overflow = Math.max(0, selectedFiles.length - room);
    var files = selectedFiles.slice(0, room);
    if (!files.length) return;
    setPill('skuState', '压缩 SKU 产品图中...', '');
    Promise.all(files.map(function (file) {
      return fileToOptimizedDataUrl(file).then(function (url) {
        return { url: url, name: file.name || '产品图', source: 'file' };
      });
    })).then(function (items) {
      addSkuProducts(items);
      ev.target.value = '';
      setPill('skuState', '已载入产品图 ' + state.skuProducts.length + ' / ' + state.skuMax + (overflow ? ('；超出上限 ' + overflow + ' 张未加入') : ''), overflow ? 'warn' : 'ok');
    });
  });
  function syncSkuProductUrls() {
    var allUrls = allSkuUrlLines();
    var urls = allUrls.slice(0, state.skuMax);
    var removed = state.skuProducts.filter(function (item) { return item.source === 'url' && urls.indexOf(item.url) < 0; });
    removed.forEach(function (item) {
      var index = state.skuProducts.indexOf(item);
      if (index < 0) return;
      state.skuProducts.splice(index, 1);
      removeSkuAttributeAt(index);
      delete state.skuSelections[item.skuId];
      delete state.skuTaskStatus[item.skuId];
      state.skuResults = state.skuResults.filter(function (result) { return result.skuId !== item.skuId; });
    });
    var summary = addSkuProducts(urls.map(function (url, idx) {
      return { url: url, name: 'URL 产品图 ' + (idx + 1), source: 'url' };
    }));
    if (allUrls.length > state.skuMax) setPill('skuState', 'URL 共 ' + allUrls.length + ' 条，只保留前 ' + state.skuMax + ' 条', 'warn');
    return summary;
  }
  if ($('skuProductUrls')) {
    var skuUrlSyncTimer = 0;
    $('skuProductUrls').addEventListener('input', function () {
      clearTimeout(skuUrlSyncTimer);
      skuUrlSyncTimer = setTimeout(syncSkuProductUrls, 350);
    });
    $('skuProductUrls').addEventListener('change', function () {
      clearTimeout(skuUrlSyncTimer);
      syncSkuProductUrls();
    });
  }
  if ($('skuTemplateFile')) $('skuTemplateFile').addEventListener('change', function (ev) {
    var f = ev.target.files && ev.target.files[0];
    if (!f) return;
    setPill('skuState', '压缩 SKU 模板中...', '');
    fileToOptimizedDataUrl(f).then(function (url) {
      state.skuTemplate = url;
      markSkuTasksStale();
      renderSkuWorkspace();
      setPill('skuState', '已载入 SKU 模板', 'ok');
    });
  });
  function syncSkuTemplateUrl() {
    state.skuTemplate = normalizeImageUrl($('skuTemplateUrl').value);
    markSkuTasksStale();
  }
  if ($('skuTemplateUrl')) {
    $('skuTemplateUrl').addEventListener('input', syncSkuTemplateUrl);
    $('skuTemplateUrl').addEventListener('change', syncSkuTemplateUrl);
  }
  if ($('skuTemplateClearBtn')) $('skuTemplateClearBtn').addEventListener('click', function () {
    state.skuTemplate = '';
    if ($('skuTemplateFile')) $('skuTemplateFile').value = '';
    if ($('skuTemplateUrl')) $('skuTemplateUrl').value = '';
    markSkuTasksStale();
    setPill('skuState', '已移除视觉模板', 'ok');
  });
  if ($('skuAttrText')) $('skuAttrText').addEventListener('input', renderSkuWorkspace);
  if ($('skuAttrFile')) $('skuAttrFile').addEventListener('change', function (ev) {
    var f = ev.target.files && ev.target.files[0];
    if (!f) return;
    readTextFile(f).then(function (text) {
      $('skuAttrText').value = text;
      renderSkuWorkspace();
      setPill('skuState', '已载入 SKU 属性文本', 'ok');
    }).catch(function () {
      setPill('skuState', 'SKU 属性文本读取失败', 'warn');
    });
  });
  if ($('skuPromptTemplateBtn')) $('skuPromptTemplateBtn').addEventListener('click', function () {
    $('skuPrompt').value = skuDefaultPrompt();
    markSkuTasksStale();
    setPill('skuState', '已载入提示词模板', 'ok');
  });
  if ($('skuPrompt')) $('skuPrompt').addEventListener('change', markSkuTasksStale);
  ['skuImageModel', 'skuResolution', 'skuRatio'].forEach(function (id) {
    if ($(id)) $(id).addEventListener('change', markSkuTasksStale);
  });
  if ($('skuConcurrency')) $('skuConcurrency').addEventListener('change', updateSkuCounts);
  if ($('skuSelectAllBtn')) $('skuSelectAllBtn').addEventListener('click', function () { setAllSkuSelections(true); });
  if ($('skuSelectNoneBtn')) $('skuSelectNoneBtn').addEventListener('click', function () { setAllSkuSelections(false); });
  if ($('skuGenerateBtn')) $('skuGenerateBtn').addEventListener('click', function () { generateSkuBatch(false); });
  if ($('skuRetryFailedBtn')) $('skuRetryFailedBtn').addEventListener('click', retryFailedSkuTasks);
  if ($('skuStopBtn')) $('skuStopBtn').addEventListener('click', stopSkuGeneration);
  if ($('skuDownloadAllBtn')) $('skuDownloadAllBtn').addEventListener('click', function () {
    send('DOWNLOAD_ALL', { items: buildDownloadItems(state.skuResults, 'sku') }).then(function (r) {
      setPill('skuState', r && r.ok ? ('开始下载 ' + r.count + ' 张') : ((r && r.error) || '下载失败'), r && r.ok ? 'ok' : 'warn');
    });
  });
  if ($('skuClearBtn')) $('skuClearBtn').addEventListener('click', function () {
    state.skuProducts = [];
    state.skuTemplate = '';
    state.skuResults = [];
    state.skuSelections = {};
    state.skuTaskStatus = {};
    state.skuActiveJobIds = {};
    state.skuProductSeq = 0;
    if ($('skuProductFiles')) $('skuProductFiles').value = '';
    if ($('skuProductUrls')) $('skuProductUrls').value = '';
    if ($('skuTemplateFile')) $('skuTemplateFile').value = '';
    if ($('skuTemplateUrl')) $('skuTemplateUrl').value = '';
    if ($('skuAttrFile')) $('skuAttrFile').value = '';
    if ($('skuAttrText')) $('skuAttrText').value = '';
    renderSkuWorkspace();
    setPill('skuState', '等待素材', '');
  });
  if ($('generateBtn')) $('generateBtn').addEventListener('click', generateCurrent);
  if ($('linkNumberGenerateBtn')) $('linkNumberGenerateBtn').addEventListener('click', generateImagesForSelectedLinks);
  if ($('batchBtn')) $('batchBtn').addEventListener('click', batchGenerate);
  if ($('stopGenerateBtn')) $('stopGenerateBtn').addEventListener('click', stopGeneration);
  if ($('imageCount')) $('imageCount').addEventListener('input', function () {
    $('imageCount').dataset.userTouched = '1';
    $('imageCount').value = '' + generationImageCount();
  });
  if ($('copyCnBtn')) $('copyCnBtn').addEventListener('click', function () { copyText($('cnPrompt').value); });
  if ($('copyEnBtn')) $('copyEnBtn').addEventListener('click', function () { copyText($('enPrompt').value); });
  if ($('copyAllPromptBtn')) $('copyAllPromptBtn').addEventListener('click', function () {
    var prompt = currentLabMode() === 'detail' && $('detailPrompt') ? $('detailPrompt').value : $('cnPrompt').value;
    copyText(['中文提示词：', prompt, '', '负面提示词：', $('negativePrompt').value].join('\n'));
  });
  $('downloadAllBtn').addEventListener('click', function () {
    var items = currentLabMode() === 'detail' ? detailPreviewResults() : state.results;
    send('DOWNLOAD_ALL', { items: buildDownloadItems(items, currentLabMode()) }).then(function (r) {
      setPill('generateState', r && r.ok ? ('开始下载 ' + r.count + ' 张') : ((r && r.error) || '下载失败'), r && r.ok ? 'ok' : 'warn');
    });
  });
  $('clearResultsBtn').addEventListener('click', function () {
    state.results = [];
    state.detailStitchSelectionOrder = [];
    if ($('detailStitchToggle')) $('detailStitchToggle').checked = false;
    renderResults();
    setPill('generateState', generationIdleText(), '');
  });
  if ($('detailStitchBtn')) $('detailStitchBtn').addEventListener('click', stitchDetailLongImage);
  if ($('copyOriginalImageBtn')) $('copyOriginalImageBtn').addEventListener('click', function () {
    var item = state.actionItem;
    closeImageActionModal();
    copyImageToClipboard(item && item.url);
  });
  if ($('copyShareCardBtn')) $('copyShareCardBtn').addEventListener('click', function () {
    var item = state.actionItem;
    closeImageActionModal();
    copyShareCardToClipboard(item);
  });
  if ($('imageActionClose')) $('imageActionClose').addEventListener('click', closeImageActionModal);
  if ($('imageActionModal')) $('imageActionModal').addEventListener('click', function (ev) {
    if (ev.target === $('imageActionModal')) closeImageActionModal();
  });
  if ($('generatedImagePreviewClose')) $('generatedImagePreviewClose').addEventListener('click', closeGeneratedImagePreview);
  if ($('generatedImagePreviewModal')) $('generatedImagePreviewModal').addEventListener('click', function (ev) {
    if (ev.target === $('generatedImagePreviewModal')) closeGeneratedImagePreview();
  });
  document.addEventListener('keydown', function (ev) {
    if (ev && ev.key === 'Escape' && $('generatedImagePreviewModal') && !$('generatedImagePreviewModal').hidden) {
      closeGeneratedImagePreview();
    }
  });
  if ($('guideRunBtn')) $('guideRunBtn').addEventListener('click', runGuideRegenerate);
  if ($('guideCancelBtn')) $('guideCancelBtn').addEventListener('click', closeGuideRegenerateModal);
  if ($('guideActionClose')) $('guideActionClose').addEventListener('click', closeGuideRegenerateModal);
  if ($('guideActionModal')) $('guideActionModal').addEventListener('click', function (ev) {
    if (ev.target === $('guideActionModal')) closeGuideRegenerateModal();
  });
  if ($('productSubjectFocusBtn')) $('productSubjectFocusBtn').addEventListener('click', function () {
    focusProductSubjectUpload();
  });
  if ($('productSubjectCancelBtn')) $('productSubjectCancelBtn').addEventListener('click', closeProductSubjectModal);
  if ($('productSubjectClose')) $('productSubjectClose').addEventListener('click', closeProductSubjectModal);
  if ($('productSubjectModal')) $('productSubjectModal').addEventListener('click', function (ev) {
    if (ev.target === $('productSubjectModal')) closeProductSubjectModal();
  });
  if ($('contextImportBtn')) $('contextImportBtn').addEventListener('click', function () {
    var ctx = state.contextItem;
    var auto = state.contextAuto;
    closeContextActionModal();
    applyAndConsumeContextImage(ctx, auto);
  });
  if ($('contextShareCardBtn')) $('contextShareCardBtn').addEventListener('click', function () {
    var ctx = state.contextItem;
    closeContextActionModal();
    if (!$('apiKey') || !$('apiKey').value.trim()) {
      setPill('runState', '请先在插件启动界面的“统一 API 设置”保存 API Key', 'warn');
      openUnifiedApiSettings();
      return;
    }
    applyAndConsumeContextImage(ctx, true).then(function (resp) {
      if (resp && resp.ok) {
        copyShareCardToClipboard({ url: ctx && ctx.imageUrl, variantName: '提示词分享卡', prompt: $('cnPrompt').value || $('enPrompt').value });
      }
    });
  });
  if ($('contextActionClose')) $('contextActionClose').addEventListener('click', closeContextActionModal);
  if ($('contextActionModal')) $('contextActionModal').addEventListener('click', function (ev) {
    if (ev.target === $('contextActionModal')) closeContextActionModal();
  });
  document.querySelectorAll('[data-share-card]').forEach(function (ctrl) {
    ctrl.addEventListener('change', function (ev) { syncShareCardControls(ev); });
    ctrl.addEventListener('input', function (ev) { syncShareCardControls(ev); });
  });
  syncShareCardControls({ position: 'top', border: '36', ratio: '4:5' });
  $('linkJson').addEventListener('change', function () {
    try { applyLinkToFields(parseLinkListInput(), true); } catch (e) { setPill('linkState', 'JSON 待修正', 'warn'); }
  });
  document.addEventListener('paste', function (ev) {
    var items = ev.clipboardData && ev.clipboardData.items;
    if (!items) return;
    for (var i = 0; i < items.length; i++) {
      if (items[i] && items[i].type && items[i].type.indexOf('image/') === 0) {
        ev.preventDefault();
        var file = items[i].getAsFile();
        if (!file) return;
        var activeId = document.activeElement && document.activeElement.id;
        setPill('contextState', '压缩粘贴图片中...', '');
        fileToOptimizedDataUrl(file).then(function (url) {
          if (activeId === 'skuProductUrls') {
            addSkuProducts([{ url: url, name: '粘贴产品图', source: 'paste' }]);
            setPill('skuState', '已粘贴 SKU 产品图', 'ok');
            return;
          }
          if (activeId === 'skuTemplateUrl') {
            state.skuTemplate = url;
            if ($('skuTemplateUrl')) $('skuTemplateUrl').value = '';
            renderSkuWorkspace();
            setPill('skuState', '已粘贴 SKU 模板', 'ok');
            return;
          }
          var matched = '';
          Object.keys(PRODUCT_ANGLES).some(function (kind) {
            if (PRODUCT_ANGLES[kind].url === activeId) { matched = kind; return true; }
            return false;
          });
          if (matched) setProductAngle(matched, url, '');
          else {
            Object.keys(MODEL_ANGLES).some(function (kind) {
              if (MODEL_ANGLES[kind].url === activeId) { matched = 'model:' + kind; return true; }
              return false;
            });
            if (matched.indexOf('model:') === 0) setModelAngle(matched.split(':')[1], url, '');
            else addRefImages([url]);
          }
        });
        return;
      }
    }
  });
}

if (typeof globalThis !== 'undefined' && globalThis.__SZ_PROMPTLAB_TEST_MODE__) {
  globalThis.__SZ_PROMPTLAB_TEST_API__ = {
    state: state,
    setTestSend: function (fn) { promptLabTestSend = fn; },
    setRefImage: setRefImage,
    setRefImages: setRefImages,
    addRefImages: addRefImages,
    referenceImageList: referenceImageList,
    setProductAngle: setProductAngle,
    setModelAngle: setModelAngle,
    productImageEvidence: productImageEvidence,
    collectDetailPayload: collectDetailPayload,
    fillDetailFieldsFromContext: fillDetailFieldsFromContext,
    canonicalLinkId: canonicalLinkId,
    normalizeLinkRowsForBatch: normalizeLinkRowsForBatch,
    firstLinkSequence: firstLinkSequence,
    defaultBatchEndSequence: defaultBatchEndSequence,
    mainLinkPlanningLayer: mainLinkPlanningLayer,
    referenceStyleNotes: referenceStyleNotes,
    subjectReplacementPrompt: subjectReplacementPrompt,
    runSequential: runSequential,
    runConcurrent: runConcurrent,
    buildLinkPrompt: buildLinkPrompt,
    setDetailMode: setDetailMode,
    generateDetailPromptFromPrimaryAction: generateDetailPromptFromPrimaryAction,
    generateSelectedLinkPrompts: generateSelectedLinkPrompts,
    generateImagesForSelectedLinks: generateImagesForSelectedLinks,
    ensureReferencePromptForGeneration: ensureReferencePromptForGeneration,
    generateCurrent: generateCurrent,
    stopGeneration: stopGeneration,
    displayBatchPromptRecords: displayBatchPromptRecords,
    normalizeCfg: normalizeCfg,
    normalizeHostedTextModel: normalizeHostedTextModel,
    normalizeHostedImageModel: normalizeHostedImageModel,
    applyModelFallbackFromResponse: applyModelFallbackFromResponse,
    syncModelDatalistTargets: syncModelDatalistTargets,
    unifiedApiSettingsUnavailable: unifiedApiSettingsUnavailable,
    openUnifiedApiSettings: openUnifiedApiSettings,
    renderResults: renderResults,
    renderSkuResults: renderSkuResults,
    renderSkuWorkspace: renderSkuWorkspace,
    addSkuProducts: addSkuProducts,
    skuAttributes: skuAttributes,
    skuPromptFor: skuPromptFor,
    selectedSkuTasks: selectedSkuTasks,
    generateSkuBatch: generateSkuBatch,
    retryFailedSkuTasks: retryFailedSkuTasks,
    stopSkuGeneration: stopSkuGeneration,
    applySkuQueryParams: applySkuQueryParams,
    renderDetailLongPreview: renderDetailLongPreview,
    openGeneratedImagePreview: openGeneratedImagePreview,
    closeGeneratedImagePreview: closeGeneratedImagePreview,
    bind: bind
  };
}

document.addEventListener('DOMContentLoaded', function () {
  var params = new URLSearchParams(location.search);
  var source = params.get('source') || '';
  var detailMode = params.get('detailMode') || (source === 'linkmatrix' ? 'link' : 'reference');
  var requestedMode = params.get('mode') || params.get('surface') || 'main';
  var sourceRequestsDetail = source === 'detail-plugin' || source === 'detail-reference' || source === 'detail-batch';
  var labMode = requestedMode === 'sku' ? 'sku' : (requestedMode === 'detail' || sourceRequestsDetail ? 'detail' : 'main');
  setupLabMode(labMode, detailMode);
  if (labMode === 'sku') applySkuQueryParams(params);
  bind();
  if (labMode === 'detail') syncDetailModeDefaultsAfterRestore();
  renderResults();
  renderSkuWorkspace();
  refreshBusinessKnowledgeStatus();
  loadContext(params.get('auto') === '1');
  if (labMode !== 'sku' && source === 'linkmatrix') loadStoredLinks();
});
