'use strict';

(function () {
  var KB = globalThis.SZBusinessKnowledge;
  var MAX_FILE_BYTES = 10 * 1024 * 1024;
  var MAX_TOTAL_BYTES = 30 * 1024 * 1024;
  var state = { record: KB ? KB.normalize({}) : {}, sources: [], accountKey: 'local', loading: false };
  var ids = [
    'accountState', 'saveState', 'sourceFiles', 'sourceList', 'sourceCount', 'kbName', 'kbEnabled',
    'scopeLink', 'scopeMain', 'scopeDetail', 'contextPreview', 'contextCount', 'saveBtn', 'exportBtn', 'clearBtn', 'hint',
    'fieldBrand', 'fieldCategory', 'fieldAudience', 'fieldScenarios', 'fieldBenefits', 'fieldDifferentiation',
    'fieldTone', 'fieldVisual', 'fieldCompliance'
  ];
  var el = ids.reduce(function (out, id) { out[id] = document.getElementById(id); return out; }, {});
  var fieldMap = {
    brand: 'fieldBrand', category: 'fieldCategory', audience: 'fieldAudience', scenarios: 'fieldScenarios',
    benefits: 'fieldBenefits', differentiation: 'fieldDifferentiation', tone: 'fieldTone', visual: 'fieldVisual',
    compliance: 'fieldCompliance'
  };

  function setState(text, kind) {
    if (!el.saveState) return;
    el.saveState.textContent = text;
    el.saveState.className = 'pill' + (kind ? ' ' + kind : '');
  }

  function send(type, payload) {
    return new Promise(function (resolve) {
      if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
        resolve(type === 'GET_BUSINESS_KNOWLEDGE'
          ? { ok: true, accountKey: 'local-preview', knowledge: {} }
          : { ok: false, error: '请在 Chrome 扩展页面中保存知识库' });
        return;
      }
      try {
        chrome.runtime.sendMessage(Object.assign({ type: type }, payload || {}), function (resp) {
          var error = chrome.runtime.lastError;
          resolve(error ? { ok: false, error: error.message } : (resp || { ok: false, error: '无响应' }));
        });
      } catch (error) {
        resolve({ ok: false, error: (error && error.message) || String(error) });
      }
    });
  }

  function readFileText(file) {
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onload = function () { resolve(String(reader.result || '')); };
      reader.onerror = function () { reject(reader.error || new Error('文件读取失败')); };
      reader.readAsText(file);
    });
  }

  function workbookText(file) {
    if (globalThis.LOCALTABLES && typeof globalThis.LOCALTABLES.extractWorkbookText === 'function') {
      return globalThis.LOCALTABLES.extractWorkbookText(file, { maxChars: KB.MAX_SOURCE_CHARS }).then(function (result) {
        if (result && result.truncated) el.hint.textContent = 'Excel内容超过知识库正文预算，已在安全解析后截取前12万字。';
        return result && result.text || '';
      });
    }
    return Promise.reject(new Error('Excel 安全解析组件未加载，请重载插件后再试'));
  }

  function parseFile(file) {
    if (!file || !file.size) return Promise.reject(new Error('空文件不能导入'));
    if (file.size > MAX_FILE_BYTES) return Promise.reject(new Error('单文件不能超过 10MB'));
    var ext = String(file && file.name || '').toLowerCase().split('.').pop();
    var parser = /^(xlsx|xls)$/.test(ext) ? workbookText(file) : readFileText(file);
    return parser.then(function (text) {
      text = KB.cleanText(text, KB.MAX_SOURCE_CHARS);
      if (!text) throw new Error('文件没有可读取文本');
      return {
        id: 'kb-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8),
        name: file.name || '未命名资料',
        type: file.type || ('application/' + ext),
        size: Number(file.size) || 0,
        chars: text.length,
        text: text
      };
    });
  }

  function renderSources() {
    el.sourceList.innerHTML = '';
    el.sourceCount.textContent = state.sources.length + ' / ' + KB.MAX_SOURCE_COUNT;
    if (!state.sources.length) {
      var empty = document.createElement('div');
      empty.className = 'empty';
      empty.textContent = '尚未导入资料';
      el.sourceList.appendChild(empty);
      return;
    }
    state.sources.forEach(function (source, idx) {
      var row = document.createElement('div'); row.className = 'source-row';
      var copy = document.createElement('div');
      var name = document.createElement('strong'); name.textContent = source.name;
      var meta = document.createElement('span'); meta.textContent = source.type + ' · ' + source.chars.toLocaleString() + ' 字';
      var chars = document.createElement('b'); chars.textContent = '#' + String(idx + 1).padStart(2, '0');
      var remove = document.createElement('button'); remove.type = 'button'; remove.textContent = '×'; remove.title = '移除资料';
      remove.addEventListener('click', function () { state.sources.splice(idx, 1); renderAll(); setState('有未保存修改', 'warn'); });
      copy.appendChild(name); copy.appendChild(meta); row.appendChild(copy); row.appendChild(chars); row.appendChild(remove);
      el.sourceList.appendChild(row);
    });
  }

  function recordFromForm() {
    var fields = {};
    Object.keys(fieldMap).forEach(function (key) { fields[key] = el[fieldMap[key]].value || ''; });
    return KB.normalize({
      name: el.kbName.value,
      enabled: el.kbEnabled.checked,
      updatedAt: state.record.updatedAt || 0,
      scopes: { link: el.scopeLink.checked, main: el.scopeMain.checked, detail: el.scopeDetail.checked },
      fields: fields,
      sources: state.sources
    });
  }

  function applyRecord(record) {
    record = KB.normalize(record);
    state.record = record;
    state.sources = record.sources.slice();
    el.kbName.value = record.name;
    el.kbEnabled.checked = record.enabled;
    el.scopeLink.checked = record.scopes.link;
    el.scopeMain.checked = record.scopes.main;
    el.scopeDetail.checked = record.scopes.detail;
    Object.keys(fieldMap).forEach(function (key) { el[fieldMap[key]].value = record.fields[key] || ''; });
    renderAll();
  }

  function renderPreview() {
    var record = recordFromForm();
    var scopes = [];
    if (record.scopes.link) scopes.push('链接定位');
    if (record.scopes.main) scopes.push('主图提示词');
    if (record.scopes.detail) scopes.push('详情页提示词');
    var context = KB.contextForScope(record, record.scopes.link ? 'link' : (record.scopes.main ? 'main' : 'detail'));
    el.contextPreview.textContent = context || '当前知识库未启用、未选择调用范围，或还没有有效内容。';
    el.contextCount.textContent = context.length.toLocaleString() + ' 字 · ' + (scopes.join(' / ') || '未调用');
  }

  function renderAll() { renderSources(); renderPreview(); }

  function loadCurrent() {
    setState('读取中…', '');
    return send('GET_BUSINESS_KNOWLEDGE').then(function (resp) {
      if (!resp || !resp.ok) throw new Error((resp && resp.error) || '知识库读取失败');
      state.accountKey = resp.accountKey || 'local';
      el.accountState.textContent = state.accountKey === 'local' ? '本机账号' : '当前登录账号';
      el.accountState.className = 'pill ok';
      applyRecord(resp.knowledge || {});
      var summary = KB.summary(resp.knowledge || {});
      setState(summary.ready ? ('已保存 · ' + summary.sourceCount + ' 份资料') : '等待导入', summary.ready ? 'ok' : '');
    }).catch(function (error) {
      el.accountState.textContent = '账号读取失败'; el.accountState.className = 'pill warn';
      setState((error && error.message) || String(error), 'warn');
    });
  }

  function saveCurrent() {
    var record = recordFromForm();
    if (!KB.hasContent(record)) { setState('请先导入资料或填写至少一项业务规则', 'warn'); return; }
    el.saveBtn.disabled = true; setState('保存中…', '');
    send('SAVE_BUSINESS_KNOWLEDGE', { knowledge: Object.assign({}, record, { updatedAt: Date.now() }) }).then(function (resp) {
      if (!resp || !resp.ok) throw new Error((resp && resp.error) || '保存失败');
      applyRecord(resp.knowledge || record);
      setState('已保存 · 三条链路可调用', 'ok');
    }).catch(function (error) {
      setState((error && error.message) || String(error), 'warn');
    }).finally(function () { el.saveBtn.disabled = false; });
  }

  function exportCurrent() {
    var record = recordFromForm();
    var blob = new Blob([JSON.stringify(record, null, 2)], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var link = document.createElement('a');
    link.href = url; link.download = '少壮AI业务知识库_' + new Date().toISOString().slice(0, 10) + '.json';
    document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(url);
    setState('已导出 JSON', 'ok');
  }

  function clearCurrent() {
    if (!confirm('确认清空当前账号的业务知识库吗？API配置、链接清单和图片不会被删除。')) return;
    el.clearBtn.disabled = true;
    send('CLEAR_BUSINESS_KNOWLEDGE').then(function (resp) {
      if (!resp || !resp.ok) throw new Error((resp && resp.error) || '清空失败');
      applyRecord({}); setState('已清空当前账号知识库', 'ok');
    }).catch(function (error) { setState((error && error.message) || String(error), 'warn'); })
      .finally(function () { el.clearBtn.disabled = false; });
  }

  el.sourceFiles.addEventListener('change', function (event) {
    var files = Array.prototype.slice.call((event.target && event.target.files) || []);
    var room = Math.max(0, KB.MAX_SOURCE_COUNT - state.sources.length);
    files = files.slice(0, room);
    if (!files.length) { setState(room ? '未选择文件' : '最多只能导入 8 份资料', 'warn'); return; }
    var existingBytes = state.sources.reduce(function (sum, source) { return sum + (Number(source.size) || 0); }, 0);
    var incomingBytes = files.reduce(function (sum, file) { return sum + (Number(file.size) || 0); }, 0);
    if (existingBytes + incomingBytes > MAX_TOTAL_BYTES) {
      setState('本次知识库原文件总量不能超过 30MB', 'warn');
      event.target.value = '';
      return;
    }
    setState('正在解析 ' + files.length + ' 份资料…', '');
    Promise.allSettled(files.map(parseFile)).then(function (results) {
      var added = 0, errors = [];
      results.forEach(function (result, idx) {
        if (result.status === 'fulfilled') { state.sources.push(result.value); added++; }
        else errors.push((files[idx] && files[idx].name || '文件') + '：' + ((result.reason && result.reason.message) || result.reason));
      });
      var beforeChars = state.sources.reduce(function (sum, source) { return sum + (source.chars || 0); }, 0);
      state.sources = KB.normalize({ sources: state.sources }).sources;
      var afterChars = state.sources.reduce(function (sum, source) { return sum + (source.chars || 0); }, 0);
      renderAll(); event.target.value = '';
      var truncated = beforeChars > afterChars;
      setState('已解析 ' + added + ' 份' + (errors.length ? '，失败 ' + errors.length + ' 份' : '') + (truncated ? '，正文已按12万字上限截取' : '') + ' · 请保存', (errors.length || truncated) ? 'warn' : 'ok');
      if (errors.length || truncated) el.hint.textContent = errors.concat(truncated ? ['知识库正文最多保留12万字；界面已明确标记本次截取。'] : []).join('；');
    });
  });

  Object.keys(fieldMap).forEach(function (key) { el[fieldMap[key]].addEventListener('input', function () { renderPreview(); setState('有未保存修改', 'warn'); }); });
  [el.kbName, el.kbEnabled, el.scopeLink, el.scopeMain, el.scopeDetail].forEach(function (control) {
    control.addEventListener('input', function () { renderPreview(); setState('有未保存修改', 'warn'); });
    control.addEventListener('change', function () { renderPreview(); setState('有未保存修改', 'warn'); });
  });
  el.saveBtn.addEventListener('click', saveCurrent);
  el.exportBtn.addEventListener('click', exportCurrent);
  el.clearBtn.addEventListener('click', clearCurrent);
  loadCurrent();
})();
