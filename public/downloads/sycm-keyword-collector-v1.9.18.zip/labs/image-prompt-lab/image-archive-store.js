/* image-archive-store.js — 生图结果本机留档、7天回收站与缺失清理 */
(function (root, factory) {
  var api = factory(root || {});
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.SZ_IMAGE_ARCHIVE = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (root) {
  'use strict';

  var DB_NAME = 'sz_image_archive_v1';
  var DB_VERSION = 1;
  var BATCH_STORE = 'batches';
  var ASSET_STORE = 'assets';
  var RETENTION_MS = 7 * 24 * 60 * 60 * 1000;
  var MAX_IMAGE_BYTES = 40 * 1024 * 1024;

  function text(value, max) {
    var out = String(value == null ? '' : value).trim();
    return max ? out.slice(0, max) : out;
  }

  function normalizeAccountKey(value) {
    return text(value, 140) || 'local';
  }

  function hashText(value) {
    var h = 2166136261;
    value = String(value || '');
    for (var i = 0; i < value.length; i++) h = Math.imul(h ^ value.charCodeAt(i), 16777619);
    return ('00000000' + (h >>> 0).toString(16)).slice(-8);
  }

  function allowedMime(value) {
    value = text(value, 80).toLowerCase().split(';')[0];
    if (value === 'image/jpg') value = 'image/jpeg';
    return /^(image\/png|image\/jpeg|image\/webp|image\/gif)$/.test(value) ? value : '';
  }

  function dataUrlToBlob(dataUrl) {
    var match = /^data:(image\/[a-z0-9.+-]+);base64,([\s\S]+)$/i.exec(String(dataUrl || ''));
    if (!match) return Promise.reject(new Error('不是可留档的图片数据'));
    var mime = allowedMime(match[1]);
    if (!mime) return Promise.reject(new Error('不支持的图片格式'));
    try {
      var binary = root.atob ? root.atob(match[2].replace(/\s+/g, '')) : Buffer.from(match[2], 'base64').toString('binary');
      if (binary.length > MAX_IMAGE_BYTES) return Promise.reject(new Error('单张留档图片不能超过40MB'));
      var bytes = new Uint8Array(binary.length);
      for (var i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      return Promise.resolve(new Blob([bytes], { type: mime }));
    } catch (error) {
      return Promise.reject(new Error('图片数据解码失败'));
    }
  }

  function validBlob(blob) {
    return !!(blob && typeof blob.size === 'number' && blob.size > 0 && blob.size <= MAX_IMAGE_BYTES && allowedMime(blob.type));
  }

  function sourceToBlob(source, fetcher) {
    if (validBlob(source)) return Promise.resolve(source);
    var value = String(source || '');
    if (/^data:image\//i.test(value)) return dataUrlToBlob(value);
    if (!/^(https?:|blob:)/i.test(value)) return Promise.reject(new Error('没有可留档的本机图片来源'));
    fetcher = fetcher || root.fetch;
    if (typeof fetcher !== 'function') return Promise.reject(new Error('当前环境无法读取图片文件'));
    return fetcher(value, { credentials: 'omit', referrerPolicy: 'no-referrer' }).then(function (response) {
      if (!response || !response.ok) throw new Error('图片文件读取失败');
      var declared = Number(response.headers && response.headers.get && response.headers.get('content-length')) || 0;
      if (declared > MAX_IMAGE_BYTES) throw new Error('单张留档图片不能超过40MB');
      return response.blob();
    }).then(function (blob) {
      if (!validBlob(blob)) throw new Error('返回内容不是有效图片或超过40MB');
      return blob;
    });
  }

  function openDb() {
    return new Promise(function (resolve, reject) {
      if (!root.indexedDB) { reject(new Error('当前环境不支持本机图片档案')); return; }
      var request = root.indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = function () {
        var db = request.result;
        var batches = db.objectStoreNames.contains(BATCH_STORE)
          ? request.transaction.objectStore(BATCH_STORE)
          : db.createObjectStore(BATCH_STORE, { keyPath: 'archiveBatchId' });
        if (!batches.indexNames.contains('accountKey')) batches.createIndex('accountKey', 'accountKey', { unique: false });
        if (!batches.indexNames.contains('updatedAt')) batches.createIndex('updatedAt', 'updatedAt', { unique: false });
        var assets = db.objectStoreNames.contains(ASSET_STORE)
          ? request.transaction.objectStore(ASSET_STORE)
          : db.createObjectStore(ASSET_STORE, { keyPath: 'archiveAssetId' });
        if (!assets.indexNames.contains('accountKey')) assets.createIndex('accountKey', 'accountKey', { unique: false });
        if (!assets.indexNames.contains('archiveBatchId')) assets.createIndex('archiveBatchId', 'archiveBatchId', { unique: false });
        if (!assets.indexNames.contains('purgeAt')) assets.createIndex('purgeAt', 'purgeAt', { unique: false });
      };
      request.onsuccess = function () { resolve(request.result); };
      request.onerror = function () { reject(request.error || new Error('无法打开本机图片档案')); };
    });
  }

  function transaction(storeNames, mode, task) {
    return openDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(storeNames, mode);
        var stores = {};
        storeNames.forEach(function (name) { stores[name] = tx.objectStore(name); });
        var result;
        var failed = false;
        function fail(error) {
          if (failed) return;
          failed = true;
          try { tx.abort(); } catch (_) {}
          reject(error || new Error('本机图片档案事务失败'));
        }
        try { result = task(stores, fail); }
        catch (error) { fail(error); }
        tx.oncomplete = function () { db.close(); if (!failed) resolve(typeof result === 'function' ? result() : result); };
        tx.onerror = function () { db.close(); fail(tx.error || new Error('本机图片档案事务失败')); };
        tx.onabort = function () { db.close(); if (!failed) fail(tx.error || new Error('本机图片档案事务已取消')); };
      });
    });
  }

  function sanitizeArchiveInput(raw) {
    raw = raw || {};
    var accountKey = normalizeAccountKey(raw.accountKey);
    var surfaceMode = ['main', 'detail', 'sku', 'viral'].indexOf(raw.surfaceMode) >= 0 ? raw.surfaceMode : 'main';
    var sourceBatchId = text(raw.sourceBatchId || raw.batchId || raw.jobId || raw.resultId, 220) || ('local_' + Date.now());
    var archiveBatchId = text(raw.archiveBatchId, 260) || ('archive_batch_' + hashText(accountKey + '|' + surfaceMode + '|' + sourceBatchId));
    var resultId = text(raw.resultId || raw.jobId, 260) || ('result_' + Date.now() + '_' + Math.random().toString(16).slice(2));
    var archiveAssetId = text(raw.archiveAssetId, 260) || ('archive_asset_' + hashText(accountKey + '|' + archiveBatchId + '|' + resultId));
    return {
      accountKey: accountKey,
      surfaceMode: surfaceMode,
      creativeRoute: text(raw.creativeRoute, 80),
      detailMode: text(raw.detailMode, 80),
      sourceBatchId: sourceBatchId,
      archiveBatchId: archiveBatchId,
      archiveAssetId: archiveAssetId,
      resultId: resultId,
      batchTitle: text(raw.batchTitle, 160) || '本机生图档案',
      linkId: text(raw.linkId, 40),
      skuId: text(raw.skuId, 120),
      skuCode: text(raw.skuCode, 80),
      variant: text(raw.variant, 100),
      variantName: text(raw.variantName, 180),
      imageIndex: Math.max(1, Number(raw.imageIndex) || 1),
      ratio: text(raw.ratio, 20),
      resolution: text(raw.resolution, 20),
      provider: text(raw.provider, 80),
      imageModel: text(raw.imageModel, 120),
      prompt: text(raw.prompt, 30000),
      negativePrompt: text(raw.negativePrompt, 8000),
      parentResultId: text(raw.parentResultId, 260),
      taskId: text(raw.taskId, 180),
      createdAt: Math.max(1, Number(raw.createdAt) || Date.now())
    };
  }

  function saveResult(raw, options) {
    options = options || {};
    var safe = sanitizeArchiveInput(raw);
    return sourceToBlob(raw && (raw.blob || raw.url), options.fetch).then(function (blob) {
      return transaction([BATCH_STORE, ASSET_STORE], 'readwrite', function (stores, fail) {
        var batchRequest = stores[BATCH_STORE].get(safe.archiveBatchId);
        batchRequest.onerror = function () { fail(batchRequest.error || new Error('读取档案批次失败')); };
        batchRequest.onsuccess = function () {
          var existing = batchRequest.result || {};
          stores[BATCH_STORE].put({
            archiveBatchId: safe.archiveBatchId,
            accountKey: safe.accountKey,
            surfaceMode: safe.surfaceMode,
            creativeRoute: safe.creativeRoute,
            detailMode: safe.detailMode,
            sourceBatchId: safe.sourceBatchId,
            batchTitle: existing.batchTitle || safe.batchTitle,
            linkId: existing.linkId || safe.linkId,
            skuId: existing.skuId || safe.skuId,
            provider: existing.provider || safe.provider,
            imageModel: existing.imageModel || safe.imageModel,
            ratio: existing.ratio || safe.ratio,
            resolution: existing.resolution || safe.resolution,
            createdAt: Number(existing.createdAt) || safe.createdAt,
            updatedAt: Date.now()
          });
          stores[ASSET_STORE].put(Object.assign({}, safe, {
            blob: blob,
            mimeType: allowedMime(blob.type),
            size: Number(blob.size) || 0,
            deletedAt: 0,
            purgeAt: 0,
            updatedAt: Date.now()
          }));
        };
        return function () { return Object.assign({}, safe, { size: blob.size, mimeType: blob.type }); };
      });
    });
  }

  function recordsForAccount(accountKey) {
    var output = { batches: [], assets: [] };
    return transaction([BATCH_STORE, ASSET_STORE], 'readonly', function (stores, fail) {
      var batchRequest = stores[BATCH_STORE].index('accountKey').getAll(accountKey);
      var assetRequest = stores[ASSET_STORE].index('accountKey').getAll(accountKey);
      batchRequest.onsuccess = function () { output.batches = batchRequest.result || []; };
      assetRequest.onsuccess = function () { output.assets = assetRequest.result || []; };
      batchRequest.onerror = function () { fail(batchRequest.error || new Error('读取档案批次失败')); };
      assetRequest.onerror = function () { fail(assetRequest.error || new Error('读取档案图片失败')); };
      return function () { return output; };
    });
  }

  function permanentlyRemove(accountKey, assetIds) {
    accountKey = normalizeAccountKey(accountKey);
    var selected = {};
    (assetIds || []).forEach(function (id) { if (id) selected[String(id)] = true; });
    if (!Object.keys(selected).length) return Promise.resolve({ removed: 0 });
    var removed = 0;
    return transaction([ASSET_STORE], 'readwrite', function (stores, fail) {
      Object.keys(selected).forEach(function (id) {
        var request = stores[ASSET_STORE].get(id);
        request.onerror = function () { fail(request.error || new Error('读取待删除档案失败')); };
        request.onsuccess = function () {
          var record = request.result;
          if (!record || normalizeAccountKey(record.accountKey) !== accountKey) return;
          stores[ASSET_STORE].delete(id);
          removed++;
        };
      });
      return function () { return { removed: removed }; };
    }).then(function (result) {
      return removeEmptyBatches(accountKey).then(function () { return result; });
    });
  }

  function removeEmptyBatches(accountKey) {
    accountKey = normalizeAccountKey(accountKey);
    return recordsForAccount(accountKey).then(function (records) {
      var occupied = {};
      records.assets.forEach(function (asset) { occupied[asset.archiveBatchId] = true; });
      var empty = records.batches.filter(function (batch) { return !occupied[batch.archiveBatchId]; });
      if (!empty.length) return { removed: 0 };
      return transaction([BATCH_STORE], 'readwrite', function (stores) {
        empty.forEach(function (batch) { stores[BATCH_STORE].delete(batch.archiveBatchId); });
        return { removed: empty.length };
      });
    });
  }

  function mutateTrash(accountKey, assetIds, deleted) {
    accountKey = normalizeAccountKey(accountKey);
    var selected = {};
    (assetIds || []).forEach(function (id) { if (id) selected[String(id)] = true; });
    var changed = 0;
    var now = Date.now();
    return transaction([ASSET_STORE], 'readwrite', function (stores, fail) {
      Object.keys(selected).forEach(function (id) {
        var request = stores[ASSET_STORE].get(id);
        request.onerror = function () { fail(request.error || new Error('读取回收站档案失败')); };
        request.onsuccess = function () {
          var record = request.result;
          if (!record || normalizeAccountKey(record.accountKey) !== accountKey) return;
          record.deletedAt = deleted ? now : 0;
          record.purgeAt = deleted ? (now + RETENTION_MS) : 0;
          record.updatedAt = now;
          stores[ASSET_STORE].put(record);
          changed++;
        };
      });
      return function () { return { changed: changed, deleted: !!deleted, purgeAt: deleted ? now + RETENTION_MS : 0 }; };
    });
  }

  function moveToTrash(accountKey, assetIds) { return mutateTrash(accountKey, assetIds, true); }
  function restore(accountKey, assetIds) { return mutateTrash(accountKey, assetIds, false); }

  function purgeExpired(accountKey, now) {
    accountKey = normalizeAccountKey(accountKey);
    now = Number(now) || Date.now();
    return recordsForAccount(accountKey).then(function (records) {
      var expired = records.assets.filter(function (asset) {
        return Number(asset.deletedAt) > 0 && Number(asset.purgeAt) > 0 && Number(asset.purgeAt) <= now;
      }).map(function (asset) { return asset.archiveAssetId; });
      return permanentlyRemove(accountKey, expired).then(function () { return { removed: expired.length }; });
    });
  }

  function purgeAllExpired(now) {
    now = Number(now) || Date.now();
    var accountKeys = {};
    var removed = 0;
    return transaction([ASSET_STORE], 'readwrite', function (stores, fail) {
      var request = stores[ASSET_STORE].getAll();
      request.onerror = function () { fail(request.error || new Error('读取超期档案失败')); };
      request.onsuccess = function () {
        (request.result || []).forEach(function (asset) {
          if (!(Number(asset.deletedAt) > 0 && Number(asset.purgeAt) > 0 && Number(asset.purgeAt) <= now)) return;
          stores[ASSET_STORE].delete(asset.archiveAssetId);
          accountKeys[normalizeAccountKey(asset.accountKey)] = true;
          removed++;
        });
      };
      return function () { return { removed: removed, accountKeys: Object.keys(accountKeys) }; };
    }).then(function (result) {
      return Promise.all(result.accountKeys.map(removeEmptyBatches)).then(function () { return { removed: result.removed }; });
    });
  }

  function list(accountKey, options) {
    accountKey = normalizeAccountKey(accountKey);
    options = options || {};
    var ready = options.skipPurge ? Promise.resolve({ removed: 0 }) : purgeExpired(accountKey, options.now);
    return ready.then(function () {
      return recordsForAccount(accountKey);
    }).then(function (records) {
      var missing = [];
      var byBatch = {};
      records.assets.forEach(function (asset) {
        if (!validBlob(asset.blob)) { missing.push(asset.archiveAssetId); return; }
        var trashed = Number(asset.deletedAt) > 0;
        if (!!options.trash !== trashed) return;
        if (!byBatch[asset.archiveBatchId]) byBatch[asset.archiveBatchId] = [];
        byBatch[asset.archiveBatchId].push(asset);
      });
      var batches = records.batches.filter(function (batch) { return byBatch[batch.archiveBatchId] && byBatch[batch.archiveBatchId].length; });
      batches.forEach(function (batch) {
        batch.assets = byBatch[batch.archiveBatchId].sort(function (a, b) { return Number(a.imageIndex) - Number(b.imageIndex) || Number(a.createdAt) - Number(b.createdAt); });
        batch.assetCount = batch.assets.length;
        batch.totalBytes = batch.assets.reduce(function (sum, asset) { return sum + (Number(asset.size) || 0); }, 0);
      });
      batches.sort(function (a, b) { return Number(b.updatedAt) - Number(a.updatedAt); });
      var cleanup = missing.length ? permanentlyRemove(accountKey, missing) : Promise.resolve({ removed: 0 });
      return cleanup.then(function () { return batches; });
    });
  }

  function summary(accountKey) {
    return Promise.all([list(accountKey, { trash: false }), list(accountKey, { trash: true })]).then(function (parts) {
      var active = parts[0], trash = parts[1];
      return {
        activeBatches: active.length,
        activeAssets: active.reduce(function (sum, batch) { return sum + batch.assets.length; }, 0),
        trashAssets: trash.reduce(function (sum, batch) { return sum + batch.assets.length; }, 0),
        bytes: active.concat(trash).reduce(function (sum, batch) { return sum + batch.totalBytes; }, 0)
      };
    });
  }

  return Object.freeze({
    DB_NAME: DB_NAME,
    RETENTION_MS: RETENTION_MS,
    normalizeAccountKey: normalizeAccountKey,
    sanitizeArchiveInput: sanitizeArchiveInput,
    dataUrlToBlob: dataUrlToBlob,
    sourceToBlob: sourceToBlob,
    saveResult: saveResult,
    list: list,
    summary: summary,
    moveToTrash: moveToTrash,
    restore: restore,
    permanentlyRemove: permanentlyRemove,
    purgeExpired: purgeExpired,
    purgeAllExpired: purgeAllExpired
  });
});
