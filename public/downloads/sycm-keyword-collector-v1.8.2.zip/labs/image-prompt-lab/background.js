'use strict';

var CONFIG_KEY = 'sz_image_prompt_lab_config';
var CONTEXT_KEY = 'sz_image_prompt_lab_context';
var LAB_PAGE = ((chrome.runtime.getManifest().name || '').indexOf('少壮AI自动化') >= 0)
  ? 'labs/image-prompt-lab/promptlab.html'
  : 'promptlab.html';
var CONTEXT_CARD_SCRIPT = ((chrome.runtime.getManifest().name || '').indexOf('少壮AI自动化') >= 0)
  ? 'labs/image-prompt-lab/context-card.js'
  : 'context-card.js';
var VOLC_SEEDREAM_DEFAULT = 'doubao-seedream-5-0-260128';
var DEFAULT_CFG = {
  provider: 'dashscope',
  imageAdapter: 'dashscope-wan',
  visionBaseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
  visionModel: 'qwen-vl-plus',
  textModel: 'qwen-plus',
  imageEndpoint: 'https://dashscope.aliyuncs.com/api/v1/services/aigc/image-generation/generation',
  imageModel: 'wan2.7-image',
  apiKey: ''
};
var activeJobs = {};

function signalForPayload(payload) {
  var jobId = payload && payload._jobId;
  return jobId && activeJobs[jobId] ? activeJobs[jobId].signal : null;
}

chrome.runtime.onInstalled.addListener(function () {
  chrome.contextMenus.removeAll(function () {
    chrome.contextMenus.create({
      id: 'sz-analyze-image',
      title: '少壮AI：用此图片生成提示词',
      contexts: ['image']
    });
  });
});

chrome.action.onClicked.addListener(function () {
  chrome.tabs.create({ url: chrome.runtime.getURL(LAB_PAGE) });
});

chrome.contextMenus.onClicked.addListener(function (info, tab) {
  if (info.menuItemId !== 'sz-analyze-image') return;
  var payload = {
    imageUrl: info.srcUrl || '',
    pageUrl: info.pageUrl || (tab && tab.url) || '',
    title: tab && tab.title || '',
    at: Date.now()
  };
  showInlineContextCard(tab && tab.id, payload);
});

function openContextWorkbench(payload) {
  var o = {}; o[CONTEXT_KEY] = payload;
  chrome.storage.local.set(o, function () {
    chrome.tabs.create({ url: chrome.runtime.getURL(LAB_PAGE) + '?source=context&auto=1' });
  });
}

function showInlineContextCard(tabId, payload) {
  if (tabId == null) {
    openContextWorkbench(payload);
    return;
  }
  try {
    chrome.scripting.executeScript({
      target: { tabId: tabId, allFrames: false },
      files: [CONTEXT_CARD_SCRIPT]
    }, function () {
      if (chrome.runtime.lastError) {
        console.warn('context card inject failed:', chrome.runtime.lastError.message);
        return;
      }
      chrome.tabs.sendMessage(tabId, { type: 'SZ_CONTEXT_IMAGE_ACTION', payload: payload }, function () {
        var _ = chrome.runtime.lastError;
      });
    });
  } catch (e) {
    console.warn('context card unavailable:', e && e.message ? e.message : e);
  }
}

function endpoint(baseURL, suffix) {
  var b = (baseURL || DEFAULT_CFG.visionBaseUrl).replace(/\/+$/, '');
  if (/\/chat\/completions$/.test(b)) return b;
  return b + suffix;
}

function textJsonPrompt(link) {
  return '你是资深天猫淘宝主图创意总监。根据链接清单 JSON，为这条链接生成电商主图提示词方案。\n' +
    '要求：1) 不照抄任何竞品品牌、商标、包装版式；2) 要服务链接定位和转化，不做泛泛的艺术图；3) 输出中英文提示词；4) 保留产品真实外观和卖点；5) 给出可直接用于生图模型的负面提示词。\n' +
    '只输出 JSON：{"主图方向":"","画面布局":"","中文提示词":"","English Prompt":"","负面提示词":"","主图文案":"","4方向":["主图转化版","场景种草版","视觉锤版","竞品差异化版"]}。\n' +
    '链接清单 JSON：' + JSON.stringify(link);
}

function analyzeImagePrompt(linkHint) {
  return '你是电商图片提示词分析器。分析输入图片，提取适合电商生图复用的视觉提示词，但禁止复刻品牌、商标、包装文字、人物肖像身份。\n' +
    '请重点识别：主体、品类、构图、镜头、光线、色彩、场景、材质、背景、文案区域、风格、可借鉴点、必须避让点。\n' +
    '如果有链接定位，请把视觉表达向链接定位靠拢。链接定位：' + (linkHint || '无') + '\n' +
    '只输出 JSON：{"主体":"","品类":"","构图":"","镜头":"","光线":"","色彩":"","场景":"","材质":"","背景":"","风格":"","可借鉴点":"","避让点":"","中文提示词":"","English Prompt":"","负面提示词":""}。';
}

function buildVisionMessages(image, linkHint) {
  return [
    { role: 'system', content: '你只输出合法 JSON，不输出 markdown。' },
    {
      role: 'user',
      content: [
        { type: 'text', text: analyzeImagePrompt(linkHint) },
        { type: 'image_url', image_url: { url: image } }
      ]
    }
  ];
}

function cleanJson(content) {
  if (!content) return null;
  if (typeof content === 'object') return content;
  try { return JSON.parse(content); } catch (e) {}
  var m = ('' + content).match(/\{[\s\S]*\}/);
  if (m) { try { return JSON.parse(m[0]); } catch (e2) {} }
  return null;
}

function chatJson(cfg, messages, model, temperature, timeoutMs) {
  return new Promise(function (resolve) {
    cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
    if (cfg.provider === 'nano-banana' || cfg.imageAdapter === 'nano-banana' || cfg.imageAdapter === 'gemini-image') {
      geminiJson(cfg, messages, model, timeoutMs).then(resolve);
      return;
    }
    if (!cfg.apiKey) { resolve({ ok: false, error: '未配置 API Key' }); return; }
    var url = endpoint(cfg.visionBaseUrl, '/chat/completions');
    var body = {
      model: model || cfg.visionModel || DEFAULT_CFG.visionModel,
      messages: messages,
      temperature: temperature == null ? 0.2 : temperature
    };
    if (!/^https:\/\/ark\.cn-beijing\.volces\.com/.test(url)) {
      body.response_format = { type: 'json_object' };
    }
    var ctrl = new AbortController();
    var waitMs = timeoutMs || 180000;
    var to = setTimeout(function () { try { ctrl.abort(); } catch (e) {} }, waitMs);
    fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + cfg.apiKey },
      body: JSON.stringify(body),
      signal: ctrl.signal
    }).then(function (r) {
      return r.text().then(function (txt) { return { status: r.status, txt: txt }; });
    }).then(function (resp) {
      clearTimeout(to);
      if (resp.status < 200 || resp.status >= 300) {
        resolve({ ok: false, error: 'HTTP ' + resp.status + ': ' + (resp.txt || '').slice(0, 260) });
        return;
      }
      var data; try { data = JSON.parse(resp.txt); } catch (e) { resolve({ ok: false, error: '模型返回不是 JSON' }); return; }
      var content = data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
      var obj = cleanJson(content);
      if (!obj) { resolve({ ok: false, error: '解析模型 JSON 失败' }); return; }
      resolve({ ok: true, data: obj, raw: content });
    }).catch(function (e) {
      clearTimeout(to);
      resolve({ ok: false, error: (e && e.name === 'AbortError') ? ('请求超时（已等待 ' + Math.round(waitMs / 1000) + ' 秒）') : ('网络错误：' + ((e && e.message) || e)) });
    });
  });
}

function geminiPartsFromMessages(messages) {
  var parts = [];
  (messages || []).forEach(function (msg) {
    if (!msg || msg.role === 'system') return;
    if (typeof msg.content === 'string') {
      parts.push({ text: msg.content });
    } else if (Array.isArray(msg.content)) {
      msg.content.forEach(function (it) {
        if (!it) return;
        if (it.type === 'text') parts.push({ text: it.text || '' });
        if (it.type === 'image_url' && it.image_url && it.image_url.url) parts.push(imagePartForGemini(it.image_url.url));
      });
    }
  });
  parts.push({ text: '\n只输出合法 JSON，不要 markdown。' });
  return parts;
}

function geminiJson(cfg, messages, model, timeoutMs) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  if (!cfg.apiKey) return Promise.resolve({ ok: false, error: '未配置 API Key' });
  var oldModel = cfg.imageModel;
  cfg.imageModel = model || cfg.visionModel || cfg.textModel || cfg.imageModel || 'gemini-2.5-flash-image-preview';
  var body = { contents: [{ role: 'user', parts: geminiPartsFromMessages(messages) }] };
  var url = geminiUrl(cfg);
  cfg.imageModel = oldModel;
  return fetchJson(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }, timeoutMs || 120000)
    .then(function (res) {
      if (!res.ok) return res;
      var text = '';
      try {
        var parts = (((res.data || {}).candidates || [])[0] || {}).content.parts || [];
        parts.forEach(function (p) { if (p.text) text += p.text; });
      } catch (e) {}
      var obj = cleanJson(text);
      return obj ? { ok: true, data: obj, raw: text || res.data } : { ok: false, error: '解析 Gemini JSON 失败', raw: res.data };
    });
}

function analyzeImage(cfg, payload) {
  if (!payload || !payload.image) return Promise.resolve({ ok: false, error: '缺少图片' });
  if (cfg && cfg.provider === 'deepseek-v4') return Promise.resolve({ ok: false, error: 'DeepSeek V4 当前作为文本提词模型接入，不支持图片反推。请切换到千问/豆包/智谱/OpenAI/Nano Banana 等视觉模型。' });
  return chatJson(cfg, buildVisionMessages(payload.image, payload.linkHint || ''), (cfg && cfg.visionModel) || DEFAULT_CFG.visionModel, 0.1, 300000);
}

function buildLinkPrompt(cfg, payload) {
  var link = payload && payload.link;
  if (!link || typeof link !== 'object') return Promise.resolve({ ok: false, error: '链接清单 JSON 无效' });
  var messages = [
    { role: 'system', content: '你只输出合法 JSON，不输出 markdown。' },
    { role: 'user', content: textJsonPrompt(link) }
  ];
  return chatJson(cfg, messages, (cfg && (cfg.textModel || cfg.visionModel)) || DEFAULT_CFG.textModel, 0.35, 240000);
}

function claritySuffix(clarity) {
  if (clarity === 'commercial') return ' commercial product photography, high clarity, clean details, sharp edges, premium studio lighting';
  if (clarity === 'high') return ' high definition, crisp details, clean edges, realistic texture';
  return ' clean product image, balanced lighting';
}

function normalizeSize(size, sep) {
  var s = (size || '1024*1024').replace(/\s+/g, '');
  var m = s.match(/^(\d+)[x*](\d+)$/i);
  if (!m) return sep === 'x' ? '1024x1024' : '1024*1024';
  return m[1] + (sep || '*') + m[2];
}

function normalizeVolcSeedreamSize(size) {
  var s = (size || '2048x2048').replace(/\s+/g, '');
  if (/^(2K|3K)$/i.test(s)) return s.toUpperCase();
  var m = s.match(/^(\d+)[x*](\d+)$/i);
  var w = m ? parseInt(m[1], 10) : 2048;
  var h = m ? parseInt(m[2], 10) : 2048;
  var presets = [
    [2048, 2048], [2304, 1728], [1728, 2304], [2848, 1600],
    [1600, 2848], [2496, 1664], [1664, 2496], [3136, 1344],
    [3072, 3072], [3456, 2592], [2592, 3456], [4096, 2304],
    [2304, 4096], [2496, 3744], [3744, 2496], [4704, 2016]
  ];
  var ratio = w / h;
  var best = presets.slice().sort(function (a, b) {
    var da = Math.abs(Math.log(ratio / (a[0] / a[1])));
    var db = Math.abs(Math.log(ratio / (b[0] / b[1])));
    if (Math.abs(da - db) > 0.0001) return da - db;
    return (a[0] * a[1]) - (b[0] * b[1]);
  })[0];
  return best[0] + 'x' + best[1];
}

function isDataUrl(s) { return /^data:image\/[a-z0-9.+-]+;base64,/i.test('' + (s || '')); }
function dataUrlInfo(dataUrl) {
  var m = /^data:(image\/[a-z0-9.+-]+);base64,([\s\S]+)$/i.exec(dataUrl || '');
  return m ? { mime: m[1], base64: m[2] } : null;
}
function blobFromDataUrl(dataUrl) {
  var info = dataUrlInfo(dataUrl);
  if (!info) return null;
  var bin = atob(info.base64);
  var bytes = new Uint8Array(bin.length);
  for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type: info.mime });
}
function imagePartForGemini(image) {
  var info = dataUrlInfo(image);
  if (info) return { inline_data: { mime_type: info.mime, data: info.base64 } };
  return { file_data: { file_uri: image } };
}
function imageToProviderValue(image) {
  if (!image) return '';
  return image;
}

function productImagesFromPayload(payload) {
  payload = payload || {};
  var imgs = [];
  if (Array.isArray(payload.productImages)) imgs = imgs.concat(payload.productImages);
  if (payload.productImage) imgs.unshift(payload.productImage);
  return Array.from(new Set(imgs.filter(Boolean)));
}

function inputImagesFromPayload(payload) {
  payload = payload || {};
  var imgs = productImagesFromPayload(payload);
  if (payload.referenceImage) imgs.push(payload.referenceImage);
  return Array.from(new Set(imgs.filter(Boolean)));
}

function generationPayload(cfg, payload) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  payload = payload || {};
  var prompt = (payload.prompt || '').trim();
  if (payload.negativePrompt) prompt += '\nNegative prompt: ' + payload.negativePrompt;
  prompt += claritySuffix(payload.clarity || 'standard');
  var content = [];
  productImagesFromPayload(payload).forEach(function (img) { content.push({ image: img }); });
  if (payload.referenceImage) content.push({ image: payload.referenceImage });
  content.push({ text: prompt });
  return {
    model: cfg.imageModel || DEFAULT_CFG.imageModel,
    input: { messages: [{ role: 'user', content: content }] },
    parameters: {
      size: payload.size || '1024*1024',
      n: Math.max(1, Math.min(4, parseInt(payload.count, 10) || 1)),
      watermark: payload.watermark === true || payload.watermark === 'true',
      prompt_extend: true
    }
  };
}

function taskUrlFrom(endpointUrl, taskId) {
  try {
    var u = new URL(endpointUrl || DEFAULT_CFG.imageEndpoint);
    return u.origin + '/api/v1/tasks/' + encodeURIComponent(taskId);
  } catch (e) {
    return 'https://dashscope.aliyuncs.com/api/v1/tasks/' + encodeURIComponent(taskId);
  }
}

function deepFindImages(value, out) {
  out = out || [];
  if (!value) return out;
  if (typeof value === 'string') {
    if (/^https?:\/\//.test(value) && /\.(png|jpe?g|webp|gif)(\?|$)/i.test(value)) out.push(value);
    return out;
  }
  if (Array.isArray(value)) {
    value.forEach(function (v) { deepFindImages(v, out); });
    return out;
  }
  if (typeof value === 'object') {
    ['url', 'image', 'image_url', 'orig_url', 'actual_image_url'].forEach(function (k) {
      if (typeof value[k] === 'string' && /^https?:\/\//.test(value[k])) out.push(value[k]);
    });
    Object.keys(value).forEach(function (k) { deepFindImages(value[k], out); });
  }
  return Array.from(new Set(out));
}

function deepFindBase64Images(value, out) {
  out = out || [];
  if (!value) return out;
  if (Array.isArray(value)) {
    value.forEach(function (v) { deepFindBase64Images(v, out); });
    return out;
  }
  if (typeof value === 'object') {
    var mime = value.mime_type || value.mimeType || value.media_type || 'image/png';
    var data = value.b64_json || value.base64 || value.data;
    if (typeof data === 'string' && data.length > 200 && /^[A-Za-z0-9+/=\s]+$/.test(data)) {
      out.push('data:' + mime + ';base64,' + data.replace(/\s+/g, ''));
    }
    var inlineData = value.inlineData || value.inline_data;
    if (inlineData && inlineData.data) {
      out.push('data:' + (inlineData.mimeType || inlineData.mime_type || 'image/png') + ';base64,' + inlineData.data);
    }
    Object.keys(value).forEach(function (k) { deepFindBase64Images(value[k], out); });
  }
  return Array.from(new Set(out));
}

function parseImageResponse(data) {
  var imgs = [];
  if (data && Array.isArray(data.data)) {
    data.data.forEach(function (it) {
      if (it && it.url) imgs.push(it.url);
      if (it && it.b64_json) imgs.push('data:image/png;base64,' + it.b64_json);
    });
  }
  imgs = imgs.concat(deepFindImages(data), deepFindBase64Images(data));
  return Array.from(new Set(imgs));
}

function fetchJson(url, opt, timeoutMs) {
  return new Promise(function (resolve) {
    var ctrl = new AbortController();
    var externalSignal = opt && opt.signal;
    var abortedByExternal = false;
    if (externalSignal) {
      if (externalSignal.aborted) {
        resolve({ ok: false, error: '请求已终止' });
        return;
      }
      externalSignal.addEventListener('abort', function () {
        abortedByExternal = true;
        try { ctrl.abort(); } catch (e) {}
      }, { once: true });
    }
    var to = setTimeout(function () { try { ctrl.abort(); } catch (e) {} }, timeoutMs || 120000);
    opt = opt || {};
    opt.signal = ctrl.signal;
    fetch(url, opt).then(function (r) {
      return r.text().then(function (txt) { return { status: r.status, txt: txt }; });
    }).then(function (resp) {
      clearTimeout(to);
      if (resp.status < 200 || resp.status >= 300) {
        resolve({ ok: false, error: 'HTTP ' + resp.status + ': ' + (resp.txt || '').slice(0, 420) });
        return;
      }
      var data; try { data = JSON.parse(resp.txt); } catch (e) { resolve({ ok: false, error: '返回非 JSON' }); return; }
      resolve({ ok: true, data: data });
    }).catch(function (e) {
      clearTimeout(to);
      resolve({ ok: false, error: (e && e.name === 'AbortError') ? (abortedByExternal ? '请求已终止' : '请求超时') : ('网络错误：' + ((e && e.message) || e)) });
    });
  });
}

function createDashScopeImageTask(cfg, payload) {
  return new Promise(function (resolve) {
    cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
    if (!cfg.apiKey) { resolve({ ok: false, error: '未配置 API Key' }); return; }
    if (!payload || !payload.prompt) { resolve({ ok: false, error: '缺少生图提示词' }); return; }
    var url = cfg.imageEndpoint || DEFAULT_CFG.imageEndpoint;
    var body = generationPayload(cfg, payload);
    var ctrl = new AbortController();
    var externalSignal = signalForPayload(payload);
    var abortedByExternal = false;
    if (externalSignal) {
      if (externalSignal.aborted) { resolve({ ok: false, error: '请求已终止' }); return; }
      externalSignal.addEventListener('abort', function () {
        abortedByExternal = true;
        try { ctrl.abort(); } catch (e) {}
      }, { once: true });
    }
    var to = setTimeout(function () { try { ctrl.abort(); } catch (e) {} }, 60000);
    fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + cfg.apiKey,
        'X-DashScope-Async': 'enable'
      },
      body: JSON.stringify(body),
      signal: ctrl.signal
    }).then(function (r) {
      return r.text().then(function (txt) { return { status: r.status, txt: txt }; });
    }).then(function (resp) {
      clearTimeout(to);
      if (resp.status < 200 || resp.status >= 300) {
        resolve({ ok: false, error: 'HTTP ' + resp.status + ': ' + (resp.txt || '').slice(0, 320) });
        return;
      }
      var data; try { data = JSON.parse(resp.txt); } catch (e) { resolve({ ok: false, error: '创建任务返回非 JSON' }); return; }
      var taskId = data && data.output && data.output.task_id;
      if (!taskId) {
        var imgs = deepFindImages(data);
        if (imgs.length) resolve({ ok: true, taskId: '', images: imgs, raw: data });
        else resolve({ ok: false, error: '未拿到 task_id', raw: data });
        return;
      }
      pollImageTask(cfg, url, taskId, 0, externalSignal).then(function (res) { resolve(res); });
    }).catch(function (e) {
      clearTimeout(to);
      resolve({ ok: false, error: (e && e.name === 'AbortError') ? (abortedByExternal ? '请求已终止' : '创建任务超时') : ('网络错误：' + ((e && e.message) || e)) });
    });
  });
}

function createOpenAIImage(cfg, payload) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  payload = payload || {};
  if (!cfg.apiKey) return Promise.resolve({ ok: false, error: '未配置 API Key' });
  var prompt = ((payload.prompt || '') + claritySuffix(payload.clarity || 'standard')).trim();
  if (payload.negativePrompt) prompt += '\nAvoid: ' + payload.negativePrompt;
  var productImages = productImagesFromPayload(payload);
  var hasInputImage = !!(payload.referenceImage || productImages.length);
  var base = (cfg.imageEndpoint || 'https://api.openai.com/v1/images/generations').replace(/\/+$/, '');
  var url = hasInputImage ? base.replace(/\/images\/generations$/, '/images/edits') : base;
  if (hasInputImage) {
    var fd = new FormData();
    fd.append('model', cfg.imageModel || 'gpt-image-2');
    fd.append('prompt', prompt);
    fd.append('size', normalizeSize(payload.size, 'x'));
    fd.append('n', '' + Math.max(1, Math.min(4, parseInt(payload.count, 10) || 1)));
    var appended = 0;
    productImages.map(function (img, idx) {
      return { image: img, name: 'product-subject-' + (idx + 1) };
    }).concat(payload.referenceImage ? [{ image: payload.referenceImage, name: 'style-reference' }] : []).forEach(function (entry) {
      var blob = isDataUrl(entry.image) ? blobFromDataUrl(entry.image) : null;
      if (blob) {
        fd.append(appended === 0 ? 'image' : 'image[]', blob, entry.name + '.png');
        appended++;
      }
    });
    if (!appended) {
      return Promise.resolve({ ok: false, error: 'OpenAI 编辑接口需要本地上传图片或可转成 Blob 的 data URL；网页 URL 请先右键导入。' });
    }
    return fetchJson(url, { method: 'POST', headers: { 'Authorization': 'Bearer ' + cfg.apiKey }, body: fd, signal: signalForPayload(payload) }, 180000)
      .then(function (res) { if (!res.ok) return res; var imgs = parseImageResponse(res.data); return imgs.length ? { ok: true, images: imgs, raw: res.data } : { ok: false, error: '未解析到图片', raw: res.data }; });
  }
  var body = { model: cfg.imageModel || 'gpt-image-2', prompt: prompt, size: normalizeSize(payload.size, 'x'), n: Math.max(1, Math.min(4, parseInt(payload.count, 10) || 1)) };
  return fetchJson(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + cfg.apiKey }, body: JSON.stringify(body), signal: signalForPayload(payload) }, 180000)
    .then(function (res) { if (!res.ok) return res; var imgs = parseImageResponse(res.data); return imgs.length ? { ok: true, images: imgs, raw: res.data } : { ok: false, error: '未解析到图片', raw: res.data }; });
}

function createMiniMaxImage(cfg, payload) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  payload = payload || {};
  if (!cfg.apiKey) return Promise.resolve({ ok: false, error: '未配置 API Key' });
  var prompt = ((payload.prompt || '') + claritySuffix(payload.clarity || 'standard')).trim();
  if (payload.negativePrompt) prompt += '\nNegative prompt: ' + payload.negativePrompt;
  var refs = inputImagesFromPayload(payload).slice(0, 4).map(function (img) {
    return { type: 'general', image_file: imageToProviderValue(img) };
  });
  var body = {
    model: cfg.imageModel || 'image-01',
    prompt: prompt,
    n: Math.max(1, Math.min(4, parseInt(payload.count, 10) || 1)),
    response_format: 'url',
    prompt_optimizer: true
  };
  if (refs.length) body.subject_reference = refs;
  return fetchJson(cfg.imageEndpoint || 'https://api.minimax.io/v1/image_generation', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + cfg.apiKey },
    body: JSON.stringify(body),
    signal: signalForPayload(payload)
  }, 180000).then(function (res) {
    if (!res.ok) return res;
    var imgs = parseImageResponse(res.data);
    return imgs.length ? { ok: true, images: imgs, raw: res.data } : { ok: false, error: '未解析到 MiniMax 图片', raw: res.data };
  });
}

function createZhipuImage(cfg, payload) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  payload = payload || {};
  if (!cfg.apiKey) return Promise.resolve({ ok: false, error: '未配置 API Key' });
  var prompt = ((payload.prompt || '') + claritySuffix(payload.clarity || 'standard')).trim();
  if (payload.negativePrompt) prompt += '\n负面约束：' + payload.negativePrompt;
  var body = {
    model: cfg.imageModel || 'cogview-4-250304',
    prompt: prompt,
    size: normalizeSize(payload.size, 'x'),
    n: Math.max(1, Math.min(4, parseInt(payload.count, 10) || 1))
  };
  return fetchJson(cfg.imageEndpoint || 'https://open.bigmodel.cn/api/paas/v4/images/generations', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + cfg.apiKey },
    body: JSON.stringify(body),
    signal: signalForPayload(payload)
  }, 180000).then(function (res) {
    if (!res.ok) return res;
    var imgs = parseImageResponse(res.data);
    return imgs.length ? { ok: true, images: imgs, raw: res.data } : { ok: false, error: '未解析到智谱图片', raw: res.data };
  });
}

function createVolcengineImage(cfg, payload) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  payload = payload || {};
  if (!cfg.apiKey) return Promise.resolve({ ok: false, error: '未配置 API Key' });
  var prompt = ((payload.prompt || '') + claritySuffix(payload.clarity || 'standard')).trim();
  if (payload.negativePrompt) prompt += '\nNegative prompt: ' + payload.negativePrompt;
  var body = {
    model: cfg.imageModel || VOLC_SEEDREAM_DEFAULT,
    prompt: prompt,
    size: normalizeVolcSeedreamSize(payload.size),
    n: Math.max(1, Math.min(4, parseInt(payload.count, 10) || 1)),
    response_format: 'url'
  };
  var refs = inputImagesFromPayload(payload).map(imageToProviderValue);
  if (refs.length === 1) body.image = refs[0];
  else if (refs.length > 1) body.image = refs;
  return fetchJson(cfg.imageEndpoint || 'https://ark.cn-beijing.volces.com/api/v3/images/generations', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + cfg.apiKey },
    body: JSON.stringify(body),
    signal: signalForPayload(payload)
  }, 180000).then(function (res) {
    if (!res.ok) {
      if (/InvalidEndpointOrModel\.NotFound|does not exist|not have access/i.test(res.error || '')) {
        res.error += '\n火山/豆包生图模型未开通或模型名不对：请在火山方舟控制台复制已开通的 Seedream 模型 ID 或推理接入点 ID，填到“生图模型”输入框。';
      }
      if (/parameter `?size`?|image size must be at least|InvalidParameter/i.test(res.error || '')) {
        res.error += '\nSeedream 5.0-lite 需要 2K/3K 尺寸，本插件已将小尺寸自动映射到同构图比例的 2K 尺寸；请重新点击生图。';
      }
      return res;
    }
    var imgs = parseImageResponse(res.data);
    return imgs.length ? { ok: true, images: imgs, raw: res.data } : { ok: false, error: '未解析到火山/豆包图片', raw: res.data };
  });
}

function geminiUrl(cfg) {
  var model = cfg.imageModel || 'gemini-2.5-flash-image-preview';
  var ep = cfg.imageEndpoint || 'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent';
  ep = ep.replace('{model}', encodeURIComponent(model));
  return ep + (ep.indexOf('?') >= 0 ? '&' : '?') + 'key=' + encodeURIComponent(cfg.apiKey);
}

function createGeminiImage(cfg, payload) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  payload = payload || {};
  if (!cfg.apiKey) return Promise.resolve({ ok: false, error: '未配置 API Key' });
  var prompt = ((payload.prompt || '') + claritySuffix(payload.clarity || 'standard')).trim();
  if (payload.negativePrompt) prompt += '\nAvoid: ' + payload.negativePrompt;
  var parts = [{ text: prompt }];
  inputImagesFromPayload(payload).forEach(function (img) { parts.push(imagePartForGemini(img)); });
  var body = { contents: [{ role: 'user', parts: parts }] };
  return fetchJson(geminiUrl(cfg), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: signalForPayload(payload) }, 180000)
    .then(function (res) {
      if (!res.ok) return res;
      var imgs = parseImageResponse(res.data);
      return imgs.length ? { ok: true, images: imgs, raw: res.data } : { ok: false, error: '未解析到 Nano Banana/Gemini 图片', raw: res.data };
    });
}

function createGenericJsonImage(cfg, payload) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  payload = payload || {};
  if (!cfg.apiKey) return Promise.resolve({ ok: false, error: '未配置 API Key' });
  var body = {
    model: cfg.imageModel,
    prompt: payload.prompt,
    negative_prompt: payload.negativePrompt || '',
    size: normalizeSize(payload.size, 'x'),
    n: Math.max(1, Math.min(4, parseInt(payload.count, 10) || 1)),
    reference_image: payload.referenceImage || '',
    product_image: productImagesFromPayload(payload)[0] || '',
    product_images: productImagesFromPayload(payload)
  };
  return fetchJson(cfg.imageEndpoint, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + cfg.apiKey }, body: JSON.stringify(body), signal: signalForPayload(payload) }, 180000)
    .then(function (res) {
      if (!res.ok) return res;
      var imgs = parseImageResponse(res.data);
      return imgs.length ? { ok: true, images: imgs, raw: res.data } : { ok: false, error: '未解析到图片 URL/base64', raw: res.data };
    });
}

function createImageTask(cfg, payload) {
  var adapter = (cfg && cfg.imageAdapter) || 'dashscope-wan';
  if (adapter === 'none') return Promise.resolve({ ok: false, error: '当前服务商只支持文本提词，不支持生图。请选择生图适配器。' });
  if (adapter === 'openai-images') return createOpenAIImage(cfg, payload);
  if (adapter === 'minimax-image') return createMiniMaxImage(cfg, payload);
  if (adapter === 'zhipu-cogview') return createZhipuImage(cfg, payload);
  if (adapter === 'volcengine-image' || adapter === 'doubao-image') return createVolcengineImage(cfg, payload);
  if (adapter === 'gemini-image' || adapter === 'nano-banana') return createGeminiImage(cfg, payload);
  if (adapter === 'generic-json') return createGenericJsonImage(cfg, payload);
  return createDashScopeImageTask(cfg, payload);
}

function pollImageTask(cfg, endpointUrl, taskId, round, signal) {
  return new Promise(function (resolve) {
    if (signal && signal.aborted) { resolve({ ok: false, error: '请求已终止', taskId: taskId }); return; }
    if (round > 90) { resolve({ ok: false, error: '生图任务超时', taskId: taskId }); return; }
    setTimeout(function () {
      if (signal && signal.aborted) { resolve({ ok: false, error: '请求已终止', taskId: taskId }); return; }
      fetch(taskUrlFrom(endpointUrl, taskId), {
        method: 'GET',
        headers: { 'Authorization': 'Bearer ' + cfg.apiKey },
        signal: signal || undefined
      }).then(function (r) {
        return r.text().then(function (txt) { return { status: r.status, txt: txt }; });
      }).then(function (resp) {
        if (resp.status < 200 || resp.status >= 300) {
          resolve({ ok: false, error: '轮询失败 HTTP ' + resp.status + ': ' + (resp.txt || '').slice(0, 240), taskId: taskId });
          return;
        }
        var data; try { data = JSON.parse(resp.txt); } catch (e) { resolve({ ok: false, error: '轮询返回非 JSON', taskId: taskId }); return; }
        var status = data && data.output && data.output.task_status;
        if (status === 'SUCCEEDED') {
          resolve({ ok: true, taskId: taskId, images: deepFindImages(data), raw: data });
        } else if (status === 'FAILED' || status === 'CANCELED' || status === 'UNKNOWN') {
          resolve({ ok: false, error: '任务失败：' + status, taskId: taskId, raw: data });
        } else {
          pollImageTask(cfg, endpointUrl, taskId, round + 1, signal).then(function (r) { resolve(r); });
        }
      }).catch(function (e) {
        resolve({ ok: false, error: (e && e.name === 'AbortError') ? '请求已终止' : ('轮询网络错误：' + ((e && e.message) || e)), taskId: taskId });
      });
    }, round < 3 ? 1800 : 3000);
  });
}

function arrayBufferToDataUrl(buffer, contentType) {
  var bytes = new Uint8Array(buffer);
  var chunk = 0x8000;
  var parts = [];
  for (var i = 0; i < bytes.length; i += chunk) {
    parts.push(String.fromCharCode.apply(null, bytes.subarray(i, i + chunk)));
  }
  return 'data:' + (contentType || 'image/jpeg') + ';base64,' + btoa(parts.join(''));
}

function fetchAsDataUrl(url) {
  return new Promise(function (resolve) {
    fetch(url).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      var type = r.headers.get('content-type') || 'image/jpeg';
      return r.arrayBuffer().then(function (buf) { return { buf: buf, type: type }; });
    }).then(function (x) {
      resolve({ ok: true, dataUrl: arrayBufferToDataUrl(x.buf, x.type) });
    }).catch(function (e) {
      resolve({ ok: false, error: ((e && e.message) || e) });
    });
  });
}

function downloadAll(urls) {
  urls = (urls || []).filter(Boolean);
  if (!urls.length) return Promise.resolve({ ok: false, error: '没有可下载图片' });
  urls.forEach(function (url, idx) {
    chrome.downloads.download({
      url: url,
      filename: '少壮AI主图实验室/image_' + Date.now() + '_' + (idx + 1) + '.png',
      conflictAction: 'uniquify',
      saveAs: false
    });
  });
  return Promise.resolve({ ok: true, count: urls.length });
}

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || !msg.type) return;
  if (msg.type === 'OPEN_CONTEXT_WORKBENCH') {
    openContextWorkbench(msg.payload || {});
    sendResponse({ ok: true });
    return;
  }
  if (msg.type === 'GET_CONTEXT') {
    chrome.storage.local.get([CONTEXT_KEY, CONFIG_KEY], function (r) {
      sendResponse({ ok: true, context: r[CONTEXT_KEY] || null, config: Object.assign({}, DEFAULT_CFG, r[CONFIG_KEY] || {}) });
    });
    return true;
  }
  if (msg.type === 'SAVE_CONFIG') {
    var o = {}; o[CONFIG_KEY] = Object.assign({}, DEFAULT_CFG, msg.config || {});
    chrome.storage.local.set(o, function () { sendResponse({ ok: true }); });
    return true;
  }
  if (msg.type === 'FETCH_IMAGE') { fetchAsDataUrl(msg.url).then(sendResponse); return true; }
  if (msg.type === 'ANALYZE_IMAGE') { analyzeImage(msg.config, msg.payload).then(sendResponse); return true; }
  if (msg.type === 'BUILD_LINK_PROMPT') { buildLinkPrompt(msg.config, msg.payload).then(sendResponse); return true; }
  if (msg.type === 'GENERATE_IMAGE') {
    var jobId = msg.jobId || (msg.payload && msg.payload._jobId) || '';
    if (jobId) {
      activeJobs[jobId] = new AbortController();
      msg.payload = Object.assign({}, msg.payload || {}, { _jobId: jobId });
    }
    createImageTask(msg.config, msg.payload).then(function (res) {
      if (jobId) delete activeJobs[jobId];
      sendResponse(res);
    });
    return true;
  }
  if (msg.type === 'CANCEL_GENERATION') {
    if (msg.jobId && activeJobs[msg.jobId]) {
      try { activeJobs[msg.jobId].abort(); } catch (e) {}
      delete activeJobs[msg.jobId];
      sendResponse({ ok: true, cancelled: true });
    } else {
      sendResponse({ ok: true, cancelled: false });
    }
    return true;
  }
  if (msg.type === 'DOWNLOAD_ALL') { downloadAll(msg.urls).then(sendResponse); return true; }
});
