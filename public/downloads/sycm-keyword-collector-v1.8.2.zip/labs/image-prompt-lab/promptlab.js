'use strict';

var DEFAULT_CFG = {
  provider: 'dashscope',
  imageAdapter: 'dashscope-wan',
  visionBaseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
  visionModel: 'qwen-vl-plus',
  textModel: 'qwen-plus',
  imageEndpoint: 'https://dashscope.aliyuncs.com/api/v1/services/aigc/image-generation/generation',
  imageModel: 'wan2.7-image',
  apiKey: ''
};
var VOLC_SEEDREAM_DEFAULT = 'doubao-seedream-5-0-260128';
var LINKMATRIX_JSON_KEY = 'sycm_linkmatrix_json';
var PRESETS = {
  dashscope: {
    provider: 'dashscope',
    imageAdapter: 'dashscope-wan',
    visionBaseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
    visionModel: 'qwen-vl-plus',
    textModel: 'qwen-plus',
    imageEndpoint: 'https://dashscope.aliyuncs.com/api/v1/services/aigc/image-generation/generation',
    imageModel: 'wan2.7-image'
  },
  'deepseek-v4': {
    provider: 'deepseek-v4',
    imageAdapter: 'none',
    visionBaseUrl: 'https://api.deepseek.com',
    visionModel: '',
    textModel: 'deepseek-v4-flash',
    imageEndpoint: '',
    imageModel: ''
  },
  minimax: {
    provider: 'minimax',
    imageAdapter: 'minimax-image',
    visionBaseUrl: 'https://api.minimax.io/v1',
    visionModel: 'MiniMax-M2.1',
    textModel: 'MiniMax-M2.1',
    imageEndpoint: 'https://api.minimax.io/v1/image_generation',
    imageModel: 'image-01'
  },
  zhipu: {
    provider: 'zhipu',
    imageAdapter: 'zhipu-cogview',
    visionBaseUrl: 'https://open.bigmodel.cn/api/paas/v4',
    visionModel: 'glm-4v-plus',
    textModel: 'glm-4-plus',
    imageEndpoint: 'https://open.bigmodel.cn/api/paas/v4/images/generations',
    imageModel: 'cogview-4-250304'
  },
  doubao: {
    provider: 'doubao',
    imageAdapter: 'doubao-image',
    visionBaseUrl: 'https://ark.cn-beijing.volces.com/api/v3',
    visionModel: 'doubao-seed-evolving',
    textModel: 'doubao-seed-evolving',
    imageEndpoint: 'https://ark.cn-beijing.volces.com/api/v3/images/generations',
    imageModel: VOLC_SEEDREAM_DEFAULT
  },
  openai: {
    provider: 'openai',
    imageAdapter: 'openai-images',
    visionBaseUrl: 'https://api.openai.com/v1',
    visionModel: 'gpt-5-mini',
    textModel: 'gpt-5-mini',
    imageEndpoint: 'https://api.openai.com/v1/images/generations',
    imageModel: 'gpt-image-2'
  },
  'nano-banana': {
    provider: 'nano-banana',
    imageAdapter: 'nano-banana',
    visionBaseUrl: 'https://generativelanguage.googleapis.com/v1beta',
    visionModel: 'gemini-2.5-flash-image-preview',
    textModel: 'gemini-2.5-flash',
    imageEndpoint: 'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent',
    imageModel: 'gemini-2.5-flash-image-preview'
  },
  'openai-compatible': {
    provider: 'openai-compatible',
    imageAdapter: 'generic-json',
    visionBaseUrl: 'https://api.example.com/v1',
    visionModel: 'vision-model',
    textModel: 'chat-model',
    imageEndpoint: 'https://api.example.com/v1/images/generations',
    imageModel: 'image-model'
  }
};
var sampleLink = {
  "链接编号": "L001",
  "链接分组": "差异化链接",
  "链接定位": "家庭厨房鲜味升级",
  "主推关键词": "蚝油｜鲜味｜家常炒菜｜厨房调味",
  "主标题": "鲜味蚝油厨房炒菜拌馅提鲜家用大瓶装",
  "核心场景": "家常炒菜、拌馅、烧菜",
  "风格定位": "红金高识别度、食欲感、商超爆品",
  "目标人群": "家庭厨房、做饭人群",
  "核心功能": "提鲜、增香、挂汁",
  "差异化壁垒": "突出一勺提鲜和真实菜品食欲感，不复刻竞品包装",
  "主图核心文案": "一勺爆鲜，家常菜更香"
};

var $ = function (id) { return document.getElementById(id); };
var PRODUCT_ANGLES = {
  front: { preview: 'productFrontPreview', file: 'productFrontFile', url: 'productFrontUrl', label: '正视图' },
  side: { preview: 'productSidePreview', file: 'productSideFile', url: 'productSideUrl', label: '侧视图' },
  back: { preview: 'productBackPreview', file: 'productBackFile', url: 'productBackUrl', label: '背视图' }
};
var state = {
  refImage: '',
  productImage: '',
  productImages: { front: '', side: '', back: '' },
  results: [],
  linkList: [],
  lastLink: null,
  analysis: null,
  activeJobId: '',
  cancelledJobs: {},
  stopRequested: false,
  actionItem: null,
  guideItem: null,
  contextItem: null,
  contextAuto: false
};

function send(type, payload) {
  return new Promise(function (resolve) {
    try {
      chrome.runtime.sendMessage(Object.assign({ type: type }, payload || {}), function (resp) {
        var err = chrome.runtime.lastError;
        if (err) resolve({ ok: false, error: err.message });
        else resolve(resp || { ok: false, error: '无响应' });
      });
    } catch (e) { resolve({ ok: false, error: (e && e.message) || e }); }
  });
}

function setPill(id, text, kind) {
  var el = $(id);
  if (!el) return;
  el.textContent = text;
  el.className = 'pill' + (kind ? ' ' + kind : '');
}

function cfgFromForm() {
  return normalizeCfg({
    provider: $('provider').value,
    imageAdapter: $('imageAdapter').value,
    apiKey: $('apiKey').value.trim(),
    visionBaseUrl: $('visionBaseUrl').value.trim() || DEFAULT_CFG.visionBaseUrl,
    visionModel: $('visionModel').value.trim() || DEFAULT_CFG.visionModel,
    textModel: $('textModel').value.trim() || DEFAULT_CFG.textModel,
    imageEndpoint: $('imageEndpoint').value.trim() || DEFAULT_CFG.imageEndpoint,
    imageModel: $('imageModel').value.trim() || DEFAULT_CFG.imageModel
  });
}

function normalizeCfg(cfg) {
  cfg = Object.assign({}, DEFAULT_CFG, cfg || {});
  if (cfg.provider === 'jimeng') cfg.provider = 'doubao';
  if (cfg.imageAdapter === 'jimeng-image') cfg.imageAdapter = 'doubao-image';
  var isVolc = cfg.provider === 'doubao' || /^https:\/\/ark\.cn-beijing\.volces\.com/.test(cfg.visionBaseUrl || '');
  if (isVolc) {
    if (!cfg.visionModel || /^doubao-1\.5/.test(cfg.visionModel)) cfg.visionModel = 'doubao-seed-evolving';
    if (!cfg.textModel || /^doubao-1\.5/.test(cfg.textModel)) cfg.textModel = 'doubao-seed-evolving';
    if (!cfg.imageEndpoint) cfg.imageEndpoint = PRESETS.doubao.imageEndpoint;
    if (!cfg.imageModel || /^doubao-seedream-3-0/i.test(cfg.imageModel)) cfg.imageModel = VOLC_SEEDREAM_DEFAULT;
  }
  return cfg;
}

function applyCfg(cfg) {
  cfg = normalizeCfg(cfg);
  $('provider').value = cfg.provider || 'dashscope';
  $('imageAdapter').value = cfg.imageAdapter || 'dashscope-wan';
  $('apiKey').value = cfg.apiKey || '';
  $('visionBaseUrl').value = cfg.visionBaseUrl || DEFAULT_CFG.visionBaseUrl;
  $('visionModel').value = cfg.visionModel || DEFAULT_CFG.visionModel;
  $('textModel').value = cfg.textModel || DEFAULT_CFG.textModel;
  $('imageEndpoint').value = cfg.imageEndpoint || DEFAULT_CFG.imageEndpoint;
  $('imageModel').value = cfg.imageModel || DEFAULT_CFG.imageModel;
  setPill('configState', cfg.apiKey ? '已配置' : '未配置', cfg.apiKey ? 'ok' : 'warn');
  return cfg;
}

function applyProviderPreset(provider) {
  var key = $('apiKey').value.trim();
  var preset = Object.assign({}, PRESETS[provider] || PRESETS.dashscope);
  preset.apiKey = key;
  applyCfg(preset);
}

function saveCfg() {
  var cfg = cfgFromForm();
  send('SAVE_CONFIG', { config: cfg }).then(function (r) {
    setPill('configState', r && r.ok ? '已保存' : '保存失败', r && r.ok ? 'ok' : 'warn');
    if (r && r.ok) setTimeout(closeConfigModal, 180);
  });
}

function openConfigModal() {
  var modal = $('configModal');
  if (modal) modal.hidden = false;
  if ($('provider')) $('provider').focus();
}

function closeConfigModal() {
  var modal = $('configModal');
  if (modal) modal.hidden = true;
}

function fileToDataUrl(file) {
  return new Promise(function (resolve, reject) {
    var rd = new FileReader();
    rd.onload = function () { resolve(rd.result); };
    rd.onerror = function () { reject(rd.error); };
    rd.readAsDataURL(file);
  });
}

function imageToOptimizedDataUrl(src, maxSide, quality) {
  maxSide = maxSide || 1280;
  quality = quality || 0.86;
  return new Promise(function (resolve) {
    var img = new Image();
    img.onload = function () {
      var w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
      if (!w || !h) { resolve(src); return; }
      var scale = Math.min(1, maxSide / Math.max(w, h));
      var cw = Math.max(1, Math.round(w * scale));
      var ch = Math.max(1, Math.round(h * scale));
      var canvas = document.createElement('canvas');
      canvas.width = cw; canvas.height = ch;
      var ctx = canvas.getContext('2d');
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, cw, ch);
      ctx.drawImage(img, 0, 0, cw, ch);
      resolve(canvas.toDataURL('image/jpeg', quality));
    };
    img.onerror = function () { resolve(src); };
    img.src = src;
  });
}

function fileToOptimizedDataUrl(file) {
  return fileToDataUrl(file).then(function (url) { return imageToOptimizedDataUrl(url, 1280, 0.86); });
}

function renderPreview(id, src, label) {
  var box = $(id);
  if (!src) {
    box.className = 'preview empty';
    box.textContent = label;
    return;
  }
  box.className = 'preview';
  box.innerHTML = '';
  var img = document.createElement('img');
  img.src = src;
  img.alt = label;
  box.appendChild(img);
}

function setRefImage(src, urlText) {
  state.refImage = src || '';
  if (urlText != null) $('refUrl').value = urlText;
  renderPreview('refPreview', state.refImage, '上传、粘贴 URL / 图片，或右键网页图片导入');
  setPill('contextState', state.refImage ? '已载入参考图' : '等待图片', state.refImage ? 'ok' : '');
}

function productPlaceholder(kind) {
  if (kind === 'side') return '上传侧面厚度、结构或规格角度';
  if (kind === 'back') return '上传背面信息、开盒或反面角度';
  return '上传正面包装或主展示面';
}

function syncPrimaryProductImage() {
  state.productImage = state.productImages.front || state.productImages.side || state.productImages.back || '';
}

function setProductAngle(kind, src, urlText) {
  var meta = PRODUCT_ANGLES[kind];
  if (!meta) return;
  state.productImages[kind] = src || '';
  if (urlText != null && $(meta.url)) $(meta.url).value = urlText;
  syncPrimaryProductImage();
  renderPreview(meta.preview, state.productImages[kind], productPlaceholder(kind));
  var count = productImageList().length;
  setPill('contextState', count ? ('已载入主体图 ' + count + ' 张') : (state.refImage ? '已载入参考图' : '等待图片'), count ? 'ok' : (state.refImage ? 'ok' : ''));
}

function setProductImage(src, urlText) {
  setProductAngle('front', src, urlText);
}

function productImageList() {
  var out = [];
  ['front', 'side', 'back'].forEach(function (kind) {
    var meta = PRODUCT_ANGLES[kind];
    var img = state.productImages[kind] || (meta && $(meta.url) ? normalizeImageUrl($(meta.url).value) : '');
    if (img && out.indexOf(img) < 0) out.push(img);
  });
  return out;
}

function primaryProductImage() {
  var imgs = productImageList();
  return imgs[0] || '';
}

function normalizeImageUrl(input) {
  var v = (input || '').trim();
  if (!v) return '';
  if (/^data:image\//.test(v)) return v;
  if (/^https?:\/\//.test(v)) return v;
  return '';
}

function plainObject(value) {
  return value && typeof value === 'object' && !Array.isArray(value);
}

function hasRowValue(row) {
  if (!plainObject(row)) return false;
  return Object.keys(row).some(function (k) {
    var v = row[k];
    return v != null && ('' + v).trim() !== '';
  });
}

function normalizeLinkRows(value) {
  var source = value;
  if (plainObject(source)) {
    if (Array.isArray(source.rows)) source = source.rows;
    else if (Array.isArray(source.linksJson)) source = source.linksJson;
    else if (Array.isArray(source.linkRows)) source = source.linkRows;
    else if (Array.isArray(source.data)) source = source.data;
    else if (Array.isArray(source.links)) source = source.links;
    else source = [source];
  }
  if (!Array.isArray(source)) return [];
  return source.filter(plainObject).map(function (row) { return Object.assign({}, row); }).filter(hasRowValue);
}

function splitDelimitedLine(line, delimiter) {
  if (delimiter === '\t') return line.split('\t');
  var out = [], cur = '', quote = false;
  for (var i = 0; i < line.length; i++) {
    var ch = line.charAt(i);
    if (ch === '"') {
      if (quote && line.charAt(i + 1) === '"') { cur += '"'; i++; }
      else quote = !quote;
    } else if (ch === delimiter && !quote) {
      out.push(cur); cur = '';
    } else {
      cur += ch;
    }
  }
  out.push(cur);
  return out;
}

function parseDelimitedLinks(raw) {
  var lines = (raw || '').split(/\r?\n/).filter(function (line) { return line.trim(); });
  if (lines.length < 2) return [];
  var delimiter = raw.indexOf('\t') >= 0 ? '\t' : (raw.indexOf(',') >= 0 ? ',' : '');
  if (!delimiter) return [];
  var headers = splitDelimitedLine(lines[0], delimiter).map(function (h) { return h.trim(); });
  if (!headers.length || headers.every(function (h) { return !h; })) return [];
  return lines.slice(1).map(function (line) {
    var cols = splitDelimitedLine(line, delimiter);
    var row = {};
    headers.forEach(function (h, i) {
      if (!h) return;
      row[h] = (cols[i] == null ? '' : cols[i]).trim();
    });
    return row;
  }).filter(hasRowValue);
}

function parseNdjsonLinks(raw) {
  var rows = [];
  var lines = (raw || '').split(/\r?\n/).map(function (line) { return line.trim(); }).filter(Boolean);
  if (lines.length < 2) return [];
  for (var i = 0; i < lines.length; i++) {
    if (!/^\{/.test(lines[i])) return [];
    rows.push(JSON.parse(lines[i]));
  }
  return normalizeLinkRows(rows);
}

function parseLinkListInput() {
  var raw = $('linkJson').value.trim();
  if (!raw) return [];
  try {
    var parsed = JSON.parse(raw);
    var rows = normalizeLinkRows(parsed);
    if (rows.length) return rows;
    throw new Error('JSON 中没有可用链接行');
  } catch (jsonErr) {
    try {
      var ndRows = parseNdjsonLinks(raw);
      if (ndRows.length) return ndRows;
    } catch (e) {}
    var tableRows = parseDelimitedLinks(raw);
    if (tableRows.length) return tableRows;
    throw new Error('链接清单解析失败：请粘贴单条 JSON、数组 JSON、{"rows":[...]}，或带表头的表格。原始错误：' + jsonErr.message);
  }
}

function parseLinkJson() {
  var rows = parseLinkListInput();
  var obj = rows.length ? Object.assign({}, rows[0]) : {};
  var pos = $('positioning').value.trim();
  var copy = $('imageCopy').value.trim();
  if (pos) obj['链接定位'] = pos;
  if (copy) obj['主图核心文案'] = copy;
  if (!Object.keys(obj).length) throw new Error('请粘贴链接清单 JSON，或至少填写链接定位');
  if (rows.length) rows[0] = Object.assign({}, rows[0], obj);
  state.linkList = rows.length ? rows : [obj];
  state.lastLink = obj;
  return obj;
}

function applyLinkToFields(value, keepRawText) {
  var rows = normalizeLinkRows(value);
  if (!rows.length) return;
  var obj = rows[0];
  state.linkList = rows;
  state.lastLink = obj;
  if (!keepRawText) $('linkJson').value = JSON.stringify(rows.length === 1 ? obj : rows, null, 2);
  $('positioning').value = obj['链接定位'] || obj.positioning || '';
  $('imageCopy').value = obj['主图核心文案'] || obj.imageCopy || '';
  syncBatchRangeDefaults(rows, !keepRawText);
  setPill('linkState', rows.length > 1 ? ('已载入 ' + rows.length + ' 条链接') : '已载入链接', 'ok');
}

function showAnalysis(data) {
  data = data || {};
  state.analysis = data;
  $('cnPrompt').value = data['中文提示词'] || data.cnPrompt || '';
  $('enPrompt').value = data['English Prompt'] || data.englishPrompt || data.enPrompt || '';
  $('negativePrompt').value = data['负面提示词'] || data.negativePrompt || $('negativePrompt').value;
  $('analysisJson').textContent = JSON.stringify(data, null, 2);
}

function analyzeCurrentImage() {
  var image = state.refImage || normalizeImageUrl($('refUrl').value);
  if (!image) { setPill('runState', '缺少参考图', 'warn'); return Promise.resolve({ ok: false, error: '缺少参考图' }); }
  var cfg = cfgFromForm();
  var linkHint = $('positioning').value.trim();
  setPill('runState', '图片提词中...', '');
  $('analyzeBtn').disabled = true;
  return send('ANALYZE_IMAGE', { config: cfg, payload: { image: image, linkHint: linkHint } }).then(function (resp) {
    $('analyzeBtn').disabled = false;
    if (resp && resp.ok) {
      showAnalysis(resp.data);
      setPill('runState', '提词完成', 'ok');
    } else {
      setPill('runState', (resp && resp.error) || '提词失败', 'warn');
    }
    return resp;
  });
}

function linkRowLabel(link, idx) {
  link = link || {};
  var id = link['链接编号'] || link.linkId || ('L' + ('00' + ((idx || 0) + 1)).slice(-3));
  var text = link['链接定位'] || link['主推关键词'] || link['主标题'] || link.keyword || '';
  text = ('' + text).replace(/\s+/g, ' ').slice(0, 18);
  return text ? (id + ' ' + text) : id;
}

function linkSequenceNumber(link, idx) {
  link = link || {};
  var raw = link['链接编号'] || link.linkId || link.link_id || '';
  if (!raw) return (idx || 0) + 1;
  var text = String(raw).trim();
  var match = text.match(/L\s*0*(\d+)/i) || text.match(/^0*(\d+)$/);
  var n = match ? parseInt(match[1], 10) : NaN;
  return isFinite(n) && n > 0 ? n : ((idx || 0) + 1);
}

function formatLinkRangeCode(num) {
  num = parseInt(num, 10);
  return 'L' + (isFinite(num) && num > 0 ? num : 1);
}

function parseLinkRangeText(value) {
  var text = (value || '').trim();
  if (!text) return {};
  var nums = [];
  text.replace(/[Ll]\s*0*(\d+)|\b0*(\d+)\b/g, function (_, a, b) {
    var n = parseInt(a || b, 10);
    if (isFinite(n) && n > 0) nums.push(n);
    return _;
  });
  return {
    start: nums.length ? nums[0] : 0,
    end: nums.length > 1 ? nums[1] : 0
  };
}

function firstLinkSequence(rows) {
  return rows && rows.length ? linkSequenceNumber(rows[0], 0) : 1;
}

function defaultBatchEndSequence(rows, start) {
  if (!rows || !rows.length) return start || 1;
  var targetIndex = Math.min(2, rows.length - 1);
  var target = linkSequenceNumber(rows[targetIndex], targetIndex);
  return Math.max(start || 1, target);
}

function isDefaultBatchRangeValue(startValue, endValue) {
  var start = parseLinkRangeText(startValue);
  var end = parseLinkRangeText(endValue);
  var startNum = start.start || 0;
  var endNum = end.end || end.start || start.end || 0;
  return (!startValue && !endValue) || (startNum === 1 && (!endNum || endNum === 3));
}

function syncBatchRangeDefaults(rows, force) {
  if (!rows || !rows.length) return;
  var startEl = $('batchLinkStart');
  var endEl = $('batchLinkEnd');
  if (!startEl || !endEl) return;
  var start = firstLinkSequence(rows);
  var end = defaultBatchEndSequence(rows, start);
  var canRefresh = force || isDefaultBatchRangeValue(startEl.value.trim(), endEl.value.trim());
  if (canRefresh || !startEl.value.trim()) startEl.value = formatLinkRangeCode(start);
  if (canRefresh || !endEl.value.trim()) endEl.value = formatLinkRangeCode(end);
}

function getBatchRange(rows) {
  rows = rows || [];
  var fallbackStart = firstLinkSequence(rows);
  var fallbackEnd = defaultBatchEndSequence(rows, fallbackStart);
  var startText = $('batchLinkStart') ? $('batchLinkStart').value : '';
  var endText = $('batchLinkEnd') ? $('batchLinkEnd').value : '';
  var startParsed = parseLinkRangeText(startText);
  var endParsed = parseLinkRangeText(endText);
  var start = startParsed.start || fallbackStart;
  var end = endParsed.end || endParsed.start || startParsed.end || fallbackEnd;
  if (start > end) {
    var tmp = start;
    start = end;
    end = tmp;
  }
  return { start: start, end: end, label: formatLinkRangeCode(start) + '-' + formatLinkRangeCode(end) };
}

function selectRowsByLinkRange(rows) {
  var range = getBatchRange(rows);
  var selected = rows.filter(function (row, idx) {
    var seq = linkSequenceNumber(row, idx);
    return seq >= range.start && seq <= range.end;
  });
  return Object.assign(range, { rows: selected });
}

function syncLinkFields(link) {
  link = link || {};
  state.lastLink = link;
  $('positioning').value = link['链接定位'] || link.positioning || '';
  $('imageCopy').value = link['主图核心文案'] || link.imageCopy || '';
}

function buildPromptForLink(link, label, options) {
  options = options || {};
  link = Object.assign({}, link || {});
  syncLinkFields(link);
  if (!Object.keys(link).length) return Promise.resolve({ ok: false, error: '链接清单 JSON 无效' });
  setPill('runState', '链接提词中' + (label ? '：' + label : '') + '...', '');
  if (!options.silent) $('buildPromptBtn').disabled = true;
  return send('BUILD_LINK_PROMPT', { config: cfgFromForm(), payload: { link: link } }).then(function (resp) {
    if (!options.silent) $('buildPromptBtn').disabled = false;
    if (resp && resp.ok) {
      var data = resp.data || {};
      showAnalysis(data);
      $('imageCopy').value = data['主图文案'] || $('imageCopy').value;
      setPill('runState', '主图提示词完成' + (label ? '：' + label : ''), 'ok');
    } else {
      setPill('runState', (resp && resp.error) || '生成失败', 'warn');
    }
    return resp;
  });
}

function buildLinkPrompt() {
  var link;
  try { link = parseLinkJson(); } catch (e) { setPill('runState', e.message, 'warn'); return Promise.resolve({ ok: false, error: e.message }); }
  return buildPromptForLink(link, '', { silent: false });
}

function promptText(value) {
  if (!value) return '';
  if (Array.isArray(value)) return value.join(', ');
  if (typeof value === 'object') return JSON.stringify(value);
  return '' + value;
}

function firstAnalysisValue(data, keys) {
  data = data || {};
  for (var i = 0; i < keys.length; i++) {
    var v = data[keys[i]];
    if (v) return promptText(v);
  }
  return '';
}

function referenceStyleNotes(data) {
  data = data || {};
  var rows = [
    ['Composition/layout', ['构图', '画面布局', '版式结构', 'layout']],
    ['Camera/view', ['镜头', 'camera']],
    ['Lighting', ['光线', 'lighting']],
    ['Color palette', ['色彩', 'color_palette', '色彩系统']],
    ['Background/mood', ['背景', 'background']],
    ['Material/texture', ['材质', 'texture']],
    ['Visual style', ['风格', 'style', 'style_tags']],
    ['Commercial direction', ['主图方向', '风格定位']]
  ].map(function (item) {
    var v = firstAnalysisValue(data, item[1]);
    return v ? item[0] + ': ' + v : '';
  }).filter(Boolean);
  return rows.join('\n');
}

function subjectReplacementPrompt(productImages) {
  productImages = Array.isArray(productImages) ? productImages : (productImages ? [productImages] : []);
  if (!productImages.length) return '';
  var angleText = productImages.length > 1
    ? 'Use the first three product-subject inputs as front view, side view and back/detail view evidence.'
    : 'Use the first product-subject input as the new product identity evidence.';
  return [
    'SUBJECT REPLACEMENT MODE:',
    angleText,
    'These product-subject images define the ONLY hero product in the final ad.',
    'Recreate the product from the product evidence: package shape, SKU count, front-facing structure, side thickness, back/detail information, main colors, label hierarchy, visible logo/text placement and realistic proportions.',
    'The reference/competitor image is only for composition, camera angle, lighting, color mood, background depth, commercial layout and prop atmosphere.',
    'Replace every old product or package from the reference image and from any reference notes. Do not generate the competitor subject, competitor logo, competitor packaging, old gift contents, old bottles, old boxes, old snacks, old toiletries or old props as the main product.',
    'Final image requirement: the new product is large, clear, commercially centered, properly lit, with natural shadow and no subject confusion.'
  ].join('\n');
}

function replacementNegativePrompt() {
  return 'old reference product, competitor product, competitor packaging, competitor brand logo, original reference subject, wrong product category, product hidden, product cropped, product replaced by props, mixed old and new products, distorted package, unreadable fake text';
}

function guidePriorityLayer(guide, hasProductImage) {
  if (!guide) return '';
  return [
    'HIGHEST PRIORITY SEMANTIC GUIDE LAYER:',
    'User guide: ' + guide,
    'Conflict rule: if this guide conflicts with the reference image, editable prompt notes, link prompt, previous generated result, product props, or any lower-priority description, this guide wins semantically.',
    'Implementation rule: do not render the guide as visible text. Translate it into natural visual decisions: subject selection, prop replacement, container choice, crop, occlusion, spatial layout, camera angle, material choice, and background simplification.',
    'Integration rule: keep the image commercially believable and visually integrated. Do not force an awkward literal object unless it naturally belongs in the product scene.',
    hasProductImage ? 'Product authority: the uploaded product subject image still has the highest visual identity authority for the final product; the guide controls what must be changed around it and which conflicting reference elements must disappear or be softened.' : '',
    'If the guide says an element should be replaced or removed, remove the conflicting old element from the scene and replace it with a visually compatible e-commerce display solution.'
  ].filter(Boolean).join('\n');
}

function generationPrompt(variant) {
  var base = $('enPrompt').value.trim() || $('cnPrompt').value.trim();
  var guide = (variant === 'guide' && $('guidePrompt')) ? $('guidePrompt').value.trim() : '';
  var pos = $('positioning').value.trim();
  var copy = $('imageCopy').value.trim();
  var link = state.lastLink || {};
  var productImages = productImageList();
  var productImage = productImages[0] || '';
  var styleNotes = referenceStyleNotes(state.analysis);
  var prefix = '';
  if (variant === 'main') prefix = 'E-commerce hero main image, strong conversion focus. ';
  if (variant === 'scene') prefix = 'Lifestyle scenario image for e-commerce, natural product usage scene. ';
  if (variant === 'hook') prefix = 'Visual hook image, memorable key visual, clear product benefit. ';
  if (variant === 'diff') prefix = 'Differentiated competitor-avoidance e-commerce image, original layout. ';
  if (!productImage) {
    return [
      guidePriorityLayer(guide, false),
      prefix + base,
      pos ? 'Link positioning: ' + pos : '',
      copy ? 'Main visual copy direction: ' + copy : '',
      link['核心场景'] ? 'Core scene: ' + link['核心场景'] : '',
      link['目标人群'] ? 'Target audience: ' + link['目标人群'] : '',
      link['风格定位'] ? 'Style: ' + link['风格定位'] : '',
      'Avoid using real brand logos, trademarked packaging layouts, unreadable text, or copying competitor design.'
    ].filter(Boolean).join('\n');
  }
  return [
    guidePriorityLayer(guide, true),
    prefix + 'Create a new e-commerce ad image with product subject replacement.',
    subjectReplacementPrompt(productImages),
    styleNotes ? 'Reference style/layout notes to borrow, excluding its product/category:\n' + styleNotes : 'Use the reference image only for non-subject style: composition, camera, lighting, color mood, background and commercial layout.',
    pos ? 'Link positioning: ' + pos : '',
    copy ? 'Main visual copy direction: ' + copy : '',
    link['主推关键词'] ? 'New product keywords/context: ' + link['主推关键词'] : '',
    link['主标题'] ? 'New product title direction: ' + link['主标题'] : '',
    link['核心场景'] ? 'Core scene: ' + link['核心场景'] : '',
    link['目标人群'] ? 'Target audience: ' + link['目标人群'] : '',
    link['风格定位'] ? 'Style: ' + link['风格定位'] : '',
    'Do not use the reference image subject as the product. Keep only its visual grammar.',
    base ? 'LOWER PRIORITY editable prompt notes. Use only the parts that do not conflict with the highest priority guide or product subject:\n' + base : '',
    'Avoid using real brand logos, trademarked packaging layouts, unreadable text, or copying competitor design.'
  ].filter(Boolean).join('\n');
}

function renderResults() {
  var grid = $('resultGrid');
  grid.innerHTML = '';
  if (!state.results.length) {
    var empty = document.createElement('div');
    empty.className = 'empty-result';
    empty.textContent = '还没有生成结果';
    grid.appendChild(empty);
    return;
  }
  state.results.forEach(function (item, idx) {
    var card = document.createElement('div');
    card.className = 'result-card';
    var img = document.createElement('img');
    img.src = item.url;
    img.alt = item.variant || 'generated image';
    var meta = document.createElement('div');
    meta.className = 'result-meta';
    var strong = document.createElement('strong');
    strong.textContent = (idx + 1) + '. ' + (item.variantName || item.variant || '生成图');
    var urlLine = document.createElement('div');
    urlLine.className = 'result-url';
    urlLine.title = item.url;
    urlLine.textContent = item.url ? '图片链接已生成' : '无图片链接';
    var row = document.createElement('div');
    row.className = 'result-actions';
    var copyImg = document.createElement('button');
    copyImg.className = 'btn ghost';
    copyImg.type = 'button';
    copyImg.textContent = '复制图片';
    copyImg.addEventListener('click', function () { openImageActionModal(item); });
    var guideBtn = document.createElement('button');
    guideBtn.className = 'btn ghost';
    guideBtn.type = 'button';
    guideBtn.textContent = '引导重生';
    guideBtn.addEventListener('click', function () { openGuideRegenerateModal(item); });
    var dl = document.createElement('button');
    dl.className = 'btn ghost';
    dl.type = 'button';
    dl.textContent = '下载';
    dl.addEventListener('click', function () { send('DOWNLOAD_ALL', { urls: [item.url] }); });
    row.appendChild(copyImg);
    row.appendChild(guideBtn);
    row.appendChild(dl);
    meta.appendChild(strong);
    meta.appendChild(urlLine);
    meta.appendChild(row);
    card.appendChild(img);
    card.appendChild(meta);
    grid.appendChild(card);
  });
}

function resultGuidePrompt(item) {
  item = item || {};
  return [
    '【最高权重引导词，可编辑】',
    '这张结果图只作为视觉参考，不作为商品主体锁定。参考图：' + (item.url || ''),
    '优先保留：构图关系、镜头角度、光影方向、色彩氛围、背景层次、商业版式、产品摆位、画面质感。',
    '语义覆盖：如果原提示词、参考图或结果图里仍包含旧商品、旧包装、旧容器、旧配件、旧品牌、旧文案，以这里填写的引导为准，冲突内容自动降权。',
    '融合落地：把引导要求转化为自然画面调整，例如替换容器、改变陈列方式、弱化/移除冲突道具、调整遮挡关系、改变摆放空间、重排局部构图；不要把引导词当成画面文字。',
    '主体规则：最终商品主体以当前上传的产品主体图为准，结果图/参考图只能提供风格和版式。',
    item.variantName ? '结果方向：' + item.variantName : '',
    item.prompt ? '低权重历史提示词，仅作风格记忆，不得覆盖以上引导：\n' + item.prompt : ''
  ].filter(Boolean).join('\n\n');
}

function blobToPngBlob(blob) {
  if (blob && blob.type === 'image/png') return Promise.resolve(blob);
  if (!blob || !window.createImageBitmap) return Promise.reject(new Error('浏览器不支持图片转码'));
  return createImageBitmap(blob).then(function (bitmap) {
    var canvas = document.createElement('canvas');
    canvas.width = bitmap.width;
    canvas.height = bitmap.height;
    var ctx = canvas.getContext('2d');
    ctx.drawImage(bitmap, 0, 0);
    if (bitmap.close) bitmap.close();
    return new Promise(function (resolve, reject) {
      canvas.toBlob(function (pngBlob) {
        if (pngBlob) resolve(pngBlob);
        else reject(new Error('图片转码失败'));
      }, 'image/png');
    });
  });
}

function openImageActionModal(item) {
  state.actionItem = item || null;
  var modal = $('imageActionModal');
  if (!modal) {
    copyImageToClipboard(item && item.url);
    return;
  }
  modal.hidden = false;
  var first = $('copyOriginalImageBtn');
  if (first) first.focus();
}

function closeImageActionModal() {
  state.actionItem = null;
  var modal = $('imageActionModal');
  if (modal) modal.hidden = true;
}

function applyContextImage(ctx, autoAnalyze) {
  ctx = ctx || {};
  if (!ctx.imageUrl) return Promise.resolve({ ok: false, error: '缺少右键图片' });
  setPill('contextState', '右键图片导入中...', '');
  $('refUrl').value = ctx.imageUrl;
  setRefImage(ctx.imageUrl, ctx.imageUrl);
  if (autoAnalyze && ($('apiKey') && $('apiKey').value.trim())) return analyzeCurrentImage();
  return Promise.resolve({ ok: true });
}

function openContextActionModal(ctx, autoAnalyze) {
  state.contextItem = ctx || null;
  state.contextAuto = !!autoAnalyze;
  var modal = $('contextActionModal');
  if (!modal) {
    applyContextImage(ctx, autoAnalyze);
    return;
  }
  modal.hidden = false;
  var first = $('contextImportBtn');
  if (first) first.focus();
}

function closeContextActionModal() {
  state.contextItem = null;
  var modal = $('contextActionModal');
  if (modal) modal.hidden = true;
}

function syncShareCardControls(source) {
  source = source || {};
  var values = {
    position: source.position,
    border: source.border,
    ratio: source.ratio
  };
  if (source.target && source.target.getAttribute) {
    values[source.target.getAttribute('data-share-card')] = source.target.value;
  }
  ['position', 'border', 'ratio'].forEach(function (key) {
    var controls = document.querySelectorAll('[data-share-card="' + key + '"]');
    var val = values[key];
    if (val == null && controls[0]) val = controls[0].value;
    controls.forEach(function (ctrl) {
      if (val != null) ctrl.value = val;
    });
  });
}

function shareCardValue(key, fallback) {
  var el = document.querySelector('[data-share-card="' + key + '"]');
  return (el && el.value) || fallback;
}

function shareCardConfig() {
  return {
    position: shareCardValue('position', 'top'),
    border: Math.max(0, Math.min(80, parseInt(shareCardValue('border', '36'), 10) || 36)),
    ratio: shareCardValue('ratio', '4:5')
  };
}

function shareCardSize(ratio) {
  if (ratio === '1:1') return { w: 1080, h: 1080 };
  if (ratio === '3:4') return { w: 1080, h: 1440 };
  return { w: 1080, h: 1350 };
}

function loadCanvasImage(url) {
  return fetch(url).then(function (r) {
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.blob();
  }).then(function (blob) {
    return new Promise(function (resolve, reject) {
      var objectUrl = URL.createObjectURL(blob);
      var img = new Image();
      img.onload = function () {
        URL.revokeObjectURL(objectUrl);
        resolve(img);
      };
      img.onerror = function () {
        URL.revokeObjectURL(objectUrl);
        reject(new Error('图片载入失败'));
      };
      img.src = objectUrl;
    });
  });
}

function roundRect(ctx, x, y, w, h, r) {
  r = Math.min(r || 0, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function drawImageFit(ctx, img, rect, mode) {
  var iw = img.naturalWidth || img.width;
  var ih = img.naturalHeight || img.height;
  var scale = mode === 'cover' ? Math.max(rect.w / iw, rect.h / ih) : Math.min(rect.w / iw, rect.h / ih);
  var sw = rect.w / scale;
  var sh = rect.h / scale;
  var sx = (iw - sw) / 2;
  var sy = (ih - sh) / 2;
  ctx.drawImage(img, sx, sy, sw, sh, rect.x, rect.y, rect.w, rect.h);
}

function wrapText(ctx, text, x, y, maxWidth, lineHeight, maxLines) {
  text = (text || '').replace(/\s+/g, ' ').trim();
  var line = '';
  var lines = 0;
  for (var i = 0; i < text.length; i++) {
    var test = line + text[i];
    if (ctx.measureText(test).width > maxWidth && line) {
      ctx.fillText(line, x, y);
      y += lineHeight;
      lines++;
      line = text[i];
      if (maxLines && lines >= maxLines - 1) break;
    } else {
      line = test;
    }
  }
  if (line && (!maxLines || lines < maxLines)) ctx.fillText(line, x, y);
}

function shareCardText(item) {
  var cn = ($('cnPrompt') && $('cnPrompt').value.trim()) || '';
  var en = ($('enPrompt') && $('enPrompt').value.trim()) || '';
  var prompt = cn || item.prompt || en || '高质感电商主图，主体清晰，背景克制，细节丰富。';
  return {
    title: item.variantName || item.variant || '提示词',
    prompt: prompt,
    negative: ($('negativePrompt') && $('negativePrompt').value.trim()) || ''
  };
}

function drawShareCopy(ctx, box, text, compact) {
  roundRect(ctx, box.x, box.y, box.w, box.h, 24);
  ctx.fillStyle = 'rgba(8, 15, 4, .92)';
  ctx.fill();
  ctx.fillStyle = '#f6c65f';
  ctx.font = compact ? '700 34px "PingFang SC", sans-serif' : '700 44px "PingFang SC", sans-serif';
  ctx.fillText(text.title || '提示词', box.x + 34, box.y + 52);
  ctx.fillStyle = '#f3edd7';
  ctx.font = compact ? '28px "PingFang SC", sans-serif' : '32px "PingFang SC", sans-serif';
  wrapText(ctx, text.prompt, box.x + 34, box.y + (compact ? 96 : 112), box.w - 68, compact ? 42 : 48, compact ? 7 : 9);
}

function buildShareCardBlob(item) {
  item = item || {};
  if (!item.url) return Promise.reject(new Error('没有图片可生成卡片'));
  var cfg = shareCardConfig();
  var size = shareCardSize(cfg.ratio);
  return loadCanvasImage(item.url).then(function (img) {
    var canvas = document.createElement('canvas');
    canvas.width = size.w;
    canvas.height = size.h;
    var ctx = canvas.getContext('2d');
    ctx.fillStyle = '#f5f1e7';
    ctx.fillRect(0, 0, size.w, size.h);
    var b = cfg.border;
    var inner = { x: b, y: b, w: size.w - b * 2, h: size.h - b * 2 };
    var text = shareCardText(item);
    if (cfg.position === 'left') {
      var mediaW = Math.round(inner.w * .56);
      roundRect(ctx, inner.x, inner.y, mediaW, inner.h, 28);
      ctx.save();
      ctx.clip();
      drawImageFit(ctx, img, { x: inner.x, y: inner.y, w: mediaW, h: inner.h }, 'cover');
      ctx.restore();
      drawShareCopy(ctx, { x: inner.x + mediaW + 20, y: inner.y, w: inner.w - mediaW - 20, h: inner.h }, text, true);
    } else if (cfg.position === 'full') {
      drawImageFit(ctx, img, { x: 0, y: 0, w: size.w, h: size.h }, 'cover');
      drawShareCopy(ctx, { x: b, y: size.h - Math.max(360, size.h * .32) - b, w: size.w - b * 2, h: Math.max(360, size.h * .32) }, text, true);
    } else {
      var mediaH = cfg.position === 'center' ? Math.round(inner.h * .68) : Math.round(inner.h * .58);
      roundRect(ctx, inner.x, inner.y, inner.w, mediaH, 28);
      ctx.save();
      ctx.clip();
      drawImageFit(ctx, img, { x: inner.x, y: inner.y, w: inner.w, h: mediaH }, cfg.position === 'center' ? 'contain' : 'cover');
      ctx.restore();
      var copyY = inner.y + mediaH + 20;
      drawShareCopy(ctx, { x: inner.x, y: copyY, w: inner.w, h: inner.y + inner.h - copyY }, text, false);
    }
    return new Promise(function (resolve, reject) {
      canvas.toBlob(function (blob) {
        if (blob) resolve(blob);
        else reject(new Error('卡片导出失败'));
      }, 'image/png');
    });
  });
}

function copyShareCardToClipboard(item) {
  if (!navigator.clipboard || !window.ClipboardItem) {
    setPill('generateState', '当前浏览器不支持复制卡片', 'warn');
    return;
  }
  setPill('generateState', '生成分享卡中...', '');
  buildShareCardBlob(item).then(function (blob) {
    return navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
  }).then(function () {
    setPill('generateState', '分享卡已复制', 'ok');
  }).catch(function (e) {
    setPill('generateState', '分享卡失败：' + ((e && e.message) || e), 'warn');
  });
}

function copyImageToClipboard(url) {
  if (!url) { setPill('generateState', '没有图片可复制', 'warn'); return; }
  if (!navigator.clipboard || !window.ClipboardItem) {
    setPill('generateState', '当前浏览器不支持复制图片', 'warn');
    return;
  }
  setPill('generateState', '复制图片中...', '');
  fetch(url).then(function (r) {
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.blob();
  }).then(blobToPngBlob).then(function (blob) {
    return navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
  }).then(function () {
    setPill('generateState', '图片已复制', 'ok');
  }).catch(function () {
    setPill('generateState', '复制图片失败', 'warn');
  });
}

function openGuideRegenerateModal(item) {
  item = item || {};
  if (!item.url) { setPill('generateState', '缺少引导图片', 'warn'); return; }
  state.guideItem = item;
  if ($('guidePrompt')) $('guidePrompt').value = resultGuidePrompt(item);
  if (item.negativePrompt) $('negativePrompt').value = item.negativePrompt;
  var modal = $('guideActionModal');
  if (modal) modal.hidden = false;
  if ($('guidePrompt')) $('guidePrompt').focus();
}

function closeGuideRegenerateModal() {
  state.guideItem = null;
  var modal = $('guideActionModal');
  if (modal) modal.hidden = true;
}

function runGuideRegenerate() {
  var item = state.guideItem || {};
  if (!item.url) { setPill('generateState', '缺少引导图片', 'warn'); return; }
  setRefImage(item.url, item.url);
  if (item.negativePrompt) $('negativePrompt').value = item.negativePrompt;
  closeGuideRegenerateModal();
  state.stopRequested = false;
  setStopAvailable(true);
  setPill('generateState', '引导重生中...', '');
  generateOne('guide', '引导重生', 1).then(function (resp) {
    setStopAvailable(false);
    setPill('generateState', resp && resp.ok ? '引导重生完成' : ((resp && resp.error) || '引导重生失败'), resp && resp.ok ? 'ok' : 'warn');
  });
}

function setStopAvailable(on) {
  var btn = $('stopGenerateBtn');
  if (!btn) return;
  btn.hidden = !on;
  btn.disabled = !on;
}

function newJobId() {
  return 'job_' + Date.now() + '_' + Math.random().toString(16).slice(2);
}

function stopGeneration() {
  state.stopRequested = true;
  if (state.activeJobId) {
    state.cancelledJobs[state.activeJobId] = true;
    send('CANCEL_GENERATION', { jobId: state.activeJobId });
  }
  setStopAvailable(false);
  setPill('generateState', '已终止', 'warn');
}

function generateOne(variant, variantName, countOverride) {
  if (state.stopRequested) return Promise.resolve({ ok: false, error: '已终止' });
  var prompt = generationPrompt(variant);
  if (!prompt.trim()) return Promise.resolve({ ok: false, error: '缺少提示词' });
  var jobId = newJobId();
  state.activeJobId = jobId;
  var productImages = productImageList();
  var productImage = productImages[0] || '';
  var negative = $('negativePrompt').value.trim();
  if (productImage) negative = [negative, replacementNegativePrompt()].filter(Boolean).join(', ');
  var payload = {
    prompt: prompt,
    negativePrompt: negative,
    referenceImage: state.refImage || normalizeImageUrl($('refUrl').value),
    productImage: productImage,
    productImages: productImages,
    size: $('imageSize').value,
    clarity: $('clarity').value,
    count: countOverride || $('imageCount').value,
    watermark: $('watermark').value,
    _jobId: jobId
  };
  return send('GENERATE_IMAGE', { jobId: jobId, config: cfgFromForm(), payload: payload }).then(function (resp) {
    if (state.activeJobId === jobId) state.activeJobId = '';
    if (state.stopRequested || state.cancelledJobs[jobId]) {
      delete state.cancelledJobs[jobId];
      return { ok: false, error: '已终止' };
    }
    if (resp && resp.ok && resp.images && resp.images.length) {
      resp.images.forEach(function (url) {
        state.results.push({
          url: url,
          variant: variant,
          variantName: variantName,
          taskId: resp.taskId || '',
          prompt: prompt,
          negativePrompt: negative
        });
      });
      renderResults();
    }
    return resp;
  });
}

function generateCurrent() {
  state.stopRequested = false;
  setStopAvailable(true);
  setPill('generateState', '生图中...', '');
  $('generateBtn').disabled = true;
  generateOne('single', '当前提示词', $('imageCount').value).then(function (resp) {
    $('generateBtn').disabled = false;
    setStopAvailable(false);
    setPill('generateState', resp && resp.ok ? '生成完成' : ((resp && resp.error) || '生成失败'), resp && resp.ok ? 'ok' : 'warn');
  });
}

function batchGenerate() {
  var variants = [
    ['main', '主图转化版'],
    ['scene', '场景种草版'],
    ['hook', '视觉锤版'],
    ['diff', '竞品差异化版']
  ];
  if ($('batchMode').value === 'single') variants = [['single', '当前提示词']];
  state.stopRequested = false;
  setStopAvailable(true);
  setPill('generateState', '批量生成中 0/' + variants.length, '');
  $('batchBtn').disabled = true;
  var i = 0;
  function next() {
    if (state.stopRequested) {
      $('batchBtn').disabled = false;
      setStopAvailable(false);
      setPill('generateState', '已终止', 'warn');
      return;
    }
    if (i >= variants.length) {
      $('batchBtn').disabled = false;
      setStopAvailable(false);
      setPill('generateState', '批量完成，共 ' + state.results.length + ' 张', 'ok');
      return;
    }
    var v = variants[i++];
    setPill('generateState', '批量生成中 ' + (i - 1) + '/' + variants.length + '：' + v[1], '');
    generateOne(v[0], v[1], 1).then(function (resp) {
      if (!resp || !resp.ok) setPill('generateState', '部分失败：' + ((resp && resp.error) || '未知错误'), 'warn');
      next();
    });
  }
  next();
}

function clampInt(value, min, max, fallback) {
  var n = parseInt(value, 10);
  if (!isFinite(n)) n = fallback;
  return Math.max(min, Math.min(max, n));
}

function setBatchLinksBusy(on) {
  if ($('batchLinksBtn')) $('batchLinksBtn').disabled = !!on;
  if ($('buildPromptBtn')) $('buildPromptBtn').disabled = !!on;
  if ($('generateBtn')) $('generateBtn').disabled = !!on;
  if ($('batchBtn')) $('batchBtn').disabled = !!on;
}

function readBatchLinkRows() {
  var rows = [];
  try { rows = parseLinkListInput(); } catch (e) { throw e; }
  if (!rows.length) {
    var single = parseLinkJson();
    rows = [single];
  }
  state.linkList = rows;
  return rows;
}

function batchLinksPromptAndGenerate() {
  var rows;
  try { rows = readBatchLinkRows(); } catch (e) { setPill('runState', e.message, 'warn'); return; }
  if (!rows.length) { setPill('runState', '没有可处理的链接清单', 'warn'); return; }
  var productImages = productImageList();
  if (!productImages.length) {
    setPill('generateState', '请先上传或粘贴产品主体图', 'warn');
    return;
  }
  syncPrimaryProductImage();
  var rangeSelection = selectRowsByLinkRange(rows);
  var selected = rangeSelection.rows;
  if (!selected.length) {
    setPill('linkState', '没有匹配 ' + rangeSelection.label + ' 的链接', 'warn');
    setPill('generateState', '请检查链接编号范围', 'warn');
    return;
  }
  var perLink = clampInt($('batchImagesPerLink') && $('batchImagesPerLink').value, 1, 4, 1);
  if ($('imageCount')) $('imageCount').value = perLink;
  var before = state.results.length;
  var index = 0;
  state.stopRequested = false;
  setStopAvailable(true);
  setBatchLinksBusy(true);
  setPill('linkState', '批量队列 ' + rangeSelection.label + '，共 ' + selected.length + ' 条', 'ok');
  setPill('generateState', '批量准备中...', '');

  function finish(text, kind) {
    setBatchLinksBusy(false);
    setStopAvailable(false);
    setPill('generateState', text, kind);
  }

  function next() {
    if (state.stopRequested) {
      finish('已终止，已生成 ' + Math.max(0, state.results.length - before) + ' 张', 'warn');
      return;
    }
    if (index >= selected.length) {
      finish('批量完成：' + rangeSelection.label + '，' + selected.length + ' 条链接，新增 ' + Math.max(0, state.results.length - before) + ' 张', 'ok');
      return;
    }
    var row = Object.assign({}, selected[index]);
    var label = linkRowLabel(row, index);
    index++;
    setPill('runState', '链接提词 ' + index + '/' + selected.length + '：' + label, '');
    buildPromptForLink(row, label, { silent: true }).then(function (resp) {
      if (state.stopRequested) { next(); return; }
      if (!resp || !resp.ok) {
        setPill('runState', '跳过 ' + label + '：' + ((resp && resp.error) || '提词失败'), 'warn');
        next();
        return;
      }
      setPill('generateState', '链接生图 ' + index + '/' + selected.length + '：' + label + '（' + perLink + ' 张）', '');
      generateOne('single', label, perLink).then(function (genResp) {
        if (!genResp || !genResp.ok) setPill('generateState', '部分失败：' + label + '，' + ((genResp && genResp.error) || '生图失败'), 'warn');
        next();
      });
    });
  }
  next();
}

function copyText(text, stateId) {
  navigator.clipboard.writeText(text || '').then(function () {
    setPill(stateId || 'runState', '已复制', 'ok');
  }).catch(function () {
    setPill(stateId || 'runState', '复制失败', 'warn');
  });
}

function loadStoredLinks() {
  return new Promise(function (resolve) {
    try {
      chrome.storage.local.get([LINKMATRIX_JSON_KEY], function (r) {
        var saved = r && r[LINKMATRIX_JSON_KEY];
        var rows = normalizeLinkRows(saved);
        if (!rows.length) {
          setPill('linkState', '暂无缓存链接', 'warn');
          resolve({ ok: false, error: '暂无缓存链接' });
          return;
        }
        $('linkJson').value = JSON.stringify(rows, null, 2);
        applyLinkToFields(rows, true);
        syncBatchRangeDefaults(rows, false);
        setPill('linkState', '已载入 ' + rows.length + ' 条链接', 'ok');
        resolve({ ok: true, rows: rows });
      });
    } catch (e) {
      setPill('linkState', '载入失败', 'warn');
      resolve({ ok: false, error: (e && e.message) || e });
    }
  });
}

function loadContext(auto) {
  send('GET_CONTEXT').then(function (r) {
    if (!r || !r.ok) return;
    var normalized = applyCfg(r.config);
    if (JSON.stringify(normalized) !== JSON.stringify(Object.assign({}, DEFAULT_CFG, r.config || {}))) {
      send('SAVE_CONFIG', { config: normalized });
      setPill('configState', '已自动迁移旧豆包模型', 'ok');
    }
    if (r.context && r.context.imageUrl) {
      var params = new URLSearchParams(location.search);
      if (params.get('source') === 'context') {
        openContextActionModal(r.context, auto && (r.config && r.config.apiKey));
        return;
      }
      setPill('contextState', '右键图片导入中...', '');
      $('refUrl').value = r.context.imageUrl;
      setRefImage(r.context.imageUrl, r.context.imageUrl);
      if (auto && (r.config && r.config.apiKey)) analyzeCurrentImage();
    }
  });
}

function bind() {
  if ($('openConfigBtn')) $('openConfigBtn').addEventListener('click', openConfigModal);
  $('saveConfigBtn').addEventListener('click', saveCfg);
  if ($('configCloseBtn')) $('configCloseBtn').addEventListener('click', closeConfigModal);
  if ($('configCancelBtn')) $('configCancelBtn').addEventListener('click', closeConfigModal);
  if ($('configModal')) $('configModal').addEventListener('click', function (ev) {
    if (ev.target === $('configModal')) closeConfigModal();
  });
  $('loadSampleBtn').addEventListener('click', function () { applyLinkToFields(sampleLink); });
  $('provider').addEventListener('change', function () {
    applyProviderPreset($('provider').value);
    setPill('configState', '已切换预设，记得保存', '');
  });
  $('refFile').addEventListener('change', function (ev) {
    var f = ev.target.files && ev.target.files[0];
    if (!f) return;
    setPill('contextState', '压缩参考图中...', '');
    fileToOptimizedDataUrl(f).then(function (url) { setRefImage(url, ''); });
  });
  Object.keys(PRODUCT_ANGLES).forEach(function (kind) {
    var meta = PRODUCT_ANGLES[kind];
    if ($(meta.file)) $(meta.file).addEventListener('change', function (ev) {
      var f = ev.target.files && ev.target.files[0];
      if (!f) return;
      setPill('contextState', '压缩' + meta.label + '中...', '');
      fileToOptimizedDataUrl(f).then(function (url) { setProductAngle(kind, url, ''); });
    });
    if ($(meta.url)) $(meta.url).addEventListener('change', function () {
      setProductAngle(kind, normalizeImageUrl($(meta.url).value), $(meta.url).value);
    });
    var clearBtn = $('clearProduct' + kind.charAt(0).toUpperCase() + kind.slice(1) + 'Btn');
    if (clearBtn) clearBtn.addEventListener('click', function () {
      setProductAngle(kind, '', '');
      if ($(meta.file)) $(meta.file).value = '';
    });
  });
  $('refUrl').addEventListener('change', function () { setRefImage(normalizeImageUrl($('refUrl').value), $('refUrl').value); });
  $('clearRefBtn').addEventListener('click', function () { setRefImage('', ''); $('refFile').value = ''; });
  $('analyzeBtn').addEventListener('click', analyzeCurrentImage);
  $('buildPromptBtn').addEventListener('click', buildLinkPrompt);
  if ($('batchLinksBtn')) $('batchLinksBtn').addEventListener('click', batchLinksPromptAndGenerate);
  if ($('loadStoredLinksBtn')) $('loadStoredLinksBtn').addEventListener('click', loadStoredLinks);
  $('generateBtn').addEventListener('click', generateCurrent);
  $('batchBtn').addEventListener('click', batchGenerate);
  $('stopGenerateBtn').addEventListener('click', stopGeneration);
  $('copyCnBtn').addEventListener('click', function () { copyText($('cnPrompt').value); });
  $('copyEnBtn').addEventListener('click', function () { copyText($('enPrompt').value); });
  $('copyAllPromptBtn').addEventListener('click', function () {
    copyText(['中文提示词：', $('cnPrompt').value, '', 'English Prompt:', $('enPrompt').value, '', '负面提示词：', $('negativePrompt').value].join('\n'));
  });
  $('downloadAllBtn').addEventListener('click', function () {
    send('DOWNLOAD_ALL', { urls: state.results.map(function (r) { return r.url; }) }).then(function (r) {
      setPill('generateState', r && r.ok ? ('开始下载 ' + r.count + ' 张') : ((r && r.error) || '下载失败'), r && r.ok ? 'ok' : 'warn');
    });
  });
  $('clearResultsBtn').addEventListener('click', function () { state.results = []; renderResults(); setPill('generateState', '未生成', ''); });
  if ($('copyOriginalImageBtn')) $('copyOriginalImageBtn').addEventListener('click', function () {
    var item = state.actionItem;
    closeImageActionModal();
    copyImageToClipboard(item && item.url);
  });
  if ($('copyShareCardBtn')) $('copyShareCardBtn').addEventListener('click', function () {
    var item = state.actionItem;
    closeImageActionModal();
    copyShareCardToClipboard(item);
  });
  if ($('imageActionClose')) $('imageActionClose').addEventListener('click', closeImageActionModal);
  if ($('imageActionModal')) $('imageActionModal').addEventListener('click', function (ev) {
    if (ev.target === $('imageActionModal')) closeImageActionModal();
  });
  if ($('guideRunBtn')) $('guideRunBtn').addEventListener('click', runGuideRegenerate);
  if ($('guideCancelBtn')) $('guideCancelBtn').addEventListener('click', closeGuideRegenerateModal);
  if ($('guideActionClose')) $('guideActionClose').addEventListener('click', closeGuideRegenerateModal);
  if ($('guideActionModal')) $('guideActionModal').addEventListener('click', function (ev) {
    if (ev.target === $('guideActionModal')) closeGuideRegenerateModal();
  });
  if ($('contextImportBtn')) $('contextImportBtn').addEventListener('click', function () {
    var ctx = state.contextItem;
    var auto = state.contextAuto;
    closeContextActionModal();
    applyContextImage(ctx, auto);
  });
  if ($('contextShareCardBtn')) $('contextShareCardBtn').addEventListener('click', function () {
    var ctx = state.contextItem;
    closeContextActionModal();
    if (!$('apiKey') || !$('apiKey').value.trim()) {
      setPill('runState', '生成分享卡前需要先配置 API Key', 'warn');
      return;
    }
    applyContextImage(ctx, true).then(function (resp) {
      if (resp && resp.ok) {
        copyShareCardToClipboard({ url: ctx && ctx.imageUrl, variantName: '提示词分享卡', prompt: $('cnPrompt').value || $('enPrompt').value });
      }
    });
  });
  if ($('contextActionClose')) $('contextActionClose').addEventListener('click', closeContextActionModal);
  if ($('contextActionModal')) $('contextActionModal').addEventListener('click', function (ev) {
    if (ev.target === $('contextActionModal')) closeContextActionModal();
  });
  document.querySelectorAll('[data-share-card]').forEach(function (ctrl) {
    ctrl.addEventListener('change', function (ev) { syncShareCardControls(ev); });
    ctrl.addEventListener('input', function (ev) { syncShareCardControls(ev); });
  });
  syncShareCardControls({ position: 'top', border: '36', ratio: '4:5' });
  $('linkJson').addEventListener('change', function () {
    try { applyLinkToFields(parseLinkListInput(), true); } catch (e) { setPill('linkState', 'JSON 待修正', 'warn'); }
  });
  document.addEventListener('paste', function (ev) {
    var items = ev.clipboardData && ev.clipboardData.items;
    if (!items) return;
    for (var i = 0; i < items.length; i++) {
      if (items[i] && items[i].type && items[i].type.indexOf('image/') === 0) {
        ev.preventDefault();
        var file = items[i].getAsFile();
        if (!file) return;
        var activeId = document.activeElement && document.activeElement.id;
        setPill('contextState', '压缩粘贴图片中...', '');
        fileToOptimizedDataUrl(file).then(function (url) {
          var matched = '';
          Object.keys(PRODUCT_ANGLES).some(function (kind) {
            if (PRODUCT_ANGLES[kind].url === activeId) { matched = kind; return true; }
            return false;
          });
          if (matched) setProductAngle(matched, url, '');
          else setRefImage(url, '');
        });
        return;
      }
    }
  });
}

document.addEventListener('DOMContentLoaded', function () {
  bind();
  renderResults();
  var params = new URLSearchParams(location.search);
  loadContext(params.get('auto') === '1');
  if (params.get('source') === 'linkmatrix') loadStoredLinks();
});
