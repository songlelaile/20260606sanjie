(function (root, factory) {
  'use strict';
  var contract = factory();
  if (typeof module === 'object' && module.exports) module.exports = contract;
  if (root) root.SZ_STYLE_REFRESH_CONTRACT = contract;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var VERSION = 'STYLE_REFRESH_V4';
  var STRENGTHS = Object.freeze({
    stable: Object.freeze({ id: 'stable', name: '稳妥焕新', redesignTarget: 45, rule: '保留熟悉的电商构图，只升级背景、光影、留白和材质质感。' }),
    commercial: Object.freeze({ id: 'commercial', name: '商业升级', redesignTarget: 68, rule: '在商品身份不变的前提下明显重构场景、镜头、光影和视觉秩序。' }),
    breakthrough: Object.freeze({ id: 'breakthrough', name: '破圈创意', redesignTarget: 86, rule: '允许大胆尺度、空间与艺术化表达，但不得改变商品本体或妨碍商品识别。' })
  });

  var COPY_MODES = Object.freeze({
    none: Object.freeze({ id: 'none', name: '不要文案' }),
    generate: Object.freeze({ id: 'generate', name: '生成新文案' }),
    rewrite: Object.freeze({ id: 'rewrite', name: '修改已有文案' })
  });

  var STYLES = Object.freeze([
    Object.freeze({ id: 'gallery-white', name: '白盒美术馆', group: '高级棚拍', tags: ['服装', '鞋履', '箱包', '配饰', '珠宝'], fit: ['服装', '鞋', '包', '首饰', '饰品', '金属'], visual: '纯净暖白展厅、雕塑式留白、柔和顶侧光、低饱和阴影、克制高级的艺术陈列' }),
    Object.freeze({ id: 'architectural-pedestal', name: '建筑基座', group: '高级棚拍', tags: ['鞋履', '箱包', '家居', '配饰'], fit: ['鞋', '包', '家居', '皮革', '金属'], visual: '几何建筑台座、硬朗空间切面、斜向日光、清晰体块与秩序感' }),
    Object.freeze({ id: 'tactile-fabric', name: '柔感织物', group: '材质叙事', tags: ['服装', '家纺', '软包', '配饰'], fit: ['服装', '家纺', '布艺', '针织', '棉', '羊毛', '丝'], visual: '层叠织物背景、柔软褶皱、近距离触感、漫射窗光、温和浅色调' }),
    Object.freeze({ id: 'obsidian-luxury', name: '黑曜奢品', group: '高级棚拍', tags: ['珠宝', '腕表', '皮具', '香氛'], fit: ['珠宝', '首饰', '腕表', '皮革', '金属', '玻璃'], visual: '深黑镜面与黑曜石、精确轮廓光、金属高光、低调奢华、戏剧化暗部' }),
    Object.freeze({ id: 'hard-flash-editorial', name: '硬闪编辑', group: '潮流编辑', tags: ['服装', '鞋履', '眼镜', '配饰'], fit: ['服装', '鞋', '眼镜', '帽', '饰品'], visual: '杂志硬闪、锐利投影、近景裁切、轻微颗粒、直接而时髦的编辑感' }),
    Object.freeze({ id: 'film-street', name: '胶片街拍', group: '潮流编辑', tags: ['服装', '鞋履', '箱包', '配饰'], fit: ['服装', '鞋', '包', '帽', '眼镜'], visual: '城市街角、自然抓拍、胶片颗粒、真实环境光、松弛生活方式氛围' }),
    Object.freeze({ id: 'kinetic-freeze', name: '动态冻结', group: '运动能量', tags: ['运动服', '鞋履', '户外', '配饰'], fit: ['运动', '鞋', '户外', '尼龙', '机能'], visual: '高速动作冻结、风感与颗粒飞溅、强方向光、倾斜构图、清晰能量轨迹' }),
    Object.freeze({ id: 'surreal-scale', name: '超现实巨物', group: '创意实验', tags: ['箱包', '鞋履', '配饰', '潮玩'], fit: ['包', '鞋', '饰品', '潮玩'], visual: '超现实尺度反差、微缩人物或巨物空间、清楚商品轮廓、电影化景深与想象力' }),
    Object.freeze({ id: 'color-block', name: '色块平面', group: '平面设计', tags: ['服装', '鞋履', '配饰', '美妆'], fit: ['服装', '鞋', '饰品', '彩色', '美妆'], visual: '大面积色块、图形切割、平面构成、清晰负空间、强识别但无文字的海报语言' }),
    Object.freeze({ id: 'liquid-metal', name: '液态金属', group: '创意实验', tags: ['珠宝', '眼镜', '科技配饰', '鞋履'], fit: ['珠宝', '首饰', '眼镜', '金属', '科技', '鞋'], visual: '流动银色金属、镜面反射、冷色光晕、未来感材质、精致高光控制' }),
    Object.freeze({ id: 'local-craft', name: '在地手作', group: '生活方式', tags: ['服装', '编织', '家居', '配饰'], fit: ['服装', '编织', '木', '陶', '棉麻', '手作'], visual: '手作工作台、自然材料、暖色侧光、真实细节、质朴但精致的在地文化气息' }),
    Object.freeze({ id: 'natural-sunlight', name: '自然日照', group: '生活方式', tags: ['服装', '鞋履', '箱包', '家居'], fit: ['服装', '鞋', '包', '家居', '棉麻', '皮革'], visual: '居家或建筑空间自然日照、真实阴影、轻松呼吸感、柔和暖色、可信生活场景' })
  ]);

  var DEFAULT_DIRECTIONS = Object.freeze([
    Object.freeze({ id: 'hero', name: '英雄主图', axis: '构图与空间', brief: '以商品为绝对主角建立第一眼识别，轮廓完整，留白清楚，适合作为电商首图或传播封面。' }),
    Object.freeze({ id: 'material', name: '材质特写', axis: '镜头与质感', brief: '用近景或局部放大证明材质、工艺、纹理和边缘细节，同时保留足够整体信息用于确认同款。' }),
    Object.freeze({ id: 'interaction', name: '自然互动', axis: '场景与动作', brief: '在合理使用场景中加入自然手部、身体局部或环境互动，表达尺度与使用关系，不喧宾夺主。' }),
    Object.freeze({ id: 'concept', name: '创意场景', axis: '概念与道具', brief: '使用符合所选风格的空间、道具或尺度创意形成传播记忆点，商品结构仍必须真实可辨。' }),
    Object.freeze({ id: 'angle', name: '角度新解', axis: '机位与透视', brief: '选择不同于常规正面的俯拍、低机位或侧向透视，保持产品比例和结构不变。' }),
    Object.freeze({ id: 'rhythm', name: '节奏构成', axis: '排列与节奏', brief: '用单商品多层空间关系或克制重复元素形成平面节奏，不复制出错误商品数量。' }),
    Object.freeze({ id: 'light', name: '光影实验', axis: '光线与色温', brief: '通过明确主光、轮廓光或投影结构塑造不同情绪，避免遮盖商品颜色与关键结构。' }),
    Object.freeze({ id: 'environment', name: '环境叙事', axis: '生活方式', brief: '把商品放进可信但具有审美完成度的环境，表达目标人群与生活方式。' })
  ]);

  function text(value) { return String(value == null ? '' : value).trim(); }
  function clampOutputCount(value) {
    var n = parseInt(value, 10);
    return isFinite(n) ? Math.max(1, Math.min(8, n)) : 4;
  }
  function styleById(id) {
    id = text(id);
    return STYLES.filter(function (style) { return style.id === id; })[0] || STYLES[0];
  }
  function strengthById(id) { return STRENGTHS[text(id)] || STRENGTHS.commercial; }
  function normalizeStyleSource(value) { return text(value).toLowerCase() === 'custom' ? 'custom' : 'library'; }
  function normalizeCopyMode(value) {
    value = text(value).toLowerCase();
    if (value === 'generate') return 'generate';
    if (value === 'rewrite' || value === 'retain') return 'rewrite';
    return 'none';
  }

  function copyStyleProfile(styleId) {
    var style = styleById(styleId);
    var profiles = {
      'gallery-white': ['克制、高级、策展式短句', '现代无衬线或高对比衬线感', '大留白、疏字距、左下或边缘对齐'],
      'architectural-pedestal': ['理性、结构化、精确有力', '几何无衬线粗体', '沿建筑切面网格对齐'],
      'tactile-fabric': ['柔和、感官化、贴近材质', '轻盈人文无衬线或柔和衬线感', '小尺度、呼吸留白、避免压住纹理'],
      'obsidian-luxury': ['极简、稀缺感、奢品语气', '高对比衬线或精细窄体', '少字、宽字距、暗部边缘排布'],
      'hard-flash-editorial': ['直接、时髦、杂志标题感', '粗体窄字或编辑体', '大胆裁切、错位层级、避免遮挡商品'],
      'film-street': ['松弛、真实、生活方式口吻', '自然手写感或简洁杂志体', '像街拍注释般克制排布'],
      'kinetic-freeze': ['短促、动势强、能量感', '倾斜粗体或运动无衬线', '顺应运动轨迹、强节奏层级'],
      'surreal-scale': ['概念化、带反差、记忆点优先', '超大展示字或实验排版', '利用尺度反差形成标题空间'],
      'color-block': ['清晰、图形化、品牌识别强', '几何粗体无衬线', '与色块网格一体化排版'],
      'liquid-metal': ['未来、冷静、科技奢感', '细窄科技无衬线', '沿反射与光晕边缘克制排布'],
      'local-craft': ['真诚、温暖、有手作温度', '人文衬线或自然手写感', '贴近材料与工作台关系排布'],
      'natural-sunlight': ['自然、可信、轻生活叙事', '友好现代无衬线', '顺应窗光与空间留白排布']
    };
    var profile = profiles[style.id] || ['简洁、可信、商业清晰', '现代无衬线', '不遮挡商品的稳定留白区'];
    return Object.freeze({ tone: profile[0], typography: profile[1], layout: profile[2] });
  }

  function copyStrategy(input) {
    input = input || {};
    var mode = normalizeCopyMode(input.copyMode);
    var strength = strengthById(input.strength);
    var custom = normalizeStyleSource(input.styleSource) === 'custom';
    var customName = text(input.customStyleName) || '自由共创风格';
    var profile = custom
      ? Object.freeze({
        tone: '贴合' + customName + '视觉描述的原创语气',
        typography: '根据用户自定义视觉描述推导字体气质，保持清晰可读',
        layout: '根据用户自定义构图与留白要求排布，不遮挡商品主体'
      })
      : copyStyleProfile(input.styleId);
    var strengthRule = strength.id === 'stable'
      ? '一句短标题为主，建议4-10个汉字，画面占比约8%-12%，不使用夸张口号。'
      : (strength.id === 'breakthrough'
        ? '允许强标题与一条短副标题，画面占比约18%-28%，表达可更具反差与记忆点，但必须易读且不遮挡商品。'
        : '一条核心标题，可选一条短副标题，画面占比约12%-20%，突出单一利益点并保持商业清晰。');
    return Object.freeze({
      mode: mode,
      modeName: COPY_MODES[mode].name,
      tone: profile.tone,
      typography: profile.typography,
      layout: profile.layout,
      densityRule: strengthRule,
      source: text(input.copySource),
      instruction: text(input.copyInstruction)
    });
  }

  function recommendStyles(category, material, limit) {
    var haystack = (text(category) + ' ' + text(material)).toLowerCase();
    limit = Math.max(1, Math.min(6, parseInt(limit, 10) || 3));
    return STYLES.map(function (style, index) {
      var score = 0;
      style.fit.forEach(function (token) { if (haystack.indexOf(String(token).toLowerCase()) >= 0) score += 8; });
      style.tags.forEach(function (token) { if (haystack.indexOf(String(token).toLowerCase()) >= 0) score += 4; });
      if (!haystack) score = index === 0 ? 3 : (index === 11 ? 2 : 0);
      return { style: style, score: score, index: index };
    }).sort(function (a, b) { return b.score - a.score || a.index - b.index; }).slice(0, limit).map(function (entry, rank) {
      return Object.freeze({ id: entry.style.id, name: entry.style.name, group: entry.style.group, visual: entry.style.visual, rank: rank + 1, reason: entry.score > 0 ? '与当前品类/材质匹配' : '通用商业安全起点' });
    });
  }

  function directionSpecs(count, productName) {
    count = clampOutputCount(count);
    productName = text(productName) || '目标商品';
    return Array.apply(null, Array(count)).map(function (_, index) {
      var base = DEFAULT_DIRECTIONS[index] || DEFAULT_DIRECTIONS[index % DEFAULT_DIRECTIONS.length];
      return Object.freeze({
        index: index + 1,
        id: base.id,
        name: base.name,
        axis: base.axis,
        brief: productName + '：' + base.brief
      });
    });
  }

  function createConfig(input) {
    input = input || {};
    var styleSource = normalizeStyleSource(input.styleSource);
    var libraryStyle = styleById(input.styleId);
    var customName = text(input.customStyleName) || '自由共创风格';
    var customVisual = text(input.customStyleVisual);
    var customAvoid = text(input.customStyleAvoid);
    var style = styleSource === 'custom'
      ? { id: 'custom-user', name: customName, group: 'V3 自由共创', visual: customVisual || '等待用户填写自定义视觉描述' }
      : libraryStyle;
    var strength = strengthById(input.strength);
    var copy = copyStrategy(input);
    var outputCount = clampOutputCount(input.outputCount == null ? input.screenCount : input.outputCount);
    return Object.freeze({
      version: VERSION,
      routeId: 'style-refresh',
      routeName: '风格焕新',
      styleSource: styleSource,
      styleSourceName: styleSource === 'custom' ? 'V3 自由共创' : '经典风格库',
      styleId: style.id,
      styleName: style.name,
      styleGroup: style.group,
      styleVisual: style.visual,
      customStyleName: styleSource === 'custom' ? customName : '',
      customStyleVisual: styleSource === 'custom' ? customVisual : '',
      customStyleAvoid: styleSource === 'custom' ? customAvoid : '',
      strength: strength.id,
      strengthName: strength.name,
      redesignTarget: strength.redesignTarget,
      copyMode: copy.mode,
      copyModeName: copy.modeName,
      copySource: copy.source,
      copyInstruction: copy.instruction,
      copyTone: copy.tone,
      copyTypography: copy.typography,
      copyLayout: copy.layout,
      copyDensityRule: copy.densityRule,
      outputCount: outputCount,
      category: text(input.category),
      material: text(input.material),
      productConsistencyMode: 'strict_same_sku',
      productIdentityPriority: 100,
      qaGate: Object.freeze({ identityMin: 86, styleMin: 75, copyMin: 75, copyViolationMax: 0 })
    });
  }

  function promptRules(input) {
    var cfg = createConfig(input);
    var copyRule = cfg.copyMode === 'none'
      ? '用户选择不要文案：画面必须完全无营销文案，禁止新增标题、副标题、价格、参数、字母、数字、水印和伪文字；商品本身真实存在的品牌标识与包装文字必须保持原样，不得新增或改写。'
      : (cfg.copyMode === 'rewrite'
        ? '用户选择修改已有文案：原文案为“' + (cfg.copySource || '未填写') + '”；修改要求为“' + (cfg.copyInstruction || '在事实不变的前提下优化表达') + '”。必须明确替换原文案，不得同时保留新旧两版，不得臆造参数、功效、价格或品牌。'
        : '用户选择生成新文案：依据当前商品事实与“' + (cfg.copySource || '未指定必含卖点') + '”生成新文案；附加要求为“' + (cfg.copyInstruction || '无') + '”。不得臆造参数、功效、价格、销量、认证或品牌。');
    return [
      'STYLE REFRESH CONTRACT ' + VERSION + '：当前路线为“风格焕新”，不得读取或混入“案例裂变”的图1参考、分析结果或提示词。',
      '商品身份最高优先级：上传的商品主体图是唯一事实来源。100%保持同一SKU的结构、比例、颜色、材质、部件、图案、包装、数量和可见细节；任何风格创意都不得改款。',
      '所选风格：' + cfg.styleName + ' / ' + cfg.styleGroup + '。视觉定义：' + cfg.styleVisual + '。',
      cfg.styleSource === 'custom' ? 'V3备选来源：这是用户直接填写的自由共创方案，不是案例裂变参考，也不得读取案例图、案例分析或案例提示词。避让要求：' + (cfg.customStyleAvoid || '无额外要求；继续遵守商品保真与商业真实性边界。') : '',
      '创意强度：' + cfg.strengthName + '，目标重设计强度约 ' + cfg.redesignTarget + '%。' + strengthById(cfg.strength).rule,
      copyRule,
      cfg.copyMode === 'none' ? '' : '文案视觉方式必须同时参考风格与强度：语气=' + cfg.copyTone + '；字体气质=' + cfg.copyTypography + '；排版=' + cfg.copyLayout + '；密度与冲击力=' + cfg.copyDensityRule,
      '每次请求只生成一张独立完整图片，禁止九宫格、拼图、对比合集、分镜编号和多图合成。整组共享同一风格语言，但每张在构图、镜头、场景、互动、道具或光影中至少三项不同。',
      '不得凭空增加商品数量，不得用参考风格中的旧商品替换目标商品，不得夸大材质、功能或使用效果。'
    ].filter(Boolean).join('\n');
  }

  function createPlan(input) {
    var cfg = createConfig(input);
    var productName = text(input && input.productName) || '目标商品';
    var directions = directionSpecs(cfg.outputCount, productName);
    return Object.freeze({
      config: cfg,
      screens: Object.freeze(directions.map(function (direction) {
        return Object.freeze({
          屏幕: direction.index,
          名称: direction.name,
          焕新方向: direction.axis,
          视觉风格: cfg.styleName + '：' + cfg.styleVisual,
          创意强度: cfg.strengthName,
          画面任务: direction.brief,
          文案规则: cfg.copyMode === 'none'
            ? '不要文案；不新增营销文字，商品原有标识保持真实'
            : (cfg.copyMode === 'rewrite'
              ? '修改已有文案“' + (cfg.copySource || '未填写') + '”；' + (cfg.copyInstruction || '按当前风格与强度优化表达')
              : '生成新文案；必含信息=' + (cfg.copySource || '仅使用已确认商品事实') + '；' + (cfg.copyInstruction || '按当前风格与强度生成')),
          文案风格: cfg.copyMode === 'none' ? '不适用' : cfg.copyTone + '；' + cfg.copyTypography,
          文案排版: cfg.copyMode === 'none' ? '不适用' : cfg.copyLayout + '；' + cfg.copyDensityRule,
          商品保真: '严格锁定上传主体图中的同一SKU；结构、比例、颜色、材质、部件、图案、包装、数量全部不变',
          质检门槛: cfg.copyMode === 'none' ? '商品保真≥86；风格命中≥75；新增营销文字违规必须为0' : '商品保真≥86；风格命中≥75；文案达成≥75'
        });
      }))
    });
  }

  function qaStatus(input) {
    input = input || {};
    var identity = Number(input.identityScore) || 0;
    var style = Number(input.styleScore) || 0;
    var copyViolation = Math.max(0, Number(input.copyViolationCount) || 0);
    var mode = normalizeCopyMode(input.copyMode);
    var copyScore = Number(input.copyScore);
    if (!isFinite(copyScore)) copyScore = mode === 'none' && copyViolation === 0 ? 100 : 0;
    if (identity < 70 || (mode === 'none' && copyViolation > 0) || (mode !== 'none' && copyScore < 50)) return 'failed';
    if (identity >= 86 && style >= 75 && (mode === 'none' ? copyViolation === 0 : copyScore >= 75)) return 'passed';
    return 'review';
  }

  return Object.freeze({
    version: VERSION,
    config: Object.freeze({ defaultOutputCount: 4, minOutputCount: 1, maxOutputCount: 8, defaultStyleSource: 'library', defaultStyleId: 'gallery-white', defaultStrength: 'commercial', defaultCopyMode: 'none' }),
    styles: STYLES,
    strengths: STRENGTHS,
    copyModes: COPY_MODES,
    styleById: styleById,
    strengthById: strengthById,
    normalizeStyleSource: normalizeStyleSource,
    clampOutputCount: clampOutputCount,
    normalizeCopyMode: normalizeCopyMode,
    copyStyleProfile: copyStyleProfile,
    copyStrategy: copyStrategy,
    recommendStyles: recommendStyles,
    directionSpecs: directionSpecs,
    createConfig: createConfig,
    createPlan: createPlan,
    promptRules: promptRules,
    qaStatus: qaStatus
  });
});
