'use strict';

(function () {
  var KB = globalThis.SZBusinessKnowledge;
  var MAX_FILE_BYTES = 10 * 1024 * 1024;
  var MAX_TOTAL_BYTES = 30 * 1024 * 1024;
  var state = {
    record: KB ? KB.normalize({}) : {}, sources: [], accountKey: 'local', loading: false,
    obsidian: null, obsidianContext: '', obsidianSources: [], obsidianMeta: null, wizardStep: 1,
    obsidianDraftDirty: { baseUrl: false, folder: false, maxNotes: false, apiKey: false, legacyDefaults: false },
    obsidianDraftRevision: 0
  };
  var ids = [
    'accountState', 'saveState', 'sourceFiles', 'sourceList', 'sourceCount', 'kbName', 'kbEnabled',
    'scopeLink', 'scopeMain', 'scopeDetail', 'contextPreview', 'contextCount', 'saveBtn', 'exportBtn', 'clearBtn', 'hint',
    'saveActionState', 'saveActionTitle', 'saveActionText', 'saveFeedback',
    'fieldProduct', 'fieldBrand', 'fieldCategory', 'fieldAudience', 'fieldScenarios', 'fieldBenefits', 'fieldDifferentiation',
    'fieldTone', 'fieldVisual', 'fieldCompliance', 'obsidianState', 'obsidianBaseUrl', 'obsidianFolder',
    'obsidianMaxNotes', 'obsidianApiKey', 'obsidianEnabled', 'toggleObsidianKey', 'connectObsidianBtn',
    'obsidianKeyStatus', 'saveObsidianKeyBtn', 'deleteObsidianKeyBtn',
    'previewObsidianBtn', 'disconnectObsidianBtn', 'openObsidianCertBtn', 'obsidianHint', 'obsidianSources',
    'obsidianPreviewScope', 'obsidianCertificateGuide', 'checkObsidianCertBtn', 'copyObsidianUrlBtn', 'obsidianTrace',
    'obsidianApplicationState', 'obsidianConclusion', 'obsidianProcess', 'obsidianProductionOrder', 'obsidianHighlights',
    'legacyModeProduct', 'legacyModeBrand', 'legacyModeGlobal', 'legacyProductFields', 'legacyCategoryField',
    'legacyCategory', 'legacyIdentityLabel', 'legacyProduct', 'legacyFocus', 'legacySolution',
    'quickStartPanel', 'quickStartState', 'quickStartBtn', 'importStartBtn', 'obsidianStartBtn', 'quickWizard',
    'wizardStepLabel', 'wizardStepTitle', 'wizardProgressBar', 'wizardPrevBtn', 'wizardNextBtn', 'quickCreateBtn',
    'quickProduct', 'quickBrand', 'quickCategory', 'quickAudience', 'quickScenarios', 'quickBenefits',
    'quickDifferentiation', 'quickTone', 'quickVisual', 'quickCompliance', 'structuredPanel', 'localFilesPanel',
    'readinessTitle', 'readinessHint', 'readinessBar', 'readinessDimensions', 'obsidianAdvanced', 'obsidianSummaryState',
    'copyObsidianTemplateBtn', 'downloadObsidianTemplateBtn'
  ];
  var el = ids.reduce(function (out, id) { out[id] = document.getElementById(id); return out; }, {});
  var fieldMap = {
    product: 'fieldProduct', brand: 'fieldBrand', category: 'fieldCategory', audience: 'fieldAudience', scenarios: 'fieldScenarios',
    benefits: 'fieldBenefits', differentiation: 'fieldDifferentiation', tone: 'fieldTone', visual: 'fieldVisual',
    compliance: 'fieldCompliance'
  };

  function setState(text, kind) {
    if (!el.saveState) return;
    el.saveState.textContent = text;
    el.saveState.className = 'pill' + (kind ? ' ' + kind : '');
  }

  function setSaveFeedback(text, kind) {
    setState(text, kind);
    if (!el.saveFeedback) return;
    el.saveFeedback.hidden = !text;
    el.saveFeedback.textContent = text || '';
    el.saveFeedback.className = 'save-feedback' + (kind ? ' ' + kind : '');
  }

  function renderWizard() {
    var titles = ['你在卖什么', '卖给谁，凭什么被选择', '用什么方式表达'];
    state.wizardStep = Math.max(1, Math.min(3, Number(state.wizardStep) || 1));
    Array.prototype.forEach.call(document.querySelectorAll('[data-wizard-step]'), function (pane) {
      pane.hidden = Number(pane.getAttribute('data-wizard-step')) !== state.wizardStep;
    });
    el.wizardStepLabel.textContent = '第 ' + state.wizardStep + ' 步，共 3 步';
    el.wizardStepTitle.textContent = titles[state.wizardStep - 1];
    el.wizardProgressBar.style.width = Math.round(state.wizardStep / 3 * 100) + '%';
    el.wizardPrevBtn.disabled = state.wizardStep === 1;
    el.wizardNextBtn.hidden = state.wizardStep === 3;
    el.quickCreateBtn.hidden = state.wizardStep !== 3;
  }

  function openQuickWizard() {
    el.quickWizard.hidden = false;
    state.wizardStep = 1;
    renderWizard();
    el.quickStartState.textContent = '正在共创';
    setTimeout(function () { el.quickProduct.focus(); }, 0);
  }

  function renderReadiness() {
    if (!KB || typeof KB.readiness !== 'function') return;
    var result = KB.readiness(recordFromForm());
    el.readinessTitle.textContent = 'AI 业务理解 ' + result.completed + ' / ' + result.total;
    el.readinessBar.style.width = result.percent + '%';
    el.readinessHint.textContent = result.strong
      ? '信息较完整，可继续用真实证据迭代'
      : (result.ready ? '基础可用；补齐灰色项会让输出更稳定' : '先完成产品身份，再补充受众、场景和卖点');
    el.quickStartState.textContent = result.strong ? '理解较完整' : (result.ready ? '基础可用' : (result.completed ? '待补充' : '未开始'));
    el.readinessDimensions.innerHTML = '';
    result.dimensions.forEach(function (dimension) {
      var button = document.createElement('button');
      button.type = 'button';
      button.className = 'readiness-dimension ' + (dimension.complete ? 'done' : 'missing');
      button.textContent = dimension.label + (dimension.complete ? ' ✓' : '');
      button.title = dimension.complete ? ('已提供' + dimension.label + '信息，点击检查') : ('点击补充' + dimension.label);
      button.addEventListener('click', function () {
        var targetId = fieldMap[dimension.key] || (dimension.key === 'product' ? 'fieldProduct' : '');
        var target = targetId && el[targetId];
        if (!target) return;
        el.structuredPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
        setTimeout(function () { target.focus(); }, 250);
      });
      el.readinessDimensions.appendChild(button);
    });
  }

  function quickAnswers() {
    return {
      product: el.quickProduct.value,
      brand: el.quickBrand.value,
      category: el.quickCategory.value,
      audience: el.quickAudience.value,
      scenarios: el.quickScenarios.value,
      benefits: el.quickBenefits.value,
      differentiation: el.quickDifferentiation.value,
      tone: el.quickTone.value,
      visual: el.quickVisual.value,
      compliance: el.quickCompliance.value
    };
  }

  function createQuickStarter() {
    var answers = quickAnswers();
    var current = recordFromForm();
    if (!String(answers.product || current.fields.product || '').trim() && !String(answers.category || current.fields.category || '').trim()) {
      state.wizardStep = 1; renderWizard();
      setState('请至少填写产品名称或产品品类', 'warn');
      el.quickProduct.focus();
      return;
    }
    var starter = KB.starterFromAnswers(answers, current);
    applyRecord(starter);
    el.quickCreateBtn.disabled = true;
    el.quickStartState.textContent = '正在保存';
    saveCurrent().then(function (saved) {
      if (!saved) {
        renderReadiness();
        el.quickStartState.textContent = '底稿待保存';
        return;
      }
      el.quickWizard.hidden = true;
      renderReadiness();
      el.quickStartState.textContent = '底稿已保存';
      el.structuredPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }).finally(function () { el.quickCreateBtn.disabled = false; });
  }

  function obsidianTemplate() {
    return KB.obsidianMarkdown(recordFromForm());
  }

  function copyObsidianTemplate() {
    var markdown = obsidianTemplate();
    var copied = navigator.clipboard && navigator.clipboard.writeText
      ? navigator.clipboard.writeText(markdown)
      : Promise.reject(new Error('clipboard unavailable'));
    copied.then(function () {
      setState('已复制 Obsidian 笔记模板', 'ok');
    }).catch(function () {
      var textarea = document.createElement('textarea');
      textarea.value = markdown; textarea.setAttribute('readonly', ''); textarea.style.position = 'fixed'; textarea.style.opacity = '0';
      document.body.appendChild(textarea); textarea.select();
      var ok = false;
      try { ok = document.execCommand('copy'); } catch (error) { ok = false; }
      textarea.remove();
      setState(ok ? '已复制 Obsidian 笔记模板' : '复制失败，请使用下载 .md', ok ? 'ok' : 'warn');
    });
  }

  function downloadObsidianTemplate() {
    var record = recordFromForm();
    var identity = record.fields.product || record.fields.brand || record.fields.category || '业务知识';
    var filename = String(identity).replace(/[\\/:*?"<>|\r\n]+/g, '-').slice(0, 60) || '业务知识';
    var blob = new Blob([obsidianTemplate()], { type: 'text/markdown;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var link = document.createElement('a');
    link.href = url; link.download = filename + '-业务事实.md';
    document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(url);
    setState('已下载 Obsidian 笔记模板', 'ok');
  }

  function send(type, payload) {
    return new Promise(function (resolve) {
      if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
        resolve(type === 'GET_BUSINESS_KNOWLEDGE'
          ? { ok: true, accountKey: 'local-preview', knowledge: {} }
          : { ok: false, error: '请在 Chrome 扩展页面中保存知识库' });
        return;
      }
      try {
        chrome.runtime.sendMessage(Object.assign({ type: type }, payload || {}), function (resp) {
          var error = chrome.runtime.lastError;
          resolve(error ? { ok: false, error: error.message } : (resp || { ok: false, error: '无响应' }));
        });
      } catch (error) {
        resolve({ ok: false, error: (error && error.message) || String(error) });
      }
    });
  }

  function selectedScope() {
    var value = el.obsidianPreviewScope && el.obsidianPreviewScope.value;
    return value === 'detail' ? 'detail' : (value === 'main' ? 'main' : 'link');
  }

  function obsidianConfigFromForm() {
    var productMode = !!(el.legacyModeProduct && el.legacyModeProduct.checked);
    var brandMode = !!(el.legacyModeBrand && el.legacyModeBrand.checked);
    return {
      enabled: !!el.obsidianEnabled.checked,
      baseUrl: String(el.obsidianBaseUrl.value || '').trim(),
      folder: String(el.obsidianFolder.value || '').trim(),
      maxNotes: Math.max(1, Math.min(60, Number(el.obsidianMaxNotes.value) || 30)),
      scopes: {
        link: !!el.scopeLink.checked,
        main: !!el.scopeMain.checked,
        detail: !!el.scopeDetail.checked
      },
      legacyDefaults: {
        mode: productMode ? 'product' : (brandMode ? 'brand' : 'none'),
        category: productMode ? String(el.legacyCategory.value || '').trim() : '',
        product: productMode ? String(el.legacyProduct.value || '').trim() : '',
        brand: brandMode ? String(el.legacyProduct.value || '').trim() : '',
        focus: productMode ? String(el.legacyFocus.value || '').trim() : '',
        solution: productMode ? String(el.legacySolution.value || '').trim() : ''
      }
    };
  }

  function renderLegacyDefaults(config) {
    var defaults = config && config.legacyDefaults || {};
    var productMode = defaults.mode === 'product';
    var brandMode = defaults.mode === 'brand';
    el.legacyModeProduct.checked = productMode;
    el.legacyModeBrand.checked = brandMode;
    el.legacyModeGlobal.checked = !productMode && !brandMode;
    el.legacyProductFields.hidden = !productMode && !brandMode;
    el.legacyCategoryField.hidden = !productMode;
    el.legacyIdentityLabel.textContent = brandMode ? '品牌名称' : '产品名称 / SKU';
    el.legacyCategory.value = defaults.category || '';
    el.legacyProduct.value = defaults.product || defaults.brand || defaults.sku || '';
    el.legacyFocus.value = defaults.focus || '';
    el.legacySolution.value = defaults.solution || '';
  }

  function setObsidianHint(text, kind) {
    el.obsidianHint.textContent = text;
    el.obsidianHint.className = 'connection-hint' + (kind ? ' ' + kind : '');
  }

  function renderObsidianSources() {
    el.obsidianSources.innerHTML = '';
    if (!state.obsidianSources.length) {
      var empty = document.createElement('div'); empty.className = 'empty compact';
      empty.textContent = state.obsidian && state.obsidian.connected ? '已连接；点击“刷新当前作用域预览”查看命中的笔记。' : '连接后显示实时命中的笔记来源';
      el.obsidianSources.appendChild(empty);
      return;
    }
    state.obsidianSources.forEach(function (source, index) {
      var row = document.createElement('div'); row.className = 'obsidian-source';
      var name = document.createElement('strong'); name.textContent = '第 ' + (index + 1) + ' 顺位 · ' + (source.path || '未命名笔记'); name.title = source.path || '';
      var meta = document.createElement('span');
      var reasons = Array.isArray(source.matchReason) ? source.matchReason.map(obsidianMatchReasonLabel).join(' / ') : '';
      var updated = source.mtime ? new Date(source.mtime).toLocaleString() : '无mtime';
      meta.textContent = (source.priority ? ('优先级 ' + source.priority + ' · ') : '') + Number(source.chars || 0).toLocaleString() + ' 字 · ' + updated + (reasons ? (' · ' + reasons) : '');
      row.appendChild(name); row.appendChild(meta); el.obsidianSources.appendChild(row);
    });
  }

  function obsidianMatchReasonLabel(reason) {
    reason = String(reason || '');
    var parts = reason.split(':');
    var type = parts[0], kind = parts[1], value = parts.slice(2).join(':');
    if (type === 'scope') return kind === 'all' ? '全作用域' : (kind === 'main' ? '主图作用域' : (kind === 'detail' ? '详情作用域' : '链接作用域'));
    if (type === 'category') return kind === 'exact' ? '精确品类' : '通用品类';
    if (type === 'sku') return kind === 'exact' ? '精确 SKU' : (kind === 'ALL' ? '全部 SKU' : '通用 SKU');
    if (type === 'link') return kind === 'exact' ? '精确 L 编号' : (kind === 'ALL' ? '全部 L 编号' : '通用 L 编号');
    if (type === 'keyword') return kind === 'general' ? '通用关键词' : ('关键词' + (kind === 'exact' ? '精确' : '包含') + (value ? '：' + value : ''));
    var labels = { tag: '标签', alias: '别名', topic: '主题' };
    if (labels[type]) return labels[type] + (kind === 'exact' ? '精确' : '包含') + (value ? '：' + value : '');
    return reason;
  }

  function renderObsidianTrace() {
    var meta = state.obsidianMeta;
    if (!el.obsidianTrace) return;
    if (!meta) {
      el.obsidianTrace.textContent = '尚未读取：来源、指纹和缓存状态将在这里持续显示。';
      return;
    }
    var query = meta.query || {};
    el.obsidianTrace.textContent = [
      '作用域 ' + (meta.scope || selectedScope()),
      '品类 ' + (query.category || '仅通用知识'),
      'L ' + (query.linkId || '无'),
      'SKU ' + (query.skuId || '无'),
      '可读 ' + Number(meta.noteCount || 0) + ' 篇',
      '路由合格 ' + Number(meta.eligibleCount || 0) + ' 篇',
      '最终入模 ' + Number(meta.matchedCount || 0) + ' 篇',
      'Vault ' + String(meta.vaultFingerprint || '').slice(0, 8),
      '上下文 ' + String(meta.contextFingerprint || meta.fingerprint || '').slice(0, 8),
      meta.fromCache ? '缓存命中' : '实时读取',
      meta.retrievedAt ? new Date(meta.retrievedAt).toLocaleString() : ''
    ].filter(Boolean).join(' · ');
  }

  function obsidianScopeLabel(scope) {
    return scope === 'detail' ? '详情页提示词' : (scope === 'main' ? '主图提示词' : '链接定位');
  }

  function renderTextList(container, items, emptyText) {
    if (!container) return;
    container.innerHTML = '';
    (items && items.length ? items : [emptyText]).forEach(function (text) {
      var row = document.createElement('li');
      row.textContent = text;
      container.appendChild(row);
    });
  }

  function obsidianContextHighlights(context, limit) {
    var out = [], seen = Object.create(null), currentPath = '';
    String(context || '').split(/\n/).forEach(function (raw) {
      var source = raw.match(/^来源《(.+?)》/);
      if (source) { currentPath = source[1]; return; }
      var line = String(raw || '').trim();
      if (!line || /^【Obsidian 实时业务知识库】$/.test(line) || /^读取边界：/.test(line) || /^```/.test(line) || /^[-|: ]+$/.test(line)) return;
      line = line.replace(/^#{1,6}\s*/, '').replace(/^[-*+]\s+/, '').replace(/^\d+[.)、]\s*/, '').replace(/\s+/g, ' ').trim();
      if (!line || line === '待补充' || line.length < 4) return;
      var key = (currentPath + '|' + line).toLowerCase();
      if (seen[key]) return;
      seen[key] = true;
      out.push((currentPath ? ('摘录《' + currentPath + '》：') : '摘录：') + line.slice(0, 180));
    });
    limit = Number(limit);
    if (!Number.isFinite(limit)) limit = 8;
    return out.slice(0, Math.max(0, limit));
  }

  function obsidianEvidenceItems(meta) {
    meta = meta || {};
    var out = [];
    (Array.isArray(meta.facts) ? meta.facts : []).slice(0, 6).forEach(function (fact) {
      var status = String(fact && fact.evidenceStatus || '').toLowerCase();
      var verified = ['verified', 'confirmed', 'approved', '已验证', '已确认', '有效'].indexOf(status) >= 0;
      var value = [fact && fact.factValue, fact && fact.unit].filter(Boolean).join(' ');
      if (!fact || !fact.factKey || !value) return;
      out.push((verified ? '已验证事实' : '待核验事实') + ' · ' + fact.factKey + ' = ' + value + (fact.sourcePath ? (' · 《' + fact.sourcePath + '》') : ''));
    });
    return out.concat(obsidianContextHighlights(state.obsidianContext, Math.max(0, 8 - out.length))).slice(0, 8);
  }

  function obsidianPositioningText(defaults) {
    defaults = defaults || {};
    if (defaults.mode === 'product') return '产品信息 · 品类“' + (defaults.category || '未填写') + '” · 产品/SKU“' + (defaults.product || '未填写') + '”';
    if (defaults.mode === 'brand') return '品牌信息 · 品牌“' + (defaults.brand || '未填写') + '”';
    return '不提供额外定位 · 仅匹配 category=ALL 的通用知识';
  }

  function renderObsidianApplication() {
    if (!el.obsidianApplicationState) return;
    var connected = !!(state.obsidian && state.obsidian.connected);
    var config = state.obsidian && state.obsidian.config || {};
    var defaults = obsidianConfigFromForm().legacyDefaults;
    var scope = selectedScope();
    var scopeLabel = obsidianScopeLabel(scope);
    var meta = state.obsidianMeta;
    var noteCount = Number(meta && meta.noteCount || config.lastNoteCount) || 0;
    var eligibleCount = Number(meta && meta.eligibleCount) || 0;
    var matchedCount = Number(meta && meta.matchedCount) || state.obsidianSources.length;
    var connectionDraftChanged = !!(state.obsidianDraftDirty.baseUrl || state.obsidianDraftDirty.folder);
    var statusText = '等待连接', statusKind = '', conclusion = '连接后选择知识定位与预览作用域，再刷新预览形成应用结论。';

    if (connected && connectionDraftChanged) {
      statusText = '配置待重连'; statusKind = 'warn';
      conclusion = 'API 地址或 Vault 目录已修改，当前结论已作废。请点击“连接并测试”，确认新目录后再刷新作用域预览。';
    } else if (connected && !el.obsidianEnabled.checked) {
      statusText = '已暂停'; statusKind = 'warn';
      conclusion = '连接参数仍在，但“启用 Obsidian 实时知识”已关闭；三条生产链路当前都不会读取 Vault。';
    } else if (connected && defaults.mode === 'product' && !defaults.category) {
      statusText = '尚未应用'; statusKind = 'warn';
      conclusion = '已连通，目录内可读取 ' + noteCount + ' 篇，但当前选择“产品信息”且产品品类为空，因此尚未执行匹配、没有知识结论，也不会把这批笔记直接塞进生产。请填写产品品类后刷新预览。';
    } else if (connected && !meta) {
      statusText = '待形成结论';
      conclusion = '已连通，目录内可读取 ' + noteCount + ' 篇；当前只是连接诊断，尚未执行“' + scopeLabel + '”检索。点击“刷新当前作用域预览”后才会显示命中数量、入模顺位和依据。';
    } else if (connected && meta && (meta.externalError || meta.ok === false)) {
      statusText = '读取失败'; statusKind = 'warn';
      conclusion = '本次知识读取失败，生产链路会停止而不是使用旧结论：' + String(meta.externalError || meta.error || '未知错误');
    } else if (connected && meta && matchedCount > 0) {
      statusText = '可用于生产'; statusKind = 'ok';
      conclusion = '“' + scopeLabel + '”本次从 ' + noteCount + ' 篇可读笔记中筛出 ' + (eligibleCount || matchedCount) + ' 篇符合路由，按相关性、优先级与上下文预算最终装入 ' + matchedCount + ' 篇。下方来源顺位就是本次真实入模顺序；正式生产时还会带入当前任务的 L 编号、SKU 和关键词重新匹配，不会把这次预览永久套用到所有商品。';
    } else if (connected && meta) {
      statusText = '命中 0 篇'; statusKind = 'warn';
      conclusion = '已完成“' + scopeLabel + '”读取，但当前定位没有命中可用笔记，所以 Obsidian 对本次生产不产生影响。请核对笔记的 status、scope、category、L/SKU 或关键词 frontmatter。';
    }

    el.obsidianApplicationState.textContent = statusText;
    el.obsidianApplicationState.className = statusKind;
    el.obsidianConclusion.textContent = conclusion;
    renderTextList(el.obsidianProcess, [
      '连接：只读当前专用目录；当前可读 ' + noteCount + ' 篇，Key 和正文不会进入任务持久化。',
      '定位：' + obsidianPositioningText(defaults) + '。',
      '路由：当前预览使用“' + scopeLabel + '”；正式生产会再自动带入当前 L 编号、SKU、品类和主推关键词逐任务重匹配。',
      '筛选：只保留 active、作用域匹配、品类匹配，并满足 L/SKU/关键词声明的笔记；同级已验证硬事实冲突会阻止生成。',
      '排序：精确 L+SKU → 精确 L → 精确 SKU → 精确品类 → 精确关键词 → 笔记优先级 → 更新时间。',
      '裁剪：最多读取 ' + Math.max(1, Math.min(60, Number(el.obsidianMaxNotes.value) || 30)) + ' 篇，单篇最多占上下文 40%；随后与本地结构化知识合并并执行生成后事实/合规校验。'
    ], '尚未建立读取过程。');
    renderTextList(el.obsidianProductionOrder,
      KB && typeof KB.productionOrder === 'function' ? KB.productionOrder(scope) : [],
      '当前版本未加载生产顺序合同。');
    renderTextList(el.obsidianHighlights, obsidianEvidenceItems(meta),
      meta ? '本次没有可展示的结构化事实或原文摘录。' : '刷新当前作用域预览后显示。');
  }

  function refreshSavedKeyAction() {
    var connected = !!(state.obsidian && state.obsidian.connected);
    var hasSavedKey = !!(state.obsidian && state.obsidian.hasSavedKey);
    var pendingKey = String(el.obsidianApiKey.value || '').trim().replace(/^Bearer\s+/i, '');
    if (hasSavedKey && !pendingKey) {
      el.saveObsidianKeyBtn.disabled = true;
      el.saveObsidianKeyBtn.textContent = '已保存，无需重复操作';
      return;
    }
    // 首次保存可直接使用已验证的 session Key，无需再粘贴一次；
    // 已有持久 Key 时则只有输入新 Key 才允许替换。
    el.saveObsidianKeyBtn.disabled = !connected || (hasSavedKey && !pendingKey);
    el.saveObsidianKeyBtn.textContent = hasSavedKey ? '验证并更换已保存 Key' : '保存 Key 到此设备';
  }

  function resetObsidianDraftDirty() {
    Object.keys(state.obsidianDraftDirty).forEach(function (key) { state.obsidianDraftDirty[key] = false; });
    state.obsidianDraftRevision += 1;
  }

  function markObsidianDraftDirty(key) {
    if (!Object.prototype.hasOwnProperty.call(state.obsidianDraftDirty, key)) return;
    state.obsidianDraftDirty[key] = true;
    state.obsidianDraftRevision += 1;
  }

  function mayHydrateObsidianField(key, preserveDraft) {
    return !preserveDraft || !state.obsidianDraftDirty[key];
  }

  function renderObsidianConnection(result, options) {
    result = result || {};
    options = options || {};
    var preserveDraft = options.preserveDraft === true;
    state.obsidian = result;
    var config = result.config || {};
    if (config.baseUrl && mayHydrateObsidianField('baseUrl', preserveDraft)) el.obsidianBaseUrl.value = config.baseUrl;
    if (config.folder != null && mayHydrateObsidianField('folder', preserveDraft)) el.obsidianFolder.value = config.folder;
    if (config.maxNotes && mayHydrateObsidianField('maxNotes', preserveDraft)) el.obsidianMaxNotes.value = config.maxNotes;
    if (mayHydrateObsidianField('legacyDefaults', preserveDraft)) renderLegacyDefaults(config);
    el.obsidianEnabled.checked = config.enabled !== false;
    // 被动状态刷新不能覆盖正在填写的目录或清空待提交 Key。只有显式连接、
    // 保存、删除或断开完成后才重置草稿；真实 Key 仍然永不从后台回填 DOM。
    if (mayHydrateObsidianField('apiKey', preserveDraft)) {
      el.obsidianApiKey.value = '';
      el.obsidianApiKey.type = 'password';
      el.toggleObsidianKey.textContent = '显示';
      el.toggleObsidianKey.setAttribute('aria-label', '显示 API Key');
    }
    var hasSavedKey = result.hasSavedKey === true;
    var credentialSource = result.credentialSource === 'saved' ? 'saved' : (result.credentialSource === 'session' ? 'session' : 'none');
    el.obsidianKeyStatus.textContent = hasSavedKey
      ? '已保存到此设备 · 以后自动使用 · ••••••••'
      : '未长期保存（默认仅本次会话）';
    refreshSavedKeyAction();
    el.deleteObsidianKeyBtn.disabled = !hasSavedKey;
    if (result.connected) {
      el.obsidianState.textContent = '已连接' + (config.lastNoteCount ? (' · ' + config.lastNoteCount + ' 篇') : '');
      el.obsidianState.className = 'connection-state ok';
      el.obsidianSummaryState.textContent = '已连接' + (config.lastNoteCount ? (' · ' + config.lastNoteCount + ' 篇') : '');
      el.obsidianSummaryState.className = 'ok';
      el.obsidianApiKey.placeholder = hasSavedKey
        ? 'Key 已保存到此设备（••••••••）；如需更换可重新粘贴'
        : 'Key 仅保存在本次浏览器会话；如需更换可重新粘贴';
      setObsidianHint('连接可用' + (hasSavedKey ? '；Key 已保存，以后打开插件和重启 Chrome 都会自动使用，无需重复填写' : '') + '。AI 会按 link / main / detail 作用域实时读取，正文不会写入扩展长期存储。', 'ok');
    } else if (result.configured && !result.hasSessionKey && !hasSavedKey) {
      el.obsidianState.textContent = '需重新输入 Key';
      el.obsidianState.className = 'connection-state warn';
      el.obsidianSummaryState.textContent = '需要重新连接';
      el.obsidianSummaryState.className = '';
      el.obsidianApiKey.placeholder = '当前无可用 Key，请重新粘贴 API Key';
      setObsidianHint('连接参数仍在，但当前无可用 API Key。重新粘贴 Key 并点击连接。', 'warn');
    } else {
      el.obsidianState.textContent = '未连接';
      el.obsidianState.className = 'connection-state';
      el.obsidianSummaryState.textContent = '未连接 · 可选';
      el.obsidianSummaryState.className = '';
      setObsidianHint('需要 Obsidian 保持打开，并已启用 Local REST API。建议只授权专用“少壮AI知识库”目录；HTTPS 首次使用需信任本机证书。', '');
    }
    if (!preserveDraft) resetObsidianDraftDirty();
    renderObsidianSources(); renderObsidianTrace(); renderObsidianApplication();
  }

  function loadObsidianConnection() {
    var requestedAtRevision = state.obsidianDraftRevision;
    return send('GET_OBSIDIAN_CONNECTION').then(function (result) {
      if (!result || !result.ok) throw new Error((result && result.error) || 'Obsidian 连接状态读取失败');
      // 请求发出后若用户继续输入或显式操作已经完成，该响应已过时，不能再
      // 改写状态或表单；下一次被动刷新会读取最新配置。
      if (requestedAtRevision !== state.obsidianDraftRevision) return result;
      renderObsidianConnection(result, { preserveDraft: true });
      return result;
    }).catch(function (error) {
      state.obsidian = null;
      state.obsidianContext = '';
      state.obsidianSources = [];
      state.obsidianMeta = null;
      refreshSavedKeyAction();
      el.obsidianState.textContent = '连接器异常'; el.obsidianState.className = 'connection-state warn';
      el.obsidianSummaryState.textContent = '连接器异常'; el.obsidianSummaryState.className = '';
      setObsidianHint((error && error.message) || String(error), 'warn');
      renderObsidianApplication();
      return null;
    });
  }

  function originPermissionPattern(baseUrl) {
    var parsed = new URL(baseUrl);
    return parsed.protocol + '//' + parsed.hostname + '/*';
  }

  function ensureObsidianPermission(baseUrl) {
    if (typeof chrome === 'undefined' || !chrome.permissions || !chrome.permissions.request) return Promise.resolve(true);
    var origin;
    try { origin = originPermissionPattern(baseUrl); }
    catch (error) { return Promise.reject(new Error('Obsidian API 地址格式不正确')); }
    return new Promise(function (resolve) {
      function requestPermission() {
        // permissions.request 只在尚未授权时调用。保存 Key 前的 confirm
        // 可能消耗 Chrome 的用户激活，不得因重复申请把已有授权误报为拒绝。
        chrome.permissions.request({ origins: [origin] }, function (granted) {
          var requestError = chrome.runtime.lastError;
          resolve(!requestError && !!granted);
        });
      }
      if (typeof chrome.permissions.contains !== 'function') {
        requestPermission();
        return;
      }
      chrome.permissions.contains({ origins: [origin] }, function (granted) {
        var containsError = chrome.runtime.lastError;
        if (!containsError && granted) {
          resolve(true);
          return;
        }
        requestPermission();
      });
    });
  }

  function refreshObsidianPreview() {
    if (!state.obsidian || !state.obsidian.connected) {
      setObsidianHint('请先连接 Obsidian，再读取实时预览。', 'warn');
      return Promise.resolve();
    }
    el.previewObsidianBtn.disabled = true;
    setObsidianHint('正在从 Obsidian 实时读取当前作用域…', '');
    var defaults = obsidianConfigFromForm().legacyDefaults;
    if (defaults.mode === 'product' && !defaults.category) {
      setObsidianHint('请先填写产品品类；或选择“暂不提供”按全局通用知识读取。', 'warn');
      el.legacyCategory.focus();
      el.previewObsidianBtn.disabled = false;
      renderObsidianApplication();
      return Promise.resolve();
    }
    return persistObsidianSettings().then(function (saved) {
      if (!saved) throw new Error('Obsidian 设置保存失败，本次未继续读取知识');
      return send('PREVIEW_OBSIDIAN_CONTEXT', {
        scope: selectedScope(), maxChars: 8000, allowGlobalOnly: true,
        category: defaults.mode === 'product' ? defaults.category : '',
        keywords: defaults.mode !== 'none' ? [defaults.product, defaults.brand, defaults.focus, defaults.solution].filter(Boolean) : []
      });
    }).then(function (result) {
      if (!result || !result.ok) throw new Error((result && (result.externalError || result.error)) || 'Obsidian 预览读取失败');
      state.obsidianContext = result.externalContext || '';
      state.obsidianSources = Array.isArray(result.sources) ? result.sources : [];
      state.obsidianMeta = result;
      renderPreview(); renderObsidianSources(); renderObsidianTrace(); renderObsidianApplication();
      if (result.externalError && !result.sources.length) {
        setObsidianHint(result.externalError, 'warn');
      } else {
        setObsidianHint('实时读取完成：当前作用域命中 ' + Number(result.matchedCount || state.obsidianSources.length) + ' 篇笔记；未把正文写入插件存储。', 'ok');
      }
    }).catch(function (error) {
      var message = (error && error.message) || String(error);
      state.obsidianContext = ''; state.obsidianSources = [];
      state.obsidianMeta = {
        ok: false,
        externalError: message,
        scope: selectedScope(),
        noteCount: Number(state.obsidian && state.obsidian.config && state.obsidian.config.lastNoteCount) || 0,
        eligibleCount: 0,
        matchedCount: 0,
        query: { category: defaults.mode === 'product' ? defaults.category : '' }
      };
      renderPreview(); renderObsidianSources(); renderObsidianTrace(); renderObsidianApplication();
      setObsidianHint(message, 'warn');
    }).finally(function () { el.previewObsidianBtn.disabled = false; });
  }

  function connectObsidian() {
    var config = obsidianConfigFromForm();
    var apiKey = String(el.obsidianApiKey.value || '').trim().replace(/^Bearer\s+/i, '');
    if (!config.folder && !confirm('当前目录为空，将允许 AI 在每次任务中扫描整个 Vault。Local REST Key 拥有全 Vault 权限，可能误读 Clippings 等网页资料。仍要继续吗？')) return;
    var hasStoredCredential = !!(state.obsidian && (state.obsidian.hasSessionKey || state.obsidian.hasSavedKey));
    if (!hasStoredCredential && config.enabled && !apiKey) {
      setObsidianHint('请粘贴 Local REST API 页面中 Bearer 后面的 API Key。', 'warn');
      el.obsidianApiKey.focus(); return;
    }
    el.connectObsidianBtn.disabled = true;
    setObsidianHint('正在申请本机地址权限并测试连接…', '');
    ensureObsidianPermission(config.baseUrl).then(function (granted) {
      if (!granted) throw new Error('未获得本机 Obsidian 地址访问权限，无法连接');
      return send('CONNECT_OBSIDIAN', { config: config, apiKey: apiKey });
    }).then(function (result) {
      if (!result || !result.ok) {
        var connectError = new Error((result && result.error) || '连接失败');
        connectError.code = result && result.code || 'connection_failed';
        throw connectError;
      }
      renderObsidianConnection(result);
      var diagnostics = result.diagnostics || {};
      setObsidianHint('连接成功：' + (diagnostics.service || 'Obsidian Local REST API') +
        (diagnostics.version ? (' v' + diagnostics.version) : '') + '，目录内发现 ' + Number(diagnostics.noteCount || 0) + ' 篇可读笔记。', 'ok');
      return refreshObsidianPreview();
    }).catch(function (error) {
      el.obsidianState.textContent = '连接失败'; el.obsidianState.className = 'connection-state warn';
      setObsidianHint((error && error.message) || String(error), 'warn');
      renderObsidianApplication();
      if (el.obsidianCertificateGuide && /^https:/i.test(config.baseUrl) && /network|certificate|证书|连接/i.test(String((error && (error.code + ' ' + error.message)) || error))) {
        el.obsidianCertificateGuide.open = true;
      }
    }).finally(function () { el.connectObsidianBtn.disabled = false; });
  }

  function saveObsidianKey() {
    if (!state.obsidian || !state.obsidian.connected) {
      setObsidianHint('请先成功连接 Obsidian，再保存 Key。', 'warn');
      return;
    }
    var pendingKey = String(el.obsidianApiKey.value || '').trim().replace(/^Bearer\s+/i, '');
    if (state.obsidian.hasSavedKey && !pendingKey) {
      setObsidianHint('Key 已保存到此设备，以后会自动使用，无需重复填写或保存。', 'ok');
      refreshSavedKeyAction();
      return;
    }
    var confirmation = state.obsidian.hasSavedKey
      ? '确认用输入的新 Key 替换此设备上已保存的 Key 吗？'
      : '确认把 Obsidian API Key 保存到当前 Chrome 扩展存储吗？\n\nKey 不会上传，但这不是 macOS 钥匙串。仅建议在个人设备上保存。';
    if (!confirm(confirmation)) return;
    var config = obsidianConfigFromForm();
    if (pendingKey && !config.folder && !confirm('当前目录为空，新 Key 验证会允许扫描整个 Vault。仍要继续吗？')) return;
    el.saveObsidianKeyBtn.disabled = true;
    setObsidianHint(pendingKey ? '正在先验证新 Key，再保存到此设备…' : '正在重新验证连接并保存 Key…', '');
    // 输入框存在新 Key 时，不能静默重存旧 session Key。先用新 Key 完成
    // CONNECT_OBSIDIAN 真连接并更新 session，再执行显式持久化的二次验证。
    var prepare = pendingKey
      ? ensureObsidianPermission(config.baseUrl).then(function (granted) {
          if (!granted) throw new Error('未获得本机 Obsidian 地址访问权限，无法验证新 Key');
          return send('CONNECT_OBSIDIAN', { config: config, apiKey: pendingKey });
        }).then(function (connected) {
          if (!connected || !connected.ok) throw new Error((connected && connected.error) || '新 Key 连接验证失败');
          return connected;
        })
      : Promise.resolve(state.obsidian);
    prepare.then(function () { return send('SAVE_OBSIDIAN_API_KEY'); }).then(function (result) {
      if (!result || !result.ok) throw new Error((result && result.error) || 'Key 保存失败');
      renderObsidianConnection(result);
      setObsidianHint('Key 已保存到此设备；界面和消息响应不会回传明文。', 'ok');
    }).catch(function (error) {
      setObsidianHint((error && error.message) || String(error), 'warn');
    }).finally(function () {
      refreshSavedKeyAction();
    });
  }

  function deleteObsidianKey() {
    if (!state.obsidian || !state.obsidian.hasSavedKey) return;
    if (!confirm('确认删除此设备上已保存的 Obsidian Key 吗？\n\n当前浏览器会话仍可继续使用；完全退出 Chrome 后需重新输入。')) return;
    el.deleteObsidianKeyBtn.disabled = true;
    send('DELETE_OBSIDIAN_API_KEY').then(function (result) {
      if (!result || !result.ok) throw new Error((result && result.error) || '删除已保存 Key 失败');
      renderObsidianConnection(result);
      setObsidianHint('已删除此设备上已保存的 Key；当前会话仍可继续使用。', 'ok');
    }).catch(function (error) {
      setObsidianHint((error && error.message) || String(error), 'warn');
    }).finally(function () {
      el.deleteObsidianKeyBtn.disabled = !(state.obsidian && state.obsidian.hasSavedKey);
    });
  }

  function persistObsidianSettings() {
    if (!state.obsidian || !state.obsidian.configured) return Promise.resolve();
    return send('SAVE_OBSIDIAN_CONNECTION', { config: obsidianConfigFromForm(), apiKey: '' }).then(function (result) {
      if (!result || !result.ok) throw new Error((result && result.error) || 'Obsidian 设置保存失败');
      state.obsidian = result;
      return result;
    }).catch(function (error) {
      setObsidianHint((error && error.message) || String(error), 'warn');
      return null;
    });
  }

  function disconnectObsidian() {
    if (!confirm('确认断开 Obsidian 吗？只会删除插件中的连接参数、会话 Key 和此设备已保存 Key，不会修改 Vault。')) return;
    el.disconnectObsidianBtn.disabled = true;
    send('DISCONNECT_OBSIDIAN').then(function (result) {
      if (!result || !result.ok) throw new Error((result && result.error) || '断开失败');
      state.obsidianContext = ''; state.obsidianSources = []; state.obsidianMeta = null;
      el.obsidianApiKey.value = '';
      renderObsidianConnection({ ok: true, configured: false, connected: false, hasSessionKey: false, hasSavedKey: false, credentialSource: 'none', config: obsidianConfigFromForm() });
      renderPreview();
    }).catch(function (error) {
      setObsidianHint((error && error.message) || String(error), 'warn');
    }).finally(function () { el.disconnectObsidianBtn.disabled = false; });
  }

  function openObsidianCertificate() {
    var baseUrl = String(el.obsidianBaseUrl.value || '').trim().replace(/\/+$/, '');
    var url;
    try { url = new URL('/obsidian-local-rest-api.crt', baseUrl).toString(); }
    catch (error) { setObsidianHint('请先填写正确的 HTTPS API 地址。', 'warn'); return; }
    if (!/^https:/.test(url)) { setObsidianHint('当前使用 HTTP，不需要安装 HTTPS 证书。', ''); return; }
    try {
      chrome.tabs.create({ url: url });
      setObsidianHint('已打开证书地址。下载后需在 macOS 钥匙串中设为“始终信任”，然后重启 Chrome。', '');
    } catch (error) {
      window.open(url, '_blank');
    }
  }

  function checkObsidianCertificate() {
    var baseUrl = String(el.obsidianBaseUrl.value || '').trim().replace(/\/+$/, '');
    if (!/^https:/i.test(baseUrl)) { setObsidianHint('当前使用 HTTP，不需要 HTTPS 证书。', ''); return; }
    el.checkObsidianCertBtn.disabled = true;
    fetch(baseUrl + '/', { method: 'GET', cache: 'no-store' }).then(function () {
      setObsidianHint('浏览器已能建立 HTTPS 连接；请继续点击“连接并测试”验证 Key 和目录。', 'ok');
    }).catch(function () {
      setObsidianHint('HTTPS 证书仍未被 Chrome 信任，请严格完成下方四步后完全重启 Chrome。', 'warn');
      if (el.obsidianCertificateGuide) el.obsidianCertificateGuide.open = true;
    }).finally(function () { el.checkObsidianCertBtn.disabled = false; });
  }

  function copyObsidianUrl() {
    var value = String(el.obsidianBaseUrl.value || '').trim();
    var copied = navigator.clipboard && navigator.clipboard.writeText ? navigator.clipboard.writeText(value) : Promise.reject(new Error('clipboard unavailable'));
    copied.then(function () { setObsidianHint('已复制 Local REST API 地址。', 'ok'); }).catch(function () { setObsidianHint('复制失败，请手动选择 API 地址复制。', 'warn'); });
  }

  function readFileText(file) {
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onload = function () { resolve(String(reader.result || '')); };
      reader.onerror = function () { reject(reader.error || new Error('文件读取失败')); };
      reader.readAsText(file);
    });
  }

  function workbookText(file) {
    if (globalThis.LOCALTABLES && typeof globalThis.LOCALTABLES.extractWorkbookText === 'function') {
      return globalThis.LOCALTABLES.extractWorkbookText(file, { maxChars: KB.MAX_SOURCE_CHARS }).then(function (result) {
        if (result && result.truncated) el.hint.textContent = 'Excel内容超过知识库正文预算，已在安全解析后截取前12万字。';
        return result && result.text || '';
      });
    }
    return Promise.reject(new Error('Excel 安全解析组件未加载，请重载插件后再试'));
  }

  function parseFile(file) {
    if (!file || !file.size) return Promise.reject(new Error('空文件不能导入'));
    if (file.size > MAX_FILE_BYTES) return Promise.reject(new Error('单文件不能超过 10MB'));
    var ext = String(file && file.name || '').toLowerCase().split('.').pop();
    var parser = /^(xlsx|xls)$/.test(ext) ? workbookText(file) : readFileText(file);
    return parser.then(function (text) {
      text = KB.cleanText(text, KB.MAX_SOURCE_CHARS);
      if (!text) throw new Error('文件没有可读取文本');
      return {
        id: 'kb-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8),
        name: file.name || '未命名资料',
        type: file.type || ('application/' + ext),
        size: Number(file.size) || 0,
        chars: text.length,
        text: text
      };
    });
  }

  function renderSources() {
    el.sourceList.innerHTML = '';
    el.sourceCount.textContent = state.sources.length + ' / ' + KB.MAX_SOURCE_COUNT;
    if (!state.sources.length) {
      var empty = document.createElement('div');
      empty.className = 'empty';
      empty.textContent = '尚未导入资料';
      el.sourceList.appendChild(empty);
      return;
    }
    state.sources.forEach(function (source, idx) {
      var row = document.createElement('div'); row.className = 'source-row';
      var copy = document.createElement('div');
      var name = document.createElement('strong'); name.textContent = source.name;
      var meta = document.createElement('span'); meta.textContent = source.type + ' · ' + source.chars.toLocaleString() + ' 字';
      var chars = document.createElement('b'); chars.textContent = '#' + String(idx + 1).padStart(2, '0');
      var remove = document.createElement('button'); remove.type = 'button'; remove.textContent = '×'; remove.title = '移除资料';
      remove.addEventListener('click', function () { state.sources.splice(idx, 1); renderAll(); setState('有未保存修改', 'warn'); });
      copy.appendChild(name); copy.appendChild(meta); row.appendChild(copy); row.appendChild(chars); row.appendChild(remove);
      el.sourceList.appendChild(row);
    });
  }

  function recordFromForm() {
    var fields = {};
    Object.keys(fieldMap).forEach(function (key) { fields[key] = el[fieldMap[key]].value || ''; });
    return KB.normalize({
      name: el.kbName.value,
      enabled: el.kbEnabled.checked,
      updatedAt: state.record.updatedAt || 0,
      scopes: { link: el.scopeLink.checked, main: el.scopeMain.checked, detail: el.scopeDetail.checked },
      fields: fields,
      sources: state.sources
    });
  }

  function applyRecord(record) {
    record = KB.normalize(record);
    state.record = record;
    state.sources = record.sources.slice();
    el.kbName.value = record.name;
    el.kbEnabled.checked = record.enabled;
    el.scopeLink.checked = record.scopes.link;
    el.scopeMain.checked = record.scopes.main;
    el.scopeDetail.checked = record.scopes.detail;
    Object.keys(fieldMap).forEach(function (key) { el[fieldMap[key]].value = record.fields[key] || ''; });
    renderAll();
  }

  function renderPreview() {
    var record = recordFromForm();
    var scopes = [];
    if (record.scopes.link) scopes.push('链接定位');
    if (record.scopes.main) scopes.push('主图提示词');
    if (record.scopes.detail) scopes.push('详情页提示词');
    var context = KB.contextForScope(record, record.scopes.link ? 'link' : (record.scopes.main ? 'main' : 'detail'));
    if (state.obsidianContext) context = [context, state.obsidianContext].filter(Boolean).join('\n\n');
    el.contextPreview.textContent = context || '当前知识库未启用、未选择调用范围，或还没有有效内容。';
    el.contextCount.textContent = context.length.toLocaleString() + ' 字 · ' + (scopes.join(' / ') || '未调用') +
      (state.obsidianSources.length ? (' · Obsidian ' + state.obsidianSources.length + ' 篇') : '');
    renderSaveActionState(record);
  }

  function renderSaveActionState(record) {
    if (!el.saveActionState) return;
    record = record || recordFromForm();
    var hasLocal = KB.hasContent(record);
    var obsidianReady = !!(state.obsidian && state.obsidian.connected && el.obsidianEnabled.checked &&
      (state.obsidianContext || state.obsidianMeta && Number(state.obsidianMeta.matchedCount) > 0));
    var title = '本地业务底稿尚未填写';
    var text = 'Obsidian 正文会实时读取；只有上方手填字段或导入资料需要保存到扩展存储。';
    var kind = '';
    if (hasLocal && obsidianReady) {
      title = '本地底稿可保存 · Obsidian 已实时启用';
      text = '点击下方按钮只保存本地手填字段和导入资料；Obsidian 正文继续在每次 AI 任务中实时读取。';
      kind = 'ok';
    } else if (hasLocal) {
      title = '本地业务底稿可保存';
      text = '点击下方按钮后，本地手填字段和导入资料会保存到当前账号。';
      kind = 'ok';
    } else if (obsidianReady) {
      title = 'Obsidian 实时知识已启用 · 无需保存正文';
      text = '正式生成时会按当前作用域自动重新读取。下方按钮仅用于保存本地业务底稿，当前没有本地内容可保存。';
      kind = 'ok';
    }
    el.saveActionTitle.textContent = title;
    el.saveActionText.textContent = text;
    el.saveActionState.className = 'save-action-state' + (kind ? ' ' + kind : '');
  }

  function renderAll() { renderSources(); renderPreview(); renderReadiness(); }

  function loadCurrent() {
    setState('读取中…', '');
    return send('GET_BUSINESS_KNOWLEDGE').then(function (resp) {
      if (!resp || !resp.ok) throw new Error((resp && resp.error) || '知识库读取失败');
      var previousAccountKey = state.accountKey;
      state.accountKey = resp.accountKey || '';
      if (previousAccountKey && previousAccountKey !== state.accountKey) {
        state.obsidian = null;
        state.obsidianContext = '';
        state.obsidianSources = [];
        state.obsidianMeta = null;
        el.obsidianApiKey.value = '';
        resetObsidianDraftDirty();
        renderObsidianSources();
        renderObsidianTrace();
      }
      el.accountState.textContent = state.accountKey === 'local' ? '本机账号' : '当前登录账号';
      el.accountState.className = 'pill ok';
      applyRecord(resp.knowledge || {});
      var summary = KB.summary(resp.knowledge || {});
      setState(summary.ready ? ('已保存 · ' + summary.sourceCount + ' 份资料') : '等待导入', summary.ready ? 'ok' : '');
    }).catch(function (error) {
      state.accountKey = '';
      state.obsidian = null;
      state.obsidianContext = '';
      state.obsidianSources = [];
      state.obsidianMeta = null;
      el.accountState.textContent = '账号读取失败'; el.accountState.className = 'pill warn';
      setState((error && error.message) || String(error), 'warn');
    });
  }

  function saveCurrent() {
    var record = recordFromForm();
    if (!KB.hasContent(record)) {
      var obsidianReady = !!(state.obsidian && state.obsidian.connected && el.obsidianEnabled.checked &&
        (state.obsidianContext || state.obsidianMeta && Number(state.obsidianMeta.matchedCount) > 0));
      setSaveFeedback(obsidianReady
        ? 'Obsidian 实时知识已经启用，无需保存正文；这个按钮只保存上方手填字段或导入资料，当前没有本地内容可保存。'
        : '当前没有可保存的本地业务底稿。请先填写至少一项业务规则，或导入一份资料。', obsidianReady ? 'ok' : 'warn');
      return Promise.resolve(false);
    }
    el.saveBtn.disabled = true; setSaveFeedback('正在保存本地业务底稿…', '');
    return send('SAVE_BUSINESS_KNOWLEDGE', { knowledge: Object.assign({}, record, { updatedAt: Date.now() }) }).then(function (resp) {
      if (!resp || !resp.ok) throw new Error((resp && resp.error) || '保存失败');
      applyRecord(resp.knowledge || record);
      setSaveFeedback('本地业务底稿已保存；链接、主图和详情三条链路均可调用。Obsidian 正文仍按任务实时读取。', 'ok');
      return true;
    }).catch(function (error) {
      setSaveFeedback('本地业务底稿保存失败：' + ((error && error.message) || String(error)), 'warn');
      return false;
    }).finally(function () { el.saveBtn.disabled = false; });
  }

  function exportCurrent() {
    var record = recordFromForm();
    var blob = new Blob([JSON.stringify(record, null, 2)], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var link = document.createElement('a');
    link.href = url; link.download = '少壮AI业务知识库_' + new Date().toISOString().slice(0, 10) + '.json';
    document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(url);
    setState('已导出 JSON', 'ok');
  }

  function clearCurrent() {
    if (!confirm('确认清空当前账号的业务知识库吗？API配置、链接清单和图片不会被删除。')) return;
    el.clearBtn.disabled = true;
    send('CLEAR_BUSINESS_KNOWLEDGE').then(function (resp) {
      if (!resp || !resp.ok) throw new Error((resp && resp.error) || '清空失败');
      applyRecord({}); setState('已清空当前账号知识库', 'ok');
    }).catch(function (error) { setState((error && error.message) || String(error), 'warn'); })
      .finally(function () { el.clearBtn.disabled = false; });
  }

  el.sourceFiles.addEventListener('change', function (event) {
    var files = Array.prototype.slice.call((event.target && event.target.files) || []);
    var room = Math.max(0, KB.MAX_SOURCE_COUNT - state.sources.length);
    files = files.slice(0, room);
    if (!files.length) { setState(room ? '未选择文件' : '最多只能导入 8 份资料', 'warn'); return; }
    var existingBytes = state.sources.reduce(function (sum, source) { return sum + (Number(source.size) || 0); }, 0);
    var incomingBytes = files.reduce(function (sum, file) { return sum + (Number(file.size) || 0); }, 0);
    if (existingBytes + incomingBytes > MAX_TOTAL_BYTES) {
      setState('本次知识库原文件总量不能超过 30MB', 'warn');
      event.target.value = '';
      return;
    }
    setState('正在解析 ' + files.length + ' 份资料…', '');
    Promise.allSettled(files.map(parseFile)).then(function (results) {
      var added = 0, errors = [];
      results.forEach(function (result, idx) {
        if (result.status === 'fulfilled') { state.sources.push(result.value); added++; }
        else errors.push((files[idx] && files[idx].name || '文件') + '：' + ((result.reason && result.reason.message) || result.reason));
      });
      var beforeChars = state.sources.reduce(function (sum, source) { return sum + (source.chars || 0); }, 0);
      state.sources = KB.normalize({ sources: state.sources }).sources;
      var afterChars = state.sources.reduce(function (sum, source) { return sum + (source.chars || 0); }, 0);
      renderAll(); event.target.value = '';
      var truncated = beforeChars > afterChars;
      setState('已解析 ' + added + ' 份' + (errors.length ? '，失败 ' + errors.length + ' 份' : '') + (truncated ? '，正文已按12万字上限截取' : '') + ' · 请保存', (errors.length || truncated) ? 'warn' : 'ok');
      if (errors.length || truncated) el.hint.textContent = errors.concat(truncated ? ['知识库正文最多保留12万字；界面已明确标记本次截取。'] : []).join('；');
    });
  });

  Object.keys(fieldMap).forEach(function (key) { el[fieldMap[key]].addEventListener('input', function () { renderPreview(); renderReadiness(); setState('有未保存修改', 'warn'); }); });
  [el.kbName, el.kbEnabled, el.scopeLink, el.scopeMain, el.scopeDetail].forEach(function (control) {
    control.addEventListener('input', function () { renderPreview(); setState('有未保存修改', 'warn'); });
    control.addEventListener('change', function () { renderPreview(); setState('有未保存修改', 'warn'); });
  });
  [el.scopeLink, el.scopeMain, el.scopeDetail].forEach(function (control) {
    control.addEventListener('change', function () {
      state.obsidianContext = ''; state.obsidianSources = []; state.obsidianMeta = null;
      renderPreview(); renderObsidianSources(); renderObsidianTrace(); renderObsidianApplication();
      if (state.obsidian && state.obsidian.connected) {
        setObsidianHint('正在保存 Obsidian 调用范围…', '');
        persistObsidianSettings().then(function () {
          setObsidianHint('调用范围已保存；点击“刷新当前作用域预览”核对实时内容。', 'ok');
        });
      }
    });
  });
  [el.legacyModeProduct, el.legacyModeBrand, el.legacyModeGlobal].forEach(function (control) {
    control.addEventListener('change', function () {
      markObsidianDraftDirty('legacyDefaults');
      var productMode = el.legacyModeProduct.checked;
      var brandMode = el.legacyModeBrand.checked;
      el.legacyProductFields.hidden = !productMode && !brandMode;
      el.legacyCategoryField.hidden = !productMode;
      el.legacyIdentityLabel.textContent = brandMode ? '品牌名称' : '产品名称 / SKU';
      state.obsidianContext = ''; state.obsidianSources = []; state.obsidianMeta = null;
      renderPreview(); renderObsidianSources(); renderObsidianTrace(); renderObsidianApplication();
      persistObsidianSettings();
    });
  });
  [el.legacyCategory, el.legacyProduct, el.legacyFocus, el.legacySolution].forEach(function (control) {
    control.addEventListener('input', function () {
      markObsidianDraftDirty('legacyDefaults');
      state.obsidianContext = ''; state.obsidianSources = []; state.obsidianMeta = null;
      renderPreview(); renderObsidianSources(); renderObsidianTrace(); renderObsidianApplication();
    });
    control.addEventListener('change', persistObsidianSettings);
  });
  el.quickStartBtn.addEventListener('click', openQuickWizard);
  el.importStartBtn.addEventListener('click', function () {
    el.localFilesPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
    el.sourceFiles.click();
  });
  el.obsidianStartBtn.addEventListener('click', function () {
    el.obsidianAdvanced.open = true;
    el.obsidianAdvanced.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
  el.wizardPrevBtn.addEventListener('click', function () {
    state.wizardStep = Math.max(1, state.wizardStep - 1);
    renderWizard();
  });
  el.wizardNextBtn.addEventListener('click', function () {
    if (state.wizardStep === 1 && !String(el.quickProduct.value || '').trim() && !String(el.quickCategory.value || '').trim()) {
      setState('请至少填写产品名称或产品品类', 'warn');
      el.quickProduct.focus();
      return;
    }
    state.wizardStep = Math.min(3, state.wizardStep + 1);
    renderWizard();
  });
  el.quickCreateBtn.addEventListener('click', createQuickStarter);
  el.copyObsidianTemplateBtn.addEventListener('click', copyObsidianTemplate);
  el.downloadObsidianTemplateBtn.addEventListener('click', downloadObsidianTemplate);
  el.saveBtn.addEventListener('click', saveCurrent);
  el.exportBtn.addEventListener('click', exportCurrent);
  el.clearBtn.addEventListener('click', clearCurrent);
  el.toggleObsidianKey.addEventListener('click', function () {
    var showing = el.obsidianApiKey.type === 'text';
    el.obsidianApiKey.type = showing ? 'password' : 'text';
    el.toggleObsidianKey.textContent = showing ? '显示' : '隐藏';
    el.toggleObsidianKey.setAttribute('aria-label', showing ? '显示 API Key' : '隐藏 API Key');
  });
  function invalidateObsidianPreviewForConnectionDraft(field) {
    markObsidianDraftDirty(field);
    state.obsidianContext = ''; state.obsidianSources = []; state.obsidianMeta = null;
    renderPreview(); renderObsidianSources(); renderObsidianTrace(); renderObsidianApplication();
  }
  el.obsidianBaseUrl.addEventListener('input', function () { invalidateObsidianPreviewForConnectionDraft('baseUrl'); });
  el.obsidianFolder.addEventListener('input', function () { invalidateObsidianPreviewForConnectionDraft('folder'); });
  el.obsidianMaxNotes.addEventListener('input', function () {
    markObsidianDraftDirty('maxNotes');
    state.obsidianContext = ''; state.obsidianSources = []; state.obsidianMeta = null;
    renderPreview(); renderObsidianSources(); renderObsidianTrace(); renderObsidianApplication();
  });
  el.obsidianApiKey.addEventListener('input', function () {
    markObsidianDraftDirty('apiKey');
    refreshSavedKeyAction();
  });
  el.connectObsidianBtn.addEventListener('click', connectObsidian);
  el.saveObsidianKeyBtn.addEventListener('click', saveObsidianKey);
  el.deleteObsidianKeyBtn.addEventListener('click', deleteObsidianKey);
  el.previewObsidianBtn.addEventListener('click', refreshObsidianPreview);
  el.disconnectObsidianBtn.addEventListener('click', disconnectObsidian);
  el.openObsidianCertBtn.addEventListener('click', openObsidianCertificate);
  el.checkObsidianCertBtn.addEventListener('click', checkObsidianCertificate);
  el.copyObsidianUrlBtn.addEventListener('click', copyObsidianUrl);
  el.obsidianEnabled.addEventListener('change', function () {
    state.obsidianContext = ''; state.obsidianSources = []; state.obsidianMeta = null; renderPreview(); renderObsidianSources(); renderObsidianTrace(); renderObsidianApplication();
    persistObsidianSettings();
  });
  el.obsidianPreviewScope.addEventListener('change', function () {
    state.obsidianContext = ''; state.obsidianSources = []; state.obsidianMeta = null;
    renderPreview(); renderObsidianSources(); renderObsidianTrace(); renderObsidianApplication();
    if (state.obsidian && state.obsidian.connected) refreshObsidianPreview();
  });
  var accountRefreshTimer = 0;
  function reloadAccountBoundState() {
    return loadCurrent().then(function () { return loadObsidianConnection(); });
  }
  function scheduleAccountRefresh() {
    clearTimeout(accountRefreshTimer);
    accountRefreshTimer = setTimeout(function () { reloadAccountBoundState(); }, 80);
  }
  window.addEventListener('focus', scheduleAccountRefresh);
  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState === 'visible') scheduleAccountRefresh();
  });
  renderWizard();
  renderObsidianApplication();
  reloadAccountBoundState();
})();
