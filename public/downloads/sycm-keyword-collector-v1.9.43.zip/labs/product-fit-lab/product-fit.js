'use strict';
(function () {
  var CONTRACT = globalThis.SZ_SUBJECT_ORCHESTRATION;
  var ASSETS = globalThis.SZ_SUBJECT_ASSETS;
  if (!CONTRACT || !ASSETS) throw new Error('商品承接合同或素材库未加载');
  var LINK_KEY = 'sycm_linkmatrix_json';
  var MARKET_KEY = 'sycm_mr_data';
  var state = { payload: null, plan: null, market: null, selectedTaskId: '', filter: 'all', search: '', objectUrls: [] };
  var $ = function (id) { return document.getElementById(id); };

  function getStore(keys) {
    return new Promise(function (resolve, reject) {
      try { chrome.storage.local.get(keys, function (r) { var e = chrome.runtime.lastError; e ? reject(new Error(e.message)) : resolve(r || {}); }); }
      catch (e) { reject(e); }
    });
  }
  function setStore(values) {
    return new Promise(function (resolve, reject) {
      try { chrome.storage.local.set(values, function () { var e = chrome.runtime.lastError; e ? reject(new Error(e.message)) : resolve(); }); }
      catch (e) { reject(e); }
    });
  }
  function send(type, payload) {
    return new Promise(function (resolve) {
      try { chrome.runtime.sendMessage({ type: type, payload: payload || {} }, function (r) { var _ = chrome.runtime.lastError; resolve(r || { ok: false, error: '后台无响应' }); }); }
      catch (e) { resolve({ ok: false, error: e.message || String(e) }); }
    });
  }
  function escapeHtml(value) { return String(value == null ? '' : value).replace(/[&<>"']/g, function (ch) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch]; }); }
  function taskById(id) { return (state.plan && state.plan.tasks || []).find(function (task) { return task.subjectTaskId === id; }) || null; }
  function selectedTask() { return taskById(state.selectedTaskId); }
  function statusGroup(task) {
    var status = CONTRACT.taskStatus(task);
    if (status === 'ready') return 'ready';
    if (status === 'needs_report' || status === 'report_ready') return 'no_product';
    if (status === 'skipped' || status === 'later') return 'skipped';
    return 'pending';
  }
  function statusLabel(status) {
    return ({ ready: '可生产', pending: '待选择', needs_assets: '待传主体', needs_sku: 'SKU未填（可选）', needs_facts: '待确认事实',
      needs_report: '待开款报告', report_ready: '报告已生成', skipped: '本批跳过', later: '稍后处理' })[status] || status;
  }
  function persist(message) {
    CONTRACT.syncBindings(state.plan);
    state.payload.subjectPlan = state.plan;
    state.payload.subjectPlanUpdatedAt = Date.now();
    var values = {}; values[LINK_KEY] = state.payload;
    return setStore(values).then(function () {
      if ($('saveState')) $('saveState').textContent = message || '已保存到当前链接清单。';
      renderAll();
      return true;
    }).catch(function (error) {
      if ($('saveState')) $('saveState').textContent = '保存失败：' + error.message;
      return false;
    });
  }
  function summaryText() {
    var summary = CONTRACT.planSummary(state.plan);
    return summary.links + ' 条链接 → ' + summary.total + ' 个主体子批次 ｜ 可生产 ' + summary.ready + ' ｜ 待承接 ' + summary.pending + ' ｜ 无商品/报告 ' + summary.noProduct + ' ｜ 跳过/稍后 ' + summary.skipped;
  }
  function renderCounts() {
    var summary = CONTRACT.planSummary(state.plan);
    $('fitSummary').textContent = summaryText() + '。主图与详情会按路线生成不同子批次，最终仍按全局 L 编号排序。';
    $('statusCounts').innerHTML = [
      ['主体批次', summary.total], ['可生产', summary.ready], ['待承接', summary.pending], ['无商品', summary.noProduct]
    ].map(function (item) { return '<div class="count-card"><b>' + item[1] + '</b><span>' + item[0] + '</span></div>'; }).join('');
  }
  function visibleTasks() {
    return (state.plan.tasks || []).filter(function (task) {
      if (state.filter !== 'all' && statusGroup(task) !== state.filter) return false;
      if (!state.search) return true;
      var hay = [task.subjectTaskId, task.label, task.category, (task.linkIds || []).join(' '), (task.requiredFacts || []).join(' ')].join(' ').toLowerCase();
      return hay.indexOf(state.search.toLowerCase()) >= 0;
    });
  }
  function renderCards() {
    var tasks = visibleTasks();
    $('visibleTaskCount').textContent = tasks.length + ' 项';
    $('taskCards').innerHTML = tasks.map(function (task) {
      var status = CONTRACT.taskStatus(task);
      return '<article class="task-card ' + (task.subjectTaskId === state.selectedTaskId ? 'active' : '') + '" data-task-id="' + escapeHtml(task.subjectTaskId) + '">' +
        '<span class="task-id">' + escapeHtml(task.subjectTaskId) + '</span><div><h3>' + escapeHtml(task.label) + '</h3>' +
        '<p>' + escapeHtml((task.requiredFacts || []).join(' · ') || '属性待用户确认') + '</p><div class="task-links">' + escapeHtml((task.linkIds || []).join('、')) + '</div></div>' +
        '<span class="status-chip ' + status + '">' + escapeHtml(statusLabel(status)) + '</span></article>';
    }).join('') || '<div class="empty-detail">当前筛选下没有任务。</div>';
  }
  function clearObjectUrls() { state.objectUrls.forEach(function (url) { try { URL.revokeObjectURL(url); } catch (_) {} }); state.objectUrls = []; }
  function renderAssetGrid(task) {
    clearObjectUrls();
    var refs = task.subjectAssets || [];
    $('subjectAssets').innerHTML = refs.map(function (ref) { return '<div class="asset-card" data-asset-id="' + escapeHtml(ref.assetId) + '"><span>载入中…</span><button data-remove-role="subject" data-asset-id="' + escapeHtml(ref.assetId) + '" title="移除">×</button></div>'; }).join('');
    ASSETS.getMany(refs.map(function (ref) { return ref.assetId; })).then(function (records) {
      var found = {};
      records.forEach(function (record) {
        found[record.assetId] = true;
        var card = $('subjectAssets').querySelector('[data-asset-id="' + record.assetId + '"]');
        if (!card) return;
        var url = URL.createObjectURL(record.blob); state.objectUrls.push(url);
        card.innerHTML = '<img src="' + url + '" alt="商品主体"><button data-remove-role="subject" data-asset-id="' + escapeHtml(record.assetId) + '" title="移除">×</button>';
      });
      var missing = refs.filter(function (ref) { return !found[ref.assetId]; });
      if (missing.length) $('recognitionState').textContent = '有 ' + missing.length + ' 张素材只保留了 ID，但本设备缺少文件；不会用其他图片兜底。';
    });
    var modelCount = (task.modelAssets || []).length;
    var mainTemplates = task.visualProfiles && task.visualProfiles.main && task.visualProfiles.main.templateAssetIds || [];
    var detailTemplates = task.visualProfiles && task.visualProfiles.detail && task.visualProfiles.detail.templateAssetIds || [];
    $('roleAssets').textContent = '详情模特 ' + modelCount + ' 张（可选）｜主图模板 ' + mainTemplates.length + ' 张｜详情模板 ' + detailTemplates.length + ' 张。模板只提供风格/布局。';
  }
  function setInput(id, value) { if ($(id)) $(id).value = value == null ? '' : value; }
  function renderReport(task) {
    var report = task.openingReport;
    $('acceptOpeningSuggestionBtn').hidden = !(report && report.evidenceStatus === 'supported' && report.suggestions && report.suggestions.length);
    if (!report) { $('openingReport').innerHTML = ''; return; }
    var html = '<div class="report-message">' + escapeHtml(report.message || '') + '</div>';
    (report.benchmarks || []).slice(0, 6).forEach(function (item) { html += '<div class="benchmark"><b>Top' + escapeHtml(item.rank) + '</b> ' + escapeHtml(item.title) + '<br><small>命中：' + escapeHtml((item.hits || []).join('、')) + '</small></div>'; });
    if (report.suggestions && report.suggestions.length) html += '<ol class="report-suggestions">' + report.suggestions.map(function (item) { return '<li>' + escapeHtml(item) + '</li>'; }).join('') + '</ol>';
    $('openingReport').innerHTML = html;
  }
  function renderDetail() {
    var task = selectedTask();
    $('emptyDetail').hidden = !!task; $('taskDetail').hidden = !task;
    if (!task) return;
    var status = CONTRACT.taskStatus(task);
    $('detailTaskId').textContent = task.subjectTaskId; $('detailTaskLabel').textContent = task.label;
    $('detailStatus').className = 'status-chip ' + status; $('detailStatus').textContent = statusLabel(status);
    $('linkChips').innerHTML = (task.linkIds || []).map(function (id) { return '<span>' + escapeHtml(id) + '</span>'; }).join('');
    $('hardFacts').innerHTML = '<b>必须匹配：</b>' + escapeHtml((task.requiredFacts || []).join(' · ') || task.subjectCategory) +
      (task.unsupportedReason ? '<br><span style="color:var(--error)">' + escapeHtml(task.unsupportedReason) + '</span>' : '');
    document.querySelectorAll('#decisionGrid button').forEach(function (btn) { btn.classList.toggle('active', btn.dataset.decision === task.decision); });
    $('overrideReasonWrap').hidden = task.decision !== 'near' && task.decision !== 'override';
    setInput('overrideReason', task.overrideReason); setInput('skuId', task.skuId);
    var facts = CONTRACT.productionFacts(task);
    setInput('factProductName', facts.productName); setInput('factCategory', facts.category || task.category); setInput('factStructure', facts.structure || task.hardAttributes.structure);
    setInput('factMaterial', facts.material || task.hardAttributes.material); setInput('factSize', facts.size || task.hardAttributes.size);
    setInput('factColors', facts.colors.join('、')); setInput('factStyle', facts.style); setInput('factProcess', facts.process); setInput('factNotes', facts.notes);
    $('factsApproved').checked = task.subjectFactsApproved === true;
    var visual = task.visualProfiles || {};
    setInput('mainStyle', visual.main && visual.main.style); setInput('mainLayout', visual.main && visual.main.layout); $('mainApproved').checked = !!(visual.main && visual.main.approved);
    setInput('detailStyle', visual.detail && visual.detail.style); setInput('detailLayout', visual.detail && visual.detail.layout); $('detailApproved').checked = !!(visual.detail && visual.detail.approved);
    var matched = CONTRACT.evaluateMatch(task, facts);
    $('matchResult').className = 'match-result ' + matched.level;
    $('matchResult').textContent = matched.conflicts.length ? ('不匹配：' + matched.conflicts.join('；')) : (matched.missing.length ? ('仍需确认：' + matched.missing.join('；')) : ('主体与任务硬属性匹配，匹配度 ' + matched.score + '。'));
    $('openingSection').hidden = task.decision !== 'no_product';
    $('subjectSection').hidden = task.decision === 'no_product' || task.decision === 'skipped' || task.decision === 'later';
    $('factsSection').hidden = $('subjectSection').hidden; $('roleAssetsSection').hidden = $('subjectSection').hidden;
    var factsSource = CONTRACT.subjectFactsSource(task);
    $('recognitionState').textContent = factsSource === 'link_plan'
      ? ('已从链接清单明确识别“' + facts.productName + '”，无需重复填写；AI 识别的其他属性仍需确认后才会采用。')
      : (task.recognition ? 'AI 已给出建议；当前只以你勾选确认后的补充事实为准。' : '产品名称不明确时可用 AI 识别，其他建议需确认后才会采用。');
    renderAssetGrid(task); renderReport(task);
  }
  function renderAll() { renderCounts(); renderCards(); renderDetail(); }
  function readFactsForm() {
    var currentTask = selectedTask();
    var acceptedInnovation = currentTask && currentTask.subjectFacts && currentTask.subjectFacts.acceptedInnovation
      ? currentTask.subjectFacts.acceptedInnovation
      : null;
    return { productName: $('factProductName').value.trim(), category: $('factCategory').value.trim(), structure: $('factStructure').value.trim(),
      material: $('factMaterial').value.trim(), size: $('factSize').value.trim(), colors: $('factColors').value.split(/[,，、|]/).map(function (x) { return x.trim(); }).filter(Boolean),
      style: $('factStyle').value.trim(), process: $('factProcess').value.trim(), notes: $('factNotes').value.trim(), acceptedInnovation: acceptedInnovation };
  }
  function readTaskForm(task) {
    task.skuId = $('skuId').value.trim(); task.overrideReason = $('overrideReason').value.trim(); task.subjectFacts = readFactsForm();
    task.subjectFactsApproved = $('factsApproved').checked;
    task.visualProfiles = task.visualProfiles || {};
    task.visualProfiles.main = Object.assign(task.visualProfiles.main || {}, { route: 'main', style: $('mainStyle').value.trim(), layout: $('mainLayout').value.trim(), approved: $('mainApproved').checked });
    task.visualProfiles.detail = Object.assign(task.visualProfiles.detail || {}, { route: 'detail', style: $('detailStyle').value.trim(), layout: $('detailLayout').value.trim(), approved: $('detailApproved').checked });
    task.updatedAt = Date.now(); CONTRACT.refreshTaskFingerprints(task); task.status = CONTRACT.taskStatus(task); return task;
  }
  function saveCurrentTask(message) { var task = selectedTask(); if (!task) return Promise.resolve(false); readTaskForm(task); return persist(message || ('已保存 ' + task.subjectTaskId + '。')); }
  function uploadFiles(role, files) {
    var task = selectedTask(); if (!task) return;
    files = Array.prototype.slice.call(files || []);
    var max = role === 'subject' ? 3 : 6;
    if (role === 'subject') files = files.slice(0, Math.max(0, max - (task.subjectAssets || []).length));
    Promise.all(files.map(function (file, index) { return ASSETS.putFile(file, { role: role, angle: role === 'subject' ? ['front', 'side', 'back'][(task.subjectAssets || []).length + index] : '' }); })).then(function (refs) {
      if (role === 'subject') task.subjectAssets = (task.subjectAssets || []).concat(refs).slice(0, 3);
      else if (role === 'model') task.modelAssets = (task.modelAssets || []).concat(refs).slice(0, 6);
      else {
        task.visualProfiles.main.templateAssetIds = Array.from(new Set((task.visualProfiles.main.templateAssetIds || []).concat(refs.map(function (ref) { return ref.assetId; })))).slice(0, 6);
        task.visualProfiles.detail.templateAssetIds = Array.from(new Set((task.visualProfiles.detail.templateAssetIds || []).concat(refs.map(function (ref) { return ref.assetId; })))).slice(0, 6);
      }
      CONTRACT.refreshTaskFingerprints(task); return persist('素材已保存在本机并绑定 ' + task.subjectTaskId + '。');
    }).catch(function (error) { $('saveState').textContent = '素材保存失败：' + error.message; });
  }
  function removeAsset(role, assetId) {
    var task = selectedTask(); if (!task) return;
    if (role === 'subject') task.subjectAssets = (task.subjectAssets || []).filter(function (item) { return item.assetId !== assetId; });
    CONTRACT.refreshTaskFingerprints(task); persist('已从任务解绑该素材（本机素材文件仍保留，可供其他任务复用）。');
  }
  function analyzeSubject() {
    var task = selectedTask(); if (!task || !(task.subjectAssets || []).length) { $('recognitionState').textContent = '请先上传至少1张商品主体图。'; return; }
    $('analyzeSubjectBtn').disabled = true; $('recognitionState').textContent = '正在识别可见属性…';
    ASSETS.getDataUrls(task.subjectAssets.map(function (item) { return item.assetId; })).then(function (items) {
      if (items.length !== task.subjectAssets.length) throw new Error('本设备缺少部分主体素材，不会自动换图兜底');
      return send('ANALYZE_SUBJECT_ASSET', { category: task.category, requiredFacts: task.requiredFacts, productImages: items.map(function (item) { return item.dataUrl; }) });
    }).then(function (resp) {
      if (!resp || !resp.ok) throw new Error(resp && resp.error || '识别失败');
      task.recognition = resp.data || {}; task.recognitionSuggestedAt = Date.now();
      var data = task.recognition;
      setInput('factProductName', data.productName || $('factProductName').value); setInput('factCategory', data.category || $('factCategory').value);
      setInput('factStructure', data.structure || $('factStructure').value); setInput('factMaterial', data.material || $('factMaterial').value);
      setInput('factSize', data.size || $('factSize').value); setInput('factColors', (data.colors || []).join('、') || $('factColors').value);
      setInput('factStyle', data.style || $('factStyle').value); setInput('factProcess', data.process || $('factProcess').value);
      task.subjectFactsApproved = false; $('factsApproved').checked = false;
      $('recognitionState').textContent = 'AI 建议已填入表单，请人工核对并勾选确认。'; return persist('AI 识别建议已保存，但尚未批准为商品事实。');
    }).catch(function (error) { $('recognitionState').textContent = '识别失败：' + error.message; }).finally(function () { $('analyzeSubjectBtn').disabled = false; });
  }
  function buildOpeningReport() {
    var task = selectedTask(); if (!task) return;
    var report = CONTRACT.buildOpeningReport(task, state.market || []); task.openingReport = report; persist('开款报告已按当前本机 Top300 证据生成。');
  }
  function acceptOpeningSuggestion() {
    var task = selectedTask();
    var suggestion = task && task.openingReport && task.openingReport.suggestions && task.openingReport.suggestions[0];
    if (!task || !suggestion) return;
    task.subjectFacts = Object.assign({}, task.subjectFacts || {}, { acceptedInnovation: suggestion });
    task.subjectFactsApproved = false;
    task.acceptedInnovationAt = Date.now();
    CONTRACT.refreshTaskFingerprints(task);
    persist('已采纳为待开发方向；它不会进入生产提示词，仍需开款、上传真实主体并重新确认商品事实。');
  }
  function openPromptLab(route, taskId) {
    route = route === 'detail' ? 'detail' : 'main';
    var query = '?source=product-fit&subjectRoute=' + route + (route === 'detail' ? '&mode=detail&detailMode=link' : '');
    if (taskId) query += '&subjectTaskId=' + encodeURIComponent(taskId);
    chrome.tabs.create({ url: chrome.runtime.getURL('labs/image-prompt-lab/promptlab.html') + query });
  }
  function bind() {
    $('taskCards').addEventListener('click', function (event) { var card = event.target.closest('.task-card'); if (!card) return; state.selectedTaskId = card.dataset.taskId; renderAll(); });
    $('statusFilters').addEventListener('click', function (event) { var btn = event.target.closest('button[data-status]'); if (!btn) return; state.filter = btn.dataset.status; document.querySelectorAll('#statusFilters button').forEach(function (item) { item.classList.toggle('active', item === btn); }); renderCards(); });
    $('taskSearch').addEventListener('input', function () { state.search = this.value.trim(); renderCards(); });
    $('decisionGrid').addEventListener('click', function (event) { var btn = event.target.closest('button[data-decision]'); var task = selectedTask(); if (!btn || !task) return; task.decision = btn.dataset.decision; if (task.decision === 'near') task.decision = 'near'; persist('已记录商品承接选择：' + (CONTRACT.matchStatus[task.decision] || task.decision) + '。'); });
    $('subjectFiles').addEventListener('change', function () { uploadFiles('subject', this.files); this.value = ''; });
    $('modelFiles').addEventListener('change', function () { uploadFiles('model', this.files); this.value = ''; });
    $('templateFiles').addEventListener('change', function () { uploadFiles('template', this.files); this.value = ''; });
    $('subjectAssets').addEventListener('click', function (event) { var btn = event.target.closest('[data-remove-role]'); if (btn) removeAsset(btn.dataset.removeRole, btn.dataset.assetId); });
    $('analyzeSubjectBtn').addEventListener('click', analyzeSubject); $('saveTaskBtn').addEventListener('click', function () { saveCurrentTask(); });
    $('buildOpeningReportBtn').addEventListener('click', buildOpeningReport);
    $('acceptOpeningSuggestionBtn').addEventListener('click', acceptOpeningSuggestion);
    $('openMainTaskBtn').addEventListener('click', function () { saveCurrentTask().then(function () { openPromptLab('main', state.selectedTaskId); }); });
    $('openDetailTaskBtn').addEventListener('click', function () { saveCurrentTask().then(function () { openPromptLab('detail', state.selectedTaskId); }); });
    $('openMainAllBtn').addEventListener('click', function () { openPromptLab('main', ''); }); $('openDetailAllBtn').addEventListener('click', function () { openPromptLab('detail', ''); });
  }
  function init() {
    bind();
    getStore([LINK_KEY, MARKET_KEY]).then(function (stored) {
      var payload = stored[LINK_KEY];
      if (!payload || !CONTRACT.payloadRows(payload).length) throw new Error('还没有链接清单，请先在插件中生成并确认。');
      state.payload = payload; state.market = stored[MARKET_KEY] || null;
      state.plan = CONTRACT.createPlan(payload, payload.subjectPlan || null); state.payload.subjectPlan = state.plan;
      state.selectedTaskId = (state.plan.tasks[0] && state.plan.tasks[0].subjectTaskId) || '';
      return persist('商品承接计划已载入。');
    }).catch(function (error) { $('fitSummary').textContent = error.message || String(error); $('taskCards').innerHTML = '<div class="empty-detail">' + escapeHtml(error.message || error) + '</div>'; });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
